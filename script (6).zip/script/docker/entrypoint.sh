#!/bin/sh
# Prepare the writable state, then hand over to whatever was asked for.
#
# Everything here is idempotent, because it runs on every container start -- a
# restart, a redeploy, a crash loop. Nothing here destroys data.
set -eu

DB="${DJANGO_DATA_DIR:-/data}/outreach.sqlite3"

echo "==> Lead Mapper starting"

# Which settings module, said out loud. Since the settings were split into
# base/development/production this is the single fact that most changes how the
# container behaves -- DEBUG, ALLOWED_HOSTS, cookie security, whether a missing
# SECRET_KEY is fatal -- and it can be overridden from four places: the image ENV,
# compose's `environment:`, the override file, and .env. One line in the log turns
# "why is it serving tracebacks" into a five-second answer.
echo "    settings: ${DJANGO_SETTINGS_MODULE:-config.settings.development (manage.py default)}"

case "${DJANGO_SETTINGS_MODULE:-}" in
    *development)
        # Not fatal: the development override deliberately does this, and a laptop is
        # entitled to run whatever it likes. But it is worth being loud about, because
        # the same line on a public box means DEBUG is on and ALLOWED_HOSTS is "*".
        echo "WARNING: running with the DEVELOPMENT settings -- DEBUG is on and any" >&2
        echo "         Host header is accepted. Correct for a laptop; on a reachable" >&2
        echo "         machine set DJANGO_SETTINGS_MODULE=config.settings.production." >&2
        ;;
esac

# Refuse to run with the development secret key. The consequences are not
# theoretical: SECRET_KEY signs the session cookies, and it also derives the
# encryption key for AI credentials saved through Settings. A container that
# silently used the fallback would issue forgeable sessions and write credentials
# nobody can decrypt afterwards.
if [ -z "${DJANGO_SECRET_KEY:-}" ]; then
    echo "FATAL: DJANGO_SECRET_KEY is not set." >&2
    echo "       Generate one with:" >&2
    echo "         python -c 'import secrets; print(secrets.token_urlsafe(64))'" >&2
    echo "       and put it in .env. Keep it stable: changing it makes AI keys" >&2
    echo "       already saved in Settings unreadable." >&2
    exit 1
fi

if [ "${OUTREACH_BLOCK_SEND:-}" = "1" ]; then
    # It exists for the test suite. On a real deployment it would silently
    # disable both sending and reply reading, which looks like a bug for days.
    echo "WARNING: OUTREACH_BLOCK_SEND=1 -- no email will be sent and no inbox" >&2
    echo "         will be read. Remove it unless that is what you want." >&2
fi

# The static volume is initialised from the image the first time it is created and
# never refreshed afterwards, so after a rebuild it would still hold the previous
# release's CSS and JS while the templates came from the new image. Re-running
# collectstatic writes into the mounted volume and copies only what changed.
echo "==> Collecting static files"
python manage.py collectstatic --noinput --clear >/dev/null

echo "==> Applying migrations"
python manage.py migrate --noinput

# WAL journal mode, so the campaign worker thread can write while the workspace
# polls for progress instead of the two blocking each other. Stored in the
# database file itself, so this is a no-op after the first run -- it is here rather
# than in a manual step so a fresh volume is never missed.
if [ -f "$DB" ]; then
    MODE=$(sqlite3 "$DB" "PRAGMA journal_mode;" 2>/dev/null || echo unknown)
    if [ "$MODE" != "wal" ]; then
        echo "==> Switching the database to WAL journal mode (was: $MODE)"
        sqlite3 "$DB" "PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL;" >/dev/null
    fi
fi

# A campaign whose container was replaced mid-run is left in a working phase with
# no thread behind it. The application already detects that and offers Resume in
# the workspace, so this is a note rather than an action: recovering it silently
# here would restart AI work nobody asked for, on a container that has only just
# come up.
WORKING="'crawling', 'analysing', 'generating', 'cancel_requested'"
# `-v 0` matters: without it Django prints its "N objects imported automatically"
# notice to stdout, and the count comes back as two lines.
STUCK=$(python manage.py shell -v 0 -c \
    "from apps.outreach.models import Campaign; \
     print(Campaign.objects.filter(phase__in=[$WORKING]).count())" \
    2>/dev/null | tail -1 || echo 0)
if [ "${STUCK:-0}" != "0" ]; then
    echo "==> $STUCK campaign(s) were interrupted by a restart."
    echo "    Open the workspace and press Resume -- leads already finished are"
    echo "    skipped, so nothing is analysed or drafted twice."
fi

echo "==> Ready"
exec "$@"
