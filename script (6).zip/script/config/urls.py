"""
Root URL configuration.

`/login`, `/signup` and `/logout` live at the top level because they are not
part of either feature app, and `/dashboard` does too because it is the
authenticated home rather than a page inside the outreach workflow.

Everything except the three auth routes requires a signed-in user, enforced by
LoginRequiredMiddleware rather than per-view decorators.
"""

from django.urls import include, path

from apps.outreach import views as outreach_views

urlpatterns = [
    path("", include("apps.accounts.urls")),
    path("dashboard", outreach_views.dashboard, name="dashboard"),
    # The credential pool, at the prefix it has always answered on. The routes
    # live in `apps.ai` now; the paths are unchanged so nothing a browser or a
    # script knows about moves.
    path("outreach/ai/", include("apps.ai.urls")),
    # Settings → Database, under the same prefix as the Settings page it is reached
    # from, so the URL reads as the sub-page it is. Listed before the outreach
    # include only for readability -- `settings` and `settings/database` do not
    # compete, so the order does not decide anything.
    path("outreach/", include("apps.core.urls")),
    path("outreach/", include("apps.outreach.urls")),
    path("", include("apps.leads.urls")),
]
