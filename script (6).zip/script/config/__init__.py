"""Project configuration: settings, URLs and the WSGI/ASGI entry points."""
