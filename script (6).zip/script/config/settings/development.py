"""
Local development.

The differences from `base.py` are all in one direction: more visible errors, fewer
transport requirements, faster tests. Every one of them would be wrong in
production, which is why they are in a file production never imports.

    DJANGO_SETTINGS_MODULE=config.settings.development

This is `manage.py`'s default, so a fresh checkout runs with no configuration at
all.
"""

import os
import sys

from .base import *  # noqa: F403
from .base import DATA_DIR, INSTALLED_APPS  # noqa: F401

DEBUG = True

#: Anything, because a developer reaches the site by whatever name is convenient
#: -- localhost, a LAN address, a tunnel host. Never acceptable in production,
#: where a permissive host list is a cache-poisoning and password-reset-link
#: forgery vector.
ALLOWED_HOSTS = ["*"]

#: A known, useless key -- but only when the environment has not supplied a real
#: one. Development needs *a* key for sessions and for the credential encryption to
#: work at all; making it obviously fake is better than a real one sitting in a
#: checkout, and `production.py` refuses to start with it.
#:
#: The `or` matters more than it looks. `manage.py` defaults to this module, so a
#: management command run on a server -- a cron job preparing follow-ups, an
#: automation pass -- lands here unless something names the production settings.
#: Overriding `DJANGO_SECRET_KEY` unconditionally meant those commands ran with a
#: key that was not the one the web process uses, and `SECRET_KEY` derives the
#: encryption key for the AI credentials saved through Settings: every one of them
#: would have read as "cannot be decrypted", from a cron job nobody was watching.
#: Honouring the environment means the worst case is a *correct* run under the
#: wrong DEBUG setting rather than a subtly broken one.
SECRET_KEY = os.environ.get("DJANGO_SECRET_KEY", "") or (
    "django-insecure-development-only-not-a-secret")

#: Local development is plain HTTP, and a Secure cookie is never sent over it --
#: so with these on you cannot stay signed in.
SESSION_COOKIE_SECURE = False
CSRF_COOKIE_SECURE = False

#: Password hashing is deliberately slow; that is the point of PBKDF2. Under
#: `manage.py test` it becomes the dominant cost, because every test signs an
#: account in. MD5 is worthless for storing a real password and is used here only
#: while the suite runs.
if "test" in sys.argv:
    PASSWORD_HASHERS = ["django.contrib.auth.hashers.MD5PasswordHasher"]
