"""
Settings shared by every environment.

Split three ways rather than switched on `DEBUG`: `development.py` and
`production.py` each import this and then say only what differs. The reason is that
a single file full of `if DEBUG` is a file where the production behaviour is never
the one you can read straight through -- and where forgetting to set an environment
variable silently gives you the development answer.

What lives where:

  * **here** -- the application itself: installed apps, middleware, templates,
    database, authentication, and every `OUTREACH_*` feature setting.
  * **development.py** -- `DEBUG`, a permissive host list, a throwaway secret key,
    and the fast password hasher the test suite needs.
  * **production.py** -- HTTPS enforcement, HSTS, the proxy header, and the refusal
    to start without a real secret key.

Nothing here reads a secret from source. `_load_env` below loads `.env` into the
environment, a real environment variable always wins over the file, and the file is
git-ignored.
"""

import os
import sys
from pathlib import Path

#: The project root -- the directory holding `manage.py`. Three parents up
#: because this file is `config/settings/base.py`.
BASE_DIR = Path(__file__).resolve().parent.parent.parent

#: Where everything the application *writes* lives: the SQLite database and the
#: CSV/Excel exports.
#:
#: Separate from BASE_DIR because of containers. In an image the code directory is
#: replaced on every deploy, so a database inside it would be a new empty database
#: each time -- this is the one path a volume gets mounted at. Defaults to
#: BASE_DIR, so a local checkout is unchanged and needs no configuration.
DATA_DIR = Path(os.environ.get("DJANGO_DATA_DIR") or BASE_DIR)


def _load_env(path: Path = BASE_DIR / ".env") -> None:
    """Read KEY=VALUE lines from .env into the environment.

    Keeps the live SMTP password in a git-ignored file instead of in this
    source file. A real environment variable always wins, so CI and one-off
    shell overrides still work.
    """
    if not path.is_file():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip().strip("\"'"))


_load_env()

# Fine as-is for local use. Set the env var before exposing this anywhere.
#: Never a usable default in production -- `production.py` refuses to start
#: without a real one. See `development.py` for why a default exists at all.
SECRET_KEY = os.environ.get("DJANGO_SECRET_KEY", "")
#: Off in the shared settings, and switched on only by `development.py`. The
#: default matters: a deployment that forgets to name a settings module gets the
#: safe answer rather than a debug page with a traceback in it.
DEBUG = False

ALLOWED_HOSTS = [
    host.strip() for host in os.environ.get("DJANGO_ALLOWED_HOSTS", "").split(",")
    if host.strip()
]

INSTALLED_APPS = [
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    # This application's own, in dependency order: `ai` and `auditing` are
    # imported by `outreach` and import nothing of it.
    "apps.core",
    "apps.ai",
    "apps.auditing",
    "apps.accounts",
    "apps.leads",
    "apps.outreach",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    # Django's own middleware, added in 5.1: every view requires a logged-in
    # user unless it is explicitly marked otherwise with @login_not_required.
    # Deny-by-default is the point -- a new view added later is protected
    # without anybody remembering to protect it.
    "django.contrib.auth.middleware.LoginRequiredMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    # Sends X-Frame-Options: DENY. Now that there are sessions, a page framed by
    # another site is a clickjacking target -- an invisible frame over a
    # convincing decoy can turn a stray click into a real, authenticated action.
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    # Binds the signed-in account to the AI credential resolver for the length of
    # the request. Without it, code three layers down -- ai.generate() ->
    # backend().complete() -> client() -> credentials.require() -- would have no
    # way to know whose API key to use, and threading an owner argument through
    # all of it would break the first time somebody forgot.
    "apps.ai.context.AiOwnerMiddleware",
]

ROOT_URLCONF = "config.urls"
WSGI_APPLICATION = "config.wsgi.application"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        # The project's own directory first, then each app's. Templates live in
        # `templates/<app>/` at the project root; APP_DIRS stays on so a
        # third-party app's own templates are still found.
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

# SQLite, purely so the email workflow can keep its sending history and refuse
# to contact the same lead twice. The scraper still uses no database at all.
# `timeout` matters: the background analyse/generate/send jobs write from a
# worker thread while the page polls for progress from the request thread.
#: The default: one SQLite file, which needs no configuration and is what a fresh
#: checkout runs on.
#:
#: `timeout` matters for it: the background analyse/generate/send jobs write from a
#: worker thread while the page polls for progress from the request thread.
_SQLITE = {
    "ENGINE": "django.db.backends.sqlite3",
    "NAME": DATA_DIR / "outreach.sqlite3",
    "OPTIONS": {"timeout": 20},
}

DATABASES = {"default": _SQLITE}

#: DATABASE_URL moves the application onto Postgres -- Supabase or anything else
#: that speaks it. Unset, nothing changes: the URL is the only switch, there is no
#: second settings module to keep in step, and a deployment that never sets it
#: behaves exactly as it always has.
#:
#: A malformed URL is a hard failure rather than a quiet fall back to SQLite.
#: Falling back would mean a production deployment writing to a file nobody
#: intended, and discovering it later from the missing data.
#:
#: Settings → Database can override this in one direction only: a recorded choice
#: of "local" makes the application ignore `DATABASE_URL` and stay on the file.
#: That asymmetry is deliberate.
#:
#:   * Choosing *local* has to be able to override the environment, because
#:     otherwise the button does nothing on a deployment that has DATABASE_URL set
#:     -- which is every deployment that would ever want to switch back.
#:   * Choosing *Supabase* cannot invent a connection. The three fields on that
#:     page are PostgREST API credentials; the database password is in
#:     DATABASE_URL, and without it there is nothing to connect to. The page
#:     refuses the switch and says so rather than recording a choice that would
#:     leave the next restart unable to serve.
#:
#: With no choice recorded -- which is every existing deployment, because the file
#: only appears when somebody presses a button -- this block behaves exactly as it
#: did before the page existed.
_DB_SELECTION = ""
try:
    from apps.core.database import selection as _database_selection

    _DB_SELECTION = _database_selection(DATA_DIR)
except Exception:      # noqa: BLE001 - see below
    # Reading a small JSON file, so the realistic failures are a permissions
    # problem or a truncated write. Neither is a reason a deployment cannot start,
    # and the consequence of ignoring it is the old behaviour rather than a wrong
    # one. `apps.core.database` re-reads the file for the settings page, which is
    # where the error becomes visible and actionable.
    _DB_SELECTION = ""

if os.environ.get("DATABASE_URL") and _DB_SELECTION != "local":
    from apps.core.dburl import parse as _parse_database_url

    DATABASES["default"] = _parse_database_url(
        os.environ["DATABASE_URL"],
        conn_max_age=int(os.environ.get("DJANGO_CONN_MAX_AGE", "600") or 0),
    )

#: The database being migrated *from*, for `manage.py db_transfer`. Present only
#: while a migration is happening, so the application never carries a second
#: connection it does not use.
if os.environ.get("SQLITE_SOURCE"):
    DATABASES["sqlite_source"] = {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": os.environ["SQLITE_SOURCE"],
        "OPTIONS": {"timeout": 20},
        # Read-only in intent: the transfer only ever selects from it. Stated here
        # so a mistake in the command cannot rewrite the file it is copying.
        "TEST": {"MIRROR": "default"},
    }

# --------------------------------------------------------------------------- #
# Authentication
# --------------------------------------------------------------------------- #

#: Email is the login identifier, so the backend looks users up by email
#: (case-insensitively) rather than by username. ModelBackend stays in the list
#: so `createsuperuser` and the admin-style username path keep working.
AUTHENTICATION_BACKENDS = [
    "apps.accounts.backends.EmailBackend",
    "django.contrib.auth.backends.ModelBackend",
]

LOGIN_URL = "/login"
LOGIN_REDIRECT_URL = "/dashboard"
LOGOUT_REDIRECT_URL = "/login"

#: Django's standard validators. Rejecting a password is cheaper than dealing
#: with a compromised account, and the messages are already written and
#: translated.
AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation."
             "UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
     "OPTIONS": {"min_length": 10}},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

# Session cookies. HttpOnly and SameSite are set explicitly rather than left to
# the defaults so the intent is visible: no JavaScript reads the session, and it
# is not sent on cross-site requests.
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = "Lax"
CSRF_COOKIE_SAMESITE = "Lax"
#: Two weeks, refreshed on each request so an active user is not logged out
#: mid-campaign, and an idle one expires.
SESSION_COOKIE_AGE = 60 * 60 * 24 * 14
SESSION_SAVE_EVERY_REQUEST = True
SESSION_EXPIRE_AT_BROWSER_CLOSE = False

#: Secure cookies are the default here and switched *off* by `development.py`,
#: which is the safe direction: a deployment that names no settings module gets
#: cookies that will not travel over plain HTTP rather than cookies that will.
#: HTTPS enforcement itself lives in `production.py`.
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True

STATIC_URL = "static/"
#: Where `collectstatic` writes. Never served from directly in development.
STATIC_ROOT = BASE_DIR / "staticfiles"
#: The project's own assets, as opposed to any app's. One place for the CSS and
#: JS this application owns, so a stylesheet is not hidden three directories
#: inside whichever app happened to need it first.
STATICFILES_DIRS = [BASE_DIR / "static"]

#: Uploaded and generated files. Nothing writes here yet; the directory exists so
#: that when something does, it has a configured home rather than inventing one.
MEDIA_URL = "media/"
MEDIA_ROOT = DATA_DIR / "media"

LANGUAGE_CODE = "en-us"
TIME_ZONE = "UTC"
USE_I18N = True
USE_TZ = True

# --------------------------------------------------------------------------- #
# App settings
# --------------------------------------------------------------------------- #

#: Where generated CSV files are written.
EXPORT_DIR = DATA_DIR / "exports"

#: Nominatim's usage policy asks for a contact address in the User-Agent so
#: they can get in touch if this app ever misbehaves. It has to be a real
#: address -- placeholders like you@example.com are answered with a 403 -- so
#: this defaults to the address the project was set up with. Change it, or set
#: OSM_CONTACT_EMAIL, if a different mailbox should own the traffic.
OSM_CONTACT_EMAIL = os.environ.get(
    "OSM_CONTACT_EMAIL", "muhammadsaqibyounas11@gmail.com"
)

# --------------------------------------------------------------------------- #
# Outreach sender identity
# --------------------------------------------------------------------------- #

#: Default identity for outreach campaigns. These pre-fill the sender form on
#: the setup page; each campaign stores whatever was submitted, so a one-off can
#: still be sent from a different account by editing the form.
#:
#: The address must be one you can actually log in to over SMTP -- it becomes
#: the From header, and apps/outreach/mail/transport.py refuses to send if the visible sender
#: and the SMTP login differ. For Gmail that means a 16-character App Password,
#: not the account password: Google rejects plain passwords on SMTP.
OUTREACH_SENDER_EMAIL = os.environ.get(
    "OUTREACH_SENDER_EMAIL", "muhammadsaqibyounas11@gmail.com"
)
OUTREACH_SENDER_NAME = os.environ.get(
    "OUTREACH_SENDER_NAME", "Muhammad Saqib Younas"
)
OUTREACH_SENDER_COMPANY = os.environ.get("OUTREACH_SENDER_COMPANY", "7skysolutions")

#: Matches the address above -- see PROVIDERS in apps/outreach/mail/providers.py.
OUTREACH_PROVIDER = os.environ.get("OUTREACH_PROVIDER", "gmail")

#: Hard block on opening an SMTP connection, on by default under `manage.py
#: test`. Real credentials now live in .env, so without this a stray test that
#: reached the send path could authenticate against Gmail and mail live people.
#: The suite mocks the transport anyway; this makes the mistake impossible
#: rather than merely unlikely.
OUTREACH_BLOCK_SEND = os.environ.get("OUTREACH_BLOCK_SEND") == "1" or "test" in sys.argv

# --------------------------------------------------------------------------- #
# Reply tracking and manual follow-ups
# --------------------------------------------------------------------------- #

#: How many follow-ups a single lead may ever receive. Reaching it closes the
#: lead to further follow-ups; the deliberate re-contact workflow is separate.
OUTREACH_FOLLOWUP_MAX = int(os.environ.get("OUTREACH_FOLLOWUP_MAX", "2"))

#: Days to wait before each follow-up becomes available, counted from the last
#: message actually sent to that lead. One entry per follow-up: the first number
#: gates follow-up #1, the second gates #2. A shorter list than
#: OUTREACH_FOLLOWUP_MAX reuses its final value for the remaining numbers.
OUTREACH_FOLLOWUP_DELAYS = [
    int(part) for part in
    os.environ.get("OUTREACH_FOLLOWUP_DELAYS", "2,7").replace(" ", "").split(",")
    if part
] or [3]

#: Where to read replies. Blank means "use the provider preset in
#: apps/outreach/mail/providers.py" -- the same account and password as sending, never a
#: second credential.
OUTREACH_IMAP_HOST = os.environ.get("OUTREACH_IMAP_HOST", "")
OUTREACH_IMAP_PORT = int(os.environ.get("OUTREACH_IMAP_PORT", "0") or 0)

#: How far back an inbox check looks. Replies older than this are assumed to
#: have been seen already, and it keeps the IMAP search cheap on a busy mailbox.
OUTREACH_INBOX_DAYS = int(os.environ.get("OUTREACH_INBOX_DAYS", "45"))

# --------------------------------------------------------------------------- #
# Lead scoring
# --------------------------------------------------------------------------- #

#: Outreach priority bands. A lead scoring at or above HOT is hot, and so on
#: down; below LOW it is a skip. Configurable because "worth emailing" depends on
#: how much list a user has to work through -- somebody with 2,000 leads can
#: afford to be pickier than somebody with 40.
OUTREACH_PRIORITY_HOT = int(os.environ.get("OUTREACH_PRIORITY_HOT", "80"))
OUTREACH_PRIORITY_WARM = int(os.environ.get("OUTREACH_PRIORITY_WARM", "60"))
OUTREACH_PRIORITY_LOW = int(os.environ.get("OUTREACH_PRIORITY_LOW", "40"))

#: Below this, the application does not recommend sending: it means there is not
#: enough reliable material to write anything worth reading. Advisory -- the user
#: can still send.
OUTREACH_READINESS_MIN = int(os.environ.get("OUTREACH_READINESS_MIN", "60"))

#: How long a stored website audit stays fresh. A stale audit is still used and
#: still shown; the lead page offers a re-analysis rather than silently spending
#: a crawl on page load.
OUTREACH_AUDIT_MAX_AGE_DAYS = int(
    os.environ.get("OUTREACH_AUDIT_MAX_AGE_DAYS", "30"))
