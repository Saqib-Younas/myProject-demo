"""
Production.

Everything here is about how the site is *served*: TLS, HSTS, the proxy header,
and the one refusal -- a deployment without a real secret key does not start.

    DJANGO_SETTINGS_MODULE=config.settings.production

That refusal is deliberate. A missing `DJANGO_SECRET_KEY` used to fall back to a
development default, which meant sessions signed with a key that is in the
repository and, since the same key derives the encryption for saved credentials,
saved passwords readable by anybody with the source. Failing at startup is the
kindest version of that problem.
"""

import os

from .base import *  # noqa: F403
from .base import BASE_DIR, SECRET_KEY  # noqa: F401

DEBUG = False

if not SECRET_KEY or SECRET_KEY.startswith("django-insecure"):
    raise RuntimeError(
        "DJANGO_SECRET_KEY is not set. Production will not start without one: it "
        "signs sessions and derives the encryption key for saved provider and "
        "mailbox credentials. Generate one with "
        "`python -c \"import secrets; print(secrets.token_urlsafe(50))\"` and put "
        "it in the environment or in .env."
    )

#: HTTPS enforcement, opt-in rather than on by default even here.
#:
#: Both of these break a site that is not actually served over HTTPS -- a redirect
#: loop in one case, and a browser that refuses to connect for the length of the
#: HSTS window in the other. HSTS in particular is hard to undo, because the
#: browser remembers it. So they are switched on by the deployment that knows it
#: has a certificate, not by a default that assumes one.
SECURE_SSL_REDIRECT = os.environ.get("DJANGO_SSL_REDIRECT") == "1"
SECURE_HSTS_SECONDS = int(os.environ.get("DJANGO_HSTS_SECONDS", "0") or 0)
SECURE_HSTS_INCLUDE_SUBDOMAINS = SECURE_HSTS_SECONDS > 0
SECURE_HSTS_PRELOAD = SECURE_HSTS_SECONDS > 0

#: Behind a reverse proxy that terminates TLS, this is how Django learns the
#: original request was HTTPS. Only trusted when the deployment says so: setting
#: it without a proxy that overwrites the header lets a client claim HTTPS.
if os.environ.get("DJANGO_TRUST_PROXY_TLS") == "1":
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")

#: Referrer and content-type headers. Cheap, and both are defaults Django
#: recommends for a deployed site.
SECURE_REFERRER_POLICY = "same-origin"
SECURE_CONTENT_TYPE_NOSNIFF = True

#: Logging to stdout, which is where a container's logs are read from. The
#: application's own loggers are noisy at DEBUG and quiet at INFO; INFO is the
#: level at which every send, skip and failure is recorded.
LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "plain": {"format": "{asctime} {levelname} {name}: {message}",
                  "style": "{"},
    },
    "handlers": {
        "console": {"class": "logging.StreamHandler", "formatter": "plain"},
    },
    "root": {"handlers": ["console"], "level": "INFO"},
    "loggers": {
        "django.request": {"handlers": ["console"], "level": "WARNING",
                           "propagate": False},
    },
}
