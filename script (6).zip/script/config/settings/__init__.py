"""Settings, split by environment. `base.py` is shared; the other two differ."""
