"""
The WSGI entry point, for gunicorn and anything else that serves traffic.

    gunicorn config.wsgi:application

**The default is production, and that is deliberate.** `manage.py` defaults to
`config.settings.development`, because a developer running `runserver` wants DEBUG and a
throwaway key. Nothing runs *this* module by accident: if a WSGI server is loading it,
something is serving requests to somebody.

Defaulting the other way was the arrangement that came out of splitting the settings, and
it fails in the worst possible direction -- a deployment that forgets to set
`DJANGO_SETTINGS_MODULE` comes up quietly with `DEBUG = True`, `ALLOWED_HOSTS = ["*"]`
and a published secret key, and looks like it is working. This way the same mistake fails
closed: `config.settings.production` refuses to start without a real `SECRET_KEY`, so a
misconfigured deployment stops instead of serving tracebacks to strangers.

`setdefault`, not an assignment, so an explicit `DJANGO_SETTINGS_MODULE` still wins --
including `config.settings.development`, if you really do want to point a WSGI server at
the development settings.
"""

import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.production")

application = get_wsgi_application()
