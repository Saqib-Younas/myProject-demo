"""
The ASGI entry point, for uvicorn, daphne or hypercorn.

    uvicorn config.asgi:application

Nothing in this project needs ASGI today -- there are no websockets and no async views,
and `config/wsgi.py` is what the documented deployments use. It is here because Django
generates it and because removing an entry point somebody might reach for is a worse
outcome than keeping seven lines.

The default is `production`, for the same reason as in `wsgi.py`: an ASGI server loading
this module is a server taking requests, and a deployment that forgets to set
`DJANGO_SETTINGS_MODULE` should fail closed rather than come up with `DEBUG = True`.
`setdefault` means an explicit value still wins.
"""

import os

from django.core.asgi import get_asgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.production")

application = get_asgi_application()
