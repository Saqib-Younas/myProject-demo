# Moving the database to Supabase Postgres

> **Settings → Database and this document do different things.** The page stores the
> Supabase URL and the two API keys, checks that Postgres is reachable, and records
> which database to open on the next restart. It moves no data. Copying your existing
> rows onto Postgres is `manage.py db_transfer`, below, and it is a separate explicit
> command precisely so that no button on a settings page can move a database by
> accident. `DATABASE_URL` is what actually connects, and it belongs in the
> environment: it carries the database password.

The application stores everything in one SQLite file. This moves it to Supabase
Postgres without changing a line of application code: Django's ORM speaks both, so
the switch is one environment variable.

**There was no Excel database to migrate.** The `.xlsx` file in `exports/` is a
report *generated from* the database — [history.py](apps/outreach/services/history.py) reads the
sheet only to collect the row ids it has already written, so it can append without
duplicating. The data has always lived in `outreach.sqlite3`.

---

## 1. What moves

| Table | Rows today |
| --- | --- |
| `auth_user` | 1 |
| `outreach_campaign` | 13 |
| `outreach_emaildraft` | 68 |
| `outreach_sentlead` | 4 |
| `outreach_websiteaudit`, `outreach_followup`, `outreach_suppression`, `outreach_providercredential`, `outreach_credentialevent`, `outreach_aiselection` | 0 |

**Not moved, deliberately:** `django_content_type`, `auth_permission` and
`django_session`. The first two are recreated by `migrate` with their own ids, so
copied rows would collide and nothing in this application references them by id. The
third is a browser cookie's other half — you sign in again, which is the safer
outcome anyway.

---

## 2. Before you start

- [ ] **Rotate the Supabase secret key.** It was pasted into a chat window, so
      treat it as public. Dashboard → Project Settings → API.
- [ ] Get the **database password** — Project Settings → Database. This is not one
      of the API keys; `sb_secret_…` cannot open a Postgres connection.
- [ ] Back up the SQLite file: `cp outreach.sqlite3 outreach.sqlite3.backup`
- [ ] `pip install -r requirements/development.txt` on a laptop, or
      `requirements/production.txt` on a server. `psycopg` is in `base.txt`,
      so either one has the Postgres driver.

Two connection strings, and they are not interchangeable:

| Use | Host | Port | Why |
| --- | --- | --- | --- |
| **Migrations** | `db.<ref>.supabase.co` | 5432 | The pooler runs in transaction mode and cannot hold the session state some DDL needs |
| **The application** | `…pooler.supabase.com` | 6543 | Postgres allocates a process per connection; the pooler stops a few worker threads exhausting them |

`manage.py db_transfer` prints which one it is looking at, and warns if you point it
at the pooler.

---

## 3. Migrate

```bash
# 1. Build the schema on the new database, using the DIRECT connection.
export DATABASE_URL="postgresql://postgres:PASSWORD@db.YOUR-REF.supabase.co:5432/postgres"
python manage.py migrate

# 2. Lock it down before any data arrives. Supabase SQL editor:
#    paste and run sql/supabase_setup.sql  -- see section 5, this one matters
#    then set DATABASE_URL to use leadmapper_app instead of postgres

# 3. Copy the rows.
export SQLITE_SOURCE=outreach.sqlite3
python manage.py db_transfer --dry-run     # says exactly what it would do
python manage.py db_transfer

# 4. Check it again, whenever you like. Read-only.
python manage.py db_transfer --verify-only
```

What `db_transfer` does that `dumpdata | loaddata` does not:

- **Orders the tables by their dependencies**, and handles the one case ordering
  cannot: `Campaign.current_draft` → `EmailDraft` → `Campaign` is a genuine cycle.
  The nullable side is written as `NULL` and filled in afterwards. This matters
  because Postgres, unlike SQLite, will not let a non-superuser switch foreign keys
  off.
- **Preserves timestamps.** `bulk_create` lets `auto_now_add` overwrite the value,
  so without this every `created_at` in the new database would read as the day of
  the migration and the real history would be gone — silently, with row counts
  matching perfectly.
- **Resets the sequences.** `loaddata` leaves them at 1, so the next `INSERT`
  collides with row 1 and the application looks broken for reasons unrelated to the
  migration.
- **Proves it.** Counts every table on both sides, then re-reads a sample of real
  rows and compares every field. It refuses to report success unless both agree,
  and rolls the whole copy back if they do not.

Everything happens in one transaction, and the SQLite file is only ever read.

---

## 4. Point the application at it

```ini
# .env
DATABASE_URL=postgresql://leadmapper_app:PASSWORD@aws-0-REGION.pooler.supabase.com:6543/postgres
```

Then the ordinary checks:

```bash
python manage.py check
python manage.py db_transfer --verify-only
python manage.py runserver          # sign in, open the dashboard, open a lead
```

Removing `DATABASE_URL` puts you back on SQLite. Nothing else has to change, and
the old file is untouched — which is what makes the rollback trivial.

---

## 5. Security: your tables are exposed by default

This is the part that is easy to miss and expensive to miss.

**Supabase runs a REST API over the `public` schema.** Any table there is reachable
over HTTPS by anyone holding the publishable key — a key designed to be published.
Tables created through the Supabase dashboard get Row Level Security switched on for
you. Tables created by a Django migration do not, because Django knows nothing about
Supabase.

So a plain `manage.py migrate` against a fresh project leaves every campaign, lead,
email body and sent-mail record readable at:

```
https://<ref>.supabase.co/rest/v1/outreach_emaildraft?select=*
```

[sql/supabase_setup.sql](sql/supabase_setup.sql) closes it with two independent
locks, either of which would do on its own:

1. **RLS enabled on every table, with no policies.** PostgREST connects as `anon` or
   `authenticated`; with RLS on and nothing granting them anything, both see zero
   rows. The application is unaffected because it connects as the role that *owns*
   the tables, and an owner is exempt from its own policies.
2. **The grants PostgREST relies on, revoked** from those roles outright — including
   `ALTER DEFAULT PRIVILEGES`, so the next migration's new tables are not exposed
   the moment they are created.

The file ends with a query that shows `owner`, `rls_enabled` and `anon_can_read` per
table. Every row should read `leadmapper_app / true / false`. Run it.

### Why RLS is not doing per-user isolation

Supabase policies key on `auth.uid()`, which comes from a Supabase Auth JWT. This
application authenticates with **Django sessions** and connects to Postgres as one
role, so `auth.uid()` is null on every connection it opens — policies written that
way would block everything or nothing.

Per-user isolation lives where it already is: in every query, with the owner as a
required argument, returning 404 rather than 403 for another account's row, covered
by `apps/outreach/tests/test_authorization.py`. The database-level layer here is a **restricted
role**: `leadmapper_app` is `NOSUPERUSER NOCREATEDB NOCREATEROLE` and can touch only
the application's own tables, so a leaked connection string has a ceiling on the
damage.

### The keys, and where each belongs

| Variable | Read by | Notes |
| --- | --- | --- |
| `SUPABASE_URL` | nothing yet | The project URL |
| `SUPABASE_PUBLISHABLE_KEY` | nothing yet | **Has no consumer.** No client-side code touches Supabase; the browser only ever talks to Django |
| `SUPABASE_SECRET_KEY` | nothing yet | Bypasses RLS. Server-side only, and there is currently no server-side code that needs it either |
| `DATABASE_URL` | Django | The actual connection. Contains the database password — not an API key |

All four live in `.env`, which `.gitignore` excludes. `.env.example` carries the
names and placeholders only.

---

## 6. After the migration

```bash
python manage.py db_transfer --verify-only    # counts + field-by-field samples
python manage.py test                         # 1,058 tests
python manage.py migrate --check              # schema is current
```

Then by hand, because these are the ones a test cannot cover for you:

- [ ] Sign in. Sessions were not migrated, so this is a fresh login.
- [ ] Dashboard, lead table, a lead detail page, history, settings, follow-ups.
- [ ] **Create something** — add a do-not-contact entry. This is the operation that
      fails if the sequences were not reset, so it is worth doing deliberately.
- [ ] Edit and delete it.
- [ ] Open a past campaign's workspace and confirm the drafts are attached.
- [ ] Check a date: the oldest campaign should show its original date, not today's.
- [ ] Download the Excel history. It reads from the database and should be
      unchanged.
- [ ] Add an AI credential in Settings, activate it, delete it. This exercises the
      encrypted column and the partial unique index.
- [ ] Run `sql/supabase_setup.sql`'s final query and confirm `anon_can_read` is
      `false` everywhere.
- [ ] From a terminal, try the REST API with the publishable key and confirm it
      returns nothing:
      `curl "https://<ref>.supabase.co/rest/v1/outreach_emaildraft?select=*" -H "apikey: <publishable>"`

### Excel formulas and business logic

There are none to port. The `.xlsx` is written by `openpyxl` with values only — no
formulas, no macros — and every calculation already lives in Python:
`apps/auditing/scoring.py` for the scores, `apps/outreach/services/history.py`
for the export layout.
Nothing was ever computed in the spreadsheet.

---

## 7. Rolling back

```bash
unset DATABASE_URL        # or remove the line from .env
```

SQLite is untouched. The Supabase project can be deleted or left alone; nothing in
the application refers to it once the variable is gone.

---

## 8. What is left to decide

- **Docker and deployment.** [DEPLOY.md](DEPLOY.md) is written around a single
  SQLite file: one Gunicorn worker, a WAL pragma, a volume to back up. On Postgres
  the WAL step and the backup script become unnecessary, and the one-worker rule
  relaxes — though the campaign worker being a thread inside the web process is
  still what makes "one job per campaign" hold, so leave `--workers 1` alone until
  that changes too.
- **Connection limits.** Supabase's free tier allows a small number of direct
  connections. `CONN_MAX_AGE=600` keeps them open between requests, and the pooler
  is what makes that safe. If you see "too many connections", lower
  `DJANGO_CONN_MAX_AGE` before anything else.
- **Point-in-time recovery** is a paid Supabase feature. Until then, keep taking the
  daily backup DEPLOY.md sets up — `pg_dump` against the direct connection now,
  rather than a file copy.
