# Lead Mapper

An AI lead-generation and outreach tool. It finds local businesses on a public
map, reads their websites, works out what is wrong with them, writes a personal
email about what it actually found, and sends it once you approve it.

- **Django 6.1**, server-rendered templates, vanilla JavaScript. No build step.
- **SQLite** in one file by default; set `DATABASE_URL` to run on Postgres or
  Supabase instead. No Redis, no task queue either way.
- **1,642 tests**, all passing.
- Every AI provider is optional and swappable: Groq, Claude, Gemini, OpenAI,
  OpenRouter.

---

## Contents

1. [What it does](#1-what-it-does)
2. [The workflow, step by step](#2-the-workflow-step-by-step)
2b. [Unattended campaigns](#2b-unattended-campaigns)
2c. [Auditing one website](#2c-auditing-one-website)
3. [Features, point by point](#3-features-point-by-point)
4. [Rules the system will not break](#4-rules-the-system-will-not-break)
5. [Project structure](#5-project-structure)
6. [Setup](#6-setup)
7. [Environment variables](#7-environment-variables)
8. [Commands](#8-commands)
9. [Routes](#9-routes)
10. [Testing](#10-testing)
11. [Troubleshooting](#11-troubleshooting)

Deployment is in **[DEPLOY.md](DEPLOY.md)** — Docker Compose or a manual install
on AWS EC2. Moving the database to Supabase Postgres is in
**[SUPABASE.md](SUPABASE.md)**.

---

## 1. What it does

- Searches **OpenStreetMap** for businesses by country, city and category.
- Shows them on a map and in a table, with whatever contact details are published.
- Crawls each selected lead's website — its own pages only, obeying `robots.txt`.
- **Measures** the site: load time, page weight, mobile viewport, calls to action,
  forms, headings, titles, alt text, HTTPS — and whether the pages answer the
  questions a customer arrives with: what it costs, where they work, how the
  process goes, who they are, why to trust them. **48 signals per page.**
- Asks the AI to turn those measurements into **evidenced findings** across six
  areas — business logic, customer journey, content, trust, search, technical —
  never opinions, never anything it cannot point at.
- Scores every lead on six dimensions and gives it a priority band.
- Writes **one email per lead** built on that lead's strongest findings.
- Lets you edit, regenerate or reject each email before anything is sent.
- Sends the approved ones over your own SMTP account, at the provider's rate limit.
- Reads your inbox afterwards to match **replies and bounces** to what was sent.
- Drafts follow-ups for the ones that never answered — you press Send.
- Keeps the whole history, per account, exportable to Excel.

---

## 2. The workflow, step by step

### Search and select

1. Sign in. Every page requires it; there is no anonymous access.
2. Choose a **country**, a **city** and a **category** (restaurants, dentists,
   garages, and so on).
3. The search runs against OpenStreetMap and returns businesses with their
   address, phone, email and website where published.
4. Review them on the map or in the table. Tick the ones worth contacting.
5. Press **Start campaign**. The selected leads become a campaign.

### Set up the campaign

6. Enter the sender name, sender email and email provider.
7. Enter **what you offer**. Every email connects a website finding to this text,
   and the AI may not describe your service in any terms other than these.
8. Press **Run**. An unconfigured AI provider stops here, before a single website
   is crawled.

### Per lead, one at a time

Each lead completes all five steps before the next lead is touched. Nothing is
batched by stage.

```
Lead 1 → crawl → find issues → write email → score → save
Lead 2 → crawl → find issues → write email → score → save
Lead 3 → …
```

9. **Crawl.** Fetch `robots.txt`, discover the site's own pages from its links and
   sitemap, read the most useful ones, and measure every page.
10. **Find issues.** The AI receives the page text and the measurements and returns
    8–10 findings, each with the specific measurement behind it, what it costs the
    business, a suggested fix and a severity.
11. **Write the email.** The findings are ranked by commercial importance, the
    strongest one to three are sent to the AI as structured evidence, and it writes
    a subject and body naming those specific findings.
12. **Score.** Six sub-scores, a classification, a priority band and a recommended
    service — arithmetic over what was measured, no AI call, no cost.
13. **Save.** The lead is stamped complete. Its card appears in the workspace with
    its findings and its email together.

While this runs, the workspace shows: `Lead 7 of 25`, a percentage bar, the company
and website being read right now, which of the five steps is in flight, what is
next, the whole queue, and one **Cancel** button.

### Review

14. Read each email. The findings the email used are tagged, so you can see at a
    glance whether it is grounded or vague.
15. **Edit** it, **Regenerate** it (optionally with a note like "make it shorter"),
    **Re-review** the website, **Approve** it or **Reject** it.
16. Or **Approve all** once you trust them.

### Send

17. Press **Send**. Enter the SMTP password if it is not in `.env` — it is never
    stored in the database.
18. Emails go out one at a time, pausing between each for the provider's rate
    limit, and stopping at the daily cap.
19. Every send is recorded: to whom, what subject, when, and the `Message-ID` that
    a reply will quote.

### Follow up

20. Press **Check inbox**. Replies and bounces are matched to what was sent, by
    `Message-ID` first, then address, then subject.
21. When the first email goes out, the next follow-up's date is written down.
    Leads that never answered become due after 2 days, then 7 days, up to 2
    follow-ups.
22. Either press **Create follow-up**, or let the background worker prepare it
    when the date arrives. Both write a draft from the original email, every
    follow-up already sent, and any reply that came back.
23. A prepared follow-up sits as **Ready to review**. Read it, edit it, and press
    **Send follow-up**. Nothing sends itself — the worker prepares, a person
    sends.

---

## 2b. Unattended campaigns

The workflow above is a person driving each step. An **automation campaign** is the
same steps with the person replaced by a schedule and two targets — and nothing else
replaced: the same crawler, the same audit, the same evidence rules, the same
duplicate protection, the same do-not-contact list.

### Configure it once

1. **Automation → New automation campaign.**
2. Choose **countries, cities and business categories**. Each combination becomes one
   search of the public map data, run once.
3. Choose a **website filter** — any business, or only ones with a website. There is
   deliberately no “website is bad” filter: that is not knowable before the site has
   been read, and offering it would mean inventing a claim.
4. Set a **daily target** and a **total target**.
5. Set the **dates and the daily window**, and the **timezone the campaign runs in**.
   09:00–17:00 America/Chicago means nine in Chicago, whatever the server thinks the
   time is.
6. Choose the **mailbox** it sends from, and the **email template**.
7. Choose whether **follow-ups** are prepared. Sending one is still a click — that is
   not configurable.
8. Read the **review panel**, then **Create campaign**. Creating is not starting.
9. On the dashboard, press **Start campaign**.

### Then the worker runs it

10. A scheduled job on the server picks the campaign up — **not the browser**. Close
    the tab; nothing changes.
11. It checks the campaign's status, then its window, then its targets, then the
    mailbox, **before every single lead**. Any of them can stop it mid-pass.
12. It tops the prospect pool up with one map search when the pool runs low.
13. Per lead: crawl the site, audit it, score it, write the email, validate it, send
    it, record the result, write a line in the activity log.
14. When today's target is reached it waits for tomorrow's window. When the total
    target is reached, the end date passes, or nothing eligible is left, the campaign
    is **Completed**, with the reason on the dashboard.
15. **Pause** stops it at the next lead. **Resume** carries on from where it stopped
    — never from the beginning.

### What it will not do

- It will not send outside the window, or past either target.
- It will not send the same business twice, or contact anybody on the do-not-contact
  list, or email an address that has bounced.
- It will not send an email whose claims cannot be traced to a verified finding. A
  draft that fails validation is **held for review** rather than sent.
- It will not send a follow-up. It prepares one and waits for a click.
- It will not raise a mailbox's provider limit, or blast without spacing.
- It will not keep going after a mailbox stops working — it pauses the campaign and
  says why.

---

## 2c. Auditing one website

Sometimes you already know whose website you want to look at. This is that: paste one
address, get an audit and a short email, read both, send it yourself. It shares every
piece of machinery with the campaigns above and shares none of their automation —
**nothing here sends without you pressing Send.**

### The flow

1. **Audit a website → paste the URL.** No country, no city, no category, no map. Just
   the address; type the bare domain if you like.
2. The address is checked and tidied: `https://` added, the host lowercased, tracking
   parameters (`utm_*`, `fbclid`, `gclid`, …) removed, the fragment dropped.
3. **A background worker reads the site.** You can close the tab. Up to 8 pages —
   home, about, services, contact, pricing, FAQ, team, testimonials where they exist —
   following the site's own links and its sitemap, never leaving the domain.
4. **The status page shows the real counts**: pages found, pages crawled, which useful
   pages exist and which do not, and what the worker is doing now. All of it is
   written by the crawler as it happens.
5. **The findings come from the pages.** Same evidence rule as everywhere: each one
   cites a measurement or a quote, and anything unverifiable is listed separately and
   never used in the email.
6. **Contact details are read, never guessed** — `mailto:` links, addresses printed on
   the page, lightly obfuscated ones (`hello [at] example.com`), and `schema.org`
   structured data. Each one records the page it came from and how much it is trusted.
7. **The addresses are ranked** — a named owner, then the business's general address,
   then a department, then the rest — and the top one is *suggested*. You can pick a
   different one from the list, or type your own.
8. **A 90–150 word email is drafted** from the strongest one to three findings.
9. **You review everything**: the findings with their evidence, the contact details
   with their sources, and the email. Edit the recipient, the subject and the body as
   much as you like.
10. **Press Send email**, confirm the recipient and subject on the step that follows,
    and it goes out. Only then is the provider called.

### What it will not do

- It will not send anything on its own. There is no automatic send after the AI
  finishes, and the send endpoint refuses a request that does not carry an explicit
  confirmation.
- It will not invent a contact address. No `info@` guess: if the site published
  nothing, it says so and lists the pages it checked, and you can supply an address.
- It will not invent a finding. If nothing evidence-based turns up it says **"No
  strong evidence-based website issues were found in the pages reviewed"** and drafts
  no email.
- It will not produce an audit from a site it could not read. A timeout, a refusal, a
  `robots.txt` disallow, a redirect loop or a server error is reported as that, with
  no findings attached.
- It will not fetch a private address. `localhost`, loopback, private ranges, cloud
  metadata endpoints, internal hostnames and non-web ports are refused — **including
  when a public site redirects to one**, because every redirect hop is checked too.
- It will not email the same business twice, or anybody on the do-not-contact list:
  the send reserves the address in the same history the campaigns use.

---

## 3. Features, point by point

### Accounts

- Sign up, log in, log out. Sessions are cycled on login and flushed on logout.
- Deny-by-default: every view requires a session unless explicitly marked public.
- Every campaign, lead, email, reply, suppression and AI credential belongs to one
  account, enforced in the database query rather than checked afterwards.
- Reaching another account's record by changing a URL returns **404**, not 403 —
  "forbidden" would confirm the record exists.

### Lead search

- 252 countries and ~34,000 cities, offline. No geocoding API.
- Category presets plus free text.
- Results on a map with clustering, and in a sortable table.
- CSV export of any result set.
- `robots.txt` is honoured, requests to one host are spaced a second apart, and the
  crawler identifies itself with a contact address.

### Website analysis

- Discovers the site's own pages from its links and its sitemap; ranks them by
  usefulness (home, services, contact, about) and reads the best few.
- Measures **48 signals per page** — performance, mobile, SEO, content,
  conversion, trust, technical, and ten business questions a visitor asks before
  making contact (pricing, service area, process, team, hours, guarantees, proof,
  credentials, FAQs, who it is for).
- A count of zero is evidence: `pricing_mentions=0` across four pages supports
  "no indication of cost on any page reviewed" — and nothing broader than that.
- A blocked or unreachable site is recorded as **unverified**, never as "no
  website". The two are completely different sales situations.
- A CAPTCHA, a login wall, a `401`, `402`, `403` or `429` stops the crawl for that
  site. Nothing is bypassed.

### The audit

- Covers **six areas**, in the order they matter commercially:

  | | Area | Examples |
  | --- | --- | --- |
  | 1 | Business and logical gaps | no pricing, no service area, no explanation of how it works, no target customer |
  | 2 | Customer journey and conversion | no obvious way to enquire, buried contact page, an eleven-field form |
  | 3 | Content | thin services pages, placeholder text, no FAQs |
  | 4 | Trust and credibility | no testimonials, no certifications, no team |
  | 5 | Search visibility | titles, headings, alt text, local content |
  | 6 | Technical health | speed, mobile rendering, HTTPS, accessibility |

- Every finding carries an **id** (`AUD-001`), and every point in an email traces
  back to one — a claim that resolves to no finding is rejected and the draft is
  rewritten.
- Every finding says the same seven things: **what is wrong**, its **priority**
  (HIGH / MEDIUM / LOW), the **measurement it rests on**, **why it matters** to
  the business, the **recommended fix**, the **potential business benefit**, and
  the **affected page**.
- The lead page groups them by priority — three things costing money now, five
  worth doing, four to tidy up — and shows how many of the six areas the review
  actually reached, so a thin audit is visible rather than implied.
- **Priority is not inflated.** The prompt says so and the grouping makes an
  all-HIGH list obvious at a glance.
- **Benefits are hedged, and it is checked.** "Could help", "may reduce friction
  for", "creates an opportunity to" — a sentence that promises a ranking, a lead
  count or a revenue figure is stripped in code and the finding keeps its
  evidence.
- **What a crawl cannot settle, it says so about.** Whether a form actually
  submits, whether a phone is answered: the reviewer writes "Could not be
  verified from the available crawl", and those are shown apart from confirmed
  findings so both do not look equally certain.
- **The platform is detected, and left alone.** WordPress, Wix, Squarespace,
  Shopify, Webflow, Drupal, Joomla, Next.js and the page builder on top of it,
  plus what is measuring visitors. The default verdict is "this is a reasonable
  choice and nothing measured says otherwise", the email then says nothing about
  technology, and a fix recommending React or a rebuild is withheld from the email
  unless several measured problems support it. "Newer" is not a finding.

### Lead intelligence

- **Classification**: website found · no-website opportunity · website unverified.
- **Six sub-scores**: performance, mobile, SEO, UX & content, conversion,
  security & technical.
- **Opportunity score** and a priority band: hot · warm · low · skip.
- **Recommended service** from nine options, chosen from the measured weaknesses.
- **Email readiness score**, so you can see which leads are worth contacting now.
- **Five smart queues**: hot website leads · no-website opportunities · warm leads
  · unverified websites · skip.
- **Thirteen lifecycle stages** from `new` through `qualified`, `email_ready`,
  `contacted`, `replied`, `interested`, `meeting`, `won` / `lost`.
- A lead detail page with the sub-scores, every finding and its evidence, and a
  "why this is a good prospect" explanation.
- Opening a lead page never crawls anything. Audits are cached per domain and
  refreshed on request or after 30 days.

### The email

- Built on the **actual findings from that lead's crawl** — the pages read, the
  measurements taken, and the one to three findings that matter commercially.
- Findings are prioritised in this order: broken functionality → conversion and
  customer journey → mobile usability → speed → missing content → search
  visibility → technical detail.
- **250–500 words**, structured as a consultative note: what you looked at, two
  or three findings each explained properly, an honest summary, then an offer of
  a 15-minute call. No hard sell — no deadlines, no discounts, no "book now".
- Measurements are context for the AI and are **forbidden in the email**.
  `LCP = 4.8s` becomes "the homepage takes noticeably longer to load on mobile".
- A draft that says "I noticed some issues with your website", or that quotes a
  metric at a business owner, is **detected and regenerated** with the specific
  failure as the note.
- Two audit fields come back with every email: what specifically it refers to, and
  which findings it used.
- Businesses with no website get a different email entirely — about what a site
  would make easier, with no critique of a site nobody has seen.
- Every email closes with an invitation to reply, and carries a
  `List-Unsubscribe` header.

### Duplicate prevention and do-not-contact

- The same address cannot enter one campaign twice.
- An address contacted before is flagged, with when and in which campaign.
- **Contact anyway** exists as a deliberate, recorded override.
- A do-not-contact list of addresses and whole domains, checked before the send is
  reserved — and it cannot be overridden, not even by "contact anyway".
- The final guarantee is a database constraint, so two concurrent send threads
  cannot both send to the same person.

### Sending addresses

- Add as many mailboxes as you like under **Settings → Sending addresses**. Gmail,
  Outlook, Zoho, Fastmail or a custom SMTP host.
- **Only addresses marked Active are ever used.** Switching one off stops future
  sends and keeps every sent record, prepared follow-up and reply.
- Each password is encrypted before it is stored and never shown again — not on the
  page, not in any response, not in the logs. Only a masked hint comes back.
- **Test connection** authenticates against SMTP and opens the mailbox over IMAP
  without sending anything.
- Per-address limits: a daily cap (never above the provider's own), how many
  follow-ups per lead, and the delays between them.
- Each campaign chooses which addresses it may send from, on the setup screen. A
  campaign with no choice uses the sender configured in `.env`.
- Choosing an address is permission, not a promise: active, configured, tested and
  under-limit are all re-checked when the send starts, and the screen says what the
  choice can actually do today.
- **Forget password** clears the credential and keeps the address and its history.
  An address that has sent something cannot be deleted at all — it is switched off
  instead, so the record of who was contacted survives.

### Sending

- Always authenticated. The `From` header is built from the address that logged in,
  so there is no code path that can spoof a sender.
- One message at a time, spaced for the provider, stopping at its daily cap.
- An SMTP password typed into the send dialog is never written to the database — it
  is held only in the sending thread's memory. A saved sending address is the other
  route, and that one is encrypted at rest.
- Which address actually sent each email is recorded on the row, because "who was
  allowed to send" and "who sent it" are different questions.

### Auditing one website

- One URL in, one reviewed email out, with a person in the middle. Separate from the
  campaigns in every way that matters, and built from the same crawler, analyzer, AI
  audit, ranking and sender.
- **URL safety.** Scheme, credentials, port and address range are all checked before a
  request is made, and again on every redirect hop. A site cannot walk the crawler
  into a private network.
- **Real background processing.** The audit is a job row with a state
  (`created → queued → crawling → analyzing → contacts_found → draft_ready →
  ready_for_review → sent`, or `failed`), run by a thread and by
  `manage.py run_audits`. A restart does not lose a queued job, and two workers cannot
  run the same one.
- **Honest progress.** Every count on the status page is written by the crawler as it
  reads. Nothing on that page can advance the audit, so what it reports is what
  happened.
- **Contact extraction with provenance.** Every address, phone number, postal address
  and social profile records the page it came from and how much it is trusted.
- **Ranked recipients, one send.** The addresses are ordered by who is most likely to
  read them, the choice is shown, and exactly one address is ever written to.
- **A proper editor.** Recipient, subject and body are all editable, with Save draft,
  Regenerate draft (from the same findings — the site is not re-read) and Send email.

### Automation

- One configuration — locations, categories, targets, schedule, timezone, mailbox,
  template — and a background worker that works through it.
- **Real backend automation.** The worker is a management command run from cron or as
  a service. There is no JavaScript timer, no browser-driven loop, and no counter that
  moves without work behind it. The dashboard reports the worker's state and cannot
  produce it.
- **Timezone-aware.** Every schedule decision is made in the campaign's own zone with
  aware datetimes. The server's timezone is never assumed.
- **The daily target is enforced by the database.** One row per campaign-day, and the
  slot is claimed with a conditional `UPDATE`, so two workers running at once cannot
  both take the last one.
- **Two workers never process the same lead.** The plan is leased, the lead is claimed
  and the address is reserved — three conditional writes, no shared memory.
- **Idempotent.** A pass repeated after a crash re-sends nothing: the sent record, the
  claim and the day counter are all written before the next lead starts.
- Stops for any of: total target, daily target, end date, daily cutoff, pause, stop,
  no eligible businesses left, a mailbox that cannot send, repeated provider failures.
- **A skipped lead always says why** — no email, already contacted, suppressed, wrong
  city, no website — on the lead and in the activity log.
- **An activity log per campaign**: every lead selected, every crawl, every finding
  count, every email written, sent, skipped or failed, with a timestamp in the
  campaign's zone.
- **Contact addresses are read, never invented.** Where the map data has no email, an
  address published in a `mailto:` link on the business's own pages is used. Nothing
  is constructed from a domain or a person's name.
- Two approved email templates: **consultative** (250–500 words, one to three findings
  explained) and **brief** (90–150 words, the strongest finding and the ask). The
  campaign chooses; every other rule is identical.

### Campaign status

- Every campaign has a status a person controls — **draft, scheduled, active,
  paused, completed, stopped, failed** — separate from the phase, which is what the
  machinery is doing. A campaign can be paused while its last send finishes.
- **Only an ACTIVE campaign sends anything**, by hand or by worker.
- **Pause** stops new sends and stops the worker preparing follow-ups for it, and
  changes nothing else. Everything already sent, scheduled or replied to stays
  exactly where it was, so resuming continues rather than restarts.
- **Stop** is the same promise, meant to be final; it can still be reactivated.
- The controls offered on a row are derived from the same transition table the
  server checks, so no button is shown that would return an error.
- Every change records who decided, when, and an optional note, and the note is
  shown wherever the status is.

### Replies and follow-ups

- Read-only IMAP. Nothing is marked read, and an email that does not match
  something this application sent is dropped without being stored.
- Five statuses per sent lead: sent · replied · bounced · no reply · unsubscribed.
- Follow-up eligibility after configurable delays (2 and 7 days by default), to a
  configurable maximum (2).
- A follow-up is drafted by the AI and sent only by a click. There is no automatic
  send path.
- Six conditions are re-checked immediately before the connection opens.
- A follow-up threads: `In-Reply-To` and `References` are built from the
  `Message-ID`s already recorded, so it arrives in the conversation the first email
  started rather than as a third email from a stranger. Nothing is invented — a
  fabricated id breaks threading rather than fixing it.
- It is sent from the address that sent the original, with that address's signature
  and reply-to. A follow-up from somewhere else is a different conversation as far
  as the recipient's mail client is concerned.

### The follow-up worker

- `python manage.py process_followups` prepares what is due. Run it from cron.
- **It sends nothing.** It checks, drafts, and marks the result *Ready to review* —
  everything that costs money or takes time happens there, and the judgement stays
  with a person. A test asserts there is no code path in it that opens SMTP.
- **Idempotent.** Two workers at once, or one run twice by an overlapping cron,
  cannot produce two drafts or two sends for the same schedule: the claim is a
  conditional `UPDATE`, or an insert racing a unique constraint. The database
  decides, not the timing.
- **One schedule, at most one send.** One row per follow-up number per lead,
  reused rather than stepped over — a skipped or failed attempt is retried at the
  same number.
- It stops for a paused campaign, a lead that replied, bounced or opted out, an
  address that cannot send, and a lead whose last attempt failed three times. Each
  reason is written down once, so "why did nothing happen for this lead" has an
  answer on the screen.
- `--dry-run` reports what it would prepare and writes nothing at all.

### Database

Settings → Database, staff accounts only, because it decides which database
*everybody's* data is in.

> **The page is invisible until an account has `is_staff`.** An account made through
> the sign-up form does not, so on a fresh install nobody can see it. Grant it once:
>
> ```bash
> python manage.py shell -c "from django.contrib.auth import get_user_model as m; >   u = m().objects.get(email__iexact='you@example.com'); u.is_staff = True; >   u.save(update_fields=['is_staff'])"
> ```
>
> `is_staff` is enough — `is_superuser` also unlocks the Django admin and bypasses
> every permission check, which this page does not need. To revoke, set it back to
> `False` the same way.

- Two options: **Local Database** and **Supabase**. The page shows which is active,
  which is selected, and the live connection with no password in it.
- **The local database needs no configuration.** It is one SQLite file in the data
  directory, which Django creates on first use — so the page shows a status and two
  buttons and asks for no host, port, user or password.
- **Supabase has exactly three fields**: project URL, anon/public key, service
  role/secret key. Both keys are encrypted at rest with a key derived from
  `DJANGO_SECRET_KEY`, are never sent back to a browser, and are never logged. After
  saving, only a masked hint is shown. An empty key field on save means "keep the
  stored one", which is why nothing ever needs to read one back.
- **The database connection itself is `DATABASE_URL`.** Django talks to Postgres
  directly; the three keys above are PostgREST API credentials and cannot open a
  Postgres connection. The page says so before you try, and refuses to switch to
  Supabase until `DATABASE_URL` is set — the connection string carries the database
  password, so it stays in the environment rather than in a browser form.
- **Test Connection** checks both halves separately: the Postgres connection, with
  whether the schema is migrated, and the two API keys against the project's REST
  endpoint. Failures are reported as sentences with no key, password or connection
  string in them.
- **Switching moves no data.** Nothing is copied and nothing is deleted; to move data
  between the two use `python manage.py db_transfer`. A switch is validated first, and
  a failed check leaves the current database exactly as it was.
- **A switch takes effect on restart.** `DATABASES` is read once at startup and the
  campaign worker threads hold connections from it, so the choice is recorded and
  applied next time the process starts. The page says so rather than implying
  otherwise.
- Scheduled jobs follow the same selection, because it lives in a file every process
  reads rather than in one process's memory.

### AI credentials

- Providers are parents; the keys you add under them are children. **One is
  active** and every AI feature uses it.
- Add as many keys per provider as you like, name them, and switch which is active
  in one click.
- Resolution order: **active credential → environment variable → a clear error**.
- Keys are encrypted at rest with Fernet, shown only as `sk-proj-••••••••9X2A`, and
  never returned to the browser.
- Per credential: when it was added, when it was last used, how many requests it
  served, how many failed, and the last error category.
- An optional fallback: a spare key you mark may be tried **once** when the active
  one is rate limited. It never changes which key is active, and every use is
  recorded.

### AI rate limits

- A rate limit pauses the **whole run** rather than being retried per lead. A
  provider that refuses one request will refuse the next twenty-four.
- `RUNNING → PAUSED_RATE_LIMIT → RUNNING`.
- The position is saved. Every lead already finished keeps its completion stamp.
- `Retry-After` is respected — from the header or from "try again in 8.5s" in the
  message. With no answer, exponential backoff: 30s, 60s, 120s, 240s, capped at
  15 minutes.
- A **temporary limit** is waited out. An **exhausted quota** is not — waiting
  cannot fix it, so the run stops and offers a link to switch provider or key.
- After five pauses in one run it stays paused and waits for a person.

### Cancelling

- One Cancel button for the job. `RUNNING → CANCEL_REQUESTED → CANCELLED`.
- Checked before every lead **and** before every page fetch, so a running crawl
  stops within one page.
- The lead being written finishes; nothing new starts.
- Completed leads stay completed. Resuming later starts at the first unfinished one.
- Idempotent: pressing it twice changes nothing.
- Cancellation beats an automatic retry. A cancelled run never resumes on its own.

### Resuming

- A server restart mid-campaign leaves the phase saying `crawling` with no thread
  behind it. The workspace detects exactly that and offers **Resume**.
- Resuming skips every finished lead, and within an interrupted lead, the steps it
  already completed. A crawl already paid for is not paid for twice.
- An interrupted **send** is different: the password is not stored, so the queue is
  released back to approved and you press Send again. Anything already delivered
  is in the history and cannot go out twice.

### History and reporting

- Per-campaign report: what was sent, what failed and why.
- A progress card per campaign: leads, first emails, awaiting reply, replies,
  follow-ups ready, sent and skipped, bounced, opted out, failed. Every figure is
  counted from the records on each request rather than kept as a running total, so
  it cannot disagree with the tables underneath it.
- Full sending history per account, with an Excel export split by country.
- Dashboard with live counts, the five queues, and reply statistics.

### Long lists

- Campaigns, leads, follow-ups and the do-not-contact list are paginated
  server-side: 20 per page by default, with 50 and 100 offered.
- The summary above each list states the real total — *Showing 21–40 of 47* — which
  is the part a silent slice could not say. Nothing is quietly truncated.
- Search and filters are part of the URL, so a filtered list can be bookmarked or
  sent on, and page 2 keeps the filter.

---

## 4. Rules the system will not break

- **The AI may never invent a website problem.** Every finding must cite a
  measured signal or a quoted phrase. Unevidenced findings are discarded in code —
  when the audit is parsed, when the email is built, and again before the audit is
  rendered.
- **The AI may never promise a result.** No guaranteed rankings, traffic, leads or
  revenue. Hedged wording is required, and an unhedged benefit is removed rather
  than shown.
- **The AI may never invent a business fact** — revenue, customer numbers,
  traffic, rankings, company size, technology, contact details. Where something is
  not known it says `Unknown` or `Not detected`.
- **The AI may never invent your service.** It describes your offer only in the
  words you supplied.
- **No email sends itself.** Not the first one, and not a follow-up whose waiting
  period has passed. The worker prepares and stops; a person presses Send.
- **Only an active campaign sends.** Pausing stops the send path and the worker,
  and loses nothing. A *completed* campaign sends nothing new either — and may still
  finish the conversations it started, because reaching a target is the machinery
  finishing rather than a person stopping it.
- **Nothing runs in the browser.** Automation is a server-side worker. A page that
  appeared to run a campaign would make “is it still going?” unanswerable.
- **No email password reaches the browser** — not the plaintext, not the
  ciphertext. Passwords are encrypted at rest, and only a masked hint is ever
  returned.
- **No sender address is ever spoofed.**
- **No CAPTCHA, login wall or anti-bot protection is ever bypassed.**
- **No contact address is ever guessed.** Only an address published on the pages that
  were actually read, with the page recorded beside it.
- **The crawler never reaches a private network.** Loopback, private ranges, cloud
  metadata endpoints, internal hostnames and non-web ports are refused, on the
  submitted URL and on every redirect after it.
- **No API key reaches the browser**, a log, a URL, an error message or an audit
  row. Tests scan the rendered pages and every endpoint response to prove it.
- **No provider limit is worked around.** A per-address cap is only ever lowered
  below the provider's own, never raised above it.
- **The inbox is read-only**, and unrelated email is never stored.
- **A do-not-contact entry cannot be overridden.**

---

## 5. Project structure

```
manage.py
config/                     the Django project: settings, root URLs, WSGI/ASGI
  settings/
    base.py                 everything both environments share
    development.py          DEBUG, a throwaway key, permissive hosts
    production.py           refuses to start without a real SECRET_KEY
apps/
  core/                     shared, domain-free
    database.py             which database is in use; Settings -> Database
    secrets.py              Fernet encryption for anything stored at rest
    dburl.py                parsing DATABASE_URL
    paging.py               server-side pagination
    testing.py              the signed-in TestCase every app's tests use
  accounts/                 sign-up, sign-in, sessions
  leads/                    finding businesses: OpenStreetMap search, scraping
  auditing/                 reading a website and measuring it
    crawler.py              fetching pages, robots.txt, deciding what to read
    measurements.py         the signals an audit may cite as evidence
    scoring.py              turning signals into scores
    safeurl.py              the SSRF check in front of every fetch
  ai/                       every model call, and nothing else
    prompts.py              what the model is asked
    client.py               the one place a provider is called
    parsing.py              turning an answer into typed objects
    validation.py           rejecting an answer that invented something
    backends/               Groq, Claude, Gemini, OpenAI, OpenRouter
    credentials.py          encrypted keys, resolution order
  outreach/                 campaigns, email, follow-ups, the screens
    models/                 one module per group of tables
    views/                  thin: parse the request, call a service, render
    selectors.py            the filtered, sorted, paginated reads
    services/               where the decisions are
      pipeline.py           one lead: crawl -> review -> write -> send
      followups.py          what is due, what may be prepared
      websiteaudit.py       the submitted-URL workflow
      automation/           unattended campaigns
    mail/                   accounts, providers, compose, transport, inbox
    tasks.py                the three unattended jobs, as plain functions
    management/commands/    the CLI entry points
templates/                  server-rendered HTML, no build step
static/                     css/, js/, images/
tests/
  integration/              settings and the DATABASE_URL switch
  e2e/                      the one test that reads a real website
```

**The rules it follows.** Each app owns one domain and its own migrations. The
dependency arrow points one way — `core` <- `ai` <- `auditing` <- `outreach` — so
`apps/auditing` does not know what a campaign is and `apps/ai` does not know what a
website is. Views parse a request, call a service and render; they decide nothing.
Reusable decisions live in `services/`, complex reads in `selectors.py`, and background
jobs in `tasks.py`, which calls services rather than containing logic. Tests sit beside
what they test; the two that belong to no single app are in the top-level `tests/`.

There is **no Celery and no Redis**. Background work is a management command on a timer
or, for the supervised `--loop` shapes, a daemon thread in the web process. The jobs are
minutes apart, not milliseconds, and a broker would be a second thing to run and restart
for no benefit at this size. See [Commands](#8-commands) and DEPLOY.md for the cron
lines.

---

## 6. Setup

### With Docker

```bash
cp .env.example .env       # fill in DJANGO_SECRET_KEY and one provider key
cp docker-compose.override.yml.example docker-compose.override.yml
docker compose up --build
docker compose exec web python manage.py createsuperuser
# http://localhost:8000
```

### Without Docker

```bash
python -m venv .venv
.venv\Scripts\activate                # Windows
# source .venv/bin/activate           # macOS / Linux

pip install -r requirements/development.txt
cp .env.example .env                  # then edit it
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Then sign in at `http://127.0.0.1:8000/`.

Only the SDK for the provider you actually use is needed — the backends are
imported lazily.

---

## 7. Environment variables

Everything lives in a git-ignored `.env`. `.env.example` is the committed
template. **Never put a real password or key in a tracked file.**

### Django

| Variable | Required | Notes |
| --- | --- | --- |
| `DJANGO_SECRET_KEY` | In production | Signs sessions **and** derives the encryption key for saved AI credentials. Keep it stable. |
| `DJANGO_DEBUG` | No | `1` for local development |
| `DJANGO_ALLOWED_HOSTS` | In production | Comma-separated |
| `DJANGO_SSL_REDIRECT` | No | `1` behind HTTPS |
| `DJANGO_HSTS_SECONDS` | No | e.g. `31536000` |
| `DJANGO_TRUST_PROXY_TLS` | Behind a proxy | `1` when nginx or Caddy terminates TLS |
| `DJANGO_DATA_DIR` | No | Where the database and exports live. Defaults to the project directory. |
| `DATABASE_URL` | No | `postgresql://…` moves the application onto Postgres or Supabase. Unset keeps SQLite. See [SUPABASE.md](SUPABASE.md). |
| `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, `SUPABASE_SECRET_KEY` | No | Supabase REST API credentials. Nothing reads them yet — the browser never talks to the database. |

### Sending

| Variable | Required | Notes |
| --- | --- | --- |
| `OUTREACH_SENDER_EMAIL` | Yes | The authenticated address |
| `OUTREACH_SENDER_NAME` | Yes | |
| `OUTREACH_SENDER_COMPANY` | No | |
| `OUTREACH_PROVIDER` | Yes | `gmail` · `outlook` · `zoho` · `fastmail` · `custom` |
| `OUTREACH_SMTP_PASSWORD` | No | Leave it out and the browser prompts per run |
| `OUTREACH_SMTP_HOST` / `_PORT` | Only for `custom` | |
| `OUTREACH_BLOCK_SEND` | No | `1` blocks SMTP **and** IMAP. For tests. Never set it in production. |

### Replies and follow-ups

| Variable | Required | Notes |
| --- | --- | --- |
| `OUTREACH_IMAP_HOST` / `_PORT` | No | Defaults from the sending provider |
| `OUTREACH_INBOX_DAYS` | No | How far back to look. Default 45. |
| `OUTREACH_FOLLOWUP_MAX` | No | Default 2 |
| `OUTREACH_FOLLOWUP_DELAYS` | No | Default `2,7` (days) |

### Crawling

Every limit on how much of somebody else's website is read. Raising a delay or
lowering a ceiling is always safe; the defaults are deliberately modest.

| Variable | Required | Notes |
| --- | --- | --- |
| `OUTREACH_CRAWL_TARGET_PAGES` | No | Internal pages to aim for. Default 5. |
| `OUTREACH_CRAWL_MAX_PAGES` | No | Hard ceiling including the home page. Default 8. |
| `OUTREACH_CRAWL_MAX_DEPTH` | No | How deep a path may go. Default 3. |
| `OUTREACH_CRAWL_TIMEOUT` | No | Seconds per request. Default 15. |
| `OUTREACH_CRAWL_MAX_BYTES` | No | Largest response read. Default 2,000,000. |
| `OUTREACH_CRAWL_DELAY` | No | Seconds between requests to one host. Default 1. |
| `OUTREACH_CRAWL_RETRIES` | No | Attempts per page. Default 2. |
| `OUTREACH_CRAWL_MAX_REDIRECTS` | No | Redirect hops followed, each one checked. Default 5. |
| `OUTREACH_CRAWL_ROBOTS_TTL` | No | Seconds a cached `robots.txt` is trusted. Default 3600. |

### AI

| Variable | Required | Notes |
| --- | --- | --- |
| `OUTREACH_AI_PROVIDER` | No | `groq` · `claude` · `gemini` · `openai` · `openrouter`. A choice made in Settings wins. |
| `OUTREACH_AI_MODEL` | No | Per-credential models in Settings win |
| `GROQ_API_KEY`, `ANTHROPIC_API_KEY`, `GEMINI_API_KEY`, `OPENAI_API_KEY`, `OPENROUTER_API_KEY` | No | Used when no credential is active for that provider |
| `OUTREACH_CREDENTIALS_UI` | No | `0` closes the credential write endpoints and takes keys only from `.env` |
| `OUTREACH_AI_CONTEXT_CHARS` | No | Crawl material sent to the reviewer. Default 9000. |
| `OUTREACH_AI_AUDIT_TOKENS` / `_EMAIL_TOKENS` / `_FOLLOWUP_TOKENS` | No | Reply size ceilings |

### Scoring

| Variable | Required | Notes |
| --- | --- | --- |
| `OUTREACH_PRIORITY_HOT` / `_WARM` / `_LOW` | No | Band thresholds. Default 80 / 60 / 40. |
| `OUTREACH_READINESS_MIN` | No | Default 60 |
| `OUTREACH_AUDIT_MAX_AGE_DAYS` | No | Default 30 |
| `OSM_CONTACT_EMAIL` | Yes | Sent in the crawler's User-Agent, as OpenStreetMap's policy asks |

---

## 8. Commands

| Command | What it does |
| --- | --- |
| `python manage.py runserver` | Start the development server |
| `python manage.py migrate` | Apply migrations |
| `python manage.py createsuperuser` | Create an account |
| `python manage.py test` | Run all 1,642 tests. Sends nothing, contacts nothing. |
| `python manage.py ai_status` | Which AI provider and credential are active |
| `python manage.py ai_status --user you@example.com` | Include that account's saved credentials |
| `python manage.py ai_status --live` | Generate one throwaway email to prove it works |
| `python manage.py smtp_check` | Verify SMTP without emailing anybody |
| `python manage.py check_replies --user you@example.com` | Read the inbox once |
| `python manage.py run_audits` | Run queued website audits. Sends nothing. |
| `python manage.py run_audits --loop --interval 30` | The same, continuously, for a supervised service |
| `python manage.py run_audits --job 7` | One audit, by id |
| `python manage.py run_automation` | One automation pass over every campaign that is inside its schedule |
| `python manage.py run_automation --loop --interval 60` | The same, continuously, for a supervised service |
| `python manage.py run_automation --dry-run` | Report what it would do, crawling nothing and sending nothing |
| `python manage.py run_automation --campaign 3 --limit 5` | One campaign, at most five leads |
| `python manage.py process_followups` | Prepare every follow-up that is due. Sends nothing. |
| `python manage.py process_followups --dry-run` | Report what it would prepare, writing nothing |
| `python manage.py process_followups --limit 20` | Cap how many are prepared in one run |
| `python manage.py claim_data you@example.com` | Assign pre-accounts rows to an account |
| `python manage.py db_transfer --dry-run` | Report what a SQLite → Postgres copy would move |
| `python manage.py db_transfer` | Copy the data, reset sequences, verify counts and fields |
| `python manage.py db_transfer --verify-only` | Compare two databases, read-only |
| `python manage.py check --deploy` | Production readiness |

---

## 9. Routes

| Method | Path | Purpose |
| --- | --- | --- |
| GET | `/` | Lead search |
| GET/POST | `/login`, `/signup`, `/logout` | Accounts |
| GET | `/dashboard` | Sales dashboard |
| POST | `/api/search` | Run a search |
| GET | `/api/export/<job_id>` | Download a CSV |
| POST | `/outreach/start` | Turn selected leads into a campaign |
| GET | `/outreach/<id>/setup` | Sender settings and lead table |
| POST | `/outreach/<id>/run` | Start crawl → findings → email |
| GET | `/outreach/<id>/` | Review workspace |
| GET | `/outreach/<id>/state` | Live progress (polled) |
| POST | `/outreach/<id>/cancel` | Stop the job |
| POST | `/outreach/<id>/resume` | Pick up a paused, cancelled or interrupted run |
| POST | `/outreach/draft/<pk>/<action>` | `save` · `regenerate` · `rereview` · `approve` · `reject` · `recontact` · `suppress` |
| POST | `/outreach/<id>/approve-all` | Approve every draft |
| POST | `/outreach/<id>/send` | Start the send |
| GET | `/outreach/<id>/report` | Campaign report |
| GET | `/outreach/leads` | Lead intelligence table |
| GET | `/outreach/lead/<pk>/intel` | Lead detail |
| POST | `/outreach/lead/<pk>/reanalyse` | Refresh the audit |
| POST | `/outreach/lead/<pk>/lifecycle` | Move the lifecycle stage |
| GET | `/outreach/followups` | Replies and follow-up review |
| POST | `/outreach/followups/check-inbox` | Read the inbox |
| POST | `/outreach/lead/<pk>/followup` | Draft a follow-up (sends nothing) |
| POST | `/outreach/followup/<pk>/<action>` | `save` · `regenerate` · `cancel` · `send` |
| GET/POST | `/outreach/suppressions…` | Do-not-contact list |
| GET | `/outreach/audit` | Past website audits |
| GET/POST | `/outreach/audit/new` | Audit one submitted website |
| GET | `/outreach/audit/<pk>` | Status, findings, contacts and the email editor |
| GET | `/outreach/audit/<pk>/state` | Live crawl progress (read-only, polled) |
| POST | `/outreach/audit/<pk>/save` | Save the recipient, subject and body |
| POST | `/outreach/audit/<pk>/regenerate` | Write the email again from the same findings |
| POST | `/outreach/audit/<pk>/send` | Send it — requires `confirm` in the body |
| POST | `/outreach/audit/<pk>/retry` | Crawl the same URL again |
| GET | `/outreach/automation` | Automation campaigns |
| GET/POST | `/outreach/automation/new` | Create an automation campaign |
| GET | `/outreach/automation/<pk>` | One campaign's dashboard |
| GET | `/outreach/automation/<pk>/state` | Live figures and activity (read-only, polled) |
| POST | `/outreach/automation/<pk>/start` | Hand it to the worker |
| POST | `/outreach/<id>/status/<action>` | `activate` · `resume` · `pause` · `stop` · `complete` |
| GET | `/outreach/<id>/dashboard` | The campaign's figures, counted from the tables |
| POST | `/outreach/<id>/accounts` | Which addresses this campaign may send from |
| GET | `/outreach/settings` | Configuration, sending addresses and the AI credential pool |
| GET | `/outreach/settings/database` | Which database is in use (staff only) |
| GET | `/outreach/settings/database/state` | The same figures as JSON |
| POST | `/outreach/settings/database/supabase` | Store the three Supabase fields |
| POST | `/outreach/settings/database/test` | Test the local database or Supabase |
| POST | `/outreach/settings/database/switch` | Record which database to use |
| POST | `/outreach/accounts/save` | Add or edit a sending address (the one request that carries a password) |
| POST | `/outreach/accounts/<pk>/active` · `test` · `forget` · `delete` | Manage one address |
| POST | `/outreach/ai/select` | Choose the provider (sends a name, never a key) |
| POST | `/outreach/ai/credentials/<provider>/add` | Add a credential |
| POST | `/outreach/ai/credentials/<id>/activate` · `deactivate` · `test` · `fallback` · `delete` | Manage one credential |
| GET | `/outreach/ai/credentials/events` | Recent credential history (no keys) |
| POST | `/outreach/rescore` | Re-score every lead from what is already known |
| GET | `/outreach/history`, `/outreach/history.xlsx` | Campaigns list (paginated, filterable) and Excel export |

---

## 10. Testing

```bash
python manage.py test                    # everything, including tests/
python manage.py test apps.auditing      # the crawler and the measurements
python manage.py test apps.ai            # prompts, parsing, backends, credentials
python manage.py test apps.outreach      # campaigns, mail, follow-ups, the screens
python manage.py test tests.integration  # settings and the DATABASE_URL switch
python manage.py test apps.ai.tests.test_audit        # the audit and its rules
python manage.py test apps.ai.tests.test_evidence     # the findings behind each email
python manage.py test apps.outreach.tests.test_runcontrol   # rate-limit pauses
python manage.py test apps.auditing.tests.test_safeurl      # the SSRF refusals
```

Tests live beside what they test, so the path to a test module is the path to its
subject. The exception is the top-level `tests/`: `integration/` reads settings the way
a deployment reads them, and `e2e/` holds the one test that touches a real website —
opt-in, and skipped without `LIVE_WEB_TESTS=1` and a network.

- **1,642 tests**, about two minutes.
- **Nothing leaves the machine.** `OUTREACH_BLOCK_SEND` is forced on under
  `manage.py test`, which blocks SMTP and IMAP, and every AI call and HTTP fetch is
  a double. A test asserts that this is on.
Before calling anything finished:

```bash
ruff check .                                   # lint and import order
ruff check --fix .                             # fix what is fixable
python manage.py check                         # Django system checks
python manage.py check --deploy                # the production settings
python manage.py makemigrations --check --dry-run   # no model drifted from a migration
python manage.py test
```

---

## 11. Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
| "OpenAI is not configured…" | No active credential and no environment key | Add one in Settings → AI credentials |
| Every lead fails with the same AI error | Missing or rejected key | `python manage.py ai_status --user you@…` |
| The run says "Paused — AI rate limit" | The provider refused; the run kept its place | Wait for the countdown, or press **Resume now** |
| Paused with "quota exhausted" | A daily or billing allowance is spent | Switch provider or credential, then resume |
| Gmail rejects the password | An account password was used | Use an **App Password** |
| A campaign says it is crawling but nothing happens | The server restarted mid-run | Press **Resume** |
| Emails look generic | The site could not be crawled, so there were no findings | The card says so; the email makes no claim about the site |
| A saved AI key reads "cannot be decrypted" | `DJANGO_SECRET_KEY` changed | Add the key again, and keep the secret key stable |
| Nothing sends and there is no error | `OUTREACH_BLOCK_SEND` is set | Remove it |
| `database is locked` | WAL not enabled on a busy install | `sqlite3 outreach.sqlite3 "PRAGMA journal_mode=WAL;"` |
| Old campaigns are invisible after adding accounts | They belong to nobody | `python manage.py claim_data you@example.com` |

---

## Licence and attribution

- Business data from **OpenStreetMap**, © OpenStreetMap contributors, ODbL.
- Nominatim's usage policy is respected: one request per second per host, and a
  contact address in the User-Agent.
- Use it only for outreach you are entitled to send, under the marketing and
  privacy law that applies to you.
