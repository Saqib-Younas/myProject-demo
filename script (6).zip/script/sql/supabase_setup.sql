-- Supabase setup for Lead Mapper.
--
-- Run this in the Supabase SQL editor AFTER `python manage.py migrate` has created
-- the tables, and BEFORE you point the application at them.
--
-- Django owns the schema: every table, index and constraint comes from the 14
-- migrations in outreach/migrations/, and this file deliberately creates none of
-- them. What it does is the part Django cannot do -- roles, grants, and shutting
-- the REST API off the application's data.
--
--
-- ============================================================================
-- READ THIS FIRST: your tables are exposed by default
-- ============================================================================
--
-- Supabase runs PostgREST over the `public` schema. Any table in `public` is
-- reachable over HTTPS by anyone holding the publishable key, which is a key
-- designed to be published. Tables created through the Supabase dashboard get Row
-- Level Security switched on for you; tables created by a Django migration do NOT
-- -- Django knows nothing about Supabase.
--
-- So a Django migration against a fresh Supabase project leaves every campaign,
-- every scraped lead, every email body and every sent-mail record readable at
--
--     https://<ref>.supabase.co/rest/v1/outreach_emaildraft?select=*
--
-- to anybody who has seen the publishable key. That is the single most important
-- thing this file fixes, and it is why it is not optional.
--
-- Two independent locks, because either one alone can be undone by accident:
--
--   1. RLS is enabled on every table with no policies at all. PostgREST connects
--      as `anon` or `authenticated`; with RLS on and nothing granting them access,
--      both see zero rows -- deny by default.
--   2. The grants PostgREST relies on are revoked from those roles outright.
--
-- The application is unaffected by both, because it connects as the role that
-- OWNS the tables, and a table's owner is not subject to its own RLS policies.
--
--
-- ============================================================================
-- 1. The application's database role
-- ============================================================================
--
-- Django connects as this role, not as `postgres`. It can read and write the
-- application's data and nothing else: no superuser, no other databases, no
-- ability to create roles. If the connection string leaks, that is the ceiling on
-- the damage.
--
-- Replace the password. Generate one with:
--     python -c "import secrets; print(secrets.token_urlsafe(32))"

do $$
begin
  if not exists (select 1 from pg_roles where rolname = 'leadmapper_app') then
    create role leadmapper_app with login password 'REPLACE_WITH_A_LONG_RANDOM_PASSWORD'
      nosuperuser nocreatedb nocreaterole noinherit;
  end if;
end
$$;

grant connect on database postgres to leadmapper_app;
grant usage on schema public to leadmapper_app;


-- ============================================================================
-- 2. Hand Django's tables to that role
-- ============================================================================
--
-- Ownership rather than grants, for one specific reason: a table's owner is exempt
-- from its own RLS policies. That is what lets step 3 lock everyone else out
-- without locking the application out too.
--
-- Only tables Django created. Anything Supabase manages itself (auth.*, storage.*,
-- realtime.*) is in another schema and is not touched.

do $$
declare
  target record;
begin
  for target in
    select tablename from pg_tables
    where schemaname = 'public'
      and (tablename like 'outreach\_%' escape '\'
        or tablename like 'auth\_%' escape '\'
        or tablename like 'django\_%' escape '\')
  loop
    execute format('alter table public.%I owner to leadmapper_app', target.tablename);
  end loop;

  for target in
    select sequencename from pg_sequences
    where schemaname = 'public'
      and (sequencename like 'outreach\_%' escape '\'
        or sequencename like 'auth\_%' escape '\'
        or sequencename like 'django\_%' escape '\')
  loop
    execute format('alter sequence public.%I owner to leadmapper_app',
                   target.sequencename);
  end loop;
end
$$;


-- ============================================================================
-- 3. Deny by default, then revoke as well
-- ============================================================================
--
-- Enabling RLS with no policies is the deny-all case: every role except the owner
-- sees nothing. The application, as owner, is unaffected.
--
-- Per-user isolation is NOT done here. It lives in the application, where every
-- query carries the owner as a required argument, 404s rather than 403s on someone
-- else's row, and is covered by its own authorization test suite. Adding policies
-- keyed on `auth.uid()` would achieve nothing: this application authenticates with
-- Django sessions, not Supabase Auth, so `auth.uid()` is null on every connection
-- it opens.

do $$
declare
  target record;
begin
  for target in
    select tablename from pg_tables
    where schemaname = 'public'
      and (tablename like 'outreach\_%' escape '\'
        or tablename like 'auth\_%' escape '\'
        or tablename like 'django\_%' escape '\')
  loop
    execute format('alter table public.%I enable row level security',
                   target.tablename);
    -- Belt and braces: revoke the access PostgREST depends on, so the data stays
    -- unreachable even if RLS is switched off later by mistake.
    execute format('revoke all on public.%I from anon, authenticated',
                   target.tablename);
  end loop;
end
$$;

-- And stop the next migration's new tables from being exposed the moment they are
-- created. Default privileges apply to future objects only, which is exactly the
-- gap this closes.
alter default privileges in schema public revoke all on tables from anon, authenticated;
alter default privileges in schema public revoke all on sequences from anon, authenticated;


-- ============================================================================
-- 4. Check it worked
-- ============================================================================
--
-- Every row should read: owner leadmapper_app, rls_enabled true, anon_can_read
-- false. Anything else means a step above did not apply, and the data is still
-- reachable over HTTPS.

select
  c.relname                                    as table_name,
  pg_get_userbyid(c.relowner)                  as owner,
  c.relrowsecurity                             as rls_enabled,
  has_table_privilege('anon', c.oid, 'SELECT') as anon_can_read,
  has_table_privilege('authenticated', c.oid, 'SELECT') as auth_can_read
from pg_class c
join pg_namespace n on n.oid = c.relnamespace
where n.nspname = 'public'
  and c.relkind = 'r'
  and (c.relname like 'outreach\_%' escape '\'
    or c.relname like 'auth\_%' escape '\'
    or c.relname like 'django\_%' escape '\')
order by c.relname;


-- ============================================================================
-- 5. What to do with this afterwards
-- ============================================================================
--
-- Connection strings, and which to use where:
--
--   migrations   the DIRECT connection, port 5432 (db.<ref>.supabase.co). The
--                pooler runs in transaction mode and cannot hold the session state
--                some DDL needs.
--   application  the POOLED connection, port 6543 (...pooler.supabase.com).
--                Postgres allocates a process per connection; the pooler is what
--                stops a handful of worker threads exhausting them.
--
-- Both with `leadmapper_app` and the password from step 1, not with `postgres`:
--
--   DATABASE_URL=postgresql://leadmapper_app:PASSWORD@aws-0-REGION.pooler.supabase.com:6543/postgres
--
-- One thing to know about future migrations: `leadmapper_app` cannot create tables.
-- Run `manage.py migrate` with the `postgres` connection string, then re-run
-- sections 2 and 3 of this file so the new tables end up owned and locked like the
-- rest. Running them again is harmless -- every statement here is idempotent.
