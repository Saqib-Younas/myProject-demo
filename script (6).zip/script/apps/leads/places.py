"""
Worldwide country and city data for the search form.

Sourced from `geonamescache`, an offline packaging of the GeoNames database:
252 countries and ~34,000 cities, no network call and no API key. Countries and
cities come from the same dataset on purpose -- deriving the country list
separately would let the two drift, and a country whose code does not appear in
the city data is a country whose city dropdown silently comes back empty.

One important limit, and the reason the city field is not a closed dropdown:
the dataset is GeoNames' `cities15000` extract, so it holds places with a
population of roughly 15,000 or more. That is comprehensive for cities but omits
smaller towns -- Nauru has one entry, the Cayman Islands two. Nominatim, which
actually does the geocoding, resolves those small places perfectly well. So the
city field suggests from this dataset but still accepts free text, and validation
rejects only a *contradiction* (a city this dataset places in another country)
rather than mere absence. Turning absence into an error would make the app worse
at its job.
"""

from __future__ import annotations

from functools import lru_cache

import geonamescache

#: Everyday or ISO names people type, mapped to the name THIS DATASET uses.
#:
#: The right-hand side must match geonamescache exactly, which is not always the
#: ISO short name -- it calls NL "The Netherlands", CI "Ivory Coast", TR "Turkey"
#: and TL "Timor Leste". Writing the ISO name there instead makes the alias
#: silently do nothing, which is a bug you only notice when a dropdown comes back
#: empty, so `check_aliases()` asserts every target resolves and a test calls it.
ALIASES: tuple[tuple[str, str], ...] = (
    # Abbreviations and everyday forms.
    ("UAE", "United Arab Emirates"),
    ("UK", "United Kingdom"),
    ("Great Britain", "United Kingdom"),
    ("England", "United Kingdom"),
    ("Scotland", "United Kingdom"),
    ("Wales", "United Kingdom"),
    ("Northern Ireland", "United Kingdom"),
    ("USA", "United States"),
    ("US", "United States"),
    ("Holland", "The Netherlands"),
    ("DR Congo", "Democratic Republic of the Congo"),
    ("Burma", "Myanmar"),
    # ISO / official names that differ from the dataset's wording.
    ("Netherlands", "The Netherlands"),
    ("Côte d'Ivoire", "Ivory Coast"),
    ("Cote d'Ivoire", "Ivory Coast"),
    ("Türkiye", "Turkey"),
    ("Turkiye", "Turkey"),
    ("Czech Republic", "Czechia"),
    ("Vatican City", "Vatican"),
    ("Holy See", "Vatican"),
    ("East Timor", "Timor Leste"),
    ("Timor-Leste", "Timor Leste"),
    ("Swaziland", "Eswatini"),
    ("Cape Verde", "Cabo Verde"),
    ("Macedonia", "North Macedonia"),
    ("Korea (South)", "South Korea"),
    ("Korea (North)", "North Korea"),
    ("Republic of Korea", "South Korea"),
    ("Russian Federation", "Russia"),
    ("Congo (Democratic Republic of the)", "Democratic Republic of the Congo"),
)


@lru_cache(maxsize=1)
def _cache() -> geonamescache.GeonamesCache:
    """One parsed copy of the dataset per process.

    Parsing costs a moment and tens of megabytes; doing it per request would be
    absurd for data that never changes between deploys.
    """
    return geonamescache.GeonamesCache()


# --------------------------------------------------------------------------- #
# Countries
# --------------------------------------------------------------------------- #

@lru_cache(maxsize=1)
def countries() -> tuple[tuple[str, str], ...]:
    """(alpha-2, name) for every country, sorted by name."""
    rows = [
        (code, str(row.get("name") or "").strip())
        for code, row in _cache().get_countries().items()
    ]
    # Sorted by NAME, not code -- this is what the dropdown renders, and the
    # default tuple sort would order by code and look random to a reader.
    return tuple(sorted(((c, n) for c, n in rows if n),
                        key=lambda row: row[1]))


@lru_cache(maxsize=1)
def _code_by_name() -> dict[str, str]:
    """Lower-cased name (and alias) -> alpha-2."""
    index = {name.casefold(): code for code, name in countries()}
    for alias, canonical in ALIASES:
        code = index.get(canonical.casefold())
        if code:
            index.setdefault(alias.casefold(), code)
    return index


@lru_cache(maxsize=1)
def country_choices() -> tuple[str, ...]:
    """Names for the dropdown: canonical list first, then the aliases."""
    known = {name for _code, name in countries()}
    extra = tuple(a for a, _c in ALIASES if a not in known)
    return tuple(name for _code, name in countries()) + extra


def code_for(name: str) -> str:
    """Alpha-2 for a typed country name or alias, or "" if unrecognised.

    Also accepts a raw alpha-2 code, so a caller can pass either.
    """
    text = (name or "").strip()
    if not text:
        return ""
    if len(text) == 2 and text.upper() in {c for c, _n in countries()}:
        return text.upper()
    return _code_by_name().get(text.casefold(), "")


def check_aliases() -> list[str]:
    """Alias targets that do not exist in the dataset.

    An empty list is the healthy state. This exists because a mistyped target is
    invisible at runtime -- the alias just never matches -- so a test asserts on
    it instead.
    """
    known = {name.casefold() for _code, name in countries()}
    return [f"{alias} -> {target}" for alias, target in ALIASES
            if target.casefold() not in known]


def country_name(code: str) -> str:
    """The dataset's name for an alpha-2 code, or ""."""
    wanted = (code or "").strip().upper()
    for c, name in countries():
        if c == wanted:
            return name
    return ""


# --------------------------------------------------------------------------- #
# Cities
# --------------------------------------------------------------------------- #

@lru_cache(maxsize=1)
def _cities_by_country() -> dict[str, tuple[dict, ...]]:
    """alpha-2 -> city records, largest population first.

    Population order matters for the dropdown: with an empty search box the
    user sees the cities they are most likely to want, rather than whatever
    happens to sort first alphabetically.
    """
    grouped: dict[str, list[dict]] = {}
    for row in _cache().get_cities().values():
        code = str(row.get("countrycode") or "").upper()
        name = str(row.get("name") or "").strip()
        if not code or not name:
            continue
        grouped.setdefault(code, []).append({
            "name": name,
            "population": int(row.get("population") or 0),
            "admin1": str(row.get("admin1code") or ""),
            "latitude": row.get("latitude"),
            "longitude": row.get("longitude"),
        })

    return {
        code: tuple(sorted(rows, key=lambda r: (-r["population"], r["name"])))
        for code, rows in grouped.items()
    }


def cities_for(country: str) -> tuple[dict, ...]:
    """City records for a country name, alias or alpha-2 code."""
    code = code_for(country)
    if not code:
        return ()
    return _cities_by_country().get(code, ())


def city_names_for(country: str) -> tuple[str, ...]:
    """Just the names, de-duplicated, still population-ordered."""
    seen: dict[str, None] = {}
    for row in cities_for(country):
        seen.setdefault(row["name"], None)
    return tuple(seen)


@lru_cache(maxsize=1)
def _countries_by_city() -> dict[str, frozenset[str]]:
    """Lower-cased city name -> the country codes that have such a city.

    A set, not a single code: "Paris" exists in France and in Texas, and
    validation has to know that a name can be legitimately shared.
    """
    index: dict[str, set[str]] = {}
    for code, rows in _cities_by_country().items():
        for row in rows:
            index.setdefault(row["name"].casefold(), set()).add(code)
    return {name: frozenset(codes) for name, codes in index.items()}


def countries_with_city(city: str) -> frozenset[str]:
    """Which countries the dataset says have a city of this name."""
    return _countries_by_city().get((city or "").strip().casefold(), frozenset())


# --------------------------------------------------------------------------- #
# Validation
# --------------------------------------------------------------------------- #

def validate(country: str, city: str) -> tuple[bool, str]:
    """Is this country/city pair coherent?

    Returns (ok, message). The rule is deliberately asymmetric:

      * a city the dataset places ONLY in other countries is an error -- that is
        the mistake worth catching, e.g. city "Paris" with country "Germany";
      * a city the dataset does not know at all is accepted, because the dataset
        stops at ~15,000 population and the geocoder does not. Rejecting it would
        block every small town.
    """
    country = (country or "").strip()
    city = (city or "").strip()

    if not city:
        return False, "Enter a city or location."
    if not country:
        return True, ""          # country is optional; the geocoder copes

    code = code_for(country)
    if not code:
        return True, ""          # unrecognised country: let the geocoder judge

    holders = countries_with_city(city)
    if not holders or code in holders:
        return True, ""

    names = sorted(filter(None, (country_name(c) for c in holders)))[:3]
    where = ", ".join(names) if names else "another country"
    return False, (
        f"{city} is not in {country_name(code) or country} — the reference data "
        f"places it in {where}. Pick a city from the list, or clear the country "
        "field to search by name alone."
    )
