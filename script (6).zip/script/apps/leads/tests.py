"""
Tests for the scraper and the three views.

The offline tests cover query building, tag normalisation, CSV shape and the
HTTP layer. The live tests at the bottom actually call Nominatim and Overpass;
they only run when LIVE_OSM_TESTS=1 so an offline test run stays green.

    python manage.py test                          # offline only
    LIVE_OSM_TESTS=1 python manage.py test         # include the live calls
"""

from __future__ import annotations

import csv
import io
import os
import tempfile
import unittest
from unittest import mock

from django.test import SimpleTestCase, TestCase, override_settings
from django.urls import reverse

from apps.core.testing import SignedIn  # noqa: F401

from . import scraper
from .scraper import Area, Lead

LIVE = os.environ.get("LIVE_OSM_TESTS") == "1"

BERLIN = Area(
    city="Berlin",
    country="Germany",
    label="Berlin, Germany",
    lat=52.52,
    lon=13.405,
    bbox=(52.3, 13.0, 52.7, 13.8),
)


def make_lead(**overrides) -> Lead:
    values = dict(
        business_name="Café Central",
        category="Cafe",
        country="Germany",
        city="Berlin",
        address="12 Hauptstraße, Berlin, 10827",
        phone="+49 30 123456",
        email="hello@central.example",
        website="https://central.example",
        latitude=52.5,
        longitude=13.4,
        source="https://www.openstreetmap.org/node/1",
    )
    values.update(overrides)
    return Lead(**values)


class BuildQueryTests(SimpleTestCase):
    def test_query_contains_bbox_filters_and_limit(self):
        query = scraper.build_query(['["amenity"="cafe"]'], (1.0, 2.0, 3.0, 4.0), 25)

        self.assertIn("[out:json]", query)
        self.assertIn('nwr["amenity"="cafe"](1.000000,2.000000,3.000000,4.000000);', query)
        self.assertIn("out tags center 25;", query)

    def test_every_filter_becomes_its_own_clause(self):
        query = scraper.build_query(['["office"]', '["craft"]'], BERLIN.bbox, 10)

        self.assertEqual(query.count("nwr"), 2)

    def test_known_categories_all_produce_parseable_clauses(self):
        for label, filters in scraper.CATEGORIES.items():
            with self.subTest(category=label):
                query = scraper.build_query(filters, BERLIN.bbox, 5)
                self.assertEqual(query.count("nwr"), len(filters))
                self.assertTrue(query.rstrip().endswith(";"))


class CustomFilterTests(SimpleTestCase):
    def test_free_text_matches_tags_and_names(self):
        filters = scraper._custom_filters("Bicycle Repair")

        self.assertIn('["shop"="bicycle_repair"]', filters)
        self.assertIn('["amenity"="bicycle_repair"]', filters)
        self.assertTrue(any(f.startswith('["name"~') for f in filters))

    def test_regex_characters_in_the_name_are_escaped(self):
        filters = scraper._custom_filters("Joe's (Cafe)")
        name_filter = next(f for f in filters if f.startswith('["name"~'))

        self.assertIn(r"\(", name_filter)

    def test_blank_category_is_rejected(self):
        with self.assertRaises(scraper.ScrapeError):
            scraper._custom_filters("   ")


class ToLeadTests(SimpleTestCase):
    def test_node_tags_map_onto_lead_fields(self):
        element = {
            "type": "node",
            "id": 42,
            "lat": 52.5001,
            "lon": 13.4002,
            "tags": {
                "name": "Bäckerei Schmidt",
                "shop": "bakery",
                "addr:housenumber": "7",
                "addr:street": "Hauptstraße",
                "addr:postcode": "10827",
                "phone": "+49 30 555",
                "email": "info@schmidt.example",
                "website": "schmidt.example",
            },
        }

        lead = scraper.to_lead(element, BERLIN)

        self.assertEqual(lead.business_name, "Bäckerei Schmidt")
        self.assertEqual(lead.category, "Bakery")
        self.assertEqual(lead.address, "7 Hauptstraße, Berlin, 10827")
        self.assertEqual(lead.phone, "+49 30 555")
        self.assertEqual(lead.email, "info@schmidt.example")
        self.assertEqual(lead.website, "https://schmidt.example")
        self.assertEqual(lead.latitude, 52.5001)
        self.assertEqual(lead.source, "https://www.openstreetmap.org/node/42")

    def test_way_uses_its_computed_centre(self):
        element = {
            "type": "way",
            "id": 9,
            "center": {"lat": 52.6, "lon": 13.3},
            "tags": {"name": "Hotel Adler", "tourism": "hotel"},
        }

        lead = scraper.to_lead(element, BERLIN)

        self.assertEqual((lead.latitude, lead.longitude), (52.6, 13.3))
        self.assertEqual(lead.category, "Hotel")
        self.assertEqual(lead.source, "https://www.openstreetmap.org/way/9")

    def test_contact_prefixed_tags_are_picked_up(self):
        element = {
            "type": "node", "id": 1, "lat": 52.5, "lon": 13.4,
            "tags": {
                "name": "Praxis Wolf",
                "amenity": "dentist",
                "contact:phone": "+49 30 777",
                "contact:email": "praxis@wolf.example",
                "contact:website": "https://wolf.example",
            },
        }

        lead = scraper.to_lead(element, BERLIN)

        self.assertEqual(lead.phone, "+49 30 777")
        self.assertEqual(lead.email, "praxis@wolf.example")
        self.assertEqual(lead.website, "https://wolf.example")

    def test_unnamed_feature_is_not_a_lead(self):
        element = {"type": "node", "id": 2, "lat": 52.5, "lon": 13.4,
                   "tags": {"amenity": "cafe"}}

        self.assertIsNone(scraper.to_lead(element, BERLIN))

    def test_feature_without_coordinates_is_dropped(self):
        element = {"type": "relation", "id": 3, "tags": {"name": "Chain HQ",
                                                        "office": "company"}}

        self.assertIsNone(scraper.to_lead(element, BERLIN))

    def test_area_supplies_city_and_country_when_untagged(self):
        element = {"type": "node", "id": 4, "lat": 52.5, "lon": 13.4,
                   "tags": {"name": "Kiosk", "shop": "convenience"}}

        lead = scraper.to_lead(element, BERLIN)

        self.assertEqual(lead.city, "Berlin")
        self.assertEqual(lead.country, "Germany")

    def test_generic_yes_values_do_not_become_the_category(self):
        element = {"type": "node", "id": 5, "lat": 52.5, "lon": 13.4,
                   "tags": {"name": "Some Firm", "office": "yes"}}

        self.assertEqual(scraper.to_lead(element, BERLIN).category, "Business")

    def test_completeness_counts_usable_contact_details(self):
        self.assertEqual(make_lead().completeness, 4)
        self.assertEqual(
            make_lead(phone="", email="", website="", address="").completeness, 0
        )


class CsvTests(SimpleTestCase):
    def test_header_row_matches_the_requested_columns(self):
        rows = list(csv.reader(io.StringIO(scraper.csv_text([]))))

        self.assertEqual(rows[0], [
            "Business Name", "Category", "Country", "City", "Address",
            "Phone", "Email", "Website", "Latitude", "Longitude", "Source",
        ])

    def test_values_line_up_under_their_headers(self):
        rows = list(csv.reader(io.StringIO(scraper.csv_text([make_lead()]))))
        record = dict(zip(rows[0], rows[1]))

        self.assertEqual(record["Business Name"], "Café Central")
        self.assertEqual(record["Category"], "Cafe")
        self.assertEqual(record["City"], "Berlin")
        self.assertEqual(record["Email"], "hello@central.example")
        self.assertEqual(record["Latitude"], "52.5")
        self.assertEqual(record["Source"], "https://www.openstreetmap.org/node/1")

    def test_one_row_per_lead(self):
        text = scraper.csv_text([make_lead(), make_lead(business_name="Second")])

        self.assertEqual(len(list(csv.reader(io.StringIO(text)))), 3)

    def test_commas_in_addresses_stay_in_one_field(self):
        rows = list(csv.reader(io.StringIO(scraper.csv_text([make_lead()]))))

        self.assertEqual(len(rows[1]), len(scraper.CSV_HEADERS))
        self.assertEqual(rows[1][4], "12 Hauptstraße, Berlin, 10827")


class ContactGuardTests(SimpleTestCase):
    def test_placeholder_contact_is_refused_before_any_request(self):
        with mock.patch.object(scraper, "CONTACT", "you@example.com"):
            with self.assertRaises(scraper.ScrapeError) as caught:
                scraper.geocode("Berlin", "Germany")

        self.assertIn("OSM_CONTACT_EMAIL", str(caught.exception))

    def test_real_contact_passes_the_guard(self):
        with mock.patch.object(scraper, "CONTACT", "dev@realdomain.test"):
            scraper._check_contact()  # must not raise


class SearchPipelineTests(SimpleTestCase):
    """search() dedupes, ranks and truncates -- with the network stubbed out."""

    def _run(self, elements, limit=10):
        with mock.patch.object(scraper, "geocode", return_value=BERLIN), \
             mock.patch.object(scraper, "run_overpass", return_value=elements):
            return scraper.search("Germany", "Berlin", "Cafes", limit)

    def test_same_business_mapped_twice_appears_once(self):
        node = {"type": "node", "id": 1, "lat": 52.50001, "lon": 13.40001,
                "tags": {"name": "Café Central", "amenity": "cafe"}}
        way = {"type": "way", "id": 2, "center": {"lat": 52.50002, "lon": 13.40002},
               "tags": {"name": "Café Central", "amenity": "cafe"}}

        _, leads = self._run([node, way])

        self.assertEqual(len(leads), 1)

    def test_leads_with_contact_details_rank_first(self):
        bare = {"type": "node", "id": 1, "lat": 52.5, "lon": 13.4,
                "tags": {"name": "Bare Cafe", "amenity": "cafe"}}
        rich = {"type": "node", "id": 2, "lat": 52.6, "lon": 13.5,
                "tags": {"name": "Zebra Cafe", "amenity": "cafe",
                         "phone": "+49 1", "website": "https://z.example"}}

        _, leads = self._run([bare, rich])

        self.assertEqual([l.business_name for l in leads], ["Zebra Cafe", "Bare Cafe"])

    def test_result_count_respects_the_requested_limit(self):
        elements = [
            {"type": "node", "id": i, "lat": 52.5 + i / 1000, "lon": 13.4,
             "tags": {"name": f"Cafe {i}", "amenity": "cafe"}}
            for i in range(20)
        ]

        _, leads = self._run(elements, limit=5)

        self.assertEqual(len(leads), 5)

    def test_requested_limit_is_capped(self):
        with mock.patch.object(scraper, "geocode", return_value=BERLIN), \
             mock.patch.object(scraper, "run_overpass", return_value=[]) as overpass:
            scraper.search("Germany", "Berlin", "Cafes", 10_000)

        query = overpass.call_args[0][0]
        self.assertIn(f"out tags center {scraper.MAX_LEADS * 4};", query)


@override_settings(ALLOWED_HOSTS=["*"])
class ViewTests(SignedIn):
    """Needs a database: /api/search now checks the sending history, so an
    already-contacted business can be flagged before the user selects it."""

    def test_index_renders_the_form_and_the_map(self):
        response = self.client.get(reverse("leads:index"))

        self.assertEqual(response.status_code, 200)
        body = response.content.decode()
        for field in ("id=\"country\"", "id=\"city\"", "id=\"category\"",
                      "id=\"limit\"", "id=\"map\""):
            self.assertIn(field, body)

    def test_index_offers_every_category(self):
        response = self.client.get(reverse("leads:index"))
        body = response.content.decode()

        for label in scraper.CATEGORIES:
            self.assertIn(label.replace("&", "&amp;"), body)

    def _post(self, **payload):
        body = {"country": "Germany", "city": "Berlin", "category": "Cafes",
                "limit": 5}
        body.update(payload)
        return self.client.post(
            reverse("leads:search"), data=body, content_type="application/json"
        )

    def test_search_returns_leads_and_a_download_url(self):
        with tempfile.TemporaryDirectory() as tmp:
            with override_settings(EXPORT_DIR=__import__("pathlib").Path(tmp)):
                with mock.patch.object(
                    scraper, "search", return_value=(BERLIN, [make_lead()])
                ):
                    response = self._post()

                self.assertEqual(response.status_code, 200)
                data = response.json()
                self.assertEqual(data["count"], 1)
                self.assertEqual(data["leads"][0]["business_name"], "Café Central")
                self.assertEqual(data["area"]["city"], "Berlin")
                self.assertTrue(data["download_url"].startswith("/api/export/"))
                self.assertTrue(data["csv_filename"].endswith(".csv"))

    def test_search_writes_the_csv_as_soon_as_it_finishes(self):
        import pathlib

        with tempfile.TemporaryDirectory() as tmp:
            export_dir = pathlib.Path(tmp)
            with override_settings(EXPORT_DIR=export_dir):
                with mock.patch.object(
                    scraper, "search", return_value=(BERLIN, [make_lead()])
                ):
                    response = self._post()

                written = list(export_dir.glob("*.csv"))
                self.assertEqual(len(written), 1)
                self.assertEqual(written[0].name, response.json()["csv_filename"])
                self.assertIn("Café Central", written[0].read_text(encoding="utf-8-sig"))

    def test_download_serves_the_csv_as_an_attachment(self):
        import pathlib

        with tempfile.TemporaryDirectory() as tmp:
            with override_settings(EXPORT_DIR=pathlib.Path(tmp)):
                with mock.patch.object(
                    scraper, "search", return_value=(BERLIN, [make_lead()])
                ):
                    job = self._post().json()

                response = self.client.get(job["download_url"])

                self.assertEqual(response.status_code, 200)
                self.assertEqual(response["Content-Type"], "text/csv")
                self.assertIn("attachment", response["Content-Disposition"])
                self.assertIn(job["csv_filename"], response["Content-Disposition"])

                text = b"".join(response.streaming_content).decode("utf-8-sig")
                self.assertIn("Business Name,Category,Country", text)
                self.assertIn("Café Central", text)

    def test_missing_city_is_a_400(self):
        response = self._post(city="")

        self.assertEqual(response.status_code, 400)
        self.assertIn("city", response.json()["error"].lower())

    def test_missing_category_is_a_400(self):
        response = self._post(category="")

        self.assertEqual(response.status_code, 400)
        self.assertIn("category", response.json()["error"].lower())

    def test_non_numeric_limit_is_a_400(self):
        response = self._post(limit="loads")

        self.assertEqual(response.status_code, 400)

    def test_malformed_json_is_a_400(self):
        response = self.client.post(
            reverse("leads:search"), data="not json", content_type="application/json"
        )

        self.assertEqual(response.status_code, 400)

    def test_scraper_failure_is_reported_not_raised(self):
        with mock.patch.object(
            scraper, "search", side_effect=scraper.ScrapeError("mirrors are busy")
        ):
            response = self._post()

        self.assertEqual(response.status_code, 502)
        self.assertEqual(response.json()["error"], "mirrors are busy")

    def test_empty_result_set_explains_itself(self):
        with mock.patch.object(scraper, "search", return_value=(BERLIN, [])):
            response = self._post()

        self.assertEqual(response.status_code, 404)
        self.assertIn("Berlin", response.json()["error"])

    def test_unknown_job_id_is_a_404(self):
        response = self.client.get("/api/export/deadbeef1234")

        self.assertEqual(response.status_code, 404)

    def test_search_rejects_get(self):
        self.assertEqual(self.client.get(reverse("leads:search")).status_code, 405)


@unittest.skipUnless(LIVE, "set LIVE_OSM_TESTS=1 to call the real OSM APIs")
class LiveOsmTests(SimpleTestCase):
    """Hits Nominatim and Overpass for real. Slow, and needs a network."""

    def test_geocode_resolves_a_real_city(self):
        area = scraper.geocode("Berlin", "Germany")

        self.assertEqual(area.country, "Germany")
        self.assertAlmostEqual(area.lat, 52.5, delta=0.6)
        self.assertAlmostEqual(area.lon, 13.4, delta=0.6)
        south, west, north, east = area.bbox
        self.assertLess(south, north)
        self.assertLess(west, east)

    def test_geocode_rejects_a_nonsense_place(self):
        with self.assertRaises(scraper.ScrapeError):
            scraper.geocode("Zzzqqqx Not A Place", "")

    def test_full_search_returns_plottable_leads(self):
        area, leads = scraper.search("Germany", "Berlin", "Cafes", 8)

        self.assertTrue(leads, "expected some cafes in Berlin")
        self.assertLessEqual(len(leads), 8)

        south, west, north, east = area.bbox
        for lead in leads:
            with self.subTest(lead=lead.business_name):
                self.assertTrue(lead.business_name)
                self.assertTrue(south <= lead.latitude <= north)
                self.assertTrue(west <= lead.longitude <= east)
                self.assertTrue(lead.source.startswith("https://www.openstreetmap.org/"))

    def test_custom_category_without_a_country(self):
        _, leads = scraper.search("", "Amsterdam", "bicycle repair", 5)

        self.assertTrue(leads, "expected bicycle shops in Amsterdam")
