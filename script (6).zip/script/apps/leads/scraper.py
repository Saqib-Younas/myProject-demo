"""
Collects public business listings from OpenStreetMap.

Two public, documented APIs do the work, both serving data under the ODbL:

  * Nominatim -- turns "City, Country" into a centre point + bounding box.
  * Overpass  -- returns the points of interest (businesses) inside that box,
                 together with the tags contributors have attached to them.

Nothing in this module logs in, solves a CAPTCHA or works around a bot
defence. These endpoints are published for exactly this kind of query; the only
obligations are the ones in the usage policies -- identify yourself with a real
User-Agent, keep request rates modest, and credit OpenStreetMap when you
publish the results. That is what CONTACT and the throttle below are for.
"""

from __future__ import annotations

import csv
import io
import re
import threading
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Iterable
from urllib.parse import urlparse

import requests

# --------------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------------- #

#: Nominatim's usage policy requires a User-Agent that identifies the app and
#: gives them somebody to contact if it misbehaves. This has to be a real,
#: reachable address: Nominatim returns 403 for placeholder contacts such as
#: you@example.com. Set OSM_CONTACT_EMAIL to change it.
CONTACT = "you@example.com"
USER_AGENT = "LeadMapper/1.0 (+{contact})"

#: Placeholder domains Nominatim refuses to serve.
_PLACEHOLDER_CONTACTS = ("example.com", "example.org", "example.net", "test.com")

NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"

#: Tried in order -- the main instance is busy often enough to be worth a
#: fallback. All three run the same public Overpass software and dataset.
OVERPASS_URLS = (
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://overpass.osm.ch/api/interpreter",
)

#: Seconds to wait between two calls to the same host. Nominatim's policy is an
#: absolute maximum of 1 request/second; Overpass asks for "be gentle".
MIN_INTERVAL = {"nominatim.openstreetmap.org": 1.1}
DEFAULT_INTERVAL = 0.5

QUERY_TIMEOUT = 90
MAX_LEADS = 300

# --------------------------------------------------------------------------- #
# Categories
# --------------------------------------------------------------------------- #

#: Friendly label -> the Overpass tag filters that describe it. Each filter is
#: a separate clause in a union, so "Doctors & Clinics" can match either the
#: amenity or the healthcare tagging scheme.
CATEGORIES: dict[str, tuple[str, ...]] = {
    "Restaurants": ('["amenity"="restaurant"]',),
    "Cafes": ('["amenity"="cafe"]',),
    "Bars & Pubs": ('["amenity"~"^(bar|pub)$"]',),
    "Fast Food & Takeaway": ('["amenity"="fast_food"]',),
    "Bakeries": ('["shop"="bakery"]',),
    "Hotels & Guest Houses": ('["tourism"~"^(hotel|guest_house|hostel|motel)$"]',),
    "Supermarkets & Grocery": ('["shop"~"^(supermarket|convenience|greengrocer)$"]',),
    "Clothing & Fashion": ('["shop"~"^(clothes|shoes|boutique|jewelry)$"]',),
    "Hairdressers & Beauty": ('["shop"~"^(hairdresser|beauty|massage)$"]',),
    "Gyms & Fitness": ('["leisure"~"^(fitness_centre|sports_centre)$"]',),
    "Pharmacies": ('["amenity"="pharmacy"]',),
    "Doctors & Clinics": (
        '["amenity"~"^(doctors|clinic)$"]',
        '["healthcare"~"^(doctor|clinic|centre)$"]',
    ),
    "Dentists": ('["amenity"="dentist"]',),
    "Veterinarians": ('["amenity"="veterinary"]',),
    "Car Repair & Dealers": ('["shop"~"^(car|car_repair|car_parts|tyres)$"]',),
    "Real Estate Agents": ('["office"="estate_agent"]',),
    "Lawyers": ('["office"="lawyer"]',),
    "Accountants": ('["office"="accountant"]',),
    "Insurance": ('["office"="insurance"]',),
    "Banks": ('["amenity"="bank"]',),
    "IT & Software Offices": ('["office"~"^(it|company|coworking)$"]',),
    "Construction & Trades": (
        '["craft"~"^(builder|carpenter|electrician|plumber|painter|roofer)$"]',
    ),
    "Schools & Education": (
        '["amenity"~"^(school|college|language_school|driving_school)$"]',
    ),
    "Hardware & DIY": ('["shop"~"^(hardware|doityourself|trade|paint)$"]',),
    "Furniture & Interiors": ('["shop"~"^(furniture|interior_decoration|kitchen)$"]',),
    "Electronics & Phones": (
        '["shop"~"^(electronics|computer|mobile_phone|hifi)$"]',
    ),
    "Florists": ('["shop"="florist"]',),
    "Laundry & Dry Cleaning": ('["shop"~"^(laundry|dry_cleaning)$"]',),
    "Travel Agencies": ('["shop"="travel_agency"]',),
    "Any business": (
        '["shop"]',
        '["office"]',
        '["craft"]',
        '["amenity"~"^(restaurant|cafe|bar|pub|fast_food|pharmacy|bank|dentist'
        '|doctors|clinic|veterinary)$"]',
        '["tourism"~"^(hotel|guest_house|hostel|motel)$"]',
    ),
}

#: Tags whose value names the kind of business, best first.
_KIND_TAGS = ("shop", "office", "craft", "amenity", "healthcare", "tourism", "leisure")


class ScrapeError(RuntimeError):
    """Something went wrong that the user needs to read, not a stack trace."""


# --------------------------------------------------------------------------- #
# Polite HTTP
# --------------------------------------------------------------------------- #

_lock = threading.Lock()
_last_call: dict[str, float] = {}


def _throttle(url: str) -> None:
    """Space out requests per host so we stay inside the usage policies."""
    host = urlparse(url).hostname or url
    gap = MIN_INTERVAL.get(host, DEFAULT_INTERVAL)
    with _lock:
        wait = gap - (time.monotonic() - _last_call.get(host, 0.0))
        if wait > 0:
            time.sleep(wait)
        _last_call[host] = time.monotonic()


def _headers(accept: str = "*/*") -> dict[str, str]:
    """Build request headers.

    Overpass negotiates content types strictly and answers 406 to a narrow
    ``Accept: application/json``, so the default is deliberately permissive and
    only Nominatim asks for JSON explicitly.
    """
    return {
        "User-Agent": USER_AGENT.format(contact=CONTACT),
        "Accept": accept,
        "Accept-Language": "en",
    }


def _check_contact() -> None:
    """Fail early and legibly rather than on a bare 403 from Nominatim."""
    if any(bad in CONTACT.lower() for bad in _PLACEHOLDER_CONTACTS):
        raise ScrapeError(
            "OpenStreetMap rejects placeholder contact addresses. Set a real "
            "one, e.g. set OSM_CONTACT_EMAIL=you@yourdomain.com, or edit "
            "OSM_CONTACT_EMAIL in config/settings/base.py."
        )


# --------------------------------------------------------------------------- #
# The lead record
# --------------------------------------------------------------------------- #

#: Column order of the exported CSV.
CSV_FIELDS = (
    "business_name",
    "category",
    "country",
    "city",
    "address",
    "phone",
    "email",
    "website",
    "latitude",
    "longitude",
    "source",
)

CSV_HEADERS = (
    "Business Name",
    "Category",
    "Country",
    "City",
    "Address",
    "Phone",
    "Email",
    "Website",
    "Latitude",
    "Longitude",
    "Source",
)


@dataclass
class Lead:
    business_name: str
    category: str
    country: str
    city: str
    address: str
    phone: str
    email: str
    website: str
    latitude: float
    longitude: float
    source: str
    osm_id: str = field(default="", compare=False)

    @property
    def completeness(self) -> int:
        """How usable this row is as a lead -- drives the result ordering."""
        return sum(bool(v) for v in (self.phone, self.email, self.website, self.address))

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


# --------------------------------------------------------------------------- #
# Step 1 -- geocode the search area
# --------------------------------------------------------------------------- #

@dataclass
class Area:
    city: str
    country: str
    label: str
    lat: float
    lon: float
    bbox: tuple[float, float, float, float]  # south, west, north, east


def geocode(city: str, country: str) -> Area:
    """Resolve "city, country" to a centre point and a bounding box."""
    query = ", ".join(p for p in (city.strip(), country.strip()) if p)
    if not query:
        raise ScrapeError("Enter a city or location to search.")

    _check_contact()
    _throttle(NOMINATIM_URL)
    try:
        response = requests.get(
            NOMINATIM_URL,
            params={
                "q": query,
                "format": "jsonv2",
                "limit": 1,
                "addressdetails": 1,
            },
            headers=_headers("application/json"),
            timeout=30,
        )
        if response.status_code == 403:
            raise ScrapeError(
                "OpenStreetMap's geocoder refused the request (403). That "
                "usually means the User-Agent contact address is not one it "
                "accepts -- set OSM_CONTACT_EMAIL to a real address."
            )
        response.raise_for_status()
        results = response.json()
    except requests.RequestException as exc:
        raise ScrapeError(f"Could not reach the geocoder: {exc}") from exc
    except ValueError as exc:
        raise ScrapeError("The geocoder returned an unreadable response.") from exc

    if not results:
        raise ScrapeError(
            f"No place called {query!r} was found. Check the spelling, or try a "
            "larger nearby city."
        )

    hit = results[0]
    try:
        south, north, west, east = (float(v) for v in hit["boundingbox"])
        lat, lon = float(hit["lat"]), float(hit["lon"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ScrapeError("The geocoder returned no usable coordinates.") from exc

    address = hit.get("address") or {}
    resolved_city = (
        address.get("city")
        or address.get("town")
        or address.get("village")
        or address.get("municipality")
        or address.get("county")
        or city.strip()
    )
    return Area(
        city=resolved_city,
        country=address.get("country") or country.strip(),
        label=hit.get("display_name") or query,
        lat=lat,
        lon=lon,
        bbox=(south, west, north, east),
    )


# --------------------------------------------------------------------------- #
# Step 2 -- pull the businesses in that box
# --------------------------------------------------------------------------- #

def _custom_filters(text: str) -> tuple[str, ...]:
    """Build filters for a category the dropdown does not cover.

    Matches the free text against the usual "what kind of business is this"
    tags, and against the business name itself.
    """
    slug = re.sub(r"[^a-z0-9]+", "_", text.strip().lower()).strip("_")
    if not slug:
        raise ScrapeError("Enter a business category to search for.")
    safe = re.escape(text.strip())
    filters = [f'["{tag}"="{slug}"]' for tag in ("shop", "office", "craft", "amenity")]
    filters.append(f'["name"~"{safe}",i]')
    return tuple(filters)


def build_query(filters: Iterable[str], bbox: tuple[float, float, float, float],
                limit: int) -> str:
    """Assemble an Overpass QL query.

    ``nwr`` covers nodes, ways and relations -- a business may be tagged on a
    single point or on its building outline. ``out center`` collapses each one
    to a single lat/lon, which is all a map marker needs.
    """
    south, west, north, east = bbox
    box = f"({south:.6f},{west:.6f},{north:.6f},{east:.6f})"
    clauses = "\n".join(f"  nwr{f}{box};" for f in filters)
    return (
        f"[out:json][timeout:{QUERY_TIMEOUT}];\n"
        f"(\n{clauses}\n);\n"
        f"out tags center {limit};\n"
    )


def run_overpass(query: str) -> list[dict[str, Any]]:
    """POST the query, falling back to the mirrors if an instance is busy."""
    problems: list[str] = []
    for url in OVERPASS_URLS:
        _throttle(url)
        try:
            response = requests.post(
                url,
                data={"data": query},
                headers=_headers(),
                timeout=QUERY_TIMEOUT + 15,
            )
            if response.status_code in (429, 504):
                problems.append(f"{urlparse(url).hostname}: server busy")
                continue
            response.raise_for_status()
            return response.json().get("elements", [])
        except requests.RequestException as exc:
            problems.append(f"{urlparse(url).hostname}: {exc}")
        except ValueError:
            problems.append(f"{urlparse(url).hostname}: unreadable response")

    raise ScrapeError(
        "Every Overpass mirror refused the query, so no data was collected. "
        "These are shared public servers -- wait a minute and try again, or "
        "search a smaller area. (" + "; ".join(problems) + ")"
    )


# --------------------------------------------------------------------------- #
# Step 3 -- turn OSM tags into lead rows
# --------------------------------------------------------------------------- #

def _first(tags: dict[str, str], *keys: str) -> str:
    for key in keys:
        value = (tags.get(key) or "").strip()
        if value:
            return value
    return ""


def _pretty(value: str) -> str:
    return value.replace("_", " ").replace(";", ", ").strip().title()


def _describe(tags: dict[str, str], fallback: str) -> str:
    for tag in _KIND_TAGS:
        value = (tags.get(tag) or "").strip()
        if value and value not in ("yes", "no"):
            return _pretty(value)
    return fallback


def _address(tags: dict[str, str], area: Area) -> str:
    """Assemble a street address from the addr:* tags contributors supplied."""
    street = _first(tags, "addr:street")
    number = _first(tags, "addr:housenumber")
    line = f"{number} {street}".strip() if street else ""
    locality = _first(tags, "addr:city", "addr:town", "addr:suburb") or area.city
    parts = [p for p in (line, locality, _first(tags, "addr:postcode")) if p]
    return ", ".join(parts)


def _website(tags: dict[str, str]) -> str:
    url = _first(tags, "website", "contact:website", "url", "brand:website")
    if url and not url.startswith(("http://", "https://")):
        url = f"https://{url}"
    return url


def to_lead(element: dict[str, Any], area: Area) -> Lead | None:
    """Convert one Overpass element into a Lead, or None if it is not one.

    Unnamed features are dropped: a marker with no business name is not a lead.
    """
    tags = element.get("tags") or {}
    name = _first(tags, "name", "brand", "operator")
    if not name:
        return None

    centre = element.get("center") or element
    lat, lon = centre.get("lat"), centre.get("lon")
    if lat is None or lon is None:
        return None

    kind, osm_id = element.get("type", "node"), element.get("id", "")
    return Lead(
        business_name=name,
        category=_describe(tags, "Business"),
        country=_first(tags, "addr:country") or area.country,
        city=_first(tags, "addr:city", "addr:town") or area.city,
        address=_address(tags, area),
        phone=_first(tags, "phone", "contact:phone", "contact:mobile", "telephone"),
        email=_first(tags, "email", "contact:email"),
        website=_website(tags),
        latitude=round(float(lat), 6),
        longitude=round(float(lon), 6),
        source=f"https://www.openstreetmap.org/{kind}/{osm_id}",
        osm_id=f"{kind}/{osm_id}",
    )


# --------------------------------------------------------------------------- #
# The public entry point
# --------------------------------------------------------------------------- #

def search(country: str, city: str, category: str, limit: int) -> tuple[Area, list[Lead]]:
    """Geocode, query, clean up -- the whole collection run for one search."""
    limit = max(1, min(int(limit), MAX_LEADS))
    area = geocode(city, country)

    filters = CATEGORIES.get(category) or _custom_filters(category)
    # Over-fetch: unnamed and duplicate features get dropped below, and we
    # still want to be able to fill the requested number of leads.
    elements = run_overpass(build_query(filters, area.bbox, limit * 4))

    leads: list[Lead] = []
    seen: set[tuple[str, float, float]] = set()
    for element in elements:
        lead = to_lead(element, area)
        if lead is None:
            continue
        # Businesses mapped as both a node and a building show up twice.
        key = (lead.business_name.casefold(), round(lead.latitude, 4),
               round(lead.longitude, 4))
        if key in seen:
            continue
        seen.add(key)
        leads.append(lead)

    # Best leads first: the ones with contact details you can actually use.
    leads.sort(key=lambda l: (-l.completeness, l.business_name.casefold()))
    return area, leads[:limit]


# --------------------------------------------------------------------------- #
# CSV export
# --------------------------------------------------------------------------- #

def write_csv(leads: Iterable[Lead], stream: io.TextIOBase) -> None:
    writer = csv.writer(stream)
    writer.writerow(CSV_HEADERS)
    for lead in leads:
        writer.writerow([lead.as_dict()[f] for f in CSV_FIELDS])


def csv_text(leads: Iterable[Lead]) -> str:
    buffer = io.StringIO()
    write_csv(leads, buffer)
    return buffer.getvalue()
