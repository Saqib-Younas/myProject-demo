from django.urls import path

from . import views

app_name = "leads"

urlpatterns = [
    path("", views.index, name="index"),
    path("api/search", views.search, name="search"),
    path("api/cities", views.cities, name="cities"),
    path("api/export/<str:job_id>", views.export, name="export"),
]
