"""
Country and city selection: the dataset, the dependent lookup, and validation.

The interesting cases are the ones where a naive implementation goes wrong:
an alias pointing at a name the dataset does not use (which fails silently), a
city that exists in several countries, and a real town the reference data has
never heard of.
"""

from __future__ import annotations

import json

from django.test import TestCase, override_settings
from django.urls import reverse

from apps.core.testing import SignedIn  # noqa: F401

from . import places


class CountryListTests(SignedIn):
    def test_the_whole_world_is_present(self):
        codes = {code for code, _name in places.countries()}

        # 249 ISO 3166-1 entries plus a few historical codes GeoNames retains.
        self.assertGreater(len(codes), 240)
        for code in ("US", "GB", "DE", "PK", "NL", "IN", "CN", "BR", "ZA",
                     "AU", "JP", "NG", "EG", "KY", "NR", "TV", "VA"):
            with self.subTest(code=code):
                self.assertIn(code, codes)

    def test_names_are_unique_and_sorted(self):
        names = [name for _code, name in places.countries()]

        self.assertEqual(len(names), len(set(names)))
        self.assertEqual(names, sorted(names))

    def test_the_dropdown_offers_names_plus_aliases(self):
        choices = places.country_choices()

        self.assertIn("Pakistan", choices)
        self.assertIn("Germany", choices)
        self.assertIn("UAE", choices)
        self.assertIn("UK", choices)
        self.assertGreater(len(choices), len(places.countries()))

    def test_every_alias_resolves_to_a_real_country(self):
        """An alias pointing at a name the dataset does not use is invisible.

        It simply never matches, and the only symptom is an empty city dropdown.
        Several were wrong on the first pass -- the dataset calls NL "The
        Netherlands" and CI "Ivory Coast" -- so this asserts on it directly.
        """
        self.assertEqual(places.check_aliases(), [])

    def test_code_lookup_accepts_names_aliases_and_codes(self):
        self.assertEqual(places.code_for("Pakistan"), "PK")
        self.assertEqual(places.code_for("  germany "), "DE")
        self.assertEqual(places.code_for("UAE"), "AE")
        self.assertEqual(places.code_for("Holland"), "NL")
        self.assertEqual(places.code_for("Netherlands"), "NL")
        self.assertEqual(places.code_for("DE"), "DE")
        self.assertEqual(places.code_for("Atlantis"), "")
        self.assertEqual(places.code_for(""), "")

    def test_country_name_round_trips(self):
        self.assertEqual(places.country_name("PK"), "Pakistan")
        self.assertEqual(places.country_name("pk"), "Pakistan")
        self.assertEqual(places.country_name("ZZ"), "")


class CityLookupTests(SignedIn):
    def test_cities_load_for_a_country(self):
        cities = places.city_names_for("Pakistan")

        self.assertGreater(len(cities), 100)
        for expected in ("Lahore", "Karachi", "Islamabad"):
            with self.subTest(city=expected):
                self.assertIn(expected, cities)

    def test_cities_are_ordered_by_population(self):
        rows = places.cities_for("Pakistan")
        populations = [r["population"] for r in rows]

        self.assertEqual(populations, sorted(populations, reverse=True))
        self.assertEqual(rows[0]["name"], "Lahore")

    def test_aliases_and_codes_load_the_same_cities(self):
        by_name = places.city_names_for("Netherlands")
        by_alias = places.city_names_for("Holland")
        by_code = places.city_names_for("NL")

        self.assertEqual(by_name, by_alias)
        self.assertEqual(by_name, by_code)
        self.assertIn("Amsterdam", by_name)

    def test_each_country_gets_its_own_cities(self):
        german = set(places.city_names_for("Germany"))
        pakistani = set(places.city_names_for("Pakistan"))

        self.assertIn("Berlin", german)
        self.assertNotIn("Berlin", pakistani)
        self.assertIn("Lahore", pakistani)
        self.assertNotIn("Lahore", german)

    def test_an_unknown_country_yields_no_cities(self):
        self.assertEqual(places.cities_for("Atlantis"), ())
        self.assertEqual(places.cities_for(""), ())

    def test_city_names_are_deduplicated(self):
        names = places.city_names_for("United States")

        self.assertEqual(len(names), len(set(names)))

    def test_a_shared_city_name_maps_to_several_countries(self):
        holders = places.countries_with_city("Paris")

        self.assertIn("FR", holders)
        self.assertGreater(len(holders), 1)   # also in the United States

    def test_an_unknown_city_maps_to_no_country(self):
        self.assertEqual(places.countries_with_city("Kleinkleckersdorf"),
                         frozenset())


class ValidationTests(SignedIn):
    """City must not contradict country -- but absence is not contradiction."""

    def test_a_matching_pair_is_accepted(self):
        for country, city in (("Germany", "Berlin"), ("Pakistan", "Lahore"),
                              ("Netherlands", "Amsterdam"), ("NL", "Rotterdam")):
            with self.subTest(pair=(country, city)):
                ok, message = places.validate(country, city)
                self.assertTrue(ok, message)

    def test_a_city_from_another_country_is_rejected(self):
        ok, message = places.validate("Germany", "Lahore")

        self.assertFalse(ok)
        self.assertIn("not in Germany", message)
        self.assertIn("Pakistan", message)

    def test_the_rejection_names_where_the_city_actually_is(self):
        ok, message = places.validate("Pakistan", "Berlin")

        self.assertFalse(ok)
        self.assertIn("Germany", message)

    def test_an_unknown_town_is_allowed_through(self):
        """The dataset stops at ~15,000 people; the geocoder does not.

        Rejecting absence would make every small town unsearchable, which is a
        worse failure than letting the geocoder decide.
        """
        ok, message = places.validate("Germany", "Kleinkleckersdorf")

        self.assertTrue(ok, message)

    def test_a_city_shared_between_countries_is_allowed_in_both(self):
        self.assertTrue(places.validate("France", "Paris")[0])
        self.assertTrue(places.validate("United States", "Paris")[0])

    def test_no_country_means_no_contradiction_to_find(self):
        self.assertTrue(places.validate("", "Berlin")[0])

    def test_an_unrecognised_country_is_left_to_the_geocoder(self):
        self.assertTrue(places.validate("Atlantis", "Berlin")[0])

    def test_a_missing_city_is_rejected(self):
        ok, message = places.validate("Germany", "")

        self.assertFalse(ok)
        self.assertIn("Enter a city", message)


@override_settings(ALLOWED_HOSTS=["*"])
class CitiesEndpointTests(SignedIn):
    def _get(self, country):
        return self.client.get(reverse("leads:cities"), {"country": country})

    def test_selecting_a_country_returns_its_cities(self):
        response = self._get("Pakistan")

        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["code"], "PK")
        self.assertEqual(data["country"], "Pakistan")
        self.assertGreater(data["count"], 100)
        names = [c["name"] for c in data["cities"]]
        self.assertIn("Lahore", names)
        self.assertNotIn("Berlin", names)

    def test_each_city_carries_its_population_for_the_dropdown(self):
        city = self._get("Germany").json()["cities"][0]

        self.assertIn("name", city)
        self.assertIsInstance(city["population"], int)

    def test_an_alias_works_as_the_country(self):
        data = self._get("Holland").json()

        self.assertEqual(data["code"], "NL")
        self.assertIn("Amsterdam", [c["name"] for c in data["cities"]])

    def test_a_missing_country_is_a_400(self):
        response = self._get("")

        self.assertEqual(response.status_code, 400)
        self.assertIn("country", response.json()["error"].lower())

    def test_an_unknown_country_returns_an_explanatory_note(self):
        data = self._get("Atlantis").json()

        self.assertEqual(data["cities"], [])
        self.assertIn("not in the reference data", data["note"])

    def test_a_country_with_no_listed_cities_explains_itself(self):
        # Nauru has a single settlement above the dataset's population floor.
        data = self._get("Nauru").json()

        self.assertEqual(data["code"], "NR")
        if not data["cities"]:
            self.assertIn("Type the place name", data["note"])


@override_settings(ALLOWED_HOSTS=["*"])
class SearchValidationTests(SignedIn):
    """The server rejects an incoherent pair before spending a geocode."""

    def _post(self, **body):
        payload = {"country": "", "city": "Berlin", "category": "Cafes",
                   "limit": 5}
        payload.update(body)
        return self.client.post(reverse("leads:search"), data=payload,
                                content_type="application/json")

    def test_a_city_from_another_country_is_refused(self):
        from unittest import mock

        from . import scraper

        with mock.patch.object(scraper, "search") as search:
            response = self._post(country="Germany", city="Lahore")

        self.assertEqual(response.status_code, 400)
        self.assertIn("not in Germany", response.json()["error"])
        # The point of validating here: no geocoding request was made.
        search.assert_not_called()

    def test_a_coherent_pair_reaches_the_scraper(self):
        from unittest import mock

        from . import scraper
        from .tests import BERLIN, make_lead

        with mock.patch.object(scraper, "search",
                               return_value=(BERLIN, [make_lead()])) as search:
            response = self._post(country="Germany", city="Berlin")

        self.assertEqual(response.status_code, 200)
        search.assert_called_once()

    def test_an_unlisted_town_still_reaches_the_scraper(self):
        from unittest import mock

        from . import scraper
        from .tests import BERLIN, make_lead

        with mock.patch.object(scraper, "search",
                               return_value=(BERLIN, [make_lead()])):
            response = self._post(country="Germany", city="Kleinkleckersdorf")

        self.assertEqual(response.status_code, 200)


@override_settings(ALLOWED_HOSTS=["*"])
class SearchFormRestoreTests(SignedIn):
    """A stored country and city must come back into the form."""

    def test_the_form_ships_the_whole_country_list(self):
        response = self.client.get(reverse("leads:index"))
        body = response.content.decode()

        self.assertEqual(response.status_code, 200)
        payload = json.loads(
            body.split('id="country-data" type="application/json">')[1]
                .split("</script>")[0]
        )
        self.assertGreater(len(payload), 240)
        self.assertIn("Pakistan", payload)
        self.assertIn("Germany", payload)

    def test_the_city_field_starts_disabled(self):
        body = self.client.get(reverse("leads:index")).content.decode()

        city_field = body.split('id="city"')[1].split(">")[0]
        self.assertIn("disabled", city_field)

    def test_a_saved_country_and_city_are_restored(self):
        response = self.client.get(
            reverse("leads:index"),
            {"country": "Pakistan", "city": "Lahore", "category": "Restaurants"},
        )
        body = response.content.decode()

        self.assertIn('id="country"', body)
        self.assertIn('value="Pakistan"', body)
        self.assertIn('value="Lahore"', body)

    def test_a_restored_country_enables_the_city_field(self):
        body = self.client.get(
            reverse("leads:index"), {"country": "Pakistan"}
        ).content.decode()

        city_field = body.split('id="city"')[1].split(">")[0]
        self.assertNotIn("disabled", city_field)

    def test_a_restored_country_preloads_its_cities(self):
        body = self.client.get(
            reverse("leads:index"), {"country": "Pakistan"}
        ).content.decode()

        payload = json.loads(
            body.split('id="initial-city-data" type="application/json">')[1]
                .split("</script>")[0]
        )
        names = [c["name"] for c in payload]
        self.assertIn("Lahore", names)

    def test_no_country_means_no_preloaded_cities(self):
        body = self.client.get(reverse("leads:index")).content.decode()

        payload = json.loads(
            body.split('id="initial-city-data" type="application/json">')[1]
                .split("</script>")[0]
        )
        self.assertEqual(payload, [])


class CampaignPlaceRoundTripTests(SignedIn):
    """The campaign record keeps the country and city it was created with."""

    def test_a_campaign_stores_and_returns_its_place(self):
        from apps.outreach.models import Campaign, EmailDraft

        campaign = Campaign.objects.create(
            country="Pakistan", city="Lahore", category="Restaurants")
        draft = EmailDraft.objects.create(
            campaign=campaign, business_name="ABC", email="abc@abc.example",
            country="Pakistan", city="Lahore")

        campaign.refresh_from_db()
        draft.refresh_from_db()

        self.assertEqual((campaign.country, campaign.city), ("Pakistan", "Lahore"))
        self.assertEqual((draft.country, draft.city), ("Pakistan", "Lahore"))
        self.assertIn("Lahore", campaign.label)

    def test_the_stored_place_is_a_valid_pair(self):
        from apps.outreach.models import Campaign

        campaign = Campaign.objects.create(
            country="Pakistan", city="Lahore", category="Restaurants")

        ok, message = places.validate(campaign.country, campaign.city)

        self.assertTrue(ok, message)
