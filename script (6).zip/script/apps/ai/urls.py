"""
The credential pool's routes.

Mounted by `config/urls.py` at the prefix the outreach app already answered on, so
every path a browser or a piece of JavaScript knows is unchanged. Only the reverse()
namespace moved -- from `outreach:` to `ai:` -- which is internal to templates and
tests.

Every route acts on one credential by id and re-reads it scoped to the signed-in
account, so an id in a URL grants nothing on its own. `select` is the exception: it
carries a provider name, never a key.
"""

from django.urls import path

from . import views

app_name = "ai"

urlpatterns = [
    path("select", views.ai_select, name="ai_select"),
    # One route to add a child under a provider, then routes that act on one child.
    path("credentials/<str:provider>/add", views.credential_add,
         name="credential_add"),
    path("credentials/<int:pk>/activate", views.credential_activate,
         name="credential_activate"),
    path("credentials/<int:pk>/deactivate", views.credential_deactivate,
         name="credential_deactivate"),
    path("credentials/<int:pk>/test", views.credential_test,
         name="credential_test"),
    path("credentials/<int:pk>/fallback", views.credential_fallback,
         name="credential_fallback"),
    path("credentials/<int:pk>/delete", views.credential_delete,
         name="credential_delete"),
    path("credentials/events", views.credential_events,
         name="credential_events"),
]
