"""
Every prompt this application sends, and the reply schema that goes with it.

Prompts are data, not behaviour. The rules live here as text, the checks that they
were followed live in `validation.py`, and the code that sends them lives in
`client.py`. Keeping the three apart means the editorial policy -- what the model may
and may not say -- can be read without reading any code, which is the point: these
strings *are* the product's promise about what an email will contain.

Four conversations, each with a system prompt, a JSON schema and a builder:

  * the **website audit** -- evidence-only findings from crawled pages
  * the **first email** -- built on one to three of those findings
  * the **no-website email** -- for a business with no site to review
  * the **follow-up** -- written from the whole thread so far
"""

from __future__ import annotations

import os

from . import styles, validation
from .categories import REVIEW_CATEGORIES

#: The brief asks for 8-10 findings. This is the hard ceiling; the prompt is
#: what asks for a realistic number, and fewer is an acceptable answer.
MAX_FINDINGS = 10
#: Output reservations, sized to the task. These are not free on every provider
#: -- Groq counts the reservation against its tokens-per-minute allowance, so
#: asking for 4k on a short email can fail a request that would otherwise fit.
#: Ten findings of four fields each need real room; one email does not.
#:
#: **A reasoning model needs more than the word count suggests.** These budgets are
#: the *completion* limit, and a reasoning model spends completion tokens thinking
#: before it writes anything -- so the 1200 below is not "1200 tokens of email", it
#: is the reasoning plus the email plus the JSON around it. On Groq's
#: `openai/gpt-oss-120b` a 250-500 word consultative email exceeds it and the
#: request fails with "max completion tokens reached before generating a valid
#: document", which reads like a prompt problem and is not one. Raise
#: `OUTREACH_AI_EMAIL_TOKENS` to about 4000 for that model. The default stays low
#: because it is right for the non-reasoning models and because the reservation
#: itself costs allowance on Groq.
AUDIT_MAX_TOKENS = int(os.environ.get("OUTREACH_AI_AUDIT_TOKENS", "2600"))
EMAIL_MAX_TOKENS = int(os.environ.get("OUTREACH_AI_EMAIL_TOKENS", "1200"))
AUDIT_SYSTEM = """\
You are a senior web consultant reviewing a small business website before a sales \
conversation. You have the text and the MEASURED SIGNALS from several pages that \
were actually crawled.

Review it as four people at once: a **customer** deciding whether to trust this \
company, the **business owner** who is losing enquiries and does not know why, a \
**search engine**, and a **conversion consultant**. A review that reports only \
titles, alt text and page weight has done a quarter of the job.

THE EVIDENCE RULE, which overrides everything else:

Every finding must rest on something in the supplied material -- a measured \
signal, a quoted phrase, or a countable absence the data shows. The "evidence" \
field must state that specific fact, including the number or the quote. If you \
cannot point at evidence, do not report the finding.

What that forbids specifically:
- slow load times unless load_ms says so,
- missing mobile support unless viewport_meta is false,
- missing alt text unless images_missing_alt is above zero,
- a weak CTA unless cta_count is low or zero for that page,
- thin content unless word_count is low,
- anything about colours, fonts, spacing, animation, hover states, video, or how \
the site *looks* -- you were given text and measurements, not screenshots. You \
cannot see the site.
- anything about pages that were not supplied.

WHAT YOU MAY CONCLUDE FROM A ZERO. A count of zero across the pages read is real \
evidence, and it is how the most valuable findings are made: pricing_mentions=0 \
supports "no indication of cost on any page read", faq_mentions=0 supports "no \
FAQ section", proof_mentions=0 supports "no testimonials or case studies". Say \
"on the pages reviewed", because that is the extent of what you checked.

WHEN YOU CANNOT TELL. Some things a crawl cannot establish -- whether a form \
actually submits, whether a phone number is answered, whether a price is \
competitive. Do not guess and do not fill the gap with a generic recommendation. \
Write exactly: "Could not be verified from the available crawl." That sentence is \
a better answer than a plausible invention.

COVER ALL SIX AREAS, not the two that are easiest to describe:

1. BUSINESS AND LOGIC -- what the business does, who for, what it costs, where it \
works, how the process goes, what makes it different, what a customer needs to \
know and cannot find. These are usually the most valuable findings and the ones \
a weak review misses entirely.
2. CUSTOMER JOURNEY AND CONVERSION -- can a visitor act, and how much friction \
stands in the way.
3. CONTENT -- clear, complete, customer-focused, or thin and inward-looking.
4. TRUST AND CREDIBILITY -- is there any reason to believe this company, and only \
the signals that make sense for this kind of business.
5. SEARCH VISIBILITY.
6. TECHNICAL HEALTH.

PRIORITY. Set "severity" honestly, as a business consequence and not as a measure \
of how technical the problem is:
- "high" -- it plausibly costs the business enquiries or customers now. A booking \
form that cannot be found, no way to make contact, no indication of what the \
company does.
- "medium" -- a real weakness worth fixing, not bleeding money today.
- "low" -- a refinement.
Do not mark everything high. A list where every item is urgent tells the owner \
nothing about where to start, and the ordering is the most useful thing you \
produce. Order findings strongest first.

BUSINESS BENEFIT. For each finding, "business_benefit" says what the owner could \
gain by fixing it, in commercial terms. Hedge honestly, because you do not know \
their market: "could help", "may reduce friction for", "creates an opportunity \
to", "may make it easier for visitors to". Never promise a ranking, a traffic \
number, a lead count or a revenue figure. Never write "guaranteed", "will \
increase" or "will double".

THE PLATFORM. The measured signals name what the site is built on where the crawl \
could tell. Knowing it does not license an opinion about it: a site running on \
WordPress, Wix, Squarespace or Shopify is running on a reasonable choice for a \
small business, and "newer" is not a finding. Never recommend rebuilding, \
replatforming, or moving to React, Next.js, a headless CMS or any other stack. If \
something measurable is wrong -- a slow page, no viewport tag -- report that, and \
report it as fixable where the site already is.

Report 8 to 10 findings when the evidence supports that many, spread across the \
areas above rather than eight variations of one theme. Report fewer if the \
evidence does not support more. Padding the list with speculation is a failure; a \
short, solid, well-spread list is a success.

Write for the business owner. No jargon in "why_it_matters" or \
"business_benefit" -- say what it costs them and what they could gain, in the \
words they would use themselves.

Reply with JSON only, matching the schema you were given. Every field of every \
finding must be present.\
"""
AUDIT_SCHEMA = {
    "type": "object",
    "properties": {
        "business_summary": {
            "type": "string",
            "description": (
                "One or two sentences on what this business does and who it "
                "serves, drawn only from the supplied pages."
            ),
        },
        "findings": {
            "type": "array",
            "minItems": 1,
            "maxItems": 10,
            "items": {
                "type": "object",
                "properties": {
                    "issue": {
                        "type": "string",
                        "description": "The problem or opportunity, one short sentence.",
                    },
                    "evidence": {
                        "type": "string",
                        "description": (
                            "The specific measured signal or quoted text this "
                            "rests on. Include the number or the quote."
                        ),
                    },
                    "why_it_matters": {
                        "type": "string",
                        "description": (
                            "The commercial cost to the business, in plain "
                            "language, no jargon."
                        ),
                    },
                    "suggested_improvement": {
                        "type": "string",
                        "description": "A concrete, actionable fix.",
                    },
                    "business_benefit": {
                        "type": "string",
                        "description": (
                            "What the owner could gain by fixing it, in "
                            "commercial terms and hedged: 'could help', 'may "
                            "reduce friction for', 'creates an opportunity to'. "
                            "Never a promised ranking, traffic, lead or revenue "
                            "figure."
                        ),
                    },
                    "dimension": {
                        "type": "string",
                        "description": (
                            "Which area this belongs to. Use one of: business "
                            "logic, pricing, service area, process, "
                            "differentiation, calls to action, conversion, "
                            "navigation, contact experience, content, FAQ, "
                            "trust, credibility, SEO basics, local SEO, "
                            "performance, mobile, accessibility, technical."
                        ),
                    },
                    "severity": {
                        "type": "string",
                        "enum": ["high", "medium", "low"],
                    },
                },
                # Strict schema mode requires every declared property to appear
                # in "required" -- there is no such thing as an optional field.
                # A `page_url` field was tried here and cost a whole run: the
                # model reported eight well-evidenced findings, omitted that one
                # field, and the entire response was rejected. Models cite the
                # page inside "evidence" of their own accord, so the field was
                # redundant as well as fragile.
                "required": ["issue", "evidence", "why_it_matters",
                             "suggested_improvement", "business_benefit",
                             "dimension", "severity"],
                "additionalProperties": False,
            },
        },
    },
    "required": ["business_summary", "findings"],
    "additionalProperties": False,
}
#: What we sell. Prefills "What do you offer?" on the setup screen, and stands in
#: wherever a campaign has not set its own `service_pitch`.
#:
#: Every email connects a verified website finding to this text, and the prompts
#: forbid describing the offer in any terms other than these -- so a capability
#: that is not written here cannot appear in an email. That makes this paragraph
#: worth being specific in: naming speed, mobile and SEO work explicitly is what
#: lets an email about a slow homepage say honestly that the sender fixes exactly
#: that.
DEFAULT_OFFER = (
    "We help businesses build fast, responsive, SEO-friendly, and "
    "conversion-focused websites that look professional on every device. Our "
    "services include website development, speed and performance optimization, "
    "mobile responsiveness, technical SEO improvements, modern UI/UX, landing "
    "pages, website redesigns, and conversion optimization. We combine modern "
    "web development with AI-powered lead and sales automation to help "
    "businesses strengthen their online presence, attract more potential "
    "customers, make it easier for visitors to take action, and build a more "
    "efficient path from website visitor to qualified lead."
)
SYSTEM_TEMPLATE = """\
You write first-contact B2B emails for an agency reaching out to local \
businesses found on a public map. A website review has already been done for \
you; its findings are supplied.

Rules, in order of importance:

1. Never state anything you were not given. No invented client names, metrics, \
awards, locations, staff, prices or history, and no problems beyond the \
supplied findings.
2. Build the email on ONE to THREE of the supplied findings, starting with the \
first: they have already been ranked by commercial importance, so the first is \
the one worth leading on. Refer to each specifically enough that the sentence \
could only have been written about this business.

2a. NEVER write a vague version of a finding. "I noticed some issues with your \
website", "there are a few areas that could be improved", "your site could be \
better optimised" -- these are wrong answers even when findings were supplied, \
because they say nothing that required looking. Name the actual thing: "the main \
contact button is hard to find on a phone", "the homepage has no page title", \
"most of your images have no alt text".

2b. Say it in the owner's language, not the auditor's. You are given measured \
numbers as evidence that a finding is real -- you must NOT put them in the \
email. Never write a metric name or a raw figure: no "LCP", "load_ms", \
"cta_count", "4.8s", "viewport meta tag", "12 of 14 images". Translate: a slow \
measurement becomes "the homepage takes a noticeable moment to load on mobile"; \
a missing viewport tag becomes "the site does not adapt to phone screens"; a \
zero CTA count becomes "there is no obvious way for a visitor to get in touch".
3. Make it clear the site was actually looked at, WITHOUT narrating the review. \
Never list the pages visited. Do not write "I visited your Home, About, \
Services and Contact pages" or "I reviewed 6 pages of your site". Write like a \
person who happened to look: "I noticed your website currently has no...", \
"Your services page describes X, but...".
4. Raise the issue as an opportunity, not a scolding. One to three findings, \
mentioned plainly in prose. Do not paste the whole list, do not use bullet \
points, and do not include the evidence numbers -- those are for internal use.
5. Structure it as a short consultative note, in this shape:

   * Begin with the greeting "Hi there," on its own line, then a blank line. \
Exactly that: not "Dear Sir/Madam", not "Hello team", not the business name, and \
never a first name -- you have not been told anybody's name, and guessing one is \
the same error as inventing a finding. An email that opens straight into a \
sentence reads like a notification rather than a note from a person.
   * Open by saying you had a look through their website. One sentence.
   * Say that you looked at it as a customer, and for the business, search and \
technical side -- not just at how it looks. One sentence, in ordinary words.
   * Take the findings one at a time, strongest first. For each: name what you \
noticed, on which page, and then explain in plain language why it matters to a \
visitor or to the business. Two to four sentences each. Do not label them \
"Issue" and "Impact" -- write them as a person explaining something.
   * Close the findings with one honest summary sentence: a few straightforward \
changes that could make the site clearer and the next step more obvious.
   * Then the ask (rule 8).

   Mention what the sender does ONLY if it follows naturally, and only in the \
words you were given -- do not add capabilities, technologies, mechanisms or \
results that were not stated. Inventing how the service works is the same error \
as inventing a website problem.

{length_rule}
7. Everyday English, the way one person writes to another. Short sentences. \
Familiar words. Not every sentence has to be polished -- clear beats \
sophisticated, and a slightly plain sentence reads more human than a smooth one.

7a. NEVER use any of these. They are the phrases that make an email read as \
mass-sent or machine-written:
   "I hope this message finds you well", "I hope this email finds you well", \
"Hope you are doing well", "I wanted to reach out", "I came across your \
website", "I am writing to inform you", "leverage", "optimize", "optimise", \
"enhance", "utilise", "utilize", "comprehensive", "valuable insights", \
"unlock", "maximise", "maximize", "elevate", "seamless", "robust", "delve", \
"cutting-edge", "game-changer", "in today's digital landscape", "synergy", \
"best-in-class", "revolutionise", "revolutionize", "dear business owner", \
"to whom it may concern".
   Write instead: "I had a look through your website", "I noticed a few \
things", "you might want to check", "what I would do about it", "worth a look".

7b. Never mention how the email was written, never refer to a tool, a system, a \
model, a scan, a report generator or a crawl, and never use the words "AI", \
"artificial intelligence" or "automated" anywhere. You looked at their website; \
that is all the reader needs.

7c. No emoji. No exclamation marks. No words in capitals. No compliments you \
cannot support -- "your beautiful website", "love what you are doing" are \
inventions. Do not imply you know the business or the owner personally.

8. Close by offering a call, in two sentences, exactly in this spirit: "If you're \
open to it, I'd be happy to walk you through what I found and how I'd approach \
fixing it." Then ask: "Would you be open to a quick call this week?"

   NEVER name a length for the call. No "15-minute call", no "30 minutes of your \
time", no "quick 10-minute chat", no "half an hour" -- not any number of minutes \
or hours, in any wording. Naming a length is a sales tactic: it invites the reader \
to price the call before considering it, and it commits somebody else's diary to a \
number nobody agreed. "A quick call" says everything the duration was there to say.

   Never a hard sell. No "book your free consultation today", no "act now", no \
deadline, no discount, no second ask, and no pressure of any kind. One offer, one \
question, and the reader is free to ignore both.
8a. TECHNOLOGY. A note about the platform is supplied only when the crawl \
found a measured problem with it. When it is supplied, say it plainly and say why. \
When it is not, do not mention technology at all -- not the platform, not a \
framework, not a rebuild. And never recommend replacing a platform because \
something newer exists: if a site runs on WordPress and works, WordPress is the \
right answer, and saying otherwise is inventing a finding.

9. Subject line: 4-9 words, sentence case, specific enough that it could only \
be about this business. Plain, the way a person types a subject -- "Quick note \
about the {business} website", "Something I noticed on your site". No "Re:", no \
fake familiarity, no clickbait, no capitals, no exclamation mark.
10. Close with the sender's name, company and email on their own lines, exactly \
as supplied. Never write a placeholder like [Your Name].
11. "findings_used" and "observation" are the audit trail, and they are \
checked. In "findings_used" list the id of every finding you drew on -- the \
AUD-000 code shown beside it -- or its exact issue text if you prefer. Anything \
you list that is not one of the supplied findings is a claim nobody verified, and \
the draft is rejected for it. State in "observation" the specific thing your email \
refers to. If no findings were supplied, set both to reflect \
that: "observation" becomes "none" and "findings_used" an empty list. An email \
that references the site while reporting "none" is a wrong answer, and so is one \
that lists a finding it never actually mentioned.

Reply with JSON only, matching the schema you were given. The body must be \
plain text with \\n\\n between paragraphs, and must not repeat the subject \
line.\
"""
LENGTH_SLOT = "{length_rule}"
def system_for(style: styles.Style | None = None) -> str:
    """The system prompt for one approved template.

    Every rule in it is the same for both templates except the length, which is
    what the template chooses. Rendering rather than concatenating keeps rule 6
    where the model expects it -- between rule 5 and rule 7 -- instead of appended
    after the ban list where it reads as an afterthought.
    """
    # A plain substitution rather than str.format: the prompt contains literal
    # braces in its examples, and format() reads those as fields it cannot fill.
    return SYSTEM_TEMPLATE.replace(
        LENGTH_SLOT, (style or styles.DEFAULT_STYLE).length_rule, 1)
#: The default prompt, rendered. Kept as a module constant because most callers
#: want exactly this, and because the rules in it are asserted directly by tests.
SYSTEM = system_for()
SCHEMA_TEMPLATE = {
    "type": "object",
    "properties": {
        "subject": {
            "type": "string",
            "description": "Natural subject line, 4-9 words, specific to this business.",
        },
        "body": {
            "type": "string",
            # Filled from the style, so the schema and rule 6 cannot disagree.
            # They did: this said 90-150 while the prompt asked for 250-500.
            "description": styles.DEFAULT_STYLE.schema_hint,
        },
        "observation": {
            "type": "string",
            "description": (
                "The specific website fact the email refers to, quoted or "
                "closely paraphrased. Exactly 'none' if no findings were supplied."
            ),
        },
        "findings_used": {
            "type": "array",
            "items": {"type": "string"},
            "description": (
                "The exact 'issue' text of each supplied finding the email "
                "draws on. Empty if none were supplied."
            ),
        },
    },
    "required": ["subject", "body", "observation", "findings_used"],
    "additionalProperties": False,
}
def schema_for(style: styles.Style | None = None) -> dict:
    """The reply schema for one approved template.

    A shallow copy per call rather than a mutated shared dict: the schema goes to a
    provider SDK, and a mutable module-level object that different campaigns edit
    in turn is how a brief campaign ends up asking for a consultative body.
    """
    chosen = style or styles.DEFAULT_STYLE
    schema = dict(SCHEMA_TEMPLATE)
    schema["properties"] = {
        key: (dict(value) if key != "body" else
              {**value, "description": chosen.schema_hint})
        for key, value in SCHEMA_TEMPLATE["properties"].items()
    }
    return schema
#: The default schema, rendered. Same reason as `SYSTEM`.
SCHEMA = schema_for()
def build_audit_prompt(*, business_name: str, category: str, city: str,
                       country: str, website: str, site_context: str,
                       pages_read: int, discovered: int) -> str:
    """Assemble the review request for one lead's crawled site."""
    areas = "\n".join(
        f"{index}. {label}\n   " + "\n   ".join(f"- {item}" for item in items)
        for index, (_key, label, items) in enumerate(REVIEW_CATEGORIES, 1)
    )

    return f"""\
Review this business's website and report the strongest genuine issues and \
improvement opportunities.

BUSINESS (from a public map listing):
Name: {business_name}
Category: {category or 'unknown'}
Location: {', '.join(p for p in (city, country) if p) or 'unknown'}
Website: {website}

CRAWL: {pages_read} page(s) were read automatically out of {discovered} \
discovered internal links. Only what appears below was seen -- say nothing \
about anything else, and where something could not be checked say "Could not be \
verified from the available crawl."

TWO QUESTIONS TO ANSWER FIRST, before you look for anything technical:

  "If I were a potential customer visiting this website for the first time, what \
would I need to know before I would trust this company and get in touch?"

  "What on these pages could make that customer leave without contacting the \
business?"

Whatever is missing from the answers is a finding, and it is usually a more \
valuable one than a missing meta description.

AREAS TO COVER (only where the evidence supports a finding):
{areas}

CRAWLED PAGES, TEXT AND MEASURED SIGNALS:
{site_context}

Report the 8-10 strongest findings the evidence supports, strongest first, \
spread across the areas above rather than concentrated in one. Every "evidence" \
field must cite a specific measured signal or quote from above -- including a \
count of zero, which is evidence that something is absent from the pages \
reviewed."""
#: Measured signals worth restating in the email request, and what each one
#: actually means to a business owner. The email must not quote the numbers -- the
#: prompt says so -- but the model writes a better sentence when it knows the
#: measurement behind the finding it is describing, and a wrong-way-round claim
#: ("your fast site is slow") becomes impossible rather than merely forbidden.
#:
#: Kept short on purpose. Every extra signal is another thing the model can be
#: tempted to mention, and these are the ones that carry commercial meaning.
EMAIL_SIGNALS: tuple[tuple[str, str], ...] = (
    ("load_ms", "homepage response time, milliseconds"),
    ("page_kb", "homepage weight, KB"),
    ("viewport_meta", "adapts to phone screens (false means it does not)"),
    ("cta_count", "obvious ways to get in touch, counted on the page"),
    ("forms", "contact or enquiry forms found"),
    ("tel_links", "tappable phone links"),
    ("word_count", "words of visible copy"),
    ("title_length", "page title length, 0 means missing"),
    ("meta_description_length", "search description length, 0 means missing"),
    ("images", "images on the page"),
    ("images_missing_alt", "images with no alt text"),
    ("h1_count", "main headings (0 or several is a problem)"),
    ("https", "served over HTTPS"),
)
def attribute_pages(findings: list, pages: list | None) -> list:
    """Fill in each finding's `page_url` from the pages that were crawled.

    §5 asks for the page a finding was found on. It is derived here rather than
    asked of the model: a required `page_url` field in the audit schema was tried
    and cost a whole run when the model omitted it, and a URL invented to satisfy
    a schema is worse than no URL at all.

    So the evidence text is matched against the pages actually read -- by URL
    first, then by the page's kind ("the contact page has no form"). Nothing
    matches, nothing is filled in. Every URL this produces is one the crawler
    fetched.
    """
    crawled = [
        (str(p.get("url") or ""), str(p.get("kind") or "").lower())
        for p in (pages or []) if isinstance(p, dict) and p.get("url")
    ]
    if not crawled:
        return findings

    home = crawled[0][0]
    for finding in findings:
        if getattr(finding, "page_url", ""):
            continue
        haystack = f"{finding.evidence} {finding.issue}".lower()

        # Longest first: the site root is a prefix of every other page, so a
        # shortest-match search would attribute every finding to the homepage.
        match = next(
            (url for url in sorted((u for u, _k in crawled), key=len, reverse=True)
             if url.lower() in haystack), "")
        if not match:
            match = next(
                (url for url, kind in crawled
                 if kind and kind != "home" and f"{kind} page" in haystack), "")
        if not match and ("home" in haystack or "homepage" in haystack):
            match = home
        finding.page_url = match
    return findings
def build_prompt(*, business_name: str, category: str, city: str, country: str,
                 website: str, sender_name: str, sender_company: str,
                 sender_email: str = "", service_pitch: str = "",
                 findings: list | None = None, business_summary: str = "",
                 site_note: str = "", retry_hint: str = "",
                 pages: list | None = None, signals: dict | None = None,
                 platform_note: str = "") -> str:
    """Assemble the per-lead email request from the review findings.

    The findings arrive here already ranked by commercial importance and already
    trimmed to the two or three the email may use -- see
    `scoring.rank_for_email`. This function's job is to present them as
    *structured evidence* rather than as a sentence: issue, severity, dimension,
    the measured fact behind it, what it costs the business, the fix, and the page
    it was found on.

    That structure is the whole defence against a generic email. A model given
    "review the site at example.com" will write "I noticed some issues with your
    website" because that is all it knows. A model given "the homepage has no
    page title (title_length=0), found at example.com/, which means search
    results show a bare URL" can only write something specific.
    """
    facts = [
        f"Business name: {business_name}",
        f"Category: {category or 'unknown'}",
        f"Location: {', '.join(p for p in (city, country) if p) or 'unknown'}",
        f"Website: {website or 'none published'}",
    ]
    if business_summary:
        facts.append(f"What they do (from their site): {business_summary}")

    findings = list(findings or [])
    if findings:
        findings = attribute_pages(findings, pages)
        findings = validation.assign_ids(findings)
        blocks = []
        for index, finding in enumerate(findings, 1):
            lines = [
                f"{index}. [{finding.finding_id}] {finding.issue}",
                f"   Severity: {finding.severity or 'medium'}"
                + (f"   Area: {finding.dimension}" if finding.dimension else ""),
                f"   Evidence (measured -- do NOT quote in the email): "
                f"{finding.evidence}",
                f"   What it costs them: {finding.why_it_matters}",
            ]
            if finding.suggested_improvement:
                lines.append(f"   Fix: {finding.suggested_improvement}")
            if getattr(finding, "page_url", ""):
                lines.append(f"   Found on: {finding.page_url}")
            blocks.append("\n".join(lines))

        findings_block = (
            "VERIFIED WEBSITE FINDINGS. These come from a crawl of the pages "
            "listed above and are the ONLY website problems that exist as far as "
            "this email is concerned. They are ordered by commercial importance, "
            "most important first. Each carries an id -- list the ids you used in "
            "\"findings_used\", and never write about anything that is not here:"
            "\n\n" + "\n\n".join(blocks)
        )
    else:
        findings_block = (
            f"VERIFIED WEBSITE FINDINGS: none available ({site_note or 'the site could not be reviewed'}). "
            "Do not imply you looked at their website. Write a short, honest "
            "note based only on the business facts above, and set "
            '"observation" to "none" with an empty "findings_used".'
        )

    sections = [f"BUSINESS FACTS:\n{chr(10).join(facts)}"]

    pages_block = _pages_block(pages)
    if pages_block and findings:
        sections.append(pages_block)

    signals_block = _signals_block(signals)
    if signals_block and findings:
        sections.append(signals_block)

    sections.append(findings_block)

    # Only when the crawl measured a problem with the platform. Section 16: not
    # mentioned merely to fill a section, and never to suggest something newer.
    if platform_note and findings:
        sections.append(
            "PLATFORM. Mention this in one or two sentences, plainly, and say why "
            "-- it is here because the crawl measured it:\n" + platform_note)

    sections.append(
        "ABOUT THE SENDER (close the email with these, on their own lines):\n"
        f"Name: {sender_name}\n"
        f"Company: {sender_company or sender_name}\n"
        f"Email: {sender_email or 'omit if blank'}\n"
        f"What they offer: {service_pitch or DEFAULT_OFFER}"
    )

    prompt = ("Write one first-contact email to this business.\n\n"
              + "\n\n".join(sections))
    if retry_hint:
        prompt += f"\n\nREVISION NOTE: {retry_hint}"
    return prompt
def _pages_block(pages: list | None) -> str:
    """Which pages were actually read. §5's "pages analyzed"."""
    rows = [
        f"- {p.get('kind') or 'page'}: {p['url']}"
        for p in (pages or [])
        if isinstance(p, dict) and p.get("url")
    ]
    if not rows:
        return ""
    return (f"PAGES ANALYSED ({len(rows)} crawled -- nothing outside this list "
            "was seen, and the email must never claim otherwise):\n"
            + "\n".join(rows[:12]))
def _signals_block(signals: dict | None) -> str:
    """The measured numbers behind the findings, with what each one means.

    Present so the model describes a real measurement in plain words rather than
    guessing at the shape of the problem. Explicitly labelled as not for
    quoting -- the prompt forbids putting a figure in the email, and a labelled
    number is easier to obey than an unexplained one.
    """
    if not signals:
        return ""
    rows = []
    for key, meaning in EMAIL_SIGNALS:
        if key not in signals:
            continue
        value = signals[key]
        if value in (None, "", []):
            continue
        rows.append(f"- {key} = {value}   ({meaning})")
    if not rows:
        return ""
    return ("MEASURED SIGNALS behind those findings. Context for your wording "
            "only -- translate them into plain business language and NEVER put a "
            "number or a metric name in the email:\n" + "\n".join(rows))
NO_WEBSITE_SYSTEM = """\
You are writing a first email to a small business that has no website.

There is nothing to critique here, so do not try. You have never seen a website \
for this business because there is not one to see, and the whole email is about \
what having one could make easier.

WHAT YOU HAVE: the business name, what kind of business it is, where it is, and a \
short list of things a website could plausibly help with for that kind of \
business. That is all. Work from it and nothing else.

THE RULE THAT OVERRIDES EVERYTHING: never state a fact you were not given.

You do not know their revenue, their customer numbers, how busy they are, how \
many staff they have, whether they are losing business, what their competitors \
do, or how people currently find them. Do not imply that you do. "I noticed \
you're missing out on customers" is an invented fact and a bad email.

NEVER GUARANTEE AN OUTCOME. Not revenue, not sales, not more customers, not \
search rankings, not return on investment. Write in the conditional:
- "could make it easier for people to ..."
- "may help when somebody is looking for ..."
- "would give customers somewhere to ..."
- "can be a straightforward way to ..."

NEVER:
- mention SEO rankings, traffic figures or percentages of any kind,
- claim they are invisible online, or that customers cannot find them,
- say a website is essential, or that they are behind their competitors,
- open with "I noticed you don't have a website" as an accusation. It is a fact, \
not a failing, and plenty of good businesses run without one.

STRUCTURE:
1. The greeting "Hi there," on its own line, then a blank line. Exactly that, and \
never a first name -- you have not been told anybody's name.
2. One line that shows you know what this business actually is and where.
3. One or two of the supplied benefits, in your own words, as possibilities.
4. A single, small, easy next step -- a question they can answer in one line.

LENGTH: 70-110 words of body text. Plain British English, contractions welcome, \
no marketing register, no exclamation marks, no bullet points.

Return only JSON."""
NO_WEBSITE_SCHEMA = {
    "type": "object",
    "properties": {
        "subject": {
            "type": "string",
            "description": (
                "Natural subject line, 4-9 words, naming the business or its "
                "trade. Not a question, and no 'Re:'."
            ),
        },
        "body": {
            "type": "string",
            "description": (
                "The email body as plain text, 70-110 words, paragraphs "
                "separated by blank lines, closing with the sender's name and "
                "company."
            ),
        },
        "observation": {
            "type": "string",
            "description": (
                "The specific thing about this business the email opens on -- "
                "its trade and location. Never a claim about a website."
            ),
        },
        "benefits_used": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Which of the supplied benefits the email drew on.",
        },
    },
    "required": ["subject", "body", "observation", "benefits_used"],
    "additionalProperties": False,
}
def build_no_website_prompt(*, business_name: str, category: str = "",
                            city: str = "", country: str = "",
                            phone: str = "", benefits: list | None = None,
                            sender_name: str = "", sender_company: str = "",
                            sender_email: str = "", service_pitch: str = "",
                            retry_hint: str = "") -> str:
    """Assemble the no-website prompt from listing data only."""
    lines = [
        f"BUSINESS: {business_name}",
        f"WHAT THEY DO: {category or 'not recorded'}",
        f"WHERE: {', '.join(p for p in (city, country) if p) or 'not recorded'}",
    ]
    if phone:
        lines.append("THEY PUBLISH A PHONE NUMBER, so enquiries by phone already "
                     "matter to them.")

    lines += ["",
              "THIS BUSINESS HAS NO VERIFIED WEBSITE. Do not refer to one, and "
              "do not speculate about what it might be like."]

    chosen = [b for b in (benefits or []) if b]
    if chosen:
        lines += ["",
                  "THINGS A WEBSITE COULD PLAUSIBLY HELP WITH FOR THIS KIND OF "
                  "BUSINESS (use one or two, in your own words, as "
                  "possibilities):"]
        for benefit in chosen[:5]:
            lines.append(f"- {benefit}")
    else:
        lines += ["",
                  "NO CATEGORY-SPECIFIC BENEFITS WERE SUPPLIED. Keep to the "
                  "general case: somewhere to send enquiries, and a presence "
                  "that works outside opening hours."]

    lines += [
        "",
        f"WHAT THE SENDER OFFERS: {service_pitch or DEFAULT_OFFER}",
        "",
        "SIGN OFF AS:",
        f"  {sender_name}",
    ]
    if sender_company:
        lines.append(f"  {sender_company}")
    if sender_email:
        lines.append(f"  {sender_email}")
    if retry_hint:
        lines += ["", f"REVISION REQUESTED: {retry_hint}"]

    lines += ["",
              "Write the email. 70-110 words. Nothing about website problems, "
              "and no promises about results."]
    return "\n".join(lines)
FOLLOWUP_SYSTEM = """\
You are writing a short follow-up email to a small business that did not reply \
to an earlier email.

You will be shown the email that was already sent, what was noticed on the \
company's website, and how long ago the first email went out.

THE RULE THAT MATTERS MOST: do not rewrite or restate the first email. The \
recipient may well read the two next to each other. A follow-up that repeats \
the original in new words is worse than no follow-up at all -- it reads as \
automated, and it spends the small amount of goodwill a second email has.

So:
- Begin with the greeting "Hi there," on its own line, then a blank line. \
Exactly that, and never a first name -- you have not been told anybody's name.
- Reference the earlier message briefly and move on. One clause, not a \
paragraph.
- Add something the first email did not say: a different angle on the same \
opportunity, a sharper version of the offer, or a smaller and easier next step.
- Do NOT re-list the website issues. At most allude to the one thing the first \
email was built on, in a handful of words.
- Assume the silence is busyness, not rejection. No guilt, no "I noticed you \
have not responded", no invented deadline, no false urgency.
- Make replying trivial: one small question, or a yes/no ask.

LENGTH: 45-90 words of body text, and always shorter than the original. A \
follow-up that runs long has misunderstood what it is.

TONE: a competent person sending a brief nudge to a peer. Plain British \
English, contractions welcome, no marketing register, no exclamation marks.

NEVER:
- claim anything about the website that is not in the supplied material,
- invent a phone call, a meeting, an earlier conversation or a mutual contact,
- mention how many emails have been sent, or that this is attempt number two,
- write a new subject line: reuse the original, prefixed with "Re: ".

Return only JSON."""
FOLLOWUP_SCHEMA = {
    "type": "object",
    "properties": {
        "subject": {
            "type": "string",
            "description": (
                "The original subject prefixed with 'Re: ', otherwise "
                "unchanged. Do not add 'Re: ' twice."
            ),
        },
        "body": {
            "type": "string",
            "description": (
                "The follow-up body as plain text, 45-90 words, paragraphs "
                "separated by blank lines, closing with the sender name and "
                "company."
            ),
        },
        "angle": {
            "type": "string",
            "description": (
                "In one short phrase, what this follow-up adds that the first "
                "email did not say. Shown to the user to check it is not a "
                "repeat."
            ),
        },
    },
    "required": ["subject", "body", "angle"],
    "additionalProperties": False,
}
#: A follow-up is short by design, so it needs far less room than a first email.
FOLLOWUP_MAX_TOKENS = int(os.environ.get("OUTREACH_AI_FOLLOWUP_TOKENS", "800"))
def reply_subject(subject: str) -> str:
    """A subject with exactly one "Re: " on the front."""
    text = (subject or "").strip()
    while text[:3].casefold() == "re:":
        text = text[3:].strip()
    return f"Re: {text}" if text else "Re: following up"
def _conversation_block(conversation: list | None) -> str:
    """The thread so far, for the follow-up prompt.

    Everything already said, oldest first, with who said it. Section 12: a
    follow-up written without this repeats the first email, because the model has
    no way to know one was already sent.

    Bodies go in whole. They are the context, and a truncated one is how a
    follow-up ends up referring to something that was cut off.
    """
    rows = [row for row in (conversation or []) if row.get("body")]
    if not rows:
        return ""

    parts = []
    for row in rows:
        who = "YOU WROTE" if row.get("role") == "sent" else "THEY REPLIED"
        when = f" on {str(row.get('when'))[:10]}" if row.get("when") else ""
        stage = row.get("stage") or ""
        subject = f"\nSubject: {row['subject']}" if row.get("subject") else ""
        parts.append(f"--- {who} ({stage}){when} ---{subject}\n{row['body']}")

    return (
        "THE CONVERSATION SO FAR. This is everything already said to this "
        "business. Read it before writing: the follow-up has to continue the "
        "conversation rather than restart it, and repeating a point you have "
        "already made is the failure this is here to prevent.\n\n"
        + "\n\n".join(parts)
    )
def build_followup_prompt(*, business_name: str, category: str = "",
                          city: str = "", country: str = "", website: str = "",
                          sender_name: str = "", sender_company: str = "",
                          sender_email: str = "", service_pitch: str = "",
                          original_subject: str = "", original_body: str = "",
                          observation: str = "", findings: list | None = None,
                          business_summary: str = "", days_since: int = 0,
                          number: int = 1, campaign_label: str = "",
                          conversation: list | None = None,
                          retry_hint: str = "") -> str:
    """Assemble the follow-up prompt from the thread so far.

    `conversation` is preferred over `original_body` when it is available: it
    contains the original email *and* everything since, so including both would put
    the same text in the prompt twice.
    """
    lines = [
        f"BUSINESS: {business_name}",
        f"CATEGORY: {category or 'unknown'}",
        f"LOCATION: {', '.join(p for p in (city, country) if p) or 'unknown'}",
        f"WEBSITE: {website or 'none'}",
    ]
    if campaign_label:
        lines.append(f"CAMPAIGN: {campaign_label}")
    if business_summary:
        lines.append(f"WHAT THEY DO: {business_summary}")

    lines += [
        "",
        f"THIS IS FOLLOW-UP NUMBER {number}.",
        f"THE LAST EMAIL WENT OUT {days_since} DAY(S) AGO AND HAD NO REPLY.",
    ]

    thread = _conversation_block(conversation)
    if thread:
        # The whole thread, which already contains the original email. Section 12.
        lines += ["", thread]
    else:
        # One email and nothing since -- the case before conversations were
        # recorded, and the case for a lead whose draft has been deleted.
        lines += [
            "",
            "--- THE EMAIL ALREADY SENT (do not restate it) ---",
            f"Subject: {original_subject}",
            "",
            (original_body or "").strip(),
            "--- END OF THE EMAIL ALREADY SENT ---",
        ]

    if observation and observation.casefold() != "none":
        lines += ["", f"WHAT THE FIRST EMAIL WAS BUILT ON: {observation}"]

    spare = [f for f in (findings or []) if getattr(f, "issue", "")]
    if spare:
        lines += ["",
                  "OTHER VERIFIED FINDINGS, IF A DIFFERENT ANGLE HELPS "
                  "(use at most one, in a few words):"]
        for finding in spare[:4]:
            lines.append(f"- {finding.issue} -- {finding.evidence}")
    else:
        lines += ["",
                  "NO WEBSITE FINDINGS ARE AVAILABLE. Do not imply the website "
                  "was examined; follow up on the offer alone."]

    lines += [
        "",
        f"WHAT THE SENDER OFFERS: {service_pitch or DEFAULT_OFFER}",
        "",
        "SIGN OFF AS:",
        f"  {sender_name}",
    ]
    if sender_company:
        lines.append(f"  {sender_company}")
    if sender_email:
        lines.append(f"  {sender_email}")
    if retry_hint:
        lines += ["", f"REVISION REQUESTED: {retry_hint}"]

    lines += ["",
              "Write the follow-up. Under 90 words. Continue the conversation: "
              "reference what you already said in a few words, give one honest "
              "reason you are writing again, and ask once. Do not restate the "
              "first email, and do not repeat a point an earlier follow-up "
              "already made."]
    return "\n".join(lines)
