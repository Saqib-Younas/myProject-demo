"""
The one place AI provider credentials come from.

Every backend asks this module; none of them reads an environment variable of its
own any more. That is the whole point -- credential resolution scattered across
five files is how a provider ends up quietly using another provider's key, or
keeps working from `.env` after the user thought they had changed it in Settings.

Providers are parents; credentials are children. One account may hold four
OpenAI keys, and exactly one of them is *active* -- that is the one every AI
feature uses, and switching it needs no code change anywhere.

Resolution order, per provider, for one account:

  1. **The active child credential** saved through Settings, encrypted at rest.
  2. **Environment** -- the `.env` variables the project already supported.
  3. **A CLI profile**, for Anthropic only, where `ant auth login` leaves a
     token the SDK finds on its own.
  4. Not configured.

An active child therefore overrides `.env`, and deactivating or deleting it falls
straight back to `.env` with no further action. An existing deployment that only
ever used `.env` behaves exactly as it did before.

Whose credentials apply comes from `apps.ai.context`, set per request by
middleware and per background job by the runner. **With no account in context the
resolver uses environment credentials only** -- it never reaches for "whichever
database credential exists", so a call from an unset context cannot borrow an
account's keys.

Secrets handling, in one place so it can be audited in one place:

  * stored encrypted with Fernet, under a key derived from DJANGO_SECRET_KEY;
  * `status()` is the only thing the UI ever sees, and it carries a masked hint
    (last four characters) rather than the key;
  * the plaintext leaves this module only through `resolve()`, which is called
    exclusively by server-side backend code;
  * nothing here logs, formats or raises a message containing a key.

Rotating DJANGO_SECRET_KEY makes stored credentials undecryptable. That is
treated as "the database credential is unusable, fall back to the environment"
and reported plainly, rather than crashing a campaign mid-run.
"""

from __future__ import annotations

import hashlib
import logging
import os
from dataclasses import dataclass, field

from django.db import transaction
from django.utils import timezone

from apps.core import secrets as core_secrets

log = logging.getLogger(__name__)

#: Sources, in priority order. Also the vocabulary the UI shows.
DATABASE = "database"
ENVIRONMENT = "environment"
CLI_PROFILE = "cli_profile"
NONE = ""

SOURCE_LABELS = {
    DATABASE: "Database",
    ENVIRONMENT: "Environment",
    CLI_PROFILE: "CLI login",
    NONE: "Not configured",
}

#: The exact message the brief asks for when a selected provider has no key.
NOT_CONFIGURED_TEMPLATE = (
    "{label} is not configured. Please add {label} credentials in Settings."
)


@dataclass(frozen=True)
class Spec:
    """What one provider needs, and where its key can come from."""

    name: str
    label: str
    #: Environment variables this project already honoured, in priority order.
    #: The first one present wins, matching the previous per-backend behaviour.
    env_vars: tuple[str, ...]
    module: str                  # backend module path
    package: str                 # pip package the backend needs
    default_model: str
    console_url: str
    #: What `import` actually takes, where it differs from the pip name. Stated
    #: rather than derived: guessing it from the package name needs a special
    #: case per provider, which is the kind of thing that breaks silently when a
    #: sixth provider is added.
    import_name: str = ""
    key_prefix: str = ""         # what a valid key usually starts with
    #: Optional extra settings the UI offers, stored beside the key. Never
    #: secret: a base URL is configuration, not a credential.
    extras: tuple[tuple[str, str, str], ...] = ()
    #: Anthropic can authenticate from an `ant auth login` profile with no key.
    allows_cli_login: bool = False
    #: Provider-specific wording for the two cases where generic advice is
    #: actively unhelpful. `{name}` is the environment variable involved.
    #: Centralising resolution must not cost the diagnostics the per-backend
    #: code used to give -- an empty ANTHROPIC_API_KEY shadowing a good CLI
    #: profile is a real trap, and "no credentials found" does not explain it.
    empty_key_advice: str = ""
    missing_advice: str = ""


#: Every provider the application can talk to. Adding one here plus a backend
#: module is the whole job -- the Settings UI, the resolver, the selector and the
#: status endpoints are all driven off this table.
SPECS: dict[str, Spec] = {
    "claude": Spec(
        name="claude", label="Claude (Anthropic)",
        env_vars=("ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN"),
        module="apps.ai.backends.claude", package="anthropic",
        default_model="claude-opus-5",
        console_url="https://console.anthropic.com/settings/keys",
        key_prefix="sk-ant-", allows_cli_login=True,
        empty_key_advice=(
            "An empty {name} still takes priority over an `ant auth login` "
            "profile and authenticates with nothing. Remove it "
            "(`Remove-Item Env:\\{name}`) and try again, or save a key in "
            "Settings."
        ),
        missing_advice=(
            "Run `ant auth login` to sign in through the browser, set "
            "ANTHROPIC_API_KEY in .env, or save a key in Settings."
        ),
    ),
    "gemini": Spec(
        name="gemini", label="Gemini (Google)",
        env_vars=("GEMINI_API_KEY", "GOOGLE_API_KEY"),
        module="apps.ai.backends.gemini", package="google-genai",
        import_name="google.genai",
        default_model="gemini-3.7-flash",
        console_url="https://aistudio.google.com/apikey",
    ),
    "openai": Spec(
        name="openai", label="OpenAI",
        env_vars=("OPENAI_API_KEY",),
        module="apps.ai.backends.openai", package="openai",
        default_model="gpt-4.1-mini",
        console_url="https://platform.openai.com/api-keys",
        key_prefix="sk-",
        extras=(
            ("base_url", "Base URL",
             "Optional. For an Azure or proxy endpoint. Leave blank for OpenAI."),
            ("organization", "Organization ID",
             "Optional. Only needed on accounts with several organisations."),
        ),
    ),
    "openrouter": Spec(
        name="openrouter", label="OpenRouter",
        env_vars=("OPENROUTER_API_KEY",),
        module="apps.ai.backends.openrouter", package="openai",
        default_model="openai/gpt-4.1-mini",
        console_url="https://openrouter.ai/keys",
        key_prefix="sk-or-",
        extras=(
            ("base_url", "Base URL",
             "Optional. Defaults to https://openrouter.ai/api/v1."),
        ),
    ),
    "groq": Spec(
        name="groq", label="Groq",
        env_vars=("GROQ_API_KEY",),
        module="apps.ai.backends.groq", package="groq",
        default_model="openai/gpt-oss-120b",
        console_url="https://console.groq.com/keys",
        key_prefix="gsk_",
    ),
}

#: Kept for the message shown when an unknown provider name turns up.
PROVIDER_NAMES = tuple(SPECS)

DEFAULT_PROVIDER = "claude"


def spec(provider: str) -> Spec:
    """The spec for one provider. Raises KeyError for an unknown name."""
    return SPECS[(provider or "").strip().lower()]


def known(provider: str) -> bool:
    return (provider or "").strip().lower() in SPECS


# --------------------------------------------------------------------------- #
# Encryption at rest
# --------------------------------------------------------------------------- #

class CredentialError(RuntimeError):
    """A credential could not be stored or read. Never contains a key."""


# --------------------------------------------------------------------------- #
# Encryption
# --------------------------------------------------------------------------- #
#
# The mechanism is in `apps/core/secrets.py`, because three things in this project
# store a secret -- provider keys, mailbox passwords, and the Supabase service-role
# key -- and they must not each have their own idea of how. What stays here is the
# exception type: `CredentialError` is caught by name in the AI views, in
# `mail/accounts.py` and in the tests, so the core error is converted rather than
# allowed to escape under a different name.

def encrypt(value: str) -> str:
    """Encrypt one credential for storage. Returns url-safe base64 text."""
    try:
        return core_secrets.encrypt(value)
    except core_secrets.SecretError as exc:
        raise CredentialError(str(exc)) from exc


def decrypt(token: str) -> str:
    """Decrypt a stored credential, or "" if it cannot be read.

    An unreadable value is almost always a rotated DJANGO_SECRET_KEY. Returning
    "" lets the caller fall back to the environment instead of failing a run.
    """
    try:
        return core_secrets.decrypt(token)
    except core_secrets.SecretError as exc:
        raise CredentialError(str(exc)) from exc


def mask(value: str) -> str:
    """A safe hint: shape and last four characters, never the key.

    `sk-ant-api03-abc...WXYZ` becomes `sk-ant-••••••••WXYZ`. Short values are
    masked entirely rather than half-revealed.
    """
    return core_secrets.mask(value)


# --------------------------------------------------------------------------- #
# Resolution
# --------------------------------------------------------------------------- #

@dataclass(frozen=True)
class Credential:
    """One provider's resolved credential. `key` never leaves the server."""

    provider: str
    source: str = NONE
    key: str = ""
    #: Which environment variable, or the child's label, for status text. Never
    #: contains a key.
    detail: str = ""
    advice: str = ""
    extras: dict = field(default_factory=dict)
    model: str = ""
    #: Which child credential this came from, when it came from one. The usage
    #: stamps and the error record are written against this row.
    credential_id: int | None = None
    label: str = ""

    @property
    def usable(self) -> bool:
        """Is there something to authenticate with?

        A CLI profile has no key here and is still usable -- the SDK resolves it
        itself, which is why `ant auth login` works with no variable set.
        """
        return bool(self.key) or self.source == CLI_PROFILE

    @property
    def source_label(self) -> str:
        return SOURCE_LABELS.get(self.source, SOURCE_LABELS[NONE])

    @property
    def fingerprint(self) -> str:
        """A stable, non-reversible id for cache invalidation.

        Backends cache their SDK client; when a key changes the cached client
        must be rebuilt. Comparing fingerprints does that without holding the
        key anywhere else.
        """
        material = f"{self.provider}|{self.source}|{self.key}".encode()
        return hashlib.sha256(material).hexdigest()[:16]


def _from_environment(provider_spec: Spec) -> Credential | None:
    """The `.env` path, preserving the exact behaviour it had before.

    An empty-but-present variable is still reported, because that is the trap it
    always was: it occupies the slot and the SDK treats it as missing.
    """
    for name in provider_spec.env_vars:
        if name not in os.environ:
            continue
        if os.environ[name].strip():
            return Credential(
                provider=provider_spec.name, source=ENVIRONMENT,
                key=os.environ[name].strip(),
                detail=f"{name} environment variable",
            )
        advice = (provider_spec.empty_key_advice
                  or "{name} is present but blank, which the SDK treats as a "
                     "missing key. Remove it, give it a value, or save a key "
                     "in Settings.").format(name=name)
        return Credential(
            provider=provider_spec.name, source=NONE, key="",
            detail=f"{name} is set but empty", advice=advice,
        )
    return None


def _cli_profile(provider_spec: Spec) -> Credential | None:
    """Anthropic only: a token left by `ant auth login`.

    Returns an unusable Credential -- rather than None -- when ANTHROPIC_PROFILE
    names a profile that does not exist. That is a configuration mistake with a
    specific fix, and reporting it beats "no credentials found".
    """
    if not provider_spec.allows_cli_login:
        return None
    try:
        from .backends import claude
        found, detail = claude.find_cli_profile()
    except Exception:   # noqa: BLE001 - a missing SDK must not break resolution
        return None
    if found:
        return Credential(provider=provider_spec.name, source=CLI_PROFILE,
                          key="", detail=detail)
    if "does not exist" in detail:
        # `detail` carries the profiles that do exist; repeating it in the advice
        # is what makes the message actionable rather than merely correct.
        return Credential(
            provider=provider_spec.name, source=NONE, key="", detail=detail,
            advice=(f"{detail}. Run `ant auth login --profile <name>` for that "
                    "profile, clear ANTHROPIC_PROFILE, or save a key in "
                    "Settings."),
        )
    return None


def resolve(provider: str, owner=None, *, credential=None) -> Credential:
    """The resolved credential for one provider. Server-side callers only.

    Active child first, then environment, then a CLI profile, then nothing.
    `credential` forces a specific child, which is how the fallback path and the
    per-credential connection test use one that is not active.
    """
    try:
        provider_spec = spec(provider)
    except KeyError:
        return Credential(
            provider=(provider or "").strip().lower(), source=NONE,
            detail=f"unknown provider {provider!r}",
            advice=("Choose one of: " + ", ".join(sorted(SPECS)) + "."),
        )

    if credential is None:
        # A forced credential from the context: the connection test and the
        # fallback path both need a specific child rather than the active one.
        from apps.ai import context as aicontext

        forced = aicontext.get_forced_credential()
        if forced is not None and forced.provider == provider_spec.name:
            credential = forced

    row = credential if credential is not None else _stored(provider_spec.name,
                                                            owner)
    if row is not None:
        key = decrypt(row.secret)
        if key:
            return Credential(
                provider=provider_spec.name, source=DATABASE, key=key,
                detail=f"credential {row.label!r}",
                extras=dict(row.extras or {}), model=row.model or "",
                credential_id=row.pk, label=row.label,
            )
        # Saved but unreadable -- a rotated SECRET_KEY. Say so, and fall through
        # to the environment rather than failing.
        fallback = _from_environment(provider_spec) or Credential(
            provider=provider_spec.name)
        return Credential(
            provider=provider_spec.name,
            source=fallback.source, key=fallback.key,
            detail=fallback.detail or f"credential {row.label!r} unreadable",
            advice=(f"The credential {row.label!r} cannot be decrypted, which "
                    "happens when DJANGO_SECRET_KEY changes. Add it again to "
                    "replace it."),
            extras=dict(row.extras or {}), model=row.model or "",
            credential_id=row.pk, label=row.label,
        )

    # A present environment variable decides, empty included: an empty one still
    # occupies the SDK's credential slot and authenticates with nothing, so
    # falling through to a CLI profile here would report a working profile that
    # the SDK will never actually reach.
    from_env = _from_environment(provider_spec)
    if from_env is not None:
        return from_env

    profile = _cli_profile(provider_spec)
    if profile is not None:
        return profile          # usable, or a named profile that is missing

    return Credential(
        provider=provider_spec.name, source=NONE,
        detail="no credentials found",
        advice=provider_spec.missing_advice or (
            f"Save a key in Settings, or set {provider_spec.env_vars[0]}=... "
            f"in .env. Keys are created at {provider_spec.console_url}."),
    )


def current_owner():
    """The account whose credentials apply right now, or None."""
    from apps.ai import context as aicontext

    return aicontext.get_owner()


def children(provider: str, owner=None):
    """Every child credential for one provider, active first.

    Empty when there is no account in context: a caller with no owner must not
    be shown, or handed, anybody's keys.
    """
    from .models import ProviderCredential

    owner = owner if owner is not None else current_owner()
    if owner is None or not getattr(owner, "pk", None):
        return ProviderCredential.objects.none()
    try:
        return ProviderCredential.objects.filter(
            owner=owner, provider=(provider or "").strip().lower())
    except Exception:   # noqa: BLE001 - an unmigrated database must still run
        log.warning("could not read credentials for %s", provider)
        return ProviderCredential.objects.none()


def _stored(provider: str, owner=None):
    """The *active* child credential for one provider, or None."""
    return children(provider, owner).filter(is_active=True).first()


def fallbacks(provider: str, owner=None) -> list:
    """Inactive children the user has marked usable as a fallback.

    Opt-in per credential rather than a provider-wide switch: "this spare key may
    be used when the main one is rate limited" is a decision about that spare key,
    and a user may well want one backup in play and another kept for testing.
    """
    return list(children(provider, owner)
                .filter(is_active=False, allow_fallback=True)
                .order_by("label"))


def require(provider: str, owner=None, *, credential=None) -> Credential:
    """Resolve, or raise the message the UI is specified to show."""
    from apps.ai.base import AiError

    credential = resolve(provider, owner, credential=credential)
    if credential.usable:
        return credential

    label = SPECS[provider].label if known(provider) else provider
    message = NOT_CONFIGURED_TEMPLATE.format(label=label)
    if credential.detail:
        message = f"{message} ({credential.detail})"
    if credential.advice:
        message = f"{message} {credential.advice}"
    raise AiError(message)


def invalidate(provider: str) -> None:
    """Drop a backend's cached SDK client for one provider.

    The backends hold one client and rebuild it when the resolved credential's
    fingerprint changes, so this is belt and braces rather than the mechanism --
    but the fingerprint is only consulted on the next request, and activating a
    credential should take effect before anybody looks. Cheap, and it makes the
    "activate the backup and everything uses it" promise immediate rather than
    eventually true.

    Silent when the backend package is not installed: invalidating a client that
    could never have been built is a no-op, not an error.
    """
    if not known(provider):
        return
    try:
        module = __import__(SPECS[provider].module, fromlist=["reset_client"])
    except Exception:   # noqa: BLE001 - a missing SDK is not a failure here
        return
    reset = getattr(module, "reset_client", None)
    if callable(reset):
        try:
            reset()
        except Exception:   # noqa: BLE001 - never fail a save over a cache
            log.warning("could not reset the %s client", provider)


# --------------------------------------------------------------------------- #
# Status, for the UI. Never carries a key.
# --------------------------------------------------------------------------- #

def child_status(row) -> dict:
    """Everything the UI may know about one child credential.

    The masked hint, the label, the counters and the timestamps -- and no key.
    This is the only shape a browser ever receives.
    """
    return {
        "id": row.pk,
        "provider": row.provider,
        "label": row.label,
        "description": row.description,
        "masked": row.hint or "",
        "is_active": row.is_active,
        "allow_fallback": row.allow_fallback,
        "status": row.status,
        "status_label": row.status_label,
        "model": row.model or "",
        "extras": dict(row.extras or {}),
        "created_at": row.created_at.isoformat() if row.created_at else None,
        # Null becomes "Unknown" in the template rather than a zero date: an
        # invented timestamp is worse than an absent one.
        "last_used_at": row.last_used_at.isoformat() if row.last_used_at else None,
        "last_success_at": (row.last_success_at.isoformat()
                            if row.last_success_at else None),
        "last_error_at": (row.last_error_at.isoformat()
                          if row.last_error_at else None),
        "last_error_category": row.last_error_category,
        "last_error_detail": row.last_error_detail,
        "request_count": row.request_count,
        "error_count": row.error_count,
        "last_test_result": row.last_test_result,
        "last_tested_at": (row.last_tested_at.isoformat()
                           if row.last_tested_at else None),
    }


def status(provider: str, owner=None) -> dict:
    """One provider (the parent) and its credentials (the children)."""
    provider_spec = spec(provider)
    owner = owner if owner is not None else current_owner()
    resolved = resolve(provider_spec.name, owner)
    rows = list(children(provider_spec.name, owner)
                .order_by("-is_active", "label"))
    active = next((r for r in rows if r.is_active), None)

    installed = True
    try:
        __import__(provider_spec.import_name or provider_spec.package)
    except ImportError:
        installed = False

    return {
        "name": provider_spec.name,
        "label": provider_spec.label,
        "configured": resolved.usable,
        "source": resolved.source,
        "source_label": resolved.source_label,
        "detail": resolved.detail,
        "advice": resolved.advice,
        # The active child's mask where there is one, otherwise the mask of
        # whatever the environment supplied. Never a key either way.
        "masked": (active.hint if active is not None and active.hint
                   else mask(resolved.key)),
        "credentials": [child_status(row) for row in rows],
        "credential_count": len(rows),
        "active_label": active.label if active is not None else "",
        "active_id": active.pk if active is not None else None,
        "has_active": active is not None,
        "fallback_count": sum(1 for r in rows
                              if r.allow_fallback and not r.is_active),
        "has_database_row": bool(rows),
        "env_vars": list(provider_spec.env_vars),
        "env_present": any(name in os.environ and os.environ[name].strip()
                           for name in provider_spec.env_vars),
        "default_model": provider_spec.default_model,
        "key_prefix": provider_spec.key_prefix,
        "model": resolved.model or "",
        "console_url": provider_spec.console_url,
        "package": provider_spec.package,
        "sdk_installed": installed,
        "allows_cli_login": provider_spec.allows_cli_login,
        "extras": [
            {"key": key, "label": label, "hint": hint}
            for key, label, hint in provider_spec.extras
        ],
    }


def all_statuses(owner=None) -> list[dict]:
    owner = owner if owner is not None else current_owner()
    return [status(name, owner) for name in SPECS]


# --------------------------------------------------------------------------- #
# Writing
# --------------------------------------------------------------------------- #

class CredentialConflict(CredentialError):
    """A label that is already taken, or a state change that cannot apply."""


def add(owner, provider: str, key: str, *, label: str = "",
        description: str = "", extras: dict | None = None, model: str = "",
        activate: bool | None = None,
        allow_fallback: bool = False):
    """Add one child credential. Returns the row.

    `activate=None` means "activate it if this provider has no active credential
    yet, otherwise leave the current one alone" -- adding a spare key should not
    silently redirect every request onto it.
    """
    from .models import CredentialEvent, ProviderCredential

    provider_spec = spec(provider)
    if owner is None or not getattr(owner, "pk", None):
        raise CredentialError("Credentials belong to an account. Sign in first.")

    key = (key or "").strip()
    if not key:
        raise CredentialError("Enter an API key.")

    label = (label or "").strip() or _default_label(owner, provider_spec.name)
    if children(provider_spec.name, owner).filter(label__iexact=label).exists():
        raise CredentialConflict(
            f"You already have a {provider_spec.label} credential called "
            f"{label!r}. Pick a different name."
        )

    secret = encrypt(key)          # raises before anything is written
    allowed = {name for name, _label, _hint in provider_spec.extras}
    clean_extras = {
        name: str(value).strip()
        for name, value in (extras or {}).items()
        if name in allowed and str(value).strip()
    }

    with transaction.atomic():
        has_active = children(provider_spec.name, owner).filter(
            is_active=True).exists()
        make_active = (not has_active) if activate is None else bool(activate)
        if make_active and has_active:
            # One active child per provider is a database constraint, so the
            # previous one has to stand down inside the same transaction.
            children(provider_spec.name, owner).filter(is_active=True).update(
                is_active=False)

        row = ProviderCredential.objects.create(
            owner=owner, provider=provider_spec.name, label=label,
            description=(description or "")[:300], secret=secret,
            hint=mask(key), extras=clean_extras,
            model=(model or "").strip()[:120], is_active=make_active,
            allow_fallback=bool(allow_fallback),
        )
        CredentialEvent.objects.create(
            owner=owner, credential=row, provider=row.provider,
            label=row.label, kind=CredentialEvent.Kind.CREATED,
            detail="Added" + (" and activated." if make_active else "."),
        )

    invalidate(provider_spec.name)
    return row


def _default_label(owner, provider: str) -> str:
    """"Credential 1", "Credential 2", ... for a user who did not name it."""
    used = set(children(provider, owner).values_list("label", flat=True))
    for number in range(1, 200):
        candidate = f"Credential {number}"
        if candidate not in used:
            return candidate
    return "Credential"


def activate(owner, row) -> dict:
    """Make one child the active credential for its provider.

    The swap happens in one transaction against the unique constraint, so two
    tabs both pressing Activate cannot leave a provider with two active keys --
    the second one fails rather than corrupting the state.
    """
    from .models import CredentialEvent

    if row.owner_id != getattr(owner, "pk", None):
        raise CredentialError("That credential belongs to another account.")

    with transaction.atomic():
        previous = (children(row.provider, owner)
                    .filter(is_active=True).exclude(pk=row.pk).first())
        if previous is not None:
            children(row.provider, owner).filter(pk=previous.pk).update(
                is_active=False)
            CredentialEvent.objects.create(
                owner=owner, credential=previous, provider=previous.provider,
                label=previous.label, kind=CredentialEvent.Kind.DEACTIVATED,
                detail=f"Replaced by {row.label!r}.",
            )

        children(row.provider, owner).filter(pk=row.pk).update(is_active=True)
        CredentialEvent.objects.create(
            owner=owner, credential=row, provider=row.provider, label=row.label,
            kind=CredentialEvent.Kind.ACTIVATED,
            detail=(f"Replacing {previous.label!r}." if previous is not None
                    else "First active credential for this provider."),
        )

    invalidate(row.provider)
    return status(row.provider, owner)


def deactivate(owner, row) -> dict:
    """Stand one child down, leaving the provider with no active credential.

    Nothing is promoted in its place. Quietly redirecting every request onto a
    key the user did not choose is exactly the surprise this whole feature exists
    to avoid, so the provider reads "No active credential" and falls back to the
    environment if one is set there.
    """
    from .models import CredentialEvent

    if row.owner_id != getattr(owner, "pk", None):
        raise CredentialError("That credential belongs to another account.")

    with transaction.atomic():
        children(row.provider, owner).filter(pk=row.pk).update(is_active=False)
        CredentialEvent.objects.create(
            owner=owner, credential=row, provider=row.provider, label=row.label,
            kind=CredentialEvent.Kind.DEACTIVATED,
            detail="Deactivated by hand. No credential promoted in its place.",
        )

    invalidate(row.provider)
    return status(row.provider, owner)


def remove(owner, row) -> dict:
    """Delete one child credential.

    Deleting the active one leaves the provider without an active credential
    rather than promoting a sibling. The caller is expected to have warned the
    user; see `deactivate` for why nothing is auto-promoted.
    """
    from .models import CredentialEvent

    if row.owner_id != getattr(owner, "pk", None):
        raise CredentialError("That credential belongs to another account.")

    provider = row.provider
    label = row.label
    was_active = row.is_active

    with transaction.atomic():
        # The event outlives the row: `credential` is SET_NULL, and the provider
        # and label are snapshots, so the trail still reads afterwards.
        CredentialEvent.objects.create(
            owner=owner, credential=None, provider=provider, label=label,
            kind=CredentialEvent.Kind.DELETED,
            detail=("Deleted while active -- this provider now has no active "
                    "credential." if was_active else "Deleted."),
        )
        row.delete()

    invalidate(provider)
    return status(provider, owner)


def set_fallback(owner, row, enabled: bool) -> dict:
    """Mark whether this child may be tried when the active one is rate limited."""
    if row.owner_id != getattr(owner, "pk", None):
        raise CredentialError("That credential belongs to another account.")

    children(row.provider, owner).filter(pk=row.pk).update(
        allow_fallback=bool(enabled))
    return status(row.provider, owner)


# --------------------------------------------------------------------------- #
# Usage and failures
#
# Recorded against the child that was used, so two questions have answers: which
# key served that request, and why did it fail. Neither record contains a key or
# a provider response body -- a category and a label are enough to act on, and a
# body can quote the request that carried the key.
# --------------------------------------------------------------------------- #

def record_use(credential_id: int | None, *, success: bool = True,
               category: str = "", detail: str = "") -> None:
    """Stamp one request against the credential that served it."""
    from django.db.models import F

    from .models import CredentialEvent, ProviderCredential

    if not credential_id:
        return          # an environment or CLI credential has no row to stamp

    now = timezone.now()
    fields = {"last_used_at": now, "request_count": F("request_count") + 1}
    if success:
        fields["last_success_at"] = now
        fields["last_error_category"] = ""
        fields["last_error_detail"] = ""
    else:
        fields["last_error_at"] = now
        fields["error_count"] = F("error_count") + 1
        fields["last_error_category"] = (category or "error")[:32]
        fields["last_error_detail"] = _safe_detail(detail)

    try:
        ProviderCredential.objects.filter(pk=credential_id).update(**fields)
        row = ProviderCredential.objects.filter(pk=credential_id).first()
        if row is not None:
            CredentialEvent.objects.create(
                owner_id=row.owner_id, credential=row, provider=row.provider,
                label=row.label,
                kind=(CredentialEvent.Kind.USED if success
                      else CredentialEvent.Kind.ERROR),
                category=(category or ("ok" if success else "error"))[:32],
                detail=_safe_detail(detail),
            )
    except Exception:   # noqa: BLE001 - bookkeeping must never fail a request
        log.warning("could not record credential usage")


#: Words that mean a message is quoting something it should not. A provider error
#: can echo the request, and the request carried the key.
_SECRET_MARKERS = ("sk-", "gsk_", "aiza", "bearer ", "api_key", "apikey",
                   "authorization")


def _safe_detail(detail: str, limit: int = 300) -> str:
    """A diagnostic line with anything key-shaped removed.

    Belt and braces: callers are supposed to pass a category and a short phrase,
    not a provider body. This makes a mistake harmless rather than a leak.
    """
    text = " ".join((detail or "").split())
    lowered = text.lower()
    if any(marker in lowered for marker in _SECRET_MARKERS):
        return "(withheld: the provider message may quote the request)"
    return text[:limit]


def categorise(error: Exception) -> tuple[str, str]:
    """(category, safe phrase) for an AI failure.

    The category is what gets stored and shown. The provider's own text is never
    stored, because it can contain the request -- only one of a fixed set of
    phrases written here.
    """
    name = type(error).__name__.lower()
    text = str(error).lower()

    if "authentication" in name or "rejected the api key" in text or (
            "unauthor" in text or "invalid api key" in text):
        return "invalid", "The provider rejected this key."
    if "ratelimit" in name or "rate limit" in text or "quota" in text:
        return "rate_limited", "The provider is rate limiting this key."
    if "permissiondenied" in name or "forbidden" in text:
        return "forbidden", "This key does not have access to that model."
    if "notfound" in name or "does not recognise the model" in text:
        return "model", "The model name was not recognised."
    if "connection" in name or "could not reach" in text:
        return "unavailable", "The provider could not be reached."
    if "not configured" in text:
        return "missing", "No credential is configured for this provider."
    if "5" in text and "api error" in text:
        return "unavailable", "The provider returned a server error."
    return "error", "The request failed."


def record_test(provider: str, result: str, credential_id: int | None = None,
                owner=None) -> None:
    """Remember the outcome of a Test Connection, for the card."""
    from .models import CredentialEvent, ProviderCredential

    category, _phrase = (result.split(":", 1)[0].strip(), "")
    if credential_id:
        ProviderCredential.objects.filter(pk=credential_id).update(
            last_test_result=_safe_detail(result, 120),
            last_tested_at=timezone.now())
        row = ProviderCredential.objects.filter(pk=credential_id).first()
        if row is not None:
            CredentialEvent.objects.create(
                owner_id=row.owner_id, credential=row, provider=row.provider,
                label=row.label, kind=CredentialEvent.Kind.TESTED,
                category=category[:32], detail=_safe_detail(result))
        return

    for row in children(provider, owner).filter(is_active=True):
        record_test(provider, result, row.pk, owner)


def record_fallback(*, owner, provider: str, from_label: str, to_row,
                    reason: str, result: str) -> None:
    """Record that a request used a credential other than the active one.

    §11's requirement, and the reason automatic rotation is safe to offer at all:
    the active credential never changes, and every use of a spare is written down
    with why it happened and whether it worked.
    """
    from .models import CredentialEvent

    try:
        CredentialEvent.objects.create(
            owner=owner, credential=to_row, provider=provider,
            label=to_row.label, kind=CredentialEvent.Kind.FALLBACK,
            category=_safe_detail(reason, 32),
            detail=_safe_detail(
                f"Active credential {from_label!r} failed ({reason}); tried "
                f"{to_row.label!r} instead: {result}."),
        )
    except Exception:   # noqa: BLE001 - bookkeeping must never fail a request
        log.warning("could not record a credential fallback")


def events(owner, provider: str = "", limit: int = 40) -> list:
    """The recent audit trail for one account. Never contains a key."""
    from .models import CredentialEvent

    if owner is None or not getattr(owner, "pk", None):
        return []
    rows = CredentialEvent.objects.filter(owner=owner)
    if provider:
        rows = rows.filter(provider=provider)
    return list(rows[:limit])


# --------------------------------------------------------------------------- #
# Which provider is selected
# --------------------------------------------------------------------------- #

def selection(owner=None) -> tuple[str, str]:
    """(provider, model) chosen by this account, falling back to the environment.

    Same shape of priority as credentials: a choice made in Settings wins, then
    OUTREACH_AI_PROVIDER / OUTREACH_AI_MODEL, then the built-in default. An
    existing `.env`-only deployment is unaffected.
    """
    from .models import AiSelection

    owner = owner if owner is not None else current_owner()
    provider = ""
    model = ""
    try:
        if owner is not None and getattr(owner, "pk", None):
            row = AiSelection.objects.filter(owner=owner).first()
            if row is not None:
                provider = (row.provider or "").strip().lower()
                model = (row.model or "").strip()
    except Exception:   # noqa: BLE001 - unmigrated database
        pass

    if not known(provider):
        # An unrecognised name is passed through rather than corrected, so
        # `ai.load()` can say which name was wrong. Silently falling back to the
        # default would run a whole campaign on a provider nobody chose.
        from_env = (os.environ.get("OUTREACH_AI_PROVIDER") or "").strip().lower()
        provider = from_env or DEFAULT_PROVIDER
    if not model:
        model = (os.environ.get("OUTREACH_AI_MODEL") or "").strip()
    return provider, model


def set_selection(provider: str, model: str = "", owner=None) -> tuple[str, str]:
    """Choose the provider (and optionally the model) used from now on."""
    from .models import AiSelection

    owner = owner if owner is not None else current_owner()
    if owner is None or not getattr(owner, "pk", None):
        raise CredentialError("The provider choice belongs to an account. "
                              "Sign in first.")

    provider_spec = spec(provider)
    AiSelection.objects.update_or_create(
        owner=owner, defaults={"provider": provider_spec.name,
                               "model": (model or "").strip()[:120]},
    )
    return selection(owner)
