"""
Which provider answers, and the one path every request takes.

Two jobs that belong together because the second depends on the first:

  * **Resolution.** A provider name comes from the campaign, the account's saved
    selection, or the environment -- in that order -- and turns into a backend module
    plus a resolved credential. Nothing else in the application chooses a provider.
  * **`_complete`.** Every AI request in this application goes through it. That is
    what makes usage recording, error categorisation and the one-retry fallback true
    everywhere rather than in whichever caller remembered -- and a test asserts no
    other module calls a backend directly.

The fallback is deliberately narrow: one retry, on a rate limit or an outage, using a
credential the user explicitly marked as a fallback. Retrying a refused request
against the same key is how a rate limit becomes a longer rate limit.
"""

from __future__ import annotations

import importlib
import logging
from types import ModuleType

from apps.ai import credentials
from apps.ai.base import AiError

log = logging.getLogger(__name__)

#: Backend name -> (module path, the pip package it needs).
#:
#: Imported lazily so only the provider actually in use needs its SDK
#: installed -- running on Gemini should not require `anthropic`, or vice versa.
#: Each module exposes NAME, LABEL, DEFAULT_MODEL, describe_credentials() and
#: complete().
#: Derived from credentials.SPECS so there is one list of providers in the
#: project, not two that can drift apart. The shape is unchanged, so callers and
#: tests that read PROVIDERS keep working.
PROVIDERS: dict[str, tuple[str, str]] = {
    name: (provider_spec.module, provider_spec.package)
    for name, provider_spec in credentials.SPECS.items()
}

DEFAULT_PROVIDER = credentials.DEFAULT_PROVIDER
























# --------------------------------------------------------------------------- #
# Provider selection
# --------------------------------------------------------------------------- #

def provider() -> str:
    """The selected provider name.

    Read live, and through the resolver, so a change made in Settings takes
    effect on the next request without a restart. The priority is the same as it
    is for credentials: a choice saved in Settings, then OUTREACH_AI_PROVIDER,
    then the built-in default.
    """
    return credentials.selection()[0]


def load(name: str) -> ModuleType:
    """Import one backend by name, with a readable error if it is unavailable."""
    try:
        path, package = PROVIDERS[(name or "").strip().lower()]
    except KeyError:
        raise AiError(
            f"Unknown AI provider {name!r}. Choose one of: "
            f"{', '.join(sorted(PROVIDERS))} in Settings, or set "
            "OUTREACH_AI_PROVIDER."
        ) from None

    try:
        return importlib.import_module(path)
    except ImportError as exc:
        raise AiError(
            f"The {name} backend needs the {package!r} package, which is not "
            f"installed. Run `pip install {package}`, or switch provider with "
            f"OUTREACH_AI_PROVIDER."
        ) from exc


def backend() -> ModuleType:
    return load(provider())


def model() -> str:
    """The model to use, for the selected provider.

    Priority: a model saved against that provider's credential, then the model
    chosen in Settings, then OUTREACH_AI_MODEL, then the backend default. Each
    provider keeps its own model, so switching provider cannot leave a model name
    belonging to a different one behind.
    """
    name = provider()
    resolved = credentials.resolve(name)
    if resolved.model:
        # Carried with the active credential, so a testing key can point at a
        # cheaper model than the production one without any other change.
        return resolved.model

    chosen = credentials.selection()[1]
    if chosen:
        return chosen
    return backend().DEFAULT_MODEL


def describe_credentials() -> tuple[bool, str, str]:
    """(usable, source, advice) for the configured provider."""
    try:
        return backend().describe_credentials()
    except AiError as exc:
        return False, str(exc), ""


def describe_provider() -> str:
    """One line for status output and error messages."""
    try:
        return f"{backend().LABEL} / {model()}"
    except AiError:
        return f"{provider()} (unknown)"


# --------------------------------------------------------------------------- #
# The one path every AI request takes
# --------------------------------------------------------------------------- #

def _complete(*, system: str, prompt: str, schema: dict,
              max_tokens: int) -> str:
    """Send one request through the active credential, and record what happened.

    Every AI feature in the application goes through here -- the website review,
    the email, the follow-up, the no-website email, and anything added later.
    That is what makes "activate the backup credential" take effect everywhere at
    once with no other change: this function asks the resolver which credential is
    active, and the resolver is the only thing that knows.

    Three responsibilities, in one place because they belong together:

      * **usage** -- which credential served the request, and did it work. Written
        against the child row, so the Settings page can show a real "last used"
        rather than an invented one.
      * **safe failures** -- the provider's own error text is never stored or
        shown. It can quote the request, and the request carried the key; a
        category and a written phrase are enough to act on.
      * **opt-in fallback** -- if the active credential is rate limited and the
        user has explicitly marked a spare as usable, the spare is tried *for this
        request only*. The active credential never changes: silently rotating it
        would leave the user looking at a Settings page that no longer says what
        the application is doing.
    """
    from apps.ai import context as aicontext
    from apps.ai import credentials

    name = provider()
    resolved = credentials.require(name)
    handle = backend()

    def send() -> str:
        return handle.complete(system=system, prompt=prompt, schema=schema,
                               model=model(), max_tokens=max_tokens)

    try:
        text = send()
    except Exception as first_error:      # noqa: BLE001 - categorised below
        category, phrase = credentials.categorise(first_error)
        credentials.record_use(resolved.credential_id, success=False,
                               category=category, detail=phrase)

        spare = _fallback_for(name, category, resolved)
        if spare is None:
            raise

        # One retry, on one spare, for this request only.
        owner = aicontext.get_owner()
        try:
            with aicontext.using_credential(spare):
                credentials.invalidate(name)
                text = handle.complete(system=system, prompt=prompt,
                                       schema=schema, model=model(),
                                       max_tokens=max_tokens)
        except Exception as second_error:  # noqa: BLE001
            spare_category, spare_phrase = credentials.categorise(second_error)
            credentials.record_use(spare.pk, success=False,
                                   category=spare_category, detail=spare_phrase)
            credentials.record_fallback(
                owner=owner, provider=name, from_label=resolved.label or "active",
                to_row=spare, reason=category, result=spare_phrase)
            credentials.invalidate(name)
            raise first_error from None     # report the active key's failure
        finally:
            credentials.invalidate(name)

        credentials.record_use(spare.pk, success=True)
        credentials.record_fallback(
            owner=owner, provider=name, from_label=resolved.label or "active",
            to_row=spare, reason=category, result="succeeded")
        return text

    credentials.record_use(resolved.credential_id, success=True)
    return text


#: Failures a different key might genuinely survive. An invalid key is not one of
#: them for the *same* provider account, but a rate limit or a quota is exactly
#: what a spare key exists for.
FALLBACK_CATEGORIES = ("rate_limited", "unavailable")


def _fallback_for(name: str, category: str, resolved):
    """A spare credential to try, or None.

    None whenever anything is unclear: the failure is not one a different key
    would survive, the user has not marked a spare as usable, or the request was
    not using a database credential in the first place.
    """
    from apps.ai import credentials

    if category not in FALLBACK_CATEGORIES:
        return None
    if not resolved.credential_id:
        # An environment or CLI credential. There is no pool to fall back within.
        return None

    for spare in credentials.fallbacks(name):
        if spare.pk != resolved.credential_id:
            return spare
    return None


# --------------------------------------------------------------------------- #
# Prompt
# --------------------------------------------------------------------------- #













# --------------------------------------------------------------------------- #
# Generation
# --------------------------------------------------------------------------- #









# --------------------------------------------------------------------------- #
# The audit, as a report
#
# Ten findings in a flat list is a wall. Grouped by priority it is a plan: three
# things that are costing money now, five worth doing, four to tidy up. The
# grouping is what makes the list actionable, so it happens here rather than being
# left to whichever template happens to render it.
# --------------------------------------------------------------------------- #








# --------------------------------------------------------------------------- #
# Was the email actually built on the findings?
#
# The prompt says to name the specific thing that was measured. This checks it,
# because "I noticed some issues with your website" is the exact output the brief
# rules out, and a prompt instruction is a request rather than a guarantee.
#
# Two separate failures, both caught here:
#
#   * a **vague claim** -- the email gestures at problems without naming one;
#   * a **quoted metric** -- the email puts "LCP 4.8s" or "cta_count 0" in front
#     of a business owner, which is the audit's language, not theirs.
#
# Neither is fatal. `generate_draft` regenerates once with the failure as the
# revision note, which is cheaper than a human noticing it in review, and far
# cheaper than sending it.
# --------------------------------------------------------------------------- #



















# --------------------------------------------------------------------------- #
# Workflow B: no verified website
# --------------------------------------------------------------------------- #












# --------------------------------------------------------------------------- #
# Follow-ups
# --------------------------------------------------------------------------- #
