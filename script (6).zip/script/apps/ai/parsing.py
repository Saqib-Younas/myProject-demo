"""
Turning a model's reply into the objects the rest of the application uses.

Tolerant about shape, strict about content. A code fence around the JSON is stripped,
a missing optional field becomes an empty string -- but a finding with no evidence is
dropped, a benefit that promises a result is withheld, and every finding comes out
with an id so a claim in an email can be traced back to it.

Parsing is where the evidence rule is first enforced, before anything downstream has
a chance to treat an unevidenced finding as real.
"""

from __future__ import annotations

import json

from apps.ai.base import (
    AiError,
    GeneratedEmail,
    SiteAudit,
)

from . import prompts, validation
from .validation import (
    assign_ids,
    hedge_findings,
)


def _load_json(text: str) -> dict:
    """Parse a model reply into a JSON object, tolerating a code fence."""
    if not (text or "").strip():
        raise AiError("The model returned an empty response.")

    # Some models wrap JSON in a ```json fence even when asked not to.
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.split("\n", 1)[-1].rsplit("```", 1)[0].strip()

    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as exc:
        raise AiError("The model returned malformed JSON.") from exc

    if not isinstance(data, dict):
        raise AiError("The model returned JSON that is not an object.")
    return data
def parse(text: str) -> GeneratedEmail:
    """Validate the model's JSON into a GeneratedEmail."""
    data = _load_json(text)
    subject = str(data.get("subject") or "").strip()
    body = str(data.get("body") or "").strip()
    if not subject or not body:
        raise AiError("The model returned an email with no subject or no body.")

    used = data.get("findings_used") or []
    if not isinstance(used, list):
        used = []

    return GeneratedEmail(
        subject=subject,
        body=body,
        observation=str(data.get("observation") or "").strip() or "none",
        findings_used=[str(u).strip() for u in used if str(u).strip()],
    )
def parse_no_website(text: str) -> GeneratedEmail:
    """Validate the no-website JSON, and refuse a promise it should not make."""
    data = _load_json(text)
    subject = str(data.get("subject") or "").strip()
    body = str(data.get("body") or "").strip()
    if not subject or not body:
        raise AiError("The model returned an email with no subject or no body.")

    flat = " ".join(body.lower().split())
    for phrase in validation.GUARANTEE_PATTERNS:
        if phrase in flat:
            raise AiError(
                f"The draft promised an outcome ({phrase!r}), which this "
                "application does not do. Regenerate it.",
                retryable=True,
            )

    used = data.get("benefits_used") or []
    if not isinstance(used, list):
        used = []

    return GeneratedEmail(
        subject=subject[:400],
        body=body,
        observation=str(data.get("observation") or "").strip() or "none",
        findings_used=[str(u).strip() for u in used if str(u).strip()],
    )
def parse_followup(text: str, *, original_subject: str = "") -> GeneratedEmail:
    """Validate the follow-up JSON.

    The subject is rebuilt here rather than trusted. Models add "Re:" twice, drop
    it, or quietly rewrite the line -- and a follow-up that does not thread under
    the original defeats the point of sending one.
    """
    data = _load_json(text)
    body = str(data.get("body") or "").strip()
    if not body:
        raise AiError("The model returned a follow-up with no body.")

    # The original wins over a model that decided to write its own subject.
    base = original_subject or str(data.get("subject") or "").strip()

    return GeneratedEmail(
        subject=prompts.reply_subject(base)[:400],
        body=body,
        observation=str(data.get("angle") or "").strip() or "follow-up",
        findings_used=[],
    )
def parse_audit(text: str) -> SiteAudit:
    """Validate the review JSON, then drop findings with no evidence.

    The evidence rule is enforced here as well as in the prompt: a finding with
    an empty evidence field is exactly the speculation the prompt forbids, so it
    is discarded rather than shown to the user as if it were verified.
    """
    data = _load_json(text)
    audit_result = SiteAudit.from_dict(data)

    kept = [
        f for f in audit_result.findings
        if f.issue and f.evidence and f.why_it_matters
    ]
    kept.sort(key=lambda f: f.rank)
    # A benefit that promises an outcome loses the sentence, not the finding: the
    # evidence behind it is still real and still worth acting on.
    audit_result.findings = assign_ids(hedge_findings(kept[:prompts.MAX_FINDINGS]))

    if not audit_result.findings:
        raise AiError(
            "The review produced no findings backed by evidence. The crawled "
            "pages may have been too thin to assess."
        )
    return audit_result
