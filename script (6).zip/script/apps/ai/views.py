"""
The credential pool's endpoints.

Here rather than in `outreach` because this is where credentials live. The page that
renders them is still the outreach Settings page -- one screen can be served by two
apps, and pretending otherwise would mean either a second settings page or credential
code in the wrong app.

Three rules, all of them about not leaking a key:

  * **The only request that carries a key is the one that saves it.** Everything else
    sends an id, and the server re-reads that credential against the signed-in account
    before acting on it.
  * **No response ever contains a key.** Masked hints, labels and counters only.
  * **`OUTREACH_CREDENTIALS_UI=0` closes every write endpoint here**, for a deployment
    that wants keys to come from `.env` alone.
"""

from __future__ import annotations

import importlib

from django.conf import settings as django_settings
from django.db import IntegrityError
from django.http import HttpRequest, JsonResponse
from django.shortcuts import get_object_or_404
from django.views.decorators.http import require_GET, require_POST

from apps import ai
from apps.ai import context as aicontext
from apps.ai import credentials
from apps.ai.models import ProviderCredential
from apps.core.http import json_body
from apps.outreach.views.settings import _credential_ui_enabled


def _json(request: HttpRequest) -> dict:
    """Read a JSON body, tolerating a malformed one."""
    return json_body(request)


def _credential_guard() -> JsonResponse | None:
    if _credential_ui_enabled():
        return None
    return JsonResponse({
        "error": "Credential editing is disabled here (OUTREACH_CREDENTIALS_UI=0). "
                 "Set provider keys in .env instead.",
    }, status=403)
def _provider_or_error(provider: str):
    """(spec_name, error_response). Rejects anything not in the provider table."""
    name = (provider or "").strip().lower()
    if not credentials.known(name):
        return "", JsonResponse({
            "error": f"Unknown AI provider {provider!r}. Choose one of: "
                     + ", ".join(sorted(credentials.SPECS)) + ".",
        }, status=400)
    return name, None
def _my_credential(request: HttpRequest, pk: int) -> ProviderCredential:
    """One of this account's credentials, or 404.

    404 rather than 403, and `owner` in the query rather than a check after the
    fetch: "forbidden" would confirm that a credential with that id exists and
    belongs to somebody else.
    """
    return get_object_or_404(ProviderCredential, pk=pk, owner=request.user)
def _pool(request: HttpRequest) -> dict:
    """The whole pool in its safe shape: providers, each with its children."""
    return {
        "providers": credentials.all_statuses(request.user),
        "selected": ai.provider(),
    }
def _verify_credential(row) -> tuple[str, str]:
    """Test one child credential. ("", reason) when there is no way to test it.

    ("blocked", reason) where outbound requests are switched off.

    Returns rather than raises: a provider being unreachable is information, not
    a reason to refuse to save a key. The verdict is recorded against the row, so
    the card can show when it was last tested and what happened.
    """
    if getattr(django_settings, "OUTREACH_BLOCK_SEND", False):
        # The same switch that blocks SMTP and IMAP. A connection test is an
        # outbound request like any other, so it is refused here rather than
        # quietly made -- which is also what keeps the test suite offline.
        return "blocked", ("Not verified: outbound requests are blocked in this "
                           "environment (OUTREACH_BLOCK_SEND).")

    provider_spec = credentials.spec(row.provider)
    try:
        module = importlib.import_module(provider_spec.module)
    except ImportError:
        return "", (f"Not verified: the {provider_spec.label} backend needs the "
                    f"{provider_spec.package!r} package, which is not "
                    f"installed. Run `pip install {provider_spec.package}`.")

    verify = getattr(module, "verify", None)
    if not callable(verify):
        return "", ""

    try:
        # Forced onto this specific child, so a spare can be tested without
        # activating it -- and so the test proves *this* key works rather than
        # whichever one happens to be active.
        with aicontext.using_credential(row):
            credentials.invalidate(row.provider)
            result, message = verify(row.model or "")
    except Exception as exc:      # noqa: BLE001 - a test must not raise at a user
        result, message = credentials.categorise(exc)
    finally:
        # The forced credential is gone; the cached client must go with it.
        credentials.invalidate(row.provider)

    credentials.record_test(row.provider, f"{result}: {message}", row.pk,
                            row.owner)
    return result, message
@require_POST
def credential_add(request: HttpRequest, provider: str) -> JsonResponse:
    """Add one child credential under a provider.

    Tested immediately after saving, where the SDK is installed and the provider
    offers a cheap check. A failed test does not undo the save -- the key may be
    fine and the provider merely unreachable -- but it is reported in the same
    response and recorded against the row, so a bad key is known now rather than
    in the middle of a campaign.
    """
    blocked = _credential_guard()
    if blocked is not None:
        return blocked
    name, error = _provider_or_error(provider)
    if error is not None:
        return error

    payload = _json(request)
    key = str(payload.get("api_key", ""))
    if not key.strip():
        return JsonResponse({"error": "Enter an API key."}, status=400)

    extras = payload.get("extras") or {}
    if not isinstance(extras, dict):
        extras = {}

    try:
        row = credentials.add(
            request.user, name, key,
            label=str(payload.get("label", "")),
            description=str(payload.get("description", "")),
            extras={k: str(v) for k, v in extras.items()},
            model=str(payload.get("model", "")),
            activate=payload.get("activate"),
            allow_fallback=bool(payload.get("allow_fallback")),
        )
    except credentials.CredentialConflict as exc:
        return JsonResponse({"error": str(exc)}, status=409)
    except credentials.CredentialError as exc:
        # Never contains the key: CredentialError is documented not to carry one.
        return JsonResponse({"error": str(exc)}, status=400)

    verdict, verdict_message = _verify_credential(row)

    status = credentials.status(name, request.user)
    message = f"{status['label']} credential {row.label!r} saved."
    if row.is_active:
        message += " It is now the active credential for this provider."
    if verdict and verdict != "ok":
        message += f" {verdict_message}"

    return JsonResponse({
        "saved": True,
        "message": message,
        "verified": verdict,
        "verify_message": verdict_message,
        "credential": credentials.child_status(
            ProviderCredential.objects.get(pk=row.pk)),
        "status": status,
        **_pool(request),
    })
@require_POST
def credential_activate(request: HttpRequest, pk: int) -> JsonResponse:
    """Make one child the active credential for its provider.

    The previous active credential stands down in the same transaction, and every
    AI feature uses the new one from the next request onwards -- because they all
    ask the same resolver which credential is active.
    """
    blocked = _credential_guard()
    if blocked is not None:
        return blocked
    row = _my_credential(request, pk)

    if row.is_active:
        return JsonResponse({
            "message": f"{row.label!r} is already the active credential.",
            "status": credentials.status(row.provider, request.user),
            **_pool(request),
        })

    try:
        status = credentials.activate(request.user, row)
    except IntegrityError:
        # Two tabs both pressed Activate. The database constraint held; say so
        # plainly rather than reporting a success that did not happen.
        return JsonResponse({
            "error": "Another change to this provider happened at the same "
                     "time. Reload the page and try again.",
        }, status=409)
    except credentials.CredentialError as exc:
        return JsonResponse({"error": str(exc)}, status=400)

    return JsonResponse({
        "message": f"{status['label']} now uses {row.label!r}. Every AI request "
                   "for this provider will use it from now on.",
        "status": status,
        **_pool(request),
    })
@require_POST
def credential_deactivate(request: HttpRequest, pk: int) -> JsonResponse:
    """Stand one child down, promoting nothing in its place.

    The response says exactly where the provider stands afterwards, because that
    is the part a user cannot see: with no active credential it falls back to the
    environment variable if one is set, and to nothing if not.
    """
    blocked = _credential_guard()
    if blocked is not None:
        return blocked
    row = _my_credential(request, pk)

    try:
        status = credentials.deactivate(request.user, row)
    except credentials.CredentialError as exc:
        return JsonResponse({"error": str(exc)}, status=400)

    if status["source"] == credentials.ENVIRONMENT:
        message = (f"{row.label!r} deactivated. {status['label']} now falls back "
                   "to the environment variable.")
    elif status["configured"]:
        message = (f"{row.label!r} deactivated. {status['label']} now uses "
                   f"{status['source_label'].lower()}.")
    else:
        message = (f"{row.label!r} deactivated. {status['label']} has no active "
                   "credential — activate one before running anything that "
                   "needs it.")

    return JsonResponse({"message": message, "status": status, **_pool(request)})
@require_POST
def credential_delete(request: HttpRequest, pk: int) -> JsonResponse:
    """Delete one child credential.

    Deleting the active one leaves the provider with no active credential rather
    than promoting a sibling: quietly redirecting every request onto a key nobody
    chose is the surprise this whole design avoids. The response says so, and the
    browser asks for confirmation before getting here.
    """
    blocked = _credential_guard()
    if blocked is not None:
        return blocked
    row = _my_credential(request, pk)
    label, was_active = row.label, row.is_active
    remaining = (credentials.children(row.provider, request.user)
                 .exclude(pk=row.pk).count())

    try:
        status = credentials.remove(request.user, row)
    except credentials.CredentialError as exc:
        return JsonResponse({"error": str(exc)}, status=400)

    message = f"{label!r} deleted."
    if was_active:
        if status["source"] == credentials.ENVIRONMENT:
            message += (f" {status['label']} now falls back to the environment "
                        "variable.")
        elif remaining:
            message += (f" {status['label']} has no active credential — "
                        f"activate one of the remaining {remaining}.")
        else:
            message += f" {status['label']} is no longer configured."

    return JsonResponse({
        "deleted": True, "message": message, "status": status, **_pool(request),
    })
@require_POST
def credential_test(request: HttpRequest, pk: int) -> JsonResponse:
    """Test one child credential, active or not.

    Categories are `ok`, `invalid`, `rate_limited`, `forbidden`, `model`,
    `unavailable`, `error`. The message is written locally and never passed
    through unread from the provider: provider error text can quote the request,
    and the request carried the key.
    """
    row = _my_credential(request, pk)
    result, message = _verify_credential(row)

    if not result:
        return JsonResponse({
            "result": "unsupported",
            "message": message or "This provider has no connection test.",
            "status": credentials.status(row.provider, request.user),
        }, status=400)

    if result == "blocked":
        # A local policy, not a provider verdict: 400, not a bad gateway.
        return JsonResponse({
            "result": result, "message": message,
            "status": credentials.status(row.provider, request.user),
        }, status=400)

    return JsonResponse({
        "result": result,
        "message": message,
        "credential": credentials.child_status(
            ProviderCredential.objects.get(pk=row.pk)),
        "status": credentials.status(row.provider, request.user),
    }, status=200 if result in ("ok", "rate_limited") else 502)
@require_POST
def credential_fallback(request: HttpRequest, pk: int) -> JsonResponse:
    """Mark whether this spare may be tried when the active credential fails.

    Off unless the user turns it on: automatic rotation has to be something they
    asked for. Even on, it never changes which credential is active -- it borrows
    the spare for one request, and writes down that it did.
    """
    blocked = _credential_guard()
    if blocked is not None:
        return blocked
    row = _my_credential(request, pk)
    payload = _json(request)
    enabled = bool(payload.get("enabled"))

    if row.is_active and enabled:
        return JsonResponse({
            "error": "The active credential is the one already in use. Mark a "
                     "spare as the fallback instead.",
        }, status=400)

    try:
        status = credentials.set_fallback(request.user, row, enabled)
    except credentials.CredentialError as exc:
        return JsonResponse({"error": str(exc)}, status=400)

    return JsonResponse({
        "message": (f"{row.label!r} may now be used for a single retry when the "
                    "active credential is rate limited." if enabled else
                    f"{row.label!r} will no longer be used as a fallback."),
        "status": status,
        **_pool(request),
    })
@require_GET
def credential_events(request: HttpRequest) -> JsonResponse:
    """The recent credential history for this account.

    Answers §11's questions after the fact -- which credential was used, why,
    when, and what happened -- and contains no keys, only labels and categories.
    """
    provider = (request.GET.get("provider") or "").strip().lower()
    if provider and not credentials.known(provider):
        provider = ""

    rows = credentials.events(request.user, provider, limit=40)
    return JsonResponse({
        "events": [
            {
                "kind": row.kind,
                "kind_label": row.get_kind_display(),
                "provider": row.provider,
                "provider_label": (credentials.spec(row.provider).label
                                   if credentials.known(row.provider)
                                   else row.provider),
                "label": row.label,
                "category": row.category,
                "detail": row.detail,
                "at": row.created_at.isoformat(),
            }
            for row in rows
        ],
    })
@require_POST
def ai_select(request: HttpRequest) -> JsonResponse:
    """Choose the provider used from now on.

    The browser sends `{"provider": "openai"}` and nothing else -- never a key.
    Which key that provider then uses is the server's business: the active child.
    """
    payload = _json(request)
    name, error = _provider_or_error(str(payload.get("provider", "")))
    if error is not None:
        return error

    resolved = credentials.resolve(name, request.user)
    if not resolved.usable:
        # Refused rather than saved: selecting a provider with no credential
        # would leave every later AI call failing with the same message.
        return JsonResponse({
            "error": credentials.NOT_CONFIGURED_TEMPLATE.format(
                label=credentials.spec(name).label),
            "status": credentials.status(name, request.user),
        }, status=400)

    provider_name, model_name = credentials.set_selection(
        name, str(payload.get("model", "")), request.user)

    return JsonResponse({
        "selected": provider_name,
        "model": model_name or credentials.spec(provider_name).default_model,
        "message": f"{credentials.spec(provider_name).label} selected"
                   + (f", using {resolved.label!r}." if resolved.label else "."),
        **_pool(request),
    })
