"""
Shared types for the AI backends.

Kept in its own module so `ai.py` and each backend can import them without a
circular import.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

#: A per-minute limit: waiting a short while genuinely fixes it.
RATE_LIMIT = "rate_limit"
#: A per-day, per-month or billing allowance that is spent. Waiting a minute
#: fixes nothing -- this one needs the reset, or a different provider.
QUOTA = "quota"


class AiError(RuntimeError):
    """Generation failed for a reason worth showing the user.

    `retryable` marks the failures that a second attempt a few seconds later can
    genuinely fix -- a rate limit, a dropped connection, a 5xx, a reply cut off
    mid-JSON. It is deliberately *not* set for missing credentials, an unknown
    model, or a context that exceeds the provider's per-request ceiling: those
    fail identically every time, and retrying each of 25 leads would add minutes
    to a run to arrive at the same error.

    `category` is set to RATE_LIMIT or QUOTA when the provider said so. The two
    are handled completely differently -- one is waited out, the other stops the
    run until the allowance resets or the user picks another provider -- so the
    distinction is carried on the error rather than guessed at from its text
    later.

    `retry_after` is the provider's own answer, in seconds, when it gave one. A
    provider that says "try again in 8 seconds" knows better than any backoff
    formula, so that number is used in preference to one.
    """

    def __init__(self, *args, retryable: bool = False, category: str = "",
                 retry_after: float | None = None):
        super().__init__(*args)
        self.retryable = retryable
        self.category = category
        self.retry_after = retry_after

    @property
    def rate_limited(self) -> bool:
        """Either kind of allowance problem."""
        return self.category in (RATE_LIMIT, QUOTA)

    @property
    def quota_exhausted(self) -> bool:
        """A daily/monthly/billing allowance, not a per-minute burst."""
        return self.category == QUOTA


#: Words that mean "this allowance resets on a clock you cannot wait out".
#: Checked against the provider's message because the HTTP status is the same 429
#: either way -- OpenAI's `insufficient_quota`, Groq's per-day limit and Gemini's
#: exhausted free tier all arrive as one.
_QUOTA_MARKERS = (
    "insufficient_quota", "insufficient quota", "exceeded your current quota",
    "quota exceeded", "quota_exceeded", "billing", "credit balance",
    "out of credits", "no credits", "per day", "per-day", "daily limit",
    "requests per day", "tokens per day", "rpd", "tpd", "per month",
    "monthly limit", "free tier", "spending limit", "hard limit",
    "plan and billing",
)


def classify_rate_limit(message: str) -> str:
    """RATE_LIMIT or QUOTA, from what the provider actually said.

    Defaults to RATE_LIMIT: treating a per-minute limit as an exhausted quota
    would stop a run that a 30-second wait would have finished, and that is the
    more expensive mistake of the two.
    """
    flat = " ".join((message or "").lower().split())
    return QUOTA if any(marker in flat for marker in _QUOTA_MARKERS) else RATE_LIMIT


#: "try again in 8.532s", "retry after 12 seconds", "please wait 1m30s".
_WAIT_PATTERNS = (
    re.compile(r"try again in\s+(?P<value>[\d.]+)\s*(?P<unit>ms|s|m|h)\b"),
    re.compile(r"retry after\s+(?P<value>[\d.]+)\s*(?P<unit>ms|s|m|h)?"),
    re.compile(r"wait\s+(?P<value>[\d.]+)\s*(?P<unit>ms|s|m|h)\b"),
)

_UNIT_SECONDS = {"ms": 0.001, "s": 1.0, "m": 60.0, "h": 3600.0, None: 1.0, "": 1.0}


def retry_after_of(error: Exception) -> float | None:
    """The provider's own retry delay in seconds, or None.

    Two places to look, in order of trustworthiness:

      1. the `Retry-After` header, which is the standard answer and is what the
         brief says to respect;
      2. the message text, because several providers put "try again in 8.5s" in
         the body and send no header at all.

    Anything unparseable returns None, and the caller falls back to its own
    backoff. A wrong number here would either hammer the provider or idle a run
    for an hour, so a guess is worse than no answer.
    """
    header = _header_delay(error)
    if header is not None:
        return header

    flat = " ".join(str(error).lower().split())
    for pattern in _WAIT_PATTERNS:
        found = pattern.search(flat)
        if not found:
            continue
        try:
            value = float(found.group("value"))
        except (TypeError, ValueError):
            continue
        unit = (found.groupdict().get("unit") or "s").strip()
        seconds = value * _UNIT_SECONDS.get(unit, 1.0)
        if 0 < seconds <= 86_400:
            return seconds
    return None


def _header_delay(error: Exception) -> float | None:
    """`Retry-After` (seconds or a date) or `retry-after-ms`, if the SDK kept it."""
    headers = getattr(getattr(error, "response", None), "headers", None)
    if headers is None:
        return None

    try:
        millis = headers.get("retry-after-ms") or headers.get("Retry-After-Ms")
        if millis:
            return max(0.0, float(millis) / 1000.0)

        raw = headers.get("retry-after") or headers.get("Retry-After")
        if not raw:
            return None
        raw = str(raw).strip()
        if raw.replace(".", "", 1).isdigit():
            return max(0.0, float(raw))

        # The header also allows an HTTP date. Rare from AI providers, but
        # cheap to honour and the alternative is ignoring a correct answer.
        from email.utils import parsedate_to_datetime

        from django.utils import timezone

        when = parsedate_to_datetime(raw)
        if when.tzinfo is None:
            when = when.replace(tzinfo=timezone.utc)
        return max(0.0, (when - timezone.now()).total_seconds())
    except Exception:  # noqa: BLE001 - a malformed header is not an error here
        return None


@dataclass
class GeneratedEmail:
    subject: str
    body: str
    observation: str
    findings_used: list[str] = field(default_factory=list)


@dataclass
class Finding:
    """One verified website issue or opportunity.

    The fields map onto the seven things an audit entry has to say:

        issue                 what is wrong
        evidence              the measured fact or quote it rests on
        why_it_matters        the cost to the business
        suggested_improvement the fix
        business_benefit      what fixing it could gain, hedged
        severity              the priority: high / medium / low
        page_url              the page it was found on, where derivable

    `severity` is the priority. One field rather than two, because a "priority"
    that can disagree with a "severity" is worse than either on its own.
    """

    issue: str
    evidence: str
    why_it_matters: str
    suggested_improvement: str
    dimension: str = ""
    severity: str = "medium"
    page_url: str = ""
    #: What the owner could gain by fixing it. Hedged by instruction and checked
    #: in code -- see `ai.unhedged_benefit`.
    business_benefit: str = ""
    #: AUD-001, AUD-002 ... Assigned in code after ranking, never asked of the
    #: model: an id the model invented would trace to nothing, which defeats the
    #: point of having one.
    finding_id: str = ""

    #: HIGH / MEDIUM / LOW, for display. Derived, never stored.
    @property
    def priority(self) -> str:
        return (self.severity or "medium").upper()

    #: Ordering weight, so the strongest findings come first.
    RANK = {"high": 0, "medium": 1, "low": 2}

    @property
    def rank(self) -> int:
        return self.RANK.get(self.severity, 1)

    def as_dict(self) -> dict:
        return {
            "issue": self.issue,
            "evidence": self.evidence,
            "why_it_matters": self.why_it_matters,
            "suggested_improvement": self.suggested_improvement,
            "dimension": self.dimension,
            "severity": self.severity,
            "page_url": self.page_url,
            "business_benefit": self.business_benefit,
            "finding_id": self.finding_id,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Finding":
        return cls(
            issue=str(data.get("issue") or "").strip(),
            evidence=str(data.get("evidence") or "").strip(),
            why_it_matters=str(data.get("why_it_matters") or "").strip(),
            suggested_improvement=str(data.get("suggested_improvement") or "").strip(),
            dimension=str(data.get("dimension") or "").strip(),
            severity=str(data.get("severity") or "medium").strip().lower(),
            page_url=str(data.get("page_url") or "").strip(),
            # Absent on findings stored before the field existed, which is why it
            # defaults rather than being required here.
            business_benefit=str(data.get("business_benefit") or "").strip(),
            finding_id=str(data.get("finding_id") or "").strip(),
        )


@dataclass
class SiteAudit:
    """The result of the review stage: a summary plus ranked findings."""

    business_summary: str
    findings: list[Finding] = field(default_factory=list)

    def as_dict(self) -> dict:
        return {
            "business_summary": self.business_summary,
            "findings": [f.as_dict() for f in self.findings],
        }

    @classmethod
    def from_dict(cls, data: dict) -> "SiteAudit":
        return cls(
            business_summary=str(data.get("business_summary") or "").strip(),
            findings=[Finding.from_dict(f) for f in (data.get("findings") or [])],
        )
