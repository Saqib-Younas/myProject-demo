"""
OpenRouter backend, via the `openai` SDK against OpenRouter's endpoint.

OpenRouter is an OpenAI-compatible gateway in front of many vendors' models, so
the transport in `openai_compatible` is reused unchanged and only the base URL,
the default model and two optional attribution headers differ.

Model names here are `vendor/model` — `openai/gpt-4.1-mini`,
`anthropic/claude-sonnet-4`, `google/gemini-2.5-flash` — and the catalogue moves,
so the model is expected to be set in Settings. Not every model on OpenRouter
supports strict JSON schemas; the shared transport falls back to plain JSON mode
when one does not, and the parser validates the result either way.
"""

from __future__ import annotations

from apps.ai.base import AiError

from . import openai_compatible as compat

NAME = "openrouter"
LABEL = "OpenRouter"
DEFAULT_BASE_URL = "https://openrouter.ai/api/v1"
DEFAULT_MODEL = "openai/gpt-4.1-mini"
CONSOLE_URL = "https://openrouter.ai/keys"

KEY_VARS = ("OPENROUTER_API_KEY",)

MAX_TOKENS = 4000

#: OpenRouter uses these for its public leaderboard attribution. Optional, and
#: deliberately generic -- nothing identifying is sent.
HEADERS = {
    "HTTP-Referer": "https://github.com/",
    "X-Title": "Lead Mapper",
}

_client = None
_client_fingerprint = ""


def describe_credentials() -> tuple[bool, str, str]:
    """(usable, source, advice), from the central resolver."""
    from apps.ai import credentials

    resolved = credentials.resolve(NAME)
    if resolved.usable:
        return True, resolved.detail, ""
    return False, resolved.detail, resolved.advice


def reset_client() -> None:
    """Drop the cached client, so a newly saved key takes effect at once."""
    global _client, _client_fingerprint
    _client = None
    _client_fingerprint = ""


def client():
    """One shared client, rebuilt when the resolved credential changes."""
    global _client, _client_fingerprint
    from apps.ai import credentials

    resolved = credentials.require(NAME)
    if _client is None or _client_fingerprint != resolved.fingerprint:
        _client = compat.build_client(
            api_key=resolved.key,
            base_url=(resolved.extras or {}).get("base_url") or DEFAULT_BASE_URL,
            default_headers=HEADERS,
            label=LABEL,
        )
        _client_fingerprint = resolved.fingerprint
    return _client


def complete(*, system: str, prompt: str, schema: dict, model: str,
             max_tokens: int = MAX_TOKENS) -> str:
    """Return the model's JSON text, or raise AiError."""
    return compat.complete(
        client(), system=system, prompt=prompt, schema=schema, model=model,
        max_tokens=max_tokens or MAX_TOKENS, label=LABEL,
        console_url=CONSOLE_URL,
    )


def verify(model: str = "") -> tuple[str, str]:
    """Test Connection: (category, message). Never raises for a bad key."""
    try:
        return compat.verify(client(), model=model or DEFAULT_MODEL, label=LABEL)
    except AiError as exc:
        return "error", str(exc)
