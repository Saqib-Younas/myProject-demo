"""One module per language-model provider.

Each exposes the same pair -- `complete(...)` and `verify(...)` -- and imports its own
SDK at call time, so a deployment installs only the provider it uses. `client.load`
turns a provider name into one of these."""
