"""
Claude backend, via the official Anthropic SDK.

Returns the model's raw JSON text; `ai.py` owns the schema, the prompt and the
parsing, so this module is only transport plus provider-specific error handling.
"""

from __future__ import annotations

import os
from pathlib import Path

import anthropic

from apps.ai.base import (
    RATE_LIMIT,
    AiError,
    classify_rate_limit,
    retry_after_of,
)

NAME = "claude"
LABEL = "Claude (Anthropic)"
DEFAULT_MODEL = "claude-opus-5"

#: `medium` keeps per-lead cost sane on a 100-lead run while still writing well.
#: Raise to "high" for a small, high-value list.
EFFORT = os.environ.get("OUTREACH_AI_EFFORT", "medium")

MAX_TOKENS = 4000

#: Server-side fallback: if safety classifiers decline a request, the API reruns
#: it on the recommended fallback model instead of handing back a refusal.
FALLBACK_BETA = "server-side-fallback-2026-07-01"

_client: anthropic.Anthropic | None = None
_client_fingerprint = ""


def _profile_dir() -> Path:
    """Where the `ant` CLI keeps OAuth profiles, per platform."""
    override = os.environ.get("ANTHROPIC_CONFIG_DIR")
    if override:
        return Path(override)
    if os.name == "nt":
        return Path(os.environ.get("APPDATA", "~")).expanduser() / "Anthropic"
    return Path("~/.config/anthropic").expanduser()


def find_cli_profile() -> tuple[bool, str]:
    """(found, description) for an `ant auth login` profile.

    Called by the credential resolver, which owns priority. This function only
    answers "is there a CLI profile, and which one" -- it does not decide whether
    the profile should be used.
    """
    profile = os.environ.get("ANTHROPIC_PROFILE")
    creds = _profile_dir() / "credentials"
    stored = sorted(p.stem for p in creds.glob("*.json")) if creds.is_dir() else []

    if profile:
        if profile in stored:
            return True, f"ant CLI profile {profile!r}"
        return False, (f"ANTHROPIC_PROFILE={profile!r} names a profile that does "
                       f"not exist (found: {', '.join(stored) or 'none'})")
    if stored:
        return True, f"ant CLI profile ({', '.join(stored)})"
    return False, "no CLI profile"


def describe_credentials() -> tuple[bool, str, str]:
    """(usable, source, advice), from the central resolver.

    Kept as a function so `ai_status`, the settings page and the existing tests
    keep working, but the resolution itself now lives in one place for every
    provider. The trap this used to warn about -- an empty ANTHROPIC_API_KEY
    shadowing a good CLI profile -- is still reported, by the resolver.
    """
    from apps.ai import credentials

    resolved = credentials.resolve(NAME)
    if resolved.usable:
        return True, resolved.detail, ""
    return False, resolved.detail, resolved.advice or (
        "Run `ant auth login` to sign in through the browser, set "
        "ANTHROPIC_API_KEY, or save a key in Settings."
    )


def reset_client() -> None:
    """Drop the cached client, so a newly saved key takes effect at once."""
    global _client, _client_fingerprint
    _client = None
    _client_fingerprint = ""


def client() -> anthropic.Anthropic:
    """One shared client, rebuilt when the resolved credential changes.

    An explicit `api_key` is passed when the resolver found one -- including a
    key saved in Settings, which the SDK could not discover by itself. When the
    credential is a CLI profile there is no key to pass, and omitting it is what
    lets the SDK resolve the profile.
    """
    global _client, _client_fingerprint
    from apps.ai import credentials

    resolved = credentials.require(NAME)
    if _client is None or _client_fingerprint != resolved.fingerprint:
        try:
            if resolved.key:
                _client = anthropic.Anthropic(api_key=resolved.key, max_retries=3)
            else:
                _client = anthropic.Anthropic(max_retries=3)
        except Exception as exc:  # noqa: BLE001 - surface as a readable message
            raise AiError(f"Could not build the Claude client: {exc}") from exc
        _client_fingerprint = resolved.fingerprint
    return _client


def verify(model: str = "") -> tuple[str, str]:
    """Test Connection: the cheapest call that proves the credential works.

    Returns (category, message) rather than raising -- "invalid credentials" is an
    answer here, not a failure. Provider error text is not included, because it
    can quote request details.
    """
    try:
        handle = client()
    except AiError as exc:
        return "error", str(exc)

    try:
        handle.messages.create(
            model=model or DEFAULT_MODEL, max_tokens=1,
            messages=[{"role": "user", "content": "ping"}],
        )
    except anthropic.AuthenticationError:
        return "invalid", f"{LABEL} rejected the credentials."
    except anthropic.PermissionDeniedError:
        return "invalid", (f"{LABEL} accepted the credentials but refused access "
                           f"to {model or DEFAULT_MODEL!r}.")
    except anthropic.NotFoundError:
        return "invalid", (f"{LABEL} does not recognise the model "
                           f"{model or DEFAULT_MODEL!r}. The key may still be fine.")
    except anthropic.RateLimitError:
        return "rate_limited", (f"{LABEL} accepted the credentials but is rate "
                                "limited right now.")
    except anthropic.APIConnectionError:
        return "unavailable", f"Could not reach {LABEL}."
    except anthropic.APIStatusError as exc:
        if exc.status_code >= 500:
            return "unavailable", f"{LABEL} is unavailable ({exc.status_code})."
        return "error", f"{LABEL} returned status {exc.status_code}."
    except Exception:  # noqa: BLE001 - never leak an unexpected provider string
        return "error", f"{LABEL} could not be reached."
    return "ok", f"Connected to {LABEL} successfully."


def complete(*, system: str, prompt: str, schema: dict, model: str,
             max_tokens: int = MAX_TOKENS) -> str:
    """Return the model's JSON text, or raise AiError."""
    request = {
        "model": model,
        "max_tokens": max_tokens,
        "system": system,
        "messages": [{"role": "user", "content": prompt}],
        "output_config": {"format": {"type": "json_schema", "schema": schema},
                          "effort": EFFORT},
    }

    try:
        response = _create(request)
    except anthropic.AuthenticationError as exc:
        _, source, _ = describe_credentials()
        raise AiError(
            f"The Claude API rejected the credentials ({source}). If you signed "
            "in with the CLI, the token may have expired -- run "
            "`ant auth login` again. Check `ant auth status` to see which "
            "credential is actually being used."
        ) from exc
    except anthropic.RateLimitError as exc:
        category = classify_rate_limit(str(exc))
        raise AiError(
            "Claude API rate limit reached -- retry in a moment."
            if category == RATE_LIMIT else
            "Claude quota exhausted for this key -- this is a billing or "
            "allowance limit, not a short pause. Wait for the reset, or switch "
            "provider or credential in Settings.",
            retryable=True, category=category,
            retry_after=retry_after_of(exc),
        ) from exc
    except anthropic.APIStatusError as exc:
        raise AiError(f"Claude API error ({exc.status_code}): {exc.message}",
                      retryable=exc.status_code >= 500) from exc
    except anthropic.APIConnectionError as exc:
        raise AiError(f"Could not reach the Claude API: {exc}",
                      retryable=True) from exc

    # A refusal is a successful HTTP call with no usable content -- check it
    # before touching response.content.
    if response.stop_reason == "refusal":
        category = getattr(response.stop_details, "category", None)
        raise AiError(
            "Claude declined to write this email"
            + (f" ({category})" if category else "")
            + ". Review the lead and the service description, then retry."
        )
    if response.stop_reason == "max_tokens":
        raise AiError("The reply was cut off by the token limit -- retry.",
                      retryable=True)

    return next((b.text for b in response.content if b.type == "text"), "")


def _create(request: dict):
    """Send the request, preferring server-side refusal fallbacks.

    The fallback parameter lives on the beta endpoint. If this SDK build or
    account does not accept it, fall back to the plain endpoint rather than
    failing the whole run over an optional resilience feature.
    """
    try:
        return client().beta.messages.create(
            betas=[FALLBACK_BETA], fallbacks="default", **request
        )
    except (TypeError, anthropic.BadRequestError, anthropic.NotFoundError):
        return client().messages.create(**request)
