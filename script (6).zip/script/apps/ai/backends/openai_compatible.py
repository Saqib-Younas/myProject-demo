"""
Shared transport for the OpenAI-compatible providers: OpenAI and OpenRouter.

Both speak the same Chat Completions API through the same `openai` SDK, differing
only in base URL, default model and a couple of headers. Writing the transport
twice would mean two places for a structured-output bug to hide, so the two
backend modules are thin wrappers around this one.

Same contract as the other backends: take a system prompt, a user prompt and a
JSON schema, return the model's raw JSON text, raise AiError with something
readable on failure. Credentials come from `outreach.credentials`, never from an
environment variable read here.

Structured output: `response_format={"type": "json_schema", ...}` with
`strict: true` where the model supports it. Not every model does -- older ones and
much of OpenRouter's catalogue do not -- so a rejection falls back to
`json_object` mode rather than failing the lead. `ai.parse()` validates whatever
comes back either way, so the fallback is safe rather than merely convenient.
"""

from __future__ import annotations

import openai

from apps.ai.base import (
    RATE_LIMIT,
    AiError,
    classify_rate_limit,
    retry_after_of,
)

#: Fragments that mean "this model cannot do strict JSON schema", as opposed to
#: "your request was malformed". Matched case-insensitively against the error.
_SCHEMA_UNSUPPORTED = (
    "response_format", "json_schema", "structured output",
    "not supported", "unsupported",
)


def build_client(*, api_key: str, base_url: str = "",
                 organization: str = "", default_headers: dict | None = None,
                 label: str = "provider") -> "openai.OpenAI":
    """One SDK client. The key is passed in; this module never looks one up."""
    kwargs: dict = {"api_key": api_key, "max_retries": 3, "timeout": 120.0}
    if base_url:
        kwargs["base_url"] = base_url
    if organization:
        kwargs["organization"] = organization
    if default_headers:
        kwargs["default_headers"] = default_headers
    try:
        return openai.OpenAI(**kwargs)
    except Exception as exc:  # noqa: BLE001 - surface as a readable message
        raise AiError(f"Could not build the {label} client: {exc}") from exc


def _schema_format(schema: dict, name: str = "outreach_email") -> dict:
    return {
        "type": "json_schema",
        "json_schema": {"name": name, "strict": True, "schema": schema},
    }


def complete(client: "openai.OpenAI", *, system: str, prompt: str, schema: dict,
             model: str, max_tokens: int, label: str,
             console_url: str = "") -> str:
    """Return the model's JSON text, or raise AiError."""
    messages = [
        {"role": "system", "content": system},
        {"role": "user", "content": prompt},
    ]
    request = {"model": model, "messages": messages,
               "max_completion_tokens": max_tokens}

    try:
        try:
            response = client.chat.completions.create(
                response_format=_schema_format(schema), **request)
        except openai.BadRequestError as exc:
            # Either the model cannot do strict schemas, or the schema itself was
            # rejected. Both are recoverable: ask for plain JSON instead.
            detail = str(exc).lower()
            if not any(mark in detail for mark in _SCHEMA_UNSUPPORTED):
                raise
            response = client.chat.completions.create(
                response_format={"type": "json_object"}, **request)
    except openai.AuthenticationError as exc:
        raise AiError(
            f"{label} rejected the API key. Save a working key in Settings"
            + (f" — keys are created at {console_url}." if console_url else ".")
        ) from exc
    except openai.PermissionDeniedError as exc:
        raise AiError(
            f"{label} refused this request for {model!r}. The key may not have "
            "access to that model, or the account may need billing enabled."
        ) from exc
    except openai.NotFoundError as exc:
        raise AiError(
            f"{label} does not recognise the model {model!r}. Check the model "
            "name in Settings, or clear it to use the default."
        ) from exc
    except openai.RateLimitError as exc:
        # `insufficient_quota` arrives as a 429 exactly like a per-minute burst
        # limit. Waiting out a spent billing allowance would idle the run for
        # nothing, so the two are separated here.
        category = classify_rate_limit(str(exc))
        raise AiError(
            f"{label} rate limit reached — wait a moment and retry, or reduce "
            "the list size."
            if category == RATE_LIMIT else
            f"{label} quota exhausted for this key — this is a quota or "
            "billing limit, not a short pause. Check the provider's billing "
            "page, or switch provider or credential in Settings.",
            retryable=True, category=category,
            retry_after=retry_after_of(exc),
        ) from exc
    except openai.BadRequestError as exc:
        raise AiError(f"{label} rejected the request for {model!r}: {exc}") from exc
    except openai.APIStatusError as exc:
        raise AiError(
            f"{label} API error ({exc.status_code}).",
            retryable=exc.status_code >= 500,
        ) from exc
    except openai.APIConnectionError as exc:
        raise AiError(f"Could not reach {label}: {exc}", retryable=True) from exc

    choices = getattr(response, "choices", None) or []
    if not choices:
        raise AiError(f"{label} returned no choices for this lead.")

    choice = choices[0]
    finish = getattr(choice, "finish_reason", None)
    text = (getattr(choice.message, "content", None) or "").strip()

    if finish == "length":
        raise AiError("The reply was cut off by the token limit -- retry.",
                      retryable=True)
    if finish == "content_filter":
        raise AiError(
            f"{label} filtered this response. Review the lead and the service "
            "description, then retry."
        )
    if not text:
        raise AiError(
            f"{label} returned no text for this lead"
            + (f" (finish_reason {finish})" if finish else "")
            + ". Review the lead and the service description, then retry.",
            retryable=True,
        )
    return text


def verify(client: "openai.OpenAI", *, model: str, label: str) -> tuple[str, str]:
    """The cheapest call that proves the credential works.

    Returns (category, message) rather than raising: this is the Test Connection
    path, where "invalid credentials" is an answer, not a failure. Provider error
    text is deliberately not included -- it can quote request details.
    """
    try:
        client.chat.completions.create(
            model=model, max_completion_tokens=1,
            messages=[{"role": "user", "content": "ping"}],
        )
    except openai.AuthenticationError:
        return "invalid", f"{label} rejected the API key."
    except openai.PermissionDeniedError:
        return "invalid", (f"{label} accepted the key but refused access to "
                           f"{model!r}. Check the model or account billing.")
    except openai.NotFoundError:
        return "invalid", (f"{label} does not recognise the model {model!r}. "
                           "The key may still be fine.")
    except openai.RateLimitError:
        # The key authenticated -- that is what the test is for.
        return "rate_limited", (f"{label} accepted the key but is rate limited "
                                "right now.")
    except openai.APIConnectionError:
        return "unavailable", f"Could not reach {label}."
    except openai.APIStatusError as exc:
        if exc.status_code >= 500:
            return "unavailable", f"{label} is unavailable ({exc.status_code})."
        return "error", f"{label} returned status {exc.status_code}."
    except Exception:  # noqa: BLE001 - never leak an unexpected provider string
        return "error", f"{label} could not be reached."
    return "ok", f"Connected to {label} successfully."
