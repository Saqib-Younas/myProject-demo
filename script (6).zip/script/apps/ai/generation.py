"""
The four things this application asks a language model to do.

Each one is the same three steps -- build a prompt, send it, parse and check the
reply -- and each is deliberately thin, because every part it delegates to is
separately readable and separately testable:

    prompts.build_*     what we ask
    client._complete    the one path a request takes
    parsing.parse_*     what we accept back
    validation.*        whether it may be used

Nothing here talks to a provider SDK, and nothing here contains a prompt.
"""

from __future__ import annotations

from apps.ai.base import AiError, GeneratedEmail, SiteAudit

from . import parsing, prompts, styles
from .client import _complete


def audit(*, business_name: str, category: str, city: str, country: str,
          website: str, site_context: str, pages_read: int,
          discovered: int) -> SiteAudit:
    """Review one crawled website. Raises AiError on failure."""
    if not site_context.strip():
        raise AiError("There is no crawled website material to review.")

    prompt = prompts.build_audit_prompt(
        business_name=business_name, category=category, city=city,
        country=country, website=website, site_context=site_context,
        pages_read=pages_read, discovered=discovered,
    )
    text = _complete(system=prompts.AUDIT_SYSTEM, prompt=prompt, schema=prompts.AUDIT_SCHEMA,
                     max_tokens=prompts.AUDIT_MAX_TOKENS)
    return parsing.parse_audit(text)
def generate(*, business_name: str, category: str, city: str, country: str,
             website: str, sender_name: str, sender_company: str,
             sender_email: str = "", service_pitch: str = "",
             findings: list | None = None, business_summary: str = "",
             site_note: str = "", retry_hint: str = "",
             pages: list | None = None, signals: dict | None = None,
             platform_note: str = "",
             style: styles.Style | None = None) -> GeneratedEmail:
    """Generate one email from the review findings. Raises AiError on failure.

    `findings` is expected to be the ranked shortlist, not the whole audit --
    the caller applies `scoring.rank_for_email` so that the commercial ordering
    is one decision made in one place. `pages` and `signals` are the rest of the
    structured evidence: which pages were read, and what was measured on them.

    `style` is the approved template the campaign chose. It changes the length
    asked for and nothing else: the evidence rule, the ban list and the refusal to
    invent a problem are the same email either way.
    """
    chosen = style or styles.DEFAULT_STYLE
    prompt = prompts.build_prompt(
        business_name=business_name, category=category, city=city,
        country=country, website=website, sender_name=sender_name,
        sender_company=sender_company, sender_email=sender_email,
        service_pitch=service_pitch, findings=findings,
        business_summary=business_summary, site_note=site_note,
        retry_hint=retry_hint, pages=pages, signals=signals,
        platform_note=platform_note,
    )

    text = _complete(system=prompts.system_for(chosen), prompt=prompt,
                     schema=prompts.schema_for(chosen), max_tokens=prompts.EMAIL_MAX_TOKENS)
    return parsing.parse(text)
def no_website_email(*, business_name: str, category: str = "", city: str = "",
                     country: str = "", phone: str = "",
                     benefits: list | None = None, sender_name: str = "",
                     sender_company: str = "", sender_email: str = "",
                     service_pitch: str = "",
                     retry_hint: str = "") -> GeneratedEmail:
    """Write one email to a business with no website. Raises AiError on failure."""
    prompt = prompts.build_no_website_prompt(
        business_name=business_name, category=category, city=city,
        country=country, phone=phone, benefits=benefits,
        sender_name=sender_name, sender_company=sender_company,
        sender_email=sender_email, service_pitch=service_pitch,
        retry_hint=retry_hint,
    )
    text = _complete(system=prompts.NO_WEBSITE_SYSTEM, prompt=prompt,
                     schema=prompts.NO_WEBSITE_SCHEMA, max_tokens=prompts.EMAIL_MAX_TOKENS)
    return parsing.parse_no_website(text)
def follow_up(*, business_name: str, category: str = "", city: str = "",
              country: str = "", website: str = "", sender_name: str = "",
              sender_company: str = "", sender_email: str = "",
              service_pitch: str = "", original_subject: str = "",
              original_body: str = "", observation: str = "",
              findings: list | None = None, business_summary: str = "",
              days_since: int = 0, number: int = 1, campaign_label: str = "",
              conversation: list | None = None,
              retry_hint: str = "") -> GeneratedEmail:
    """Write one follow-up email. Raises AiError on failure.

    `conversation` is the thread so far -- the original email, any reply, and every
    follow-up already sent. Section 12: without it a second follow-up repeats the
    first, because from the model's point of view nothing has happened since.
    """
    prompt = prompts.build_followup_prompt(
        business_name=business_name, category=category, city=city,
        country=country, website=website, sender_name=sender_name,
        sender_company=sender_company, sender_email=sender_email,
        service_pitch=service_pitch, original_subject=original_subject,
        original_body=original_body, observation=observation,
        findings=findings, business_summary=business_summary,
        days_since=days_since, number=number, campaign_label=campaign_label,
        conversation=conversation, retry_hint=retry_hint,
    )
    text = _complete(system=prompts.FOLLOWUP_SYSTEM, prompt=prompt,
                     schema=prompts.FOLLOWUP_SCHEMA, max_tokens=prompts.FOLLOWUP_MAX_TOKENS)
    return parsing.parse_followup(text, original_subject=original_subject)
