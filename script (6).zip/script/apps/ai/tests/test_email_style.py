"""
The email has to read like a consultant wrote it after actually looking.

The failure mode is not a wrong fact — the evidence rules handle that. It is an
email that is *correct and unsendable*: "I recently conducted a comprehensive
analysis of your digital ecosystem and identified opportunities to unlock your
online potential." Every claim in it could be true and no business owner would
reply.

So the style rules are checked in code as well as asked for in the prompt. The list
is long enough that a model drifts back into consultant-speak on its own, and a
draft that has drifted is worth one rewrite.

**This suite was rewritten when the brief changed.** It previously enforced a
90–150 word email that offered to send a write-up and was forbidden from suggesting
a call. The current brief asks for a 250–500 word consultative note ending in a
call, so the bounds and the CTA rules here are the opposite of what they
were, on instruction. The honesty rules did not change, and the last test in this
file is there to prove the rewrite did not loosen them.
"""

from __future__ import annotations

from unittest import mock

from django.test import TestCase

from apps import ai
from apps.ai import prompts, styles
from apps.ai.base import Finding, GeneratedEmail
from apps.core.testing import EMAIL_BODY, SignedIn
from apps.outreach.mail import compose, transport
from apps.outreach.models import EmailDraft
from apps.outreach.services import pipeline as runner
from apps.outreach.tests.factories import make_campaign, make_draft

GOOD_SUBJECT = "A few things I noticed on your website"


def email(body=EMAIL_BODY, subject=GOOD_SUBJECT,
          observation="no obvious way to get in touch from the homepage",
          used=("AUD-001",)) -> GeneratedEmail:
    return GeneratedEmail(subject, body, observation, list(used))


def finding(issue="No obvious way to get in touch from the homepage",
            finding_id="AUD-001") -> Finding:
    row = Finding(issue, "cta_count=0 on the homepage",
                  "A visitor ready to enquire has to go looking",
                  "Add a phone link and an enquiry button above the fold",
                  "calls to action", "high", "",
                  "Could make it easier for people to get in touch.")
    row.finding_id = finding_id
    return row


class GoodDraftTests(TestCase):
    def test_a_draft_that_follows_the_brief_passes_every_check(self):
        self.assertEqual(ai.style_problem(email()), "")
        self.assertEqual(ai.draft_problem(email(), [finding()]), "")

    def test_it_lands_inside_the_word_budget(self):
        """250-500, and nearer 300 than 500."""
        count = len(EMAIL_BODY.split())

        self.assertGreaterEqual(count, ai.EMAIL_MIN_WORDS)
        self.assertLessEqual(count, ai.EMAIL_MAX_WORDS)
        self.assertLess(count, 400)

    def test_the_body_is_what_the_recipient_receives(self):
        """Nothing is appended at send time, so the word count is the whole email.

        This used to allow for a 19-word reply invitation added by `compose`. That
        invitation was removed, so the band the validator enforces is now the delivered
        length exactly.
        """
        delivered = compose.build_message(
            sender_name="Sam", sender_email="sam@agency.test",
            to_email="ciao@bella.example", subject="Hello", body=EMAIL_BODY,
        ).get_content()

        self.assertEqual(len(delivered.split()), len(EMAIL_BODY.split()))


class BannedWordingTests(TestCase):
    """The phrases that give a mass-sent or machine-written email away."""

    def _with(self, sentence: str) -> GeneratedEmail:
        """The good body with one sentence spliced into it."""
        return email(body=EMAIL_BODY.replace(
            "I had a look through your website this week.",
            f"I had a look through your website this week. {sentence}"))

    def test_the_template_openings_are_caught(self):
        for opener in ("I hope this email finds you well.",
                       "Hope you're doing well.",
                       "I wanted to reach out about your site.",
                       "I came across your website last week.",
                       "Dear business owner,",
                       "To whom it may concern,"):
            with self.subTest(opener=opener):
                self.assertIn("mass-sent",
                              ai.style_problem(self._with(opener)))

    def test_the_consultant_speak_from_section_nine_is_caught(self):
        for phrase in ("Your digital ecosystem needs work.",
                       "This could strengthen your digital presence.",
                       "We can unlock your online potential.",
                       "I recently conducted a comprehensive analysis.",
                       "This is a holistic approach to growth.",
                       "Time for a digital transformation.",
                       "Here is the potential business benefit.",
                       "This creates a seamless digital experience.",
                       "It will drive meaningful results."):
            with self.subTest(phrase=phrase[:34]):
                self.assertIn("mass-sent",
                              ai.style_problem(self._with(phrase)))

    def test_the_corporate_filler_is_caught(self):
        for word in ("leverage", "optimize", "enhance", "utilise",
                     "comprehensive", "maximise", "elevate", "seamless",
                     "robust"):
            with self.subTest(word=word):
                self.assertIn("mass-sent", ai.style_problem(
                    self._with(f"We could {word} the pages for you.")))

    def test_inflections_are_caught_not_only_the_base_word(self):
        """"optimized" is the form a model actually writes."""
        for word in ("optimized", "optimising", "leveraging", "enhanced",
                     "maximising", "streamlined"):
            with self.subTest(word=word):
                self.assertIn("mass-sent", ai.style_problem(
                    self._with(f"The pages could be {word} further.")))

    def test_saying_a_machine_wrote_it_is_caught(self):
        for phrase in ("I used AI to review the site.",
                       "Our automated scan found this.",
                       "Our system checked your website.",
                       "This was generated by our tool.",
                       "Our crawler read four pages."):
            with self.subTest(phrase=phrase):
                self.assertIn("mass-sent",
                              ai.style_problem(self._with(phrase)))

    def test_a_trade_word_that_looks_like_filler_is_allowed(self):
        """These leads are local businesses; their own trade words turn up.

        A lift company's "elevator servicing" and a locksmith's "unlocking
        service" are not corporate filler, and rewriting a draft for using one
        would be the check getting in the way.
        """
        for sentence in ("Your elevator servicing page has no pricing on it.",
                         "Your unlocking service page has no phone number."):
            with self.subTest(sentence=sentence[:30]):
                self.assertEqual(ai.style_problem(self._with(sentence)), "")

    def test_ordinary_words_containing_ai_are_not_caught(self):
        """Word boundaries: "email", "detail", "said", "available", "maintain"."""
        sentence = ("I said I would email the detail, and the notes are "
                    "available whenever you want to maintain the site.")

        self.assertEqual(ai.style_problem(self._with(sentence)), "")

    def test_the_subject_line_is_checked_too(self):
        problem = ai.style_problem(
            email(subject="Unlock your website's potential"))

        self.assertIn("mass-sent", problem)

    def test_the_subject_lines_the_brief_prefers_pass(self):
        for subject in ("A few things I noticed on Bella Cucina's website",
                        "Quick website feedback for Bella Cucina",
                        "Had a look at your website",
                        "Website feedback — Bella Cucina"):
            with self.subTest(subject=subject):
                self.assertEqual(ai.style_problem(email(subject=subject)), "")


class CallToActionTests(TestCase):
    """The CTA the brief asks for is allowed; the hard sell is not.

    This is the rule that reversed. The previous brief banned call-based CTAs and
    asked for "shall I send it over"; the current one asks for a call. It asks for an
    *untimed* one -- naming a length invites the reader to price the call rather than
    consider it -- so `call_duration_problem` refuses "15-minute" and its many
    spellings. What did not reverse is the pressure: no deadlines, no discounts, no
    "book now".
    """

    def test_the_untimed_call_is_what_the_reference_email_offers(self):
        self.assertIn("Would you be open to a quick call this week?", EMAIL_BODY)
        self.assertEqual(ai.style_problem(email()), "")
        self.assertEqual(ai.call_duration_problem(email()), "")

    def test_the_hard_sell_closes_are_still_caught(self):
        for close in ("Book your free consultation today.",
                      "Act now before this offer ends.",
                      "Limited time only.",
                      "Book a call now."):
            with self.subTest(close=close):
                body = EMAIL_BODY.replace(
                    "Would you be open to a quick call this week?", close)
                self.assertIn("mass-sent", ai.style_problem(email(body=body)))

    def test_the_alternative_soft_closes_are_allowed(self):
        for close in ("If you'd like, I can walk you through the specific "
                      "points I found and what I'd recommend changing.",
                      "Happy to show you the areas I noticed if you'd like to "
                      "take a look."):
            with self.subTest(close=close[:34]):
                body = EMAIL_BODY.replace(
                    "Would you be open to a quick call this week?", close)
                self.assertEqual(ai.style_problem(email(body=body)), "")


class ToneTests(TestCase):
    def test_flattery_is_caught(self):
        """Nobody who only read a website can call it beautiful and mean it."""
        for word in ("beautiful", "gorgeous", "stunning", "impressive"):
            with self.subTest(word=word):
                body = EMAIL_BODY.replace("your website this week",
                                          f"your {word} website this week")
                self.assertIn("flattery", ai.style_problem(email(body=body)))

    def test_pretending_to_be_a_fan_is_caught(self):
        body = EMAIL_BODY.replace("Hi there,",
                                  "Hi there,\n\nBig fan of what you do.")

        self.assertIn("flattery", ai.style_problem(email(body=body)))

    def test_shouting_is_caught(self):
        body = EMAIL_BODY.replace("no obvious way", "NO obvious WAY")

        self.assertIn("capitals", ai.style_problem(email(body=body)))

    def test_an_acronym_a_business_writes_itself_is_allowed(self):
        for acronym in ("VAT", "FAQ", "GDPR", "CEO"):
            with self.subTest(acronym=acronym):
                body = EMAIL_BODY.replace(
                    "no phone number on it",
                    f"no phone number and no {acronym} details on it")
                self.assertEqual(ai.style_problem(email(body=body)), "")

    def test_an_exclamation_mark_is_caught(self):
        body = EMAIL_BODY.replace("gives up.", "gives up!")

        self.assertIn("exclamation", ai.style_problem(email(body=body)))

    def test_a_long_email_is_caught(self):
        body = EMAIL_BODY + " " + (
            "There is also no booking link on the contact page, which could "
            "make it harder for someone to reach you. " * 20)

        self.assertIn("words", ai.style_problem(email(body=body)))

    def test_a_short_email_is_now_a_defect(self):
        """The floor came back with the longer brief.

        The email has to carry two or three findings *and* explain why each
        matters. 120 words cannot, so a short draft means the explanations were
        skipped -- which is the whole value of this email.
        """
        short = ("Hi there,\n\nI had a look at your site and there's no booking "
                 "link on the homepage. Happy to talk it through.\n\nSam")

        problem = ai.style_problem(email(body=short))

        self.assertIn("not enough to explain", problem)


class CombinedVerdictTests(TestCase):
    """One note, so a draft with several problems costs one rewrite, not three."""

    def test_every_problem_is_reported_together(self):
        bad = ("Hi there,\n\nI noticed some issues with your website that we "
               "could help you optimize.\n\nBook a call now.\n\nSam")

        problem = ai.draft_problem(email(body=bad), [finding()])

        self.assertIn("tells the reader nothing", problem)   # vague
        self.assertIn("mass-sent", problem)                  # corporate

    def test_an_untraceable_claim_is_reported(self):
        problem = ai.draft_problem(
            email(used=["AUD-404", "The colour scheme feels dated"]),
            [finding()])

        self.assertIn("does not match any verified finding", problem)

    def test_a_good_draft_produces_no_note(self):
        self.assertEqual(ai.draft_problem(email(), [finding()]), "")


class RewriteTests(SignedIn):
    """The checks have to reach the pipeline, not just exist."""

    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(
            self.campaign, subject="", body="",
            status=EmailDraft.Status.ANALYSED,
            pages_read=[{"url": "https://bella.example/", "kind": "home",
                         "facts": {"cta_count": 0, "platform": "WordPress",
                                   "load_ms": 900, "viewport_meta": True}}],
            findings=[finding().as_dict()])

    def test_a_corporate_draft_is_rewritten_once(self):
        corporate = email(body=EMAIL_BODY.replace(
            "I had a look through your website this week.",
            "I hope this email finds you well. I conducted a comprehensive "
            "analysis of your digital ecosystem."))

        with mock.patch.object(ai, "generate",
                               side_effect=[corporate, email()]) as gen:
            written = runner.generate_draft(self.draft, self.campaign)

        self.draft.refresh_from_db()
        self.assertTrue(written)
        self.assertEqual(gen.call_count, 2)
        self.assertIn("mass-sent", gen.call_args.kwargs["retry_hint"])
        self.assertEqual(self.draft.body, EMAIL_BODY)

    def test_a_good_draft_is_written_once(self):
        with mock.patch.object(ai, "generate", return_value=email()) as gen:
            runner.generate_draft(self.draft, self.campaign)

        self.assertEqual(gen.call_count, 1)

    def test_a_draft_that_stays_wrong_is_still_saved_for_review(self):
        """Two attempts, then a person reads it. Better than sending nothing."""
        bad = email(body=EMAIL_BODY.replace(
            "I had a look through your website this week.",
            "We can optimize your digital presence."))

        with mock.patch.object(ai, "generate", side_effect=[bad, bad]) as gen:
            written = runner.generate_draft(self.draft, self.campaign)

        self.draft.refresh_from_db()
        self.assertTrue(written)
        self.assertEqual(gen.call_count, 2)
        self.assertEqual(self.draft.status, EmailDraft.Status.GENERATED)


class PromptRulesTests(TestCase):
    """The rules the brief spells out, present in the prompt that enforces them."""

    def setUp(self):
        self.flat = " ".join(ai.SYSTEM.split())

    def test_the_banned_phrases_are_named_in_the_prompt(self):
        for phrase in ("I hope this message finds you well",
                       "I wanted to reach out", "I came across your website",
                       "leverage", "optimize", "comprehensive", "elevate"):
            with self.subTest(phrase=phrase):
                self.assertIn(phrase, self.flat)

    def test_the_prompt_forbids_mentioning_how_the_email_was_written(self):
        self.assertIn('never use the words "AI"', self.flat)
        self.assertIn("never mention how the email was written",
                      self.flat.lower())

    def test_the_prompt_asks_for_the_consultative_structure(self):
        for rule in ("as a customer, and for the business, search and technical",
                     "strongest first",
                     "one honest summary sentence"):
            with self.subTest(rule=rule[:34]):
                self.assertIn(rule, self.flat)

    def test_the_prompt_forbids_audit_report_labels(self):
        self.assertIn('Do not label them "Issue" and "Impact"', self.flat)

    def test_the_prompt_asks_for_an_untimed_call(self):
        self.assertIn("how I'd approach fixing it.", self.flat)
        self.assertIn("Would you be open to a quick call this week?", self.flat)

    def test_the_prompt_forbids_naming_a_length(self):
        self.assertIn("NEVER name a length for the call", self.flat)
        self.assertIn("15-minute call", self.flat)      # named as forbidden
        self.assertIn("half an hour", self.flat)

    def test_the_prompt_still_forbids_the_hard_sell(self):
        self.assertIn("book your free consultation today", self.flat)
        self.assertIn("no deadline, no discount", self.flat)

    def test_the_prompt_targets_the_longer_word_range(self):
        self.assertIn("250-500 words", self.flat)
        self.assertIn("closer to 300", self.flat)

    def test_the_prompt_forbids_recommending_a_newer_platform(self):
        """Section 13: WordPress that works is the right answer."""
        self.assertIn("never recommend replacing a platform", self.flat)
        self.assertIn("WordPress is the right answer", self.flat)

    def test_the_honesty_rules_survived_the_rewrite(self):
        """The style brief must not have loosened what may be claimed."""
        for rule in ("Never state anything you were not given",
                     "no problems beyond the supplied findings",
                     "ONE to THREE of the supplied findings",
                     "NEVER write a vague version of a finding"):
            with self.subTest(rule=rule[:34]):
                self.assertIn(rule, self.flat)


class GreetingTests(TestCase):
    """Every outgoing email opens with "Hi there,".

    Checked rather than appended, and that is the design worth stating: the old reply
    invitation was appended at the other end of the email and had to be idempotent to
    survive an edit. A greeting cannot be appended safely at all -- the model writes one
    most of the time, so prepending would produce two. So the prompt asks for it and the
    validator rejects the draft that ignored it, which keeps exactly one greeting,
    written by whoever wrote the sentence after it.
    """

    def _email(self, body):
        return email(body=body)

    def test_the_expected_greeting_passes(self):
        self.assertEqual(
            ai.greeting_problem(self._email("Hi there,\n\nI had a look.")), "")

    def test_the_reference_body_already_opens_correctly(self):
        """The fixture the rest of the suite treats as a good email."""
        self.assertEqual(ai.greeting_problem(email(body=EMAIL_BODY)), "")
        self.assertTrue(EMAIL_BODY.startswith(ai.GREETING))

    def test_no_greeting_at_all_is_rejected(self):
        problem = ai.greeting_problem(
            self._email("I had a look through your website this week."))

        self.assertIn(ai.GREETING, problem)
        self.assertIn("own line", problem)

    def test_a_different_greeting_is_rejected(self):
        for opening in ("Hello,", "Hey,", "Good morning,", "Greetings,",
                        "Dear Sir/Madam,", "To whom it may concern,"):
            with self.subTest(opening=opening):
                problem = ai.greeting_problem(
                    self._email(f"{opening}\n\nI had a look."))

                self.assertIn("Open with exactly", problem)
                self.assertIn(ai.GREETING, problem)

    def test_a_first_name_is_rejected(self):
        """Nothing in a campaign draft carries a person's name, so one is a guess.

        `EmailDraft` has `business_name` and no contact name at all -- a cold email that
        opens with the wrong name is worse than one that opens with none.
        """
        problem = ai.greeting_problem(self._email("Hi Marco,\n\nI had a look."))

        self.assertIn("Do not use a name", problem)

    def test_the_business_name_as_a_greeting_is_rejected(self):
        problem = ai.greeting_problem(self._email("Hi Bella Cucina,\n\nI had a look."))

        self.assertIn("Do not use a name", problem)

    def test_case_and_surrounding_space_are_forgiven(self):
        """A greeting is a greeting; the model's capitalisation is not worth a retry."""
        for body in ("hi there,\n\nI had a look.",
                     "HI THERE,\n\nI had a look.",
                     "  Hi there,  \n\nI had a look.",
                     "\n\nHi there,\n\nI had a look."):
            with self.subTest(body=body):
                self.assertEqual(ai.greeting_problem(email(body=body)), "")

    def test_a_greeting_word_inside_a_sentence_is_not_a_greeting(self):
        """Only the first line is examined, so "hello" in prose is not a false pass."""
        problem = ai.greeting_problem(
            self._email("I wanted to say hello about your website."))

        self.assertIn("Start the email with", problem)

    def test_an_empty_body_is_left_to_the_other_checks(self):
        """An empty body is a different failure, reported by its own validator."""
        self.assertEqual(ai.greeting_problem(self._email("")), "")

    def test_the_full_verdict_includes_the_greeting(self):
        """`draft_problem` is what the pipeline calls, so the check has to reach it."""
        problem = ai.draft_problem(
            email(body="I had a look through your website this week."), [])

        self.assertIn(ai.GREETING, problem)


class GreetingPromptTests(TestCase):
    """The prompt has to ask for what the validator enforces.

    A validator without the matching instruction just burns an extra AI call on every
    email, so these assert the two agree -- for all three prompts that produce an email.
    """

    def test_the_email_prompt_asks_for_it(self):
        for style in styles.STYLES.values():
            with self.subTest(style=style.key):
                system = prompts.system_for(style)

                self.assertIn(f'"{ai.GREETING}"', system)
                self.assertIn("on its own line", system)

    def test_the_follow_up_prompt_asks_for_it(self):
        self.assertIn(f'"{ai.GREETING}"', prompts.FOLLOWUP_SYSTEM)

    def test_the_no_website_prompt_asks_for_it(self):
        self.assertIn(f'"{ai.GREETING}"', prompts.NO_WEBSITE_SYSTEM)

    def test_every_prompt_forbids_guessing_a_name(self):
        for system in (prompts.system_for(styles.DEFAULT_STYLE),
                       prompts.FOLLOWUP_SYSTEM, prompts.NO_WEBSITE_SYSTEM):
            with self.subTest(system=system[:40]):
                self.assertIn("never a first name", system.casefold())

    def test_no_prompt_still_promises_an_appended_reply_line(self):
        """The reply invitation was removed; a prompt still promising it would leave
        the model closing the email as though something followed."""
        for system in (prompts.system_for(styles.CONSULTATIVE),
                       prompts.system_for(styles.BRIEF),
                       prompts.FOLLOWUP_SYSTEM, prompts.NO_WEBSITE_SYSTEM):
            with self.subTest(system=system[:40]):
                self.assertNotIn("reply line is added", system)
                self.assertNotIn("added automatically", system)


class CallDurationTests(TestCase):
    """The offered call has no length attached to it.

    Written as a pattern rather than a phrase list, because the wordings are endless and
    a list is always one spelling behind the model. These tests are the spellings worth
    being sure about, and the near-misses that must not be caught.
    """

    def _email(self, close):
        return email(body=f"Hi there,\n\nI had a look.\n\n{close}")

    def test_the_wanted_close_passes(self):
        close = ("If you're open to it, I'd be happy to walk you through what I found "
                 "and how I'd approach fixing it. Would you be open to a quick call "
                 "this week?")

        self.assertEqual(ai.call_duration_problem(self._email(close)), "")

    def test_the_old_close_is_now_refused(self):
        """What the prompt used to ask for, and no longer does."""
        close = ("...how I'd approach fixing it on a quick 15-minute call. Would you "
                 "be open to a short call this week?")

        problem = ai.call_duration_problem(self._email(close))

        self.assertIn("15-minute", problem)
        self.assertIn("do not name a length", problem)

    def test_every_spelling_of_a_duration_is_caught(self):
        for close in ("a quick 15-minute call",
                      "a 15 minute call",
                      "a fifteen-minute call",
                      "a thirty minute chat",
                      "30 mins of your time",
                      "just 10 mins",
                      "half an hour",
                      "quarter of an hour",
                      "a 1 hour session",
                      "a 2-hour workshop",
                      "a 45-minute review"):
            with self.subTest(close=close):
                self.assertIn("do not name a length",
                              ai.call_duration_problem(self._email(close)))

    def test_a_unicode_hyphen_is_caught(self):
        """What a provider actually returns: "15‑minute" with a U+2011, not a "-"."""
        self.assertIn("do not name a length",
                      ai.call_duration_problem(self._email("a quick 15‑minute call")))
        self.assertIn("do not name a length",
                      ai.call_duration_problem(self._email("a 15–minute call")))

    def test_numbers_that_are_not_durations_are_left_alone(self):
        """The check must not become a ban on numbers.

        A year count, a page count and a clock time are all legitimate, and catching one
        of them would send a good draft back for a rewrite.
        """
        for close in ("You have been serving Delft for 20 years.",
                      "I looked at 4 pages of the site.",
                      "I can send over 3 examples.",
                      "Would Tuesday at 3pm suit you?",
                      "Your menu lists 12 dishes.",
                      "The 2024 opening hours are still on the contact page."):
            with self.subTest(close=close[:32]):
                self.assertEqual(ai.call_duration_problem(self._email(close)), "")

    def test_the_reference_email_offers_an_untimed_call(self):
        self.assertEqual(ai.call_duration_problem(email(body=EMAIL_BODY)), "")
        self.assertIn("Would you be open to a quick call this week?", EMAIL_BODY)
        self.assertNotIn("15-minute", EMAIL_BODY)

    def test_the_full_verdict_includes_it(self):
        """`draft_problem` is what the pipeline calls, so the check has to reach it."""
        body = EMAIL_BODY.replace(
            "Would you be open to a quick call this week?",
            "Would you be open to a 15-minute call this week?")

        self.assertIn("do not name a length", ai.draft_problem(email(body=body), []))

    def test_it_is_not_a_metric_complaint(self):
        """Two objections, kept apart. A duration is a sales tactic, not a measurement."""
        body = EMAIL_BODY.replace(
            "Would you be open to a quick call this week?",
            "Would you be open to a 15-minute call this week?")

        self.assertEqual(ai.specificity_problem(email(body=body), []), "")
        self.assertIn("do not name a length",
                      ai.call_duration_problem(email(body=body)))
