"""
Turning a provider's answer into something typed.

`ai.parse` is shared by every backend, so it is tested once and on its own: valid JSON
becomes an email, malformed JSON is an error rather than a half-filled object, and an
array where an object was promised is an error too.
"""

from __future__ import annotations

from apps import ai
from apps.core.testing import SignedIn

from .factories import make_findings


class AuditParseTests(SignedIn):
    def _payload(self, findings):
        import json as _json

        return _json.dumps({"business_summary": "A pizzeria.", "findings": findings})

    def test_findings_are_parsed_and_ordered_strongest_first(self):
        result = ai.parse_audit(self._payload([
            {"issue": "B", "evidence": "e", "why_it_matters": "w",
             "suggested_improvement": "s", "dimension": "seo", "severity": "low",
             "page_url": "u"},
            {"issue": "A", "evidence": "e", "why_it_matters": "w",
             "suggested_improvement": "s", "dimension": "cta", "severity": "high",
             "page_url": "u"},
        ]))

        self.assertEqual(result.business_summary, "A pizzeria.")
        self.assertEqual([f.issue for f in result.findings], ["A", "B"])

    def test_a_finding_with_no_evidence_is_discarded(self):
        """The evidence rule is enforced in code, not just asked for.

        A finding with an empty evidence field is exactly the speculation the
        prompt forbids, so it must never reach the user looking verified.
        """
        result = ai.parse_audit(self._payload([
            {"issue": "Real", "evidence": "cta_count=0", "why_it_matters": "w",
             "suggested_improvement": "s", "severity": "high"},
            {"issue": "Made up", "evidence": "", "why_it_matters": "w",
             "suggested_improvement": "s", "severity": "high"},
        ]))

        self.assertEqual([f.issue for f in result.findings], ["Real"])

    def test_more_than_ten_findings_are_capped(self):
        rows = [
            {"issue": f"I{i}", "evidence": "e", "why_it_matters": "w",
             "suggested_improvement": "s", "severity": "medium"}
            for i in range(18)
        ]

        self.assertEqual(len(ai.parse_audit(self._payload(rows)).findings),
                         ai.MAX_FINDINGS)

    def test_no_evidenced_findings_at_all_is_an_error(self):
        with self.assertRaises(ai.AiError) as caught:
            ai.parse_audit(self._payload([
                {"issue": "x", "evidence": "", "why_it_matters": "",
                 "suggested_improvement": ""}]))

        self.assertIn("no findings backed by evidence", str(caught.exception))

    def test_a_finding_round_trips_through_storage(self):
        original = make_findings(1)[0]
        restored = ai.Finding.from_dict(original.as_dict())

        self.assertEqual(restored, original)
class ParseTests(SignedIn):
    """ai.parse() is shared by every provider, so it is tested on its own."""

    def test_valid_json_becomes_a_generated_email(self):
        email = ai.parse(
            '{"subject": "Booking for Bella Cucina", "body": "Hi there.\\n\\nSam",'
            ' "observation": "wood-fired pizza since 1998"}'
        )

        self.assertEqual(email.subject, "Booking for Bella Cucina")
        self.assertIn("Sam", email.body)
        self.assertEqual(email.observation, "wood-fired pizza since 1998")

    def test_a_fenced_code_block_is_unwrapped(self):
        # Some models wrap JSON in ```json despite being told not to.
        email = ai.parse(
            '```json\n{"subject": "s", "body": "b", "observation": "o"}\n```')

        self.assertEqual(email.subject, "s")

    def test_malformed_json_is_an_error(self):
        with self.assertRaises(ai.AiError):
            ai.parse("not json at all")

    def test_empty_text_is_an_error(self):
        with self.assertRaises(ai.AiError):
            ai.parse("   ")

    def test_a_json_array_is_an_error(self):
        with self.assertRaises(ai.AiError):
            ai.parse('["not", "an", "object"]')

    def test_empty_subject_is_an_error(self):
        with self.assertRaises(ai.AiError):
            ai.parse('{"subject": "", "body": "x", "observation": "y"}')

    def test_missing_observation_defaults_to_none(self):
        self.assertEqual(
            ai.parse('{"subject": "s", "body": "b", "observation": ""}').observation,
            "none",
        )
