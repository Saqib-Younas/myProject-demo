"""
The email is built on the crawler's actual findings.

The failure this whole module exists to prevent is one sentence:

    "I noticed some issues with your website."

It is what a model writes when it has been handed a URL and nothing else, and it
is worse than useless -- it says the site was looked at while proving it was not.
So the pipeline hands the email stage *structured evidence*: which pages were
read, what was measured on them, and the findings those measurements support,
ranked by what actually costs the business money.

Four things are tested here:

  * **the ranking** -- which one to three findings an email may use, in the
    brief's commercial order rather than in the order they were easiest to
    measure;
  * **the prompt** -- that the evidence arrives as data, with severity, the
    measurement, the business cost and the page it was found on;
  * **the guard** -- that a generic email, or one quoting a metric at a business
    owner, is caught rather than sent;
  * **the wiring** -- that the pipeline does all of the above for a real lead.

No AI provider and no website is contacted: every call is a double.
"""

from __future__ import annotations

from unittest import mock

from django.test import TestCase

from apps import ai
from apps.ai.base import Finding, GeneratedEmail
from apps.auditing import crawler, scoring
from apps.core.testing import EMAIL_BODY, SignedIn
from apps.outreach.models import EmailDraft
from apps.outreach.services import pipeline as runner
from apps.outreach.tests.factories import make_campaign, make_draft


def finding(issue="The homepage has no page title",
            evidence="title_length=0 on the homepage",
            why="Search results show a bare web address instead of a name",
            fix="Add a descriptive title",
            dimension="SEO basics", severity="medium", page_url="") -> Finding:
    return Finding(issue=issue, evidence=evidence, why_it_matters=why,
                   suggested_improvement=fix, dimension=dimension,
                   severity=severity, page_url=page_url)


# --------------------------------------------------------------------------- #
# Which findings belong in an email
# --------------------------------------------------------------------------- #

class CommercialRankingTests(TestCase):
    """Section 6: prioritise by what it costs the business, not by tidiness."""

    def test_the_ladder_is_in_the_briefs_order(self):
        cases = [
            ("Broken functionality", "The booking form does not submit", 1),
            ("Conversion", "No call to action above the fold", 2),
            ("Mobile responsiveness", "The site does not adapt to phones", 3),
            ("Performance indicators", "The homepage is slow to load", 4),
            ("Content quality", "The services page is very thin", 5),
            ("SEO basics", "The homepage has no page title", 6),
            ("Accessibility", "Several images have no alt text", 7),
        ]
        for dimension, issue, tier in cases:
            with self.subTest(dimension=dimension):
                self.assertEqual(
                    scoring.commercial_tier(
                        finding(issue=issue, dimension=dimension)), tier)

    def test_broken_functionality_outranks_a_missing_title(self):
        broken = finding(issue="The contact form does not work",
                         dimension="forms", severity="low")
        seo = finding(issue="Missing page title", dimension="SEO basics",
                      severity="high")

        ranked = scoring.rank_for_email([seo, broken])

        # Severity high loses to a lower-severity finding in a higher tier: a
        # broken form costs enquiries today, a missing title costs ranking.
        self.assertEqual(ranked[0].issue, "The contact form does not work")

    def test_a_conversion_problem_outranks_a_technical_one(self):
        technical = finding(issue="No favicon", dimension="technical detail")
        conversion = finding(issue="No obvious way to enquire",
                             dimension="calls to action")

        ranked = scoring.rank_for_email([technical, conversion])

        self.assertEqual(ranked[0].dimension, "calls to action")

    def test_severity_breaks_ties_inside_a_tier(self):
        low = finding(issue="Alt text missing on two images",
                      dimension="SEO basics", severity="low")
        high = finding(issue="No page title at all", dimension="SEO basics",
                       severity="high")

        self.assertEqual(scoring.rank_for_email([low, high])[0], high)

    def test_the_reviewers_order_survives_an_exact_tie(self):
        first = finding(issue="First", dimension="SEO basics", severity="high")
        second = finding(issue="Second", dimension="SEO basics", severity="high")

        self.assertEqual(
            [f.issue for f in scoring.rank_for_email([first, second])],
            ["First", "Second"])

    def test_the_dimension_is_believed_over_the_issue_text(self):
        """The reviewer chose the dimension deliberately."""
        row = finding(issue="Visitors cannot tell what to do next",
                      dimension="mobile responsiveness")

        self.assertEqual(scoring.commercial_tier(row), 3)

    def test_an_unrecognised_finding_is_not_buried(self):
        """A real issue described in unfamiliar words must not rank last."""
        row = finding(issue="The opening times contradict each other",
                      dimension="something nobody has named yet")

        self.assertEqual(scoring.commercial_tier(row), scoring.DEFAULT_TIER)
        self.assertLess(scoring.commercial_tier(row), 7)

    def test_at_most_three_findings_reach_the_email(self):
        many = [finding(issue=f"Issue {i}", dimension="SEO basics")
                for i in range(9)]

        self.assertEqual(len(scoring.rank_for_email(many)),
                         scoring.EMAIL_FINDING_LIMIT)
        self.assertEqual(scoring.EMAIL_FINDING_LIMIT, 3)

    def test_the_limit_can_be_narrowed(self):
        many = [finding(issue=f"Issue {i}") for i in range(5)]

        self.assertEqual(len(scoring.rank_for_email(many, limit=1)), 1)

    def test_an_unevidenced_finding_is_dropped(self):
        """The cheapest place to stop an invented website problem.

        A finding with no evidence is exactly what this application must never put
        in an email, so it never reaches the prompt.
        """
        real = finding(issue="No page title", evidence="title_length=0")
        invented = finding(issue="The colour scheme feels dated", evidence="")

        ranked = scoring.rank_for_email([invented, real])

        self.assertEqual([f.issue for f in ranked], ["No page title"])

    def test_a_finding_with_no_issue_text_is_dropped(self):
        self.assertEqual(scoring.rank_for_email([finding(issue="  ")]), [])

    def test_nothing_in_gives_nothing_out(self):
        self.assertEqual(scoring.rank_for_email([]), [])
        self.assertEqual(scoring.rank_for_email(None), [])


# --------------------------------------------------------------------------- #
# What the model is actually sent
# --------------------------------------------------------------------------- #

class StructuredEvidenceTests(TestCase):
    """Section 5: not the URL. The pages, the measurements and the findings."""

    def setUp(self):
        self.pages = [
            {"url": "https://bella.example/", "kind": "home",
             "facts": {"cta_count": 0, "load_ms": 3200}},
            {"url": "https://bella.example/contact", "kind": "contact",
             "facts": {"forms": 0, "tel_links": 0}},
        ]
        self.signals = {"cta_count": 0, "load_ms": 3200, "forms": 0,
                        "title_length": 0, "viewport_meta": False}
        self.findings = [
            finding(issue="No obvious way to get in touch on the homepage",
                    evidence="cta_count=0 on the homepage",
                    dimension="calls to action", severity="high"),
        ]

    def _prompt(self, **overrides):
        kwargs = dict(
            business_name="Bella Cucina", category="Restaurant", city="Delft",
            country="Netherlands", website="https://bella.example",
            sender_name="Sam Rivers", sender_company="Northline",
            sender_email="sam@northline.test",
            service_pitch="We build booking sites.",
            findings=self.findings, pages=self.pages, signals=self.signals,
        )
        kwargs.update(overrides)
        return ai.build_prompt(**kwargs)

    def test_the_pages_that_were_read_are_listed(self):
        prompt = self._prompt()

        self.assertIn("PAGES ANALYSED", prompt)
        self.assertIn("https://bella.example/contact", prompt)
        self.assertIn("contact:", prompt)

    def test_the_measured_signals_are_supplied_with_their_meaning(self):
        prompt = self._prompt()

        self.assertIn("MEASURED SIGNALS", prompt)
        self.assertIn("cta_count = 0", prompt)
        self.assertIn("obvious ways to get in touch", prompt)

    def test_the_signals_are_marked_as_not_for_quoting(self):
        prompt = self._prompt()

        self.assertIn("NEVER put a", prompt)
        self.assertIn("number or a metric name in the email", prompt)

    def test_each_finding_carries_its_full_structure(self):
        prompt = self._prompt()

        self.assertIn("No obvious way to get in touch on the homepage", prompt)
        self.assertIn("Severity: high", prompt)
        self.assertIn("Area: calls to action", prompt)
        self.assertIn("cta_count=0 on the homepage", prompt)
        self.assertIn("What it costs them:", prompt)
        self.assertIn("Fix:", prompt)

    def test_the_findings_are_named_as_the_only_problems_that_exist(self):
        self.assertIn("ONLY website problems", self._prompt())

    def test_the_page_a_finding_was_found_on_is_included(self):
        prompt = self._prompt()

        self.assertIn("Found on: https://bella.example/", prompt)

    def test_nothing_is_sent_when_there_is_nothing_measured(self):
        """A lead with no findings must not be handed metrics to embroider."""
        prompt = self._prompt(findings=[])

        self.assertNotIn("MEASURED SIGNALS", prompt)
        self.assertNotIn("PAGES ANALYSED", prompt)
        self.assertIn("none available", prompt)
        self.assertIn("Do not imply you looked at their website", prompt)

    def test_the_sender_details_still_come_last(self):
        prompt = self._prompt()

        self.assertLess(prompt.index("VERIFIED WEBSITE FINDINGS"),
                        prompt.index("ABOUT THE SENDER"))
        self.assertIn("sam@northline.test", prompt)


class PageAttributionTests(TestCase):
    """A finding's page URL is derived from the crawl, never invented."""

    PAGES = [
        {"url": "https://bella.example/", "kind": "home"},
        {"url": "https://bella.example/contact", "kind": "contact"},
        {"url": "https://bella.example/menu", "kind": "services"},
    ]

    def test_a_url_quoted_in_the_evidence_is_used(self):
        row = finding(evidence="title_length=0 at https://bella.example/menu")

        ai.attribute_pages([row], self.PAGES)

        self.assertEqual(row.page_url, "https://bella.example/menu")

    def test_a_named_page_kind_is_matched(self):
        row = finding(issue="The contact page has no form",
                      evidence="forms=0")

        ai.attribute_pages([row], self.PAGES)

        self.assertEqual(row.page_url, "https://bella.example/contact")

    def test_the_homepage_is_matched_by_name(self):
        row = finding(evidence="cta_count=0 on the homepage")

        ai.attribute_pages([row], self.PAGES)

        self.assertEqual(row.page_url, "https://bella.example/")

    def test_an_unattributable_finding_gets_no_url(self):
        """Blank, not a guess: a URL invented to fill a field is a false claim."""
        row = finding(issue="Several images have no alt text",
                      evidence="images_missing_alt=6 across the site")

        ai.attribute_pages([row], self.PAGES)

        self.assertEqual(row.page_url, "")

    def test_only_crawled_urls_are_ever_used(self):
        row = finding(evidence="found at https://bella.example/pricing")

        ai.attribute_pages([row], self.PAGES)

        self.assertNotIn("pricing", row.page_url)

    def test_an_existing_attribution_is_left_alone(self):
        row = finding(page_url="https://bella.example/menu",
                      evidence="cta_count=0 on the homepage")

        ai.attribute_pages([row], self.PAGES)

        self.assertEqual(row.page_url, "https://bella.example/menu")

    def test_no_pages_means_no_attribution_and_no_error(self):
        row = finding()

        ai.attribute_pages([row], [])

        self.assertEqual(row.page_url, "")


class SystemPromptTests(TestCase):
    """The rules the brief spells out, present in the prompt that enforces them."""

    def test_generic_phrasing_is_forbidden_by_name(self):
        self.assertIn("some issues with your website", ai.SYSTEM)
        self.assertIn("NEVER write a vague version of a finding", ai.SYSTEM)

    def test_metric_quoting_is_forbidden_by_name(self):
        self.assertIn("must NOT put them in the email", ai.SYSTEM)
        for term in ("LCP", "load_ms", "cta_count"):
            with self.subTest(term=term):
                self.assertIn(term, ai.SYSTEM)

    def test_the_translation_is_demonstrated_rather_than_demanded(self):
        self.assertIn("takes a noticeable moment to load on mobile", ai.SYSTEM)
        self.assertIn("does not adapt to phone screens", ai.SYSTEM)

    def test_one_to_three_findings(self):
        self.assertIn("ONE to THREE of the supplied findings", ai.SYSTEM)

    def test_the_ranking_is_explained_to_the_model(self):
        self.assertIn("ranked by commercial importance", ai.SYSTEM)


# --------------------------------------------------------------------------- #
# Catching a generic email
# --------------------------------------------------------------------------- #

class SpecificityGuardTests(TestCase):
    """A prompt instruction is a request. This is the check."""

    FINDINGS = [finding(issue="The homepage has no page title")]

    def _email(self, body, observation="the homepage has no title",
               used=("The homepage has no page title",)):
        return GeneratedEmail("A quick note on your site", body, observation,
                              list(used))

    def test_the_exact_phrase_from_the_brief_is_caught(self):
        problem = ai.specificity_problem(
            self._email("Hello,\n\nI noticed some issues with your website and "
                        "thought I would reach out.\n\nSam"),
            self.FINDINGS)

        self.assertIn("tells the reader nothing", problem)
        self.assertIn("The homepage has no page title", problem)

    def test_other_ways_of_saying_nothing_are_caught(self):
        for body in ("There are a few areas for improvement on your site.",
                     "Your website could be better optimised for mobile.",
                     "I noticed a few things that could be improved.",
                     "I spotted some opportunities to improve the site."):
            with self.subTest(body=body[:32]):
                self.assertTrue(
                    ai.specificity_problem(self._email(body), self.FINDINGS))

    def test_a_metric_name_is_caught(self):
        problem = ai.specificity_problem(
            self._email("Your LCP is above the recommended threshold."),
            self.FINDINGS)

        self.assertIn("technical term", problem)

    def test_a_quoted_measurement_is_caught(self):
        for body in ("The homepage takes 4.8 seconds to load.",
                     "The page weighs 2100kb on mobile.",
                     "12 of 14 images have no alt text.",
                     "It responds in 920ms."):
            with self.subTest(body=body[:28]):
                problem = ai.specificity_problem(self._email(body),
                                                 self.FINDINGS)
                self.assertIn("quotes a measurement", problem)

    def test_a_specific_email_passes(self):
        problem = ai.specificity_problem(
            self._email("Hello,\n\nI had a look at your site and noticed the "
                        "homepage has no page title, so it shows as a bare web "
                        "address in search results.\n\nSam"),
            self.FINDINGS)

        self.assertEqual(problem, "")

    def test_ordinary_numbers_are_not_measurements(self):
        """20 years in business and 3 examples are not metrics.

        `specificity_problem` is about measurements leaking out of the audit trail, so a
        number that is not a measurement must not trip it. A number of *minutes* is also
        not a measurement and is not caught here -- it is refused for a different reason,
        by `call_duration_problem`, and the test below keeps the two apart.
        """
        for body in ("You have been serving Delft for 20 years.",
                     "I can send over 3 examples if that helps.",
                     "Your menu page lists 12 dishes."):
            with self.subTest(body=body[:28]):
                self.assertEqual(
                    ai.specificity_problem(self._email(body), self.FINDINGS), "")

    def test_a_call_duration_is_refused_but_not_as_a_measurement(self):
        """Two different objections, kept separate.

        Naming a length for the call is a sales-tactic problem, not an invented-metric
        problem. Folding it into the metric check would have made the metric check's
        numeric patterns wide enough to catch "20 years" as well.
        """
        body = "Would a 15-minute call next week suit you?"

        self.assertEqual(
            ai.specificity_problem(self._email(body), self.FINDINGS), "")
        self.assertIn("do not name a length",
                      ai.call_duration_problem(self._email(body)))

    def test_reporting_nothing_while_holding_findings_is_caught(self):
        problem = ai.specificity_problem(
            self._email("A specific and well written email.",
                        observation="none", used=()),
            self.FINDINGS)

        self.assertIn("no findings and no observation", problem)

    def test_an_untidy_audit_trail_alone_is_not_worth_a_second_call(self):
        """A missing list with a real observation costs nothing to leave alone."""
        problem = ai.specificity_problem(
            self._email("The homepage has no page title, so search results show "
                        "a bare address.",
                        observation="the homepage has no page title", used=()),
            self.FINDINGS)

        self.assertEqual(problem, "")

    def test_nothing_is_demanded_of_a_lead_with_no_findings(self):
        """There was nothing to be specific about, and the prompt says so."""
        problem = ai.specificity_problem(
            self._email("I could not reach your website, but I work with "
                        "restaurants in Delft.", observation="none", used=()),
            [])

        self.assertEqual(problem, "")


# --------------------------------------------------------------------------- #
# The pipeline, end to end
# --------------------------------------------------------------------------- #

class EmailFromRealFindingsTests(SignedIn):
    """The wiring: a crawled lead's own measurements reach its email."""

    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(
            self.campaign, subject="", body="",
            status=EmailDraft.Status.ANALYSED,
            analysis_status=crawler.OK,
            analysis_note="Read 2 page(s).",
            analysis_context="--- HOME\ncta_count=0",
            pages_read=[
                {"url": "https://bella.example/", "kind": "home",
                 "facts": {"cta_count": 0, "load_ms": 3400, "title_length": 0}},
                {"url": "https://bella.example/contact", "kind": "contact",
                 "facts": {"forms": 0, "cta_count": 1}},
            ],
            findings=[
                finding(issue="No favicon", dimension="technical detail",
                        evidence="favicon missing").as_dict(),
                finding(issue="The homepage has no obvious way to get in touch",
                        evidence="cta_count=0 on the homepage",
                        dimension="calls to action", severity="high").as_dict(),
                finding(issue="Several images have no alt text",
                        evidence="images_missing_alt=6",
                        dimension="SEO basics").as_dict(),
                finding(issue="The homepage has no page title",
                        evidence="title_length=0", dimension="SEO basics",
                        severity="high").as_dict(),
            ],
        )

    def _generate(self, email=None, side_effect=None):
        good = email or GeneratedEmail(
            "A thought on your contact page", EMAIL_BODY,
            "no obvious way to get in touch on the homepage",
            ["The homepage has no obvious way to get in touch"])
        with mock.patch.object(ai, "generate",
                               side_effect=side_effect,
                               return_value=None if side_effect else good) as gen:
            runner.generate_draft(self.draft, self.campaign)
        return gen

    def test_the_commercially_strongest_finding_leads(self):
        gen = self._generate()

        findings = gen.call_args.kwargs["findings"]
        self.assertEqual(findings[0].issue,
                         "The homepage has no obvious way to get in touch")
        # The favicon did not make the cut at all.
        self.assertNotIn("No favicon", [f.issue for f in findings])

    def test_the_leads_own_measurements_are_sent(self):
        gen = self._generate()

        signals = gen.call_args.kwargs["signals"]
        self.assertEqual(signals["load_ms"], 3400)
        self.assertEqual(signals["title_length"], 0)

    def test_the_pages_that_were_read_are_sent(self):
        gen = self._generate()

        urls = [p["url"] for p in gen.call_args.kwargs["pages"]]
        self.assertEqual(urls, ["https://bella.example/",
                                "https://bella.example/contact"])

    def test_a_generic_email_is_rewritten_once(self):
        generic = GeneratedEmail(
            "A quick note", "Hello,\n\nI noticed some issues with your website.\n\nSam",
            "the site", ["The homepage has no page title"])
        specific = GeneratedEmail(
            "Your homepage title", "Hello,\n\nYour homepage has no page title.\n\nSam",
            "the homepage has no page title",
            ["The homepage has no page title"])

        gen = self._generate(side_effect=[generic, specific])

        self.draft.refresh_from_db()
        self.assertEqual(gen.call_count, 2)
        # The second attempt was told what was wrong with the first.
        self.assertIn("tells the reader nothing",
                      gen.call_args.kwargs["retry_hint"])
        self.assertEqual(self.draft.body, specific.body)

    def test_a_specific_email_is_written_once(self):
        gen = self._generate()

        self.assertEqual(gen.call_count, 1)

    def test_a_stubbornly_generic_email_is_still_saved_for_review(self):
        """A person reads every email before it goes. Two attempts, then their turn."""
        generic = GeneratedEmail(
            "A quick note", "Hello,\n\nI noticed some issues with your site.\n\nSam",
            "the site", ["The homepage has no page title"])

        gen = self._generate(side_effect=[generic, generic])

        self.draft.refresh_from_db()
        self.assertEqual(gen.call_count, 2)
        self.assertEqual(self.draft.status, EmailDraft.Status.GENERATED)
        self.assertTrue(self.draft.body)

    def test_a_lead_with_no_findings_is_not_rewritten(self):
        """Nothing was measured, so there is nothing to be specific about."""
        EmailDraft.objects.filter(pk=self.draft.pk).update(
            findings=[], pages_read=[], analysis_status=crawler.BLOCKED)
        self.draft.refresh_from_db()

        honest = GeneratedEmail("Restaurants in Delft", EMAIL_BODY, "none", [])
        gen = self._generate(email=honest)

        self.assertEqual(gen.call_count, 1)
        self.assertEqual(gen.call_args.kwargs["findings"], [])
