"""Tests for the prompts, the backends and the credential store.

The prompts are tested as text, because the promise they carry -- evidence or silence --
is made in words and can be broken by editing them. The backends are tested one at a
time, because each provider fails differently and a shared test would hide exactly
that.

No test in this package calls a paid API. The one that once did, by accident, is why
they patch `ai.client.backend` rather than `ai.backend`: `_complete` resolves the name
in `client`, so patching the package attribute left the real provider in place.
"""
