"""
Where each provider's key is allowed to come from.

Three providers, three resolution orders, and one rule they share: an environment
variable and a stored credential can both be present, and which one wins has to be
decided rather than discovered. The Claude case also accepts an `ant auth login`
profile, which is why it reads a file.

These joined `test_credentials.py` in the same app but stayed a separate module: that
file is about the credential *store* -- encryption, masking, ownership, the pool --
and this one is about resolution order.
"""

from __future__ import annotations

import os
import tempfile
from pathlib import Path
from unittest import mock

from apps import ai
from apps.ai import credentials
from apps.ai.backends import claude as ai_claude
from apps.ai.backends import gemini as ai_gemini
from apps.ai.backends import groq as ai_groq
from apps.core.testing import SignedIn


class GeminiCredentialTests(SignedIn):
    def _describe(self, env):
        import os

        clean = {k: v for k, v in os.environ.items()
                 if k not in ai_gemini.KEY_VARS}
        clean.update(env)
        with mock.patch.dict(os.environ, clean, clear=True):
            return ai_gemini.describe_credentials()

    def test_gemini_api_key_is_used(self):
        usable, source, _ = self._describe({"GEMINI_API_KEY": "AQ.xyz"})

        self.assertTrue(usable)
        self.assertIn("GEMINI_API_KEY", source)

    def test_google_api_key_also_works(self):
        usable, source, _ = self._describe({"GOOGLE_API_KEY": "AIza-xyz"})

        self.assertTrue(usable)
        self.assertIn("GOOGLE_API_KEY", source)

    def test_no_key_points_at_ai_studio(self):
        usable, _, advice = self._describe({})

        self.assertFalse(usable)
        self.assertIn("aistudio.google.com", advice)

    def test_an_empty_key_is_caught(self):
        usable, source, _ = self._describe({"GEMINI_API_KEY": "  "})

        self.assertFalse(usable)
        self.assertIn("empty", source)

    def test_the_resolved_key_is_passed_to_the_client(self):
        """The key may have come from Settings, which the SDK cannot discover."""
        resolved = credentials.Credential(
            provider="gemini", source=credentials.DATABASE, key="AIza-resolved")

        with mock.patch.object(credentials, "require", return_value=resolved), \
             mock.patch.object(ai_gemini, "_client", None), \
             mock.patch.object(ai_gemini, "_client_fingerprint", ""), \
             mock.patch.object(ai_gemini.genai, "Client") as build:
            ai_gemini.client()

        self.assertEqual(build.call_args.kwargs["api_key"], "AIza-resolved")
class CredentialTests(SignedIn):
    """Claude credential resolution -- an `ant auth login` profile is enough."""

    ENV_KEYS = ("ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN",
                "ANTHROPIC_PROFILE", "ANTHROPIC_CONFIG_DIR")

    def _describe(self, env=None, profiles=()):
        """Run the Claude backend's describe_credentials() in isolation.

        Targets the backend directly rather than ai.describe_credentials(), which
        dispatches on the configured provider -- otherwise these assertions would
        silently test Gemini whenever .env selects it.
        """
        import os

        with tempfile.TemporaryDirectory() as tmp:
            creds = Path(tmp) / "credentials"
            creds.mkdir()
            for name in profiles:
                (creds / f"{name}.json").write_text("{}", encoding="utf-8")

            clean = {k: v for k, v in os.environ.items() if k not in self.ENV_KEYS}
            clean["ANTHROPIC_CONFIG_DIR"] = tmp
            clean.update(env or {})
            with mock.patch.dict(os.environ, clean, clear=True):
                return ai_claude.describe_credentials()

    def test_api_key_is_used_when_present(self):
        usable, source, _ = self._describe({"ANTHROPIC_API_KEY": "sk-ant-xyz"})

        self.assertTrue(usable)
        self.assertIn("ANTHROPIC_API_KEY", source)

    def test_a_stored_cli_profile_is_enough_on_its_own(self):
        usable, source, advice = self._describe(profiles=["default"])

        self.assertTrue(usable)
        self.assertIn("ant CLI profile", source)
        self.assertEqual(advice, "")

    def test_no_credentials_points_at_the_cli_login(self):
        usable, source, advice = self._describe()

        self.assertFalse(usable)
        self.assertIn("no credentials", source)
        self.assertIn("ant auth login", advice)

    def test_an_empty_api_key_shadowing_a_profile_is_caught(self):
        # The trap: an empty key still wins its slot and authenticates with
        # nothing, so a working profile is silently ignored.
        usable, source, advice = self._describe(
            {"ANTHROPIC_API_KEY": ""}, profiles=["default"])

        self.assertFalse(usable)
        self.assertIn("empty", source)
        self.assertIn("takes priority", advice)
        self.assertIn("Remove-Item", advice)

    def test_a_named_profile_that_does_not_exist_is_reported(self):
        usable, source, advice = self._describe(
            {"ANTHROPIC_PROFILE": "work"}, profiles=["default"])

        self.assertFalse(usable)
        self.assertIn("does not exist", source)
        self.assertIn("default", advice)

    def test_a_named_profile_that_exists_is_used(self):
        usable, source, _ = self._describe(
            {"ANTHROPIC_PROFILE": "work"}, profiles=["default", "work"])

        self.assertTrue(usable)
        self.assertIn("work", source)

    def test_auth_token_is_accepted(self):
        usable, source, _ = self._describe({"ANTHROPIC_AUTH_TOKEN": "oauth-token"})

        self.assertTrue(usable)
        self.assertIn("ANTHROPIC_AUTH_TOKEN", source)

    def test_a_cli_profile_is_used_without_passing_a_key(self):
        """The reason this matters: passing api_key= would defeat the profile.

        Asserted behaviourally rather than by reading the source, because the
        answer now depends on which credential the resolver found -- an explicit
        key IS passed when there is one to pass, and must not be when there
        isn't.
        """
        resolved = credentials.Credential(
            provider="claude", source=credentials.CLI_PROFILE, key="",
            detail="ant CLI profile ('default')")

        with mock.patch.object(credentials, "require", return_value=resolved), \
             mock.patch.object(ai_claude, "_client", None), \
             mock.patch.object(ai_claude, "_client_fingerprint", ""), \
             mock.patch.object(ai_claude.anthropic, "Anthropic") as build:
            ai_claude.client()

        self.assertNotIn("api_key", build.call_args.kwargs)
        self.assertNotIn("auth_token", build.call_args.kwargs)
        self.assertIn("max_retries", build.call_args.kwargs)

    def test_a_resolved_key_is_passed_explicitly(self):
        """A key saved in Settings is not in the environment, so the SDK cannot
        find it on its own -- it has to be handed over."""
        resolved = credentials.Credential(
            provider="claude", source=credentials.DATABASE,
            key="sk-ant-from-settings", detail="saved in Settings")

        with mock.patch.object(credentials, "require", return_value=resolved), \
             mock.patch.object(ai_claude, "_client", None), \
             mock.patch.object(ai_claude, "_client_fingerprint", ""), \
             mock.patch.object(ai_claude.anthropic, "Anthropic") as build:
            ai_claude.client()

        self.assertEqual(build.call_args.kwargs["api_key"], "sk-ant-from-settings")

    def test_the_cached_client_is_rebuilt_when_the_key_changes(self):
        """Otherwise a newly saved key would not take effect until a restart."""
        first = credentials.Credential(provider="claude",
                                       source=credentials.DATABASE, key="key-one")
        second = credentials.Credential(provider="claude",
                                        source=credentials.DATABASE, key="key-two")

        with mock.patch.object(ai_claude, "_client", None), \
             mock.patch.object(ai_claude, "_client_fingerprint", ""), \
             mock.patch.object(ai_claude.anthropic, "Anthropic") as build:
            with mock.patch.object(credentials, "require", return_value=first):
                ai_claude.client()
                ai_claude.client()          # same key: no rebuild
            self.assertEqual(build.call_count, 1)

            with mock.patch.object(credentials, "require", return_value=second):
                ai_claude.client()
            self.assertEqual(build.call_count, 2)

    def test_client_refuses_to_build_with_no_credentials(self):
        with mock.patch.dict(os.environ, {}, clear=True):
            with mock.patch.object(ai_claude, "_client", None), \
                 mock.patch.object(ai_claude, "_client_fingerprint", ""), \
                 mock.patch.object(ai_claude, "find_cli_profile",
                                   return_value=(False, "no CLI profile")):
                with self.assertRaises(ai.AiError) as caught:
                    ai_claude.client()

        message = str(caught.exception)
        self.assertIn("no credentials found", message)
        self.assertIn("not configured", message)
class GroqCredentialTests(SignedIn):
    def _describe(self, env):
        import os

        clean = {k: v for k, v in os.environ.items() if k not in ai_groq.KEY_VARS}
        clean.update(env)
        with mock.patch.dict(os.environ, clean, clear=True):
            return ai_groq.describe_credentials()

    def test_groq_api_key_is_used(self):
        usable, source, _ = self._describe({"GROQ_API_KEY": "gsk_xyz"})

        self.assertTrue(usable)
        self.assertIn("GROQ_API_KEY", source)

    def test_no_key_points_at_the_console(self):
        usable, _, advice = self._describe({})

        self.assertFalse(usable)
        self.assertIn("console.groq.com", advice)

    def test_an_empty_key_is_caught(self):
        usable, source, _ = self._describe({"GROQ_API_KEY": "  "})

        self.assertFalse(usable)
        self.assertIn("empty", source)

    def test_the_resolved_key_is_passed_to_the_client(self):
        """The key may have come from Settings, which the SDK cannot discover."""
        resolved = credentials.Credential(
            provider="groq", source=credentials.DATABASE, key="gsk_resolved")

        with mock.patch.object(credentials, "require", return_value=resolved), \
             mock.patch.object(ai_groq, "_client", None), \
             mock.patch.object(ai_groq, "_client_fingerprint", ""), \
             mock.patch.object(ai_groq.groq, "Groq") as build:
            ai_groq.client()

        self.assertEqual(build.call_args.kwargs["api_key"], "gsk_resolved")
