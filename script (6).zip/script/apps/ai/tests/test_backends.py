"""
The four providers, one at a time.

Each backend has its own way of being asked for JSON and its own way of failing, and
those differences are exactly what a shared test would hide. `ProviderSelectionTests`
covers the part that is not per-provider: which one gets picked, and that everything
downstream of the choice is shared.
"""

from __future__ import annotations

import ast
import inspect
import os
from unittest import mock

import groq as groq_errors
from google.genai import errors as genai_errors

from apps import ai
from apps.ai.backends import claude as ai_claude
from apps.ai.backends import gemini as ai_gemini
from apps.ai.backends import groq as ai_groq
from apps.core.testing import SignedIn


class ProviderSelectionTests(SignedIn):
    """OUTREACH_AI_PROVIDER picks the backend; everything else is shared."""

    def _with(self, provider=None, model=None):

        env = {k: v for k, v in os.environ.items()
               if k not in ("OUTREACH_AI_PROVIDER", "OUTREACH_AI_MODEL")}
        if provider is not None:
            env["OUTREACH_AI_PROVIDER"] = provider
        if model is not None:
            env["OUTREACH_AI_MODEL"] = model
        return mock.patch.dict(os.environ, env, clear=True)

    def test_claude_is_the_built_in_default(self):
        with self._with():
            self.assertEqual(ai.provider(), "claude")
            self.assertIs(ai.backend(), ai_claude)
            self.assertEqual(ai.model(), "claude-opus-5")

    def test_gemini_can_be_selected(self):
        with self._with(provider="gemini"):
            self.assertIs(ai.backend(), ai_gemini)
            self.assertEqual(ai.model(), "gemini-3.7-flash")

    def test_groq_can_be_selected(self):
        with self._with(provider="groq"):
            self.assertIs(ai.backend(), ai_groq)
            self.assertEqual(ai.model(), "openai/gpt-oss-120b")

    def test_provider_name_is_case_and_space_insensitive(self):
        with self._with(provider="  GEMINI  "):
            self.assertIs(ai.backend(), ai_gemini)

    def test_an_explicit_model_overrides_the_backend_default(self):
        with self._with(provider="gemini", model="gemini-3.1-pro-preview"):
            self.assertEqual(ai.model(), "gemini-3.1-pro-preview")

    def test_an_unknown_provider_is_a_readable_error(self):
        with self._with(provider="skynet"):
            with self.assertRaises(ai.AiError) as caught:
                ai.backend()

        message = str(caught.exception)
        self.assertIn("skynet", message)
        self.assertIn("claude", message)
        self.assertIn("gemini", message)

    def test_both_backends_satisfy_the_same_interface(self):
        for name in ai.PROVIDERS:
            with self.subTest(provider=name):
                module = ai.load(name)
                self.assertEqual(module.NAME, name)
                self.assertTrue(module.LABEL)
                self.assertTrue(module.DEFAULT_MODEL)
                self.assertTrue(callable(module.describe_credentials))
                self.assertTrue(callable(module.complete))

    def test_backends_are_imported_lazily(self):
        """Running on one provider must not require the other's SDK."""

        tree = ast.parse(inspect.getsource(ai))
        top_level = [
            alias.name
            for node in tree.body
            if isinstance(node, (ast.Import, ast.ImportFrom))
            for alias in getattr(node, "names", [])
        ]

        self.assertNotIn("ai_claude", top_level)
        self.assertNotIn("ai_gemini", top_level)

    def test_a_missing_sdk_names_the_package_to_install(self):
        with mock.patch.dict(ai.PROVIDERS,
                             {"ghost": ("apps.ai.backends.no_such_backend", "ghost-sdk")}):
            with self.assertRaises(ai.AiError) as caught:
                ai.load("ghost")

        message = str(caught.exception)
        self.assertIn("ghost-sdk", message)
        self.assertIn("pip install", message)

    def test_generate_routes_through_the_selected_backend(self):
        payload = ('{"subject": "s", "body": "b", "observation": "o",'
                   ' "findings_used": []}')

        with self._with(provider="gemini"), \
             mock.patch.object(ai_gemini, "complete", return_value=payload) as gem, \
             mock.patch.object(ai_claude, "complete") as claude:
            email = ai.generate(
                business_name="B", category="c", city="Delft", country="NL",
                website="", sender_name="S", sender_company="Co",
                service_pitch="p", findings=[], site_note="n",
            )

        self.assertEqual(email.subject, "s")
        gem.assert_called_once()
        claude.assert_not_called()
        # The shared contract is what reaches the backend, not a per-provider copy.
        self.assertEqual(gem.call_args.kwargs["schema"], ai.SCHEMA)
        self.assertEqual(gem.call_args.kwargs["system"], ai.SYSTEM)
class ClaudeBackendTests(SignedIn):
    """Claude-specific transport: refusals and truncation."""

    def _response(self, text, stop_reason="end_turn", details=None):
        block = mock.Mock(type="text", text=text)
        return mock.Mock(content=[block], stop_reason=stop_reason,
                         stop_details=details)

    def _complete(self, response):
        with mock.patch.object(ai_claude, "_create", return_value=response):
            return ai_claude.complete(
                system="sys", prompt="prompt", schema=ai.SCHEMA,
                model="claude-opus-5",
            )

    def test_text_is_returned_for_the_shared_parser(self):
        payload = '{"subject": "s", "body": "b", "observation": "o"}'

        self.assertEqual(self._complete(self._response(payload)), payload)

    def test_refusal_is_reported_not_read_as_content(self):
        response = self._response("", stop_reason="refusal",
                                  details=mock.Mock(category="cyber"))

        with self.assertRaises(ai.AiError) as caught:
            self._complete(response)

        self.assertIn("declined", str(caught.exception))
        self.assertIn("cyber", str(caught.exception))

    def test_truncated_reply_is_an_error(self):
        with self.assertRaises(ai.AiError) as caught:
            self._complete(self._response('{"subject": "x"',
                                          stop_reason="max_tokens"))

        self.assertIn("cut off", str(caught.exception))

    def test_the_schema_and_effort_reach_the_request(self):
        captured = {}

        def fake_create(request):
            captured.update(request)
            return self._response('{"subject": "s", "body": "b", "observation": "o"}')

        with mock.patch.object(ai_claude, "_create", side_effect=fake_create):
            ai_claude.complete(system="sys", prompt="p", schema=ai.SCHEMA,
                               model="claude-opus-5")

        fmt = captured["output_config"]["format"]
        self.assertEqual(fmt["type"], "json_schema")
        self.assertEqual(fmt["schema"], ai.SCHEMA)
        self.assertEqual(captured["output_config"]["effort"], ai_claude.EFFORT)
        self.assertEqual(captured["system"], "sys")
class GroqBackendTests(SignedIn):
    """Groq-specific transport: response_format selection and error mapping."""

    def _reply(self, content, finish_reason="stop"):
        message = mock.Mock(content=content)
        choice = mock.Mock(message=message, finish_reason=finish_reason)
        return mock.Mock(choices=[choice])

    def _complete(self, reply=None, error=None, model="openai/gpt-oss-120b"):
        client = mock.Mock()
        if error is not None:
            client.chat.completions.create.side_effect = error
        else:
            client.chat.completions.create.return_value = reply
        with mock.patch.object(ai_groq, "client", return_value=client):
            return ai_groq.complete(
                system="sys", prompt="prompt", schema=ai.SCHEMA, model=model,
            ), client

    PAYLOAD = '{"subject": "s", "body": "b", "observation": "o"}'

    def test_message_content_is_returned(self):
        text, _ = self._complete(self._reply(self.PAYLOAD))

        self.assertEqual(text, self.PAYLOAD)

    def test_a_gpt_oss_model_gets_a_strict_json_schema(self):
        _, client = self._complete(self._reply(self.PAYLOAD))

        kwargs = client.chat.completions.create.call_args.kwargs
        fmt = kwargs["response_format"]
        self.assertEqual(fmt["type"], "json_schema")
        self.assertTrue(fmt["json_schema"]["strict"])
        self.assertEqual(fmt["json_schema"]["schema"], ai.SCHEMA)
        # System and user prompts go in as separate messages.
        self.assertEqual([m["role"] for m in kwargs["messages"]],
                         ["system", "user"])
        self.assertEqual(kwargs["messages"][0]["content"], "sys")

    def test_another_model_falls_back_to_json_object_mode(self):
        # strict schemas are GPT-OSS-only, so a Llama model must not request one
        # -- that would be a hard 400 instead of a slightly looser guarantee.
        _, client = self._complete(self._reply(self.PAYLOAD),
                                   model="llama-3.3-70b-versatile")

        fmt = client.chat.completions.create.call_args.kwargs["response_format"]
        self.assertEqual(fmt, {"type": "json_object"})

    def test_response_format_helper_matches_the_model_list(self):
        for model in ai_groq.STRICT_SCHEMA_MODELS:
            with self.subTest(model=model):
                self.assertEqual(
                    ai_groq._response_format(ai.SCHEMA, model)["type"],
                    "json_schema",
                )
        self.assertEqual(
            ai_groq._response_format(ai.SCHEMA, "something-else")["type"],
            "json_object",
        )

    def test_truncation_is_reported(self):
        with self.assertRaises(ai.AiError) as caught:
            self._complete(self._reply('{"subject"', finish_reason="length"))

        self.assertIn("cut off", str(caught.exception))

    def test_empty_content_is_reported(self):
        with self.assertRaises(ai.AiError) as caught:
            self._complete(self._reply(""))

        self.assertIn("no text", str(caught.exception))

    def test_no_choices_is_reported(self):
        with self.assertRaises(ai.AiError) as caught:
            self._complete(mock.Mock(choices=[]))

        self.assertIn("no choices", str(caught.exception))

    def test_a_bad_key_is_reported_clearly(self):
        error = groq_errors.AuthenticationError.__new__(
            groq_errors.AuthenticationError)

        with self.assertRaises(ai.AiError) as caught:
            self._complete(error=error)

        self.assertIn("rejected the API key", str(caught.exception))
        self.assertIn("console.groq.com", str(caught.exception))

    def test_rate_limiting_is_reported_clearly(self):
        error = groq_errors.RateLimitError.__new__(groq_errors.RateLimitError)

        with self.assertRaises(ai.AiError) as caught:
            self._complete(error=error)

        self.assertIn("rate limit", str(caught.exception).lower())

    def test_an_unknown_model_names_the_setting_to_fix(self):
        error = groq_errors.NotFoundError.__new__(groq_errors.NotFoundError)

        with self.assertRaises(ai.AiError) as caught:
            self._complete(error=error, model="no-such-model")

        self.assertIn("OUTREACH_AI_MODEL", str(caught.exception))

    def test_a_network_failure_is_wrapped(self):
        error = groq_errors.APIConnectionError.__new__(
            groq_errors.APIConnectionError)

        with self.assertRaises(ai.AiError) as caught:
            self._complete(error=error)

        self.assertIn("Could not reach", str(caught.exception))
class GeminiBackendTests(SignedIn):
    """Gemini-specific transport: response shape and error mapping."""

    def _complete(self, interaction=None, error=None):
        client = mock.Mock()
        if error is not None:
            client.interactions.create.side_effect = error
        else:
            client.interactions.create.return_value = interaction
        with mock.patch.object(ai_gemini, "client", return_value=client):
            return ai_gemini.complete(
                system="sys", prompt="prompt", schema=ai.SCHEMA,
                model="gemini-3.7-flash",
            ), client

    def test_output_text_is_returned(self):
        payload = '{"subject": "s", "body": "b", "observation": "o"}'
        interaction = mock.Mock(output_text=payload, status="completed", errors=None)

        text, _ = self._complete(interaction)

        self.assertEqual(text, payload)

    def test_the_request_uses_the_documented_response_format(self):
        interaction = mock.Mock(output_text='{"subject":"s","body":"b","observation":"o"}',
                                status="completed", errors=None)

        _, client = self._complete(interaction)

        kwargs = client.interactions.create.call_args.kwargs
        self.assertEqual(kwargs["model"], "gemini-3.7-flash")
        self.assertEqual(kwargs["system_instruction"], "sys")
        self.assertEqual(kwargs["input"], "prompt")
        text_format = kwargs["response_format"]["text"]
        self.assertEqual(text_format["mime_type"], "application/json")
        self.assertEqual(text_format["schema"], ai.SCHEMA)

    def test_empty_output_is_reported_as_a_block_not_parsed(self):
        interaction = mock.Mock(output_text="", status="blocked", errors=None)

        with self.assertRaises(ai.AiError) as caught:
            self._complete(interaction)

        self.assertIn("no text", str(caught.exception))
        self.assertIn("safety", str(caught.exception))

    def test_a_bad_key_is_reported_clearly(self):
        error = genai_errors.ClientError.__new__(genai_errors.ClientError)
        error.message = "API_KEY_INVALID"
        error.status = "INVALID_ARGUMENT"

        with self.assertRaises(ai.AiError) as caught:
            self._complete(error=error)

        self.assertIn("rejected the API key", str(caught.exception))
        self.assertIn("aistudio.google.com", str(caught.exception))

    def test_quota_exhaustion_is_reported_clearly(self):
        error = genai_errors.ClientError.__new__(genai_errors.ClientError)
        error.message = "Quota exceeded for requests"
        error.status = "RESOURCE_EXHAUSTED"

        with self.assertRaises(ai.AiError) as caught:
            self._complete(error=error)

        self.assertIn("quota", str(caught.exception).lower())

    def test_a_server_error_asks_for_a_retry(self):
        error = genai_errors.ServerError.__new__(genai_errors.ServerError)
        error.message = "internal"
        error.status = "INTERNAL"

        with self.assertRaises(ai.AiError) as caught:
            self._complete(error=error)

        self.assertIn("retry", str(caught.exception).lower())

    def test_a_network_failure_is_wrapped(self):
        with self.assertRaises(ai.AiError) as caught:
            self._complete(error=OSError("dns failure"))

        self.assertIn("Could not reach", str(caught.exception))
