"""
What the model is asked, and what it is forbidden to do.

The prompts carry the promise the whole product rests on -- evidence or silence -- so
they are tested as text: the framing is present, the invention is forbidden in so many
words, and a finding without a citable signal has nowhere to go.
"""

from __future__ import annotations

from unittest import mock

from apps import ai
from apps.ai.backends import claude as ai_claude
from apps.ai.backends import gemini as ai_gemini
from apps.ai.backends import groq as ai_groq
from apps.core.testing import SignedIn

from .factories import make_findings


class AuditPromptTests(SignedIn):
    """The review stage: broad coverage, but evidence or nothing."""

    def _prompt(self, **overrides):
        kwargs = dict(
            business_name="Bella Cucina", category="Restaurant", city="Delft",
            country="Netherlands", website="https://bella.example",
            site_context="### PAGE 1 -- HOME\nMeasured signals: cta_count=0",
            pages_read=6, discovered=14,
        )
        kwargs.update(overrides)
        return ai.build_audit_prompt(**kwargs)

    def test_the_crawled_material_and_counts_are_supplied(self):
        prompt = self._prompt()

        self.assertIn("cta_count=0", prompt)
        self.assertIn("6 page(s) were read automatically", prompt)
        self.assertIn("14 discovered", prompt)

    def test_every_review_dimension_is_named(self):
        prompt = self._prompt()

        for dimension in ai.REVIEW_DIMENSIONS:
            with self.subTest(dimension=dimension):
                self.assertIn(dimension, prompt)

    def test_the_target_count_is_stated(self):
        self.assertIn("8-10", self._prompt())

    def test_the_system_prompt_forbids_unevidenced_claims(self):
        self.assertIn("THE EVIDENCE RULE", ai.AUDIT_SYSTEM)
        self.assertIn("do not report the finding", ai.AUDIT_SYSTEM)

    def test_the_system_prompt_forbids_padding_to_reach_the_target(self):
        self.assertIn("Report fewer if", ai.AUDIT_SYSTEM)
        self.assertIn("Padding the list with speculation is a failure",
                      ai.AUDIT_SYSTEM)

    def test_the_system_prompt_forbids_claims_it_cannot_verify(self):
        """The model has text and numbers, not screenshots.

        Without this, a model asked about "design" and "layout" will happily
        invent judgements about colours and spacing it has no way to see.
        """
        for forbidden in ("colours", "fonts", "spacing", "You cannot see the site"):
            with self.subTest(forbidden=forbidden):
                self.assertIn(forbidden, ai.AUDIT_SYSTEM)

    def test_specific_signals_are_tied_to_specific_claims(self):
        for pair in ("load_ms", "viewport_meta", "images_missing_alt",
                     "cta_count", "word_count"):
            with self.subTest(signal=pair):
                self.assertIn(pair, ai.AUDIT_SYSTEM)

    def test_audit_schema_requires_the_four_reporting_fields(self):
        item = ai.AUDIT_SCHEMA["properties"]["findings"]["items"]

        for field_name in ("issue", "evidence", "why_it_matters",
                           "suggested_improvement"):
            self.assertIn(field_name, item["required"])
        self.assertFalse(item["additionalProperties"])
        self.assertEqual(ai.AUDIT_SCHEMA["properties"]["findings"]["maxItems"], 10)

    def test_an_empty_context_is_refused_before_calling_the_model(self):
        with mock.patch.object(ai.client, "backend") as backend:
            with self.assertRaises(ai.AiError):
                ai.audit(business_name="B", category="c", city="", country="",
                         website="https://x", site_context="   ",
                         pages_read=0, discovered=0)

        backend.assert_not_called()
class PromptTests(SignedIn):
    def _prompt(self, **overrides):
        kwargs = dict(
            business_name="Bella Cucina", category="Restaurant", city="Delft",
            country="Netherlands", website="https://bella.example",
            sender_name="Sam Rivers", sender_company="Northline",
            sender_email="sam@northline.test",
            service_pitch="We build booking sites.",
            findings=make_findings(3),
            business_summary="A family pizzeria in Delft.",
            site_note="Read 6 pages.",
        )
        kwargs.update(overrides)
        return ai.build_prompt(**kwargs)

    def test_prompt_carries_the_findings_with_their_evidence(self):
        prompt = self._prompt()

        self.assertIn("VERIFIED WEBSITE FINDINGS", prompt)
        self.assertIn("Issue 0", prompt)
        self.assertIn("cta_count=0 on page 0", prompt)
        self.assertIn("Fix: Add a CTA 0", prompt)

    def test_prompt_carries_the_business_facts_and_the_offer(self):
        prompt = self._prompt()

        self.assertIn("Bella Cucina", prompt)
        self.assertIn("A family pizzeria in Delft.", prompt)
        self.assertIn("We build booking sites.", prompt)
        self.assertIn("sam@northline.test", prompt)

    def test_the_offer_falls_back_to_the_configured_default(self):
        prompt = self._prompt(service_pitch="")

        self.assertIn(ai.DEFAULT_OFFER, prompt)

    def test_no_findings_forbids_implying_the_site_was_seen(self):
        prompt = self._prompt(findings=[], site_note="robots.txt disallows")

        self.assertIn("none available", prompt)
        self.assertIn("Do not imply you looked at their website", prompt)
        self.assertIn("robots.txt disallows", prompt)

    def test_regeneration_hint_is_passed_through(self):
        prompt = self._prompt(retry_hint="make it shorter")

        self.assertIn("REVISION NOTE: make it shorter", prompt)

    def test_system_prompt_forbids_invention(self):
        self.assertIn("Never state anything you were not given", ai.SYSTEM)
        self.assertIn("no problems beyond the supplied findings", ai.SYSTEM)

    def test_system_prompt_forbids_narrating_the_crawl(self):
        """The brief is explicit: do not list the pages visited."""
        self.assertIn("Never list the pages visited", ai.SYSTEM)
        self.assertIn("I visited your Home, About", ai.SYSTEM)
        self.assertIn("I noticed your website currently has", ai.SYSTEM)

    def test_system_prompt_limits_the_email_to_one_or_two_findings(self):
        self.assertIn("ONE to THREE of the supplied findings", ai.SYSTEM)
        self.assertIn("Do not paste the whole list", ai.SYSTEM)

    def test_the_email_is_a_consultative_note_ending_in_a_call(self):
        """What the email offers has changed twice, on instruction.

        First it connected the finding to what the sender sells. Then it offered to
        send a written review, with call-based CTAs banned. Now it explains two or
        three findings properly and offers an untimed call. The assertions move
        with it; what has not moved is that the offer may not be embellished --
        the test below still guards that.
        """
        flat = " ".join(ai.SYSTEM.split())

        self.assertIn("Structure it as a short consultative note", flat)
        self.assertIn("how I'd approach fixing it.", flat)
        self.assertIn("Would you be open to a quick call this week?", flat)
        self.assertIn("NEVER name a length for the call", flat)

    def test_system_prompt_forbids_embellishing_the_offer(self):
        """A live run added "machine learning to prioritize visitors".

        That capability was never in the supplied offer. Inventing how the
        service works is the same failure mode as inventing a website problem,
        so it is forbidden in the same explicit terms -- and still is, now that
        mentioning the service at all is optional.
        """
        self.assertIn("only in the words you were given", ai.SYSTEM)
        self.assertIn("capabilities, technologies, mechanisms or results that "
                      "were not stated", " ".join(ai.SYSTEM.split()))
        self.assertIn("Inventing how the service works", ai.SYSTEM)

    def test_audit_system_asks_for_json_explicitly(self):
        """Groq's json_object fallback requires the word in the messages.

        Without it the retry path fails with "'messages' must contain the word
        'json'", turning a recoverable strict-schema miss into a lost lead.
        """
        self.assertIn("JSON", ai.AUDIT_SYSTEM)
        self.assertIn("JSON", ai.SYSTEM)

    def test_schema_requires_the_audit_trail_fields(self):
        self.assertEqual(
            set(ai.SCHEMA["required"]),
            {"subject", "body", "observation", "findings_used"})
        self.assertFalse(ai.SCHEMA["additionalProperties"])

    def test_the_observation_rule_is_stated_in_both_directions(self):
        """A provider swap exposed that "use the site" did not imply "record it".

        Gemini personalised from the website material while reporting
        observation="none", which would have made the review page claim the
        email used no website content. The rule is now explicit both ways.
        """
        self.assertIn('"findings_used" and "observation" are the audit trail',
                      ai.SYSTEM)
        self.assertIn("reporting \"none\" is a wrong answer", ai.SYSTEM)

    def test_findings_used_is_parsed_back(self):
        email = ai.parse(
            '{"subject": "s", "body": "b", "observation": "o",'
            ' "findings_used": ["Issue 0", "Issue 1"]}')

        self.assertEqual(email.findings_used, ["Issue 0", "Issue 1"])

    def test_a_missing_findings_used_defaults_to_empty(self):
        email = ai.parse('{"subject": "s", "body": "b", "observation": "none"}')

        self.assertEqual(email.findings_used, [])

    def test_each_backend_declares_a_sensible_default_model(self):
        self.assertEqual(ai_claude.DEFAULT_MODEL, "claude-opus-5")
        self.assertTrue(ai_gemini.DEFAULT_MODEL.startswith("gemini-"))
        # Groq's default must be one that accepts a strict JSON schema.
        self.assertIn(ai_groq.DEFAULT_MODEL, ai_groq.STRICT_SCHEMA_MODELS)
