"""
The audit covers the business, not only the markup.

A review that reports titles, alt text and page weight has done the easy quarter of
the job. The findings a business owner acts on are usually the ones nothing in an
unguided review ever reaches: no indication of price, no service area, no
explanation of how the work happens, no reason to believe the company.

Four things are tested here:

  * **the measurements** that make a business-logic or trust finding possible to
    evidence at all;
  * **the classification** of a finding into one of the six review areas;
  * **the honesty rules** — a promised outcome is stripped, an unevidenced finding
    is dropped, and "could not be verified" is held apart from a measured fact;
  * **the report** the lead page renders, grouped by priority.

Nothing here contacts a provider or a website.
"""

from __future__ import annotations

from django.test import TestCase
from django.urls import reverse

from apps import ai
from apps.ai.base import Finding
from apps.auditing import crawler, measurements, scoring
from apps.core.testing import SignedIn
from apps.outreach.models import EmailDraft
from apps.outreach.tests.factories import make_campaign, make_draft


def finding(issue="No indication of cost", dimension="pricing",
            severity="high", evidence="pricing_mentions=0 across 4 pages",
            benefit="Could help visitors self-qualify before they call.",
            why="Visitors who cannot gauge cost often do not enquire at all",
            fix="Add a starting price or a typical range") -> Finding:
    return Finding(issue=issue, evidence=evidence, why_it_matters=why,
                   suggested_improvement=fix, dimension=dimension,
                   severity=severity, business_benefit=benefit)


def measured(html: str) -> dict:
    """Run the real measurement over a fragment of markup."""
    from bs4 import BeautifulSoup

    fetched = crawler.Fetched(html=html, load_ms=900, size=2048,
                               final_url="https://bella.example/")
    return measurements.measure(BeautifulSoup(html, "html.parser"), html, fetched)


# --------------------------------------------------------------------------- #
# The evidence a business finding needs
# --------------------------------------------------------------------------- #

class BusinessSignalTests(TestCase):
    """Ten questions a customer arrives with, each countable.

    Without these, a reviewer asked for business-logic findings has to invent them
    -- which is the one thing it must never do.
    """

    def test_every_business_question_is_measured(self):
        self.assertEqual(set(measurements.BUSINESS_SIGNALS), {
            "pricing_mentions", "service_area_mentions", "process_mentions",
            "team_mentions", "hours_mentions", "guarantee_mentions",
            "proof_mentions", "credential_mentions", "faq_mentions",
            "audience_mentions",
        })

    def test_a_page_that_answers_them_counts_above_zero(self):
        facts = measured(
            "<html><body>"
            "<p>Our prices start from 45 euro per hour.</p>"
            "<p>We serve Delft and the surrounding areas.</p>"
            "<p>How it works: you call, we visit, we quote.</p>"
            "<p>Meet the team behind the workshop.</p>"
            "<p>Opening hours: Monday - Friday.</p>"
            "<p>Every repair carries a 12-month warranty.</p>"
            "<p>Read our reviews and see our portfolio.</p>"
            "<p>Licensed and insured, 20 years experience.</p>"
            "<p>FAQ: the questions we get asked most.</p>"
            "<p>Designed for homeowners in South Holland.</p>"
            "</body></html>")

        for key in measurements.BUSINESS_SIGNALS:
            with self.subTest(signal=key):
                self.assertGreater(facts[key], 0)

    def test_a_page_that_answers_none_of_them_counts_zero(self):
        """The zeroes are the point: they evidence an absence."""
        facts = measured("<html><body><h1>Welcome</h1>"
                         "<p>We are a company. Contact us.</p></body></html>")

        for key in measurements.BUSINESS_SIGNALS:
            with self.subTest(signal=key):
                self.assertEqual(facts[key], 0)

    def test_pricing_language_is_recognised_in_several_forms(self):
        for text in ("Our prices", "starting from 20", "per month",
                     "our rates", "how much does it cost", "request a quote"):
            with self.subTest(text=text):
                facts = measured(f"<html><body><p>{text}</p></body></html>")
                self.assertGreater(facts["pricing_mentions"], 0)

    def test_the_best_page_wins_when_signals_are_merged(self):
        """Zero still means "on none of the pages read", which is the claim."""
        merged = scoring.merge_signals([
            {"pricing_mentions": 0, "faq_mentions": 2},
            {"pricing_mentions": 4, "faq_mentions": 0},
        ])

        self.assertEqual(merged["pricing_mentions"], 4)
        self.assertEqual(merged["faq_mentions"], 2)

    def test_a_topic_absent_everywhere_merges_to_zero(self):
        merged = scoring.merge_signals([
            {"pricing_mentions": 0}, {"pricing_mentions": 0}])

        self.assertEqual(merged["pricing_mentions"], 0)


# --------------------------------------------------------------------------- #
# Which of the six areas a finding belongs to
# --------------------------------------------------------------------------- #

class CategoryTests(TestCase):
    def test_the_six_areas_are_the_ones_the_brief_names(self):
        self.assertEqual(ai.CATEGORY_KEYS,
                         ("business", "ux", "content", "trust", "seo",
                          "technical"))

    def test_each_area_is_classified_from_its_dimension(self):
        cases = [
            ("pricing", "business"),
            ("service area", "business"),
            ("process", "business"),
            ("differentiation", "business"),
            ("calls to action", "ux"),
            ("conversion", "ux"),
            ("navigation", "ux"),
            ("contact experience", "ux"),
            ("content", "content"),
            ("FAQ", "content"),
            ("trust", "trust"),
            ("credibility", "trust"),
            ("SEO basics", "seo"),
            ("local SEO", "seo"),
            ("performance", "technical"),
            ("mobile", "technical"),
            ("accessibility", "technical"),
        ]
        for dimension, expected in cases:
            with self.subTest(dimension=dimension):
                self.assertEqual(
                    ai.category_of(finding(dimension=dimension)), expected)

    def test_a_word_inside_another_word_does_not_match(self):
        """"form" is inside "performance"; a speed finding is not a form problem."""
        self.assertEqual(
            ai.category_of(finding(dimension="performance",
                                   issue="The homepage is slow to load")),
            "technical")

    def test_a_plural_phrase_still_matches(self):
        """"calls to action" must match the keyword "call to action"."""
        self.assertEqual(
            ai.category_of(finding(dimension="calls to action")), "ux")

    def test_the_dimension_outranks_the_issue_text(self):
        """The reviewer chose the dimension deliberately.

        "No location content" contains a business word and an SEO one; the
        dimension is what settles it.
        """
        self.assertEqual(
            ai.category_of(finding(dimension="local SEO",
                                   issue="No location content")), "seo")

    def test_the_issue_text_is_used_when_the_dimension_says_nothing(self):
        self.assertEqual(
            ai.category_of(finding(dimension="",
                                   issue="The contact form asks for 11 fields")),
            "ux")

    def test_an_unclassifiable_finding_lands_in_business(self):
        """Not in "technical": an unfamiliar description is usually a real gap."""
        self.assertEqual(
            ai.category_of(finding(dimension="something nobody has named",
                                   issue="The opening times contradict")),
            "business")


# --------------------------------------------------------------------------- #
# Honesty
# --------------------------------------------------------------------------- #

class HedgingTests(TestCase):
    """A promised outcome is the one thing in an audit that could mislead."""

    def test_a_hedged_benefit_passes(self):
        for text in ("Could help visitors self-qualify.",
                     "May reduce friction for someone ready to book.",
                     "Creates an opportunity to answer questions before a call.",
                     "Can make it easier for a customer to get in touch.",
                     "This potentially shortens the path to an enquiry."):
            with self.subTest(text=text[:34]):
                self.assertEqual(ai.unhedged_benefit(text), "")

    def test_a_guarantee_is_caught(self):
        for text in ("This will increase your enquiries.",
                     "Guaranteed more customers within a month.",
                     "You will rank #1 for plumbers in Delft."):
            with self.subTest(text=text[:34]):
                self.assertIn("promises an outcome", ai.unhedged_benefit(text))

    def test_an_unhedged_assertion_is_caught(self):
        """"More customers from search" is a prediction nobody can make."""
        self.assertIn("as fact", ai.unhedged_benefit("More customers from search."))

    def test_an_over_promising_benefit_loses_the_sentence_not_the_finding(self):
        rows = ai.hedge_findings([
            finding(benefit="This will double your bookings."),
            finding(issue="No testimonials", dimension="trust",
                    benefit="Could help a visitor decide to trust the company."),
        ])

        self.assertEqual(rows[0].business_benefit, ai.BENEFIT_WITHHELD)
        self.assertEqual(rows[0].issue, "No indication of cost")   # kept
        self.assertIn("Could help", rows[1].business_benefit)      # untouched

    def test_an_empty_benefit_is_left_alone(self):
        """Nothing was claimed, so there is nothing to withhold."""
        rows = ai.hedge_findings([finding(benefit="")])

        self.assertEqual(rows[0].business_benefit, "")

    def test_the_parsed_audit_is_hedged(self):
        """One place, so a regenerated audit is covered as well as a fresh one."""
        import json

        payload = json.dumps({
            "business_summary": "A pizzeria in Delft.",
            "findings": [{
                "issue": "No indication of cost",
                "evidence": "pricing_mentions=0 across 4 pages",
                "why_it_matters": "Visitors cannot gauge whether it is for them",
                "suggested_improvement": "Add a typical price range",
                "business_benefit": "Will guarantee more bookings.",
                "dimension": "pricing",
                "severity": "high",
            }],
        })

        audit = ai.parse_audit(payload)

        self.assertEqual(audit.findings[0].business_benefit,
                         ai.BENEFIT_WITHHELD)


class UnverifiedTests(TestCase):
    """A crawl cannot settle everything, and must say so rather than guess."""

    def test_the_phrase_is_recognised(self):
        row = finding(evidence="Could not be verified from the available crawl.")

        self.assertTrue(ai.is_unverified(row))

    def test_a_measured_finding_is_not_unverified(self):
        self.assertFalse(ai.is_unverified(finding()))

    def test_unverified_findings_are_held_apart_from_confirmed_ones(self):
        report = ai.audit_report([
            finding(),
            finding(issue="Whether the contact form submits",
                    dimension="conversion", severity="medium",
                    evidence="Could not be verified from the available crawl."),
        ])

        self.assertEqual(report["total"], 1)
        self.assertEqual(len(report["unverified"]), 1)
        confirmed = [f.issue for g in report["groups"] for f in g["findings"]]
        self.assertNotIn("Whether the contact form submits", confirmed)


# --------------------------------------------------------------------------- #
# The report
# --------------------------------------------------------------------------- #

class AuditReportTests(TestCase):
    def setUp(self):
        self.rows = [
            finding(issue="No indication of cost", dimension="pricing",
                    severity="high"),
            finding(issue="No way to enquire from the homepage",
                    dimension="calls to action", severity="high"),
            finding(issue="No testimonials", dimension="trust",
                    severity="medium"),
            finding(issue="Homepage has no page title", dimension="SEO basics",
                    severity="medium"),
            finding(issue="Images have no alt text", dimension="accessibility",
                    severity="low"),
        ]

    def test_findings_are_grouped_by_priority_high_first(self):
        report = ai.audit_report(self.rows)

        self.assertEqual([g["key"] for g in report["groups"]],
                         ["high", "medium", "low"])
        self.assertEqual([g["count"] for g in report["groups"]], [2, 2, 1])

    def test_an_empty_priority_is_not_shown_as_an_empty_group(self):
        report = ai.audit_report([self.rows[0]])

        self.assertEqual([g["key"] for g in report["groups"]], ["high"])

    def test_critical_is_grouped_with_high(self):
        """The audit schema offers high/medium/low; older rows may say critical."""
        report = ai.audit_report([finding(severity="critical")])

        self.assertEqual(report["groups"][0]["key"], "high")

    def test_coverage_shows_which_areas_the_review_reached(self):
        report = ai.audit_report(self.rows)
        counts = {row["key"]: row["count"] for row in report["coverage"]}

        self.assertEqual(counts["business"], 1)
        self.assertEqual(counts["ux"], 1)
        self.assertEqual(counts["trust"], 1)
        self.assertEqual(counts["seo"], 1)
        self.assertEqual(counts["technical"], 1)
        self.assertEqual(counts["content"], 0)
        self.assertEqual(report["covered"], 5)
        self.assertEqual(report["categories"], 6)

    def test_every_area_is_listed_even_with_nothing_in_it(self):
        """A gap in coverage is information, so it is shown rather than omitted."""
        report = ai.audit_report([finding()])

        self.assertEqual(len(report["coverage"]), 6)
        self.assertEqual(sum(1 for r in report["coverage"] if not r["count"]), 5)

    def test_an_unevidenced_finding_never_reaches_the_report(self):
        """The last gate before a person reads the list.

        `parse_audit` drops these already, but rows stored before that rule
        existed are still in the database, and this is what a page renders from.
        """
        report = ai.audit_report([finding(), finding(issue="Looks dated",
                                                    evidence="")])

        self.assertEqual(report["total"], 1)
        self.assertNotIn("Looks dated",
                         [f.issue for g in report["groups"] for f in g["findings"]])

    def test_the_top_finding_is_the_strongest_one(self):
        report = ai.audit_report(self.rows)

        self.assertEqual(report["top"].issue, "No indication of cost")

    def test_nothing_in_gives_an_empty_report(self):
        report = ai.audit_report([])

        self.assertEqual(report["total"], 0)
        self.assertEqual(report["groups"], [])
        self.assertIsNone(report["top"])

    def test_priority_reads_as_the_brief_writes_it(self):
        self.assertEqual(finding(severity="high").priority, "HIGH")
        self.assertEqual(finding(severity="medium").priority, "MEDIUM")
        self.assertEqual(finding(severity="low").priority, "LOW")


# --------------------------------------------------------------------------- #
# The prompt
# --------------------------------------------------------------------------- #

class AuditPromptTests(TestCase):
    def test_the_prompt_names_all_six_areas(self):
        for label in ai.CATEGORY_LABELS.values():
            with self.subTest(area=label):
                self.assertIn(label, ai.build_audit_prompt(
                    business_name="Bella", category="Restaurant", city="Delft",
                    country="NL", website="https://bella.example",
                    site_context="cta_count=0", pages_read=3, discovered=9))

    def test_business_logic_is_named_before_seo(self):
        """The order is the order they matter in, and the model is told so."""
        keys = list(ai.CATEGORY_KEYS)

        self.assertLess(keys.index("business"), keys.index("seo"))
        self.assertLess(keys.index("ux"), keys.index("technical"))

    def test_the_prompt_asks_the_customer_question(self):
        prompt = ai.build_audit_prompt(
            business_name="Bella", category="Restaurant", city="Delft",
            country="NL", website="https://bella.example",
            site_context="cta_count=0", pages_read=3, discovered=9)

        self.assertIn("potential customer visiting this website", prompt)
        self.assertIn("leave without contacting", prompt)

    def test_the_prompt_offers_the_unverified_wording(self):
        prompt = ai.build_audit_prompt(
            business_name="Bella", category="Restaurant", city="Delft",
            country="NL", website="https://bella.example",
            site_context="cta_count=0", pages_read=3, discovered=9)

        self.assertIn("Could not be verified from the available crawl", prompt)

    def test_the_system_prompt_explains_what_a_zero_evidences(self):
        self.assertIn("pricing_mentions=0", ai.AUDIT_SYSTEM)
        self.assertIn("on the pages reviewed", ai.AUDIT_SYSTEM)

    def test_the_system_prompt_forbids_inflating_every_priority(self):
        self.assertIn("Do not mark everything high", ai.AUDIT_SYSTEM)

    def test_the_system_prompt_requires_hedged_benefits(self):
        self.assertIn("business_benefit", ai.AUDIT_SYSTEM)
        for hedge in ("could help", "creates an opportunity"):
            with self.subTest(hedge=hedge):
                self.assertIn(hedge, ai.AUDIT_SYSTEM)
        self.assertIn("Never promise", ai.AUDIT_SYSTEM)

    def test_the_system_prompt_still_forbids_seeing_the_site(self):
        """The rule that predates this work and must survive it."""
        self.assertIn("You cannot see the site", ai.AUDIT_SYSTEM)
        self.assertIn("not screenshots", ai.AUDIT_SYSTEM)

    def test_business_benefit_is_required_by_the_schema(self):
        item = ai.AUDIT_SCHEMA["properties"]["findings"]["items"]

        self.assertIn("business_benefit", item["properties"])
        self.assertIn("business_benefit", item["required"])


# --------------------------------------------------------------------------- #
# The page
# --------------------------------------------------------------------------- #

class AuditOnTheLeadPageTests(SignedIn):
    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(
            self.campaign, status=EmailDraft.Status.GENERATED,
            classification=scoring.WEBSITE_FOUND,
            # Pages actually read, with their measurements. Without them the lead
            # re-classifies as "website unverified" when the page re-scores on
            # open -- and an unverified site has no audit to show, correctly.
            pages_read=[
                {"url": "https://bella.example/", "kind": "home",
                 "facts": {"cta_count": 0, "pricing_mentions": 0,
                           "proof_mentions": 0, "images_missing_alt": 9}},
                {"url": "https://bella.example/contact", "kind": "contact",
                 "facts": {"forms": 1, "tel_links": 0}},
            ],
            pages_discovered=7,
            findings=[
                finding().as_dict(),
                finding(issue="No testimonials or case studies",
                        dimension="trust", severity="medium",
                        evidence="proof_mentions=0 across 4 pages").as_dict(),
                finding(issue="Images have no alt text",
                        dimension="accessibility", severity="low",
                        evidence="images_missing_alt=9").as_dict(),
                finding(issue="Whether the booking form submits",
                        dimension="conversion", severity="medium",
                        evidence="Could not be verified from the available "
                                 "crawl.").as_dict(),
            ])

    def _page(self):
        return self.client.get(
            reverse("outreach:lead_detail", args=[self.draft.pk]))

    def test_the_page_groups_the_audit_by_priority(self):
        page = self._page()

        self.assertContains(page, "High priority")
        self.assertContains(page, "Medium priority")
        self.assertContains(page, "Low priority and optimisation")

    def test_every_audit_field_is_on_the_page(self):
        page = self._page()

        for label in ("What was detected", "Why it matters", "Recommended fix",
                      "Potential business benefit"):
            with self.subTest(label=label):
                self.assertContains(page, label)

    def test_the_business_benefit_is_shown(self):
        self.assertContains(self._page(),
                            "Could help visitors self-qualify before they call.")

    def test_the_review_areas_reached_are_shown(self):
        page = self._page()

        self.assertContains(page, "review areas")
        for label in ai.CATEGORY_LABELS.values():
            with self.subTest(area=label):
                self.assertContains(page, label)

    def test_an_unverified_finding_is_shown_apart(self):
        page = self._page()

        self.assertContains(page, "Not verified")
        self.assertContains(page, "Whether the booking form submits")
        # And it is not counted among the confirmed findings.
        self.assertContains(page, 'class="badge">3</span>', html=False)

    def test_the_page_still_never_crawls_or_calls_the_ai(self):
        from unittest import mock

        with mock.patch.object(crawler, "analyse") as crawl, \
             mock.patch.object(ai, "audit") as audit:
            self._page()

        crawl.assert_not_called()
        audit.assert_not_called()
