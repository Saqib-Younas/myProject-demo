"""
Findings, built the shape the review stage produces them.

Three severities cycled, an id per finding and a page URL on each, because the parts
of the prompt and the email builder under test are the parts that carry evidence
through -- a finding without a page to point at is the case the guards exist for.
"""

from __future__ import annotations

from apps import ai


def make_findings(count=3):
    severities = ["high", "medium", "low"]
    return [
        ai.Finding(
            issue=f"Issue {i}",
            evidence=f"cta_count=0 on page {i}",
            why_it_matters=f"Costs enquiries {i}",
            suggested_improvement=f"Add a CTA {i}",
            dimension="calls to action",
            severity=severities[i % 3],
            page_url=f"https://bella.example/p{i}",
        )
        for i in range(count)
    ]
