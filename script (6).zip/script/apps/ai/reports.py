"""
The audit as something a person reads.

Findings grouped by priority, with the unverified ones kept separately and the
categories that produced nothing listed as covered-but-clear. That last part is the
reason this exists rather than the template looping over a list: "we looked at your
trust signals and they were fine" is information, and a template that only renders
findings cannot say it.
"""

from __future__ import annotations

from .categories import CATEGORY_KEYS, CATEGORY_LABELS, category_of
from .validation import is_unverified

PRIORITY_ORDER = ("high", "medium", "low")
PRIORITY_LABELS = {
    "high": "High priority",
    "medium": "Medium priority",
    "low": "Low priority and optimisation",
}
PRIORITY_BLURBS = {
    "high": "Plausibly costing enquiries or customers now.",
    "medium": "A real weakness worth fixing, but not bleeding money today.",
    "low": "Refinements and optimisation opportunities.",
}
def audit_report(findings: list) -> dict:
    """Group findings into a report: by priority, with category coverage.

    Everything here is derived from findings that already exist. Nothing is
    invented, nothing is dropped except into the `unverified` bucket, and the
    counts are what they are -- a category with nothing in it says so rather than
    being filled in.
    """
    # The evidence rule again, at the last point before a human reads the list.
    # `parse_audit` already drops findings with no evidence, but a report built
    # straight from stored findings must not be the one place speculation gets
    # through -- rows written before that rule existed are still in the database.
    findings = [
        f for f in (findings or [])
        if (getattr(f, "issue", "") or "").strip()
        and (getattr(f, "evidence", "") or "").strip()
    ]
    confirmed = [f for f in findings if not is_unverified(f)]
    unverified = [f for f in findings if is_unverified(f)]

    groups = []
    for key in PRIORITY_ORDER:
        rows = [f for f in confirmed
                if (getattr(f, "severity", "") or "medium").lower() == key
                or (key == "high"
                    and (getattr(f, "severity", "") or "").lower() == "critical")]
        if not rows:
            continue
        groups.append({
            "key": key,
            "label": PRIORITY_LABELS[key],
            "blurb": PRIORITY_BLURBS[key],
            "count": len(rows),
            "findings": rows,
        })

    # Which of the six areas the review actually reached. An audit that found
    # nothing outside SEO and performance is a thin audit, and this is what makes
    # that visible instead of implied.
    counts = {key: 0 for key in CATEGORY_KEYS}
    for finding in confirmed:
        counts[category_of(finding)] += 1
    coverage = [
        {"key": key, "label": CATEGORY_LABELS[key], "count": counts[key]}
        for key in CATEGORY_KEYS
    ]

    return {
        "total": len(confirmed),
        "groups": groups,
        "coverage": coverage,
        "covered": sum(1 for row in coverage if row["count"]),
        "categories": len(CATEGORY_KEYS),
        "unverified": unverified,
        "top": groups[0]["findings"][0] if groups else None,
    }
