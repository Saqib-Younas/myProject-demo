"""
The credential pool: which provider key to use, and what it has cost.

Three tables, and one reason they live in this app rather than in `outreach`: they
describe *how to talk to a provider*, which is this package's whole subject. Nothing
in them refers to a campaign, a lead or an email -- their only relation leaving the
group goes to `User`, which is also what made them safe to move.

  * `ProviderCredential` -- one saved key. Several per provider, exactly one active,
    the key itself held as Fernet ciphertext and never returned to a browser.
  * `CredentialEvent` -- what happened, per credential: used, failed, tested,
    activated. No keys and no provider response bodies, because a response body can
    quote the request that carried the key.
  * `AiSelection` -- which provider an account has chosen.

**The tables keep their `outreach_` names.** They were created in that app, the rows
are already there, and `sql/supabase_setup.sql` names them in its row-level-security
policies. Renaming them would be a schema change with nothing to show for it, so
`db_table` pins the old name and this paragraph is the reason.
"""

from __future__ import annotations

from django.conf import settings
from django.db import models


class ProviderCredential(models.Model):
    """One API key for one provider, encrypted at rest.

    The parent/child structure lives in this one table. The *parent* is the
    provider -- a name from `credentials.SPECS`, not a row -- and each row here is
    a *child*: one key, with a label, belonging to one account. So a user can hold
    four OpenAI keys and switch between them without editing anything.

    Exactly one child per (owner, provider) may be active, enforced by a database
    constraint rather than by application code, because "which key is in use" has
    to have one answer even if two browser tabs try to change it at once.

    Nothing here is ever sent to a browser. `secret` is Fernet ciphertext and
    `hint` is the masked form (`sk-proj-••••••••9X2A`) that the UI shows instead --
    enough to tell two keys apart, never enough to reconstruct one.
    """

    #: Whose key this is. Credential management is per-account: one user must not
    #: be able to see, use or delete another user's keys.
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="ai_credentials", null=True, blank=True, db_index=True,
    )
    provider = models.CharField(max_length=32, db_index=True)

    #: What the user calls it: "OpenAI Production", "Backup", "Testing".
    label = models.CharField(max_length=80)
    description = models.CharField(max_length=300, blank=True)

    #: Fernet ciphertext. See outreach/credentials.py for the key derivation.
    secret = models.TextField()
    #: Masked form for display. Never enough to reconstruct the key.
    hint = models.CharField(max_length=64, blank=True)
    #: Non-secret provider configuration: base URL, organisation id.
    extras = models.JSONField(default=dict, blank=True)
    #: Optional model override carried with this key, so a testing credential can
    #: point at a cheaper model than the production one.
    model = models.CharField(max_length=120, blank=True)

    #: The one the application uses. At most one per (owner, provider).
    is_active = models.BooleanField(default=False, db_index=True)
    #: Whether this key may be tried when the active one hits a rate limit.
    #: Off by default: rotation must be something the user asked for, never
    #: something that happens quietly behind a failure.
    allow_fallback = models.BooleanField(default=False)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    # --- usage, all of it safe to display --------------------------------- #
    #: Null means "never", which the UI shows as Unknown rather than as a zero
    #: date. An invented timestamp is worse than an absent one.
    last_used_at = models.DateTimeField(null=True, blank=True)
    last_success_at = models.DateTimeField(null=True, blank=True)
    last_error_at = models.DateTimeField(null=True, blank=True)
    request_count = models.PositiveIntegerField(default=0)
    error_count = models.PositiveIntegerField(default=0)

    #: A category (`invalid`, `rate_limited`, `unavailable`), never the provider's
    #: own error text: that can quote request details, and request details can
    #: contain the key.
    last_error_category = models.CharField(max_length=32, blank=True)
    last_error_detail = models.CharField(max_length=300, blank=True)

    #: Outcome of the last Test Connection. Also a category, for the same reason.
    last_test_result = models.CharField(max_length=120, blank=True)
    last_tested_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        # Created in the `outreach` app and moved here. The name is
        # pinned so no data moves and the Supabase row-level-security
        # policies, which name this table, stay correct.
        db_table = "outreach_providercredential"
        ordering = ("provider", "-is_active", "label")
        constraints = [
            # The parent/child rule, in the database. Two tabs both pressing
            # Activate cannot leave a provider with two active keys.
            models.UniqueConstraint(
                fields=("owner", "provider"), condition=models.Q(is_active=True),
                name="one_active_credential_per_provider_per_owner",
            ),
            # Labels are how the user tells their keys apart, so they have to be
            # distinct within a provider.
            models.UniqueConstraint(
                fields=("owner", "provider", "label"),
                name="one_label_per_provider_per_owner",
            ),
        ]
        indexes = [models.Index(fields=("owner", "provider", "is_active"),
                                name="pc_owner_prov_active_idx")]

    def __str__(self) -> str:
        # The hint, never the secret: a stray repr in a log or a traceback must
        # not carry a key.
        state = "active" if self.is_active else "inactive"
        return f"{self.provider}/{self.label} ({self.hint or 'set'}, {state})"

    @property
    def status(self) -> str:
        """One word for the card: active, inactive, or failing."""
        if self.last_error_category and not self.is_active:
            return "error"
        if self.is_active and self.last_error_category and (
            self.last_success_at is None
            or (self.last_error_at and self.last_error_at > self.last_success_at)
        ):
            return "failing"
        return "active" if self.is_active else "inactive"

    @property
    def status_label(self) -> str:
        return {
            "active": "Active",
            "inactive": "Inactive",
            "failing": "Active — last request failed",
            "error": "Last request failed",
        }[self.status]
class CredentialEvent(models.Model):
    """A safe audit trail for one credential.

    Exists so two questions have answers: "which key did that request actually
    use?" and "why did it fall back?". Both matter when a provider bill or a
    failure has to be explained.

    Deliberately carries no secret and no provider response body -- only a
    category, a label and a timestamp. A log line is exactly the wrong place for
    an API key, and a provider error can quote the request that contained one.
    """

    class Kind(models.TextChoices):
        CREATED = "created", "Added"
        ACTIVATED = "activated", "Activated"
        DEACTIVATED = "deactivated", "Deactivated"
        DELETED = "deleted", "Deleted"
        TESTED = "tested", "Connection tested"
        USED = "used", "Request succeeded"
        ERROR = "error", "Request failed"
        FALLBACK = "fallback", "Fell back to another credential"

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="credential_events", null=True, blank=True, db_index=True,
    )
    credential = models.ForeignKey(
        ProviderCredential, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="events",
    )
    #: Snapshots, so the trail still reads after a credential is deleted.
    provider = models.CharField(max_length=32, db_index=True)
    label = models.CharField(max_length=80, blank=True)

    kind = models.CharField(max_length=16, choices=Kind.choices)
    #: `invalid`, `rate_limited`, `unavailable`, `ok` -- a category, never a body.
    category = models.CharField(max_length=32, blank=True)
    detail = models.CharField(max_length=300, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        # Created in the `outreach` app and moved here. The name is
        # pinned so no data moves and the Supabase row-level-security
        # policies, which name this table, stay correct.
        db_table = "outreach_credentialevent"
        ordering = ("-created_at",)
        indexes = [models.Index(fields=("owner", "provider", "-created_at"),
                                name="ce_owner_prov_time_idx")]

    def __str__(self) -> str:
        return f"{self.provider}/{self.label} {self.kind} {self.created_at:%Y-%m-%d %H:%M}"
class AiSelection(models.Model):
    """Which provider and model one account has chosen.

    Per-account for the same reason the credentials are: two users of one
    deployment should be able to work on different providers without changing each
    other's settings.

    `OUTREACH_AI_PROVIDER` still works and is the fallback, so a deployment that
    never opens Settings behaves exactly as it did.
    """

    owner = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="ai_selection", null=True, blank=True,
    )
    provider = models.CharField(max_length=32, blank=True)
    model = models.CharField(max_length=120, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        # Created in the `outreach` app and moved here. The name is pinned so no
        # data moves and the Supabase row-level-security policies, which name this
        # table, stay correct.
        db_table = "outreach_aiselection"

    def __str__(self) -> str:
        return f"{self.provider or 'default'} / {self.model or 'default model'}"
