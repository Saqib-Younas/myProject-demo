"""
The approved outreach templates, and the one thing that differs between them.

There is one email in this application -- a first-contact note built on verified
crawler findings -- and every rule about it lives in `ai.SYSTEM`: never invent a
problem, never promise a result, never mention a metric, never sound mass-sent.
None of that is negotiable per campaign, so none of it is in here.

What *is* a real choice is how long the email should be, and that turned out to be
two different products:

  * **Consultative** takes each finding in turn and explains why it matters. That
    needs 250-500 words; below about 250 it becomes a list of complaints with no
    reasoning attached, which is the thing the audit work exists to avoid.
  * **Brief** names the strongest finding, says what it costs the business, and
    asks. 90-150 words. Higher reply rate on cold traffic, and it cannot carry
    three findings, so it carries one properly.

Both were specified, at different times, as *the* format. Rather than pick one and
quietly lose the other, the campaign says which it wants, and the word band and one
prompt rule follow from that. Everything else about the two emails is identical --
same evidence, same bans, same refusal to invent.

A style is chosen by key, from `STYLES`. An unknown key falls back to the default
with a log line rather than to free text: the alternative is an email in a shape
nobody approved.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class Style:
    """One approved template.

    `min_words`/`max_words` are the band the *code* enforces after generation, and
    they are wider than the band the prompt asks for. Deliberately: a 240-word
    email when 250 was requested is a good email, and regenerating it costs a
    provider call to fix nothing a reader would notice. The prompt aims; the check
    catches the drafts that missed by enough to matter.
    """

    key: str
    label: str
    summary: str
    #: The sentence that becomes rule 6 of the system prompt.
    length_rule: str
    #: What the JSON schema tells the model about the body.
    schema_hint: str
    #: The enforced band, and the number a rewrite is asked to aim for.
    min_words: int
    max_words: int
    aim: int
    #: How many findings this shape can carry properly.
    max_findings: int = 3

    @property
    def band(self) -> str:
        return f"{self.min_words}-{self.max_words} words"


CONSULTATIVE = Style(
    key="consultative",
    label="Website audit — consultative",
    summary=(
        "Takes one to three verified findings in turn and explains what each one "
        "costs the business. 250-500 words. Best where the recipient is likely to "
        "read properly, and where the findings need reasoning rather than a list."
    ),
    length_rule=(
        "6. Length: 250-500 words in the body, and closer to 300 than 500. Short "
        "paragraphs, a blank line between each. Nothing is appended after your "
        "text, so close the email yourself."
    ),
    schema_hint=(
        "The email body as plain text, 250-500 words, paragraphs separated by "
        "blank lines, closing with the sender's name, company and email."
    ),
    # 210/560 rather than 250/500: see the note on Style.
    min_words=210,
    max_words=560,
    aim=300,
    max_findings=3,
)

BRIEF = Style(
    key="brief",
    label="Website audit — brief",
    summary=(
        "Names the strongest verified finding, says what it costs, and asks. "
        "90-150 words, ideally 100-120. Best for cold first contact, where a long "
        "email is read as a sales letter and deleted."
    ),
    length_rule=(
        "6. Length: 90-150 words in the body, and ideally 100-120. This is a short "
        "note, not a report: lead with the single strongest finding, give it two "
        "or three sentences, and stop. Mention a second finding only if it takes "
        "one sentence. Short paragraphs, a blank line between each. Nothing is "
        "appended after your text, so close the email yourself."
    ),
    schema_hint=(
        "The email body as plain text, 90-150 words, paragraphs separated by "
        "blank lines, closing with the sender's name, company and email."
    ),
    # 80/175: the same tolerance either side as the consultative band.
    min_words=80,
    max_words=175,
    aim=120,
    max_findings=2,
)

STYLES: dict[str, Style] = {style.key: style for style in (CONSULTATIVE, BRIEF)}

DEFAULT_STYLE = CONSULTATIVE


def style(key: str | None) -> Style:
    """The style for a key, falling back to the default with a log line."""
    if not key:
        return DEFAULT_STYLE
    found = STYLES.get(key)
    if found is None:
        log.warning("unknown email template %r -- using %s", key,
                    DEFAULT_STYLE.key)
        return DEFAULT_STYLE
    return found


def choices() -> list[tuple[str, str]]:
    """For a form field."""
    return [(s.key, s.label) for s in STYLES.values()]
