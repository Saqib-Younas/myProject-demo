"""
The six things a website review looks at, and which one a finding belongs to.

One table, shared by the prompt that tells the model to cover all six, the report
that groups findings under them, and the scoring that weights them. Three readers of
one definition, so they cannot drift into describing different reviews.

`category_of` is deliberately two-pass -- dimension first, then wording. A finding
about "local SEO" is an SEO finding even though it mentions a place, and a finding
about a mobile layout is a user-experience one even though "mobile" appears in the
technical word list. Matching words first got both wrong.
"""

from __future__ import annotations

import re

#: The six kinds of problem a website review has to cover, and what belongs in
#: each. Named explicitly because a model asked to "review this website" reliably
#: returns SEO and layout notes -- the things easiest to describe -- and stops
#: there. The findings a business owner actually acts on are usually in the first
#: category, and nothing in an unguided review ever lands there.
#:
#: The order is the order they matter in commercially, which is also the order
#: `scoring.rank_for_email` ranks them in.
REVIEW_CATEGORIES: tuple[tuple[str, str, tuple[str, ...]], ...] = (
    ("business", "Business and logical gaps", (
        "what the business actually does, stated plainly",
        "who it is for -- the target customer",
        "services or products explained rather than listed",
        "pricing, or any indication of cost",
        "service area or locations covered",
        "how it works -- the process a customer goes through",
        "what makes it different from a competitor",
        "guarantees, policies and terms",
        "opening hours and how to reach a human",
        "information a customer would reasonably expect and cannot find",
    )),
    ("ux", "Customer journey and conversion", (
        "can a visitor tell what to do next",
        "calls to action -- present, obvious, and in the right place",
        "how many steps stand between interest and contact",
        "navigation that matches how a customer thinks",
        "contact and enquiry flow",
        "important information buried too deep to find",
        "missed opportunities to capture an enquiry",
    )),
    ("content", "Content quality and completeness", (
        "clear, complete, customer-focused writing",
        "thin, repetitive or placeholder content",
        "missing service explanations or benefits",
        "missing FAQs -- the questions asked before buying",
        "unclear messaging or jargon",
    )),
    ("trust", "Trust and credibility", (
        "testimonials, reviews, case studies, portfolio",
        "certifications, accreditations, licences, insurance",
        "team or founder information",
        "years in business, experience, results",
        "real business address and contact details",
        "only the signals that make sense for this kind of business",
    )),
    ("seo", "Search visibility", (
        "page titles and meta descriptions",
        "heading structure and keyword targeting",
        "search intent the page answers",
        "internal linking and URL structure",
        "image alt text",
        "content depth, duplicate or thin pages",
        "local SEO and structured data",
    )),
    ("technical", "Technical health", (
        "performance and page weight",
        "mobile rendering",
        "forms that work",
        "HTTPS and visible security problems",
        "accessibility",
        "anything technically incorrect that affects a visitor",
    )),
)
#: Flat list, for the prompt and for the tests that check coverage.
REVIEW_DIMENSIONS = tuple(
    item for _key, _label, items in REVIEW_CATEGORIES for item in items
)
#: The category keys, in commercial order.
CATEGORY_KEYS = tuple(key for key, _label, _items in REVIEW_CATEGORIES)
#: Label for each key, for the audit shown on the lead page.
CATEGORY_LABELS = {key: label for key, label, _items in REVIEW_CATEGORIES}
#: Words that place a finding in a category, checked in commercial order so a
#: finding that could sit in two lands in the one that matters more to the
#: business.
#:
#: Matched on word boundaries, and as stems where a word inflects. Substring
#: matching was tried first and produced two silent misclassifications: "form"
#: matches inside "performance", so every speed finding became a conversion
#: finding; and the keyword "call to action" never matched the phrase "calls to
#: action", because the plural puts an 's' in the middle.
_CATEGORY_WORDS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("business", (r"business", r"logic\w*", r"pricing", r"price\w*", r"cost\w*",
                  r"service area\w*", r"location\w*", r"process\w*",
                  r"how it works", r"differentiat\w*", r"value proposition",
                  r"target customer\w*", r"audience", r"hours",
                  r"guarantee\w*", r"warrant\w*", r"polic\w*", r"terms",
                  r"offering\w*", r"service\w* clarity", r"product\w* clarity",
                  r"opening times")),
    ("ux", (r"ux", r"usability", r"journey", r"conversion", r"convert\w*",
            r"call\w* to action", r"call\w*-to-action", r"cta\w*",
            r"navigation", r"menu", r"contact experience", r"contact flow",
            r"enquir\w*", r"inquir\w*", r"form\w*", r"lead capture",
            r"funnel", r"user flow", r"friction", r"booking")),
    ("content", (r"content", r"cop(?:y|ywriting)", r"messaging", r"writing",
                 r"grammar", r"readability", r"faq\w*", r"thin", r"placeholder",
                 r"benefit\w*", r"explanation\w*", r"jargon")),
    ("trust", (r"trust\w*", r"credibilit\w*", r"testimonial\w*", r"review\w*",
               r"case stud\w*", r"portfolio", r"certificat\w*",
               r"accredit\w*", r"licen[cs]\w*", r"insur\w*", r"team",
               r"social proof", r"award\w*", r"experience", r"reputation")),
    ("seo", (r"seo", r"search", r"title\w*", r"meta", r"heading\w*",
             r"keyword\w*", r"canonical", r"sitemap", r"schema",
             r"structured data", r"alt text", r"alt attribute", r"index\w*",
             r"url\w*", r"snippet\w*")),
    ("technical", (r"technical", r"performance", r"speed", r"slow", r"load\w*",
                   r"mobile", r"responsive\w*", r"viewport", r"accessibilit\w*",
                   r"https", r"ssl", r"securit\w*", r"image\w*", r"script\w*",
                   r"markup", r"broken", r"redirect\w*", r"page weight")),
)
#: Compiled once, in the same commercial order.
_CATEGORY_PATTERNS: tuple[tuple[str, "re.Pattern"], ...] = tuple(
    (key, re.compile(r"\b(?:" + "|".join(words) + r")\b", re.IGNORECASE))
    for key, words in _CATEGORY_WORDS
)
def category_of(finding) -> str:
    """Which of the six categories a finding belongs to.

    Derived from the finding's own `dimension` rather than asked of the model. A
    seventh required schema field is a whole reply lost when the model forgets it
    -- which has happened here before -- and the dimension already carries the
    information.
    """
    dimension = getattr(finding, "dimension", "") or ""
    for key, pattern in _CATEGORY_PATTERNS:
        if pattern.search(dimension):
            return key

    # Only now the issue text, for a reviewer that left the dimension vague.
    issue = getattr(finding, "issue", "") or ""
    for key, pattern in _CATEGORY_PATTERNS:
        if pattern.search(issue):
            return key

    # Unclassifiable lands in "business": a finding described in words this table
    # has not seen is far more often a business gap than a favicon.
    return "business"
