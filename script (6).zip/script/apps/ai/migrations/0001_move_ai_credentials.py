"""
The credential models arrive in this app, without touching the database.

They were created in `outreach` (migrations 0009 and 0013) and their tables already
exist with rows in them, so this migration changes *ownership*, not schema:
`SeparateDatabaseAndState` with no database operations updates Django's own picture of
which app holds these models and emits no SQL.

`outreach.0023_move_ai_credentials` is the other half, and depends on this one, so the
order is fixed:

    outreach.0022  ->  ai.0001  ->  outreach.0023

The models pin `db_table` to the original `outreach_*` names. Renaming the tables
would have been a real schema change for no benefit, and `sql/supabase_setup.sql`
names them in its row-level-security policies.
"""
import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        # The state these models are being taken out of. Without this the two apps
        # could be migrated in an order where both of them claim the models.
        ("outreach", "0022_audit_jobs"),
    ]

    operations = [
        migrations.SeparateDatabaseAndState(
            # Nothing. The tables already exist, with their rows in them.
            database_operations=[],
            state_operations=[
                migrations.CreateModel(
                    name='AiSelection',
                    fields=[
                        ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                        ('provider', models.CharField(blank=True, max_length=32)),
                        ('model', models.CharField(blank=True, max_length=120)),
                        ('updated_at', models.DateTimeField(auto_now=True)),
                        ('owner', models.OneToOneField(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, related_name='ai_selection', to=settings.AUTH_USER_MODEL)),
                    ],
                    options={
                        'db_table': 'outreach_aiselection',
                    },
                ),
                migrations.CreateModel(
                    name='ProviderCredential',
                    fields=[
                        ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                        ('provider', models.CharField(db_index=True, max_length=32)),
                        ('label', models.CharField(max_length=80)),
                        ('description', models.CharField(blank=True, max_length=300)),
                        ('secret', models.TextField()),
                        ('hint', models.CharField(blank=True, max_length=64)),
                        ('extras', models.JSONField(blank=True, default=dict)),
                        ('model', models.CharField(blank=True, max_length=120)),
                        ('is_active', models.BooleanField(db_index=True, default=False)),
                        ('allow_fallback', models.BooleanField(default=False)),
                        ('created_at', models.DateTimeField(auto_now_add=True)),
                        ('updated_at', models.DateTimeField(auto_now=True)),
                        ('last_used_at', models.DateTimeField(blank=True, null=True)),
                        ('last_success_at', models.DateTimeField(blank=True, null=True)),
                        ('last_error_at', models.DateTimeField(blank=True, null=True)),
                        ('request_count', models.PositiveIntegerField(default=0)),
                        ('error_count', models.PositiveIntegerField(default=0)),
                        ('last_error_category', models.CharField(blank=True, max_length=32)),
                        ('last_error_detail', models.CharField(blank=True, max_length=300)),
                        ('last_test_result', models.CharField(blank=True, max_length=120)),
                        ('last_tested_at', models.DateTimeField(blank=True, null=True)),
                        ('owner', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, related_name='ai_credentials', to=settings.AUTH_USER_MODEL)),
                    ],
                    options={
                        'db_table': 'outreach_providercredential',
                        'ordering': ('provider', '-is_active', 'label'),
                    },
                ),
                migrations.CreateModel(
                    name='CredentialEvent',
                    fields=[
                        ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                        ('provider', models.CharField(db_index=True, max_length=32)),
                        ('label', models.CharField(blank=True, max_length=80)),
                        ('kind', models.CharField(choices=[('created', 'Added'), ('activated', 'Activated'), ('deactivated', 'Deactivated'), ('deleted', 'Deleted'), ('tested', 'Connection tested'), ('used', 'Request succeeded'), ('error', 'Request failed'), ('fallback', 'Fell back to another credential')], max_length=16)),
                        ('category', models.CharField(blank=True, max_length=32)),
                        ('detail', models.CharField(blank=True, max_length=300)),
                        ('created_at', models.DateTimeField(auto_now_add=True, db_index=True)),
                        ('owner', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, related_name='credential_events', to=settings.AUTH_USER_MODEL)),
                        ('credential', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='events', to='ai.providercredential')),
                    ],
                    options={
                        'db_table': 'outreach_credentialevent',
                        'ordering': ('-created_at',),
                    },
                ),
                migrations.AddIndex(
                    model_name='providercredential',
                    index=models.Index(fields=['owner', 'provider', 'is_active'], name='pc_owner_prov_active_idx'),
                ),
                migrations.AddConstraint(
                    model_name='providercredential',
                    constraint=models.UniqueConstraint(condition=models.Q(('is_active', True)), fields=('owner', 'provider'), name='one_active_credential_per_provider_per_owner'),
                ),
                migrations.AddConstraint(
                    model_name='providercredential',
                    constraint=models.UniqueConstraint(fields=('owner', 'provider', 'label'), name='one_label_per_provider_per_owner'),
                ),
                migrations.AddIndex(
                    model_name='credentialevent',
                    index=models.Index(fields=['owner', 'provider', '-created_at'], name='ce_owner_prov_time_idx'),
                ),
            ],
        ),
    ]
