"""
Talking to a language model: credentials, prompts, requests, and what comes back.

This package is the whole of this application's AI surface. Nothing outside it
imports a provider SDK, builds a prompt, or decides which key to use -- and nothing
inside it imports a domain app, so the dependency runs one way only.

    base.py         the data types every layer passes around
    categories.py   the six dimensions a review covers
    prompts.py      every system prompt, schema and prompt builder
    client.py       provider resolution and the single request path
    parsing.py      model reply -> Finding / GeneratedEmail / SiteAudit
    validation.py   whether a draft may be used, and what is wrong with it
    reports.py      the audit, grouped for a person to read
    generation.py   audit() / generate() / no_website_email() / follow_up()
    credentials.py  the credential pool: which key, and what it has cost
    context.py      the request's owner, for code three layers from a view
    styles.py       the approved email templates
    backends/       one module per provider

The names below are re-exported so a caller can write `ai.generate(...)` without
knowing which module it lives in. That is the package's public API; anything not
listed here is internal to it.
"""

from apps.ai.base import (
    QUOTA,
    RATE_LIMIT,
    AiError,
    Finding,
    GeneratedEmail,
    SiteAudit,
    classify_rate_limit,
    retry_after_of,
)

from .categories import (
    CATEGORY_KEYS,
    CATEGORY_LABELS,
    REVIEW_CATEGORIES,
    REVIEW_DIMENSIONS,
    category_of,
)
from .client import (
    DEFAULT_PROVIDER,
    PROVIDERS,
    _complete,
    backend,
    describe_credentials,
    describe_provider,
    load,
    model,
    provider,
)
from .generation import audit, follow_up, generate, no_website_email
from .parsing import parse, parse_audit, parse_followup, parse_no_website
from .prompts import (
    AUDIT_MAX_TOKENS,
    AUDIT_SCHEMA,
    AUDIT_SYSTEM,
    DEFAULT_OFFER,
    EMAIL_MAX_TOKENS,
    EMAIL_SIGNALS,
    FOLLOWUP_SCHEMA,
    FOLLOWUP_SYSTEM,
    MAX_FINDINGS,
    NO_WEBSITE_SCHEMA,
    NO_WEBSITE_SYSTEM,
    SCHEMA,
    SCHEMA_TEMPLATE,
    SYSTEM,
    SYSTEM_TEMPLATE,
    attribute_pages,
    build_audit_prompt,
    build_followup_prompt,
    build_no_website_prompt,
    build_prompt,
    reply_subject,
    schema_for,
    system_for,
)
from .reports import PRIORITY_LABELS, PRIORITY_ORDER, audit_report
from .validation import (
    BANNED_PHRASES,
    BANNED_STEMS,
    BENEFIT_WITHHELD,
    EMAIL_MAX_WORDS,
    EMAIL_MIN_WORDS,
    FINDING_PREFIX,
    GREETING,
    HEDGES,
    METRIC_PATTERNS,
    UNVERIFIED_PHRASE,
    VAGUE_PATTERNS,
    assign_ids,
    call_duration_problem,
    draft_problem,
    find_by_reference,
    greeting_problem,
    hedge_findings,
    is_unverified,
    specificity_problem,
    style_problem,
    traceability_problem,
    unhedged_benefit,
)

__all__ = [
    # base
    "QUOTA", "RATE_LIMIT", "AiError", "Finding", "GeneratedEmail",
    "SiteAudit", "classify_rate_limit", "retry_after_of",
    # categories
    "CATEGORY_KEYS", "CATEGORY_LABELS", "REVIEW_CATEGORIES",
    "REVIEW_DIMENSIONS", "category_of",
    # client
    "DEFAULT_PROVIDER", "PROVIDERS", "_complete", "backend",
    "describe_credentials", "describe_provider", "load", "model", "provider",
    # generation
    "audit", "follow_up", "generate", "no_website_email",
    # parsing
    "parse", "parse_audit", "parse_followup", "parse_no_website",
    # prompts
    "AUDIT_MAX_TOKENS", "AUDIT_SCHEMA", "AUDIT_SYSTEM", "DEFAULT_OFFER",
    "EMAIL_MAX_TOKENS", "EMAIL_SIGNALS", "FOLLOWUP_SCHEMA", "FOLLOWUP_SYSTEM",
    "MAX_FINDINGS", "NO_WEBSITE_SCHEMA", "NO_WEBSITE_SYSTEM", "SCHEMA",
    "SCHEMA_TEMPLATE", "SYSTEM", "SYSTEM_TEMPLATE", "attribute_pages",
    "build_audit_prompt", "build_followup_prompt", "build_no_website_prompt",
    "build_prompt", "reply_subject", "schema_for", "system_for",
    # reports
    "PRIORITY_LABELS", "PRIORITY_ORDER", "audit_report",
    # validation
    "BANNED_PHRASES", "BANNED_STEMS", "BENEFIT_WITHHELD", "EMAIL_MAX_WORDS",
    "EMAIL_MIN_WORDS", "FINDING_PREFIX", "GREETING", "HEDGES", "METRIC_PATTERNS",
    "UNVERIFIED_PHRASE", "VAGUE_PATTERNS", "assign_ids",
    "call_duration_problem", "draft_problem",
    "find_by_reference", "greeting_problem", "hedge_findings", "is_unverified",
    "specificity_problem", "style_problem", "traceability_problem",
    "unhedged_benefit",
]
