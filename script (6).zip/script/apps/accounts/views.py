"""
Login, signup and logout.

These three are the only views in the project that an anonymous visitor may
reach, marked with `@login_not_required` because `LoginRequiredMiddleware`
protects everything by default. That default is the point: a view added later is
protected without anybody remembering to protect it.

Three behaviours worth naming, because each is a decision rather than a default:

  * **A failed login never says which half was wrong.** "No account with that
    email" tells an attacker which addresses are worth guessing passwords for.
  * **The session key is cycled on login.** Django's `login()` does this, which
    is what stops a session fixed before authentication from being reused after.
  * **Logout is POST-only.** A GET logout can be triggered by an image tag on
    any page, which is a nuisance rather than a breach, but it is also trivial to
    avoid.
"""

from __future__ import annotations

from django.contrib.auth import authenticate
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as auth_logout
from django.contrib.auth.decorators import login_not_required
from django.http import HttpRequest, HttpResponse
from django.shortcuts import redirect, render
from django.urls import reverse
from django.views.decorators.debug import sensitive_post_parameters
from django.views.decorators.http import require_GET, require_POST

from .forms import LoginForm, SignUpForm

#: Where a signed-in user goes. Kept as a name rather than a path so the URL can
#: move without this changing.
HOME = "dashboard"


def _safe_next(request: HttpRequest) -> str:
    """The `?next=` target, but only if it is somewhere on this site.

    An open redirect is a real phishing primitive: a link to
    /login?next=https://evil.example lands the user on a convincing lookalike
    straight after they authenticate. Django's own helper decides.
    """
    from django.utils.http import url_has_allowed_host_and_scheme

    candidate = request.POST.get("next") or request.GET.get("next") or ""
    if candidate and url_has_allowed_host_and_scheme(
        candidate, allowed_hosts={request.get_host()},
        require_https=request.is_secure(),
    ):
        return candidate
    return reverse(HOME)


@sensitive_post_parameters("password")
@login_not_required
def login_view(request: HttpRequest) -> HttpResponse:
    """Sign in with an email and password."""
    if request.user.is_authenticated:
        return redirect(HOME)

    form = LoginForm(request.POST or None)
    error = ""

    if request.method == "POST" and form.is_valid():
        user = authenticate(
            request,
            username=form.cleaned_data["email"],
            password=form.cleaned_data["password"],
        )
        if user is not None:
            auth_login(request, user)   # cycles the session key
            return redirect(_safe_next(request))

        # One message for a wrong password, an unknown address and a disabled
        # account alike. Which of the three it was is not the visitor's business.
        error = ("Those details do not match an account. Check the email "
                 "address and password, then try again.")
    elif request.method == "POST":
        error = "Check the highlighted fields and try again."

    return render(request, "accounts/login.html", {
        "form": form,
        "error": error,
        "next": request.GET.get("next", ""),
        "nav": "login",
    })


@sensitive_post_parameters("password", "confirm_password")
@login_not_required
def signup_view(request: HttpRequest) -> HttpResponse:
    """Create an account, then sign straight in with it."""
    if request.user.is_authenticated:
        return redirect(HOME)

    form = SignUpForm(request.POST or None)
    error = ""

    if request.method == "POST" and form.is_valid():
        user = form.save()
        # Authenticate rather than calling login() with the object, so the
        # session records which backend was used -- without it, later requests
        # cannot rehydrate the user.
        signed_in = authenticate(
            request, username=user.email,
            password=form.cleaned_data["password"],
        )
        if signed_in is not None:
            auth_login(request, signed_in)
            return redirect(HOME)
        # Should not happen; if it does, the account exists and login works.
        return redirect(f"{reverse('login')}?created=1")
    elif request.method == "POST":
        error = "Check the highlighted fields and try again."

    return render(request, "accounts/signup.html", {
        "form": form,
        "error": error,
        "nav": "signup",
    })


@require_POST
def logout_view(request: HttpRequest) -> HttpResponse:
    """Sign out and destroy the session.

    `logout()` flushes the session row and the cookie, so the old session key is
    worthless afterwards -- the back button shows a cached page at most, and any
    request it makes is unauthenticated.
    """
    auth_logout(request)
    return redirect("login")


@require_GET
@login_not_required
def session_state(request: HttpRequest) -> HttpResponse:
    """Whether this request is authenticated. No account details in the answer.

    Used by the front end to tell "still loading" apart from "signed out" without
    guessing from a redirect.
    """
    from django.http import JsonResponse

    return JsonResponse({
        "authenticated": request.user.is_authenticated,
        "name": (request.user.get_short_name() or request.user.get_username()
                 if request.user.is_authenticated else ""),
        "login_url": reverse("login"),
    })
