"""
Login and signup forms.

Validation lives here rather than in the views, because a form is the one place
Django will run it on every path -- a hand-rolled check in a view is skipped the
moment someone adds a second caller. The browser also validates, but that is a
convenience: everything below runs server-side regardless of what the client did.

Nothing here ever puts a password back into a rendered form. Django's password
widgets do not re-render their value, and the errors below name the field at
fault without echoing what was typed.
"""

from __future__ import annotations

from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError

User = get_user_model()

#: Django's User.username is 150 characters; an email can be longer than that in
#: principle, so the address is stored in `email` and a stable derived value goes
#: in `username`. See SignUpForm.save().
MAX_EMAIL = 254


class LoginForm(forms.Form):
    """Email and password. Deliberately says nothing about which one was wrong."""

    email = forms.EmailField(
        max_length=MAX_EMAIL,
        widget=forms.EmailInput(attrs={
            "class": "input", "autocomplete": "email", "autofocus": True,
            "placeholder": "you@company.com", "spellcheck": "false",
            # A phone keyboard should offer @ and not capitalise the first
            # letter -- an address it capitalises is an address that fails.
            "inputmode": "email", "autocapitalize": "none",
        }),
    )
    password = forms.CharField(
        strip=False,
        widget=forms.PasswordInput(attrs={
            "class": "input", "autocomplete": "current-password",
            "placeholder": "Your password",
        }),
    )

    def clean_email(self) -> str:
        return self.cleaned_data["email"].strip().lower()


class SignUpForm(forms.Form):
    """Name, email, password, confirmation."""

    name = forms.CharField(
        max_length=150,
        widget=forms.TextInput(attrs={
            "class": "input", "autocomplete": "name", "autofocus": True,
            "placeholder": "Your name", "autocapitalize": "words",
        }),
    )
    email = forms.EmailField(
        max_length=MAX_EMAIL,
        widget=forms.EmailInput(attrs={
            "class": "input", "autocomplete": "email",
            "placeholder": "you@company.com", "spellcheck": "false",
            "inputmode": "email", "autocapitalize": "none",
        }),
    )
    password = forms.CharField(
        strip=False,
        widget=forms.PasswordInput(attrs={
            "class": "input", "autocomplete": "new-password",
            "placeholder": "At least 10 characters",
        }),
        help_text="At least 10 characters, and not a password everybody uses.",
    )
    confirm_password = forms.CharField(
        strip=False,
        widget=forms.PasswordInput(attrs={
            "class": "input", "autocomplete": "new-password",
            "placeholder": "Type it again",
        }),
    )

    def clean_name(self) -> str:
        return " ".join(self.cleaned_data["name"].split())

    def clean_email(self) -> str:
        email = self.cleaned_data["email"].strip().lower()
        # Case-insensitive, matching how EmailBackend looks accounts up. A
        # case-sensitive check here would let Sam@x.com and sam@x.com both
        # register and then make login ambiguous.
        if User.objects.filter(email__iexact=email).exists():
            raise ValidationError(
                "An account already exists for this email address. "
                "Sign in instead, or use a different address."
            )
        return email

    def clean_password(self) -> str:
        password = self.cleaned_data["password"]
        # Django's configured validators: length, commonness, all-numeric, and
        # similarity to the user's own details.
        validate_password(password, User(
            username=self.data.get("email", ""),
            email=self.data.get("email", ""),
            first_name=self.data.get("name", ""),
        ))
        return password

    def clean(self) -> dict:
        cleaned = super().clean()
        password = cleaned.get("password")
        confirm = cleaned.get("confirm_password")
        if password and confirm and password != confirm:
            # Attached to the confirmation field, so the error appears next to
            # the box the user needs to fix.
            self.add_error("confirm_password", "The two passwords do not match.")
        return cleaned

    def save(self) -> User:
        """Create the account. The password is hashed, never stored as typed.

        `username` is set from the email because Django requires a unique
        username, and a second field for the user to invent would be a field
        nobody wants. An address longer than the username column is truncated and
        de-duplicated; `email` always holds the real thing, and that is what
        login uses.
        """
        email = self.cleaned_data["email"]
        return User.objects.create_user(
            username=_unique_username(email),
            email=email,
            password=self.cleaned_data["password"],   # hashed by create_user
            first_name=self.cleaned_data["name"][:150],
        )


def _unique_username(email: str) -> str:
    """A username derived from the email that fits the column and is unique."""
    base = email[:150]
    if not User.objects.filter(username=base).exists():
        return base

    stem = base[:140]
    for suffix in range(2, 1000):
        candidate = f"{stem}-{suffix}"
        if not User.objects.filter(username=candidate).exists():
            return candidate
    raise ValidationError("Could not allocate an account name. Try again.")
