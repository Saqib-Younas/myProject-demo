"""
No models here.

Accounts use `django.contrib.auth.models.User` unchanged. Email is the login
identifier, which needs an authentication backend (see backends.py) rather than a
custom user model -- swapping the user model is a one-way decision with migration
consequences, and nothing here needs a field User does not already have.

Ownership of leads, campaigns and history lives on those models in the outreach
app, as a foreign key to this user.
"""
