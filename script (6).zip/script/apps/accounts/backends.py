"""
Log in with an email address.

Django's ModelBackend authenticates on `username`. This application asks for an
email, so the lookup happens on `email` instead -- case-insensitively, because
nobody thinks of Sam@example.com and sam@example.com as different accounts.

Two details that matter more than they look:

  * `filter(...).first()` rather than `get()`, so a duplicate email cannot raise
    MultipleObjectsReturned. Signup blocks duplicates, but a row created before
    that rule existed must not break login.
  * a wasted password hash when no user matches, so a request for a
    non-existent account takes about as long as one for a real account. Without
    it, response time answers "does this email have an account?".
"""

from __future__ import annotations

from django.contrib.auth import get_user_model
from django.contrib.auth.backends import ModelBackend


class EmailBackend(ModelBackend):
    """Authenticate on email + password."""

    def authenticate(self, request, username=None, password=None, **kwargs):
        User = get_user_model()
        email = (kwargs.get("email") or username or "").strip()

        if not email or not password:
            return None

        user = User.objects.filter(email__iexact=email).order_by("pk").first()
        if user is None:
            # Same work as the success path, so timing does not reveal whether
            # the address exists.
            User().set_password(password)
            return None

        if user.check_password(password) and self.user_can_authenticate(user):
            return user
        return None
