"""
Fetching a website politely, and stopping when asked.

The crawl half of the audit: robots.txt, rate limiting, link discovery, sitemaps, and
the loop that reads a handful of pages. What it *measures* lives in `measurements`;
this module decides what to fetch, and whether it may.

Four rules it will not break, each of them somebody else's bandwidth or somebody
else's boundary:

  * **robots.txt first**, cached with an expiry so a worker that runs for weeks still
    notices a rule added today. A 401 or 403 on robots.txt is read as "stay out".
  * **One host, one page at a time**, with a delay between requests. Link discovery
    never leaves the site it started on.
  * **A bot wall is a no.** A login page, a CAPTCHA or a Cloudflare interstitial ends
    the crawl for that site rather than starting an attempt to get around it.
  * **Every URL is checked before it is fetched**, including every redirect hop, when
    the caller supplies a guard. A public site redirecting to `127.0.0.1` is the
    shortest route from "audit my website" to reading the server's own admin pages.

`analyse()` is the entry point. It never raises: an unreachable site, a refusal and a
bot wall are all *results*, because one bad website must never end a run of leads.
"""

from __future__ import annotations

import logging
import os
import re
import threading
import time
from dataclasses import dataclass, field
from urllib.parse import urljoin, urlparse, urlunparse
from urllib.robotparser import RobotFileParser

import requests
from bs4 import BeautifulSoup

from .measurements import (
    FOOTER_CONTAINERS,
    MIN_PAGE_TEXT,
    NAV_CONTAINERS,
    PAGE_KINDS,
    SKIP_PATTERN,
    Fetched,
    Page,
    _format_facts,
    extract,
    scrape_emails,
)

# --------------------------------------------------------------------------- #
# Crawl budget and politeness
# --------------------------------------------------------------------------- #

USER_AGENT = (
    "LeadMapperBot/1.0 (+{contact}; respects robots.txt; "
    "contact to be excluded)"
)
CONTACT = "you@example.com"

def _tunable(name: str, default):
    """One crawl limit, overridable per deployment (§5).

    Read once at import. These are ceilings on how much of somebody else's server
    this application is willing to use, and a deployment crawling from a slow
    network or against a slow host needs to be able to raise the timeout without
    editing code.
    """
    raw = os.environ.get(name, "")
    if not raw:
        return default
    try:
        value = type(default)(raw)
    except (TypeError, ValueError):
        return default
    return value if value > 0 else default


#: Home page plus this many internal pages is the goal. The brief asks for at
#: least 5 internal pages where they exist.
TARGET_INTERNAL = _tunable("OUTREACH_CRAWL_TARGET_PAGES", 5)
#: Hard ceiling including the home page.
MAX_PAGES = _tunable("OUTREACH_CRAWL_MAX_PAGES", 8)
#: How deep into a site's path structure a page may sit and still be worth a
#: request. `/services/roofing` is depth 2; a page at depth 5 is almost always an
#: archive, a filter or a product variant.
MAX_DEPTH = _tunable("OUTREACH_CRAWL_MAX_DEPTH", 3)
MAX_CANDIDATES = 400       # links considered before scoring
MAX_SITEMAP_URLS = 300

MAX_BYTES = _tunable("OUTREACH_CRAWL_MAX_BYTES", 2_000_000)
TIMEOUT = _tunable("OUTREACH_CRAWL_TIMEOUT", 15)
#: Seconds between two requests to the same host. The politeness setting: raising
#: it is always safe, lowering it uses more of somebody else's bandwidth.
HOST_DELAY = _tunable("OUTREACH_CRAWL_DELAY", 1.0)
#: Attempts per page. A retry covers a dropped connection; more than a couple
#: turns one unreachable site into a long wait for every lead behind it.
MAX_ATTEMPTS = _tunable("OUTREACH_CRAWL_RETRIES", 2)
#: Redirect hops followed for one page. Each one is a URL the target chose, and
#: each one is checked.
MAX_REDIRECTS = _tunable("OUTREACH_CRAWL_MAX_REDIRECTS", 5)

#: Total characters of context handed to the AI, across all pages.
#:
#: This exists because breadth and prompt size pull against each other: reading
#: more pages is better analysis but a bigger request, and model rate limits are
#: unforgiving. A 6-page crawl at the full per-page budget came to ~10.5k tokens,
#: over Groq's free-tier 8k tokens/minute, so the review could never run. The
#: fix is to keep the page count and share a fixed character budget between
#: them -- signals stay whole (they are compact and are the evidence), prose gets
#: trimmed. Raise it if your provider's limits allow.
CONTEXT_BUDGET = int(os.environ.get("OUTREACH_AI_CONTEXT_CHARS", "9000"))


log = logging.getLogger(__name__)

_lock = threading.Lock()
_last_hit: dict[str, float] = {}
#: host -> (parser, when it was read). Cached because one crawl asks about it a
#: dozen times, and expiring because a worker process can outlive a site's rules:
#: without a TTL, a `Disallow` added today would never be seen by a worker started
#: last week.
_robots: dict[str, tuple[RobotFileParser | None, float]] = {}

#: How long a cached robots.txt is trusted.
ROBOTS_TTL = _tunable("OUTREACH_CRAWL_ROBOTS_TTL", 3600.0)


def forget_robots() -> None:
    """Drop the cache. For tests, and for a deployment that wants a fresh read."""
    with _lock:
        _robots.clear()

# --------------------------------------------------------------------------- #
# What makes a page worth reading
# --------------------------------------------------------------------------- #
















#: Markers that mean a bot wall, not a business page. Seeing one stops the run.
BOT_WALL_MARKERS = (
    "captcha",
    "cf-browser-verification",
    "cf_chl_opt",
    "checking your browser",
    "attention required! | cloudflare",
    "please enable javascript and cookies",
    "access to this page has been denied",
    "are you a robot",
    "recaptcha",
    "hcaptcha",
)


# --------------------------------------------------------------------------- #
# Results
# --------------------------------------------------------------------------- #

OK = "ok"
BLOCKED = "blocked"
FAILED = "failed"
NO_WEBSITE = "no_website"




@dataclass
class SiteAnalysis:
    status: str
    detail: str
    pages: list[Page] = field(default_factory=list)
    emails_found: list[str] = field(default_factory=list)
    discovered: int = 0
    sitemap_used: bool = False
    #: True when the caller asked the crawl to stop part-way -- a cancelled run.
    #: Kept separate from `status`, because a half-read site that nobody asked
    #: for is not a site that could not be read, and the caller needs to be able
    #: to throw the partial result away rather than store it as the whole truth.
    stopped: bool = False

    @property
    def usable(self) -> bool:
        return self.status == OK and bool(self.pages)

    def summary(self) -> str:
        """One line for the review UI."""
        if not self.usable:
            return self.detail
        kinds = ", ".join(dict.fromkeys(p.kind for p in self.pages))
        via = " via sitemap" if self.sitemap_used else ""
        return (f"Read {len(self.pages)} of {self.discovered} discovered "
                f"page(s){via}: {kinds}")

    def as_context(self, char_budget: int | None = None) -> str:
        """Page text and measured signals, formatted for the AI.

        The signals are never trimmed -- they are the evidence, and they are
        cheap. Prose is shared out across the pages that were read, so adding a
        sixth page shortens each excerpt rather than growing the request past the
        model's rate limit.
        """
        if not self.usable:
            return ""

        budget = CONTEXT_BUDGET if char_budget is None else char_budget
        blocks = []
        headers = []

        # Build everything except the prose first, so the leftover is known.
        for index, page in enumerate(self.pages, 1):
            parts = [f"### PAGE {index} -- {page.kind.upper()}: {page.url}"]
            if page.title:
                parts.append(f"Title: {page.title}")
            parts.append(
                f"Meta description: {page.description}" if page.description
                else "Meta description: MISSING"
            )
            if page.headings:
                parts.append("Headings: " + " | ".join(page.headings[:15]))
            if page.facts:
                parts.append("Measured signals: " + _format_facts(page.facts))
            headers.append("\n".join(parts))

        spent = sum(len(h) for h in headers)
        per_page = max(MIN_PAGE_TEXT, (budget - spent) // max(1, len(self.pages)))

        for header, page in zip(headers, self.pages):
            block = header
            if page.text:
                excerpt = page.text[:per_page]
                suffix = " (truncated)" if len(page.text) > per_page else ""
                block += f"\nVisible text{suffix}:\n{excerpt}"
            blocks.append(block)

        return "\n\n".join(blocks)




# --------------------------------------------------------------------------- #
# HTTP plumbing
# --------------------------------------------------------------------------- #

def _headers() -> dict[str, str]:
    return {
        "User-Agent": USER_AGENT.format(contact=CONTACT),
        "Accept": "text/html,application/xhtml+xml",
        "Accept-Language": "en",
    }


def _throttle(host: str) -> None:
    with _lock:
        wait = HOST_DELAY - (time.monotonic() - _last_hit.get(host, 0.0))
        if wait > 0:
            time.sleep(wait)
        _last_hit[host] = time.monotonic()


def normalise(url: str) -> str:
    url = (url or "").strip()
    if not url:
        return ""
    if not url.startswith(("http://", "https://")):
        url = f"https://{url}"
    return url


def _canonical(url: str) -> str:
    """Strip fragment, query and trailing slash so duplicates collapse."""
    parsed = urlparse(url)
    path = parsed.path.rstrip("/") or "/"
    return urlunparse((parsed.scheme, parsed.netloc.lower(), path, "", "", ""))


class Blocked(Exception):
    """The site actively declined the request. Stop, do not work around it."""


class TooManyRedirects(Exception):
    """The site kept redirecting. Usually a loop, sometimes a cloaking check."""


class Unsafe(Exception):
    """A URL the crawler must not fetch -- see `safeurl`.

    Its own exception rather than a `Blocked`: the site did not decline anything,
    the request was refused before it was made, and the two need different words on
    screen.
    """




def _fetch(url: str, guard=None) -> Fetched:
    """GET one HTML page, timing it. Raises Blocked when clearly unwelcome.

    Redirects are followed here rather than by `requests`, because each hop is a
    URL the *target* chose and `guard` has to see it. A public site answering
    `302 Location: http://127.0.0.1:8000/` is the shortest route from "audit my
    website" to reading the server's own admin pages, and it is entirely under the
    target's control.

    One retry, for a dropped connection. A site that refuses twice is not going to
    answer the third time, and every extra attempt is time the lead behind this one
    spends waiting.
    """
    _guard(guard, url)

    started = time.monotonic()
    target = url
    for hop in range(MAX_REDIRECTS + 1):
        response = _get(target)

        if response.status_code in (401, 402, 403, 429):
            raise Blocked(
                f"site returned HTTP {response.status_code} -- access restricted"
            )

        location = (response.headers or {}).get("Location", "")
        if 300 <= response.status_code < 400 and location:
            if hop >= MAX_REDIRECTS:
                raise TooManyRedirects(
                    f"more than {MAX_REDIRECTS} redirects starting at {url}")
            target = urljoin(target, location.strip())
            # The whole point of doing this by hand.
            _guard(guard, target)
            continue

        response.raise_for_status()

        if "html" not in response.headers.get("Content-Type", "").lower():
            raise ValueError("not an HTML page")

        body = response.raw.read(MAX_BYTES, decode_content=True) or b""
        load_ms = int((time.monotonic() - started) * 1000)
        html = body.decode(response.encoding or "utf-8", errors="replace")

        if any(marker in html[:4000].lower() for marker in BOT_WALL_MARKERS):
            raise Blocked("site is behind a bot check -- not bypassed")

        return Fetched(html, load_ms, len(body), getattr(response, "url", target))

    raise TooManyRedirects(f"more than {MAX_REDIRECTS} redirects starting at {url}")


def _guard(guard, url: str) -> None:
    """Ask the caller's guard about one URL, in the crawler's own vocabulary.

    A guard signals a refusal by raising -- `safeurl` raises a `ValueError`
    subclass -- and that is translated to `Unsafe` here. Without the translation it
    lands in the "could not read the website" branch, and a redirect into a private
    network gets described to the user as a connection problem.
    """
    if guard is None:
        return
    try:
        guard(url)
    except ValueError as exc:
        raise Unsafe(str(exc)) from exc


def _get(url: str):
    """One HTTP GET, throttled, retried once on a dropped connection."""
    last: Exception | None = None
    for attempt in range(max(1, MAX_ATTEMPTS)):
        _throttle(urlparse(url).netloc)
        try:
            return requests.get(
                url, headers=_headers(), timeout=TIMEOUT,
                allow_redirects=False, stream=True,
            )
        except (requests.ConnectionError, requests.Timeout) as exc:
            last = exc
            if attempt + 1 >= max(1, MAX_ATTEMPTS):
                break
    raise last if last is not None else requests.RequestException("no response")


def _robots_for(base: str) -> RobotFileParser | None:
    """Fetch and cache robots.txt. None means "no rules published"."""
    host = urlparse(base).netloc
    cached = _robots.get(host)
    if cached is not None and (time.monotonic() - cached[1]) < ROBOTS_TTL:
        return cached[0]

    parser: RobotFileParser | None = None
    try:
        _throttle(host)
        response = requests.get(
            urljoin(base, "/robots.txt"), headers=_headers(), timeout=TIMEOUT
        )
        if response.status_code == 200:
            parser = RobotFileParser()
            parser.parse(response.text.splitlines())
        elif response.status_code in (401, 403):
            # The spec treats an unauthorised robots.txt as "stay out".
            parser = RobotFileParser()
            parser.parse(["User-agent: *", "Disallow: /"])
    except requests.RequestException:
        parser = None  # unreachable robots.txt -- proceed, but gently

    _robots[host] = (parser, time.monotonic())
    return parser


def _allowed(url: str, robots: RobotFileParser | None) -> bool:
    if robots is None:
        return True
    return robots.can_fetch(_headers()["User-Agent"], url)


# --------------------------------------------------------------------------- #
# Step 1 -- discover candidate pages
# --------------------------------------------------------------------------- #

def classify(url: str, anchor_text: str = "") -> tuple[str, int]:
    """Guess what a link is and how valuable it looks. ("other", 0) if not."""
    haystack = f"{urlparse(url).path} {anchor_text}".lower()
    for kind, pattern, score in PAGE_KINDS:
        if re.search(pattern, haystack):
            return kind, score
    return "other", 0


def discover_links(html: str, base: str) -> list[tuple[str, str, int]]:
    """Read the page's own navigation and links.

    Returns (url, kind, score). Links in <nav>/<header> get a bonus because the
    site is telling us those pages matter; footer links get a smaller one.
    Shallow paths are preferred over deep ones.
    """
    soup = BeautifulSoup(html, "html.parser")
    home_host = urlparse(base).netloc.lower().removeprefix("www.")

    # Which anchors sit inside navigation, and which inside the footer?
    nav_hrefs, footer_hrefs = set(), set()
    for tag in soup.find_all(NAV_CONTAINERS):
        nav_hrefs.update(a.get("href", "") for a in tag.find_all("a", href=True))
    for tag in soup.find_all(FOOTER_CONTAINERS):
        footer_hrefs.update(a.get("href", "") for a in tag.find_all("a", href=True))

    seen: dict[str, tuple[str, str, int]] = {}
    for anchor in soup.find_all("a", href=True)[:MAX_CANDIDATES]:
        raw = anchor["href"].strip()
        if not raw or raw.startswith(("#", "mailto:", "tel:", "javascript:")):
            continue

        target = urljoin(base, raw)
        parsed = urlparse(target)
        if parsed.scheme not in ("http", "https"):
            continue
        if parsed.netloc.lower().removeprefix("www.") != home_host:
            continue  # stay on the lead's own site
        if SKIP_PATTERN.search(target):
            continue

        canonical = _canonical(target)
        if canonical == _canonical(base):
            continue  # that is the home page

        kind, score = classify(target, anchor.get_text(" ", strip=True))
        if not score:
            continue

        if raw in nav_hrefs:
            score += 25          # the site's own primary navigation
        elif raw in footer_hrefs:
            score += 5
        depth = len([p for p in urlparse(canonical).path.split("/") if p])
        if depth > MAX_DEPTH:
            # Deeper than this is an archive, a filter or a product variant, not a
            # page that says anything about the business (§5).
            continue
        score -= max(0, depth - 1) * 8   # prefer top-level pages

        if canonical not in seen or score > seen[canonical][2]:
            seen[canonical] = (canonical, kind, score)

    return sorted(seen.values(), key=lambda row: -row[2])


def discover_sitemap(base: str, robots: RobotFileParser | None) -> list[tuple[str, str, int]]:
    """Read the sitemap, if the site publishes one.

    Tries the URLs robots.txt advertises first, then /sitemap.xml. Follows one
    level of sitemap index. Sitemaps are published precisely so crawlers can
    find pages, which makes this the politest discovery route available.
    """
    targets: list[str] = []
    if robots is not None:
        try:
            targets.extend(robots.site_maps() or [])
        except Exception:  # noqa: BLE001 - older parsers lack site_maps()
            pass
    targets.append(urljoin(base, "/sitemap.xml"))

    home_host = urlparse(base).netloc.lower().removeprefix("www.")
    found: dict[str, tuple[str, str, int]] = {}

    for sitemap_url in targets[:3]:
        try:
            _throttle(urlparse(sitemap_url).netloc)
            response = requests.get(
                sitemap_url, headers=_headers(), timeout=TIMEOUT
            )
            if response.status_code != 200:
                continue
            body = response.text[:1_500_000]
        except requests.RequestException:
            continue

        locs = re.findall(r"<loc>\s*([^<\s]+)\s*</loc>", body, re.IGNORECASE)

        # A sitemap index points at more sitemaps; follow one level.
        if "<sitemapindex" in body[:2000].lower():
            for nested in locs[:3]:
                try:
                    _throttle(urlparse(nested).netloc)
                    nested_body = requests.get(
                        nested, headers=_headers(), timeout=TIMEOUT
                    ).text[:1_500_000]
                    locs.extend(re.findall(
                        r"<loc>\s*([^<\s]+)\s*</loc>", nested_body, re.IGNORECASE))
                except requests.RequestException:
                    continue

        for loc in locs[:MAX_SITEMAP_URLS]:
            parsed = urlparse(loc)
            if parsed.netloc.lower().removeprefix("www.") != home_host:
                continue
            if SKIP_PATTERN.search(loc):
                continue
            canonical = _canonical(loc)
            if canonical == _canonical(base):
                continue
            kind, score = classify(loc)
            if not score:
                continue
            depth = len([p for p in parsed.path.split("/") if p])
            score -= max(0, depth - 1) * 8
            if canonical not in found or score > found[canonical][2]:
                found[canonical] = (canonical, kind, score)

        if found:
            break  # one usable sitemap is enough

    return sorted(found.values(), key=lambda row: -row[2])


def choose_pages(candidates: list[tuple[str, str, int]],
                 limit: int) -> list[tuple[str, str, int]]:
    """Pick the most informative spread, not just the top scores.

    Diversity matters: five service pages say less about the customer journey
    than a services page plus pricing, contact, about and testimonials. So the
    first pass takes the best page of each kind, and only then does a second
    pass fill remaining slots with runners-up.
    """
    chosen: list[tuple[str, str, int]] = []
    used_kinds: set[str] = set()

    for row in candidates:
        if len(chosen) >= limit:
            break
        if row[1] not in used_kinds:
            chosen.append(row)
            used_kinds.add(row[1])

    for row in candidates:
        if len(chosen) >= limit:
            break
        if row not in chosen:
            chosen.append(row)

    return chosen


# --------------------------------------------------------------------------- #
# Step 2 -- measure a page
# --------------------------------------------------------------------------- #









# --------------------------------------------------------------------------- #
# The public entry point
# --------------------------------------------------------------------------- #

def analyse(website: str, target_internal: int = TARGET_INTERNAL,
            should_stop=None, *, guard=None, progress=None) -> SiteAnalysis:
    """Crawl and measure a lead's website. Never raises.

    `should_stop` is an optional callable checked before every network request.
    It is how Cancel reaches a crawl that is already running: the fetch in flight
    cannot be aborted, but the next one need never start, so a cancelled lead
    stops within one page rather than after five. The result carries
    `stopped=True` so the caller can discard a partial read instead of saving it.

    `guard` is called with every URL before it is requested, including every
    redirect hop, and may raise to refuse it. It is how a page that lets somebody
    submit an arbitrary URL keeps the crawler out of private networks -- see
    `safeurl`. A refusal ends the crawl with `BLOCKED` rather than raising, because
    to the caller it is the same kind of answer as "robots.txt says no".

    `progress` is called with a small event dict as the crawl happens:
    `{"stage": "home"|"discovered"|"page", ...}`. It exists so a status screen can
    report what has actually been read rather than a number somebody made up, and
    it is where a caller can look at each page's HTML while it is still in memory --
    contact extraction uses that, instead of the crawler storing every page's
    markup for a caller that may not want it.

    An exception from `progress` is never allowed to end a crawl: the crawl is the
    expensive part and a caller's bookkeeping is not worth losing it for.
    """
    def stop_now() -> bool:
        return bool(should_stop and should_stop())

    def report(**event) -> None:
        if progress is None:
            return
        try:
            progress(event)
        except Exception:  # noqa: BLE001 - bookkeeping must not lose a crawl
            log.exception("crawl progress callback failed")

    if stop_now():
        return SiteAnalysis(FAILED, "Cancelled before the crawl started.",
                            stopped=True)

    url = normalise(website)
    if not url:
        return SiteAnalysis(NO_WEBSITE, "No website published for this lead.")

    try:
        robots = _robots_for(url)
    except Exception:  # noqa: BLE001 - robots is best-effort
        robots = None

    if not _allowed(url, robots):
        return SiteAnalysis(
            BLOCKED, "robots.txt disallows crawling this site -- skipped.")

    try:
        home = _fetch(url, guard=guard)
    except Blocked as exc:
        return SiteAnalysis(BLOCKED, f"Not analysed: {exc}.")
    except Unsafe as exc:
        return SiteAnalysis(BLOCKED, f"Not analysed: {exc}.")
    except TooManyRedirects as exc:
        return SiteAnalysis(FAILED, f"Could not read the website: {exc}.")
    except (requests.RequestException, ValueError) as exc:
        return SiteAnalysis(FAILED, f"Could not read the website: {exc}.")

    pages = [extract(home, url, "home")]
    emails = scrape_emails(home.html)
    report(stage="home", url=home.final_url or url, kind="home", html=home.html,
           title=pages[0].title)

    if stop_now():
        return SiteAnalysis(
            OK, f"Cancelled after {len(pages)} page(s).",
            pages, emails, 0, False, stopped=True)

    # Discovery from the page that actually answered. A submitted URL that
    # redirects -- example.com to www.example.com, or an old domain to a new one --
    # serves its links relative to where it ended up, and judging them against the
    # address that was typed would reject every one of them as off-site.
    base = home.final_url or url
    candidates = discover_links(home.html, base)
    sitemap_rows = discover_sitemap(url, robots)
    sitemap_used = bool(sitemap_rows)

    merged: dict[str, tuple[str, str, int]] = {}
    for row in candidates + sitemap_rows:
        if row[0] not in merged or row[2] > merged[row[0]][2]:
            merged[row[0]] = row
    ranked = sorted(merged.values(), key=lambda row: -row[2])

    budget = min(target_internal, MAX_PAGES - 1)
    # Over-select so pages that turn out to be unreachable can be skipped
    # without dropping below the target.
    plan = choose_pages(ranked, budget * 2)
    report(stage="discovered", count=len(ranked), planned=len(plan))

    for link, kind, _score in plan:
        if len(pages) - 1 >= budget:
            break
        # Checked before the fetch, not after: the point is not to start work
        # that has already been called off.
        if stop_now():
            return SiteAnalysis(
                OK, f"Cancelled after {len(pages)} page(s).",
                pages, emails, len(ranked), sitemap_used, stopped=True)
        if not _allowed(link, robots):
            continue
        try:
            fetched = _fetch(link, guard=guard)
        except Blocked as exc:
            # The site drew a line mid-crawl. Keep what we have and stop.
            return SiteAnalysis(
                OK if len(pages) > 1 else BLOCKED,
                f"Read {len(pages)} page(s); stopped: {exc}.",
                pages, emails, len(ranked), sitemap_used,
            )
        except Unsafe:
            # One link pointed somewhere it must not. Skip that link, keep going:
            # a single bad link is not a reason to abandon the site.
            continue
        except (TooManyRedirects, requests.RequestException, ValueError):
            continue

        pages.append(extract(fetched, link, kind))
        emails.extend(e for e in scrape_emails(fetched.html) if e not in emails)
        report(stage="page", url=fetched.final_url or link, kind=kind,
               html=fetched.html, title=pages[-1].title)

    internal = len(pages) - 1
    detail = f"Read {len(pages)} page(s) ({internal} internal) of {len(ranked)} discovered."
    if internal < target_internal:
        detail += (f" Only {internal} useful internal page(s) were reachable on "
                   "this site.")

    return SiteAnalysis(OK, detail, pages, emails, len(ranked), sitemap_used)
