"""
Contact details a website publishes about itself.

Everything here comes off a page that was actually fetched. There is no inference,
no pattern-filling and no "most businesses use info@": an address this module
returns is an address that appears on the site, and the page it appeared on is
recorded beside it. That is the whole rule, and it is worth stating plainly because
the alternative is so easy — `info@` + the domain is right often enough to be
tempting and wrong often enough to email a stranger who never published an address.

What it reads, in the order that matters:

  * **`mailto:` and `tel:` links** — the least ambiguous form there is. A site that
    wraps an address in a link has published it for exactly this purpose.
  * **Text on the page** — plenty of sites print `hello@example.com` without linking
    it, and obfuscate it lightly (`hello [at] example.com`) to slow scrapers down.
    Both are still published, so both are read. What is *not* read is anything that
    needs assembling: a name and a domain in different places stay separate.
  * **Structured data** — `schema.org` JSON-LD, where a business states its own
    name, phone, address and opening hours in machine-readable form. It is the
    site's own description of itself, which makes it the best source available.
  * **Footers and contact pages** are weighted above the rest, because that is where
    a business puts the address it wants to be reached on.

Ranking (§10) is about which address a *person* would pick. A named owner beats a
department, a department beats `info@`, and a `noreply@` is not a contact at all. The
result is a shortlist with the reasoning attached — never an automatic send to
several addresses.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup

#: Kinds of detail this module extracts.
EMAIL = "email"
PHONE = "phone"
ADDRESS = "address"
SOCIAL = "social"
BUSINESS = "business"
PERSON = "person"
HOURS = "hours"

#: How much to trust one find, and why. Written as words because it is shown to a
#: person, who then decides whether to send to it.
HIGH = "high"
MEDIUM = "medium"
LOW = "low"

#: Pages whose contact details are the ones the business means. A `mailto:` in a
#: blog post is more likely to be somebody else's address.
STRONG_PAGES = ("contact", "about", "home", "team")

#: Local parts that mean "a person" rather than "a desk". Ranked highest, because
#: an email to a named person gets read and an email to `info@` gets triaged.
OWNER_WORDS = ("owner", "founder", "director", "principal", "ceo", "md",
               "managing", "proprietor", "partner")

#: Local parts a business publishes for general enquiries. Fine to write to.
BUSINESS_WORDS = ("info", "contact", "hello", "hi", "enquiries", "enquiry",
                  "inquiries", "inquiry", "office", "mail", "admin", "team",
                  "reception", "frontdesk", "general")

#: Departments: real people read them, but they are not the decision-maker.
DEPARTMENT_WORDS = ("sales", "support", "help", "service", "bookings",
                    "booking", "appointments", "accounts", "billing",
                    "invoices", "hr", "jobs", "careers", "recruitment",
                    "marketing", "press", "media")

#: Never a contact. An automated mailbox, or an address that exists to be ignored.
NEVER_WORDS = ("noreply", "no-reply", "donotreply", "do-not-reply", "bounce",
               "bounces", "mailer-daemon", "postmaster", "abuse", "spam",
               "unsubscribe", "privacy", "dpo", "legal", "webmaster",
               "hostmaster", "root", "example", "your", "youremail",
               "email", "name", "sentry", "wordpress")

#: Addresses belonging to somebody other than the business being audited.
PLATFORM_DOMAINS = ("example.com", "example.org", "example.net", "domain.com",
                    "yourdomain.com", "sentry.io", "wixpress.com",
                    "squarespace.com", "shopify.com", "wordpress.com",
                    "godaddy.com", "gstatic.com", "googlemail.com",
                    "cloudflare.com", "jsdelivr.net", "sentry-cdn.com")

#: Social networks worth recording. A business's own profiles are contact routes
#: and, for the audit, evidence of whether it points customers at them.
SOCIAL_HOSTS = {
    "facebook.com": "Facebook", "fb.com": "Facebook",
    "instagram.com": "Instagram", "twitter.com": "X", "x.com": "X",
    "linkedin.com": "LinkedIn", "youtube.com": "YouTube",
    "tiktok.com": "TikTok", "pinterest.com": "Pinterest",
    "yelp.com": "Yelp", "wa.me": "WhatsApp", "api.whatsapp.com": "WhatsApp",
    "t.me": "Telegram", "threads.net": "Threads",
}

_EMAIL_TEXT = re.compile(
    r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}")

#: Lightly obfuscated addresses. `hello [at] example [dot] com` is published; it is
#: just published awkwardly. Anything needing more reconstruction than swapping
#: these two tokens is left alone -- guessing is the thing this module does not do.
_OBFUSCATED = re.compile(
    r"([A-Za-z0-9._%+\-]+)\s*(?:\[at\]|\(at\)|\s+at\s+)\s*"
    r"([A-Za-z0-9.\-]+)\s*(?:\[dot\]|\(dot\)|\s+dot\s+)\s*([A-Za-z]{2,})",
    re.IGNORECASE)

#: A phone number as a person writes one. Deliberately loose on separators and
#: strict on length: seven digits is the shortest real number, and fifteen is the
#: E.164 maximum, so anything outside that is a date, a price or an id.
_PHONE_TEXT = re.compile(
    r"(?:\+\d{1,3}[\s.\-]?)?(?:\(\d{1,4}\)[\s.\-]?)?"
    r"\d(?:[\d\s.\-]{5,17})\d")


@dataclass
class Detail:
    """One published detail, and where it was found."""

    kind: str
    value: str
    source_url: str = ""
    #: Which part of the page it came from: "mailto", "text", "schema", "footer".
    where: str = ""
    confidence: str = MEDIUM
    #: Lower sorts first. Set by `rank`.
    rank: int = 50
    #: Why it was ranked where it was, for the screen.
    note: str = ""
    #: A name found next to it, where the page made the connection obvious.
    label: str = ""

    @property
    def local(self) -> str:
        return self.value.split("@")[0].lower() if "@" in self.value else ""

    @property
    def domain(self) -> str:
        return self.value.split("@")[-1].lower() if "@" in self.value else ""

    def as_dict(self) -> dict:
        return {
            "kind": self.kind, "value": self.value,
            "source_url": self.source_url, "where": self.where,
            "confidence": self.confidence, "rank": self.rank,
            "note": self.note, "label": self.label,
        }


@dataclass
class Harvest:
    """Everything found across every page that was read."""

    details: list[Detail] = field(default_factory=list)
    #: Pages this looked at, so "no email found" can say where it looked (§17).
    pages: list[str] = field(default_factory=list)

    def add(self, detail: Detail) -> None:
        """Keep one detail, or improve the record of one already held.

        A page's footer usually repeats the contact page's address. Keeping both
        would show the same email twice with different confidence, so the better
        source wins and the duplicate is dropped.
        """
        key = (detail.kind, detail.value.casefold())
        for existing in self.details:
            if (existing.kind, existing.value.casefold()) == key:
                if _better(detail, existing):
                    existing.source_url = detail.source_url
                    existing.where = detail.where
                    existing.confidence = detail.confidence
                if detail.label and not existing.label:
                    existing.label = detail.label
                return
        self.details.append(detail)

    def of(self, kind: str) -> list[Detail]:
        return [d for d in self.details if d.kind == kind]

    @property
    def emails(self) -> list[Detail]:
        return self.of(EMAIL)

    @property
    def best_email(self) -> Detail | None:
        emails = self.emails
        return emails[0] if emails else None

    def as_dict(self) -> dict:
        return {
            "pages": list(self.pages),
            "details": [d.as_dict() for d in self.details],
        }


_CONFIDENCE_ORDER = {LOW: 0, MEDIUM: 1, HIGH: 2}


def _better(new: Detail, old: Detail) -> bool:
    return _CONFIDENCE_ORDER[new.confidence] > _CONFIDENCE_ORDER[old.confidence]


# --------------------------------------------------------------------------- #
# Reading one page
# --------------------------------------------------------------------------- #

def harvest_page(harvest: Harvest, html: str, url: str, kind: str = "",
                 site: str = "") -> Harvest:
    """Read one page into the harvest. Never raises for a malformed page.

    `kind` is the crawler's guess at what the page is, which decides how much a
    find on it is trusted. `site` is the audited domain: an address on another
    domain is still recorded, but never trusted as the business's own.
    """
    harvest.pages.append(url)
    try:
        soup = BeautifulSoup(html or "", "html.parser")
    except Exception:  # noqa: BLE001 - a broken page is not a broken audit
        return harvest

    strong = kind in STRONG_PAGES

    _links(harvest, soup, url, strong, site)
    _schema(harvest, soup, url)
    _text(harvest, soup, url, strong, site)
    _social(harvest, soup, url)
    return harvest


def _links(harvest: Harvest, soup: BeautifulSoup, url: str, strong: bool,
           site: str) -> None:
    """`mailto:` and `tel:` -- published unambiguously, so trusted most."""
    for anchor in soup.find_all("a", href=True):
        href = anchor["href"].strip()
        lowered = href.lower()
        where = "footer" if _in_footer(anchor) else "mailto"

        if lowered.startswith("mailto:"):
            address = href[7:].split("?")[0].strip()
            for candidate in address.split(","):
                cleaned = _clean_email(candidate)
                if not cleaned:
                    continue
                harvest.add(Detail(
                    EMAIL, cleaned, url, where,
                    HIGH if (strong or where == "footer") else MEDIUM,
                    label=_nearby_name(anchor)))

        elif lowered.startswith("tel:"):
            number = _clean_phone(href[4:])
            if number:
                harvest.add(Detail(PHONE, number, url,
                                   "footer" if where == "footer" else "tel",
                                   HIGH if strong else MEDIUM))


def _schema(harvest: Harvest, soup: BeautifulSoup, url: str) -> None:
    """schema.org JSON-LD: the business describing itself in machine-readable form.

    The best source available when it exists, because nothing was inferred from it
    -- the business wrote it down. Malformed JSON is ignored rather than repaired.
    """
    for tag in soup.find_all("script", type="application/ld+json"):
        raw = tag.string or tag.get_text() or ""
        try:
            data = json.loads(raw)
        except (ValueError, TypeError):
            continue
        for node in _nodes(data):
            if not isinstance(node, dict):
                continue
            _schema_node(harvest, node, url)


def _nodes(data):
    """Flatten a JSON-LD document into the objects inside it."""
    if isinstance(data, list):
        for item in data:
            yield from _nodes(item)
    elif isinstance(data, dict):
        yield data
        for key in ("@graph", "itemListElement", "mainEntity", "publisher",
                    "author", "provider"):
            if key in data:
                yield from _nodes(data[key])


def _schema_node(harvest: Harvest, node: dict, url: str) -> None:
    kinds = node.get("@type") or ""
    kinds = " ".join(kinds) if isinstance(kinds, list) else str(kinds)
    lowered = kinds.lower()

    if any(word in lowered for word in ("organization", "localbusiness",
                                        "store", "restaurant", "professional",
                                        "corporation", "dentist", "physician",
                                        "homeandconstruction", "plumber",
                                        "roofingcontractor", "electrician")):
        name = str(node.get("name") or "").strip()
        if name:
            harvest.add(Detail(BUSINESS, name[:200], url, "schema", HIGH))

    if "person" in lowered:
        name = str(node.get("name") or "").strip()
        if name:
            harvest.add(Detail(PERSON, name[:120], url, "schema", MEDIUM,
                               label=str(node.get("jobTitle") or "")[:80]))

    email = _clean_email(str(node.get("email") or ""))
    if email:
        # The node's name is only attached when the node is a *person*. An
        # organisation's name beside an address would rank it as "published beside
        # a name", and the email would then be addressed to "Dear ABC Roofing".
        harvest.add(Detail(EMAIL, email, url, "schema", HIGH,
                           label=(str(node.get("name") or "")[:120]
                                  if "person" in lowered else "")))

    phone = _clean_phone(str(node.get("telephone") or ""))
    if phone:
        harvest.add(Detail(PHONE, phone, url, "schema", HIGH))

    address = node.get("address")
    if isinstance(address, dict):
        parts = [address.get(key) for key in (
            "streetAddress", "addressLocality", "addressRegion", "postalCode",
            "addressCountry")]
        written = ", ".join(str(part).strip() for part in parts
                            if part and str(part).strip())
        if written:
            harvest.add(Detail(ADDRESS, written[:300], url, "schema", HIGH))
    elif isinstance(address, str) and address.strip():
        harvest.add(Detail(ADDRESS, address.strip()[:300], url, "schema", HIGH))

    hours = node.get("openingHours") or node.get("openingHoursSpecification")
    if isinstance(hours, list):
        written = "; ".join(str(item) for item in hours
                           if isinstance(item, str))[:300]
        if written:
            harvest.add(Detail(HOURS, written, url, "schema", HIGH))
    elif isinstance(hours, str) and hours.strip():
        harvest.add(Detail(HOURS, hours.strip()[:300], url, "schema", HIGH))


def _text(harvest: Harvest, soup: BeautifulSoup, url: str, strong: bool,
          site: str) -> None:
    """Addresses and numbers printed on the page rather than linked.

    Read from the footer separately and first: an address in a footer is the site
    saying "this is us", while the same string in the body of a blog post might be
    anybody's.
    """
    footer_text = " ".join(
        tag.get_text(" ", strip=True) for tag in soup.find_all("footer"))
    body_text = soup.get_text(" ", strip=True)

    for text, where, confident in ((footer_text, "footer", True),
                                   (body_text, "text", strong)):
        if not text:
            continue
        for match in _EMAIL_TEXT.finditer(text[:200_000]):
            cleaned = _clean_email(match.group(0))
            if cleaned:
                harvest.add(Detail(EMAIL, cleaned, url, where,
                                   HIGH if confident else LOW))
        for match in _OBFUSCATED.finditer(text[:200_000]):
            cleaned = _clean_email(
                f"{match.group(1)}@{match.group(2)}.{match.group(3)}")
            if cleaned:
                harvest.add(Detail(EMAIL, cleaned, url, f"{where} (obfuscated)",
                                   MEDIUM))

    # Phone numbers only from the footer and from strong pages. The body of a
    # services page is full of numbers that are not phone numbers.
    if footer_text:
        _phones(harvest, footer_text, url, "footer", HIGH)
    if strong:
        _phones(harvest, body_text[:20_000], url, "text", MEDIUM)


def _phones(harvest: Harvest, text: str, url: str, where: str,
            confidence: str) -> None:
    for match in _PHONE_TEXT.finditer(text):
        number = _clean_phone(match.group(0))
        if number:
            harvest.add(Detail(PHONE, number, url, where, confidence))


def _social(harvest: Harvest, soup: BeautifulSoup, url: str) -> None:
    for anchor in soup.find_all("a", href=True):
        target = urljoin(url, anchor["href"].strip())
        host = (urlparse(target).hostname or "").lower().removeprefix("www.")
        for known, label in SOCIAL_HOSTS.items():
            if host == known or host.endswith("." + known):
                path = urlparse(target).path.strip("/")
                first = path.split("/")[0].lower()
                if not path or first in ("sharer", "share", "intent", "dialog",
                                         "sharer.php", "share.php",
                                         "shareArticle".lower(), "home", "login"):
                    continue          # a share button, not the business's profile
                harvest.add(Detail(SOCIAL, target[:400], url, "link", MEDIUM,
                                   label=label))
                break


def _in_footer(tag) -> bool:
    for parent in tag.parents:
        name = getattr(parent, "name", "")
        if name == "footer":
            return True
        if name == "body":
            return False
    return False


def _nearby_name(anchor) -> str:
    """A person's name printed beside an address, where the page makes it obvious.

    Only the immediately surrounding text, and only when it looks like a name --
    two or three capitalised words. This is the one place a name is associated with
    an address, and it is deliberately timid: getting it wrong means addressing a
    stranger by the wrong name, which is worse than not using a name at all.
    """
    parent = anchor.parent
    if parent is None:
        return ""
    text = parent.get_text(" ", strip=True)[:200]
    match = re.search(
        r"\b([A-Z][a-z]{1,15})\s+([A-Z][a-z]{1,15})(?:\s+([A-Z][a-z]{1,15}))?\b",
        text)
    if not match:
        return ""
    name = " ".join(part for part in match.groups() if part)
    # A heading like "Contact Us" or "Our Team" is not somebody's name.
    if re.search(r"\b(contact|about|our|the|get|call|email|team|us|home)\b",
                 name, re.IGNORECASE):
        return ""
    return name


# --------------------------------------------------------------------------- #
# Cleaning
# --------------------------------------------------------------------------- #

def _clean_email(raw: str) -> str:
    """A usable address, or "". Never a constructed one."""
    address = (raw or "").strip().strip(".,;:()<>[]\"'").lower()
    address = address.split("?")[0].strip()
    if not address or address.count("@") != 1:
        return ""
    if not _EMAIL_TEXT.fullmatch(address):
        return ""

    local, domain = address.split("@")
    if len(address) > 254 or len(local) > 64:
        return ""
    if domain in PLATFORM_DOMAINS or any(
            domain.endswith("." + bad) for bad in PLATFORM_DOMAINS):
        return ""
    # Image and asset filenames scraped out of inline CSS or JSON.
    if re.search(r"\.(png|jpe?g|gif|webp|svg|css|js|woff2?)$", domain):
        return ""
    if any(word == local or local.startswith(word + ".") or
           local.startswith(word + "-") for word in NEVER_WORDS):
        return ""
    return address


def _clean_phone(raw: str) -> str:
    """A phone number with its digits intact, or "".

    Kept close to how the site wrote it -- a person is going to read it -- with only
    the surrounding punctuation removed.
    """
    text = (raw or "").split("?")[0].strip()
    digits = re.sub(r"\D", "", text)
    if not 7 <= len(digits) <= 15:
        return ""
    # Four digits in a row that look like a year, with nothing else, is a date.
    if len(digits) <= 8 and re.fullmatch(r"(19|20)\d{2}\D*(19|20)?\d{0,4}", text):
        return ""
    cleaned = re.sub(r"[^\d+()\s.\-]", " ", text).strip()
    return re.sub(r"\s{2,}", " ", cleaned)[:40]


# --------------------------------------------------------------------------- #
# Ranking (§10)
# --------------------------------------------------------------------------- #

def rank(harvest: Harvest, site: str = "") -> Harvest:
    """Order the emails the way a person would choose between them.

    §10's order: a named owner, then the business's own general address, then a
    department, then anything else. An address on a different domain from the site
    sinks below every address that is on it -- it may well be the right person, but
    it is not evidence *this* business published it.

    Nothing is discarded. The screen shows the shortlist and the user picks.
    """
    site = (site or "").lower().removeprefix("www.")

    for detail in harvest.of(EMAIL):
        detail.rank, detail.note = _score_email(detail, site)

    harvest.details.sort(key=lambda d: (d.kind != EMAIL, d.rank,
                                        -_CONFIDENCE_ORDER[d.confidence],
                                        d.value))
    return harvest


def _score_email(detail: Detail, site: str) -> tuple[int, str]:
    local = detail.local
    off_site = bool(site) and detail.domain != site and not detail.domain.endswith(
        "." + site)

    if any(word in local for word in OWNER_WORDS):
        rank, note = 10, "looks like an owner or director address"
    elif detail.label and " " in detail.label:
        rank, note = 15, f"published beside a name ({detail.label})"
    elif local in BUSINESS_WORDS:
        rank, note = 20, "the business's general contact address"
    elif any(word in local for word in DEPARTMENT_WORDS):
        rank, note = 30, "a department address"
    elif "." in local or "_" in local:
        # first.last@ is a person, which is usually better than a desk.
        rank, note = 18, "looks like a named person's address"
    else:
        rank, note = 40, "published on the site"

    if detail.confidence == HIGH:
        rank -= 2
    elif detail.confidence == LOW:
        rank += 5

    if off_site:
        rank += 50
        note += f" — but on {detail.domain}, not the audited site"

    return rank, note


def summary(harvest: Harvest) -> dict:
    """What the results page shows about contacts, ready for a template."""
    emails = harvest.of(EMAIL)
    phones = harvest.of(PHONE)
    business = harvest.of(BUSINESS)
    people = harvest.of(PERSON)
    address = harvest.of(ADDRESS)
    return {
        "business_name": business[0].value if business else "",
        "person_name": people[0].value if people else "",
        "email": emails[0].value if emails else "",
        "email_source": emails[0].source_url if emails else "",
        "email_where": emails[0].where if emails else "",
        "email_confidence": emails[0].confidence if emails else "",
        "email_note": emails[0].note if emails else "",
        "emails": [d.as_dict() for d in emails],
        "phone": phones[0].value if phones else "",
        "phone_source": phones[0].source_url if phones else "",
        "address": address[0].value if address else "",
        "socials": [d.as_dict() for d in harvest.of(SOCIAL)],
        "hours": (harvest.of(HOURS)[0].value if harvest.of(HOURS) else ""),
        "pages_checked": list(harvest.pages),
        "found_email": bool(emails),
    }
