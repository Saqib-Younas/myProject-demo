"""
Reading a website and saying what is measurably true about it.

A toolkit, not a workflow. Nothing here writes to a campaign, sends an email or knows
what a lead is -- it fetches pages, measures them, scores them and extracts the
contact details a site publishes. `outreach` composes those into the workflows that
produce emails.

    safeurl.py        may this URL be fetched at all
    crawler.py        HTTP, robots.txt, discovery, the crawl loop
    measurements.py   the facts measurable on one page
    scoring.py        what those facts are worth, and which finding leads an email
    contacts.py       published contact details, with the page each came from

This app imports `core` and `ai`. It imports no domain app, which is what lets
`outreach` depend on it without a cycle.
"""
