"""
What can be measured on one page, and the tables that say how.

Every value here is a *fact*: a title's length, whether a viewport tag exists, how
many calls to action a page carries, how many images have no alt text. Nothing in this
module has an opinion -- opinions are `scoring`'s job and findings are the reviewer's.
That division is what makes "the AI may never invent a website problem" enforceable:
a finding has to cite one of these numbers, and these numbers come from the page.

The pattern tables are the interesting part. They are long on purpose and their
comments explain the trade-offs found the hard way -- word boundaries so "workshops"
is not a shop, a placeholder list so "Lorem ipsum" and "Your Company Name" are
counted as unfinished content, platform markers that identify a site's builder from
its own markup rather than from a guess.

`crawler` calls `extract()` with a fetched page and gets a `Page` back. That is the
whole interface between fetching and measuring.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from bs4 import BeautifulSoup

#: Characters of page text kept per page. Enough to quote from, small enough that
#: eight pages do not overflow a model's context.
TEXT_BUDGET = 4_000        # characters of page text stored per page
#: Never trim a page's text below this, or it stops being evidence at all.
MIN_PAGE_TEXT = 350
#: (kind, pattern, score). Higher scores are visited first. Scores encode "how
#: much does this page tell us about the business and its customer journey".
#:
#: Word boundaries are load-bearing, not decoration. Without them "workshops"
#: matches "shop" and gets labelled a products page, and "quotes" (testimonials)
#: matches "quote" and gets labelled pricing -- both seen on a real site. Paths
#: separate words with "-" and "/", which are non-word characters, so \b behaves
#: as intended on URLs.
PAGE_KINDS: tuple[tuple[str, str, int], ...] = (
    ("services", r"\b(services?|solutions?|what-we-do|expertise|treatments?"
                 r"|capabilit\w+)\b", 100),
    ("products", r"\b(products?|shop|store|menu|catalogue?|collections?)\b", 95),
    ("pricing", r"\b(pricing|prices?|plans|packages|rates|quote|fees)\b", 90),
    ("contact", r"\b(contact|contact-us|get-in-touch|reach-us|enquir\w+"
                r"|inquir\w+|book|booking|appointments?|locations?)\b", 85),
    ("about", r"\b(about|about-us|who-we-are|our-story|company|mission"
              r"|history|values)\b", 80),
    ("testimonials", r"\b(testimonials?|reviews?|quotes|clients|case-stud\w+"
                     r"|success-stories|portfolio|our-work)\b", 70),
    ("team", r"\b(team|staff|people|our-doctors|practitioners|leadership)\b", 55),
    ("faq", r"\b(faqs?|frequently-asked\w*|help|support)\b", 50),
    ("gallery", r"\b(gallery|galleries|photos|images)\b", 40),
    ("blog", r"\b(blog|news|articles|insights|resources)\b", 30),
)
#: Never worth a request: legal boilerplate, account plumbing, feeds, archives.
SKIP_PATTERN = re.compile(
    r"(privacy|terms|conditions|cookie|disclaimer|gdpr|imprint|impressum"
    r"|login|log-in|signin|sign-in|register|signup|sign-up|account|my-account"
    r"|cart|checkout|basket|wishlist|compare"
    r"|wp-admin|wp-login|wp-json|xmlrpc|feed|rss|atom"
    r"|/tag/|/tags/|/category/|/categories/|/author/|/archive"
    r"|sitemap\.xml|\.pdf$|\.jpg$|\.jpeg$|\.png$|\.gif$|\.webp$|\.svg$"
    r"|\.zip$|\.doc|\.xls|\.mp4$|\.mp3$)",
    re.IGNORECASE,
)
#: Links inside these elements are the site's own idea of what matters.
NAV_CONTAINERS = ("nav", "header")
FOOTER_CONTAINERS = ("footer",)
#: Phrases that indicate a call to action.
CTA_PATTERN = re.compile(
    r"\b(contact us|get in touch|get a quote|request a quote|free quote"
    r"|book now|book online|book a|schedule|make an appointment|enquire|inquire"
    r"|buy now|add to cart|shop now|order now|subscribe|sign up|get started"
    r"|start now|try free|free trial|call us|call now|request a demo|learn more"
    r"|find out more|download)\b",
    re.IGNORECASE,
)
#: Words that suggest social proof is present on the page.
TRUST_PATTERN = re.compile(
    r"\b(testimonial|review|rated|rating|stars|award|certified|accredited"
    r"|licensed|insured|guarantee|warranty|years of experience|since \d{4}"
    r"|trusted by|our clients|case study|iso \d|member of)\b",
    re.IGNORECASE,
)
#: Placeholder and neglect markers -- strong, checkable content problems.
PLACEHOLDER_PATTERN = re.compile(
    r"(lorem ipsum|dolor sit amet|coming soon|under construction"
    r"|page not found|insert text here|your text here|sample text"
    r"|\[.{0,20}placeholder.{0,20}\]|xxx-xxx|123-456-7890"
    r"|example\.com|yourdomain|company name here)",
    re.IGNORECASE,
)
#: Business information a customer looks for before contacting a company.
#:
#: Each one answers a question a real visitor asks, and each is countable, so a
#: finding built on it can cite a number. They are *mention* counts, not proof of a
#: good page: three occurrences of "pricing" is not a price list. The audit prompt
#: is explicit that zero mentions evidences absence only on the pages that were
#: read, which is the only claim the crawl actually supports.
BUSINESS_PATTERNS = {
    # "What does it cost?" -- the question that most often goes unanswered.
    "pricing_mentions": r"\b(pricing|price list|our prices|starting (?:at|from)"
                        r"|per hour|per month|per session|fees?|rates?|quote"
                        r"|how much|cost(?:s)?)\b",
    # "Do they cover where I live?"
    "service_area_mentions": r"\b(service area|areas we (?:serve|cover)"
                             r"|we (?:serve|cover)|serving|coverage area|locations?"
                             r"|nationwide|within \d+ (?:miles|km))\b",
    # "What actually happens if I get in touch?"
    "process_mentions": r"\b(how it works|our process|what to expect|step \d"
                        r"|next steps|our approach|the process)\b",
    # "Who are these people?"
    "team_mentions": r"\b(our team|meet the team|our staff|founder|owner"
                     r"|about us|who we are|our story)\b",
    # "When are they open?"
    "hours_mentions": r"\b(opening hours|business hours|hours of operation"
                      r"|mon(?:day)?\s*[-–to]+\s*fri(?:day)?|open (?:daily|24)"
                      r"|closed on)\b",
    # "What if it goes wrong?"
    "guarantee_mentions": r"\b(guarantee|warranty|money back|no obligation"
                          r"|free (?:estimate|consultation|assessment)"
                          r"|satisfaction|refund)\b",
    # "Has anyone else used them?"
    "proof_mentions": r"\b(testimonial|case study|case studies|before and after"
                      r"|portfolio|our work|results|clients? say|reviews?"
                      r"|\d+\+? (?:happy )?(?:clients|customers|projects))\b",
    # "Are they qualified?"
    "credential_mentions": r"\b(certified|accredited|licen[cs]ed|insured"
                           r"|qualified|member of|iso \d|award|registered"
                           r"|\d+ years(?: of)? experience)\b",
    # "Do they answer the questions I have?"
    "faq_mentions": r"\b(faq|frequently asked|common questions"
                    r"|questions we (?:get|are asked))\b",
    # "Who is this for?" -- a page that never says loses the visitor.
    "audience_mentions": r"\b(for (?:homeowners|businesses|landlords|families"
                         r"|restaurants|clinics|small business(?:es)?)"
                         r"|ideal for|designed for|whether you)\b",
}
#: Compiled once. Order is the dictionary's, which is the order a customer asks in.
BUSINESS_SIGNALS = {
    name: re.compile(pattern, re.IGNORECASE)
    for name, pattern in BUSINESS_PATTERNS.items()
}
#: How to recognise a platform from markup the crawl already has.
#:
#: Ordered most specific first, because the markers overlap: a WordPress site built
#: with Elementor matches both, and "WordPress" is the useful answer. Each entry is
#: a fragment that appears in the HTML -- a path, a generator tag, a script name --
#: so a match is a fact rather than a guess.
PLATFORM_MARKERS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("Shopify", ("cdn.shopify.com", "shopify-features", "/cdn/shop/",
                 "shopify_pay", "myshopify.com")),
    ("Wix", ("static.wixstatic.com", "wix-warmup-data", "_wixCssStates",
             "wixsite.com", "X-Wix-")),
    ("Squarespace", ("squarespace.com/universal", "static1.squarespace.com",
                     "sqs-block", "squarespace-cdn.com")),
    ("Webflow", ("webflow.js", "assets.website-files.com", "wf-domain",
                 "uploads-ssl.webflow.com")),
    ("WordPress", ("wp-content", "wp-includes", "wp-json", "wp-emoji",
                   "/wp-admin/", "wpforms", "woocommerce")),
    ("Joomla", ("/media/jui/", "joomla-script-options", "com_content")),
    ("Drupal", ("/sites/default/files/", "drupal.js", "drupal-settings-json")),
    ("Next.js", ("__NEXT_DATA__", "/_next/static")),
    ("Nuxt", ("__NUXT__", "/_nuxt/")),
    ("React", ("data-reactroot", "react-dom", "__REACT_DEVTOOLS")),
    ("GoDaddy Website Builder", ("img1.wsimg.com", "godaddy.com/websites")),
    ("Weebly", ("weebly.com", "editmysite.com")),
    ("Duda", ("dudamobile.com", "multiscreensite.com")),
)
#: Page builders and themes, which say more about how a WordPress site is
#: maintained than the platform alone does. Reported alongside, never instead.
BUILDER_MARKERS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("Elementor", ("elementor", "/elementor/")),
    ("Divi", ("et_pb_", "/themes/divi/")),
    ("WPBakery", ("vc_row", "js_composer")),
    ("Beaver Builder", ("fl-builder", "beaver-builder")),
    ("Bricks", ("brxe-", "/bricks/")),
    ("Oxygen", ("ct_section", "oxygen-builder")),
)
#: Whether anything is measuring what visitors do. §2 asks about tracking
#: implementation, and "no analytics at all" is a real, checkable gap -- a business
#: cannot tell which pages bring enquiries if nothing is counting.
TRACKING_MARKERS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("Google Analytics 4", ("gtag/js?id=G-", "google-analytics.com/g/collect")),
    ("Google Tag Manager", ("googletagmanager.com/gtm.js", "GTM-")),
    ("Universal Analytics", ("google-analytics.com/analytics.js", "ga('create'")),
    ("Meta Pixel", ("connect.facebook.net", "fbq('init'")),
    ("Hotjar", ("static.hotjar.com",)),
    ("Microsoft Clarity", ("clarity.ms/tag",)),
    ("Plausible", ("plausible.io/js",)),
    ("Fathom", ("cdn.usefathom.com",)),
)
def detect_stack(html: str, generator: str = "") -> dict:
    """What the page says it is built with. Only markers actually present.

    Returns the platform, any page builder, and what is measuring visitors -- all
    as lists of names, so a finding can cite them and an email can mention the
    platform by name without anybody having guessed.
    """
    haystack = (html or "").lower()
    hint = (generator or "").lower()

    platform = ""
    for name, markers in PLATFORM_MARKERS:
        if any(marker.lower() in haystack for marker in markers):
            platform = name
            break
    if not platform and hint:
        # The generator meta tag, for platforms that announce themselves and
        # nothing else. Read only after the markers, which are harder to fake.
        for name, _markers in PLATFORM_MARKERS:
            if name.lower() in hint:
                platform = name
                break

    builders = [
        name for name, markers in BUILDER_MARKERS
        if any(marker.lower() in haystack for marker in markers)
    ]
    tracking = [
        name for name, markers in TRACKING_MARKERS
        if any(marker.lower() in haystack for marker in markers)
    ]

    return {
        "platform": platform,
        "builders": builders,
        "tracking": tracking,
    }
#: Link text that tells a screen-reader user nothing.
VAGUE_LINK_PATTERN = re.compile(
    r"^\s*(click here|here|read more|more|link|this|learn more|continue|\>+|\.\.\.)\s*$",
    re.IGNORECASE,
)
#: Boilerplate stripped before text extraction.
_STRIP_TAGS = ("script", "style", "noscript", "svg", "template", "iframe")
@dataclass
class Fetched:
    html: str
    load_ms: int
    size: int
    final_url: str

@dataclass
class Page:
    """One crawled page: its text, and the signals measured on it."""

    url: str
    kind: str
    title: str
    description: str
    headings: list[str]
    text: str
    facts: dict = field(default_factory=dict)
def _format_facts(facts: dict) -> str:
    return "; ".join(f"{k}={v}" for k, v in facts.items() if v not in (None, "", []))
def _clean(text: str) -> str:
    return re.sub(r"[ \t\r\f\v]+", " ", re.sub(r"\n{2,}", "\n", text)).strip()
def measure(soup: BeautifulSoup, html: str, fetched: Fetched) -> dict:
    """Collect checkable signals from one page.

    Everything here is a fact about the markup or the response -- a count, a
    presence check, a measured duration. These are the only grounds on which the
    AI is allowed to raise a finding.
    """
    facts: dict = {}

    # --- performance -----------------------------------------------------
    facts["load_ms"] = fetched.load_ms
    # One decimal place: rounding a small page to a flat "0" would read as
    # evidence of an empty response, which is not what it means.
    facts["page_kb"] = round(fetched.size / 1024, 1)
    facts["https"] = fetched.final_url.startswith("https://")
    scripts = soup.find_all("script", src=True)
    facts["external_scripts"] = len(scripts)
    facts["stylesheets"] = len(soup.find_all("link", rel="stylesheet"))
    facts["inline_style_blocks"] = len(soup.find_all("style"))

    # --- images ----------------------------------------------------------
    images = soup.find_all("img")
    facts["images"] = len(images)
    if images:
        facts["images_missing_alt"] = sum(
            1 for i in images if not (i.get("alt") or "").strip())
        facts["images_no_dimensions"] = sum(
            1 for i in images if not i.get("width") and not i.get("height"))
        facts["images_lazy_loaded"] = sum(
            1 for i in images if i.get("loading") == "lazy")
        srcs = " ".join((i.get("src") or "") for i in images).lower()
        modern = sum(srcs.count(ext) for ext in (".webp", ".avif"))
        legacy = sum(srcs.count(ext) for ext in (".jpg", ".jpeg", ".png", ".gif"))
        facts["images_modern_format"] = modern
        facts["images_legacy_format"] = legacy

    # --- mobile ----------------------------------------------------------
    viewport = soup.find("meta", attrs={"name": re.compile("^viewport$", re.I)})
    facts["viewport_meta"] = bool(viewport)
    if viewport:
        facts["viewport_content"] = (viewport.get("content") or "")[:80]
    facts["fixed_width_attrs"] = len(soup.find_all(
        attrs={"width": re.compile(r"^\d{3,}$")}))

    # --- structure and headings -----------------------------------------
    h1s = soup.find_all("h1")
    facts["h1_count"] = len(h1s)
    facts["h2_count"] = len(soup.find_all("h2"))
    facts["h3_count"] = len(soup.find_all("h3"))

    # --- SEO -------------------------------------------------------------
    title = soup.title.get_text(" ", strip=True) if soup.title else ""
    facts["title_length"] = len(title)
    meta_desc = soup.find("meta", attrs={"name": re.compile("^description$", re.I)})
    desc = (meta_desc.get("content") or "").strip() if meta_desc else ""
    facts["meta_description_length"] = len(desc)
    facts["canonical"] = bool(soup.find("link", rel="canonical"))
    facts["og_tags"] = len(soup.find_all(
        "meta", attrs={"property": re.compile("^og:", re.I)}))
    facts["structured_data_blocks"] = len(soup.find_all(
        "script", attrs={"type": re.compile("ld\\+json", re.I)}))
    facts["html_lang"] = (soup.find("html") or {}).get("lang") or "MISSING"

    # --- content ---------------------------------------------------------
    body_text = _clean(soup.get_text("\n"))
    words = body_text.split()
    facts["word_count"] = len(words)
    placeholders = PLACEHOLDER_PATTERN.findall(body_text)
    if placeholders:
        facts["placeholder_text_found"] = sorted({p.lower() for p in placeholders})[:4]
    years = re.findall(r"(?:©|copyright|&copy;)\s*(\d{4})", body_text, re.IGNORECASE)
    if years:
        facts["copyright_year"] = max(years)

    # --- conversion ------------------------------------------------------
    actionable = soup.find_all(["a", "button"])
    cta_hits = [
        _clean(el.get_text(" "))[:40]
        for el in actionable
        if CTA_PATTERN.search(el.get_text(" ", strip=True) or "")
    ]
    facts["cta_count"] = len(cta_hits)
    if cta_hits:
        facts["cta_examples"] = cta_hits[:5]

    forms = soup.find_all("form")
    facts["forms"] = len(forms)
    if forms:
        inputs = soup.find_all(["input", "textarea", "select"])
        facts["form_fields"] = len(inputs)
        facts["form_fields_unlabelled"] = sum(
            1 for i in inputs
            if not i.get("aria-label") and not i.get("placeholder")
            and not (i.get("id") and soup.find("label", attrs={"for": i.get("id")}))
            and i.get("type") not in ("hidden", "submit", "button")
        )

    # --- contact ---------------------------------------------------------
    facts["mailto_links"] = len(soup.select('a[href^="mailto:"]'))
    facts["tel_links"] = len(soup.select('a[href^="tel:"]'))
    facts["map_embed"] = bool(soup.find(
        "iframe", src=re.compile(r"(google\.com/maps|openstreetmap|mapbox)", re.I))
    ) or "google.com/maps" in html.lower()

    # --- the business questions a visitor arrives with --------------------
    #
    # Counted per page. `merge_signals` takes the best page for each, so "no
    # pricing anywhere" means no pricing on any page that was read -- which is the
    # only claim the crawl supports, and the claim the prompt is allowed to make.
    for name, pattern in BUSINESS_SIGNALS.items():
        facts[name] = len(pattern.findall(body_text))

    # --- trust and social ------------------------------------------------
    facts["trust_signal_mentions"] = len(TRUST_PATTERN.findall(body_text))
    facts["social_links"] = len(soup.select(
        'a[href*="facebook.com"], a[href*="instagram.com"], a[href*="linkedin.com"], '
        'a[href*="twitter.com"], a[href*="x.com"], a[href*="youtube.com"], '
        'a[href*="tiktok.com"]'
    ))

    # --- accessibility ---------------------------------------------------
    links = soup.find_all("a", href=True)
    facts["links"] = len(links)
    facts["vague_link_text"] = sum(
        1 for a in links if VAGUE_LINK_PATTERN.match(a.get_text(" ", strip=True) or ""))
    facts["links_new_tab_no_warning"] = sum(
        1 for a in links if a.get("target") == "_blank" and not a.get("aria-label"))

    # --- platform and tracking -------------------------------------------
    generator = soup.find("meta", attrs={"name": re.compile("^generator$", re.I)})
    if generator:
        facts["generator"] = (generator.get("content") or "")[:60]

    stack = detect_stack(html, facts.get("generator", ""))
    if stack["platform"]:
        facts["platform"] = stack["platform"]
    if stack["builders"]:
        facts["page_builder"] = stack["builders"][:3]
    # Recorded even when empty: "nothing is measuring visitors" is the finding,
    # and an absent key would be indistinguishable from a page not checked.
    facts["tracking"] = stack["tracking"][:4]
    facts["tracking_count"] = len(stack["tracking"])

    return facts
def extract(fetched: Fetched, url: str, kind: str) -> Page:
    """Measure the page, then strip it down to readable text."""
    soup = BeautifulSoup(fetched.html, "html.parser")
    facts = measure(soup, fetched.html, fetched)

    meta = soup.find("meta", attrs={"name": re.compile("^description$", re.I)}) or \
        soup.find("meta", attrs={"property": "og:description"})
    title = _clean(soup.title.get_text(" ")) if soup.title else ""

    # Measurement is done; now remove chrome so the text reads cleanly.
    for tag in soup(list(_STRIP_TAGS)):
        tag.decompose()
    for tag in soup.find_all(["nav", "footer", "header", "form"]):
        tag.decompose()

    headings = [
        _clean(h.get_text(" "))
        for h in soup.find_all(["h1", "h2", "h3"])
        if _clean(h.get_text(" "))
    ]

    return Page(
        url=url,
        kind=kind,
        title=title,
        description=_clean(meta.get("content", "")) if meta else "",
        headings=headings,
        text=_clean(soup.get_text("\n"))[:TEXT_BUDGET],
        facts=facts,
    )
def scrape_emails(html: str) -> list[str]:
    """Collect mailto: addresses -- these are published for contact."""
    soup = BeautifulSoup(html, "html.parser")
    addresses = []
    for anchor in soup.find_all("a", href=True):
        href = anchor["href"].strip()
        if href.lower().startswith("mailto:"):
            address = href[7:].split("?")[0].strip()
            if "@" in address and address not in addresses:
                addresses.append(address)
    return addresses
