"""
Deciding whether a URL is safe to fetch, and what it really points at.

Until now every website this application crawled came from OpenStreetMap. That is
still third-party data, but it is data about businesses -- nobody is putting
`http://169.254.169.254/latest/meta-data/` in a shop's map listing. A page where a
person types a URL and the server fetches it is a different thing: it is a request
forwarder, and a request forwarder inside a private network is the classic
server-side request forgery hole. So this module exists.

What it refuses, and why each one matters:

  * **Anything that is not http or https.** `file:///etc/passwd` would read the
    server's disk, `javascript:` is meaningless to a fetcher but meaningful if the
    value is ever echoed into a page, and `gopher:`/`dict:` are protocol-smuggling
    tools.
  * **Credentials in the URL.** `http://user:pass@host/` sends somebody's password
    to a third party and, worse, `http://expected.com@evil.com/` reads as
    "expected.com" to a human and resolves to `evil.com`.
  * **Ports other than 80 and 443.** A public website answers on those. Everything
    else on a server -- databases, admin panels, message queues, the application's
    own runserver -- lives on other ports, and there is no legitimate audit target
    among them.
  * **Loopback, private, link-local and reserved addresses**, whether written
    directly (`127.0.0.1`, `10.0.0.5`, `[::1]`, and the integer form `2130706433`
    that resolves to localhost) or reached through a name that points at one. Cloud
    metadata endpoints live at `169.254.169.254`, which is link-local, so they are
    covered by the range check rather than by a list of magic addresses.
  * **Names that only exist inside a network**: `localhost`, and anything under
    `.local`, `.internal`, `.localdomain`, `.home.arpa`.

**Redirects are checked too.** A public site that answers with
`302 Location: http://127.0.0.1:8000/` would otherwise walk the crawler straight
past every check above, and that redirect is entirely under the target's control.
`analyzer` follows redirects one hop at a time and asks `check()` about each one.

One honest limitation, stated because pretending otherwise would be worse: this
resolves a hostname and then hands the *name* to `requests`, which resolves it
again. A DNS entry that changes between the two answers -- DNS rebinding -- is not
prevented. Closing that needs the connection pinned to the address that was
checked, which means replacing the transport adapter. The realistic cases here are
a person pasting an internal URL and a site redirecting to one, and both are
covered.
"""

from __future__ import annotations

import ipaddress
import os
import re
import socket
from dataclasses import dataclass
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

#: Ports a public website answers on. Everything else on a host is something the
#: audit has no business reaching.
ALLOWED_PORTS = (80, 443)

ALLOWED_SCHEMES = ("http", "https")

#: Hostnames and suffixes that only mean anything inside a network.
BLOCKED_HOSTS = ("localhost", "localhost.localdomain", "ip6-localhost",
                 "ip6-loopback")
BLOCKED_SUFFIXES = (".local", ".internal", ".localdomain", ".home.arpa",
                    ".localhost")

#: Query parameters that describe how somebody arrived rather than what they are
#: looking at. Stripped so the same page reached from an ad and from a search is
#: one page, and so a tracking id from the user's own browsing does not end up in
#: an outgoing request to a stranger's server.
TRACKING_PARAMS = frozenset({
    "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
    "utm_id", "utm_name", "utm_reader", "utm_place", "utm_social",
    "utm_social-type", "utm_brand", "utm_pubreferrer", "utm_swu",
    "gclid", "gclsrc", "dclid", "wbraid", "gbraid", "gad_source",
    "fbclid", "msclkid", "twclid", "igshid", "igsh", "yclid", "ttclid",
    "mc_cid", "mc_eid", "_ga", "_gl", "ref", "referrer", "source",
    "campaignid", "adgroupid", "hsa_acc", "hsa_cam", "hsa_grp", "hsa_ad",
    "hsa_src", "hsa_tgt", "hsa_kw", "hsa_mt", "hsa_net", "hsa_ver",
    "vero_conv", "vero_id", "oly_anon_id", "oly_enc_id", "si",
})

#: A host that is all digits, or hex, or has too few labels to be a real name.
#: Not a rejection on its own -- resolution decides -- but worth naming, because
#: `http://2130706433/` is localhost written in a way that looks like nothing.
_ODD_HOST = re.compile(r"^(0x[0-9a-f]+|\d+)$", re.IGNORECASE)


def _limit(name: str, default: int) -> int:
    """One crawl limit, from the environment. §5 asks for these to be tunable."""
    try:
        return max(1, int(os.environ.get(name, "") or default))
    except (TypeError, ValueError):
        return default


class UnsafeUrl(ValueError):
    """This URL must not be fetched, with a sentence saying why.

    A `ValueError` because that is what a caller does with it -- shows it to the
    person who typed the URL. The message is written for them, not for a log.
    """


class InvalidUrl(UnsafeUrl):
    """Not a URL this application can work with at all."""


@dataclass(frozen=True)
class Target:
    """A URL that has been checked, and what was learned about it."""

    url: str
    #: The hostname as typed, lowercased, with `www.` left on.
    host: str
    #: The host without `www.`, which is what "the same site" means here.
    site: str
    scheme: str
    #: Every address the hostname resolved to, as strings. Empty when the name
    #: could not be resolved -- see `check` for why that is not fatal.
    addresses: tuple[str, ...] = ()

    @property
    def root(self) -> str:
        """The domain as somebody would say it out loud: `examplebusiness.com`.

        Deliberately not a public-suffix calculation. Doing eTLD+1 properly needs
        the public suffix list -- `example.co.uk` has two labels of suffix and
        `example.com` has one -- and guessing produces confident wrong answers on
        exactly the sites where it matters. This is the host with `www.` removed,
        which is what the crawler already treats as one site.
        """
        return self.site

    @property
    def home(self) -> str:
        """The site's front page."""
        return f"{self.scheme}://{self.host}/"


def normalise(raw: str) -> str:
    """Tidy a URL the way a person typed it into something fetchable.

    Adds a scheme when there is none -- somebody typing `examplebusiness.com` means
    a website -- lowercases the host, drops the fragment, and strips tracking
    parameters. Everything else about the path and query is left alone: `?page=2`
    is part of what the page *is*, and rewriting it would fetch a different page
    from the one that was asked for.
    """
    text = (raw or "").strip()
    if not text:
        return ""

    # Reject before guessing a scheme: `javascript:alert(1)` must not become
    # `https://javascript:alert(1)`.
    if "://" in text:
        scheme = text.split("://", 1)[0].lower()
        if scheme not in ALLOWED_SCHEMES:
            return text            # left as-is for `check` to refuse by name
    elif ":" in text.split("/", 1)[0] and not _looks_like_host_port(text):
        return text                # `mailto:x@y`, `file:/etc/passwd`
    else:
        text = f"https://{text}"

    parsed = urlparse(text)
    query = urlencode([
        (key, value) for key, value in parse_qsl(parsed.query, keep_blank_values=True)
        if key.lower() not in TRACKING_PARAMS
    ])
    return urlunparse((
        parsed.scheme.lower(),
        parsed.netloc.lower(),
        parsed.path or "/",
        parsed.params,
        query,
        "",                        # the fragment is never sent to a server
    ))


def _looks_like_host_port(text: str) -> bool:
    """`example.com:8080/path` -- a host and port, not a scheme."""
    head = text.split("/", 1)[0]
    host, _, port = head.rpartition(":")
    return bool(host) and port.isdigit()


def check(raw: str, *, resolve: bool = True) -> Target:
    """Refuse or accept one URL. Raises `UnsafeUrl` with a readable reason.

    `resolve=False` skips the DNS lookup, for a caller that only wants the syntax
    checked. The range check is the part that stops SSRF, so it is on by default.
    """
    url = normalise(raw)
    if not url:
        raise InvalidUrl("Enter a website address.")

    parsed = urlparse(url)

    if parsed.scheme not in ALLOWED_SCHEMES:
        raise UnsafeUrl(
            f"{parsed.scheme or 'that'} addresses cannot be audited. Enter a "
            "website address starting with http:// or https://.")

    if parsed.username or parsed.password or "@" in (parsed.netloc.split("]")[-1]):
        # The second half catches `http://real.com@evil.com/`, which a person
        # reads as real.com.
        raise UnsafeUrl(
            "Remove the username or password from the address. A website audit "
            "does not sign in to anything.")

    host = (parsed.hostname or "").strip().rstrip(".")
    if not host:
        raise InvalidUrl("That address has no website name in it.")

    try:
        port = parsed.port
    except ValueError as exc:
        raise InvalidUrl("That address has an invalid port.") from exc
    if port is not None and port not in ALLOWED_PORTS:
        raise UnsafeUrl(
            f"Port {port} is not a public website port. Only 80 and 443 are "
            "audited -- anything else on a server is not a website.")

    lowered = host.lower()
    if lowered in BLOCKED_HOSTS or lowered.endswith(BLOCKED_SUFFIXES):
        raise UnsafeUrl(
            f"{host} is a name that only exists inside a network, so there is "
            "nothing public to audit there.")

    literal = _as_ip(lowered)
    if literal is not None:
        _refuse_private(literal, host)
        addresses = (str(literal),)
    elif resolve:
        addresses = _resolved(lowered)
        for address in addresses:
            _refuse_private(ipaddress.ip_address(address), host)
    else:
        addresses = ()

    site = lowered.removeprefix("www.")
    if "." not in site and literal is None:
        raise InvalidUrl(
            f"{host} does not look like a website address. It needs a domain, "
            "such as examplebusiness.com.")

    return Target(url=url, host=lowered, site=site, scheme=parsed.scheme,
                  addresses=tuple(addresses))


def _as_ip(host: str):
    """The address this host *is*, or None if it is a name.

    Handles the forms that hide an address: `127.0.0.1`, `[::1]`, and the integer
    `2130706433`. The integer form is the one worth the extra branch -- it looks
    like nothing and resolves to loopback.
    """
    candidate = host.strip("[]")
    try:
        return ipaddress.ip_address(candidate)
    except ValueError:
        pass
    if _ODD_HOST.match(candidate):
        try:
            packed = int(candidate, 0 if candidate.lower().startswith("0x") else 10)
            return ipaddress.ip_address(packed)
        except (ValueError, OverflowError):
            return None
    return None


def _refuse_private(address, host: str) -> None:
    """Raise unless this address is somewhere on the public internet."""
    if address.is_global and not address.is_multicast:
        return

    if address.is_loopback:
        why = "the server itself"
    elif address.is_link_local:
        # Includes 169.254.169.254, where cloud providers answer with the
        # instance's own credentials.
        why = "a link-local address, where cloud metadata services live"
    elif address.is_private:
        why = "a private network address"
    elif address.is_multicast:
        why = "a multicast address"
    else:
        why = "a reserved address"

    raise UnsafeUrl(
        f"{host} points at {why} ({address}). Only public websites can be "
        "audited.")


def _resolved(host: str) -> tuple[str, ...]:
    """Every address a name resolves to.

    An empty tuple when the name does not resolve, and that is deliberately not an
    error: the fetch is about to fail on its own with a better message ("we could
    not reach it"), and refusing here would turn every temporary DNS blip into
    "unsafe URL", which is both wrong and alarming.
    """
    try:
        found = socket.getaddrinfo(host, None, proto=socket.IPPROTO_TCP)
    except (socket.gaierror, UnicodeError, OSError):
        return ()
    return tuple({info[4][0] for info in found})


def same_site(url: str, site: str) -> bool:
    """Is this URL on the site the audit was asked about?

    Exact host match, `www.` aside -- the rule the crawler already uses. It means
    `blog.example.com` counts as a different site from `example.com`, which is
    stricter than most people mean by "the same domain" and is the right way to be
    wrong: the alternative wanders onto a shared host and audits somebody else's
    pages.
    """
    try:
        host = (urlparse(url).hostname or "").lower().removeprefix("www.")
    except ValueError:
        return False
    return bool(host) and host == (site or "").lower().removeprefix("www.")


def guard(url: str) -> None:
    """`check` as a callable for the crawler. Raises `UnsafeUrl`.

    Passed into `crawler.analyse` so every hop of every redirect goes through the
    same rules as the address the person typed.
    """
    check(url)
