"""
The signals an audit is allowed to cite as evidence.

Every one of these is a fact a person could check by opening the page themselves, which
is the whole basis for the promise that the emails contain no invention. A measurement
that cannot be pointed at is a measurement that should not exist.
"""

from __future__ import annotations

from apps.auditing import crawler, measurements
from apps.core.testing import SignedIn

from .factories import fetched


class MeasurementTests(SignedIn):
    """The signals the AI is allowed to cite as evidence.

    These are the whole basis of "no invented issues": if a number here is
    wrong, the model will report a problem that does not exist.
    """

    def _facts(self, body_html, head_html="", load_ms=120, url="https://x.test/"):
        html = f"<html lang='en'><head>{head_html}</head><body>{body_html}</body></html>"
        return measurements.extract(fetched(html, load_ms, url), url, "home").facts

    def test_missing_alt_text_is_counted_exactly(self):
        facts = self._facts(
            '<img src="a.jpg" alt="A pizza"><img src="b.jpg"><img src="c.jpg" alt="">')

        self.assertEqual(facts["images"], 3)
        self.assertEqual(facts["images_missing_alt"], 2)

    def test_a_fully_captioned_page_reports_zero_missing(self):
        facts = self._facts('<img src="a.jpg" alt="One"><img src="b.jpg" alt="Two">')

        self.assertEqual(facts["images_missing_alt"], 0)

    def test_image_formats_are_counted(self):
        facts = self._facts(
            '<img src="a.webp" alt="x"><img src="b.jpg" alt="y"><img src="c.png" alt="z">')

        self.assertEqual(facts["images_modern_format"], 1)
        self.assertEqual(facts["images_legacy_format"], 2)

    def test_viewport_meta_presence_is_recorded(self):
        with_vp = self._facts("", '<meta name="viewport" content="width=device-width">')
        without = self._facts("", "")

        self.assertTrue(with_vp["viewport_meta"])
        self.assertIn("device-width", with_vp["viewport_content"])
        self.assertFalse(without["viewport_meta"])

    def test_load_time_and_page_weight_are_recorded(self):
        facts = self._facts("<p>hello</p>" * 200, load_ms=3400)

        self.assertEqual(facts["load_ms"], 3400)
        self.assertGreater(facts["page_kb"], 0)

    def test_a_small_page_is_not_rounded_to_a_misleading_zero(self):
        """"page_kb=0" would read as evidence of an empty response."""
        facts = self._facts("<p>hi</p>")

        self.assertGreater(facts["page_kb"], 0)

    def test_https_is_detected_from_the_final_url(self):
        self.assertTrue(self._facts("", url="https://x.test/")["https"])
        self.assertFalse(self._facts("", url="http://x.test/")["https"])

    def test_cta_phrases_are_found_and_quoted(self):
        facts = self._facts(
            '<a href="/c">Contact us</a><button>Book now</button><a href="/x">Pizza</a>')

        self.assertEqual(facts["cta_count"], 2)
        self.assertIn("Contact us", facts["cta_examples"])

    def test_a_page_with_no_cta_reports_zero(self):
        facts = self._facts('<a href="/x">Pizza</a><a href="/y">Pasta</a>')

        self.assertEqual(facts["cta_count"], 0)

    def test_heading_structure_is_counted(self):
        facts = self._facts("<h1>A</h1><h1>B</h1><h2>C</h2><h3>D</h3><h3>E</h3>")

        self.assertEqual(facts["h1_count"], 2)
        self.assertEqual(facts["h2_count"], 1)
        self.assertEqual(facts["h3_count"], 2)

    def test_seo_basics_are_recorded(self):
        facts = self._facts("", """
            <title>Bella Cucina - Italian in Delft</title>
            <meta name="description" content="Wood-fired pizza in Delft.">
            <link rel="canonical" href="https://x.test/">
            <meta property="og:title" content="Bella">
            <script type="application/ld+json">{}</script>
        """)

        self.assertGreater(facts["title_length"], 0)
        self.assertGreater(facts["meta_description_length"], 0)
        self.assertTrue(facts["canonical"])
        self.assertEqual(facts["og_tags"], 1)
        self.assertEqual(facts["structured_data_blocks"], 1)

    def test_a_missing_meta_description_reads_as_zero_length(self):
        self.assertEqual(self._facts("", "<title>x</title>")["meta_description_length"], 0)

    def test_placeholder_text_is_flagged(self):
        facts = self._facts("<p>Lorem ipsum dolor sit amet, our site is Coming Soon</p>")

        self.assertIn("placeholder_text_found", facts)
        self.assertTrue(any("lorem ipsum" in p for p in facts["placeholder_text_found"]))

    def test_clean_copy_is_not_flagged_as_placeholder(self):
        facts = self._facts("<p>We make wood-fired pizza by hand every morning.</p>")

        self.assertNotIn("placeholder_text_found", facts)

    def test_copyright_year_is_captured(self):
        self.assertEqual(self._facts("<p>© 2019 Bella Cucina</p>")["copyright_year"],
                         "2019")

    def test_contact_affordances_are_counted(self):
        facts = self._facts(
            '<a href="mailto:a@b.test">Email</a><a href="tel:+3115">Call</a>')

        self.assertEqual(facts["mailto_links"], 1)
        self.assertEqual(facts["tel_links"], 1)

    def test_form_fields_without_labels_are_counted(self):
        facts = self._facts("""
            <form>
              <label for="n">Name</label><input id="n">
              <input id="e">
              <textarea id="m"></textarea>
              <input type="hidden" id="h">
              <input type="submit" value="Send">
            </form>
        """)

        self.assertEqual(facts["forms"], 1)
        # The labelled input, the hidden field and the submit are all excluded.
        self.assertEqual(facts["form_fields_unlabelled"], 2)

    def test_trust_signals_are_counted(self):
        facts = self._facts(
            "<p>Read our reviews. Rated 5 stars. Certified and insured since 1998.</p>")

        self.assertGreater(facts["trust_signal_mentions"], 2)

    def test_vague_link_text_is_counted(self):
        facts = self._facts(
            '<a href="/a">Click here</a><a href="/b">Read more</a>'
            '<a href="/c">Our wood-fired pizza menu</a>')

        self.assertEqual(facts["vague_link_text"], 2)

    def test_social_links_are_counted(self):
        facts = self._facts(
            '<a href="https://facebook.com/x">FB</a>'
            '<a href="https://instagram.com/x">IG</a>')

        self.assertEqual(facts["social_links"], 2)

    def test_html_lang_is_recorded_or_flagged(self):
        url = "https://x.test/"
        with_lang = measurements.extract(
            fetched("<html lang='nl'><body>x</body></html>", url=url), url, "home")
        without = measurements.extract(
            fetched("<html><body>x</body></html>", url=url), url, "home")

        self.assertEqual(with_lang.facts["html_lang"], "nl")
        self.assertEqual(without.facts["html_lang"], "MISSING")

    def test_word_count_reflects_visible_text(self):
        facts = self._facts("<p>one two three four five</p>")

        self.assertEqual(facts["word_count"], 5)

    def test_context_stays_within_its_character_budget(self):
        """Breadth must not blow the provider's token limit.

        A 6-page crawl at the full per-page allowance came to ~10.5k tokens,
        over Groq's free-tier 8k/minute cap, so the review could never run.
        """
        pages = [
            measurements.Page(f"https://x.test/{i}", "services", f"T{i}", "d",
                          ["H"], "word " * 3000, {"cta_count": 0})
            for i in range(6)
        ]
        result = crawler.SiteAnalysis(crawler.OK, "ok", pages, discovered=9)

        context = result.as_context(char_budget=9000)

        self.assertLess(len(context), 11000)
        # Every page still contributes something.
        for i in range(6):
            self.assertIn(f"https://x.test/{i}", context)

    def test_measured_signals_are_never_trimmed_away(self):
        """Signals are the evidence, and they are cheap. Prose is what gives."""
        pages = [
            measurements.Page(f"https://x.test/{i}", "services", "T", "", [],
                          "word " * 5000,
                          {"images_missing_alt": 7, "cta_count": 0})
            for i in range(5)
        ]
        context = crawler.SiteAnalysis(
            crawler.OK, "ok", pages).as_context(char_budget=4000)

        self.assertEqual(context.count("images_missing_alt=7"), 5)

    def test_a_small_crawl_is_not_padded(self):
        page = measurements.Page("https://x.test/", "home", "T", "", [], "short text",
                             {"cta_count": 1})
        context = crawler.SiteAnalysis(
            crawler.OK, "ok", [page]).as_context(char_budget=9000)

        self.assertIn("short text", context)
        self.assertLess(len(context), 500)

    def test_signals_reach_the_ai_context(self):
        page = measurements.Page(
            url="https://x.test/", kind="home", title="T", description="",
            headings=["H"], text="Body text",
            facts={"images_missing_alt": 4, "cta_count": 0, "load_ms": 3200},
        )
        context = crawler.SiteAnalysis(crawler.OK, "ok", [page]).as_context()

        self.assertIn("images_missing_alt=4", context)
        self.assertIn("load_ms=3200", context)
        self.assertIn("Meta description: MISSING", context)
