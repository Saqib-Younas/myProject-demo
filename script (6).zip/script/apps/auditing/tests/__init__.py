"""Tests for the crawler and the audit analysis.

Split from the outreach app's test module, where they had accumulated because there was
only one app. What is tested here reads websites and measures them; nothing in this
package knows what a campaign is.
"""
