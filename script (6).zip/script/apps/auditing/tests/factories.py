"""
Two web pages and a fake response, for tests that must not touch a network.

`HTML_HOME` is deliberately imperfect in specific ways -- it has a description and
headings, a couple of internal links worth following and a `mailto:` -- because that is
what makes it useful for testing both what the crawler extracts and what it decides to
read next.
"""

from __future__ import annotations

from unittest import mock

from apps.auditing import crawler

HTML_HOME = """
<html><head><title>Bella Cucina</title>
<meta name="description" content="Family-run Italian kitchen in Delft.">
</head><body>
<h1>Bella Cucina</h1><h2>Wood-fired pizza since 1998</h2>
<p>We make everything by hand, including our sourdough bases.</p>
<a href="/about">About us</a>
<a href="/services">Our services</a>
<a href="/contact">Contact</a>
<a href="https://facebook.com/x">Facebook</a>
<a href="mailto:ciao@bella.example">Email us</a>
</body></html>
"""
HTML_ABOUT = """
<html><head><title>About - Bella Cucina</title></head><body>
<h1>Our story</h1><p>Three generations of the Rossi family.</p>
<script>var tracking = 1;</script>
</body></html>
"""
class FakeResponse:
    """Stands in for a requests.Response in analyser tests."""

    def __init__(self, text="", status_code=200, content_type="text/html",
                 url="https://bella.example/"):
        self.text = text
        self.status_code = status_code
        self.headers = {"Content-Type": content_type}
        self.encoding = "utf-8"
        self.url = url
        self.raw = mock.Mock()
        self.raw.read.return_value = text.encode()

    def raise_for_status(self):
        if self.status_code >= 400:
            raise __import__("requests").HTTPError(f"HTTP {self.status_code}")
def fetched(html, load_ms=120, url="https://bella.example/"):
    """Wrap raw HTML the way crawler._fetch would return it."""
    return crawler.Fetched(html, load_ms, len(html.encode()), url)
