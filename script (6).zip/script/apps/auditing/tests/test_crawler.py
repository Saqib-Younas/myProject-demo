"""
What the crawler reads, what it refuses to read, and how it chooses.

The refusals are the half worth having: `robots.txt` is obeyed, a bot wall is
recognised and abandoned rather than worked around, and a page that is not HTML is not
parsed. Those are the tests that keep this a permitted-data-only crawler, and they are
here rather than in the outreach app because that is where the crawler is.
"""

from __future__ import annotations

from unittest import mock

from apps.auditing import crawler, measurements
from apps.core.testing import SignedIn

from .factories import HTML_ABOUT, HTML_HOME, FakeResponse, fetched


class AnalyserExtractionTests(SignedIn):
    def test_extracts_title_description_and_headings(self):
        page = measurements.extract(fetched(HTML_HOME), "https://bella.example", "home")

        self.assertEqual(page.title, "Bella Cucina")
        self.assertEqual(page.description, "Family-run Italian kitchen in Delft.")
        self.assertIn("Wood-fired pizza since 1998", page.headings)
        self.assertIn("sourdough bases", page.text)

    def test_scripts_are_not_part_of_the_text(self):
        page = measurements.extract(
            fetched(HTML_ABOUT), "https://bella.example/about", "about")

        self.assertNotIn("var tracking", page.text)
        self.assertIn("Three generations", page.text)

    def test_collects_published_mailto_addresses(self):
        self.assertEqual(measurements.scrape_emails(HTML_HOME), ["ciao@bella.example"])

    def test_normalise_adds_a_scheme(self):
        self.assertEqual(crawler.normalise("bella.example"), "https://bella.example")
        self.assertEqual(crawler.normalise(""), "")
class DiscoveryTests(SignedIn):
    """The crawler must decide for itself which pages are worth reading."""

    def test_internal_links_are_classified_and_scored(self):
        rows = crawler.discover_links(HTML_HOME, "https://bella.example")
        by_kind = {kind: url for url, kind, _score in rows}

        self.assertEqual(by_kind["about"], "https://bella.example/about")
        self.assertEqual(by_kind["services"], "https://bella.example/services")
        self.assertEqual(by_kind["contact"], "https://bella.example/contact")

    def test_external_links_are_not_followed(self):
        rows = crawler.discover_links(HTML_HOME, "https://bella.example")

        self.assertFalse(any("facebook" in url for url, _k, _s in rows))

    def test_the_home_page_is_not_offered_as_a_candidate(self):
        html = '<a href="/">Home</a><a href="/services">Services</a>'
        rows = crawler.discover_links(html, "https://bella.example")

        self.assertEqual([url for url, _k, _s in rows],
                         ["https://bella.example/services"])

    def test_boilerplate_and_account_pages_are_skipped(self):
        html = """
        <a href="/privacy-policy">Privacy</a><a href="/terms">Terms</a>
        <a href="/cart">Cart</a><a href="/my-account">Account</a>
        <a href="/wp-login.php">Login</a><a href="/feed">RSS</a>
        <a href="/tag/pizza">Tag</a><a href="/brochure.pdf">PDF</a>
        <a href="/services">Services</a>
        """
        rows = crawler.discover_links(html, "https://bella.example")

        self.assertEqual([url for url, _k, _s in rows],
                         ["https://bella.example/services"])

    def test_navigation_links_outrank_body_links(self):
        html = """
        <nav><a href="/our-services">Services</a></nav>
        <div><a href="/blog/a-post">A post</a></div>
        """
        rows = crawler.discover_links(html, "https://bella.example")

        self.assertEqual(rows[0][1], "services")
        self.assertGreater(rows[0][2], rows[-1][2])

    def test_shallow_pages_outrank_deep_ones(self):
        html = """
        <a href="/services">Services</a>
        <a href="/a/b/c/d/services-detail">Deep services</a>
        """
        rows = crawler.discover_links(html, "https://bella.example")

        self.assertEqual(rows[0][0], "https://bella.example/services")

    def test_duplicate_urls_collapse(self):
        html = """
        <a href="/services">Services</a>
        <a href="/services/">Services again</a>
        <a href="/services#top">Services anchor</a>
        """
        rows = crawler.discover_links(html, "https://bella.example")

        self.assertEqual(len(rows), 1)

    def test_classify_recognises_the_business_page_kinds(self):
        for path, expected in (
            ("/our-services", "services"),
            ("/shop/menu", "products"),
            ("/pricing", "pricing"),
            ("/contact-us", "contact"),
            ("/about-us", "about"),
            ("/testimonials", "testimonials"),
            ("/blog/hello", "blog"),
        ):
            with self.subTest(path=path):
                self.assertEqual(crawler.classify(path)[0], expected)

    def test_an_unrecognised_page_scores_zero(self):
        self.assertEqual(crawler.classify("/random-thing"), ("other", 0))

    def test_substrings_do_not_cause_false_classifications(self):
        """Both of these were mislabelled on a real site before word boundaries.

        "workshops" contains "shop", so it was filed as a products page, and
        "quotes" (testimonials) matched the pricing pattern for "quote". A wrong
        page kind reaches the AI as a wrong claim about the business.
        """
        self.assertNotEqual(crawler.classify("/community/workshops")[0], "products")
        # /about/quotes lands on "about", which is right -- it is under /about.
        # What matters is that it is no longer read as a pricing page.
        self.assertNotEqual(crawler.classify("/about/quotes")[0], "pricing")
        self.assertEqual(crawler.classify("/client-quotes")[0], "testimonials")
        self.assertNotEqual(crawler.classify("/restore-data")[0], "products")
        self.assertNotEqual(crawler.classify("/arrangements")[0], "products")

    def test_the_genuine_forms_still_classify(self):
        self.assertEqual(crawler.classify("/shop")[0], "products")
        self.assertEqual(crawler.classify("/get-a-quote")[0], "pricing")
        self.assertEqual(crawler.classify("/our-services")[0], "services")

    def test_choose_pages_prefers_a_spread_of_kinds(self):
        # Five service pages tell us less than services + pricing + contact.
        candidates = [
            ("https://x/services-1", "services", 100),
            ("https://x/services-2", "services", 99),
            ("https://x/services-3", "services", 98),
            ("https://x/pricing", "pricing", 90),
            ("https://x/contact", "contact", 85),
        ]

        chosen = crawler.choose_pages(candidates, 3)
        kinds = [kind for _url, kind, _score in chosen]

        self.assertEqual(kinds, ["services", "pricing", "contact"])

    def test_choose_pages_backfills_when_kinds_run_out(self):
        candidates = [
            ("https://x/services-1", "services", 100),
            ("https://x/services-2", "services", 99),
        ]

        chosen = crawler.choose_pages(candidates, 2)

        self.assertEqual(len(chosen), 2)
class SitemapTests(SignedIn):
    def test_sitemap_urls_are_discovered_and_classified(self):
        xml = """<?xml version="1.0"?>
        <urlset><url><loc>https://bella.example/services</loc></url>
        <url><loc>https://bella.example/pricing</loc></url>
        <url><loc>https://bella.example/privacy</loc></url>
        <url><loc>https://elsewhere.test/services</loc></url></urlset>"""

        with mock.patch.object(crawler.requests, "get",
                               return_value=FakeResponse(xml)):
            rows = crawler.discover_sitemap("https://bella.example", None)

        urls = [url for url, _k, _s in rows]
        self.assertIn("https://bella.example/services", urls)
        self.assertIn("https://bella.example/pricing", urls)
        self.assertNotIn("https://bella.example/privacy", urls)   # boilerplate
        self.assertFalse(any("elsewhere.test" in u for u in urls))  # off-site

    def test_a_missing_sitemap_is_not_an_error(self):
        with mock.patch.object(crawler.requests, "get",
                               return_value=FakeResponse("", 404)):
            self.assertEqual(crawler.discover_sitemap("https://bella.example", None), [])

    def test_robots_declared_sitemaps_are_tried_first(self):
        robots = crawler.RobotFileParser()
        robots.parse(["Sitemap: https://bella.example/custom-sitemap.xml",
                      "User-agent: *", "Allow: /"])
        xml = ("<urlset><url><loc>https://bella.example/services</loc></url>"
               "</urlset>")

        with mock.patch.object(crawler.requests, "get",
                               return_value=FakeResponse(xml)) as get:
            crawler.discover_sitemap("https://bella.example", robots)

        self.assertIn("custom-sitemap.xml", get.call_args_list[0][0][0])
class AnalyserPolicyTests(SignedIn):
    """The rules that keep this a permitted-data-only crawler."""

    def setUp(self):
        crawler._robots.clear()
        crawler._last_hit.clear()

    def test_no_website_is_reported_not_guessed(self):
        result = crawler.analyse("")

        self.assertEqual(result.status, crawler.NO_WEBSITE)
        self.assertFalse(result.usable)
        self.assertEqual(result.as_context(), "")

    def test_robots_disallow_stops_the_crawl(self):
        robots = FakeResponse("User-agent: *\nDisallow: /", 200, "text/plain")

        with mock.patch.object(crawler.requests, "get", return_value=robots) as get:
            result = crawler.analyse("https://bella.example")

        self.assertEqual(result.status, crawler.BLOCKED)
        self.assertIn("robots.txt", result.detail)
        # robots.txt only -- the page itself was never requested.
        self.assertEqual(get.call_count, 1)

    def test_unauthorised_robots_is_treated_as_disallow_all(self):
        with mock.patch.object(crawler.requests, "get",
                               return_value=FakeResponse("", 403)):
            result = crawler.analyse("https://bella.example")

        self.assertEqual(result.status, crawler.BLOCKED)

    def test_http_403_on_the_page_is_recorded_not_retried(self):
        responses = [FakeResponse("", 404), FakeResponse("", 403)]

        with mock.patch.object(crawler.requests, "get", side_effect=responses):
            result = crawler.analyse("https://bella.example")

        self.assertEqual(result.status, crawler.BLOCKED)
        self.assertIn("403", result.detail)

    def test_bot_wall_is_not_worked_around(self):
        wall = FakeResponse(
            "<html><head><title>Attention Required! | Cloudflare</title></head>"
            "<body>Checking your browser before accessing</body></html>"
        )

        with mock.patch.object(crawler.requests, "get",
                               side_effect=[FakeResponse("", 404), wall]):
            result = crawler.analyse("https://bella.example")

        self.assertEqual(result.status, crawler.BLOCKED)
        self.assertIn("bot check", result.detail)

    def test_rate_limited_site_is_left_alone(self):
        with mock.patch.object(crawler.requests, "get",
                               side_effect=[FakeResponse("", 404),
                                            FakeResponse("", 429)]):
            result = crawler.analyse("https://bella.example")

        self.assertEqual(result.status, crawler.BLOCKED)

    def test_successful_crawl_reads_home_plus_interior_pages(self):
        # Request order is robots.txt, home, sitemap, then the chosen pages.
        pages = [FakeResponse("", 404), FakeResponse(HTML_HOME),
                 FakeResponse("", 404)] + [FakeResponse(HTML_ABOUT)] * 6

        with mock.patch.object(crawler.requests, "get", side_effect=pages):
            result = crawler.analyse("https://bella.example")

        self.assertEqual(result.status, crawler.OK)
        self.assertTrue(result.usable)
        self.assertLessEqual(len(result.pages), crawler.MAX_PAGES)
        self.assertEqual(result.pages[0].kind, "home")
        self.assertIn("wood-fired pizza", result.as_context().lower())
        self.assertIn("ciao@bella.example", result.emails_found)

    def test_the_crawler_visits_several_internal_pages_by_itself(self):
        """The user supplies one URL; the crawler finds the rest."""
        nav = """
        <html><head><title>Bella</title></head><body>
        <nav>
          <a href="/services">Services</a><a href="/pricing">Pricing</a>
          <a href="/about">About</a><a href="/contact">Contact</a>
          <a href="/testimonials">Reviews</a><a href="/team">Team</a>
        </nav><h1>Bella</h1><p>Pizza.</p></body></html>
        """
        responses = [FakeResponse("", 404), FakeResponse(nav),
                     FakeResponse("", 404)] + [FakeResponse(HTML_ABOUT)] * 10

        with mock.patch.object(crawler.requests, "get", side_effect=responses):
            result = crawler.analyse("https://bella.example")

        internal = [p for p in result.pages if p.kind != "home"]
        self.assertGreaterEqual(len(internal), crawler.TARGET_INTERNAL)
        self.assertGreater(result.discovered, 0)
        # A spread of page kinds, not five copies of one.
        self.assertGreaterEqual(len({p.kind for p in internal}), 4)

    def test_a_thin_site_reports_what_it_could_reach(self):
        thin = ("<html><head><title>Bella</title></head><body><h1>Bella</h1>"
                '<a href="/contact">Contact</a></body></html>')
        responses = [FakeResponse("", 404), FakeResponse(thin),
                     FakeResponse("", 404), FakeResponse(thin)]

        with mock.patch.object(crawler.requests, "get", side_effect=responses):
            result = crawler.analyse("https://bella.example")

        self.assertEqual(result.status, crawler.OK)
        self.assertEqual(len(result.pages), 2)   # home + contact, all there was
        self.assertIn("Only 1 useful internal page", result.detail)

    def test_the_page_budget_is_respected(self):
        many = "<html><body>" + "".join(
            f'<a href="/services-{i}">Service {i}</a>' for i in range(40)
        ) + "</body></html>"
        responses = [FakeResponse("", 404), FakeResponse(many),
                     FakeResponse("", 404)] + [FakeResponse(many)] * 30

        with mock.patch.object(crawler.requests, "get", side_effect=responses):
            result = crawler.analyse("https://bella.example")

        self.assertLessEqual(len(result.pages), crawler.MAX_PAGES)

    def test_user_agent_carries_a_contact_address(self):
        agent = crawler._headers()["User-Agent"]

        self.assertIn("LeadMapperBot", agent)
        self.assertIn("robots.txt", agent)
