"""
What the crawler may fetch at all.

The crawler will follow a URL a stranger typed into a form, so the check in front of it
is the boundary between "reads a website" and "reads whatever is reachable from the
server". These tests are that boundary written down: loopback, link-local, the private
ranges, the cloud metadata address, a non-HTTP scheme, credentials in the URL, an
unexpected port.

Refusals are the whole content of this module. There is no test here for a URL being
allowed that is not also a test for a class of URL being refused, because a permissive
bug in this code is not a crawl that fails -- it is a crawl that succeeds against
something it should never have seen.

The same rules are exercised again in `apps/outreach/tests/test_websiteaudit.py`, where
they are applied to redirects arriving mid-crawl. Both matter: a public site that
redirects to `169.254.169.254` is the interesting attack, and it cannot be tested
without a crawl.
"""

from __future__ import annotations

from unittest import mock

from django.test import TestCase

from apps.auditing import safeurl


class SafeUrlTests(TestCase):
    """What may be fetched at all.

    The submitted URL is the one thing in this feature a stranger controls, so this
    is the boundary. Each refusal below is a request that would otherwise have been
    made from inside the server's own network.
    """

    def test_a_bare_domain_becomes_https(self):
        self.assertEqual(safeurl.check("examplebusiness.com").url,
                         "https://examplebusiness.com/")

    def test_an_http_url_is_kept_as_http(self):
        """Not upgraded: a site that has no certificate would then be unreachable."""
        self.assertEqual(safeurl.check("http://examplebusiness.com").scheme,
                         "http")

    def test_the_host_is_lowercased_and_the_fragment_dropped(self):
        target = safeurl.check("HTTPS://Example.COM/Path#section")

        self.assertEqual(target.url, "https://example.com/Path")
        self.assertEqual(target.host, "example.com")

    def test_tracking_parameters_are_stripped_and_real_ones_kept(self):
        target = safeurl.check(
            "https://example.com/x?utm_source=ads&fbclid=abc&page=2&gclid=z")

        self.assertEqual(target.url, "https://example.com/x?page=2")

    def test_www_is_kept_in_the_host_and_dropped_from_the_site(self):
        target = safeurl.check("https://www.example.com")

        self.assertEqual(target.host, "www.example.com")
        self.assertEqual(target.site, "example.com")
        self.assertEqual(target.root, "example.com")

    def test_an_empty_url_is_refused(self):
        with self.assertRaises(safeurl.InvalidUrl):
            safeurl.check("")

    def test_a_url_with_no_domain_is_refused(self):
        with self.assertRaises(safeurl.InvalidUrl):
            safeurl.check("notadomain")

    def test_non_http_schemes_are_refused(self):
        for bad in ("javascript:alert(1)", "file:///etc/passwd",
                    "ftp://example.com/x", "gopher://example.com",
                    "data:text/html,<h1>x", "mailto:someone@example.com"):
            with self.subTest(url=bad), self.assertRaises(safeurl.UnsafeUrl):
                safeurl.check(bad)

    def test_loopback_is_refused(self):
        for bad in ("http://127.0.0.1/", "http://[::1]/", "http://localhost/",
                    "https://127.0.0.1/admin"):
            with self.subTest(url=bad), self.assertRaises(safeurl.UnsafeUrl):
                safeurl.check(bad)

    def test_the_integer_form_of_loopback_is_refused(self):
        """`http://2130706433/` is 127.0.0.1 written to look like nothing."""
        with self.assertRaises(safeurl.UnsafeUrl):
            safeurl.check("http://2130706433/")

    def test_private_ranges_are_refused(self):
        for bad in ("http://10.0.0.5/", "http://192.168.1.1/",
                    "http://172.16.0.9/", "http://[fd00::1]/"):
            with self.subTest(url=bad), self.assertRaises(safeurl.UnsafeUrl):
                safeurl.check(bad)

    def test_the_cloud_metadata_endpoint_is_refused(self):
        with self.assertRaises(safeurl.UnsafeUrl) as caught:
            safeurl.check("http://169.254.169.254/latest/meta-data/")

        self.assertIn("metadata", str(caught.exception))

    def test_internal_hostnames_are_refused(self):
        for bad in ("http://db.internal/", "http://printer.local/",
                    "http://host.localdomain/"):
            with self.subTest(url=bad), self.assertRaises(safeurl.UnsafeUrl):
                safeurl.check(bad)

    def test_non_web_ports_are_refused(self):
        for bad in ("http://example.com:8000/", "http://example.com:22/",
                    "http://example.com:5432/"):
            with self.subTest(url=bad), self.assertRaises(safeurl.UnsafeUrl):
                safeurl.check(bad)

    def test_the_standard_ports_are_allowed(self):
        self.assertTrue(safeurl.check("http://example.com:80/").url)
        self.assertTrue(safeurl.check("https://example.com:443/").url)

    def test_credentials_in_the_url_are_refused(self):
        for bad in ("http://user:pass@example.com/",
                    "http://real.example.com@evil.example/"):
            with self.subTest(url=bad), self.assertRaises(safeurl.UnsafeUrl):
                safeurl.check(bad)

    def test_a_hostname_that_resolves_to_a_private_address_is_refused(self):
        """The realistic shape: a name somebody controls, pointing inside."""
        with mock.patch.object(safeurl, "_resolved", return_value=("10.1.2.3",)):
            with self.assertRaises(safeurl.UnsafeUrl):
                safeurl.check("https://sneaky.example/")

    def test_a_name_that_does_not_resolve_is_allowed_through(self):
        """The fetch fails next with a better message than "unsafe URL"."""
        with mock.patch.object(safeurl, "_resolved", return_value=()):
            self.assertTrue(safeurl.check("https://nowhere.example/").url)

    def test_same_site_is_exact_apart_from_www(self):
        self.assertTrue(safeurl.same_site("https://www.example.com/x",
                                          "example.com"))
        self.assertTrue(safeurl.same_site("https://example.com/x",
                                          "www.example.com"))
        self.assertFalse(safeurl.same_site("https://other.example/x",
                                           "example.com"))
        self.assertFalse(safeurl.same_site("https://blog.example.com/x",
                                           "example.com"))
