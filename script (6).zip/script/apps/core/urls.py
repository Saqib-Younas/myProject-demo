"""
Settings → Database routes.

Mounted under the settings prefix, so the page is a sub-page of Settings rather than a
top-level section: it is configuration, and it is the piece of configuration a person
touches least often.

Every route is staff-only, enforced in the view rather than here. A decorator on the
URLconf would be easy to lose in a later edit; a call at the top of each view is visible
in the function a reader is already looking at.
"""

from django.urls import path

from . import views

app_name = "core"

urlpatterns = [
    path("settings/database", views.database_view, name="database"),
    path("settings/database/state", views.database_state, name="database_state"),
    path("settings/database/supabase", views.supabase_save, name="supabase_save"),
    path("settings/database/test", views.connection_test, name="connection_test"),
    path("settings/database/switch", views.database_switch, name="database_switch"),
]
