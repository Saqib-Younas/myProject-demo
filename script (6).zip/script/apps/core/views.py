"""
Settings → Database.

Five endpoints, all of them thin: parse the request, call `apps/core/database.py`, render
or return JSON. Every decision -- what counts as configured, whether a switch may go
ahead, what a connection test means -- is in that module, where it can be tested without
a request.

**Staff only.** Unlike the AI credentials and the sending addresses, which are per
account, this is one global setting: it decides which database *everybody's* data is in.
`LoginRequiredMiddleware` already means a signed-in user, which is not enough here, so
every view in this module goes through `_require_staff` first.

**No key is ever in a response.** The page receives `SupabaseConfig`, which carries a
mask and a boolean per key and no plaintext. There is no endpoint that reads a key back,
deliberately: saving with an empty key field means "leave the stored one alone", so the
browser never needs a round trip. `apps/core/tests/test_database_ui.py` asserts this
against every response this module can produce.

**Nothing here logs.** Not the URL, not a key, not a connection string. The two keys are
read from the form and handed straight to the encryption; the only thing that reaches a
log is whatever `apps/core/database.py` chooses to put in a returned sentence, and it is
written for a person to read on this page.
"""

from __future__ import annotations

from django.core.exceptions import PermissionDenied
from django.http import HttpRequest, HttpResponse, JsonResponse
from django.shortcuts import render
from django.views.decorators.http import require_GET, require_POST

from apps.core import database
from apps.core.http import json_body


def _require_staff(request: HttpRequest) -> None:
    """Only a staff account may read or change which database is in use.

    `PermissionDenied` rather than a redirect: this is reached by fetch() from the
    settings page as often as by a person typing the URL, and a 403 is the answer both
    can understand. A redirect to a login page would arrive at JavaScript as a 200 full
    of HTML.
    """
    user = getattr(request, "user", None)
    if not (user and user.is_authenticated and user.is_staff):
        raise PermissionDenied(
            "Database settings are restricted to staff accounts. They decide which "
            "database every account's data is in, so they are not a per-user setting.")


def _payload() -> dict:
    """Everything the page needs, and nothing a key could hide in."""
    config = database.supabase_config()
    local = database.local_status()
    supabase = database.supabase_status()
    running = database.active()

    return {
        "active": running,
        "active_label": database.label(running),
        "active_description": database.active_description(),
        "selection": database.selection(),
        "pending_restart": database.pending_restart(),
        "supabase": {
            "url": config.url,
            # Masks and booleans. There is no field here that could carry a key.
            "anon_masked": config.anon_masked,
            "service_masked": config.service_masked,
            "anon_set": config.anon_set,
            "service_set": config.service_set,
            "from_env": config.from_env,
            "complete": config.complete,
            "database_url_present": database.database_url_present(),
            "status": {"ready": supabase.ready, "summary": supabase.summary,
                       "detail": supabase.detail},
        },
        "local": {
            "status": {"ready": local.ready, "summary": local.summary,
                       "detail": local.detail},
        },
    }


@require_GET
def database_view(request: HttpRequest) -> HttpResponse:
    """The page: which database is live, which is chosen, and how to change it."""
    _require_staff(request)

    data = _payload()
    return render(request, "core/database.html", {
        "nav": "settings",
        "db": data,
        "LOCAL": database.LOCAL,
        "SUPABASE": database.SUPABASE,
    })


@require_GET
def database_state(request: HttpRequest) -> JsonResponse:
    """The same figures as JSON, for the page to refresh itself after an action."""
    _require_staff(request)
    return JsonResponse(_payload())


@require_POST
def supabase_save(request: HttpRequest) -> JsonResponse:
    """Store the three Supabase fields. Switches nothing.

    An empty key field means "keep the stored one", which is what lets somebody correct
    the URL without their browser having to send a key back to do it.
    """
    _require_staff(request)

    body = json_body(request)
    try:
        config = database.save_supabase(
            body.get("url", ""),
            body.get("anon_key", ""),
            body.get("service_key", ""),
        )
    except database.DatabaseSettingsError as exc:
        # `DatabaseSettingsError` is documented to carry no secret, which is why its
        # message can go straight into a response.
        return JsonResponse({"error": str(exc)}, status=400)

    return JsonResponse({
        "message": ("Saved. The keys are encrypted at rest and are not shown again."
                    if config.complete else "Saved."),
        **_payload(),
    })


@require_POST
def connection_test(request: HttpRequest) -> JsonResponse:
    """Test one of the two databases and report what was found.

    Returns 200 whether or not the test passed: the request succeeded, and the answer is
    in the body. A 502 for a failed test would make the page's error handling fight with
    its result handling for the same case.
    """
    _require_staff(request)

    target = json_body(request).get("target", database.SUPABASE)
    if target not in database.CHOICES:
        return JsonResponse({"error": "Choose either the local database or Supabase."},
                            status=400)

    result = (database.test_local() if target == database.LOCAL
              else database.test_supabase())

    return JsonResponse({
        "ok": result.ok,
        "message": result.message,
        "lines": result.lines,
        **_payload(),
    })


@require_POST
def database_switch(request: HttpRequest) -> JsonResponse:
    """Choose a database, after checking it could work.

    A failed check leaves the selection exactly as it was -- that is enforced in
    `database.switch`, which writes the file only after validation passes, and asserted
    by `test_database.py`.
    """
    _require_staff(request)

    target = json_body(request).get("target", "")
    try:
        status = database.switch(target)
    except database.DatabaseSettingsError as exc:
        return JsonResponse({"error": str(exc), **_payload()}, status=400)

    return JsonResponse({
        "message": status.detail or status.summary,
        "needs_restart": status.needs_restart,
        **_payload(),
    })
