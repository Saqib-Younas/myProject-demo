"""
Encrypting a secret at rest, in one place.

Three things store a secret in this project: AI provider keys, mailbox passwords, and
now the Supabase service-role key. They must not each have their own idea of how a
secret is encrypted, so the mechanism lives here and they call it.

**How.** Fernet (AES-128-CBC with an HMAC), under a key derived from
`DJANGO_SECRET_KEY` with PBKDF2-HMAC-SHA256 at 200,000 iterations.

**Why derived rather than used directly.** `SECRET_KEY` is not 32 url-safe base64
bytes, so it cannot be a Fernet key as it stands. Running it through a KDF also means
the stored ciphertext is not decryptable with the signing key alone -- an attacker who
learns the session-signing value has not thereby learned how to read the stored keys.

**The salt is `b"outreach.credentials.v1"` and must never change.** It is not a secret;
it is part of the key derivation, and altering it makes every value already encrypted
unreadable. The name is historical -- this code was `apps/ai/credentials.py` before
three callers needed it -- and keeping the old string is the whole point.

**Failure is deliberately soft on the way out and hard on the way in.** `decrypt`
returns `""` for a value it cannot read, because the overwhelmingly likely cause is a
rotated `DJANGO_SECRET_KEY` and the caller can usually fall back to an environment
variable. `encrypt` raises, because silently storing something unreadable is worse than
refusing.

Nothing in this module logs, and no exception it raises carries the secret. That is a
requirement rather than a habit: these messages are shown on a settings page.
"""

from __future__ import annotations

import base64
import hashlib

from django.conf import settings

#: The salt for the key derivation. Not a secret, and not changeable -- see the module
#: docstring. Every value already in the database was encrypted under this string.
SALT = b"outreach.credentials.v1"

#: Iterations for PBKDF2. Raising it would make existing values unreadable, for the
#: same reason as the salt.
ITERATIONS = 200_000


class SecretError(RuntimeError):
    """A secret could not be encrypted or stored.

    Its message is written for whoever is looking at the settings page, and it never
    contains the secret -- callers show `str(exc)` directly.
    """


#: Derived Fernets, keyed by a digest of the secret they came from.
#:
#: The KDF runs 200,000 iterations, and the AI resolver decrypts on every request --
#: deriving the key each time would spend ~100ms of CPU per request to redo work whose
#: only input is a value already in memory. Cached per secret rather than in one slot so
#: `override_settings(SECRET_KEY=...)` still gets its own Fernet, which is what makes
#: the rotated-key tests meaningful.
#:
#: This costs nothing in security: the iteration count exists to slow an attacker who
#: has the database and is guessing at SECRET_KEY, and they get no cache.
_FERNETS: dict[str, object] = {}


def _fernet():
    """A Fernet built from DJANGO_SECRET_KEY."""
    try:
        from cryptography.fernet import Fernet
    except ImportError as exc:   # pragma: no cover - dependency is pinned
        raise SecretError(
            "Storing credentials needs the 'cryptography' package. Run "
            "`pip install cryptography`, or keep using .env variables."
        ) from exc

    secret = (getattr(settings, "SECRET_KEY", "") or "").encode()
    if not secret:
        raise SecretError(
            "DJANGO_SECRET_KEY is not set, so credentials cannot be encrypted. "
            "Set it before saving credentials, or keep using .env variables."
        )
    cache_key = hashlib.sha256(SALT + b"|" + secret).hexdigest()
    if cache_key not in _FERNETS:
        digest = hashlib.pbkdf2_hmac("sha256", secret, SALT, ITERATIONS, dklen=32)
        _FERNETS[cache_key] = Fernet(base64.urlsafe_b64encode(digest))
    return _FERNETS[cache_key]


def encrypt(value: str) -> str:
    """Encrypt one secret for storage. Returns url-safe base64 text."""
    if not (value or "").strip():
        raise SecretError("There is no credential to encrypt.")
    return _fernet().encrypt(value.strip().encode()).decode()


def decrypt(token: str) -> str:
    """Decrypt a stored secret, or "" if it cannot be read.

    An unreadable value is almost always a rotated DJANGO_SECRET_KEY. Returning "" lets
    the caller fall back to the environment instead of failing a run.
    """
    if not token:
        return ""
    try:
        return _fernet().decrypt(token.encode()).decode()
    except SecretError:
        raise
    except Exception:   # noqa: BLE001 - InvalidToken and anything like it
        return ""


#: Prefixes worth keeping visible, longest-first within each family.
#:
#: The order is load-bearing: `sk-` would shadow `sk-ant-`, `sk-or-` and `sk-proj-` if
#: it came first, and the point of showing a prefix is to tell two keys apart.
#: `sb_publishable_` and `sb_secret_` are Supabase's, added when the database settings
#: page started storing them.
KNOWN_PREFIXES = ("sk-ant-", "sk-or-", "sk-proj-", "gsk_", "sk-", "AIza",
                  "sb_publishable_", "sb_secret_")


def mask(value: str) -> str:
    """A safe hint: shape and last four characters, never the secret.

    `sk-ant-api03-abc...WXYZ` becomes `sk-ant-••••••••WXYZ`. Short values are masked
    entirely rather than half-revealed -- four characters out of eight is most of a
    short secret.
    """
    text = (value or "").strip()
    if not text:
        return ""
    if len(text) <= 8:
        return "•" * len(text)

    prefix = ""
    for known_prefix in KNOWN_PREFIXES:
        if text.startswith(known_prefix):
            prefix = known_prefix
            break
    return f"{prefix}{'•' * 8}{text[-4:]}"
