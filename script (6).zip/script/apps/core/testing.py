"""
Shared test scaffolding for a signed-in application.

Every page and endpoint now requires a session, so a test that drives
`self.client` needs one. `SignedIn` provides it by hooking `_pre_setup`, which
Django calls before `setUp` on every test regardless of whether the subclass
overrides `setUp` -- doing it in `setUp` would silently skip any class that
defines its own without calling `super()`.

`default_user()` is what ties the two halves together: the factories in
`tests.py` use it for `owner`, and it returns the user `SignedIn` just created.
So a campaign built inside a test belongs to the account driving the client, and
ownership filtering behaves as it does in the real application instead of hiding
the fixture from the test that made it.
"""

from __future__ import annotations

from django.contrib.auth import get_user_model
from django.test import TestCase

PASSWORD = "test-account-password-42"


def make_user(email: str = "owner@agency.test", name: str = "Test Owner"):
    """An account, created once per email."""
    User = get_user_model()
    existing = User.objects.filter(email__iexact=email).first()
    if existing is not None:
        return existing
    return User.objects.create_user(
        username=email, email=email, password=PASSWORD, first_name=name)


def default_user():
    """The account fixtures belong to: the first one, or a new one.

    Returning the *first* user rather than creating one per call is what makes
    `make_campaign()` and `SignedIn` agree without every test having to pass an
    owner explicitly.
    """
    User = get_user_model()
    return User.objects.order_by("pk").first() or make_user()


class SignedIn(TestCase):
    """A TestCase whose `self.client` is authenticated as `self.user`."""

    def _pre_setup(self):
        super()._pre_setup()
        self.user = make_user()
        self.client.force_login(self.user)


class OtherUser:
    """A second account and its own client, for authorization tests.

    Used to prove that changing a URL parameter does not cross the boundary:
    build data as `self.user`, then try to reach it as this one.
    """

    def __init__(self, email: str = "intruder@elsewhere.test"):
        from django.test import Client

        self.user = make_user(email, name="Other Person")
        self.client = Client()
        self.client.force_login(self.user)

#: An email body that satisfies the current brief, for test doubles that stand in
#: for the model. One shared constant rather than a different two-word string in
#: every file: the rules it has to satisfy -- length, no corporate wording, a
#: finding explained rather than named, the soft call close -- are checked in code,
#: so a double that ignores them makes its own test fail for reasons that have
#: nothing to do with what the test is about.
#:
#: Roughly 300 words, which is the target `ai.SYSTEM` asks for.
EMAIL_BODY = """Hi there,

I had a look through your website this week. I checked it the way a customer \
would, and also for the business, search and technical side, rather than just how \
it looks.

The first thing I noticed is that there is no obvious way to get in touch from the \
homepage. There is no enquiry link and no phone number on it, so somebody who has \
decided they want to speak to you has to go looking for a way to do it. That is \
usually the moment a visitor gives up.

I also noticed the services page lists what you do without explaining much about \
each one. A visitor can read the name of a service and still not know what is \
included or which one suits them, so they may put off asking rather than get in \
touch.

One more thing worth a look is the page title on the homepage. It does not say \
what the business does or where it is, and that is the line somebody sees in a \
search result before they decide whether to click.

Overall there are a few straightforward changes that could make the site clearer \
for visitors and make the next step more obvious.

If you are open to it, I would be happy to walk you through what I found and how I \
would approach fixing it. Would you be open to a quick call this week?

Sam Rivers"""
