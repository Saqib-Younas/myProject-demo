"""
Small things every app's views need.

`json_body` was written twice before this module existed -- once in `apps/ai/views.py`
and once in `apps/outreach/views/shared.py` -- and the database settings page would have
made three. Both keep their private `_json` name, which is what their call sites use;
the implementation is here, once.

The tolerance is the point of it. Every caller is an endpoint the page's JavaScript posts
to, and a malformed body is a client bug, not a server error. Returning `{}` means the
view's own validation reports "the URL is required" rather than the request dying with a
JSON traceback that says nothing about what the person did wrong.
"""

from __future__ import annotations

import json

from django.http import HttpRequest


def json_body(request: HttpRequest) -> dict:
    """Read a JSON object from the request body, or `{}`.

    `{}` for a malformed body, a non-object body, or no body at all -- a list or a bare
    string would otherwise reach `.get()` and raise an AttributeError somewhere less
    obvious than here.
    """
    try:
        loaded = json.loads(request.body or b"{}")
    except (json.JSONDecodeError, UnicodeDecodeError):
        return {}
    return loaded if isinstance(loaded, dict) else {}
