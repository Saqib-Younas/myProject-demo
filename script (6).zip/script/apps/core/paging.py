"""
Server-side pagination, in one place.

Every list in this application had a hard-coded slice -- `[:50]` on the campaigns
page, `[:100]` on the leads table -- which is worse than no limit at all: the page
loads quickly and silently omits records, so a campaign that ran last month simply
is not there and nothing says so.

The rules, from §6 and §7:

  * 20 per page by default, with 20, 50 and 100 offered;
  * the count comes from the database, so "247 campaigns" is the real number;
  * page links preserve whatever search, filter and sort are already applied --
    losing the filter on page 2 is the bug that makes pagination feel broken;
  * a page number that is out of range or nonsense lands on a real page rather
    than raising.

`page_context()` returns everything a template needs, so no view assembles this by
hand and no two lists disagree about what "next page" means.
"""

from __future__ import annotations

from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator
from django.http import HttpRequest

#: The default, per §7. Deliberately small: these lists carry a row per lead, and
#: the browser renders every one of them.
DEFAULT_PAGE_SIZE = 20

#: What a user may choose. A larger page is a legitimate preference; an unlimited
#: one is how a 5,000-lead account gets a page that never finishes rendering.
PAGE_SIZES = (20, 50, 100)

#: Query parameters that belong to pagination itself and must not be carried into
#: the "keep my filters" querystring twice.
PAGE_PARAMS = ("page",)


def page_size(request: HttpRequest) -> int:
    """The requested page size, clamped to what is offered."""
    raw = (request.GET.get("per_page") or "").strip()
    try:
        wanted = int(raw)
    except (TypeError, ValueError):
        return DEFAULT_PAGE_SIZE
    return wanted if wanted in PAGE_SIZES else DEFAULT_PAGE_SIZE


def paginate(request: HttpRequest, queryset, *, size: int | None = None):
    """(page, paginator). Never raises for a bad page number.

    A queryset rather than a list: the point is that the database does the
    limiting. Passing a list still works -- Paginator accepts one -- but the count
    will have loaded everything, which is the thing being avoided.
    """
    paginator = Paginator(queryset, size or page_size(request))
    requested = request.GET.get("page")
    try:
        return paginator.page(requested), paginator
    except PageNotAnInteger:
        return paginator.page(1), paginator
    except EmptyPage:
        # Past the end: the last page, not an error. A stale bookmark after rows
        # were deleted should show something rather than a traceback.
        return paginator.page(paginator.num_pages), paginator


def preserved_query(request: HttpRequest, *, drop=PAGE_PARAMS) -> str:
    """The current query string without the pagination parameters.

    What makes page 2 keep the search box and the filter chips. Returned with a
    trailing `&` when non-empty so a template can write `?{{ query }}page=3`.
    """
    params = request.GET.copy()
    for name in drop:
        params.pop(name, None)
    encoded = params.urlencode()
    return f"{encoded}&" if encoded else ""


def window(page, paginator, *, span: int = 2) -> list:
    """The page numbers to show: first, last, and a window around the current one.

    `None` marks a gap, which the template renders as an ellipsis. Without this a
    250-page list prints 250 links.
    """
    current = page.number
    total = paginator.num_pages
    if total <= 1:
        return [1] if total else []

    wanted = {1, total}
    wanted.update(range(max(1, current - span), min(total, current + span) + 1))

    numbers: list = []
    previous = 0
    for number in sorted(wanted):
        if previous and number - previous > 1:
            numbers.append(None)
        numbers.append(number)
        previous = number
    return numbers


def page_context(request: HttpRequest, queryset, *, size: int | None = None,
                 label: str = "records") -> dict:
    """Everything a template needs to render one paginated list.

    `rows` is the page's objects, so a view can hand this straight to a template
    and iterate `rows` exactly as it iterated the old unbounded list.
    """
    page, paginator = paginate(request, queryset, size=size)
    total = paginator.count

    return {
        "rows": page.object_list,
        "page": page,
        "paginator": paginator,
        "page_numbers": window(page, paginator),
        "per_page": paginator.per_page,
        "page_sizes": PAGE_SIZES,
        "total": total,
        "label": label,
        # "Showing 21-40 of 247 campaigns". Computed here because an off-by-one in
        # a template is invisible until somebody counts.
        "first_index": page.start_index() if total else 0,
        "last_index": page.end_index() if total else 0,
        "summary": (
            f"Showing {page.start_index()}–{page.end_index()} of "
            f"{total} {label}" if total else f"No {label} yet"
        ),
        "query": preserved_query(request),
        "has_other_pages": page.has_other_pages(),
    }
