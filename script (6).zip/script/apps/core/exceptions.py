"""
The base every error a user might read inherits from.

This project has a habit worth naming: when something goes wrong that a person needs
to act on -- a refused login, an unusable API key, a website that cannot be crawled, a
suppressed address -- the exception carries a *sentence written for that person*, and
the view shows it unchanged. That is why `str(exc)` is displayed all over this
codebase without embarrassment.

`UserFacingError` is that promise, made explicit. Inheriting from it says:

  * the message is written for a user, not for a log;
  * it names what happened and, where there is one, what to do about it;
  * it contains nothing secret -- no key, no password, no provider response body.

It deliberately adds no behaviour. An exception hierarchy that does things is a
hierarchy people have to learn; this one only records an intention, and the value is
that a reader can tell at a glance which errors are safe to show.

Errors that are *not* user-facing -- a programming mistake, a broken invariant -- stay
as plain `RuntimeError`, `ValueError` or `AssertionError`, and the view turns them into
a 500 rather than a message.
"""

from __future__ import annotations


class UserFacingError(Exception):
    """An error whose message may be shown to the person who caused it."""
