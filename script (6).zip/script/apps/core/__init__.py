"""Shared kernel: no domain logic, and no dependency on any app."""
