"""
Turn a `DATABASE_URL` into a Django database configuration.

Twenty lines rather than a dependency, because the shape of the problem is small
and the failure modes are specific to what this project connects to. Supabase in
particular has two connection strings and they behave differently:

  * the **pooled** one (port 6543, `...pooler.supabase.com`), which is what a web
    application should use -- Postgres allocates a backend process per connection
    and a pooler is what stops a handful of threads exhausting them;
  * the **direct** one (port 5432, `db.<ref>.supabase.co`), which is what
    migrations want, because the pooler runs in transaction mode and cannot hold
    the session state some DDL needs.

So this parser does not silently normalise a URL. It reports what it was given and
leaves the choice with whoever wrote it, and `describe()` exists so a management
command can print which one is in play before it does anything irreversible.

TLS is the one thing it does insist on: Supabase is reached over the public
internet, and a Postgres connection carries the row data of every lead this
application has ever contacted. `sslmode=require` is added unless the URL sets it.
"""

from __future__ import annotations

from urllib.parse import parse_qsl, unquote, urlparse

#: Schemes that mean Postgres, and the Django backend for them.
POSTGRES_SCHEMES = ("postgres", "postgresql", "postgis")
POSTGRES_BACKEND = "django.db.backends.postgresql"
SQLITE_SCHEMES = ("sqlite", "sqlite3")
SQLITE_BACKEND = "django.db.backends.sqlite3"

#: Supabase's pooled host. Recognised so `describe()` can say which port is which.
POOLER_MARKER = "pooler.supabase.com"
POOLED_PORT = 6543
DIRECT_PORT = 5432


class DatabaseUrlError(ValueError):
    """The URL cannot be turned into a connection. Never contains the password."""


def parse(url: str, *, conn_max_age: int = 600) -> dict:
    """A Django DATABASES entry from a connection URL.

    `conn_max_age` keeps connections open between requests, which matters more
    here than usual: every page in this application is server-rendered, and
    opening a TLS connection to a hosted Postgres per request would be most of
    the response time.
    """
    url = (url or "").strip()
    if not url:
        raise DatabaseUrlError("DATABASE_URL is empty.")

    parts = urlparse(url)
    scheme = parts.scheme.lower().split("+")[0]

    if scheme in SQLITE_SCHEMES:
        return {
            "ENGINE": SQLITE_BACKEND,
            "NAME": _sqlite_path(parts.path or ""),
            "OPTIONS": {"timeout": 20},
        }

    if scheme not in POSTGRES_SCHEMES:
        raise DatabaseUrlError(
            f"Unsupported DATABASE_URL scheme {scheme!r}. Use postgresql:// for "
            "Supabase, or leave DATABASE_URL unset to keep SQLite."
        )

    name = unquote(parts.path or "").lstrip("/")
    if not name:
        raise DatabaseUrlError(
            "DATABASE_URL has no database name. A Supabase URI ends in "
            "`/postgres` -- copy it whole from Project Settings -> Database."
        )
    if not parts.hostname:
        raise DatabaseUrlError("DATABASE_URL has no host.")

    options = dict(parse_qsl(parts.query))
    # TLS unless the URL deliberately says otherwise. The alternative is sending
    # every lead's contact details across the internet in the clear.
    options.setdefault("sslmode", "require")

    config = {
        "ENGINE": POSTGRES_BACKEND,
        "NAME": name,
        "USER": unquote(parts.username or ""),
        "PASSWORD": unquote(parts.password or ""),
        "HOST": parts.hostname,
        "PORT": str(parts.port or DIRECT_PORT),
        "CONN_MAX_AGE": conn_max_age,
        "OPTIONS": options,
    }
    return config


def _sqlite_path(raw: str) -> str:
    """The file a sqlite:// URL points at.

        sqlite:///relative/path.db   -> relative/path.db
        sqlite:////absolute/path.db  -> /absolute/path.db
        sqlite:///C:/path/file.db    -> C:/path/file.db

    The first two are the convention every tool follows. The third is the reason
    this is a function: urlparse hands back "/C:/path/file.db", and Windows cannot
    open a path with that leading slash.
    """
    path = unquote(raw)
    if path.startswith("//"):
        return path[1:]                      # sqlite://// -> absolute POSIX path
    stripped = path.lstrip("/")
    if len(stripped) > 1 and stripped[1] == ":":
        return stripped                      # a Windows drive letter
    return stripped


def is_postgres(config: dict) -> bool:
    return config.get("ENGINE") == POSTGRES_BACKEND


def describe(config: dict) -> str:
    """A one-line summary with no password in it.

    Printed by the migration commands before they touch anything, because
    "which database am I about to write to" is the question worth being certain
    about, and a masked description is the only safe way to answer it.
    """
    if not is_postgres(config):
        return f"SQLite at {config.get('NAME')}"

    host = config.get("HOST", "")
    port = str(config.get("PORT", ""))
    kind = ""
    if POOLER_MARKER in host:
        kind = (" (pooled -- right for the web app, wrong for migrations)"
                if port == str(POOLED_PORT) else " (pooler host, session mode)")
    elif host.startswith("db.") and host.endswith(".supabase.co"):
        kind = " (direct -- right for migrations)"

    user = config.get("USER") or "?"
    return f"Postgres {config.get('NAME')} on {host}:{port} as {user}{kind}"


def pooled(config: dict) -> bool:
    """Is this the transaction-mode pooler?

    Worth knowing before running DDL: the pooler does not keep session state
    between statements, and a migration that depends on it fails in ways that read
    as a Django bug rather than a connection-mode problem.
    """
    return (is_postgres(config)
            and POOLER_MARKER in (config.get("HOST") or "")
            and str(config.get("PORT")) == str(POOLED_PORT))
