"""
Which database this deployment uses, and the state behind that choice.

**Read this first, because the shape of the feature follows from it.** Django's primary
database here is a *direct PostgreSQL connection*, configured by `DATABASE_URL` and
parsed by `apps/core/dburl.py`. Supabase's URL, anon key and service-role key are
PostgREST API credentials. They are not database credentials and they cannot open a
Postgres connection -- the database password lives in `DATABASE_URL`, which is where
`.env.example` has always documented it.

So this module deliberately does *not* pretend that saving three API keys moves the
application onto Supabase. It stores those three, because they are the Supabase
configuration a person has and wants somewhere safe, and it reports the database
connection separately, from the environment variable that actually carries it. A
settings page that implied otherwise would fail at the first request with an
authentication error nobody could explain.

**Where the selection is stored, and why it is not a model.** It is a JSON file in
`DATA_DIR`, mode 0600. It cannot be a database row: the value being stored is *which
database to open*, and reading it from the database would need the answer first. A file
outside the database is the only place the question can be asked.

**No file means "unchanged".** With no selection recorded, the settings module behaves
exactly as it did before this feature existed -- `DATABASE_URL` if set, SQLite
otherwise. That is what makes deploying this change a no-op for a running site: nothing
switches until somebody chooses, and the file only appears when they do.

**A switch takes effect on restart.** `DATABASES` is read once when the process starts,
and Django's connection handling, the session backend, the auth backend and the campaign
worker *threads* all hold connections derived from it. Swapping the default database
under a running process -- one that may have a campaign mid-crawl in a daemon thread --
would be a way to corrupt two databases at once. So `switch()` records the choice and
validates it; the process picks it up next time it starts. The UI says so plainly.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path

from apps.core.exceptions import UserFacingError

#: The two things a deployment can be pointed at.
LOCAL = "local"
SUPABASE = "supabase"
CHOICES = (LOCAL, SUPABASE)

#: The selection file, inside DATA_DIR so it lives in the same volume as the SQLite
#: database and survives a container rebuild.
STATE_FILENAME = "database.json"

#: Environment variables that already carry this configuration. The names are the ones
#: `.env.example` has always used; `SUPABASE_PUBLISHABLE_KEY` is Supabase's current name
#: for what its dashboard used to call the anon key.
ENV_URL = "SUPABASE_URL"
ENV_ANON = "SUPABASE_PUBLISHABLE_KEY"
ENV_SERVICE = "SUPABASE_SECRET_KEY"

#: Supabase project URLs all look like this. Checking the shape is a correctness test
#: and an SSRF defence at once: the URL is submitted through a form and then fetched by
#: the server, so "any URL" would mean "fetch anything reachable from the server",
#: including cloud metadata endpoints. Self-hosted Supabase does not match, which is a
#: documented limitation -- use the environment variables for that.
URL_SUFFIX = ".supabase.co"


class DatabaseSettingsError(UserFacingError):
    """A database setting could not be saved, tested or switched to.

    Its message is shown on the settings page and never carries a key, a password or a
    connection string.
    """


# --------------------------------------------------------------------------- #
# The state file
# --------------------------------------------------------------------------- #

def state_path(data_dir=None) -> Path:
    """Where the selection lives.

    `data_dir` is a parameter so that `config/settings/base.py` can ask for the
    selection while the settings are still being assembled -- at that moment
    `django.conf.settings` is not usable, and a lazy import of it would be a circular
    one.
    """
    if data_dir is None:
        from django.conf import settings as django_settings

        data_dir = getattr(django_settings, "DATA_DIR", ".")
    return Path(data_dir) / STATE_FILENAME


def read_state(data_dir=None) -> dict:
    """The stored state, or an empty dict.

    Tolerant on purpose. A missing file is the ordinary case and means "nothing has been
    chosen". A corrupt one is treated the same way rather than raised: this is read
    while the settings module is being built, and an unparseable file must not be the
    reason a deployment cannot start. The settings page reports it instead.
    """
    path = state_path(data_dir)
    try:
        with path.open(encoding="utf-8") as handle:
            loaded = json.load(handle)
    except (OSError, ValueError):
        return {}
    return loaded if isinstance(loaded, dict) else {}


def write_state(state: dict, data_dir=None) -> None:
    """Replace the state file, readable only by the account that owns it.

    Written to a temporary name and moved into place, so a process reading it never sees
    half a file. `chmod` before the move, so it is never briefly world-readable -- it
    holds an encrypted service-role key, and 0600 is the same posture `.env` gets.
    """
    path = state_path(data_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".json.tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(state, handle, indent=2, sort_keys=True)
    try:
        os.chmod(temporary, 0o600)
    except OSError:      # pragma: no cover - Windows and some mounts do not support it
        pass
    os.replace(temporary, path)


def selection(data_dir=None) -> str:
    """Which database has been chosen, or "" if nobody has chosen.

    "" is not the same as `LOCAL`. It means the settings module should behave exactly as
    it did before this feature existed, which is what keeps deploying it a no-op.
    """
    chosen = read_state(data_dir).get("selection", "")
    return chosen if chosen in CHOICES else ""


# --------------------------------------------------------------------------- #
# What the running process is actually using
# --------------------------------------------------------------------------- #

@dataclass(frozen=True)
class Status:
    """One database's condition, as the page shows it."""

    ready: bool
    summary: str
    detail: str = ""
    #: Set when the answer is "it would work, but only after a restart".
    needs_restart: bool = False


def active() -> str:
    """`LOCAL` or `SUPABASE`, from the connection this process actually has.

    Derived from `settings.DATABASES`, not from the selection file, and the difference
    matters: between a switch and a restart the two disagree, and the page has to be
    able to say so.
    """
    from django.conf import settings as django_settings

    from apps.core import dburl

    config = django_settings.DATABASES.get("default", {})
    return SUPABASE if dburl.is_postgres(config) else LOCAL


def active_description() -> str:
    """A one-line summary of the live connection, with no password in it."""
    from django.conf import settings as django_settings

    from apps.core import dburl

    return dburl.describe(django_settings.DATABASES.get("default", {}))


def pending_restart() -> bool:
    """Has a choice been made that this process has not picked up?"""
    chosen = selection()
    return bool(chosen) and chosen != active()


# --------------------------------------------------------------------------- #
# The Supabase configuration: three fields, and the connection that is not one
# --------------------------------------------------------------------------- #

@dataclass(frozen=True)
class SupabaseConfig:
    """The three fields, as the page may see them.

    Only `url` is a value. The two keys are *presence and a mask* -- the plaintext never
    leaves this module except through `secret_key()` and `anon_key()`, which the
    connection test uses and which no view returns.
    """

    url: str = ""
    anon_masked: str = ""
    service_masked: str = ""
    anon_set: bool = False
    service_set: bool = False
    #: Which of the three came from the environment rather than the settings page. The
    #: page shows this, because an environment value cannot be edited in a browser.
    from_env: list = field(default_factory=list)

    @property
    def complete(self) -> bool:
        return bool(self.url) and self.anon_set and self.service_set


def _stored_secrets(data_dir=None) -> dict:
    return read_state(data_dir).get("supabase", {}) or {}


def _decrypt(token: str) -> str:
    from apps.core import secrets as core_secrets

    try:
        return core_secrets.decrypt(token)
    except core_secrets.SecretError:
        # A rotated DJANGO_SECRET_KEY. The caller falls back to the environment, the
        # same way the AI credential resolver does.
        return ""


def url() -> str:
    """The Supabase project URL: the environment first, then what was saved."""
    return (os.environ.get(ENV_URL, "") or _stored_secrets().get("url", "")).strip()


def anon_key() -> str:
    """The anon/publishable key. Server-side only; never returned by a view."""
    return (os.environ.get(ENV_ANON, "")
            or _decrypt(_stored_secrets().get("anon_key", ""))).strip()


def secret_key() -> str:
    """The service-role key. Server-side only; never returned by a view, never logged.

    The environment wins, for the same reason it does everywhere else here: a value in
    `.env` is the deployment's own statement about itself, and a form should not be able
    to override the file the operator controls.
    """
    return (os.environ.get(ENV_SERVICE, "")
            or _decrypt(_stored_secrets().get("service_key", ""))).strip()


def supabase_config() -> SupabaseConfig:
    """The three fields in the only shape a browser may see them."""
    from apps.core import secrets as core_secrets

    live_url, live_anon, live_service = url(), anon_key(), secret_key()

    from_env = [name for name, value in (
        ("url", os.environ.get(ENV_URL, "")),
        ("anon_key", os.environ.get(ENV_ANON, "")),
        ("service_key", os.environ.get(ENV_SERVICE, "")),
    ) if value.strip()]

    return SupabaseConfig(
        url=live_url,
        # A mask, not the key. `mask` keeps a recognisable prefix and the last four
        # characters, which is enough to tell two keys apart and not enough to use one.
        anon_masked=core_secrets.mask(live_anon),
        service_masked=core_secrets.mask(live_service),
        anon_set=bool(live_anon),
        service_set=bool(live_service),
        from_env=from_env,
    )


def validate_url(raw: str) -> str:
    """The project URL, or a message explaining what is wrong with it."""
    from urllib.parse import urlsplit

    text = (raw or "").strip().rstrip("/")
    if not text:
        raise DatabaseSettingsError("The Supabase URL is required.")

    parts = urlsplit(text)
    if parts.scheme != "https":
        raise DatabaseSettingsError(
            "The Supabase URL must start with https://. Copy it from the Supabase "
            "dashboard under Project Settings → API.")
    if parts.username or parts.password:
        raise DatabaseSettingsError(
            "The Supabase URL must not contain a username or password. It is a "
            "project URL, not a connection string.")
    host = (parts.hostname or "").lower()
    if not host.endswith(URL_SUFFIX) or host == URL_SUFFIX.lstrip("."):
        raise DatabaseSettingsError(
            f"That does not look like a Supabase project URL. It should end in "
            f"{URL_SUFFIX}, for example https://abcdefghijkl{URL_SUFFIX}. A "
            f"self-hosted Supabase has to be configured with the {ENV_URL} "
            f"environment variable instead.")
    if parts.path not in ("", "/"):
        raise DatabaseSettingsError(
            "Give the project URL only, with no path after the hostname.")
    return f"https://{host}"


def save_supabase(raw_url: str, raw_anon: str, raw_service: str, *,
                  data_dir=None) -> SupabaseConfig:
    """Store the three fields. Does not switch anything.

    An empty key means "leave the stored one alone", so the page can be saved after
    editing only the URL without the browser having to send a key back to do it. That is
    the whole reason a key is never returned: there is no round trip to preserve.
    """
    clean_url = validate_url(raw_url)

    state = read_state(data_dir)
    supabase = dict(state.get("supabase", {}) or {})
    supabase["url"] = clean_url

    from apps.core import secrets as core_secrets

    for field_name, raw in (("anon_key", raw_anon), ("service_key", raw_service)):
        value = (raw or "").strip()
        if not value:
            continue
        try:
            supabase[field_name] = core_secrets.encrypt(value)
        except core_secrets.SecretError as exc:
            raise DatabaseSettingsError(str(exc)) from exc

    if not (supabase.get("anon_key") or os.environ.get(ENV_ANON, "").strip()):
        raise DatabaseSettingsError("The anon / public key is required.")
    if not (supabase.get("service_key") or os.environ.get(ENV_SERVICE, "").strip()):
        raise DatabaseSettingsError("The service role / secret key is required.")

    state["supabase"] = supabase
    write_state(state, data_dir)
    return supabase_config()


# --------------------------------------------------------------------------- #
# Is each one usable?
# --------------------------------------------------------------------------- #

def local_status() -> Status:
    """The local database's condition. No credentials are involved, by design.

    "Automatic" is the literal truth here: the local database is one SQLite file whose
    path comes from `DATA_DIR`, and Django creates it on first use. There is no host,
    port, user or password to ask anybody for, so the page asks for none.

    Two failure modes are worth distinguishing, because the advice differs: a directory
    that cannot be written to is an operator problem, and a file that exists but has no
    tables is one `migrate` away.
    """
    from django.conf import settings as django_settings

    path = Path(getattr(django_settings, "DATA_DIR", ".")) / "outreach.sqlite3"

    if not path.parent.is_dir():
        return Status(False, "Not ready",
                      f"The data directory {path.parent} does not exist.")
    if not os.access(path.parent, os.W_OK):
        return Status(False, "Not ready",
                      f"The data directory {path.parent} is not writable, so the "
                      "database file cannot be created.")

    if not path.exists():
        # Not an error. Django creates the file on first connection and `migrate`
        # populates it, so this is a statement about what will happen rather than a
        # problem to solve. It is deliberately not created here: this function renders
        # a page, and rendering a page should not create a database.
        return Status(True, "Ready",
                      "The database file will be created automatically on first use. "
                      "Run migrations after switching.")

    applied, total = _sqlite_migration_counts(path)
    if applied == 0:
        return Status(True, "Ready",
                      f"The file exists at {path.name} but no migrations have been "
                      "applied yet.")
    if total and applied < total:
        return Status(True, "Ready",
                      f"{applied} of {total} migrations applied. Run "
                      "`manage.py migrate` to bring it up to date.")
    return Status(True, "Ready", f"{path.name}, {applied} migrations applied.")


def _sqlite_migration_counts(path: Path) -> tuple[int, int]:
    """How many migrations the file records, and how many exist on disk.

    Read with `sqlite3` directly rather than through Django, because this file is very
    often *not* the database this process is connected to -- that is the whole point of
    the page -- and adding an alias to `connections` to look at it would be a heavier
    and more surprising thing than opening it read-only for one query.
    """
    import sqlite3

    total = _migrations_on_disk()
    try:
        # `mode=ro` so rendering a page cannot create or alter the file.
        connection = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    except sqlite3.Error:
        return 0, total
    try:
        row = connection.execute(
            "SELECT count(*) FROM sqlite_master "
            "WHERE type='table' AND name='django_migrations'").fetchone()
        if not row or not row[0]:
            return 0, total
        applied = connection.execute(
            "SELECT count(*) FROM django_migrations").fetchone()
        return (applied[0] if applied else 0), total
    except sqlite3.Error:
        return 0, total
    finally:
        connection.close()


def _migrations_on_disk() -> int:
    """Every migration this checkout has, across every app."""
    from django.db.migrations.loader import MigrationLoader

    try:
        loader = MigrationLoader(None, ignore_no_migrations=True)
        return len(loader.disk_migrations)
    except Exception:   # noqa: BLE001 - a broken graph is not this page's problem
        return 0


def database_url_present() -> bool:
    """Is the one thing that actually moves the application onto Postgres set?"""
    return bool(os.environ.get("DATABASE_URL", "").strip())


def supabase_status() -> Status:
    """Whether a switch to Supabase could succeed, without attempting it.

    Two independent requirements, kept apart because they fail for different reasons and
    are fixed in different places:

      * the three API credentials, which this page can store;
      * `DATABASE_URL`, which it cannot -- that is the Postgres connection string, it
        contains the database password, and it belongs in the environment.
    """
    config = supabase_config()
    missing = []
    if not config.url:
        missing.append("the project URL")
    if not config.anon_set:
        missing.append("the anon / public key")
    if not config.service_set:
        missing.append("the service role / secret key")

    if not database_url_present():
        return Status(
            False, "Not configured",
            "DATABASE_URL is not set. Supabase's API keys cannot open a Postgres "
            "connection -- Django connects to the database directly, and the "
            "connection string carries the database password. Set DATABASE_URL in the "
            "environment (Supabase dashboard, Project Settings, Database, Connection "
            "string, URI), then this page can switch to it."
            + (f" Also still needed here: {', '.join(missing)}." if missing else ""))

    if missing:
        return Status(False, "Incomplete",
                      "DATABASE_URL is set, so the database connection is ready. Still "
                      f"needed on this page: {', '.join(missing)}.")

    if active() == SUPABASE:
        return Status(True, "Connected", active_description())
    return Status(True, "Ready", "Configured, and not currently in use.",
                  needs_restart=True)


# --------------------------------------------------------------------------- #
# The connection test
# --------------------------------------------------------------------------- #

@dataclass(frozen=True)
class TestResult:
    """What one connection test found. `ok` is the only thing the button colours on."""

    ok: bool
    message: str
    #: One line per thing tested, safe to show. Never a key, never a connection string.
    lines: list = field(default_factory=list)


def test_supabase(*, timeout: float = 10.0) -> TestResult:
    """Test both halves, and say which one failed.

    The Postgres connection is the one that decides whether a switch can work. The REST
    ping is what tells you the three keys on this page are the right ones. Reporting them
    together, separately labelled, is the difference between "connection failed" and an
    answer somebody can act on.

    Nothing here is logged, and no message contains a key, a password or a connection
    string: driver errors are matched against known shapes and replaced with a sentence,
    because a psycopg or requests error can quote the DSN it was handed.
    """
    lines: list[str] = []

    postgres = _test_postgres(timeout=timeout)
    lines.append(postgres)
    rest = _test_rest(timeout=timeout)
    lines.append(rest)

    ok = postgres.startswith("OK") and rest.startswith("OK")
    return TestResult(
        ok=ok,
        message=("Supabase connection successful" if ok else "Connection failed"),
        lines=lines,
    )


def _test_postgres(*, timeout: float) -> str:
    """Open the configured Postgres connection, run one statement, close it."""
    if not database_url_present():
        return ("FAIL Postgres: DATABASE_URL is not set, so there is no database "
                "connection to test.")

    from apps.core import dburl

    try:
        config = dburl.parse(os.environ["DATABASE_URL"])
    except dburl.DatabaseUrlError as exc:
        # Written by our own parser, and documented to carry no password.
        return f"FAIL Postgres: {exc}"

    if not dburl.is_postgres(config):
        return ("FAIL Postgres: DATABASE_URL does not point at Postgres, so it cannot "
                "be a Supabase connection.")

    try:
        import psycopg
    except ImportError:      # pragma: no cover - psycopg is in base.txt
        return "FAIL Postgres: the 'psycopg' package is not installed."

    try:
        connection = psycopg.connect(
            host=config.get("HOST") or "",
            port=int(config.get("PORT") or 5432),
            dbname=config.get("NAME") or "",
            user=config.get("USER") or "",
            password=config.get("PASSWORD") or "",
            sslmode=(config.get("OPTIONS") or {}).get("sslmode", "require"),
            connect_timeout=int(timeout),
        )
    except Exception as exc:   # noqa: BLE001 - psycopg raises a family of these
        return f"FAIL Postgres: {_safe_postgres_error(exc)}"

    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            cursor.fetchone()
            cursor.execute(
                "SELECT count(*) FROM information_schema.tables WHERE "
                "table_schema = 'public' AND table_name = 'django_migrations'")
            has_schema = bool((cursor.fetchone() or [0])[0])
            applied = 0
            if has_schema:
                cursor.execute("SELECT count(*) FROM django_migrations")
                applied = (cursor.fetchone() or [0])[0]
    except Exception as exc:   # noqa: BLE001
        return f"FAIL Postgres: {_safe_postgres_error(exc)}"
    finally:
        connection.close()

    where = dburl.describe(config)
    if not has_schema:
        return (f"OK Postgres: connected to {where}, but the schema is not there yet "
                "-- run `manage.py migrate` before switching.")
    total = _migrations_on_disk()
    if total and applied < total:
        return (f"OK Postgres: connected to {where}. {applied} of {total} migrations "
                "applied -- run `manage.py migrate` before switching.")
    return f"OK Postgres: connected to {where}, schema up to date."


#: Driver errors, matched to a sentence. A psycopg error can quote the whole DSN
#: including the password, so nothing from the driver is passed through verbatim.
_POSTGRES_HINTS = (
    ("password authentication failed",
     "the database password in DATABASE_URL was rejected."),
    ("could not translate host name",
     "the database host in DATABASE_URL could not be resolved."),
    ("timeout expired",
     "the connection timed out. Check the host and port, and that the network allows "
     "outbound Postgres."),
    ("connection refused",
     "the connection was refused. Check the port: 6543 is the pooler, 5432 is direct."),
    ("tenant or user not found",
     "the pooler did not recognise the username. Supabase's pooled username includes "
     "the project reference, as postgres.PROJECT-REF."),
    ("no pg_hba.conf entry",
     "the server refused the connection's SSL or host settings."),
    ("does not exist", "the database named in DATABASE_URL does not exist."),
)


def _safe_postgres_error(exc: Exception) -> str:
    """A sentence a person can act on, with nothing sensitive in it."""
    text = str(exc).lower()
    for marker, sentence in _POSTGRES_HINTS:
        if marker in text:
            return sentence
    # Deliberately not `str(exc)`: an unrecognised driver error may quote the DSN.
    return (f"the connection failed ({type(exc).__name__}). Check DATABASE_URL, and "
            "the server log for the detail.")


def _test_rest(*, timeout: float) -> str:
    """Ping the PostgREST endpoint with the anon key, then with the service key."""
    project = url()
    if not project:
        return "FAIL Supabase API: the project URL is not set."

    try:
        project = validate_url(project)
    except DatabaseSettingsError as exc:
        return f"FAIL Supabase API: {exc}"

    anon, service = anon_key(), secret_key()
    if not anon:
        return "FAIL Supabase API: the anon / public key is not set."
    if not service:
        return "FAIL Supabase API: the service role / secret key is not set."

    import requests

    endpoint = f"{project}/rest/v1/"
    for label_text, key in (("anon / public", anon), ("service role", service)):
        try:
            response = requests.get(
                endpoint,
                headers={"apikey": key, "Authorization": f"Bearer {key}"},
                timeout=timeout,
                # The URL is validated to a .supabase.co host above, and a redirect off
                # it is refused rather than followed: this request carries a
                # service-role key in a header and must not hand it to another host.
                allow_redirects=False,
            )
        except requests.RequestException as exc:
            return (f"FAIL Supabase API: could not reach the project "
                    f"({type(exc).__name__}). Check the URL and the network.")

        if response.status_code in (301, 302, 303, 307, 308):
            return ("FAIL Supabase API: the project URL redirected elsewhere, so the "
                    "request was abandoned rather than sending a key to another host.")
        if response.status_code in (401, 403):
            return (f"FAIL Supabase API: the {label_text} key was rejected. Copy it "
                    "again from Project Settings, API.")
        if response.status_code >= 500:
            return (f"FAIL Supabase API: the project answered {response.status_code}. "
                    "That is Supabase's end, not this configuration.")
        if response.status_code >= 400:
            return (f"FAIL Supabase API: the {label_text} key was not accepted "
                    f"({response.status_code}).")

    return "OK Supabase API: the project URL and both keys were accepted."


def test_local() -> TestResult:
    """Check the local database without writing to it."""
    status = local_status()
    return TestResult(
        ok=status.ready,
        message=("Local database is ready" if status.ready
                 else "Local database is not ready"),
        lines=[f"{'OK' if status.ready else 'WARN'} {status.detail or status.summary}"],
    )


# --------------------------------------------------------------------------- #
# Switching
# --------------------------------------------------------------------------- #

def switch(target: str, *, data_dir=None) -> Status:
    """Record which database to use, after checking that it could work.

    Validation first, and a failure changes nothing: the file is written only once the
    target has been shown to be configured and reachable. That is the rule the brief
    asks for, and it is also the only safe order -- a recorded selection that cannot be
    opened would leave the next restart unable to serve at all.

    Nothing is copied, migrated or deleted here. Moving data between the two is
    `manage.py db_transfer`, which is a separate, explicit, reversible operation.
    """
    if target not in CHOICES:
        raise DatabaseSettingsError(
            f"{target!r} is not a database this application knows about.")

    if target == SUPABASE:
        status = supabase_status()
        if not status.ready:
            raise DatabaseSettingsError(status.detail or status.summary)
        result = test_supabase()
        if not result.ok:
            raise DatabaseSettingsError(
                "Supabase is not reachable with this configuration, so nothing was "
                "changed. " + " ".join(result.lines))
    else:
        status = local_status()
        if not status.ready:
            raise DatabaseSettingsError(status.detail or status.summary)

    state = read_state(data_dir)
    already = state.get("selection") == target
    if not already:
        state["selection"] = target
        write_state(state, data_dir)

    running = active()
    if target == running:
        return Status(True, "Selected",
                      f"{label(target)} is the selection, and this process is already "
                      "connected to it.")
    return Status(
        True, "Selected",
        f"{label(target)} will be used from the next restart. Nothing has been copied, "
        f"moved or deleted, and this process is still connected to {label(running)}.",
        needs_restart=True)


def label(name: str) -> str:
    """The name as the page writes it."""
    return {LOCAL: "Local Database", SUPABASE: "Supabase"}.get(name, name)
