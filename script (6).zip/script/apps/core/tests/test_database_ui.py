"""
Settings → Database, through a browser.

Two groups of tests carry most of the weight here.

**The service-role key must not come back.** Not in the page, not in any JSON response,
not in a log line, not in an error message. There is no endpoint that returns it, and
these tests assert that against every response the five endpoints can produce -- including
the failure paths, which is where a secret usually escapes, in a message assembled from
whatever went wrong.

**Only staff may look.** Which database everybody's data is in is not a per-user setting,
so an ordinary signed-in account gets 403 from all five endpoints, not just the ones that
write.
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
from pathlib import Path
from unittest import mock

from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings
from django.urls import reverse

from apps.core import database
from apps.core.tests.test_database import FakeConnection

PASSWORD = "database-page-password-42"

URL = "https://abcdefgh.supabase.co"
ANON = "sb_publishable_anonanonanonanonanon"
SERVICE = "sb_secret_serviceserviceservicexyz"
DSN = ("postgresql://postgres.abcdefgh:hunter2@aws-0-eu-west-2.pooler.supabase.com"
       ":6543/postgres")


class DatabasePage(TestCase):
    """A staff account, a temporary DATA_DIR, and a clean environment."""

    def setUp(self):
        model = get_user_model()
        self.staff = model.objects.create_user(
            "boss", "boss@agency.test", PASSWORD, is_staff=True)
        self.plain = model.objects.create_user(
            "bob", "bob@agency.test", PASSWORD)

        self._tmp = tempfile.TemporaryDirectory()
        self.data_dir = Path(self._tmp.name)
        self.addCleanup(self._tmp.cleanup)
        patcher = override_settings(DATA_DIR=self.data_dir)
        patcher.enable()
        self.addCleanup(patcher.disable)

        env = mock.patch.dict(os.environ, {}, clear=False)
        env.start()
        self.addCleanup(env.stop)
        for name in (database.ENV_URL, database.ENV_ANON, database.ENV_SERVICE,
                     "DATABASE_URL"):
            os.environ.pop(name, None)

        self.client.force_login(self.staff)

    # --- helpers ---------------------------------------------------------- #

    def post(self, name, body=None):
        """POST JSON, the way the page's JavaScript does."""
        return self.client.post(reverse(name), data=json.dumps(body or {}),
                                content_type="application/json")

    def configure(self):
        database.save_supabase(URL, ANON, SERVICE, data_dir=self.data_dir)

    def working(self):
        """Both halves of the connection test passing."""
        return (mock.patch("psycopg.connect", return_value=FakeConnection()),
                mock.patch("requests.get", return_value=mock.Mock(status_code=200)))


# --------------------------------------------------------------------------- #
# The page
# --------------------------------------------------------------------------- #

class PageTests(DatabasePage):
    def test_the_page_shows_the_active_database(self):
        response = self.client.get(reverse("core:database"))
        self.assertEqual(response.status_code, 200)
        body = response.content.decode()
        self.assertIn("Active database", body)
        # The suite runs on SQLite, so this is the local database.
        self.assertIn("Local Database", body)

    def test_it_offers_exactly_two_choices(self):
        body = self.client.get(reverse("core:database")).content.decode()
        self.assertEqual(body.count('class="provider-row db-pick'), 2)
        self.assertIn('data-target="local"', body)
        self.assertIn('data-target="supabase"', body)

    def test_the_supabase_section_has_exactly_three_fields(self):
        """The brief's central UI requirement.

        Three inputs, and no fourth. A host, a port, a database name or a Postgres
        username appearing here would mean somebody had decided to ask for database
        credentials in a browser form.
        """
        body = self.client.get(reverse("core:database")).content.decode()
        section = body.split('id="db-supabase"', 1)[1].split("</section>", 1)[0]
        self.assertEqual(section.count("<input"), 3)
        for expected in ('id="db-url"', 'id="db-anon"', 'id="db-service"'):
            self.assertIn(expected, section)

    def test_the_supabase_section_asks_for_no_postgres_credentials(self):
        body = self.client.get(reverse("core:database")).content.decode()
        section = body.split('id="db-supabase"', 1)[1].split("</section>", 1)[0]
        for forbidden in ('name="host"', 'name="port"', 'name="dbname"',
                          'name="db_name"', 'name="username"', 'name="password"',
                          'name="connection_string"', 'name="dsn"'):
            self.assertNotIn(forbidden, section)

    def test_the_local_section_asks_for_nothing_at_all(self):
        """No host, user or password field -- and no input of any kind."""
        body = self.client.get(reverse("core:database")).content.decode()
        section = body.split('id="db-local"', 1)[1].split("</section>", 1)[0]
        self.assertNotIn("<input", section)
        self.assertIn("automatically configured", section)
        self.assertIn("Automatic", section)
        self.assertIn("None required", section)

    def test_the_local_section_offers_both_buttons(self):
        body = self.client.get(reverse("core:database")).content.decode()
        self.assertIn('id="db-use-local"', body)
        self.assertIn('id="db-check-local"', body)
        self.assertIn("Use Local Database", body)
        self.assertIn("Check Local Database", body)

    def test_the_supabase_section_offers_test_and_save(self):
        body = self.client.get(reverse("core:database")).content.decode()
        self.assertIn("Test Connection", body)
        self.assertIn("Save &amp; Use Supabase", body)

    def test_it_explains_that_database_url_is_what_connects(self):
        """The honest statement, before a failure rather than after one.

        Three API keys cannot open a Postgres connection. A page that implied they
        could would send somebody looking for a bug that is not there.
        """
        body = self.client.get(reverse("core:database")).content.decode()
        self.assertIn("DATABASE_URL", body)
        self.assertIn("connects to Postgres", body)

    def test_a_stored_key_is_shown_only_as_a_mask(self):
        self.configure()
        body = self.client.get(reverse("core:database")).content.decode()
        self.assertNotIn(SERVICE, body)
        self.assertNotIn(ANON, body)
        self.assertIn("•", body)
        self.assertIn(SERVICE[-4:], body)          # the hint, which is four characters

    def test_the_key_inputs_are_empty_even_when_a_key_is_stored(self):
        """No round trip, which is why there is no endpoint that returns a key."""
        self.configure()
        body = self.client.get(reverse("core:database")).content.decode()
        section = body.split('id="db-anon"', 1)[1].split(">", 1)[0]
        self.assertNotIn("value=", section)

    def test_the_settings_page_links_here_for_staff(self):
        body = self.client.get(reverse("outreach:settings")).content.decode()
        self.assertIn(reverse("core:database"), body)
        self.assertIn("Database settings", body)

    def test_the_settings_page_does_not_link_here_for_anybody_else(self):
        self.client.force_login(self.plain)
        body = self.client.get(reverse("outreach:settings")).content.decode()
        self.assertNotIn(reverse("core:database"), body)


# --------------------------------------------------------------------------- #
# Authorization
# --------------------------------------------------------------------------- #

class AuthorizationTests(DatabasePage):
    """Every endpoint, not only the writes."""

    ENDPOINTS = (
        ("core:database", "get"),
        ("core:database_state", "get"),
        ("core:supabase_save", "post"),
        ("core:connection_test", "post"),
        ("core:database_switch", "post"),
    )

    def test_an_ordinary_account_is_refused_everywhere(self):
        self.client.force_login(self.plain)
        for name, method in self.ENDPOINTS:
            with self.subTest(endpoint=name):
                response = (self.client.get(reverse(name)) if method == "get"
                            else self.post(name, {"target": "local"}))
                self.assertEqual(response.status_code, 403)

    def test_a_signed_out_visitor_is_refused_everywhere(self):
        self.client.logout()
        for name, method in self.ENDPOINTS:
            with self.subTest(endpoint=name):
                response = (self.client.get(reverse(name)) if method == "get"
                            else self.post(name, {"target": "local"}))
                # LoginRequiredMiddleware redirects; either way it is not served.
                self.assertIn(response.status_code, (302, 403))

    def test_an_ordinary_account_cannot_change_the_selection(self):
        self.client.force_login(self.plain)
        self.post("core:database_switch", {"target": "local"})
        self.assertEqual(database.selection(), "")

    def test_an_ordinary_account_cannot_store_a_key(self):
        self.client.force_login(self.plain)
        self.post("core:supabase_save",
                  {"url": URL, "anon_key": ANON, "service_key": SERVICE})
        self.assertFalse((self.data_dir / database.STATE_FILENAME).exists())

    def test_the_write_endpoints_refuse_a_get(self):
        for name in ("core:supabase_save", "core:connection_test",
                     "core:database_switch"):
            with self.subTest(endpoint=name):
                self.assertEqual(self.client.get(reverse(name)).status_code, 405)


# --------------------------------------------------------------------------- #
# Saving
# --------------------------------------------------------------------------- #

class SaveTests(DatabasePage):
    def test_saving_the_three_fields_works(self):
        # Save & Use: the save succeeds and the switch that follows it is refused,
        # because DATABASE_URL is not set. The keys are stored either way.
        response = self.post("core:supabase_save",
                             {"url": URL, "anon_key": ANON, "service_key": SERVICE})
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["supabase"]["service_set"])
        self.assertEqual(database.secret_key(), SERVICE)

    def test_a_bad_url_is_refused_with_a_readable_message(self):
        response = self.post("core:supabase_save",
                             {"url": "http://evil.example", "anon_key": ANON,
                              "service_key": SERVICE})
        self.assertEqual(response.status_code, 400)
        self.assertIn("https", response.json()["error"])

    def test_a_missing_anon_key_is_refused(self):
        response = self.post("core:supabase_save",
                             {"url": URL, "service_key": SERVICE})
        self.assertEqual(response.status_code, 400)
        self.assertIn("anon", response.json()["error"].lower())

    def test_a_missing_service_key_is_refused(self):
        response = self.post("core:supabase_save", {"url": URL, "anon_key": ANON})
        self.assertEqual(response.status_code, 400)
        self.assertIn("service role", response.json()["error"].lower())

    def test_saving_does_not_switch_the_database(self):
        self.post("core:supabase_save",
                  {"url": URL, "anon_key": ANON, "service_key": SERVICE})
        self.assertEqual(database.active(), database.LOCAL)
        self.assertEqual(database.selection(), "")

    def test_an_empty_body_is_a_readable_error_rather_than_a_crash(self):
        response = self.post("core:supabase_save", {})
        self.assertEqual(response.status_code, 400)
        self.assertIn("required", response.json()["error"])


# --------------------------------------------------------------------------- #
# The service-role key never comes back
# --------------------------------------------------------------------------- #

class SecretLeakTests(DatabasePage):
    """The assertions worth having, run against every response and every log.

    Deliberately exhaustive rather than representative: a secret escapes through the
    path nobody thought about, which is usually a failure message assembled from an
    exception.
    """

    def every_response(self):
        """One response from each endpoint, on both the happy and unhappy paths."""
        yield self.client.get(reverse("core:database"))
        yield self.client.get(reverse("core:database_state"))
        yield self.post("core:supabase_save",
                        {"url": URL, "anon_key": ANON, "service_key": SERVICE})
        yield self.post("core:supabase_save", {"url": "http://bad"})
        yield self.post("core:connection_test", {"target": "local"})
        yield self.post("core:connection_test", {"target": "supabase"})
        yield self.post("core:connection_test", {"target": "nonsense"})
        yield self.post("core:database_switch", {"target": "supabase"})
        yield self.post("core:database_switch", {"target": "local"})
        yield self.post("core:database_switch", {"target": ""})

    def test_no_response_contains_the_service_role_key(self):
        self.configure()
        for response in self.every_response():
            with self.subTest(path=response.request["PATH_INFO"]):
                self.assertNotIn(SERVICE, response.content.decode())

    def test_no_response_contains_the_anon_key(self):
        self.configure()
        for response in self.every_response():
            with self.subTest(path=response.request["PATH_INFO"]):
                self.assertNotIn(ANON, response.content.decode())

    def test_no_response_contains_the_database_password(self):
        os.environ["DATABASE_URL"] = DSN
        self.configure()
        for response in self.every_response():
            with self.subTest(path=response.request["PATH_INFO"]):
                self.assertNotIn("hunter2", response.content.decode())

    def test_the_state_endpoint_carries_no_key_shaped_field(self):
        """Not just "the value is absent" -- there is no field for it."""
        self.configure()
        payload = self.client.get(reverse("core:database_state")).json()
        supabase = payload["supabase"]
        self.assertNotIn("service_key", supabase)
        self.assertNotIn("anon_key", supabase)

        # Every key in the payload, at any depth. A field *named* for a secret must not
        # exist -- as opposed to the word appearing in a sentence, which it does and
        # should: the page explains that the connection string carries the database
        # password, which is why it does not ask for one.
        def keys(node):
            if isinstance(node, dict):
                for name, value in node.items():
                    yield name
                    yield from keys(value)
            elif isinstance(node, list):
                for value in node:
                    yield from keys(value)

        for name in keys(payload):
            self.assertNotIn(name.lower(),
                             ("password", "secret", "service_key", "anon_key",
                              "dsn", "connection_string", "database_url"),
                             f"the state payload has a field called {name!r}")

        self.assertTrue(supabase["service_masked"].startswith("sb_secret_"))

    def test_nothing_is_written_to_a_log(self):
        """Including the URL. A log is copied, shipped and searched by people who have
        no business with the key."""
        os.environ["DATABASE_URL"] = DSN
        self.configure()
        with self.assertLogs(level=logging.DEBUG) as captured:
            # assertLogs fails with nothing captured, so one line is emitted on
            # purpose and the rest of the check is that nothing else joins it.
            logging.getLogger("apps.core.tests").info("probe")
            for _ in self.every_response():
                pass
        blob = "\n".join(captured.output)
        for secret in (SERVICE, ANON, "hunter2"):
            self.assertNotIn(secret, blob)

    def test_a_failing_connection_test_does_not_leak_the_password(self):
        """The dangerous path: a psycopg error can quote the whole DSN."""
        os.environ["DATABASE_URL"] = DSN
        self.configure()
        leaky = Exception("connection to server failed: dsn was "
                          "postgresql://postgres:hunter2@host/db")
        with mock.patch("psycopg.connect", side_effect=leaky), \
                mock.patch("requests.get", return_value=mock.Mock(status_code=200)):
            response = self.post("core:connection_test", {"target": "supabase"})
        body = response.content.decode()
        self.assertNotIn("hunter2", body)
        self.assertFalse(response.json()["ok"])

    def test_the_page_source_contains_no_key(self):
        """Including in a data attribute or an inline script, which is where a value
        ends up when somebody makes the JavaScript "simpler"."""
        self.configure()
        body = self.client.get(reverse("core:database")).content.decode()
        for secret in (SERVICE, ANON):
            self.assertNotIn(secret, body)
        self.assertNotIn("service_key", body.split("<script>")[-1])


# --------------------------------------------------------------------------- #
# Testing and switching, through the endpoints
# --------------------------------------------------------------------------- #

class ConnectionTestEndpointTests(DatabasePage):
    def test_the_local_check_reports_ready(self):
        response = self.post("core:connection_test", {"target": "local"})
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["ok"])

    def test_a_successful_supabase_test_says_so(self):
        os.environ["DATABASE_URL"] = DSN
        self.configure()
        postgres, rest = self.working()
        with postgres, rest:
            response = self.post("core:connection_test", {"target": "supabase"})
        data = response.json()
        self.assertTrue(data["ok"])
        self.assertEqual(data["message"], "Supabase connection successful")

    def test_a_failed_supabase_test_says_connection_failed(self):
        self.configure()          # no DATABASE_URL
        with mock.patch("requests.get", return_value=mock.Mock(status_code=200)):
            response = self.post("core:connection_test", {"target": "supabase"})
        data = response.json()
        self.assertFalse(data["ok"])
        self.assertEqual(data["message"], "Connection failed")
        # 200, not 502: the request worked and the answer is in the body.
        self.assertEqual(response.status_code, 200)

    def test_an_unknown_target_is_refused(self):
        response = self.post("core:connection_test", {"target": "mysql"})
        self.assertEqual(response.status_code, 400)

    def test_a_test_never_changes_the_selection(self):
        os.environ["DATABASE_URL"] = DSN
        self.configure()
        postgres, rest = self.working()
        with postgres, rest:
            self.post("core:connection_test", {"target": "supabase"})
        self.assertEqual(database.selection(), "")


class SwitchEndpointTests(DatabasePage):
    def test_switching_to_local_records_the_choice(self):
        response = self.post("core:database_switch", {"target": "local"})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(database.selection(), database.LOCAL)

    def test_switching_to_an_unconfigured_supabase_is_refused(self):
        response = self.post("core:database_switch", {"target": "supabase"})
        self.assertEqual(response.status_code, 400)
        self.assertIn("DATABASE_URL", response.json()["error"])
        self.assertEqual(database.selection(), "")

    def test_a_refused_switch_leaves_the_active_database_alone(self):
        """The requirement stated three times in the brief."""
        before = database.active()
        self.post("core:database_switch", {"target": "supabase"})
        self.assertEqual(database.active(), before)
        self.assertEqual(database.selection(), "")

    def test_a_refused_switch_leaves_an_earlier_selection_alone(self):
        database.write_state({"selection": database.SUPABASE}, self.data_dir)
        self.post("core:database_switch", {"target": "supabase"})
        self.assertEqual(database.selection(), database.SUPABASE)

    def test_a_successful_switch_reports_that_a_restart_is_needed(self):
        os.environ["DATABASE_URL"] = DSN
        self.configure()
        postgres, rest = self.working()
        with postgres, rest:
            response = self.post("core:database_switch", {"target": "supabase"})
        data = response.json()
        self.assertTrue(data["needs_restart"])
        self.assertIn("restart", data["message"])
        self.assertIn("Nothing has been copied", data["message"])
        # The live connection has not moved, and the payload says so.
        self.assertEqual(data["active"], database.LOCAL)
        self.assertTrue(data["pending_restart"])

    def test_an_empty_target_is_refused(self):
        response = self.post("core:database_switch", {"target": ""})
        self.assertEqual(response.status_code, 400)

    def test_switching_moves_no_data(self):
        """The campaigns, drafts and history in the test database are untouched.

        `switch` writes one JSON file and nothing else, which is the property this
        checks from the outside rather than by reading the source.
        """
        from apps.outreach.models import Campaign

        campaign = Campaign.objects.create(
            owner=self.staff, city="Delft", country="Netherlands",
            category="Restaurants", sender_name="Sam",
            sender_email="sam@agency.test")
        self.post("core:database_switch", {"target": "local"})
        self.assertEqual(Campaign.objects.count(), 1)
        self.assertEqual(Campaign.objects.get().pk, campaign.pk)
