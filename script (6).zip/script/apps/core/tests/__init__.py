"""Tests for the shared, domain-free code.

`apps/core` holds what more than one app needs and no app owns: the pagination helper,
the DATABASE_URL parser, the secret encryption, and the database selection behind
Settings → Database.

The database tests are the substantial ones, and they are careful about one thing above
all: **no test here may change which database the suite itself is using.** Every one of
them points `DATA_DIR` at a temporary directory, so the selection file they write is
theirs and disappears with them. A test that wrote a selection into the real data
directory would be a test that reconfigured the developer's next `runserver`.
"""
