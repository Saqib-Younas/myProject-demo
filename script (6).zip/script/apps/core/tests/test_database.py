"""
The database selection: what it stores, what it refuses, and what it must never do.

The last of those is the reason most of these exist. This feature can point a deployment
at a different database, so the tests that matter most are the negative ones -- that
nothing switches without an explicit action, that a failed check changes nothing, and
that no code path here copies or deletes anybody's data.

Every test runs with `DATA_DIR` pointed at a temporary directory. That is not tidiness:
the selection file lives in `DATA_DIR`, and a test that wrote one into the real directory
would silently reconfigure the next `runserver`.
"""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from unittest import mock

from django.test import SimpleTestCase, override_settings

from apps.core import database, secrets


class TemporaryDataDir(SimpleTestCase):
    """A fresh DATA_DIR per test, so no selection file outlives its test."""

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.data_dir = Path(self._tmp.name)
        patcher = override_settings(DATA_DIR=self.data_dir)
        patcher.enable()
        self.addCleanup(patcher.disable)
        self.addCleanup(self._tmp.cleanup)
        # A clean environment: these variables decide what the module reports, and a
        # developer's own .env must not change the answer.
        env = mock.patch.dict(os.environ, {}, clear=False)
        env.start()
        self.addCleanup(env.stop)
        for name in (database.ENV_URL, database.ENV_ANON, database.ENV_SERVICE,
                     "DATABASE_URL"):
            os.environ.pop(name, None)

    def written(self) -> dict:
        return json.loads((self.data_dir / database.STATE_FILENAME)
                          .read_text(encoding="utf-8"))


# --------------------------------------------------------------------------- #
# Nothing changes on its own
# --------------------------------------------------------------------------- #

class NoAutomaticChangeTests(TemporaryDataDir):
    """The rule the whole feature is subordinate to.

    Deploying this must not move anybody's database. That is only true if "no selection
    recorded" is a distinct state from "local selected", and if the file appears solely
    because somebody pressed a button.
    """

    def test_a_fresh_install_has_no_selection_file(self):
        self.assertFalse((self.data_dir / database.STATE_FILENAME).exists())
        self.assertEqual(database.selection(), "")

    def test_reading_the_state_does_not_create_it(self):
        database.selection()
        database.supabase_config()
        database.local_status()
        database.active()
        self.assertFalse((self.data_dir / database.STATE_FILENAME).exists())

    def test_no_selection_is_not_the_same_as_choosing_local(self):
        """The distinction the settings module depends on.

        With no selection, `DATABASE_URL` is honoured. With "local" recorded, it is
        deliberately ignored. Collapsing the two would mean deploying this feature
        moved every Postgres deployment onto SQLite.
        """
        self.assertEqual(database.selection(), "")
        database.write_state({"selection": database.LOCAL}, self.data_dir)
        self.assertEqual(database.selection(), database.LOCAL)

    def test_a_corrupt_state_file_reads_as_no_selection(self):
        """A truncated write must not stop a deployment from starting."""
        (self.data_dir / database.STATE_FILENAME).write_text("{not json",
                                                             encoding="utf-8")
        self.assertEqual(database.selection(), "")

    def test_an_unknown_selection_reads_as_no_selection(self):
        database.write_state({"selection": "mysql"}, self.data_dir)
        self.assertEqual(database.selection(), "")

    def test_nothing_in_this_module_copies_or_deletes_data(self):
        """A grep with a reason, over code rather than prose.

        `switch` is one function away from being the most destructive button in the
        application. This asserts it does not reach for the tools that would make it so
        -- no transfer command, no `delete`, no `flush`, no `TRUNCATE`, no `DROP`.
        Moving data between the two databases is `manage.py db_transfer`, explicitly and
        separately.

        Docstrings and comments are stripped first, because this module's own
        documentation names `db_transfer` in order to point at it -- and a test that
        cannot tell an executable call from a sentence recommending one is a test that
        forbids explaining yourself.
        """
        import ast
        import io
        import tokenize

        source = Path(database.__file__).read_text(encoding="utf-8")

        # Comments out, via the tokeniser rather than a regex, so a `#` inside a string
        # is not mistaken for one.
        kept = []
        for token in tokenize.generate_tokens(io.StringIO(source).readline):
            if token.type != tokenize.COMMENT:
                kept.append(token)
        code = tokenize.untokenize(kept)

        # Docstrings out, via the AST, for the same reason.
        tree = ast.parse(code)
        for node in ast.walk(tree):
            if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef,
                                 ast.ClassDef)) and ast.get_docstring(node):
                node.body = node.body[1:] or [ast.Pass()]
        code = ast.unparse(ast.fix_missing_locations(tree))

        for forbidden in ("db_transfer", "call_command", "TRUNCATE", "DROP TABLE",
                          ".delete()", "flush("):
            self.assertNotIn(
                forbidden, code,
                f"{forbidden!r} is executed in apps/core/database.py. Switching "
                "database must not move or remove data.")


# --------------------------------------------------------------------------- #
# The local database
# --------------------------------------------------------------------------- #

class LocalDatabaseTests(TemporaryDataDir):
    """Automatic means automatic: no host, no port, no user, no password."""

    def test_it_is_ready_before_the_file_exists(self):
        """Django creates the file on first connection, so a missing one is not an
        error -- and this must not be the code that creates it, because it runs to
        render a page."""
        status = database.local_status()
        self.assertTrue(status.ready)
        self.assertIn("automatically", status.detail)
        self.assertFalse((self.data_dir / "outreach.sqlite3").exists())

    def test_it_reports_the_file_once_it_exists(self):
        import sqlite3

        path = self.data_dir / "outreach.sqlite3"
        connection = sqlite3.connect(path)
        connection.execute("CREATE TABLE django_migrations (id integer primary key)")
        connection.commit()
        connection.close()

        status = database.local_status()
        self.assertTrue(status.ready)
        self.assertIn("outreach.sqlite3", status.detail)

    def test_a_missing_data_directory_is_not_ready(self):
        with override_settings(DATA_DIR=self.data_dir / "nope" / "deeper"):
            status = database.local_status()
        self.assertFalse(status.ready)
        self.assertIn("does not exist", status.detail)

    def test_checking_it_needs_no_credentials(self):
        """The whole point of the local half of the page.

        `local_status` takes no arguments at all: there is no host, port, user or
        password it could be given, which is what lets the UI say "Configuration:
        Automatic" and mean it. The matching claim about the *page* -- that it renders
        no input for any of them -- is asserted in `test_database_ui.py`, where the
        HTML is.
        """
        import inspect

        self.assertEqual(list(inspect.signature(database.local_status).parameters), [])

    def test_no_local_database_credential_is_read_from_anywhere(self):
        """Not from the environment either.

        The local database is a file path derived from DATA_DIR. If this feature ever
        started reading a Postgres user or password to decide the local database's
        condition, "Configuration: Automatic" would have become a lie.
        """
        source = Path(database.__file__).read_text(encoding="utf-8")
        for variable in ("PGUSER", "PGPASSWORD", "PGHOST", "PGPORT",
                         "LOCAL_DB_USER", "LOCAL_DB_PASSWORD"):
            self.assertNotIn(variable, source,
                             f"apps/core/database.py refers to {variable}")

    def test_a_ready_local_database_can_be_switched_to(self):
        status = database.switch(database.LOCAL, data_dir=self.data_dir)
        self.assertTrue(status.ready)
        self.assertEqual(self.written()["selection"], database.LOCAL)

    def test_switching_to_local_does_not_touch_the_database_file(self):
        database.switch(database.LOCAL, data_dir=self.data_dir)
        self.assertFalse((self.data_dir / "outreach.sqlite3").exists())

    def test_the_local_check_reports_ready(self):
        result = database.test_local()
        self.assertTrue(result.ok)
        self.assertIn("ready", result.message.lower())


# --------------------------------------------------------------------------- #
# The Supabase URL
# --------------------------------------------------------------------------- #

class SupabaseUrlTests(TemporaryDataDir):
    """The URL is submitted by a person and then fetched by the server, so what it is
    allowed to be is a security question as much as a correctness one."""

    def test_a_project_url_is_accepted(self):
        self.assertEqual(database.validate_url("https://abcdefgh.supabase.co"),
                         "https://abcdefgh.supabase.co")

    def test_a_trailing_slash_is_removed(self):
        self.assertEqual(database.validate_url("https://abcdefgh.supabase.co/"),
                         "https://abcdefgh.supabase.co")

    def test_an_empty_url_is_refused(self):
        with self.assertRaises(database.DatabaseSettingsError) as caught:
            database.validate_url("")
        self.assertIn("required", str(caught.exception))

    def test_http_is_refused(self):
        with self.assertRaises(database.DatabaseSettingsError) as caught:
            database.validate_url("http://abcdefgh.supabase.co")
        self.assertIn("https", str(caught.exception))

    def test_another_host_is_refused(self):
        with self.assertRaises(database.DatabaseSettingsError):
            database.validate_url("https://evil.example.com")

    def test_a_loopback_address_is_refused(self):
        """The SSRF case. This URL is fetched by the server with a service-role key in
        the headers, so anything that is not a Supabase project has to be refused."""
        for hostile in ("https://127.0.0.1", "https://localhost",
                        "https://169.254.169.254", "https://10.0.0.1",
                        "https://[::1]"):
            with self.subTest(url=hostile):
                with self.assertRaises(database.DatabaseSettingsError):
                    database.validate_url(hostile)

    def test_a_lookalike_host_is_refused(self):
        with self.assertRaises(database.DatabaseSettingsError):
            database.validate_url("https://supabase.co.evil.example")

    def test_credentials_in_the_url_are_refused(self):
        with self.assertRaises(database.DatabaseSettingsError) as caught:
            database.validate_url("https://user:pw@abcdefgh.supabase.co")
        self.assertIn("username or password", str(caught.exception))

    def test_a_path_is_refused(self):
        with self.assertRaises(database.DatabaseSettingsError):
            database.validate_url("https://abcdefgh.supabase.co/rest/v1/secrets")


# --------------------------------------------------------------------------- #
# Saving the three fields
# --------------------------------------------------------------------------- #

class SaveTests(TemporaryDataDir):
    URL = "https://abcdefgh.supabase.co"
    ANON = "sb_publishable_aaaaaaaaaaaaaaaaaaaa"
    SERVICE = "sb_secret_bbbbbbbbbbbbbbbbbbbbbbbb"

    def test_all_three_are_stored(self):
        config = database.save_supabase(self.URL, self.ANON, self.SERVICE,
                                        data_dir=self.data_dir)
        self.assertEqual(config.url, self.URL)
        self.assertTrue(config.anon_set)
        self.assertTrue(config.service_set)
        self.assertTrue(config.complete)

    def test_the_keys_are_encrypted_on_disk(self):
        """Not obfuscated: encrypted, and the plaintext is nowhere in the file."""
        database.save_supabase(self.URL, self.ANON, self.SERVICE,
                               data_dir=self.data_dir)
        raw = (self.data_dir / database.STATE_FILENAME).read_text(encoding="utf-8")
        self.assertNotIn(self.ANON, raw)
        self.assertNotIn(self.SERVICE, raw)
        stored = json.loads(raw)["supabase"]
        self.assertEqual(secrets.decrypt(stored["service_key"]), self.SERVICE)

    def test_a_missing_url_is_refused(self):
        with self.assertRaises(database.DatabaseSettingsError) as caught:
            database.save_supabase("", self.ANON, self.SERVICE,
                                   data_dir=self.data_dir)
        self.assertIn("required", str(caught.exception))

    def test_a_missing_anon_key_is_refused(self):
        with self.assertRaises(database.DatabaseSettingsError) as caught:
            database.save_supabase(self.URL, "", self.SERVICE,
                                   data_dir=self.data_dir)
        self.assertIn("anon", str(caught.exception).lower())

    def test_a_missing_service_key_is_refused(self):
        with self.assertRaises(database.DatabaseSettingsError) as caught:
            database.save_supabase(self.URL, self.ANON, "", data_dir=self.data_dir)
        self.assertIn("service role", str(caught.exception).lower())

    def test_an_empty_key_field_keeps_the_stored_one(self):
        """Which is what lets the URL be corrected without the browser being told a
        key in order to do it -- and therefore why no endpoint returns one."""
        database.save_supabase(self.URL, self.ANON, self.SERVICE,
                               data_dir=self.data_dir)
        database.save_supabase("https://zzzzzzzz.supabase.co", "", "",
                               data_dir=self.data_dir)
        config = database.supabase_config()
        self.assertEqual(config.url, "https://zzzzzzzz.supabase.co")
        self.assertTrue(config.service_set)
        self.assertEqual(database.secret_key(), self.SERVICE)

    def test_saving_does_not_switch_anything(self):
        """"Save" and "use" are separate operations, and only the second is a switch."""
        database.save_supabase(self.URL, self.ANON, self.SERVICE,
                               data_dir=self.data_dir)
        self.assertEqual(database.selection(), "")
        self.assertNotIn("selection", self.written())

    def test_the_environment_wins_over_a_saved_value(self):
        database.save_supabase(self.URL, self.ANON, self.SERVICE,
                               data_dir=self.data_dir)
        os.environ[database.ENV_SERVICE] = "sb_secret_from_the_environment_xxxx"
        self.assertEqual(database.secret_key(),
                         "sb_secret_from_the_environment_xxxx")
        self.assertIn("service_key", database.supabase_config().from_env)

    def test_a_config_carries_masks_and_never_the_key(self):
        database.save_supabase(self.URL, self.ANON, self.SERVICE,
                               data_dir=self.data_dir)
        config = database.supabase_config()
        for value in (config.anon_masked, config.service_masked):
            self.assertIn("•", value)
        self.assertNotIn(self.SERVICE, config.service_masked)
        self.assertNotIn(self.ANON, config.anon_masked)
        # The last four characters are the whole hint, and they are not enough to use.
        self.assertTrue(config.service_masked.endswith(self.SERVICE[-4:]))


# --------------------------------------------------------------------------- #
# Status, and the requirement the three fields cannot satisfy
# --------------------------------------------------------------------------- #

class SupabaseStatusTests(TemporaryDataDir):
    URL = "https://abcdefgh.supabase.co"
    ANON = "sb_publishable_aaaaaaaaaaaaaaaaaaaa"
    SERVICE = "sb_secret_bbbbbbbbbbbbbbbbbbbbbbbb"
    DSN = ("postgresql://postgres.abcdefgh:pw@aws-0-eu-west-2.pooler.supabase.com"
           ":6543/postgres")

    def test_without_database_url_it_is_not_configured(self):
        """The honest answer, and the point of the whole design.

        Three API keys do not make a Postgres connection. Saying so before the switch
        is attempted is the difference between a clear message and an authentication
        error from psycopg that nobody can act on.
        """
        database.save_supabase(self.URL, self.ANON, self.SERVICE,
                               data_dir=self.data_dir)
        status = database.supabase_status()
        self.assertFalse(status.ready)
        self.assertIn("DATABASE_URL", status.detail)
        self.assertIn("cannot open a Postgres connection", status.detail)

    def test_with_database_url_but_no_keys_it_is_incomplete(self):
        os.environ["DATABASE_URL"] = self.DSN
        status = database.supabase_status()
        self.assertFalse(status.ready)
        self.assertIn("Still needed", status.detail)

    def test_with_both_it_is_ready(self):
        os.environ["DATABASE_URL"] = self.DSN
        database.save_supabase(self.URL, self.ANON, self.SERVICE,
                               data_dir=self.data_dir)
        self.assertTrue(database.supabase_status().ready)

    def test_no_status_message_contains_a_key_or_a_password(self):
        os.environ["DATABASE_URL"] = self.DSN
        database.save_supabase(self.URL, self.ANON, self.SERVICE,
                               data_dir=self.data_dir)
        for status in (database.supabase_status(), database.local_status()):
            for secret in (self.SERVICE, self.ANON, "pw"):
                self.assertNotIn(secret, status.detail)
                self.assertNotIn(secret, status.summary)


# --------------------------------------------------------------------------- #
# The connection test
# --------------------------------------------------------------------------- #

class FakeCursor:
    def __init__(self, answers):
        self._answers = list(answers)
        self._last = None

    def execute(self, sql, *args):
        self._last = self._answers.pop(0) if self._answers else (1,)

    def fetchone(self):
        return self._last

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


class FakeConnection:
    """Just enough of a psycopg connection for the test to reach its assertions."""

    def __init__(self, answers=((1,), (1,), (23,))):
        self._answers = answers
        self.closed = False

    def cursor(self):
        return FakeCursor(self._answers)

    def close(self):
        self.closed = True


class ConnectionTestTests(TemporaryDataDir):
    URL = "https://abcdefgh.supabase.co"
    ANON = "sb_publishable_aaaaaaaaaaaaaaaaaaaa"
    SERVICE = "sb_secret_bbbbbbbbbbbbbbbbbbbbbbbb"
    DSN = ("postgresql://postgres.abcdefgh:hunter2@aws-0-eu-west-2.pooler"
           ".supabase.com:6543/postgres")

    def configure(self):
        os.environ["DATABASE_URL"] = self.DSN
        database.save_supabase(self.URL, self.ANON, self.SERVICE,
                               data_dir=self.data_dir)

    def rest_ok(self):
        response = mock.Mock(status_code=200)
        return mock.patch("requests.get", return_value=response)

    def test_a_working_configuration_reports_success(self):
        self.configure()
        with mock.patch("psycopg.connect", return_value=FakeConnection()), \
                self.rest_ok():
            result = database.test_supabase()
        self.assertTrue(result.ok)
        self.assertEqual(result.message, "Supabase connection successful")
        self.assertEqual(len(result.lines), 2)

    def test_without_database_url_the_postgres_half_fails(self):
        database.save_supabase(self.URL, self.ANON, self.SERVICE,
                               data_dir=self.data_dir)
        with self.rest_ok():
            result = database.test_supabase()
        self.assertFalse(result.ok)
        self.assertEqual(result.message, "Connection failed")
        self.assertIn("DATABASE_URL is not set", result.lines[0])

    def test_a_rejected_database_password_is_reported_without_the_password(self):
        self.configure()
        failure = Exception('connection failed: password authentication failed for '
                            'user "postgres.abcdefgh" (dsn: hunter2)')
        with mock.patch("psycopg.connect", side_effect=failure), self.rest_ok():
            result = database.test_supabase()
        self.assertFalse(result.ok)
        joined = " ".join(result.lines)
        self.assertIn("password in DATABASE_URL was rejected", joined)
        self.assertNotIn("hunter2", joined)

    def test_an_unrecognised_driver_error_is_not_passed_through(self):
        """A driver error can quote the DSN, so an unmatched one is replaced entirely
        rather than shown."""
        self.configure()
        with mock.patch("psycopg.connect",
                        side_effect=RuntimeError("boom dsn=hunter2 leak")), \
                self.rest_ok():
            result = database.test_supabase()
        joined = " ".join(result.lines)
        self.assertNotIn("hunter2", joined)
        self.assertIn("RuntimeError", joined)

    def test_a_rejected_api_key_is_reported(self):
        self.configure()
        with mock.patch("psycopg.connect", return_value=FakeConnection()), \
                mock.patch("requests.get", return_value=mock.Mock(status_code=401)):
            result = database.test_supabase()
        self.assertFalse(result.ok)
        self.assertIn("was rejected", result.lines[1])

    def test_a_missing_schema_is_reported_as_such(self):
        """Connected, but nothing has been migrated yet -- which is a different
        problem from a refused connection and gets a different sentence."""
        self.configure()
        connection = FakeConnection(answers=((1,), (0,)))
        with mock.patch("psycopg.connect", return_value=connection), self.rest_ok():
            result = database.test_supabase()
        self.assertIn("schema is not there yet", result.lines[0])

    def test_the_api_test_refuses_to_follow_a_redirect(self):
        """The request carries a service-role key in a header. A redirect is another
        host asking for it, so the request is abandoned instead."""
        self.configure()
        with mock.patch("psycopg.connect", return_value=FakeConnection()), \
                mock.patch("requests.get",
                           return_value=mock.Mock(status_code=302)) as get:
            result = database.test_supabase()
        self.assertFalse(result.ok)
        self.assertIn("redirected elsewhere", result.lines[1])
        self.assertIs(get.call_args.kwargs["allow_redirects"], False)

    def test_no_test_result_contains_a_key(self):
        self.configure()
        with mock.patch("psycopg.connect", return_value=FakeConnection()), \
                self.rest_ok():
            result = database.test_supabase()
        blob = result.message + " ".join(result.lines)
        for secret in (self.SERVICE, self.ANON, "hunter2"):
            self.assertNotIn(secret, blob)


# --------------------------------------------------------------------------- #
# Switching
# --------------------------------------------------------------------------- #

class SwitchTests(TemporaryDataDir):
    URL = "https://abcdefgh.supabase.co"
    ANON = "sb_publishable_aaaaaaaaaaaaaaaaaaaa"
    SERVICE = "sb_secret_bbbbbbbbbbbbbbbbbbbbbbbb"
    DSN = ("postgresql://postgres.abcdefgh:pw@aws-0-eu-west-2.pooler.supabase.com"
           ":6543/postgres")

    def test_an_unknown_target_is_refused(self):
        with self.assertRaises(database.DatabaseSettingsError):
            database.switch("mongodb", data_dir=self.data_dir)
        self.assertFalse((self.data_dir / database.STATE_FILENAME).exists())

    def test_switching_to_an_unconfigured_supabase_changes_nothing(self):
        """The rule from the brief: if validation fails, do not switch."""
        with self.assertRaises(database.DatabaseSettingsError) as caught:
            database.switch(database.SUPABASE, data_dir=self.data_dir)
        self.assertIn("DATABASE_URL", str(caught.exception))
        self.assertEqual(database.selection(), "")

    def test_a_failed_connection_test_changes_nothing(self):
        os.environ["DATABASE_URL"] = self.DSN
        database.save_supabase(self.URL, self.ANON, self.SERVICE,
                               data_dir=self.data_dir)
        with mock.patch("psycopg.connect", side_effect=OSError("no route")):
            with self.assertRaises(database.DatabaseSettingsError):
                database.switch(database.SUPABASE, data_dir=self.data_dir)
        self.assertEqual(database.selection(), "")

    def test_a_failed_switch_leaves_an_earlier_selection_alone(self):
        """The one that would hurt: a deployment already on Supabase must not be
        knocked back to local by a failed attempt to re-select it."""
        database.write_state({"selection": database.SUPABASE}, self.data_dir)
        with self.assertRaises(database.DatabaseSettingsError):
            database.switch(database.SUPABASE, data_dir=self.data_dir)
        self.assertEqual(database.selection(), database.SUPABASE)

    def test_a_successful_switch_records_the_choice(self):
        os.environ["DATABASE_URL"] = self.DSN
        database.save_supabase(self.URL, self.ANON, self.SERVICE,
                               data_dir=self.data_dir)
        with mock.patch("psycopg.connect", return_value=FakeConnection()), \
                mock.patch("requests.get", return_value=mock.Mock(status_code=200)):
            status = database.switch(database.SUPABASE, data_dir=self.data_dir)
        self.assertTrue(status.ready)
        self.assertEqual(database.selection(), database.SUPABASE)

    def test_a_switch_says_it_needs_a_restart(self):
        """`DATABASES` is read once at startup, and campaign work runs in threads
        holding connections from it. The page must not imply otherwise."""
        os.environ["DATABASE_URL"] = self.DSN
        database.save_supabase(self.URL, self.ANON, self.SERVICE,
                               data_dir=self.data_dir)
        with mock.patch("psycopg.connect", return_value=FakeConnection()), \
                mock.patch("requests.get", return_value=mock.Mock(status_code=200)):
            status = database.switch(database.SUPABASE, data_dir=self.data_dir)
        self.assertTrue(status.needs_restart)
        self.assertIn("restart", status.detail)
        self.assertIn("Nothing has been copied", status.detail)

    def test_switching_twice_is_idempotent(self):
        database.switch(database.LOCAL, data_dir=self.data_dir)
        database.switch(database.LOCAL, data_dir=self.data_dir)
        self.assertEqual(database.selection(), database.LOCAL)

    def test_the_selection_and_the_live_connection_can_disagree(self):
        """Between a switch and a restart they must, and the page has to say so."""
        os.environ["DATABASE_URL"] = self.DSN
        database.save_supabase(self.URL, self.ANON, self.SERVICE,
                               data_dir=self.data_dir)
        with mock.patch("psycopg.connect", return_value=FakeConnection()), \
                mock.patch("requests.get", return_value=mock.Mock(status_code=200)):
            database.switch(database.SUPABASE, data_dir=self.data_dir)
        # The suite runs on SQLite, so this process is still local.
        self.assertEqual(database.active(), database.LOCAL)
        self.assertTrue(database.pending_restart())


# --------------------------------------------------------------------------- #
# The state file itself
# --------------------------------------------------------------------------- #

class StateFileTests(TemporaryDataDir):
    def test_it_is_not_world_readable(self):
        """It holds an encrypted service-role key, so it gets `.env`'s posture."""
        database.write_state({"selection": database.LOCAL}, self.data_dir)
        path = self.data_dir / database.STATE_FILENAME
        if os.name == "posix":
            self.assertEqual(path.stat().st_mode & 0o077, 0)
        else:
            # Windows does not carry POSIX mode bits; the call is still made and must
            # not raise, which is what this asserts.
            self.assertTrue(path.exists())

    def test_no_temporary_file_is_left_behind(self):
        database.write_state({"selection": database.LOCAL}, self.data_dir)
        self.assertEqual([p.name for p in self.data_dir.glob("*.tmp")], [])

    def test_it_is_read_from_disk_every_time(self):
        """What makes cron see a switch.

        A cron job is a new process reading the same file. If this were cached in
        module state, `manage.py process_followups` would keep using the database that
        was selected when *its* process started -- which is true, and fine -- but a
        long-running `--loop` worker would never see a change at all. Reading each
        time means the next pass picks it up.
        """
        self.assertEqual(database.selection(), "")
        database.write_state({"selection": database.SUPABASE}, self.data_dir)
        self.assertEqual(database.selection(), database.SUPABASE)
        database.write_state({"selection": database.LOCAL}, self.data_dir)
        self.assertEqual(database.selection(), database.LOCAL)
