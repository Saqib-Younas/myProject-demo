"""
What runs unattended, as plain functions.

There is no Celery here and no Redis. Background work in this project is a management
command on a timer -- cron, a systemd timer, Task Scheduler -- or a daemon thread in the
web process for the supervised `--loop` shapes. That is a deliberate choice: the jobs are
minutes apart, not milliseconds, and a broker is a second thing to run, monitor and
restart for no benefit at this size.

What that choice cost, until this module existed, was a clean way to *call* a job.
Each one lived inside a `BaseCommand`, so the automation runner reached a follow-up by
instantiating a command class and calling an underscore method on it. This module is the
fix: one place that names the three unattended jobs, each a function with a structured
return, callable from a command, from a thread, or from a test without a terminal
anywhere in the picture.

    prepare_followups   every 15 minutes -- draft what is due, send nothing
    run_audits          every few minutes -- work the submitted-URL queue
    check_replies       every 15 minutes -- read the mailbox for replies and bounces

Each one holds no business logic of its own. They select the work, call the service that
knows what to do with it, and hand back what happened; the deciding is one layer down in
`services/`, where it can be tested without pretending to be a background run.

**Nothing here sends an email that a person has not approved.** `prepare_followups`
writes drafts and stops. `run_audits` produces a report and a draft and stops. The only
sending job is a campaign the person configured and started, and that one lives in
`services/automation/runner.py` behind its own set of refusals.
"""

from __future__ import annotations

import logging

from apps.outreach.services import followups as followup_service
from apps.outreach.services import websiteaudit

log = logging.getLogger(__name__)


def prepare_followups(*, owner=None, limit: int = 100,
                      dry_run: bool = False) -> list[followup_service.Outcome]:
    """Draft every follow-up whose window has opened. Send none of them.

    With no `owner`, every account that has ever sent something -- the rest cannot have
    a follow-up due. Returns one `Outcome` per lead considered, so the caller can print
    them, log them, or count them with `followups.counts`.

    Bounded by `limit` per owner on purpose: a backlog is worked through over several
    runs rather than one run that holds a connection open for an hour.

    **Every pass is recorded**, as a `WorkerRun` row. That is what lets the Follow-Ups
    page report the worker's real state instead of asserting one: the row is written
    before any work, so a pass that dies is visible as a run that began and never
    finished, and updated in a `finally` so a crash still reports its totals.

    The recording lives here rather than in the management command because a command is
    not the only caller -- and because a status panel that only knew about cron would go
    blank the moment somebody ran the job by hand.
    """
    from apps.outreach.models import WorkerRun

    run = WorkerRun.begin(WorkerRun.Job.FOLLOWUPS, owner=owner, dry_run=dry_run)
    owners = [owner] if owner is not None else followup_service.owners_with_history()
    outcomes: list[followup_service.Outcome] = []
    try:
        for account in owners:
            for lead in followup_service.due_leads(account, limit):
                outcomes.append(
                    followup_service.prepare_one(account, lead, dry_run=dry_run))
    except Exception as exc:                      # noqa: BLE001 - recorded, then re-raised
        totals = followup_service.counts(outcomes)
        run.finish(ok=False, considered=totals["considered"],
                   succeeded=totals["prepared"], skipped=totals["skipped"],
                   failed=totals["failed"],
                   detail=f"{type(exc).__name__}: {exc}")
        raise
    totals = followup_service.counts(outcomes)
    run.finish(ok=True, considered=totals["considered"],
               succeeded=totals["prepared"], skipped=totals["skipped"],
               failed=totals["failed"])
    return outcomes


def run_audits(*, owner=None, limit: int = 5):
    """Work the website-audit queue: crawl, analyse, draft, stop.

    The queue logic is a service; what this adds is the `WorkerRun` record, so the job
    can be seen to have run. That is the same reason `prepare_followups` above is not a
    one-liner either.

    The submitted-URL workflow never sends by itself, whoever asks. The job leaves a
    finished report and an unsent draft, and a person decides whether it goes.
    """
    from apps.outreach.models import WorkerRun

    run = WorkerRun.begin(WorkerRun.Job.AUDITS, owner=owner)
    try:
        outcomes = websiteaudit.run_pending(owner=owner, limit=limit)
    except Exception as exc:                      # noqa: BLE001 - recorded, then re-raised
        run.finish(ok=False, detail=f"{type(exc).__name__}: {exc}")
        raise
    failed = sum(1 for row in outcomes if getattr(row, "state", "") == "failed")
    run.finish(ok=True, considered=len(outcomes),
               succeeded=len(outcomes) - failed, failed=failed)
    return outcomes


def check_replies(*, owner, password: str, days: int = 14):
    """Read the mailbox and mark the leads who answered.

    Read-only against IMAP. It matters because it is what stops a follow-up going to
    somebody who has already replied, or to an address that bounced.

    The password is a parameter rather than something this function reads from the
    environment: a job that fetches its own credentials is a job that cannot be called
    with a different mailbox, and the caller already knows which one it means. Raises
    `inbox.InboxError` if the mailbox cannot be opened.

    Recorded as a `WorkerRun` like the others -- and this one matters most for the
    Follow-Ups page, because a reply that was never read is a follow-up that will go out
    to somebody who already answered.
    """
    from apps.outreach.mail import inbox
    from apps.outreach.models import WorkerRun

    run = WorkerRun.begin(WorkerRun.Job.REPLIES, owner=owner)
    try:
        result = inbox.check(password=password, owner=owner, days=days)
    except Exception as exc:                      # noqa: BLE001 - recorded, then re-raised
        run.finish(ok=False, detail=f"{type(exc).__name__}: {exc}")
        raise
    run.finish(ok=True,
               considered=getattr(result, "examined", 0),
               succeeded=getattr(result, "matched", 0),
               skipped=getattr(result, "ignored", 0))
    return result
