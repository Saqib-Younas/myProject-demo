"""
A campaign, the leads in it, and the log of what happened.

`Campaign` carries two independent axes and collapsing them would lose information:
`phase` is what the machinery is doing (crawling, generating, sending) and `status` is
what a person decided (active, paused, stopped). A campaign can be paused while its
last send finishes.

`EmailDraft` is the per-lead record and the busiest table in the project: the crawl
output, the findings, the generated email, the scores, the lifecycle stage and the
claim a worker holds on it. It is deliberately one row per lead per campaign rather
than a row per step -- the whole pipeline for one lead is one place to look.
"""

from __future__ import annotations

import uuid

from django.conf import settings
from django.db import models
from django.utils import timezone

#: The per-lead cycle, in order. Every selected lead is taken through all four
#: steps before the next lead is started -- the whole run is sequential, never
#: batched by stage. `Campaign.current_step` holds the one in flight.
LEAD_STEPS = (
    ("crawl", "Website analysed"),
    ("review", "Issues identified"),
    ("generate", "Email generated"),
    ("score", "Scored and classified"),
    ("save", "Result saved"),
)
STEP_KEYS = [key for key, _label in LEAD_STEPS]
def _domain_of(website: str) -> str:
    """The history table's own domain normalisation, borrowed.

    Imported inside the function rather than at the top: `history` is the module
    *below* this one in the package's import order, and reaching up would make the
    two mutually dependent for the sake of one string operation.
    """
    from .history import SentLead

    return SentLead.domain_of(website)


class Campaign(models.Model):
    """One outreach run over a set of scraped leads."""

    class Phase(models.TextChoices):
        SETUP = "setup", "Awaiting sender settings"
        CRAWLING = "crawling", "Discovering and reading websites"
        ANALYSING = "analysing", "Reviewing websites for issues"
        GENERATING = "generating", "Generating emails"
        #: Stopped by the AI provider, not by a failure. The run keeps its place
        #: and picks up from the first unfinished lead when the window passes.
        PAUSED_RATE_LIMIT = "paused_rate_limit", "Paused — AI rate limit"
        #: The user pressed Cancel and a worker is still finishing the lead it
        #: was on. Transient, and the state the worker checks before each lead.
        CANCEL_REQUESTED = "cancel_requested", "Cancelling…"
        CANCELLED = "cancelled", "Processing cancelled"
        REVIEW = "review", "Awaiting review"
        SENDING = "sending", "Sending"
        DONE = "done", "Finished"
        FAILED = "failed", "Failed"

    class Status(models.TextChoices):
        """What the operator has decided about this campaign.

        A second axis alongside `phase`, which says what the machinery is doing.
        A campaign can be ACTIVE and in the `review` phase at once -- it is running
        and currently waiting for a person -- and collapsing the two would lose
        that. Only ACTIVE campaigns send anything, automatically or otherwise.
        """

        DRAFT = "draft", "Draft"
        SCHEDULED = "scheduled", "Scheduled"
        ACTIVE = "active", "Active"
        PAUSED = "paused", "Paused"
        COMPLETED = "completed", "Completed"
        STOPPED = "stopped", "Stopped"
        FAILED = "failed", "Failed"

    class Pause(models.TextChoices):
        """Why a run is paused. The two need opposite handling.

        A per-minute limit is waited out automatically. A spent daily, monthly or
        billing allowance is not: waiting a minute changes nothing, so the run
        stops and says so, and the user waits for the reset or switches provider.
        """

        RATE_LIMIT = "rate_limit", "Rate limit — retrying shortly"
        QUOTA = "quota", "Allowance used up"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)

    #: Who this campaign belongs to. Nullable only so the migration can run
    #: against a database that predates accounts; every new row sets it, and a
    #: row with no owner is visible to nobody -- see `manage.py claim_data`.
    #: EmailDraft ownership is derived from here rather than duplicated, so the
    #: two can never disagree about who a draft belongs to.
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="campaigns", null=True, blank=True, db_index=True,
    )

    # Where the leads came from, carried over from the scrape.
    country = models.CharField(max_length=120, blank=True)
    city = models.CharField(max_length=120, blank=True)
    category = models.CharField(max_length=120, blank=True)

    # Sender settings (section 5 of the brief).
    sender_name = models.CharField(max_length=120, blank=True)
    sender_email = models.EmailField(blank=True)
    sender_company = models.CharField(max_length=160, blank=True)
    provider = models.CharField(max_length=32, blank=True)
    service_pitch = models.TextField(blank=True)

    # 24, not 16: "paused_rate_limit" is 17 characters.
    phase = models.CharField(max_length=24, choices=Phase.choices,
                             default=Phase.SETUP)
    error = models.TextField(blank=True)
    finished_at = models.DateTimeField(null=True, blank=True)

    # --- why the run stopped, and when it may start again ------------------- #
    #
    # Persisted rather than held in the worker, for the same reason as
    # `current_step`: a rate limit that outlives the process must not leave the
    # page waiting for progress that will never arrive, and a user who reloads
    # needs to see how long the wait is.
    pause_reason = models.CharField(max_length=16, choices=Pause.choices,
                                    blank=True)
    #: What to tell the user. Written locally -- never a provider response body.
    pause_detail = models.CharField(max_length=300, blank=True)
    #: When processing may resume. Compared against the clock rather than counted
    #: down, so a closed laptop does not shorten the wait.
    retry_at = models.DateTimeField(null=True, blank=True)
    #: How many times this run has been rate limited. Drives the exponential
    #: backoff for providers that do not say how long to wait.
    pause_count = models.PositiveSmallIntegerField(default=0)
    cancelled_at = models.DateTimeField(null=True, blank=True)

    #: The operator's decision, separate from `phase`. Defaults to ACTIVE rather
    #: than DRAFT so every campaign that existed before this field behaves exactly
    #: as it did -- a migration that silently paused a running campaign would be
    #: the worst possible default.
    status = models.CharField(max_length=16, choices=Status.choices,
                              default=Status.ACTIVE, db_index=True)
    status_changed_at = models.DateTimeField(null=True, blank=True)
    #: Why it was paused or stopped, in the operator's words. Shown wherever the
    #: status is, because "paused" without a reason is a question rather than
    #: information.
    status_note = models.CharField(max_length=300, blank=True)
    #: When a SCHEDULED campaign should become ACTIVE.
    scheduled_for = models.DateTimeField(null=True, blank=True)

    # Which lead the sequential run is on, and which of its four steps. Stored
    # rather than held in the worker thread so the progress panel survives a
    # page reload, and so a restarted server cannot leave the UI claiming a
    # lead is still being analysed.
    current_draft = models.ForeignKey(
        "EmailDraft", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )
    current_step = models.CharField(max_length=12, blank=True)

    #: Which addresses this campaign may send from. Empty means "the deployment's
    #: configured sender", which is how every campaign made before email accounts
    #: existed behaves -- so adding accounts changes nothing until one is chosen.
    #:
    #: Selection is not permission: `mailaccounts.sending_accounts()` re-checks
    #: active and configured at send time, because an account can be switched off
    #: after a campaign is set up and before it runs.
    sending_accounts = models.ManyToManyField(
        "EmailAccount", blank=True, related_name="campaigns")

    class Meta:
        ordering = ("-created_at",)

    def __str__(self) -> str:
        return f"{self.category or 'leads'} in {self.city or 'unknown'} ({self.id.hex[:8]})"

    @property
    def label(self) -> str:
        bits = [b for b in (self.category, self.city, self.country) if b]
        return " · ".join(bits) or "Untitled campaign"

    # --- run control ------------------------------------------------------- #
    #
    # One place answers "may this run carry on?", so the worker thread, the
    # cancel endpoint and the progress panel cannot disagree about it.

    #: Phases where a lead-processing job is, or should be, doing work.
    PROCESSING_PHASES = ("crawling", "analysing", "generating")
    #: Phases a Cancel press is meaningful in.
    CANCELLABLE_PHASES = PROCESSING_PHASES + (
        "paused_rate_limit", "cancel_requested")

    #: Statuses in which no email may leave, by the operator's decision.
    HALTED_STATUSES = ("paused", "stopped", "completed", "failed", "draft",
                       "scheduled")

    @property
    def may_send(self) -> bool:
        """May this campaign send anything at all right now?

        The §5 rule: only ACTIVE campaigns send. Draft and Scheduled have not
        started; Paused and Stopped were halted deliberately; Completed and Failed
        are over. The follow-up worker checks this before it does anything else.
        """
        return self.status == self.Status.ACTIVE

    #: Statuses that stop a follow-up as well as a first contact. Deliberately
    #: shorter than HALTED_STATUSES: `completed` belongs there and not here,
    #: because reaching a target is the machinery finishing rather than a person
    #: stopping it -- and the people already emailed are still owed the follow-up
    #: the campaign was configured to send them.
    NO_FOLLOWUP_STATUSES = ("paused", "stopped", "failed")

    @property
    def may_follow_up(self) -> bool:
        """May this campaign continue a conversation it already started?

        Separate from `may_send`, which is about contacting somebody new. A
        completed campaign may not do that -- the target is met -- but refusing to
        follow up on what it already sent would mean a campaign that hit its number
        abandoned its most recent leads, with "the campaign is completed" on screen
        as though that were an explanation.

        Sending one is still a person's click. This only decides whether the
        follow-up may exist.
        """
        return self.status not in self.NO_FOLLOWUP_STATUSES

    @property
    def is_paused_by_operator(self) -> bool:
        return self.status == self.Status.PAUSED

    @property
    def is_processing(self) -> bool:
        return self.phase in self.PROCESSING_PHASES

    @property
    def is_paused(self) -> bool:
        return self.phase == self.Phase.PAUSED_RATE_LIMIT

    @property
    def is_cancelling(self) -> bool:
        return self.phase == self.Phase.CANCEL_REQUESTED

    @property
    def is_cancelled(self) -> bool:
        return self.phase == self.Phase.CANCELLED

    @property
    def stopping(self) -> bool:
        """Cancel has been asked for, or has already happened.

        The worker checks this before each lead, and cancellation therefore takes
        precedence over a rate-limit wait: a job asleep until the retry window
        wakes, sees this, and stops instead of resuming.
        """
        return self.phase in (self.Phase.CANCEL_REQUESTED, self.Phase.CANCELLED)

    @property
    def retry_seconds(self) -> int:
        """Whole seconds until the retry window opens. 0 once it has."""
        if not self.retry_at:
            return 0
        return max(0, int((self.retry_at - timezone.now()).total_seconds()))

    @property
    def retry_ready(self) -> bool:
        """Paused, and the wait is over."""
        return self.is_paused and self.retry_seconds == 0

    def unfinished_count(self) -> int:
        """Leads that were queued and never completed.

        What "resume" would pick up, and what a cancelled run leaves behind. A
        lead that finished stays finished -- this deliberately counts only the
        ones with no completion stamp.
        """
        return self.drafts.filter(
            sequence__gt=0, processed_at__isnull=True,
        ).exclude(status__in=(EmailDraft.Status.EXCLUDED,
                              EmailDraft.Status.DUPLICATE,
                              EmailDraft.Status.SUPPRESSED,
                              EmailDraft.Status.NO_EMAIL)).count()

    def counts(self) -> dict[str, int]:
        """Live progress figures, straight from the drafts table."""
        rows = self.drafts.values("status").annotate(n=models.Count("id"))
        by_status = {row["status"]: row["n"] for row in rows}
        working = sum(
            by_status.get(s, 0)
            for s in (EmailDraft.Status.PENDING, EmailDraft.Status.CRAWLED,
                      EmailDraft.Status.ANALYSED, EmailDraft.Status.GENERATED,
                      EmailDraft.Status.APPROVED, EmailDraft.Status.SENDING)
        )
        approved = by_status.get(EmailDraft.Status.APPROVED, 0)
        return {
            "total": sum(by_status.values()),
            "in_workflow": working,
            "approved": approved,
            "sent": by_status.get(EmailDraft.Status.SENT, 0),
            "failed": by_status.get(EmailDraft.Status.FAILED, 0),
            "rejected": by_status.get(EmailDraft.Status.REJECTED, 0),
            "excluded": by_status.get(EmailDraft.Status.EXCLUDED, 0),
            "no_email": by_status.get(EmailDraft.Status.NO_EMAIL, 0),
            "duplicate": by_status.get(EmailDraft.Status.DUPLICATE, 0),
            "suppressed": by_status.get(EmailDraft.Status.SUPPRESSED, 0),
            "remaining": approved,
        }

    def progress(self) -> dict:
        """Where the sequential run has got to: "lead 7 of 25", and which step.

        Computed from the drafts table plus `current_draft`/`current_step`, so it
        is the same answer whether the browser has been open the whole time or
        has just been reloaded.
        """
        rows = list(
            self.drafts.filter(sequence__gt=0).order_by("sequence")
            .values("id", "sequence", "business_name", "website", "subject",
                    "analysis_status", "error_message", "processed_at")
        )
        total = len(rows)
        done = sum(1 for row in rows if row["processed_at"])

        stopped = self.is_cancelled

        current_row = None
        leads = []
        for row in rows:
            if row["processed_at"]:
                # A lead that finished with no email is the only real failure;
                # an unreadable website still gets an email, just without any
                # claims about the site.
                state = "completed" if row["subject"] else "failed"
            elif stopped:
                # Cancelled: no lead is in flight, and the rest were never
                # started. "stopped" rather than "failed" -- nothing went wrong
                # with them, and resuming picks them up unchanged.
                state = "stopped"
            elif row["id"] == self.current_draft_id:
                state = "paused" if self.is_paused else "current"
                current_row = row
            else:
                state = "waiting"
            leads.append({
                "id": row["id"],
                "sequence": row["sequence"],
                "business_name": row["business_name"],
                "state": state,
            })

        index = STEP_KEYS.index(self.current_step) if self.current_step in STEP_KEYS else -1
        finished = total > 0 and done == total
        if stopped:
            # No step is in flight once a run is cancelled, so none is shown as
            # current -- a spinning tick on a cancelled job reads as still going.
            index = -1
        steps = []
        for position, (key, label) in enumerate(LEAD_STEPS):
            if index < 0:
                state = "done" if finished else "waiting"
            elif position < index:
                state = "done"
            elif position == index:
                state = "current"
            else:
                state = "waiting"
            steps.append({"key": key, "label": label, "state": state})

        # The lead in flight counts towards the bar: lead 7 of 25 reads as 28%,
        # not 24%, which is what somebody watching it expects to see.
        position = done + (1 if current_row else 0)
        upcoming = next((lead for lead in leads if lead["state"] == "waiting"), None)

        return {
            "total": total,
            "done": done,
            "position": position,
            "percent": round(position / total * 100) if total else 0,
            "step": self.current_step,
            "steps": steps,
            "leads": leads,
            # Why the run is not moving, when it is not moving. One dictionary so
            # the panel has a single thing to check rather than inferring it from
            # the phase string.
            "control": self.control_state(),
            "unfinished": total - done,
            "current": {
                "id": current_row["id"],
                "sequence": current_row["sequence"],
                "business_name": current_row["business_name"],
                "website": current_row["website"],
                "analysis_status": current_row["analysis_status"],
            } if current_row else None,
            "next": upcoming,
            "finished": finished,
        }

    def control_state(self) -> dict:
        """Paused, cancelling, cancelled or running -- and the facts behind it.

        Everything the progress panel needs to explain a stopped run without
        parsing a phase string or doing arithmetic on a timestamp.
        """
        return {
            "state": (
                "cancelled" if self.is_cancelled else
                "cancelling" if self.is_cancelling else
                "paused" if self.is_paused else
                "running" if self.is_processing else "idle"
            ),
            "cancellable": self.phase in self.CANCELLABLE_PHASES,
            "cancelled_at": (self.cancelled_at.isoformat()
                             if self.cancelled_at else None),
            "pause_reason": self.pause_reason,
            "pause_reason_label": (self.get_pause_reason_display()
                                   if self.pause_reason else ""),
            "pause_detail": self.pause_detail,
            "pause_count": self.pause_count,
            "retry_at": self.retry_at.isoformat() if self.retry_at else None,
            "retry_seconds": self.retry_seconds,
            # True once a paused run may carry on. The panel asks the server to
            # resume rather than deciding for itself that the wait is over.
            "retry_ready": self.retry_ready,
            #: A quota needs the provider's reset or a different credential --
            #: there is no wait that fixes it, so no countdown is offered.
            "waitable": self.pause_reason == self.Pause.RATE_LIMIT,
        }
class Lifecycle(models.TextChoices):
    """Where a lead has got to, in sales terms.

    Separate from EmailDraft.Status, which tracks the *machinery* -- crawled,
    analysed, approved, sending. This is what a person wants to know, and the two
    are not the same thing: a draft can be `generated` while the lead is still
    only `analyzed`, because nobody has decided to contact them yet.

    Most transitions are derived from the machinery (see `EmailDraft.derive_
    lifecycle`). The last four are judgements only a person can make, so they are
    set by hand and never overwritten by the derivation.
    """

    NEW = "new", "New"
    ANALYZING = "analyzing", "Analyzing"
    ANALYZED = "analyzed", "Analyzed"
    QUALIFIED = "qualified", "Qualified"
    EMAIL_READY = "email_ready", "Email ready"
    CONTACTED = "contacted", "Contacted"
    FOLLOW_UP = "follow_up", "Follow-up"
    REPLIED = "replied", "Replied"
    INTERESTED = "interested", "Interested"
    MEETING = "meeting", "Meeting"
    WON = "won", "Won"
    LOST = "lost", "Lost"
    DO_NOT_CONTACT = "do_not_contact", "Do not contact"
#: Stages a person sets, which the automatic derivation must not undo.
MANUAL_LIFECYCLE = (Lifecycle.INTERESTED, Lifecycle.MEETING, Lifecycle.WON,
                    Lifecycle.LOST, Lifecycle.DO_NOT_CONTACT)
#: The happy path, in order, for the progress display on the lead page.
LIFECYCLE_PATH = (Lifecycle.NEW, Lifecycle.ANALYZING, Lifecycle.ANALYZED,
                  Lifecycle.QUALIFIED, Lifecycle.EMAIL_READY,
                  Lifecycle.CONTACTED, Lifecycle.FOLLOW_UP, Lifecycle.REPLIED,
                  Lifecycle.INTERESTED, Lifecycle.MEETING, Lifecycle.WON)
class EmailDraft(models.Model):
    """One lead: its website analysis, its scores, its email, its outcome."""

    class Status(models.TextChoices):
        NO_EMAIL = "no_email", "No public email"
        EXCLUDED = "excluded", "Not selected"
        DUPLICATE = "duplicate", "Already contacted"
        SUPPRESSED = "suppressed", "Do not contact"
        PENDING = "pending", "Queued"
        CRAWLED = "crawled", "Website crawled"
        ANALYSED = "analysed", "Website reviewed"
        GENERATED = "generated", "Email drafted"
        APPROVED = "approved", "Approved"
        REJECTED = "rejected", "Rejected"
        SENDING = "sending", "Sending"
        SENT = "sent", "Sent"
        FAILED = "failed", "Failed"

    campaign = models.ForeignKey(Campaign, on_delete=models.CASCADE,
                                 related_name="drafts")

    # The lead, copied from the scrape so the campaign is self-contained.
    business_name = models.CharField(max_length=255)
    email = models.EmailField(blank=True)
    website = models.URLField(max_length=500, blank=True)
    category = models.CharField(max_length=160, blank=True)
    address = models.CharField(max_length=400, blank=True)
    phone = models.CharField(max_length=80, blank=True)
    city = models.CharField(max_length=160, blank=True)
    country = models.CharField(max_length=160, blank=True)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    source = models.URLField(max_length=500, blank=True)

    # Website crawl.
    analysis_status = models.CharField(max_length=16, blank=True)
    analysis_note = models.CharField(max_length=400, blank=True)
    analysis_context = models.TextField(blank=True)
    #: The pages the crawler chose and read, as [{"url", "kind"}, ...].
    #: Which account sent this one, once it has been sent. Set at the moment of
    #: sending rather than at approval: the campaign's selection can change, and
    #: the question this answers is "who actually sent it".
    sent_account = models.ForeignKey(
        "EmailAccount", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="drafts",
    )

    #: One entry per page read: {"url", "kind", "facts"}. `facts` is that page's
    #: measured signals, and is absent on rows crawled before it was stored.
    pages_read = models.JSONField(default=list, blank=True)
    pages_discovered = models.PositiveIntegerField(default=0)
    #: Contact addresses found in `mailto:` links on the pages that were read.
    #: Kept separate from `email`, which is what the map data said, so the
    #: provenance of an address is never lost: one was published by the business
    #: for contact, and the other was in a public dataset. Nothing here is
    #: constructed -- no info@domain guess, no pattern applied to a name.
    discovered_emails = models.JSONField(default=list, blank=True)

    # Website review.
    business_summary = models.TextField(blank=True)
    #: Verified findings, as [{"issue", "evidence", "why_it_matters", ...}, ...].
    findings = models.JSONField(default=list, blank=True)

    # The email.
    subject = models.CharField(max_length=400, blank=True)
    body = models.TextField(blank=True)
    observation = models.CharField(max_length=600, blank=True)
    #: Which findings the email actually drew on.
    findings_used = models.JSONField(default=list, blank=True)
    edited = models.BooleanField(default=False)
    regenerations = models.PositiveSmallIntegerField(default=0)

    status = models.CharField(max_length=16, choices=Status.choices,
                              default=Status.PENDING)
    error_message = models.TextField(blank=True)
    sent_at = models.DateTimeField(null=True, blank=True)

    #: 1-based position in the sequential run, stamped when the run starts. It
    #: is what lets the progress panel say "Lead 7 of 25" and keep saying the
    #: same thing after a reload; 0 means this lead is not in the run.
    sequence = models.PositiveIntegerField(default=0)
    #: When this lead's own crawl -> review -> email -> save cycle finished.
    #: Set whether the cycle succeeded or not: it means "we are done with this
    #: lead and have moved on", which is what the progress list needs to know.
    processed_at = models.DateTimeField(null=True, blank=True)

    #: Which worker is working on this lead, and since when. Empty means
    #: nobody. The claim is a conditional UPDATE against this column, which
    #: is what stops two workers processing -- and emailing -- the same
    #: business. A Python variable cannot do that job across two processes.
    claimed_by = models.CharField(max_length=120, blank=True, default="")
    claimed_at = models.DateTimeField(null=True, blank=True)

    # --- lead intelligence ------------------------------------------------
    #
    # Every number here is recomputed from the audit's measured signals by
    # outreach/scoring.py, and stored so the table can sort and filter in SQL.
    # `score_detail` holds the factors behind each one, which is what makes a
    # score explainable rather than merely present.

    #: website_found | no_website_opportunity | website_unverified
    classification = models.CharField(max_length=24, blank=True, db_index=True)
    classification_reason = models.CharField(max_length=400, blank=True)

    #: The cached audit these scores came from. Shared between drafts for the
    #: same website, so two campaigns do not pay for one crawl twice.
    audit = models.ForeignKey(
        "WebsiteAudit", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="drafts",
    )

    score_overall = models.PositiveSmallIntegerField(default=0, db_index=True)
    score_website = models.PositiveSmallIntegerField(default=0)
    score_value = models.PositiveSmallIntegerField(default=0)
    score_missing = models.PositiveSmallIntegerField(default=0)
    score_readiness = models.PositiveSmallIntegerField(default=0)
    #: hot | warm | low | skip -- derived from score_overall and the configured
    #: thresholds, stored so the queues are one indexed query each.
    priority = models.CharField(max_length=8, blank=True, db_index=True)

    #: {"overall": {...}, "website": {...}, ...} -- the factors behind each score.
    score_detail = models.JSONField(default=dict, blank=True)
    scored_at = models.DateTimeField(null=True, blank=True)

    recommended_service = models.CharField(max_length=64, blank=True)
    service_reason = models.CharField(max_length=400, blank=True)
    #: One factual sentence. Only ever restates evidence already held.
    why_prospect = models.CharField(max_length=400, blank=True)
    #: For no-website leads: the specific benefits worth talking about.
    benefits = models.JSONField(default=list, blank=True)

    lifecycle = models.CharField(max_length=16, choices=Lifecycle.choices,
                                 default=Lifecycle.NEW, db_index=True)
    lifecycle_note = models.CharField(max_length=300, blank=True)
    lifecycle_changed_at = models.DateTimeField(null=True, blank=True)

    #: A deliberate re-contact. Set only by the "Contact anyway" action, which
    #: exists because the name-and-city matching tier occasionally blocks two
    #: genuinely different businesses. It overrides the *sending history* and
    #: nothing else -- a suppressed address stays blocked, with or without it.
    force_contact = models.BooleanField(default=False)
    force_reason = models.CharField(max_length=300, blank=True)

    class Meta:
        ordering = ("business_name",)
        constraints = [
            # One *sendable* draft per address per campaign, so a campaign can
            # never mail the same mailbox twice. Rows flagged `duplicate` or
            # `suppressed` are exempt: they are the visible record of a
            # collision (two map pins sharing one info@ address) and are never
            # sent, so they must be allowed to keep the address they collided on.
            models.UniqueConstraint(
                fields=("campaign", "email"),
                condition=(
                    ~models.Q(email="")
                    & ~models.Q(status__in=("duplicate", "suppressed"))
                ),
                name="one_sendable_draft_per_email_per_campaign",
            ),
        ]
        indexes = [models.Index(fields=("status",)),
                   models.Index(fields=("email",)),
                   # The worker's query: the next unclaimed pending lead in one
                   # campaign. Without it every pass table-scans the drafts.
                   models.Index(fields=("campaign", "status", "claimed_by"),
                                name="draft_claimable_idx")]

    def __str__(self) -> str:
        return f"{self.business_name} <{self.email or 'no email'}>"

    @property
    def in_workflow(self) -> bool:
        return self.status not in (
            self.Status.NO_EMAIL, self.Status.EXCLUDED, self.Status.DUPLICATE,
            self.Status.SUPPRESSED,
        )

    @property
    def has_website_material(self) -> bool:
        return bool(self.analysis_context)

    def as_history_kwargs(self) -> dict:
        """The fields SentLead copies off a draft when a send is reserved."""
        return {
            "business_name": self.business_name,
            "email": self.email,
            "website": self.website,
            "domain": _domain_of(self.website),
            "country": self.country,
            "city": self.city,
            "subject": self.subject,
            "campaign": self.campaign,
            "campaign_label": self.campaign.label,
            "draft": self,
        }

    @property
    def contact_state(self) -> str:
        """Which badge this lead should wear. See history.STATES."""
        if self.status == self.Status.NO_EMAIL:
            return "invalid"
        if self.status == self.Status.SUPPRESSED:
            return "suppressed"
        if self.status == self.Status.DUPLICATE:
            return "contacted"
        if self.status == self.Status.SENT:
            return "sent"
        if self.status == self.Status.FAILED:
            return "failed"
        if self.status == self.Status.SENDING:
            return "sending"
        return "ready"

    @property
    def measured_signals(self) -> dict:
        """This lead's own measured signals, merged across the pages read.

        Empty for a lead crawled before the facts were stored per page, and for
        one that was never crawled -- in both cases the caller falls back to the
        shared audit row rather than inventing a measurement.
        """
        from apps.auditing import scoring

        facts = [
            page.get("facts") or {}
            for page in (self.pages_read or [])
            if isinstance(page, dict)
        ]
        return scoring.merge_signals(facts) if any(facts) else {}

    @property
    def finding_objects(self) -> list:
        """Stored findings as Finding instances, strongest first."""
        from apps.ai.base import Finding

        return [Finding.from_dict(f) for f in (self.findings or [])]

    # --- intelligence helpers ---------------------------------------------

    @property
    def classification_label(self) -> str:
        from apps.auditing.scoring import CLASSIFICATION_LABELS

        return CLASSIFICATION_LABELS.get(self.classification, "Not classified")

    @property
    def priority_label(self) -> str:
        from apps.auditing.scoring import PRIORITY_LABELS

        return PRIORITY_LABELS.get(self.priority, "Not scored")

    @property
    def has_website(self) -> bool:
        from apps.auditing.scoring import WEBSITE_FOUND

        return self.classification == WEBSITE_FOUND

    @property
    def main_issue(self) -> str:
        """The strongest evidenced finding, for the table's one-line summary."""
        for finding in self.findings or []:
            if finding.get("evidence"):
                return finding.get("issue", "")
        if self.classification == "no_website_opportunity":
            return "No website"
        if self.classification == "website_unverified":
            return "Not verified"
        return ""

    @property
    def sub_score_rows(self) -> list[dict]:
        """The six website sub-scores, in display order, from the audit."""
        from apps.auditing.scoring import SUB_SCORES

        stored = (self.audit.sub_scores if self.audit else {}) or {}
        rows = []
        for key, label, _fn in SUB_SCORES:
            entry = stored.get(key) or {}
            rows.append({
                "key": key,
                "label": label,
                "value": entry.get("value", 0),
                "measured": entry.get("measured", False),
                "display": (str(entry.get("value", 0))
                            if entry.get("measured") else "Unknown"),
                "factors": entry.get("factors", []),
            })
        return rows

    def derive_lifecycle(self) -> str:
        """Where this lead is, from the machinery. Never overrides a human stage.

        Read rather than written by most of the application: the send loop moves
        `status`, and this translates that into the sales vocabulary. The four
        judgement stages are left alone, because no amount of machinery can tell
        whether somebody is interested.
        """
        if self.lifecycle in [c.value for c in MANUAL_LIFECYCLE]:
            return self.lifecycle

        Status = self.Status
        if self.status == Status.SUPPRESSED:
            return Lifecycle.DO_NOT_CONTACT
        if self.status == Status.REJECTED:
            return Lifecycle.LOST
        if self.status in (Status.NO_EMAIL, Status.EXCLUDED, Status.DUPLICATE):
            return Lifecycle.ANALYZED if self.classification else Lifecycle.NEW

        # Contacted, and what came back.
        if self.status == Status.SENT:
            row = self.history_rows.order_by("-reserved_at").first()
            state = getattr(row, "reply_state", "") if row else ""
            if state == "replied":
                return Lifecycle.REPLIED
            if row and row.followups.filter(status="sent").exists():
                return Lifecycle.FOLLOW_UP
            return Lifecycle.CONTACTED
        if self.status in (Status.SENDING, Status.FAILED):
            return Lifecycle.CONTACTED

        if self.status == Status.APPROVED:
            return Lifecycle.EMAIL_READY
        if self.status == Status.GENERATED:
            from apps.auditing.scoring import is_ready

            return (Lifecycle.EMAIL_READY if is_ready(self.score_readiness)
                    else Lifecycle.QUALIFIED)
        if self.status == Status.ANALYSED:
            return Lifecycle.QUALIFIED if self.score_overall else Lifecycle.ANALYZED
        if self.status == Status.CRAWLED:
            return Lifecycle.ANALYZING
        return Lifecycle.NEW

    @property
    def lifecycle_steps(self) -> list[dict]:
        """The path so far, for the lead page's progress display."""
        current = self.lifecycle or Lifecycle.NEW
        if current in (Lifecycle.LOST, Lifecycle.DO_NOT_CONTACT):
            return [{"key": current, "label": self.get_lifecycle_display(),
                     "state": "ended"}]

        order = [c.value for c in LIFECYCLE_PATH]
        position = order.index(current) if current in order else 0
        rows = []
        for index, key in enumerate(order):
            rows.append({
                "key": key,
                "label": Lifecycle(key).label,
                "state": ("done" if index < position
                          else "current" if index == position else "waiting"),
            })
        return rows
class CampaignEvent(models.Model):
    """One line of what the worker did, and when.

    An unattended run that leaves no trail is indistinguishable from one that did
    nothing -- and the questions afterwards are always specific: why was this lead
    skipped, when did it stop, what did the provider say. So every decision writes
    a row, including the boring ones, and the dashboard reads them back in order.

    Cheap on purpose: two short strings and a foreign key. No JSON payload, no
    duplicated draft fields. Anything longer than a sentence belongs on the draft
    it happened to.
    """

    class Kind(models.TextChoices):
        STARTED = "started", "Campaign started"
        RESUMED = "resumed", "Campaign resumed"
        PAUSED = "paused", "Campaign paused"
        STOPPED = "stopped", "Campaign stopped"
        COMPLETED = "completed", "Campaign completed"
        SCHEDULE = "schedule", "Schedule"
        QUOTA = "quota", "Limit reached"
        PROSPECTED = "prospected", "Prospects added"
        SELECTED = "selected", "Lead selected"
        CRAWLED = "crawled", "Website crawled"
        FINDINGS = "findings", "Findings identified"
        GENERATED = "generated", "Email generated"
        SENT = "sent", "Email sent"
        SKIPPED = "skipped", "Lead skipped"
        FAILED = "failed", "Failed"
        FOLLOWUP = "followup", "Follow-up prepared"
        ERROR = "error", "Error"

    campaign = models.ForeignKey(Campaign, on_delete=models.CASCADE,
                                related_name="events")
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="campaign_events", null=True, blank=True)
    #: Which lead it was about, where it was about one. SET_NULL rather than
    #: CASCADE: the log of what happened must survive the row it happened to.
    draft = models.ForeignKey("EmailDraft", on_delete=models.SET_NULL,
                              null=True, blank=True, related_name="events")

    kind = models.CharField(max_length=16, choices=Kind.choices)
    message = models.CharField(max_length=400)
    detail = models.CharField(max_length=400, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ("-created_at", "-id")
        indexes = [
            models.Index(fields=("campaign", "-created_at"),
                         name="event_campaign_time_idx"),
            models.Index(fields=("owner", "-created_at"),
                         name="event_owner_time_idx"),
        ]

    def __str__(self) -> str:
        return f"{self.created_at:%H:%M} {self.message}"

    @property
    def is_bad(self) -> bool:
        return self.kind in (self.Kind.FAILED, self.Kind.ERROR)
