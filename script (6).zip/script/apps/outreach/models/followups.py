"""
The second and third message in a conversation.

One row per follow-up number per lead, and the unique constraint on `(lead, number)`
is what makes "one schedule, at most one send" true rather than hoped for.

Every state in `Status` is a place a follow-up can rest, and the two that matter most
are `WAITING` -- scheduled, nothing to review yet -- and `DUE`, which means a person
should read it. Nothing moves from `DUE` to `SENT` without a click.
"""

from __future__ import annotations

from django.conf import settings
from django.db import models
from django.utils import timezone

from .history import ReplyState


class FollowUp(models.Model):
    """One manual follow-up to a lead that never replied.

    Separate from SentLead rather than another row in it. A SentLead row is the
    *first* contact and the thing duplicate prevention keys on; a follow-up is a
    deliberate second or third touch on that same thread, and only ever exists
    because a person clicked Create Follow-Up and then Send Follow-Up.

    **Nothing here is ever sent automatically.** A background worker prepares
    follow-ups -- finds the ones whose window has opened, runs every safety check,
    writes the draft -- and then stops, leaving the row at DUE for a person to
    read and send. That division is deliberate: the worker exists so nobody has to
    keep a browser open, not so nobody has to read the email.
    """

    class Status(models.TextChoices):
        """The lifecycle from §18.

        WAITING and DUE are the worker's states; DRAFT is what a person creating
        one by hand gets. SKIPPED and OPTED_OUT record a decision not to send and
        why, which matters as much as the sends do -- a follow-up that quietly
        disappeared is indistinguishable from a bug.
        """

        WAITING = "waiting", "Waiting for the window"
        DUE = "due", "Ready to review"
        DRAFT = "draft", "Awaiting review"
        PROCESSING = "processing", "Being prepared"
        SENDING = "sending", "Sending"
        SENT = "sent", "Sent"
        SKIPPED = "skipped", "Skipped"
        FAILED = "failed", "Failed"
        CANCELLED = "cancelled", "Cancelled"
        OPTED_OUT = "opted_out", "Opted out"

    #: The states a person may act on: drafted, checked, and waiting for a click.
    REVIEWABLE = ("due", "draft")
    #: The states that are finished, one way or another.
    SETTLED = ("sent", "skipped", "cancelled", "opted_out")

    lead = models.ForeignKey("outreach.SentLead", on_delete=models.CASCADE,
                             related_name="followups")
    #: Copied from the lead when the follow-up is created. Stored rather than
    #: joined because this table is queried on its own, and a filter that has to
    #: remember to join is a filter somebody will forget to join.
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="followups", null=True, blank=True, db_index=True,
    )
    campaign = models.ForeignKey(
        "outreach.Campaign", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="followups",
    )
    #: Snapshot, so the record still reads correctly if the campaign is deleted.
    campaign_label = models.CharField(max_length=255, blank=True)

    #: 1 for the first follow-up, 2 for the second. Bounded by
    #: settings.OUTREACH_FOLLOWUP_MAX.
    number = models.PositiveSmallIntegerField(default=1)

    email = models.EmailField()
    subject = models.CharField(max_length=400, blank=True)
    body = models.TextField(blank=True)
    edited = models.BooleanField(default=False)
    regenerations = models.PositiveSmallIntegerField(default=0)

    status = models.CharField(max_length=12, choices=Status.choices,
                              default=Status.DRAFT)
    error_message = models.TextField(blank=True)

    #: Its own Message-ID, so a reply to the follow-up is matched to the
    #: follow-up rather than to the original email.
    message_id = models.CharField(max_length=255, blank=True, db_index=True)

    #: When this follow-up's window opens. Written when the previous email was
    #: sent, so "is it due" is an indexed comparison rather than a recalculation
    #: over every lead.
    scheduled_for = models.DateTimeField(null=True, blank=True, db_index=True)

    #: Threading, per section 16. A follow-up belongs in the same conversation as
    #: the email it follows: In-Reply-To is the immediate parent, References the
    #: chain.
    in_reply_to = models.CharField(max_length=255, blank=True)
    references = models.TextField(blank=True)
    #: The provider's own conversation id where one exists. Blank for SMTP, which
    #: has no such concept -- the headers are what threading rests on.
    thread_id = models.CharField(max_length=255, blank=True)

    #: Delivery and reply, kept apart: a message can be delivered and unanswered,
    #: and one field cannot say both.
    delivery_status = models.CharField(max_length=32, blank=True)

    #: Section 19: bounded retry. Sending the same email every fifteen minutes
    #: because a provider is briefly unhappy is what this counter prevents.
    attempts = models.PositiveSmallIntegerField(default=0)
    last_attempt_at = models.DateTimeField(null=True, blank=True)
    #: Why the worker passed over it. Set alongside SKIPPED, because a skipped
    #: follow-up with no reason is indistinguishable from a bug.
    skip_reason = models.CharField(max_length=300, blank=True)
    #: Which account is expected to send it. Nullable: a deployment with no email
    #: accounts configured sends from `.env`.
    sender_account = models.ForeignKey(
        "EmailAccount", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="followups",
    )
    reply_state = models.CharField(max_length=16, choices=ReplyState.choices,
                                   default=ReplyState.NO_REPLY)
    replied_at = models.DateTimeField(null=True, blank=True)
    reply_snippet = models.CharField(max_length=500, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    sent_at = models.DateTimeField(null=True, blank=True)
    #: Denormalised so a spreadsheet reader gets plain date and time columns.
    sent_date = models.DateField(null=True, blank=True)
    sent_time = models.TimeField(null=True, blank=True)

    class Meta:
        ordering = ("-created_at",)
        constraints = [
            # One live follow-up per number per lead. This is what stops a
            # double-clicked Create Follow-Up producing two #1 drafts, and a
            # double-clicked Send Follow-Up producing two sends. A cancelled row
            # is excluded so the number can be used again after a cancel.
            models.UniqueConstraint(
                fields=("lead", "number"),
                condition=~models.Q(status="cancelled"),
                name="one_live_followup_per_number_per_lead",
            ),
        ]
        indexes = [
            models.Index(fields=("status",)),
            models.Index(fields=("email",)),
        ]

    def __str__(self) -> str:
        return f"Follow-up #{self.number} to {self.email} ({self.status})"

    @property
    def is_live(self) -> bool:
        """Does this row occupy its follow-up number?"""
        return self.status != self.Status.CANCELLED

    def mark_sent(self, message_id: str = "") -> None:
        now = timezone.localtime()
        FollowUp.objects.filter(pk=self.pk).update(
            status=self.Status.SENT, sent_at=now, sent_date=now.date(),
            sent_time=now.time().replace(microsecond=0),
            message_id=message_id or self.message_id, error_message="",
        )

    def mark_failed(self, message: str) -> None:
        FollowUp.objects.filter(pk=self.pk).update(
            status=self.Status.FAILED, error_message=message[:2000],
        )
