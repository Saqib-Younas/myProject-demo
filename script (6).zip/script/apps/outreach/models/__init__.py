"""
The outreach tables, split by subject.

One app and one migration history, because these tables are one foreign-key graph --
`AuditJob` points at `EmailDraft`, `EmailDraft` points back at `WebsiteAudit`, and
every counter in the project is derived from `SentLead`. Splitting them across apps
would mean either a mutual dependency between two migration graphs or a data move for
no functional gain.

    accounts.py     EmailAccount -- a mailbox this workspace sends from
    history.py      SentLead, Suppression -- who was contacted, who never may be
    campaigns.py    Campaign, EmailDraft, CampaignEvent -- the run and its leads
    followups.py    FollowUp -- the second and third message in a conversation
    automation.py   AutomationPlan, AutomationDay, ProspectSearch
    auditing.py     WebsiteAudit, AuditJob

Everything is re-exported here, so `from .models import Campaign` reads the same as it
did when this was one file -- including in the 23 migrations that name
`apps.outreach.models`. The import order below is the foreign-key order: a module may
only import from the ones above it.
"""


from .accounts import EmailAccount
from .auditing import AuditJob, WebsiteAudit
from .automation import AutomationDay, AutomationPlan, ProspectSearch
from .campaigns import (
    LEAD_STEPS,
    LIFECYCLE_PATH,
    MANUAL_LIFECYCLE,
    STEP_KEYS,
    Campaign,
    CampaignEvent,
    EmailDraft,
    Lifecycle,
)
from .followups import FollowUp
from .history import NO_FOLLOW_UP_STATES, ReplyState, SentLead, Suppression

# Last: it references only auth.User, so nothing here depends on it.
from .jobs import (
    EXPECTED_EVERY,
    STALE_AFTER,
    WorkerRun,
    worker_status,
)

__all__ = [
    "EmailAccount",
    "ReplyState", "NO_FOLLOW_UP_STATES", "SentLead", "Suppression",
    "LEAD_STEPS", "STEP_KEYS", "Campaign", "EmailDraft", "CampaignEvent",
    "Lifecycle", "MANUAL_LIFECYCLE", "LIFECYCLE_PATH",
    "FollowUp",
    "AutomationPlan", "AutomationDay", "ProspectSearch",
    "WebsiteAudit", "AuditJob",
    "WorkerRun", "worker_status", "STALE_AFTER", "EXPECTED_EVERY",
]
