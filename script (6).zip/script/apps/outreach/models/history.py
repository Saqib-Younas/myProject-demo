"""
Who has been contacted, and who may never be.

Two tables that answer different questions, and the difference matters:

  * `SentLead` is the **sending history**. One row per address contacted, created
    *before* SMTP opens -- creating it is the lock that makes a second send
    impossible. A user may legitimately override it for a deliberate re-contact.
  * `Suppression` is the **do-not-contact list**. It answers "are we allowed to email
    these people at all", and the answer is no. There is no override, at any layer,
    including a `force_contact` draft.
"""

from __future__ import annotations

import uuid
from urllib.parse import urlparse

from django.conf import settings
from django.db import models
from django.utils import timezone


class ReplyState(models.TextChoices):
    """What came back after a message went out.

    Shared by SentLead and FollowUp so a follow-up's outcome is described in the
    same words as the initial email's, and one lookup table drives both.
    """

    NO_REPLY = "no_reply", "No reply"
    REPLIED = "replied", "Replied"
    BOUNCED = "bounced", "Bounced"
    UNSUBSCRIBED = "unsubscribed", "Unsubscribed"
#: Reply states that permanently end outreach to a lead. `bounced` is included:
#: a follow-up to an address that does not exist is pure deliverability damage.
NO_FOLLOW_UP_STATES = (ReplyState.REPLIED, ReplyState.BOUNCED,
                       ReplyState.UNSUBSCRIBED)
class SentLead(models.Model):
    """The permanent record of who has been contacted.

    Separate from EmailDraft on purpose. A draft belongs to one campaign and can
    be edited, rejected or deleted; this table is append-only history and is the
    single source of truth for "have we already emailed these people?". It
    outlives the campaign that produced it -- deleting a campaign leaves the
    history intact, which is the whole point of keeping it separately.

    The unique constraint is the real duplicate protection. Everything else --
    the greyed-out checkbox, the campaign-level filter, the pre-send re-check --
    is there so the user sees the situation early; this is what makes a second
    send *impossible* rather than merely unlikely, including when two sending
    threads race for the same address.
    """

    class Status(models.TextChoices):
        SENDING = "sending", "Sending"
        SENT = "sent", "Sent"
        FAILED = "failed", "Failed"

    #: Stable identity for the Excel export. A primary key would do the job
    #: until a row is deleted -- SQLite reuses ids, so a later record could be
    #: mistaken for one already exported and silently skipped.
    uid = models.UUIDField(default=uuid.uuid4, editable=False, db_index=True)

    #: Whose sending history this row belongs to. Two users may each contact the
    #: same business without colliding -- the duplicate-prevention constraint
    #: below is scoped to the owner, because "have *I* already emailed them?" is
    #: the question it answers.
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="sent_leads", null=True, blank=True, db_index=True,
    )

    business_name = models.CharField(max_length=255)
    email = models.EmailField(db_index=True)
    website = models.URLField(max_length=500, blank=True)
    #: Host without "www.", so two URLs for one site collapse to one key.
    domain = models.CharField(max_length=255, blank=True, db_index=True)
    country = models.CharField(max_length=160, blank=True)
    city = models.CharField(max_length=160, blank=True)

    campaign = models.ForeignKey(
        "outreach.Campaign", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="sent_leads",
    )
    #: Snapshot, so the history still reads correctly if the campaign is deleted.
    campaign_label = models.CharField(max_length=255, blank=True)
    draft = models.ForeignKey(
        "outreach.EmailDraft", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="history_rows",
    )

    subject = models.CharField(max_length=400, blank=True)
    status = models.CharField(max_length=8, choices=Status.choices,
                              default=Status.SENDING)
    error_message = models.TextField(blank=True)

    #: This row is a deliberate re-contact, approved with a written reason. It is
    #: exempt from the one-live-row-per-address rule, because that rule is what
    #: the re-contact is overriding. See the constraints below.
    recontact = models.BooleanField(default=False)
    recontact_reason = models.CharField(max_length=300, blank=True)

    #: The Message-ID this email went out with. A reply quotes it in In-Reply-To
    #: or References, which is the only way to match a reply to its email
    #: without guessing from the subject line.
    message_id = models.CharField(max_length=255, blank=True, db_index=True)

    #: What came back. Set by the inbox check, never by the send.
    reply_state = models.CharField(max_length=16, choices=ReplyState.choices,
                                   default=ReplyState.NO_REPLY)
    replied_at = models.DateTimeField(null=True, blank=True)
    #: First line or two of the reply, so the list is readable without opening
    #: a mail client. Deliberately short: this is a pointer, not a mail store.
    reply_snippet = models.CharField(max_length=500, blank=True)
    #: When the inbox was last checked for this row.
    checked_at = models.DateTimeField(null=True, blank=True)

    reserved_at = models.DateTimeField(auto_now_add=True)
    sent_at = models.DateTimeField(null=True, blank=True)
    #: Denormalised so a spreadsheet reader gets plain date and time columns.
    sent_date = models.DateField(null=True, blank=True)
    sent_time = models.TimeField(null=True, blank=True)

    #: Which account sent it. Nullable: rows written before email accounts
    #: existed have none, and SET_NULL rather than CASCADE because deleting an
    #: account must never delete the record of who it contacted.
    sender_account = models.ForeignKey(
        "EmailAccount", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="sent_leads",
    )
    #: The same address as text. Kept alongside the FK on purpose: it has to
    #: survive the account being deleted, and "which address contacted this
    #: person" is a question the history must always be able to answer.
    sender_email = models.EmailField(blank=True, db_index=True)

    #: Set when a row has been written into sent_leads.xlsx, so the export
    #: appends rather than rewriting the sheet on every run.
    exported_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ("-reserved_at",)
        constraints = [
            # One live record per address. A `failed` row is excluded so a
            # genuine failure can be retried, but `sending` is included -- that
            # is what makes the reservation work as a lock between threads.
            #
            # Deliberate re-contacts are excluded too, since this rule is the
            # thing they exist to override. They are not left unprotected: the
            # constraint below still allows only one per campaign, so a
            # double-clicked Send cannot turn one approved re-contact into two
            # emails. What is given up is only the cross-campaign block, which
            # is precisely what the user asked for in writing.
            models.UniqueConstraint(
                fields=("owner", "email"),
                condition=~models.Q(status="failed") & models.Q(recontact=False),
                name="one_live_send_per_email",
            ),
            # SQL compares NULLs as distinct, so the constraint above does not
            # apply to rows with no owner -- which is every row created before
            # accounts existed. Without this second constraint, duplicate
            # prevention would silently switch itself off for that data.
            models.UniqueConstraint(
                fields=("email",),
                condition=(models.Q(owner__isnull=True)
                           & ~models.Q(status="failed")
                           & models.Q(recontact=False)),
                name="one_live_send_per_unowned_email",
            ),
            models.UniqueConstraint(
                fields=("email", "campaign"),
                condition=~models.Q(status="failed") & models.Q(recontact=True),
                name="one_recontact_per_email_per_campaign",
            ),
        ]
        indexes = [
            models.Index(fields=("status",)),
            models.Index(fields=("business_name", "city")),
            models.Index(fields=("owner", "status")),
        ]

    def __str__(self) -> str:
        return f"{self.business_name} <{self.email}> {self.status}"

    @staticmethod
    def domain_of(website: str) -> str:
        """Normalise a URL to a comparable host, or "" if there isn't one."""
        raw = (website or "").strip()
        if not raw:
            return ""
        if "//" not in raw:
            raw = "https://" + raw
        host = urlparse(raw).netloc.lower().split("@")[-1].split(":")[0]
        return host.removeprefix("www.")

    @property
    def is_live(self) -> bool:
        """Does this row block another send to the same address?"""
        return self.status != self.Status.FAILED

    def mark_sent(self, message_id: str = "") -> None:
        """Record delivery, and the Message-ID replies will quote."""
        now = timezone.localtime()
        SentLead.objects.filter(pk=self.pk).update(
            status=self.Status.SENT, sent_at=now,
            sent_date=now.date(), sent_time=now.time().replace(microsecond=0),
            message_id=(message_id or self.message_id or "")[:255],
            error_message="",
        )
        # The instance is kept in step with the row it just wrote. Callers act on
        # this object straight afterwards -- the follow-up schedule is computed
        # from `sent_at` -- and reading a stale None there silently anchors the
        # whole sequence to the reservation instead of to the send.
        self.status = self.Status.SENT
        self.sent_at = now
        self.sent_date = now.date()
        self.sent_time = now.time().replace(microsecond=0)
        self.message_id = (message_id or self.message_id or "")[:255]
        self.error_message = ""

    def mark_failed(self, message: str) -> None:
        """Record the failure and release the address for a retry."""
        SentLead.objects.filter(pk=self.pk).update(
            status=self.Status.FAILED, error_message=message[:2000],
        )
class Suppression(models.Model):
    """Addresses and domains that must never be contacted.

    Deliberately separate from SentLead, and deliberately stronger. The sending
    history answers "have we already emailed these people?", which a user may
    reasonably override for a follow-up or a bad name-and-city match. This table
    answers "are we allowed to email these people at all?", and the answer is no
    -- there is no override, at any layer, including a `force_contact` draft.

    An entry can cover a single address or a whole domain, because "take us off
    your list" is usually meant for the company, not just the mailbox that
    happened to reply.
    """

    class Reason(models.TextChoices):
        UNSUBSCRIBED = "unsubscribed", "Asked to be removed"
        COMPLAINED = "complained", "Reported as spam"
        BOUNCED = "bounced", "Address does not exist"
        MANUAL = "manual", "Added manually"

    #: Whose list this is. One user's do-not-contact entry must not silently
    #: block another user's outreach.
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="suppressions", null=True, blank=True, db_index=True,
    )

    email = models.EmailField(blank=True, db_index=True)
    #: Host without "www.", matching SentLead.domain_of.
    domain = models.CharField(max_length=255, blank=True, db_index=True)
    business_name = models.CharField(max_length=255, blank=True)

    reason = models.CharField(max_length=16, choices=Reason.choices,
                              default=Reason.UNSUBSCRIBED)
    note = models.CharField(max_length=400, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    #: Where it came from, when it was added off the back of a campaign.
    campaign_label = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ("-created_at",)
        constraints = [
            models.UniqueConstraint(
                fields=("owner", "email"), condition=~models.Q(email=""),
                name="one_suppression_per_email",
            ),
            models.UniqueConstraint(
                fields=("owner", "domain"),
                condition=~models.Q(domain="") & models.Q(email=""),
                name="one_suppression_per_domain",
            ),
            # Same NULL-owner gap as SentLead, for the same reason.
            models.UniqueConstraint(
                fields=("email",),
                condition=models.Q(owner__isnull=True) & ~models.Q(email=""),
                name="one_unowned_suppression_per_email",
            ),
            # A row that names neither is not a rule, it is a mistake.
            models.CheckConstraint(
                condition=~(models.Q(email="") & models.Q(domain="")),
                name="suppression_needs_an_email_or_a_domain",
            ),
        ]

    def __str__(self) -> str:
        return f"{self.target} ({self.get_reason_display()})"

    @property
    def target(self) -> str:
        return self.email or f"*@{self.domain}"

    @property
    def scope(self) -> str:
        return "address" if self.email else "whole domain"
