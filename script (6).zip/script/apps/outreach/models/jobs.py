"""
What the background jobs actually did, so a screen can report it honestly.

Until this existed there was nothing to report. The follow-up worker is
`manage.py process_followups` on a timer: a process starts, does one pass and exits.
Nothing survived it, so "is the worker running?" could only be answered by reading a log
file on the server -- and a Follow-Ups page that claimed to know would have been making
it up.

**One row per pass, written by the job itself.** Not a heartbeat and not a queue: the
project has no broker (see `apps/outreach/tasks.py`), so there is no queue depth to read
and no worker process to ask. What there is, is a record of every pass that ran, what it
found and how long it took -- which is enough to answer the questions that matter:

    when did it last run                 -> the newest row
    did it work                           -> that row's `ok`
    when did it last succeed              -> the newest row with ok=True
    when should it run again              -> `finished_at` + the configured interval
    has it stopped                        -> nothing recent, and `WorkerRun.stale()`
    how much has it done                  -> the totals across rows

**A pass that crashes still leaves a row.** The row is written when the pass *starts*
and updated when it finishes, so a job killed halfway is visible as a run that began and
never ended -- which is exactly the state somebody debugging a stopped worker needs to
see. A row written only on success would make a crash look like the worker never ran.
"""

from __future__ import annotations

import datetime as dt

from django.db import models
from django.utils import timezone


class WorkerRun(models.Model):
    """One pass of one background job.

    Kept small on purpose. The per-lead detail is already in `CampaignEvent` and on the
    `FollowUp` rows themselves; this is only the shape of the pass, so the table stays
    cheap to write on every cron tick and cheap to query for a status panel.
    """

    class Job(models.TextChoices):
        FOLLOWUPS = "process_followups", "Follow-up worker"
        AUTOMATION = "run_automation", "Automation worker"
        AUDITS = "run_audits", "Website audit worker"
        REPLIES = "check_replies", "Inbox reader"

    job = models.CharField(max_length=40, choices=Job.choices, db_index=True)

    #: Whose pass this was, where the job runs per account. Null for a pass over every
    #: account, which is what cron does by default.
    owner = models.ForeignKey("auth.User", null=True, blank=True,
                              on_delete=models.CASCADE, related_name="worker_runs")

    #: Which process held it, from `runner.worker_id()`. A stuck run can then be traced
    #: to a host rather than guessed at.
    worker = models.CharField(max_length=120, blank=True)

    started_at = models.DateTimeField(default=timezone.now, db_index=True)
    #: Null while the pass is in flight. A row with a start and no finish is a pass that
    #: died, and that is the point of storing them separately.
    finished_at = models.DateTimeField(null=True, blank=True)

    #: False until the pass finishes cleanly. So an unfinished row is never counted as a
    #: success, which is what makes `last_success` trustworthy.
    ok = models.BooleanField(default=False)

    considered = models.PositiveIntegerField(default=0)
    succeeded = models.PositiveIntegerField(default=0)
    skipped = models.PositiveIntegerField(default=0)
    failed = models.PositiveIntegerField(default=0)

    #: One sentence for a person: the halt reason, or the error. Never a credential --
    #: the services that fill it in raise `UserFacingError` subclasses for exactly this.
    detail = models.CharField(max_length=300, blank=True)

    #: True for `--dry-run`, so a rehearsal is not mistaken for a real pass.
    dry_run = models.BooleanField(default=False)

    class Meta:
        ordering = ("-started_at",)
        indexes = [
            # The status panel's only query: the newest few rows for one job.
            models.Index(fields=["job", "-started_at"], name="run_job_time_idx"),
            models.Index(fields=["job", "ok", "-started_at"], name="run_job_ok_idx"),
        ]

    def __str__(self) -> str:
        return f"{self.get_job_display()} at {self.started_at:%Y-%m-%d %H:%M}"

    # --- reading ---------------------------------------------------------- #

    @property
    def running(self) -> bool:
        return self.finished_at is None

    @property
    def duration(self) -> dt.timedelta | None:
        if self.finished_at is None:
            return None
        return self.finished_at - self.started_at

    # --- writing ---------------------------------------------------------- #

    @classmethod
    def begin(cls, job: str, *, owner=None, worker: str = "",
              dry_run: bool = False) -> "WorkerRun":
        """Record that a pass has started.

        Called before any work, so a pass that dies leaves evidence it began.
        """
        return cls.objects.create(job=job, owner=owner, worker=worker,
                                  dry_run=dry_run)

    def finish(self, *, ok: bool = True, considered: int = 0, succeeded: int = 0,
               skipped: int = 0, failed: int = 0, detail: str = "") -> "WorkerRun":
        """Record how the pass ended. Idempotent enough to call in a `finally`."""
        self.finished_at = timezone.now()
        self.ok = ok
        self.considered = considered
        self.succeeded = succeeded
        self.skipped = skipped
        self.failed = failed
        self.detail = (detail or "")[:300]
        self.save(update_fields=["finished_at", "ok", "considered", "succeeded",
                                 "skipped", "failed", "detail"])
        return self


#: How long after a pass should finish before the screen calls the worker stopped.
#:
#: Deliberately generous relative to the cron interval in DEPLOY.md (the follow-up job
#: runs hourly there, the automation job every five minutes). A warning that fires
#: because one tick was skipped is a warning people learn to ignore, and then it is worth
#: nothing when the worker really has stopped.
STALE_AFTER = {
    WorkerRun.Job.FOLLOWUPS: dt.timedelta(hours=3),
    WorkerRun.Job.AUTOMATION: dt.timedelta(minutes=20),
    WorkerRun.Job.AUDITS: dt.timedelta(minutes=15),
    WorkerRun.Job.REPLIES: dt.timedelta(hours=2),
}

#: What the cron lines in DEPLOY.md §12 actually are, so "next check" is derived from
#: the documented schedule rather than invented. Not authoritative -- a deployment can
#: use any interval -- which is why the screen labels it as expected, not promised.
EXPECTED_EVERY = {
    WorkerRun.Job.FOLLOWUPS: dt.timedelta(hours=1),
    WorkerRun.Job.AUTOMATION: dt.timedelta(minutes=5),
    WorkerRun.Job.AUDITS: dt.timedelta(minutes=2),
    WorkerRun.Job.REPLIES: dt.timedelta(minutes=30),
}


def worker_status(job: str, *, owner=None) -> dict:
    """Everything a status panel needs about one job, from the rows it actually wrote.

    Returns figures, not sentences, so the template decides the wording. `stale` is the
    one judgement made here, because the threshold belongs with the job rather than with
    whichever screen happens to be asking.

    Totals are lifetime for this job, which is what "Jobs Processed / Sent / Failed"
    means on the panel. Scoped to the owner where one is given, so one account's page
    does not report another's work.
    """
    runs = WorkerRun.objects.filter(job=job)
    if owner is not None and getattr(owner, "pk", None):
        runs = runs.filter(models.Q(owner=owner) | models.Q(owner__isnull=True))

    latest = runs.first()
    last_ok = runs.filter(ok=True).first()
    last_bad = runs.filter(ok=False, finished_at__isnull=False).first()
    in_flight = runs.filter(finished_at__isnull=True).count()

    totals = runs.aggregate(
        considered=models.Sum("considered"), succeeded=models.Sum("succeeded"),
        skipped=models.Sum("skipped"), failed=models.Sum("failed"),
        passes=models.Count("id"))

    now = timezone.now()
    threshold = STALE_AFTER.get(job, dt.timedelta(hours=3))
    anchor = last_ok.finished_at if last_ok and last_ok.finished_at else None

    # Never run at all is reported separately from run-and-gone-quiet: one is a
    # deployment that has not set up cron, the other is a worker that has stopped, and
    # the advice differs.
    never_ran = latest is None
    stale = bool(anchor and (now - anchor) > threshold)

    expected = EXPECTED_EVERY.get(job)
    next_check = (anchor + expected) if (anchor and expected) else None

    return {
        "job": job,
        "label": WorkerRun.Job(job).label if job in WorkerRun.Job.values else job,
        "never_ran": never_ran,
        "running": in_flight > 0,
        "in_flight": in_flight,
        "last_run": latest.started_at if latest else None,
        "last_run_ok": latest.ok if latest else None,
        "last_success": anchor,
        "last_failure": last_bad.finished_at if last_bad else None,
        "last_failure_detail": last_bad.detail if last_bad else "",
        "next_check": next_check,
        "expected_every": expected,
        "stale": stale,
        "stale_after": threshold,
        "passes": totals["passes"] or 0,
        "processed": totals["considered"] or 0,
        "sent": totals["succeeded"] or 0,
        "skipped": totals["skipped"] or 0,
        "failed": totals["failed"] or 0,
    }
