"""
Unattended running: the configuration, the daily allowance, the search list.

`AutomationPlan` sits beside a `Campaign` rather than replacing it, so every screen,
control and report already built for campaigns works on an automated one.

`AutomationDay` exists for one reason worth stating: the daily target has to hold when
two workers run at once. Its `reserve()` is a conditional UPDATE, so the database
decides who gets the last slot of the day.
"""

from __future__ import annotations

from datetime import time as dt_time

from django.conf import settings
from django.db import models

from .campaigns import EmailDraft


class AutomationPlan(models.Model):
    """One campaign's automation configuration, and the worker's lease on it.

    Deliberately beside `Campaign` rather than inside it, and deliberately not a
    second campaign table. A `Campaign` already holds everything a campaign is --
    owner, status, sender identity, its drafts, its sent history, its report -- and
    duplicating that would mean two answers to "what happened", two status fields
    to keep in step and two dashboards. So this table holds only what is genuinely
    new: what to look for, when running is allowed, how much per day, how much in
    total, and which mailbox to use.

    The consequence worth knowing: everything already built on `Campaign` works on
    an automation campaign for free -- the status controls, the progress card, the
    campaigns list, the do-not-contact checks, the follow-up worker.

    `countries`, `cities` and `categories` are JSON lists rather than related
    tables. They are a search specification typed once and read as a whole, never
    joined against or aggregated, and three join tables to store "Dallas, Houston"
    would be structure without a use.
    """

    class Quality(models.TextChoices):
        """Which prospects are worth the campaign's attention.

        Only what the map data and the crawl can actually establish. There is no
        "website is bad" option, because that is not knowable before crawling and
        inventing it would put a claim in front of the AI that nothing measured.
        """

        ANY = "any", "Any business"
        HAS_WEBSITE = "has_website", "Has a website"
        NEEDS_WORK = "needs_work", "Website has verified problems"

    campaign = models.OneToOneField(
        "outreach.Campaign", on_delete=models.CASCADE,
        related_name="plan")
    #: Denormalised from the campaign so the worker can find every plan for one
    #: account without a join, and so ownership is in the query on every read.
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="automation_plans", null=True, blank=True)

    name = models.CharField(max_length=120)

    # --- what to look for ------------------------------------------------- #
    countries = models.JSONField(default=list, blank=True)
    cities = models.JSONField(default=list, blank=True)
    categories = models.JSONField(default=list, blank=True)
    quality = models.CharField(max_length=16, choices=Quality.choices,
                               default=Quality.ANY)

    #: Use a contact address published on the business's own website when the map
    #: data has none. Most map records carry a phone and a website but no email,
    #: so with this off a campaign skips most of what it finds -- and with it on,
    #: the address still comes from the business's own pages, never from a guess.
    discover_emails = models.BooleanField(default=True)

    # --- how much ---------------------------------------------------------- #
    daily_target = models.PositiveIntegerField(default=25)
    total_target = models.PositiveIntegerField(default=100)

    # --- when -------------------------------------------------------------- #
    start_date = models.DateField()
    start_time = models.TimeField(default=dt_time(9, 0))
    end_date = models.DateField(null=True, blank=True)
    end_time = models.TimeField(null=True, blank=True)
    #: An IANA name, and the campaign's own. Never the server's: a server zone is
    #: an accident of hosting, and a campaign that inherits it starts sending at a
    #: different hour after a move to another region.
    timezone_name = models.CharField(max_length=64, default="UTC")

    # --- how ---------------------------------------------------------------- #
    #: Which mailbox sends. Mirrored into `campaign.sending_accounts` on save so
    #: the existing send path resolves it the same way a manual campaign does.
    email_account = models.ForeignKey(
        "EmailAccount", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="automation_plans")
    #: Which approved email template writes the first contact. A key from
    #: `apps.ai.styles`, not free text -- the style decides length and shape,
    #: and an unknown key would silently fall back to a different email than the
    #: one the user chose.
    template_key = models.CharField(max_length=32, default="consultative")

    #: Seconds between sends, on top of the provider's own pacing. Sending as fast
    #: as SMTP will accept is how a new domain gets filtered.
    send_gap_seconds = models.PositiveSmallIntegerField(default=0)

    # --- follow-ups --------------------------------------------------------- #
    followups_enabled = models.BooleanField(default=True)
    followup_delay_days = models.PositiveSmallIntegerField(default=3)
    followup_max = models.PositiveSmallIntegerField(default=2)
    #: Present, always False, and refused by `clean()`. Unattended follow-up
    #: sending is not implemented, and the field exists so the answer to "can this
    #: be switched on?" is a visible no rather than a missing option somebody
    #: adds by hand later.
    followup_autosend = models.BooleanField(default=False)

    # --- the worker's lease ------------------------------------------------- #
    #: Which worker holds this plan, and until when. A lease rather than a lock:
    #: a worker killed mid-lead cannot release anything, so the next one takes
    #: over when the lease expires instead of the campaign being stuck forever.
    locked_by = models.CharField(max_length=120, blank=True)
    locked_until = models.DateTimeField(null=True, blank=True)

    #: Why the campaign finished, in the words shown on the dashboard.
    completion_reason = models.CharField(max_length=300, blank=True)
    last_activity_at = models.DateTimeField(null=True, blank=True)
    #: When the worker expects to do something next. Written by the worker, read
    #: by the dashboard -- so the screen reports the worker's own intention rather
    #: than recomputing a schedule and possibly disagreeing with it.
    next_run_at = models.DateTimeField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ("-created_at",)
        constraints = [
            models.UniqueConstraint(
                fields=("owner", "name"), name="one_plan_name_per_owner"),
        ]
        indexes = [
            # The worker's own query: every plan that might have work, oldest
            # activity first.
            models.Index(fields=("owner", "last_activity_at"),
                         name="plan_owner_activity_idx"),
        ]

    def __str__(self) -> str:
        return f"{self.name} ({self.campaign.get_status_display()})"

    # --- targets ------------------------------------------------------------ #

    @property
    def sent_total(self) -> int:
        """Emails actually delivered to SMTP for this campaign.

        Counted from the drafts rather than kept as a counter. A counter beside the
        rows is a second answer waiting to disagree with them, and this is the
        number that decides whether the campaign is finished.
        """
        return self.campaign.drafts.filter(
            status=EmailDraft.Status.SENT).count()

    @property
    def remaining_total(self) -> int:
        return max(0, self.total_target - self.sent_total)

    @property
    def target_reached(self) -> bool:
        return self.sent_total >= self.total_target

    def day(self, day):
        """Today's counter row, created on first use.

        `get_or_create` rather than a nightly job: a row per campaign-day that is
        written the first time the campaign works that day, and never for a day
        it did not run.
        """
        row, _created = AutomationDay.objects.get_or_create(plan=self, day=day)
        return row
class AutomationDay(models.Model):
    """One campaign-day's allowance, and what was actually done with it.

    This table exists for one reason: the daily target has to hold when two
    workers run at once. `reserve()` is a conditional UPDATE -- `SET reserved =
    reserved + 1 WHERE reserved < target` -- so the database, not a Python
    variable, decides who gets the twenty-fifth slot. Two workers asking together
    get one yes and one no.

    `day` is the campaign's own local date, not the server's. A campaign in
    Chicago rolls over at midnight in Chicago.
    """

    plan = models.ForeignKey(AutomationPlan, on_delete=models.CASCADE,
                            related_name="days")
    day = models.DateField()

    #: Slots claimed for processing. Incremented before a lead is worked on and
    #: released again if it turns out not to be sendable, so a skipped lead does
    #: not eat the day's allowance -- but a *sent* one always held a slot first.
    reserved = models.PositiveIntegerField(default=0)
    sent = models.PositiveIntegerField(default=0)
    skipped = models.PositiveIntegerField(default=0)
    failed = models.PositiveIntegerField(default=0)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ("-day",)
        constraints = [
            models.UniqueConstraint(fields=("plan", "day"),
                                    name="one_day_row_per_plan"),
        ]

    def __str__(self) -> str:
        return f"{self.plan_id} {self.day}: {self.sent} sent"

    # --- the slot, which is the whole point of this table ------------------- #

    def reserve(self, target: int) -> bool:
        """Claim one of today's slots. True if it was ours to claim.

        The conditional UPDATE is the enforcement. Reading `reserved`, comparing it
        in Python and then writing it back is the version of this that sends 30
        emails on a 25 target when two workers overlap: both read 24, both decide
        yes. Here the database compares and writes in one statement, so exactly one
        of them gets the row.
        """
        if target <= 0:
            return False
        taken = (AutomationDay.objects
                 .filter(pk=self.pk, reserved__lt=target)
                 .update(reserved=models.F("reserved") + 1))
        if taken:
            self.reserved += 1
        return bool(taken)

    def release(self) -> None:
        """Give a claimed slot back, because nothing was sent with it.

        A lead that turned out to be suppressed, already contacted or unreachable
        should not consume the day's allowance -- the allowance is a limit on
        emails, not on attempts. Floored at zero so a double release cannot make
        the count negative and quietly widen the limit.
        """
        (AutomationDay.objects
         .filter(pk=self.pk, reserved__gt=0)
         .update(reserved=models.F("reserved") - 1))
        self.reserved = max(0, self.reserved - 1)

    def record(self, outcome: str) -> None:
        """Count one finished attempt: "sent", "skipped" or "failed"."""
        field = {"sent": "sent", "skipped": "skipped",
                 "failed": "failed"}.get(outcome)
        if field is None:
            return
        AutomationDay.objects.filter(pk=self.pk).update(
            **{field: models.F(field) + 1})
        setattr(self, field, getattr(self, field) + 1)

    @property
    def remaining(self) -> int:
        """Slots left today, from this row's own target."""
        return max(0, self.plan.daily_target - self.reserved)
class ProspectSearch(models.Model):
    """One (country, city, category) the campaign will look through, once.

    The pool is filled by searching public map data, and each search costs a
    geocode and an Overpass query against somebody else's free service. So each
    combination is recorded before it runs and marked afterwards: a campaign never
    repeats a search it has already made, and "no eligible businesses remain" has
    an actual meaning -- every combination has been tried.
    """

    class Status(models.TextChoices):
        PENDING = "pending", "Not yet searched"
        RUNNING = "running", "Searching"
        DONE = "done", "Searched"
        EMPTY = "empty", "Nothing found"
        FAILED = "failed", "Search failed"

    plan = models.ForeignKey(AutomationPlan, on_delete=models.CASCADE,
                             related_name="searches")
    country = models.CharField(max_length=120, blank=True)
    city = models.CharField(max_length=120)
    category = models.CharField(max_length=120)

    status = models.CharField(max_length=12, choices=Status.choices,
                             default=Status.PENDING)
    found = models.PositiveIntegerField(default=0)
    added = models.PositiveIntegerField(default=0)
    detail = models.CharField(max_length=300, blank=True)
    attempts = models.PositiveSmallIntegerField(default=0)
    last_attempt_at = models.DateTimeField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ("city", "category")
        constraints = [
            models.UniqueConstraint(
                fields=("plan", "country", "city", "category"),
                name="one_search_per_plan_area"),
        ]
        indexes = [
            models.Index(fields=("plan", "status"), name="search_plan_state_idx"),
        ]

    def __str__(self) -> str:
        return f"{self.category} in {self.city} ({self.status})"
