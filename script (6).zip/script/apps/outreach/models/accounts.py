"""
One mailbox a workspace sends from.

Several per account, each with its own credential, its own limits and its own
signature. The password is Fernet ciphertext in `secret`, and the only form of it that
ever leaves the server is `hint` -- `smtp-........ wqnl`. There is no endpoint that
returns it, no template that renders it, and `__str__` cannot leak it.
"""

from __future__ import annotations

from django.conf import settings
from django.db import models


class EmailAccount(models.Model):
    """One address a workspace can send campaigns from.

    The parent is the signed-in account; these are its children. Ownership is in
    the query on every read, as everywhere else -- an account id in a URL grants
    nothing on its own.

    The password is Fernet ciphertext in `secret`, and the only form of it that
    ever leaves the server is `hint` -- `smtp-•••••••• wqnl`. There is no endpoint
    that returns it, no template that renders it, and `__str__` cannot leak it.
    """

    class Auth(models.TextChoices):
        """How this account authenticates.

        OAUTH is declared but not implemented, and is listed here rather than
        omitted so the gap is visible: §1 asks to prefer OAuth where the provider
        supports it, and an app password is what this actually does. Adding a
        provider's OAuth flow changes this field and nothing else.
        """

        PASSWORD = "password", "App password (SMTP)"
        OAUTH = "oauth", "OAuth (not yet available)"

    class Connection(models.TextChoices):
        UNTESTED = "untested", "Not tested"
        OK = "ok", "Connected"
        FAILED = "failed", "Connection failed"
        BLOCKED = "blocked", "Not tested — sending is blocked here"

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="email_accounts", db_index=True,
    )

    #: What the user calls it: "Sales outreach", "Marketing". Distinct from the
    #: address, because two accounts can sensibly share a mailbox with different
    #: limits and signatures.
    name = models.CharField(max_length=80)
    sender_name = models.CharField(max_length=120)
    sender_email = models.EmailField()
    #: The SMTP login, where it differs from the visible address. Blank means they
    #: are the same, which is the case that is not spoofing.
    username = models.CharField(max_length=160, blank=True)
    provider = models.CharField(max_length=32)

    #: Blank uses the provider's preset. Only `custom` needs them.
    smtp_host = models.CharField(max_length=160, blank=True)
    smtp_port = models.PositiveIntegerField(null=True, blank=True)
    imap_host = models.CharField(max_length=160, blank=True)
    imap_port = models.PositiveIntegerField(null=True, blank=True)

    auth_kind = models.CharField(max_length=16, choices=Auth.choices,
                                 default=Auth.PASSWORD)
    #: Fernet ciphertext. Never rendered, never returned, never logged.
    secret = models.TextField(blank=True)
    #: `smtp-••••••••abcd`. The only shape a browser sees.
    hint = models.CharField(max_length=64, blank=True)

    signature = models.TextField(blank=True)
    reply_to = models.EmailField(blank=True)

    #: 0 means "use the provider's cap". A lower number is honoured; a higher one
    #: is not, because the provider's limit is not ours to raise.
    daily_limit = models.PositiveIntegerField(default=0)

    #: Per-account follow-up settings. 0 and blank mean "use the deployment's".
    followup_max = models.PositiveSmallIntegerField(default=0)
    followup_delays = models.CharField(max_length=40, blank=True)

    #: Only an active account may send. Inactive is not deletion: history,
    #: scheduled follow-ups and sent records all survive it.
    is_active = models.BooleanField(default=True, db_index=True)

    connection_status = models.CharField(
        max_length=16, choices=Connection.choices, default=Connection.UNTESTED)
    #: What to show the user about the last test. Written locally -- never a
    #: provider response body, which can quote the credentials it was given.
    connection_detail = models.CharField(max_length=300, blank=True)
    last_tested_at = models.DateTimeField(null=True, blank=True)
    last_success_at = models.DateTimeField(null=True, blank=True)
    last_error_at = models.DateTimeField(null=True, blank=True)
    last_error = models.CharField(max_length=300, blank=True)

    sent_count = models.PositiveIntegerField(default=0)
    failed_count = models.PositiveIntegerField(default=0)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ("-is_active", "name")
        constraints = [
            models.UniqueConstraint(
                fields=("owner", "sender_email"),
                name="one_account_per_address_per_owner"),
            models.UniqueConstraint(
                fields=("owner", "name"),
                name="one_account_name_per_owner"),
        ]
        indexes = [
            models.Index(fields=("owner", "is_active"),
                         name="ea_owner_active_idx"),
        ]

    def __str__(self) -> str:
        state = "active" if self.is_active else "inactive"
        return f"{self.name} <{self.sender_email}> ({state})"

    @property
    def label(self) -> str:
        return f"{self.name} · {self.sender_email}"

    @property
    def configured(self) -> bool:
        """Is there a credential to authenticate with?"""
        return bool(self.secret)

    @property
    def connected(self) -> bool:
        return self.connection_status == self.Connection.OK

    @property
    def status(self) -> str:
        """One word for the card: active, inactive, unconfigured or failing."""
        if not self.configured:
            return "unconfigured"
        if not self.is_active:
            return "inactive"
        if self.connection_status == self.Connection.FAILED:
            return "failing"
        return "active"

    @property
    def sendable(self) -> bool:
        """May this account send right now?

        Active and configured. Deliberately not "and connected": an account that
        has never been tested can still be correct, and refusing to send from it
        would make Test Connection a requirement rather than a diagnostic. A
        failed test is different -- that is evidence.
        """
        return (self.is_active and self.configured
                and self.connection_status != self.Connection.FAILED)
