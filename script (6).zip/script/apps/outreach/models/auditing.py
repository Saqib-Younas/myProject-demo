"""
What was measured about a website, and one submitted URL's audit.

`WebsiteAudit` is the per-domain cache: one row per owner per domain, holding the
measured signals, the findings and the scores. Shared deliberately -- an audit run by
hand benefits the leads on that domain, and vice versa.

`AuditJob` is one website somebody pasted in: its state, its progress, the contact
details found and the email drafted from it. It lives here rather than in an
`auditing` app because it is foreign-keyed to `EmailDraft`, `SentLead` and
`EmailAccount` -- the tables are one graph, and splitting them would buy a tidier
tree at the cost of the migration history.
"""

from __future__ import annotations

from django.conf import settings
from django.db import models
from django.utils import timezone


class WebsiteAudit(models.Model):
    """A cached, refreshable audit of one website.

    Keyed on (owner, domain) rather than on a draft, because the expensive part is
    the crawl and two campaigns that both contain the same business should not pay
    for it twice. Opening a lead page reads this row; it does not re-crawl. A new
    audit happens only when the user asks for one, or when this one is older than
    the configured lifetime.

    `signals` is what the crawler measured, and it is the reason every score in
    the application can be explained: the numbers are recomputed from here, so a
    score can always be traced back to a fact.
    """

    class Status(models.TextChoices):
        OK = "ok", "Analysed"
        BLOCKED = "blocked", "Blocked"
        FAILED = "failed", "Failed"
        NO_WEBSITE = "no_website", "No website"

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="website_audits", null=True, blank=True, db_index=True,
    )
    #: Host without "www.", matching SentLead.domain_of, so one site is one row.
    domain = models.CharField(max_length=255, db_index=True)
    #: The address actually analysed, which may differ from the listed one after
    #: redirects. Stored because a finding's evidence has to point somewhere real.
    url = models.URLField(max_length=500, blank=True)

    status = models.CharField(max_length=16, choices=Status.choices,
                              default=Status.OK)
    detail = models.CharField(max_length=400, blank=True)

    #: Measured facts, merged across the pages read. See measurements.measure().
    signals = models.JSONField(default=dict, blank=True)
    #: [{"url", "kind"}, ...] -- which pages the audit is based on.
    pages = models.JSONField(default=list, blank=True)
    pages_discovered = models.PositiveIntegerField(default=0)

    #: Scores recomputed from `signals`, stored so the table can sort on them.
    quality_score = models.PositiveSmallIntegerField(default=0)
    opportunity_score = models.PositiveSmallIntegerField(default=0)
    #: {"performance": {"value", "measured", "factors"}, ...}
    sub_scores = models.JSONField(default=dict, blank=True)

    #: The reviewer's evidenced findings, and its summary of the business.
    findings = models.JSONField(default=list, blank=True)
    business_summary = models.TextField(blank=True)

    analysed_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)
    #: Bumped when the scoring rules change, so a stale score is recognisable.
    scoring_version = models.PositiveSmallIntegerField(default=1)
    #: Which provider and model produced the findings, for the same reason.
    ai_version = models.CharField(max_length=120, blank=True)
    refreshes = models.PositiveSmallIntegerField(default=0)

    class Meta:
        ordering = ("-analysed_at",)
        constraints = [
            models.UniqueConstraint(
                fields=("owner", "domain"),
                name="one_audit_per_domain_per_owner",
            ),
        ]
        indexes = [models.Index(fields=("owner", "status"))]

    def __str__(self) -> str:
        return f"{self.domain} ({self.status}, {self.quality_score}/100)"

    @property
    def usable(self) -> bool:
        return self.status == self.Status.OK and bool(self.pages)

    @property
    def age_days(self) -> int:
        if not self.analysed_at:
            return 0
        return (timezone.now() - self.analysed_at).days

    @property
    def stale(self) -> bool:
        """Old enough that a re-analysis is worth offering.

        Never triggers one on its own -- opening a lead page must not spend money.
        """
        limit = int(getattr(settings, "OUTREACH_AUDIT_MAX_AGE_DAYS", 30))
        return self.age_days >= limit

    @property
    def finding_objects(self) -> list:
        from apps.ai.base import Finding

        return [Finding.from_dict(f) for f in (self.findings or [])]
class AuditJob(models.Model):
    """One website somebody pasted in, and everything that happened to it.

    Separate from the discovery campaigns on purpose. A campaign starts from a
    place and a category and finds businesses; this starts from a URL and audits
    exactly that. Nothing here is ever picked up by the automation worker, and
    nothing here sends without a person pressing the button -- the two workflows
    share their machinery and share none of their decisions.

    The row carries the *state* and the *progress*; the findings and the email live
    on `draft`, because that is where every other part of this application already
    looks for them.
    """

    class State(models.TextChoices):
        """Where the job has got to.

        Ordered as they happen. `CONTACTS_FOUND` and `DRAFT_READY` are moments
        inside one background run rather than places a job rests, and they are
        still separate states because "it found the contact details but the email
        writing failed" is a different thing to see than "it never got past the
        crawl".
        """

        CREATED = "created", "Created"
        QUEUED = "queued", "Queued"
        CRAWLING = "crawling", "Crawling the website"
        ANALYZING = "analyzing", "Analysing what was found"
        CONTACTS_FOUND = "contacts_found", "Contact details found"
        DRAFT_READY = "draft_ready", "Email drafted"
        READY = "ready_for_review", "Ready for review"
        SENT = "sent", "Email sent"
        FAILED = "failed", "Failed"

    #: States a worker may claim. Anything else is finished or in flight.
    CLAIMABLE = ("created", "queued")
    #: States where the machinery is working. A job stuck in one of these after a
    #: restart is picked up again by the next worker pass.
    WORKING = ("crawling", "analyzing", "contacts_found", "draft_ready")
    FINISHED = ("ready_for_review", "sent", "failed")

    class Failure(models.TextChoices):
        """Why a crawl produced nothing usable (§19).

        Named rather than freeform so the screen can say something specific and a
        test can assert which one happened. The detail line carries the rest.
        """

        INVALID = "invalid", "Not a valid website address"
        UNSAFE = "unsafe", "Address not allowed"
        UNREACHABLE = "unreachable", "Website could not be reached"
        TIMEOUT = "timeout", "Website took too long to respond"
        DENIED = "denied", "Access denied by the website"
        ROBOTS = "robots", "Crawling disallowed by robots.txt"
        REDIRECTS = "redirects", "Too many redirects"
        SERVER = "server", "The website returned a server error"
        NOT_HTML = "not_html", "That address is not a web page"
        AI = "ai", "The review could not be completed"
        ERROR = "error", "Unexpected error"

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="audit_jobs", null=True, blank=True)

    #: Exactly what was submitted, kept as typed so the screen can echo it back.
    submitted_url = models.CharField(max_length=500)
    #: The normalised, checked form -- the one that was actually fetched.
    url = models.CharField(max_length=500, blank=True)
    #: Host without `www.`. What "the same site" means for this crawl.
    site = models.CharField(max_length=255, blank=True, db_index=True)

    state = models.CharField(max_length=20, choices=State.choices,
                             default=State.CREATED, db_index=True)
    state_note = models.CharField(max_length=400, blank=True)
    failure = models.CharField(max_length=16, choices=Failure.choices, blank=True)
    error = models.TextField(blank=True)

    # --- progress, written as the crawl happens (§4) ----------------------- #
    pages_found = models.PositiveIntegerField(default=0)
    pages_crawled = models.PositiveIntegerField(default=0)
    #: Which useful page kinds were seen: {"contact": "https://...", ...}. A dict
    #: rather than booleans so the screen can link to the page it found.
    pages_seen = models.JSONField(default=dict, blank=True)

    # --- what came out of it ------------------------------------------------ #
    #: The evidence record: crawl output, findings, subject and body. An
    #: `EmailDraft`, because that is what the rest of the application reads.
    draft = models.OneToOneField(
        "EmailDraft", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="audit_job")
    #: The shared per-domain audit cache, refreshed by this run where it applies.
    audit = models.ForeignKey(
        "WebsiteAudit", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="audit_jobs")

    #: `contacts.Harvest.as_dict()` -- every detail found, with its source page.
    contacts = models.JSONField(default=dict, blank=True)
    #: The address the email will go to. Chosen by ranking, changeable by the user,
    #: and the only address anything is ever sent to.
    recipient = models.EmailField(blank=True)
    #: True once a person typed the address themselves (§17), which is the one way
    #: an address that was never published on the site can get here.
    recipient_manual = models.BooleanField(default=False)
    business_name = models.CharField(max_length=255, blank=True)
    contact_name = models.CharField(max_length=160, blank=True)

    #: True when the crawl worked and the review found nothing worth saying (§18).
    #: Distinct from a failure: the site was read, and it was fine.
    no_findings = models.BooleanField(default=False)

    #: The send, once a person has approved it. `sent_lead` is the history row, and
    #: is what makes a second send impossible.
    sent_lead = models.ForeignKey(
        "SentLead", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="audit_jobs")
    sent_account = models.ForeignKey(
        "EmailAccount", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="audit_jobs")
    message_id = models.CharField(max_length=255, blank=True)
    sent_at = models.DateTimeField(null=True, blank=True)

    #: Which worker is running this job, and until when. Same lease shape as the
    #: automation plans: a worker killed mid-crawl cannot release anything, so the
    #: next one takes over when the lease expires instead of the job being stuck.
    locked_by = models.CharField(max_length=120, blank=True)
    locked_until = models.DateTimeField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    started_at = models.DateTimeField(null=True, blank=True)
    finished_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ("-created_at",)
        indexes = [
            # The worker's query: the next claimable job, oldest first.
            models.Index(fields=("state", "created_at"),
                         name="audit_state_created_idx"),
            models.Index(fields=("owner", "-created_at"),
                         name="audit_owner_time_idx"),
        ]

    def __str__(self) -> str:
        return f"{self.site or self.submitted_url} ({self.state})"

    # --- what the screens ask ---------------------------------------------- #

    @property
    def running(self) -> bool:
        return self.state in self.WORKING or self.state == self.State.QUEUED

    @property
    def reviewable(self) -> bool:
        """Is there something for a person to read and decide about?"""
        return self.state in (self.State.READY, self.State.DRAFT_READY)

    @property
    def is_sent(self) -> bool:
        return self.state == self.State.SENT

    @property
    def failed(self) -> bool:
        return self.state == self.State.FAILED

    @property
    def can_send(self) -> bool:
        """May the Send button do anything?

        A recipient, a subject, a body, and not already sent. Checked again in the
        view against the account and the suppression list -- this is the cheap part,
        for deciding whether to show the button.
        """
        if self.is_sent or not self.recipient or self.draft_id is None:
            return False
        return bool((self.draft.subject or "").strip()
                    and (self.draft.body or "").strip())

    @property
    def findings(self) -> list:
        return self.draft.finding_objects if self.draft_id else []

    @property
    def contact_pages(self) -> list:
        """Pages the contact search looked at, for "no email found" (§17)."""
        return list((self.contacts or {}).get("pages") or [])

    def contact_details(self, kind: str = "") -> list[dict]:
        rows = list((self.contacts or {}).get("details") or [])
        return [row for row in rows if not kind or row.get("kind") == kind]

    @property
    def emails_found(self) -> list[dict]:
        return self.contact_details("email")

    @property
    def progress_percent(self) -> int:
        """A rough fraction, for the status bar. Never above 95 until it is done.

        Deliberately coarse: it is derived from the state, not invented from a
        timer, and a bar that sits at 60% while the AI thinks is more honest than
        one that creeps upwards on its own.
        """
        return {
            self.State.CREATED: 2, self.State.QUEUED: 5,
            self.State.CRAWLING: 35, self.State.ANALYZING: 60,
            self.State.CONTACTS_FOUND: 75, self.State.DRAFT_READY: 90,
            self.State.READY: 100, self.State.SENT: 100,
            self.State.FAILED: 100,
        }.get(self.state, 0)
