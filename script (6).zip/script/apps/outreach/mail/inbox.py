"""
Reads replies to emails this application sent, and nothing else.

The rule that shapes this whole module: an incoming email is only ever looked at
long enough to decide whether it answers something we sent. If it does not match,
it is dropped and nothing about it is stored. There is no mail store here -- a
matched reply contributes a state, a timestamp and a two-line snippet to the row
it answers, which is what the follow-up decision needs and no more.

Matching runs strongest-evidence-first:

  1. **In-Reply-To / References** against the Message-ID we recorded at send
     time. This is proof: the recipient's mail client quoted our own identifier.
  2. **Bounce reports**, which arrive from the mail system rather than the
     recipient, so the original Message-ID is inside the attached report and the
     From header is a daemon. Matched on the quoted id, then on the address.
  3. **Sender address + recent contact**, for clients that strip threading
     headers. Only accepted when we actually emailed that address, and only
     within the lookback window.

A subject line alone is never enough. "Re: A quick idea for ABC Company" is
guessable, and acting on a guess would mark a lead as replied when it has not.

The same account and password as sending -- reply tracking never asks for a
second credential. Reading is blocked outright when OUTREACH_BLOCK_SEND is set,
which is on by default under `manage.py test`: the suite must never touch a real
mailbox.
"""

from __future__ import annotations

import email
import imaplib
import logging
import re
import ssl
from dataclasses import dataclass, field
from datetime import timedelta
from email.header import decode_header, make_header
from email.message import Message
from email.utils import getaddresses, parsedate_to_datetime

from django.conf import settings
from django.utils import timezone

from apps.outreach.models import FollowUp, ReplyState, SentLead, Suppression
from apps.outreach.services import history

from . import providers

log = logging.getLogger(__name__)


class InboxError(RuntimeError):
    """A failure that stops the whole inbox check (auth, connection, config)."""


#: Senders that mean "this is a delivery report", not "the recipient replied".
DAEMONS = ("mailer-daemon", "postmaster", "mail-daemon", "no-reply@",
           "noreply@", "bounce", "bounces@")

#: Subject fragments that mark a delivery failure, for reports whose From
#: header is not one of the daemons above.
BOUNCE_SUBJECTS = ("undelivered mail", "undeliverable", "delivery status",
                   "delivery failure", "delivery has failed",
                   "returned mail", "mail delivery failed",
                   "address not found", "failure notice")

#: Content types used by the standard delivery-report format (RFC 3464).
BOUNCE_TYPES = ("message/delivery-status", "message/rfc822-headers",
                "multipart/report")

#: A reply asking to be taken off the list. Matched on the *reply's* own words,
#: never on the quoted copy of our email -- our own footer says "unsubscribe",
#: so quoting it back must not read as a request.
UNSUBSCRIBE_PHRASES = (
    "unsubscribe", "remove me", "take me off", "opt out", "opt-out",
    "stop emailing", "stop contacting", "do not contact", "don't contact",
    "no longer wish", "not interested in receiving",
)

#: 5.x.x is a permanent failure; 4.x.x is temporary and must not mark a bounce.
_PERMANENT_STATUS = re.compile(r"\b5\.\d{1,3}\.\d{1,3}\b")
_MESSAGE_ID = re.compile(r"<[^<>@\s]+@[^<>@\s]+>")


# --------------------------------------------------------------------------- #
# Header and body helpers
# --------------------------------------------------------------------------- #

def decode(value: str) -> str:
    """Decode an RFC 2047 header into plain text, tolerating malformed input."""
    if not value:
        return ""
    try:
        return str(make_header(decode_header(value)))
    except Exception:  # noqa: BLE001 - a bad header must not stop the check
        return str(value)


def message_ids(message: Message) -> list[str]:
    """Every Message-ID this email quotes, newest reference first."""
    found: list[str] = []
    for header in ("In-Reply-To", "References"):
        for raw in message.get_all(header) or []:
            found.extend(_MESSAGE_ID.findall(raw))
    # A delivery report carries the original headers in an attached part.
    for part in message.walk():
        if part.get_content_type() in BOUNCE_TYPES:
            payload = part.get_payload(decode=False)
            if isinstance(payload, str):
                found.extend(_MESSAGE_ID.findall(payload))
    return list(dict.fromkeys(found))


def sender_address(message: Message) -> str:
    pairs = getaddresses([decode(message.get("From", ""))])
    return (pairs[0][1] if pairs else "").strip().lower()


def plain_text(message: Message, limit: int = 4000) -> str:
    """The reply's own text/plain part, decoded, truncated."""
    if not message.is_multipart():
        if message.get_content_maintype() != "text":
            return ""
        return _decode_part(message)[:limit]

    for part in message.walk():
        if part.get_content_type() == "text/plain" and not part.get_filename():
            text = _decode_part(part)
            if text:
                return text[:limit]
    return ""


def _decode_part(part: Message) -> str:
    try:
        payload = part.get_payload(decode=True)
    except Exception:  # noqa: BLE001
        return ""
    if payload is None:
        return ""
    charset = part.get_content_charset() or "utf-8"
    try:
        return payload.decode(charset, errors="replace")
    except LookupError:
        return payload.decode("utf-8", errors="replace")


def new_text(body: str) -> str:
    """The part of a reply the person actually wrote, without the quoted copy.

    Everything from the first quote marker onwards is dropped. This matters for
    correctness, not tidiness: our own footer invites a reply and mentions
    unsubscribing, so a reply that quotes it would otherwise read as a request to
    be removed.
    """
    lines: list[str] = []
    for line in (body or "").splitlines():
        stripped = line.strip()
        if stripped.startswith(">"):
            break
        # "On Mon, 4 Aug 2025 at 10:12, Sam <sam@x> wrote:"
        if re.match(r"^on .{6,80}\bwrote:\s*$", stripped, re.IGNORECASE):
            break
        if re.match(r"^-{2,}\s*(original message|forwarded message)", stripped,
                    re.IGNORECASE):
            break
        if re.match(r"^(from|sent|to|subject):\s", stripped, re.IGNORECASE) and lines:
            break
        lines.append(line)
    return "\n".join(lines).strip()


def snippet(text: str, limit: int = 400) -> str:
    """One flat line of the reply, for the list view."""
    flat = " ".join((text or "").split())
    return flat[:limit]


def looks_like_bounce(message: Message) -> bool:
    address = sender_address(message)
    if any(mark in address for mark in DAEMONS):
        return True
    subject = decode(message.get("Subject", "")).casefold()
    if any(mark in subject for mark in BOUNCE_SUBJECTS):
        return True
    return message.get_content_type() == "multipart/report"


def is_permanent_bounce(message: Message) -> bool:
    """A 5.x.x status. A 4.x.x is a deferral and must not close the lead."""
    for part in message.walk():
        if part.get_content_type() == "message/delivery-status":
            payload = part.get_payload(decode=False)
            if isinstance(payload, str) and _PERMANENT_STATUS.search(payload):
                return True
    body = plain_text(message)
    return bool(_PERMANENT_STATUS.search(body))


def asks_to_unsubscribe(text: str) -> bool:
    flat = " ".join((text or "").split()).casefold()
    return any(phrase in flat for phrase in UNSUBSCRIBE_PHRASES)


# --------------------------------------------------------------------------- #
# What one incoming email means
# --------------------------------------------------------------------------- #

@dataclass
class Verdict:
    """The outcome of examining one incoming email."""

    #: replied | bounced | unsubscribed | "" when nothing matched.
    state: str = ""
    lead: SentLead | None = None
    followup: FollowUp | None = None
    matched_by: str = ""        # message_id | bounce_report | address
    snippet: str = ""
    received_at: object = None

    @property
    def matched(self) -> bool:
        return bool(self.state and self.lead is not None)


class Matcher:
    """Ties incoming email to what we sent, from one snapshot of the database.

    Built once per inbox check rather than queried per message: a mailbox sweep
    over 200 emails would otherwise be 600 queries.
    """

    def __init__(self, owner=None):
        self.by_message_id: dict[str, tuple[SentLead, FollowUp | None]] = {}
        self.by_address: dict[str, tuple[SentLead, FollowUp | None]] = {}
        self.owner = owner

        # Scoped to the mailbox's owner: a reply in one user's inbox can only be
        # a reply to something that user sent.
        scope = SentLead.objects.exclude(status=SentLead.Status.FAILED)
        if owner is not None and getattr(owner, "pk", None):
            scope = scope.filter(owner=owner)
        leads = list(scope.order_by("-reserved_at"))
        for lead in leads:
            if lead.message_id:
                self.by_message_id.setdefault(lead.message_id.strip(),
                                              (lead, None))
            key = (lead.email or "").strip().lower()
            if key:
                self.by_address.setdefault(key, (lead, None))

        # Follow-ups are registered after the leads and overwrite the address
        # entry, so a reply to the newest message is attributed to it.
        followups = FollowUp.objects.filter(status=FollowUp.Status.SENT)
        if owner is not None and getattr(owner, "pk", None):
            followups = followups.filter(owner=owner)
        for followup in followups.select_related("lead").order_by("sent_at"):
            if followup.message_id:
                self.by_message_id[followup.message_id.strip()] = (
                    followup.lead, followup)
            key = (followup.email or "").strip().lower()
            if key:
                self.by_address[key] = (followup.lead, followup)

    def __len__(self) -> int:
        return len(self.by_message_id)

    def find(self, message: Message) -> tuple[SentLead | None, FollowUp | None, str]:
        """(lead, followup, matched_by). A miss returns (None, None, "")."""
        for quoted in message_ids(message):
            hit = self.by_message_id.get(quoted.strip())
            if hit:
                return hit[0], hit[1], "message_id"

        # A bounce report comes from the mail system, so its From header is a
        # daemon and the recipient's address is in the report body instead.
        if looks_like_bounce(message):
            haystack = " ".join(filter(None, (
                decode(message.get("Subject", "")),
                plain_text(message),
                message.get("X-Failed-Recipients", ""),
            ))).lower()
            for address, hit in self.by_address.items():
                if address in haystack:
                    return hit[0], hit[1], "bounce_report"

        hit = self.by_address.get(sender_address(message))
        if hit:
            return hit[0], hit[1], "address"

        return None, None, ""

    def classify(self, message: Message) -> Verdict:
        """What this email means for the lead it answers, if it answers one."""
        lead, followup, matched_by = self.find(message)
        if lead is None:
            # Not ours. Nothing about it is read further or stored.
            return Verdict()

        try:
            received = parsedate_to_datetime(message.get("Date", ""))
        except (TypeError, ValueError):
            received = None
        if received is not None and timezone.is_naive(received):
            received = timezone.make_aware(received, timezone.utc)

        if looks_like_bounce(message):
            if not is_permanent_bounce(message):
                # A 4.x.x deferral is the mail system retrying, not a dead
                # address. Recording it as bounced would close a live lead.
                return Verdict()
            return Verdict(state=ReplyState.BOUNCED, lead=lead, followup=followup,
                           matched_by=matched_by,
                           snippet=snippet(decode(message.get("Subject", ""))),
                           received_at=received)

        written = new_text(plain_text(message))
        state = (ReplyState.UNSUBSCRIBED if asks_to_unsubscribe(written)
                 else ReplyState.REPLIED)
        return Verdict(state=state, lead=lead, followup=followup,
                       matched_by=matched_by,
                       snippet=snippet(written or decode(message.get("Subject", ""))),
                       received_at=received)


# --------------------------------------------------------------------------- #
# Applying a verdict
# --------------------------------------------------------------------------- #

def apply(verdict: Verdict) -> str:
    """Record a matched verdict. Returns the state applied, or "".

    An unsubscribe request is also added to the do-not-contact list, because a
    reply saying "take me off your list" is exactly what that list is for and
    leaving it to be actioned by hand is how it gets missed.
    """
    if not verdict.matched:
        return ""

    now = verdict.received_at or timezone.now()
    lead, followup = verdict.lead, verdict.followup

    # The state lands on the lead -- follow-up eligibility is a property of the
    # lead, not of whichever message happened to be answered.
    SentLead.objects.filter(pk=lead.pk).update(
        reply_state=verdict.state, replied_at=now,
        reply_snippet=verdict.snippet, checked_at=timezone.now(),
    )
    if followup is not None:
        FollowUp.objects.filter(pk=followup.pk).update(
            reply_state=verdict.state, replied_at=now,
            reply_snippet=verdict.snippet,
        )
        # A drafted follow-up nobody has sent yet is now pointless.
        FollowUp.objects.filter(
            lead=lead, status=FollowUp.Status.DRAFT,
        ).update(status=FollowUp.Status.CANCELLED,
                 error_message=f"Cancelled: the lead {verdict.state}.")
    elif verdict.state in (ReplyState.REPLIED, ReplyState.BOUNCED,
                           ReplyState.UNSUBSCRIBED):
        FollowUp.objects.filter(
            lead=lead, status=FollowUp.Status.DRAFT,
        ).update(status=FollowUp.Status.CANCELLED,
                 error_message=f"Cancelled: the lead {verdict.state}.")

    if verdict.state == ReplyState.UNSUBSCRIBED and lead.email:
        history.suppress(
            lead.owner,
            email=lead.email,
            reason=Suppression.Reason.UNSUBSCRIBED,
            note=f"Asked to be removed: {verdict.snippet[:200]}",
            business_name=lead.business_name,
            campaign_label=lead.campaign_label,
        )
    elif verdict.state == ReplyState.BOUNCED and lead.email:
        history.suppress(
            lead.owner,
            email=lead.email,
            reason=Suppression.Reason.BOUNCED,
            note="Address rejected the message permanently.",
            business_name=lead.business_name,
            campaign_label=lead.campaign_label,
        )

    return verdict.state


# --------------------------------------------------------------------------- #
# IMAP
# --------------------------------------------------------------------------- #

def resolve_imap(provider: providers.Provider, host: str = "",
                 port: int = 0) -> tuple[str, int]:
    host = (host or settings.OUTREACH_IMAP_HOST or provider.imap_host).strip()
    port = int(port or settings.OUTREACH_IMAP_PORT or provider.imap_port or 993)
    if not host:
        raise InboxError(
            "No IMAP host is configured for this provider. Set "
            "OUTREACH_IMAP_HOST (and OUTREACH_IMAP_PORT) to read replies."
        )
    return host, port


class Inbox:
    """A read-only IMAP session over the sending account."""

    def __init__(self, provider: providers.Provider, email_address: str,
                 password: str, host: str = "", port: int = 0):
        self.provider = provider
        self.email = (email_address or "").strip()
        self.password = providers.normalise_password(password)
        self.host, self.port = resolve_imap(provider, host, port)
        self.imap: imaplib.IMAP4_SSL | None = None

        if not self.email:
            raise InboxError("An email address is required to read replies.")
        if not self.password:
            raise InboxError(
                "No password supplied. Set OUTREACH_SMTP_PASSWORD, or enter it "
                "when starting the inbox check."
            )

    def __enter__(self) -> "Inbox":
        # Same reasoning as the SMTP session: real credentials are on disk, so
        # this is the line between a failing test and a real mailbox being read.
        if getattr(settings, "OUTREACH_BLOCK_SEND", False):
            raise InboxError(
                "Mail access is blocked in this environment "
                "(OUTREACH_BLOCK_SEND). No IMAP connection was opened."
            )
        try:
            self.imap = imaplib.IMAP4_SSL(
                self.host, self.port, ssl_context=ssl.create_default_context(),
                timeout=30,
            )
            self.imap.login(self.email, self.password)
            # SELECT rather than EXAMINE would mark messages read; this session
            # never modifies the mailbox.
            self.imap.select("INBOX", readonly=True)
        except imaplib.IMAP4.error as exc:
            raise InboxError(
                f"{self.provider.label} rejected the IMAP login for "
                f"{self.email}. {self.provider.note} IMAP may also need to be "
                "enabled on the account."
            ) from exc
        except OSError as exc:
            raise InboxError(
                f"Could not connect to {self.host}:{self.port} -- {exc}"
            ) from exc
        return self

    def __exit__(self, *exc_info) -> None:
        if self.imap is not None:
            try:
                self.imap.close()
                self.imap.logout()
            except (imaplib.IMAP4.error, OSError):
                pass
            self.imap = None

    def recent(self, days: int) -> list[Message]:
        """Every message received in the last `days`, parsed.

        The window keeps the search cheap and bounds what is examined at all.
        """
        if self.imap is None:
            raise InboxError("IMAP session is not open.")

        since = (timezone.localtime() - timedelta(days=max(1, days)))
        criterion = f'(SINCE "{since.strftime("%d-%b-%Y")}")'
        try:
            status, data = self.imap.search(None, criterion)
            if status != "OK":
                raise InboxError(f"IMAP search failed: {status}")
            messages = []
            for uid in (data[0].split() if data and data[0] else []):
                status, payload = self.imap.fetch(uid, "(RFC822)")
                if status != "OK" or not payload:
                    continue
                for part in payload:
                    if isinstance(part, tuple) and part[1]:
                        messages.append(email.message_from_bytes(part[1]))
                        break
            return messages
        except imaplib.IMAP4.error as exc:
            raise InboxError(f"Could not read the inbox: {exc}") from exc


@dataclass
class CheckResult:
    """What one inbox check did. Counts only, plus the leads it changed."""

    examined: int = 0
    matched: int = 0
    replied: int = 0
    bounced: int = 0
    unsubscribed: int = 0
    ignored: int = 0
    changed: list[str] = field(default_factory=list)

    def summary(self) -> str:
        if not self.matched:
            return (f"Checked {self.examined} recent message(s); none were "
                    "replies to emails sent from here.")
        bits = []
        if self.replied:
            bits.append(f"{self.replied} repl{'y' if self.replied == 1 else 'ies'}")
        if self.bounced:
            bits.append(f"{self.bounced} bounced")
        if self.unsubscribed:
            bits.append(f"{self.unsubscribed} asked to be removed")
        return (f"Checked {self.examined} recent message(s): " +
                ", ".join(bits) + ".")


def check(*, password: str, owner=None, email_address: str = "",
          provider_key: str = "", days: int = 0, host: str = "",
          port: int = 0) -> CheckResult:
    """Read the inbox once and record what came back.

    Never sends anything, never marks anything read, and never stores an email
    that does not match something we sent.
    """
    email_address = email_address or settings.OUTREACH_SENDER_EMAIL
    provider = providers.provider_for(provider_key or settings.OUTREACH_PROVIDER)
    days = days or settings.OUTREACH_INBOX_DAYS

    matcher = Matcher(owner)
    result = CheckResult()
    if not len(matcher) and not matcher.by_address:
        return result       # nothing has been sent, so nothing can be a reply

    with Inbox(provider, email_address, password, host=host, port=port) as box:
        messages = box.recent(days)

    ours = (email_address or "").strip().lower()
    for message in messages:
        result.examined += 1
        if sender_address(message) == ours:
            # Our own copy in a shared mailbox. Not a reply.
            result.ignored += 1
            continue

        verdict = matcher.classify(message)
        if not verdict.matched:
            result.ignored += 1
            continue

        state = apply(verdict)
        if not state:
            result.ignored += 1
            continue

        result.matched += 1
        if state == ReplyState.REPLIED:
            result.replied += 1
        elif state == ReplyState.BOUNCED:
            result.bounced += 1
        elif state == ReplyState.UNSUBSCRIBED:
            result.unsubscribed += 1
        if verdict.lead.business_name not in result.changed:
            result.changed.append(verdict.lead.business_name)

    checked = SentLead.objects.exclude(status=SentLead.Status.FAILED)
    if owner is not None and getattr(owner, "pk", None):
        checked = checked.filter(owner=owner)
    checked.update(checked_at=timezone.now())
    return result
