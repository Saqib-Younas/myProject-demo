"""
Building one message.

Pure functions over strings: no socket, no settings, nothing to mock. That is why this
is its own module -- every rule about what an outgoing email contains can be tested
without a mail server, and the rules are worth testing.

`build_message` is the single funnel every outgoing email passes through, which is why
the unsubscribe header and the threading headers are added here rather than by
each caller. Nothing is appended to the body. Its `From` header is built from the authenticated address
and there is no parameter that could change that.
"""

from __future__ import annotations

from email.message import EmailMessage
from email.utils import formataddr, formatdate, make_msgid


# There is no standing reply invitation, deliberately.
#
# A line reading "If you're interested, simply reply to this email and our team will get
# back to you within 24 hours." used to be appended to every message here. It was
# removed: on a personal first contact it reads as a template, it promises a response
# time nobody agreed to, and it says "our team" in an email signed by one person. The
# message already closes with the sender's name, from a mailbox the recipient can reply
# to -- that is the invitation.
#
# The opt-out is unaffected. That is the `List-Unsubscribe` header in `build_message`
# plus `inbox.asks_to_unsubscribe` acting on a reply, and neither ever depended on this.
def _flat(value: str) -> str:
    """Whitespace-insensitive, case-insensitive form, for containment checks."""
    return " ".join((value or "").split()).casefold()
def with_signature(body: str, signature: str) -> str:
    """Append an email account's signature, exactly once.

    Idempotent: a user who has
    already worked the signature into the body while editing keeps it where they
    put it rather than getting a second copy underneath.

    An empty signature returns the body untouched, which is the common case -- the
    generated email already closes with the sender's name.
    """
    text = (body or "").rstrip()
    signature = (signature or "").strip()
    if not signature:
        return text
    if _flat(signature) in _flat(text):
        return text
    return f"{text}\n\n{signature}"
def build_message(*, sender_name: str, sender_email: str, to_email: str,
                  subject: str, body: str, reply_to: str = "",
                  in_reply_to: str = "", references: str = "") -> EmailMessage:
    """Build one plain-text message from the authenticated identity.

    From is always the authenticated address -- there is no parameter that
    would let a caller put someone else's address in it.

    This is the single funnel every outgoing email passes through, which is why
    the reply invitation, the unsubscribe header and the threading headers are all
    added here rather than by each caller.

    `in_reply_to` and `references` are what put a follow-up in the same
    conversation as the email it follows (§16). Without them a recipient sees three
    unrelated emails from a stranger instead of one thread with two nudges, and the
    reply matching that depends on Message-IDs has nothing to work with.
    """
    message = EmailMessage()
    message["From"] = formataddr((sender_name or sender_email, sender_email))
    message["To"] = to_email
    message["Subject"] = subject
    message["Date"] = formatdate(localtime=True)
    message["Message-ID"] = make_msgid(domain=sender_email.split("@")[-1])

    # A Reply-To only where it differs from the sender. Setting it to the same
    # address is noise, and some filters read a redundant Reply-To as a signal.
    reply_to = (reply_to or "").strip()
    if reply_to and reply_to.casefold() != sender_email.casefold():
        message["Reply-To"] = reply_to

    # Threading. Both headers, because clients disagree about which they honour:
    # In-Reply-To is the parent, References is the chain, and a thread survives
    # better with both than with either.
    in_reply_to = (in_reply_to or "").strip()
    if in_reply_to:
        message["In-Reply-To"] = in_reply_to
    references = (references or "").strip()
    if references:
        message["References"] = references
    elif in_reply_to:
        message["References"] = in_reply_to

    # Cold outreach should always offer a way out.
    message["List-Unsubscribe"] = f"<mailto:{sender_email}?subject=unsubscribe>"

    # No `Auto-Submitted` header, deliberately.
    #
    # It used to be set to `auto-generated` here, on the reasoning that the message is
    # assembled by a program. That reading is wrong for this application, and the header
    # was doing real harm:
    #
    #   * RFC 3834 defines `Auto-Submitted: auto-generated` for messages a *responder*
    #     produces -- vacation replies, bounces, notifications. Its purpose is to stop
    #     mail loops between two automatons. These emails are not that: each one is a
    #     first contact addressed to a person, sent from a mailbox that person can reply
    #     to, and the reply is read by a human.
    #   * Some receiving systems treat the header as "do not reply to this" and suppress
    #     auto-replies, and some filters weigh it as a bulk-mail signal. Both are the
    #     opposite of what a personal cold email wants.
    #
    # Nothing in this project reads it -- reply matching uses `Message-ID`, and
    # unsubscribe handling uses `List-Unsubscribe` plus the reply text -- so it was
    # costing deliverability and buying nothing. `test_mail.py` asserts it stays absent
    # so it does not come back on the same faulty reasoning.
    # The body as written and approved. Nothing is appended to it -- see the
    # note at the top of this module.
    message.set_content(body)
    return message
