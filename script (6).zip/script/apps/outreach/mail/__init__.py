"""Everything about an email except deciding to send one.
from . import transport
from . import providers
from . import compose

    accounts.py    which mailboxes exist, their limits, their encrypted passwords
    providers.py   the provider table: hosts, ports, pacing, daily ceilings
    compose.py     building one message: headers, signature, reply line, threading
    transport.py   the authenticated SMTP session, and the only place `sendmail` is
                   called
    followups.py   when the next message is due, and what it may say
    inbox.py       reading replies and bounces, read-only
    auditsend.py   sending one website audit's email, after a person approves it

Two invariants worth stating because they are enforced here rather than hoped for:

  * **The From header is always the authenticated address.** `compose.build_message`
    takes no parameter that could put somebody else's address in it.
  * **Nothing here decides to send.** `transport.Session.send` is called by a
    service, and every one of those calls is behind either a person's click or a
    campaign the person configured."""
