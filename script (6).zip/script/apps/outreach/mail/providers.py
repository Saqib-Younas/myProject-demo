"""
The mail providers this application knows how to talk to.

Hosts, ports, and two numbers per provider that matter more than they look: the delay
between messages and the daily ceiling. Both are set *below* each provider's published
limit, because the published limit is where they start refusing and a campaign that
reaches it has already been noticed.

`normalise_password` exists for Gmail: an app password is shown in four groups of four
and pasted with the spaces in, which SMTP rejects.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from .errors import SendError


@dataclass(frozen=True)
class Provider:
    key: str
    label: str
    host: str
    port: int
    delay: float          # seconds to wait between messages
    daily_cap: int        # conservative per-day ceiling for one account
    note: str
    #: Where to read replies for this provider. Same account, same password --
    #: reply tracking never needs a second credential.
    imap_host: str = ""
    imap_port: int = 993
#: Delays and caps are deliberately below each provider's published ceiling.
PROVIDERS: dict[str, Provider] = {
    "gmail": Provider(
        "gmail", "Gmail / Google Workspace", "smtp.gmail.com", 587,
        delay=2.5, daily_cap=400,
        note="Needs an App Password (Google blocks plain passwords on SMTP). "
             "Free Gmail allows ~500/day, Workspace ~2000; capped at 400 here.",
        imap_host="imap.gmail.com",
    ),
    "outlook": Provider(
        "outlook", "Outlook / Microsoft 365", "smtp.office365.com", 587,
        delay=3.5, daily_cap=250,
        note="Microsoft 365 throttles at ~30 recipients/minute and 10,000/day; "
             "capped at 250 here. Basic auth may need an app password.",
        imap_host="outlook.office365.com",
    ),
    "zoho": Provider(
        "zoho", "Zoho Mail", "smtp.zoho.com", 587,
        delay=3.0, daily_cap=200,
        note="Zoho's per-day limit depends on plan; capped at 200 here.",
        imap_host="imap.zoho.com",
    ),
    "fastmail": Provider(
        "fastmail", "Fastmail", "smtp.fastmail.com", 587,
        delay=2.5, daily_cap=300,
        note="Requires an app password.",
        imap_host="imap.fastmail.com",
    ),
    "custom": Provider(
        "custom", "Other SMTP server", "", 587,
        delay=3.0, daily_cap=200,
        note="Set OUTREACH_SMTP_HOST and OUTREACH_SMTP_PORT for your server.",
        imap_host="",
    ),
}
DEFAULT_PROVIDER = "gmail"
#: A Gmail App Password as Google displays it: four groups of four letters.
_APP_PASSWORD = re.compile(r"^[a-z]{4}(?:\s[a-z]{4}){3}$", re.IGNORECASE)
def normalise_password(password: str) -> str:
    """Trim a pasted password, and de-space a Gmail App Password.

    Google shows app passwords as `abcd efgh ijkl mnop` but expects the 16
    characters with no spaces, so a straight copy-paste would otherwise fail to
    authenticate. Only that exact shape is de-spaced -- a real password that
    happens to contain a space is left alone.
    """
    password = (password or "").strip()
    if _APP_PASSWORD.match(password):
        return password.replace(" ", "")
    return password
def provider_for(key: str) -> Provider:
    try:
        return PROVIDERS[key]
    except KeyError:
        raise SendError(f"Unknown email provider {key!r}.") from None
def resolve_host(provider: Provider, host: str = "", port: int = 0) -> tuple[str, int]:
    """Custom providers need an explicit host; presets carry their own."""
    host = (host or provider.host).strip()
    port = int(port or provider.port)
    if not host:
        raise SendError(
            "This provider needs an SMTP host. Set OUTREACH_SMTP_HOST (and "
            "OUTREACH_SMTP_PORT) or pick a preset provider."
        )
    return host, port
