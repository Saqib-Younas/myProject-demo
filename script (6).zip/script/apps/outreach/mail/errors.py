"""
What can go wrong when sending, as one exception.

Its own module because both halves of the package raise it: `providers` when a host or
a password is unusable, `transport` when a login is refused or a connection drops.
Either importing the other would be a cycle, and a shared failure type is the ordinary
answer.

`SendError`'s message is always written for a person -- it is shown on the send screen,
not logged and forgotten -- which is why it carries a sentence rather than a code.
"""

from __future__ import annotations


class SendError(RuntimeError):
    """A failure that stops the whole run (auth, connection, configuration)."""
