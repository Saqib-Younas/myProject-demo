"""
Email accounts: which address a campaign sends from, and whether it may.

One module answers that, for the same reason `credentials.py` is the only thing
that resolves an AI key: the question "may this send?" has six parts, and six
call sites each answering it slightly differently is how an inactive account ends
up sending.

The parent is the signed-in workspace; the children are its addresses. Several may
be active at once -- a campaign can legitimately send from two mailboxes -- which is
the one place this differs from the AI credential pool.

**Secrets.** The password is Fernet ciphertext, encrypted with the same helpers the
AI credentials use, because one crypto implementation is easier to keep correct than
two. `hint` is the only form of it that leaves the server. Nothing here returns a
password, and `account_status()` is the shape a browser is allowed to see.

**Selection is not permission.** A campaign records which accounts it may use;
`sending_accounts()` re-checks active, configured and under-limit at send time.
An account switched off between setup and sending must not send, and that is
enforced here rather than trusted to the UI.
"""

from __future__ import annotations

import logging

from django.conf import settings as django_settings
from django.db import models, transaction
from django.utils import timezone

from apps.ai.credentials import CredentialError, decrypt, encrypt, mask
from apps.outreach.mail import transport

from . import providers

log = logging.getLogger(__name__)


class AccountError(RuntimeError):
    """A problem with an email account. Never contains a password."""


class NoSendingAccount(AccountError):
    """Nothing is available to send from, and the reason is worth showing."""


# --------------------------------------------------------------------------- #
# Reading
# --------------------------------------------------------------------------- #

def accounts(owner):
    """Every email account this workspace owns, active first."""
    from apps.outreach.models import EmailAccount

    if owner is None or not getattr(owner, "pk", None):
        return EmailAccount.objects.none()
    return EmailAccount.objects.filter(owner=owner)


def active(owner):
    return accounts(owner).filter(is_active=True)


def for_campaign(campaign):
    """The accounts a campaign is allowed to use, as configured.

    Not the ones it may use *now* -- see `sending_accounts` for that. This is the
    stored selection, which is what the setup screen shows and what survives an
    account being switched off.
    """
    if campaign is None or not campaign.pk:
        return []
    return list(campaign.sending_accounts.all())


def sending_accounts(campaign) -> list:
    """The accounts that may send for this campaign right now.

    Every gate from §4, applied here so no caller has to remember them:

      * the account still exists (a deleted one drops out of the relation);
      * it is active -- an account switched off mid-campaign stops sending
        without any history being touched;
      * it has a credential to authenticate with;
      * its last connection test did not fail;
      * it is under its daily limit.

    Empty is a normal answer, and the caller is expected to explain it rather than
    fall back to something the user did not choose.
    """
    return [
        account for account in for_campaign(campaign)
        if account.sendable and remaining_today(account) > 0
    ]


def selection_report(campaign) -> dict:
    """Why the accounts that cannot send cannot send.

    Built for the screen that has to explain "you selected three accounts and none
    of them can send", which is otherwise the most confusing state in the feature.
    """
    rows = []
    for account in for_campaign(campaign):
        if not account.is_active:
            reason = "inactive"
        elif not account.configured:
            reason = "no credential saved"
        elif account.connection_status == account.Connection.FAILED:
            reason = "the last connection test failed"
        elif remaining_today(account) <= 0:
            reason = "today's sending limit is used up"
        else:
            reason = ""
        rows.append({
            "account": account,
            "usable": not reason,
            "reason": reason,
            "remaining": remaining_today(account),
        })
    usable = [row for row in rows if row["usable"]]
    return {
        "rows": rows,
        "selected": len(rows),
        "usable": len(usable),
        "capacity": sum(row["remaining"] for row in usable),
    }


# --------------------------------------------------------------------------- #
# Limits
# --------------------------------------------------------------------------- #

def provider_of(account) -> providers.Provider:
    """The provider preset behind an account, falling back to `custom`."""
    return providers.PROVIDERS.get(account.provider) or providers.PROVIDERS["custom"]


def daily_cap(account) -> int:
    """How many this account may send today.

    The account's own limit where it is lower than the provider's, never higher:
    the provider's cap is not ours to raise, and pretending otherwise just moves
    the failure from our code to theirs.
    """
    preset = provider_of(account).daily_cap
    if account.daily_limit and account.daily_limit < preset:
        return account.daily_limit
    return preset


def sent_today(account) -> int:
    """Sends recorded for this address today, from the history table.

    Counted from `SentLead` rather than a counter on the account, so it survives a
    restart and cannot drift: the send history is the record, and a number kept
    beside it is a second answer waiting to disagree.
    """
    from apps.outreach.models import SentLead

    start = timezone.localtime().replace(hour=0, minute=0, second=0,
                                        microsecond=0)
    return SentLead.objects.filter(
        owner=account.owner,
        sender_email__iexact=account.sender_email,
        status=SentLead.Status.SENT,
        reserved_at__gte=start,
    ).count()


def remaining_today(account) -> int:
    return max(0, daily_cap(account) - sent_today(account))


# --------------------------------------------------------------------------- #
# Writing
# --------------------------------------------------------------------------- #

@transaction.atomic
def save_account(owner, *, name: str, sender_name: str, sender_email: str,
                 provider: str, password: str = "", account=None, **fields):
    """Create or update one account. The password is encrypted or left alone.

    An empty password on an update keeps the stored one -- the form cannot show it,
    so an empty field means "unchanged" rather than "clear it". Clearing is a
    separate, deliberate action.
    """
    from apps.outreach.models import EmailAccount

    if owner is None or not getattr(owner, "pk", None):
        raise AccountError("Email accounts belong to an account. Sign in first.")

    name = (name or "").strip()
    sender_email = (sender_email or "").strip().lower()
    if not name:
        raise AccountError("Give the account a name.")
    if not sender_email:
        raise AccountError("Enter the sender email address.")
    if provider not in providers.PROVIDERS:
        raise AccountError(
            "Choose an email provider: "
            + ", ".join(sorted(providers.PROVIDERS)) + ".")

    username = (fields.get("username") or "").strip().lower()
    if username and username != sender_email:
        # The anti-spoofing rule, enforced at the point of saving as well as at
        # the point of sending. The visible sender is the authenticated account.
        raise AccountError(
            f"The login ({username}) must match the sender address "
            f"({sender_email}). Sending as an address you have not "
            "authenticated is spoofing and is not supported."
        )

    values = {
        "name": name,
        "sender_name": (sender_name or "").strip(),
        "sender_email": sender_email,
        "provider": provider,
        "username": username,
        "smtp_host": (fields.get("smtp_host") or "").strip(),
        "smtp_port": fields.get("smtp_port") or None,
        "imap_host": (fields.get("imap_host") or "").strip(),
        "imap_port": fields.get("imap_port") or None,
        "signature": (fields.get("signature") or "").strip(),
        "reply_to": (fields.get("reply_to") or "").strip().lower(),
        "daily_limit": int(fields.get("daily_limit") or 0),
        "followup_max": int(fields.get("followup_max") or 0),
        "followup_delays": (fields.get("followup_delays") or "").strip(),
        "is_active": bool(fields.get("is_active", True)),
    }

    if password.strip():
        try:
            values["secret"] = encrypt(providers.normalise_password(password))
        except CredentialError as exc:
            raise AccountError(str(exc)) from exc
        values["hint"] = mask(providers.normalise_password(password))
        # A new credential invalidates the old verdict.
        values["connection_status"] = EmailAccount.Connection.UNTESTED
        values["connection_detail"] = ""

    if account is None:
        account = EmailAccount.objects.create(owner=owner, **values)
        log.info("email account %s created for %s", account.pk, owner.pk)
        return account

    for key, value in values.items():
        setattr(account, key, value)
    account.save()
    log.info("email account %s updated", account.pk)
    return account


def set_active(owner, account, enabled: bool):
    """Switch an account on or off.

    Off is not deletion. Sent history, scheduled follow-ups and reply state all
    survive; only future sends stop, which is what §2 asks for.
    """
    if account.owner_id != getattr(owner, "pk", None):
        raise AccountError("That account belongs to another workspace.")

    account.is_active = bool(enabled)
    account.save(update_fields=["is_active", "updated_at"])
    return account


def clear_secret(owner, account):
    """Forget the stored password without deleting the account."""
    if account.owner_id != getattr(owner, "pk", None):
        raise AccountError("That account belongs to another workspace.")

    from apps.outreach.models import EmailAccount

    account.secret = ""
    account.hint = ""
    account.connection_status = EmailAccount.Connection.UNTESTED
    account.connection_detail = ""
    account.save(update_fields=["secret", "hint", "connection_status",
                                "connection_detail", "updated_at"])
    return account


def password_of(account) -> str:
    """The decrypted password. Server-side callers only.

    Returns "" when there is nothing stored or the value cannot be read -- a
    rotated DJANGO_SECRET_KEY -- so the caller reports a configuration problem
    rather than crashing a send mid-run.
    """
    if not account.secret:
        return ""
    return decrypt(account.secret)


# --------------------------------------------------------------------------- #
# The connection test
# --------------------------------------------------------------------------- #

def test_connection(owner, account) -> tuple[str, str]:
    """Authenticate against SMTP without sending anything. (status, message).

    Statuses are `ok`, `failed` and `blocked`. The message is written here, never
    passed through from the server: an SMTP rejection can quote the credentials it
    was handed.

    IMAP is checked too where the account is configured for it, because reply
    tracking depends on it and a mailbox that cannot be opened is worth knowing
    about before a campaign runs rather than after.
    """
    from apps.outreach.models import EmailAccount

    if account.owner_id != getattr(owner, "pk", None):
        raise AccountError("That account belongs to another workspace.")

    if getattr(django_settings, "OUTREACH_BLOCK_SEND", False):
        # The same switch that blocks sending and inbox reading. A connection test
        # opens a real authenticated session, so it is refused here rather than
        # quietly made -- which is also what keeps the test suite offline.
        return _record(account, EmailAccount.Connection.BLOCKED,
                       "Not tested: outbound connections are blocked in this "
                       "environment (OUTREACH_BLOCK_SEND).")

    password = password_of(account)
    if not password:
        return _record(
            account, EmailAccount.Connection.FAILED,
            "No password is stored for this account"
            + (", or it cannot be decrypted because DJANGO_SECRET_KEY changed."
               if account.secret else ". Add one and try again."))

    provider = provider_of(account)
    try:
        session = transport.Session(
            provider, account.sender_email, password,
            host=account.smtp_host, port=account.smtp_port or 0,
            username=account.username or account.sender_email,
        )
        with session:
            pass                      # connecting and authenticating is the test
    except transport.SendError as exc:
        # SendError is written by our own code and is safe to show. It names the
        # host and the login, never the password.
        return _record(account, EmailAccount.Connection.FAILED, str(exc)[:300])
    except Exception:                 # noqa: BLE001 - never leak a library string
        log.exception("email account %s failed its connection test", account.pk)
        return _record(
            account, EmailAccount.Connection.FAILED,
            "The connection failed for an unexpected reason. The server log has "
            "the details.")

    imap_note = _test_imap(account, password)
    return _record(account, EmailAccount.Connection.OK,
                   f"Connected successfully.{imap_note}")


def _test_imap(account, password: str) -> str:
    """Open the mailbox read-only, if reply tracking is configured for it."""
    from apps.outreach.mail import inbox

    try:
        host, port = inbox.resolve_imap(provider_of(account))
    except inbox.InboxError:
        return ""
    if account.imap_host:
        host, port = account.imap_host, account.imap_port or port
    if not host:
        return ""

    try:
        import imaplib

        with imaplib.IMAP4_SSL(host, port, timeout=30) as mailbox:
            mailbox.login(account.username or account.sender_email, password)
            mailbox.select("INBOX", readonly=True)
        return " Mailbox access works too, so reply tracking will run."
    except Exception:  # noqa: BLE001 - a mailbox problem is not a send problem
        log.info("email account %s: IMAP check failed", account.pk)
        return (" Sending works, but the mailbox could not be opened -- reply "
                "tracking will not run for this account.")


def _record(account, status: str, message: str) -> tuple[str, str]:
    """Store the verdict, and return it."""
    from apps.outreach.models import EmailAccount

    now = timezone.now()
    account.connection_status = status
    account.connection_detail = message[:300]
    account.last_tested_at = now
    fields = ["connection_status", "connection_detail", "last_tested_at",
              "updated_at"]

    if status == EmailAccount.Connection.OK:
        account.last_success_at = now
        account.last_error = ""
        fields += ["last_success_at", "last_error"]
    elif status == EmailAccount.Connection.FAILED:
        account.last_error_at = now
        account.last_error = message[:300]
        fields += ["last_error_at", "last_error"]

    account.save(update_fields=fields)
    return status, message


def note_success(account) -> None:
    """Count one delivered message against this account.

    An F() expression, not a read and a write: two workers sending at the same
    moment would otherwise both read 41 and both write 42.
    """
    if account is None:
        return
    from apps.outreach.models import EmailAccount

    EmailAccount.objects.filter(pk=account.pk).update(
        sent_count=models.F("sent_count") + 1,
        last_success_at=timezone.now(),
    )


def note_failure(account, detail: str = "") -> None:
    """Count one failed message, and keep the reason.

    The connection verdict is deliberately left alone. One refused recipient does
    not mean the account cannot authenticate, and marking it failed here would stop
    the account being used at all -- for something that was the recipient's problem.
    """
    if account is None:
        return
    from apps.outreach.models import EmailAccount

    EmailAccount.objects.filter(pk=account.pk).update(
        failed_count=models.F("failed_count") + 1,
        last_error_at=timezone.now(),
        last_error=(detail or "")[:300],
    )


# --------------------------------------------------------------------------- #
# Status, for the UI. Never carries a password.
# --------------------------------------------------------------------------- #

def account_status(account) -> dict:
    """Everything the browser may know about one account.

    The masked hint, the limits, the counters and the timestamps -- and no
    password. This is the only shape a browser ever receives.
    """
    return {
        "id": account.pk,
        "name": account.name,
        "sender_name": account.sender_name,
        "sender_email": account.sender_email,
        "reply_to": account.reply_to,
        "provider": account.provider,
        "provider_label": provider_of(account).label,
        "masked": account.hint or "",
        "configured": account.configured,
        "is_active": account.is_active,
        "status": account.status,
        "sendable": account.sendable,
        "connection_status": account.connection_status,
        "connection_detail": account.connection_detail,
        "daily_cap": daily_cap(account),
        "sent_today": sent_today(account),
        "remaining_today": remaining_today(account),
        "sent_count": account.sent_count,
        "failed_count": account.failed_count,
        "auth_kind": account.auth_kind,
        "signature": bool(account.signature),
        "created_at": account.created_at.isoformat() if account.created_at else None,
        "last_tested_at": (account.last_tested_at.isoformat()
                           if account.last_tested_at else None),
        "last_success_at": (account.last_success_at.isoformat()
                            if account.last_success_at else None),
        "last_error": account.last_error,
    }


def editable_fields(account) -> dict:
    """The values an edit form fills itself from. Never the password.

    Separate from `account_status()` on purpose. That one is the card payload -- small,
    sent on every repaint, and documented as carrying no password. This one is fetched
    only when somebody opens the form, and carries the things a card has no use for: the
    signature text, the custom host and port, and the raw per-account limits.

    `daily_limit` here is the *stored* value, which is not `account_status()`'s
    `daily_cap`: the cap is the effective ceiling after the provider's own preset is
    applied, and showing that in an editable field would silently rewrite a blank
    "use the provider default" into a hard number the next time the form was saved.

    There is no password and no parameter that could ask for one. An empty password field
    on save keeps the stored one, so nothing needs to be sent back.
    """
    return {
        "id": account.pk,
        "name": account.name,
        "sender_name": account.sender_name,
        "sender_email": account.sender_email,
        "username": account.username,
        "provider": account.provider,
        "reply_to": account.reply_to,
        "signature": account.signature,
        "smtp_host": account.smtp_host,
        "smtp_port": account.smtp_port or "",
        "imap_host": account.imap_host,
        "imap_port": account.imap_port or "",
        # The stored value, blank meaning "use the provider preset".
        "daily_limit": account.daily_limit or "",
        "followup_max": account.followup_max or "",
        "followup_delays": account.followup_delays,
        "is_active": account.is_active,
        # So the form can say "leave blank to keep the stored password" rather than
        # demanding one, and show which password it means.
        "configured": account.configured,
        "masked": account.hint or "",
    }


def all_statuses(owner) -> list[dict]:
    return [account_status(row) for row in accounts(owner)]


def summary(owner) -> dict:
    """The workspace's sending capacity, for the settings header."""
    rows = list(accounts(owner))
    usable = [row for row in rows if row.sendable]
    return {
        "total": len(rows),
        "active": sum(1 for row in rows if row.is_active),
        "usable": len(usable),
        "capacity": sum(remaining_today(row) for row in usable),
    }
