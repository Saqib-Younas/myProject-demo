"""
The authenticated SMTP connection, and the only place a message is handed over.

One session per run of sends, opened lazily and closed with the run. Everything about
*what* is sent lives in `compose`; this module is the socket, the login and the
failure modes -- which are the parts that need a real mail server to exercise and are
therefore kept as small as they can be.

Two refusals are built in:

  * **The visible sender must be the login.** Sending as an address you have not
    authenticated is spoofing, and `Session` will not construct.
  * **`OUTREACH_BLOCK_SEND` stops the connection being opened at all.** On by default
    under `manage.py test`, because real credentials live in `.env` and the line
    between a failing test and mail leaving the building should not be a mock nobody
    forgot.
"""

from __future__ import annotations

import smtplib
import ssl

from .compose import build_message

# Re-exported: callers and `except` clauses say `transport.SendError`, and the
# class is shared with `providers`.
from .errors import SendError
from .providers import Provider, normalise_password, resolve_host


class Session:
    """An authenticated SMTP connection for one send run."""

    def __init__(self, provider: Provider, sender_email: str, password: str,
                 host: str = "", port: int = 0, username: str = ""):
        self.provider = provider
        self.sender_email = sender_email.strip()
        self.username = (username or self.sender_email).strip()
        self.password = normalise_password(password)
        self.host, self.port = resolve_host(provider, host, port)
        self.smtp: smtplib.SMTP | None = None

        if not self.sender_email:
            raise SendError("A sender email address is required.")
        if not self.password:
            raise SendError(
                "No SMTP password supplied. Enter it when starting the send, or "
                "set OUTREACH_SMTP_PASSWORD in the environment."
            )
        # The anti-spoofing rule: the visible sender is the logged-in account.
        if self.username.casefold() != self.sender_email.casefold():
            raise SendError(
                f"The sender address ({self.sender_email}) must be the same as "
                f"the SMTP login ({self.username}). Sending as an address you "
                "have not authenticated is spoofing and is not supported."
            )

    def __enter__(self) -> "Session":
        # Refuse to reach the network when sending is blocked (default under
        # `manage.py test`). Real credentials are on disk, so this is the line
        # between a failing test and mail leaving the building.
        from django.conf import settings as django_settings

        if getattr(django_settings, "OUTREACH_BLOCK_SEND", False):
            raise SendError(
                "Sending is blocked in this environment (OUTREACH_BLOCK_SEND). "
                "No SMTP connection was opened."
            )

        try:
            if self.port == 465:
                self.smtp = smtplib.SMTP_SSL(
                    self.host, self.port, timeout=30,
                    context=ssl.create_default_context(),
                )
            else:
                self.smtp = smtplib.SMTP(self.host, self.port, timeout=30)
                self.smtp.ehlo()
                self.smtp.starttls(context=ssl.create_default_context())
                self.smtp.ehlo()
            self.smtp.login(self.username, self.password)
        except smtplib.SMTPAuthenticationError as exc:
            raise SendError(
                f"{self.provider.label} rejected the login for "
                f"{self.username}. {self.provider.note}"
            ) from exc
        except (smtplib.SMTPException, OSError) as exc:
            raise SendError(
                f"Could not connect to {self.host}:{self.port} -- {exc}"
            ) from exc
        return self

    def __exit__(self, *exc_info) -> None:
        if self.smtp is not None:
            try:
                self.smtp.quit()
            except smtplib.SMTPException:
                pass
            self.smtp = None

    def send(self, *, to_email: str, subject: str, body: str,
             sender_name: str, reply_to: str = "", in_reply_to: str = "",
             references: str = "") -> str:
        """Send one message and return its Message-ID.

        The Message-ID is what a reply quotes in In-Reply-To/References, so it is
        the only reliable way to tie an incoming email back to the one we sent.
        Storing it is what makes reply tracking work on more than a guess.
        """
        if self.smtp is None:
            raise SendError("SMTP session is not open.")
        message = build_message(
            sender_name=sender_name, sender_email=self.sender_email,
            to_email=to_email, subject=subject, body=body,
            reply_to=reply_to, in_reply_to=in_reply_to, references=references,
        )
        self.smtp.send_message(message)
        return message["Message-ID"] or ""
