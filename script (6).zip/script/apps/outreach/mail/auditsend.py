"""
Sending one audit's email, after a person has approved it.

A separate module from `siteaudit` on purpose. That one crawls, analyses and drafts,
and the claim it makes -- that there is no path from it to SMTP -- has to be true by
construction rather than by discipline. So the send lives here, it is called by one
view, and that view only calls it when the request carries an explicit confirmation.

Everything it does is the existing send path:

    history.reserve         claims the address, and is the duplicate lock
    mailaccounts.password_of decrypts the account's own credential
    transport.Session          the authenticated SMTP connection
    record.mark_sent        the history row, with the provider's message id

The order matters and is the same order the campaign send uses: reserve first, send
second, mark third. Reserving before sending means a second click, a second worker or
a retried request finds the address taken and stops -- and reserving something that
then fails to send releases it, so the address can be tried again.

**Nothing is marked sent until the provider has accepted it** (§16). `mark_sent` is
called with the id SMTP returned, after the call came back.
"""

from __future__ import annotations

import logging

from django.utils import timezone

from apps.outreach.models import AuditJob, EmailDraft
from apps.outreach.services import history

from . import accounts as mailaccounts
from . import compose, transport

log = logging.getLogger(__name__)


class SendRefused(RuntimeError):
    """The email was not sent, with a sentence explaining why."""


def send(job: AuditJob, account, *, sender_name: str = "") -> AuditJob:
    """Send this audit's email. Raises `SendRefused` if it could not be.

    `account` is the mailbox to send from -- an `EmailAccount` this user owns, with
    a stored password. Passing it in rather than looking it up keeps the choice with
    the view, which is where the user made it.
    """
    from apps.outreach.services import websiteaudit as siteaudit

    blocked = siteaudit.blocked_reason(job)
    if blocked:
        raise SendRefused(blocked)

    if account is None:
        raise SendRefused(
            "Choose a sending address first. Add one in Settings if there is "
            "none.")
    account.refresh_from_db()
    if not account.is_active:
        raise SendRefused(f"{account.name} is switched off.")
    if not account.configured:
        raise SendRefused(f"No password is stored for {account.name}.")
    if mailaccounts.remaining_today(account) <= 0:
        raise SendRefused(
            f"{account.name} has reached its daily limit of "
            f"{mailaccounts.daily_cap(account)} messages.")

    draft = job.draft
    if draft is None:
        raise SendRefused("There is no email draft to send.")

    # The recipient the user approved, on the draft the history copies from. Done
    # before the reservation, because the reservation is what locks the address and
    # it has to lock the right one.
    if (draft.email or "").casefold() != job.recipient.casefold():
        EmailDraft.objects.filter(pk=draft.pk).update(email=job.recipient)
        draft.refresh_from_db()

    password = mailaccounts.password_of(account)
    if not password:
        raise SendRefused(f"No usable password is stored for {account.name}.")

    # The lock. An insert against a unique constraint, so a double-clicked button,
    # two browser tabs and a retried request produce one email between them.
    try:
        record = history.reserve(draft, sender_account=account,
                                sender_email=account.sender_email)
    except history.DoNotContact as exc:
        raise SendRefused(str(exc)) from None
    except history.AlreadyContacted as exc:
        raise SendRefused(str(exc)) from None

    try:
        with transport.Session(
            mailaccounts.provider_of(account),
            account.sender_email,
            password,
            host=account.smtp_host,
            port=account.smtp_port or 0,
            username=account.username or account.sender_email,
        ) as session:
            message_id = session.send(
                to_email=job.recipient,
                subject=draft.subject,
                body=compose.with_signature(draft.body, account.signature),
                sender_name=(sender_name or account.sender_name
                             or account.sender_email),
                reply_to=account.reply_to,
            )
    except Exception as exc:  # noqa: BLE001 - every failure is the user's answer
        # The address goes back so it can be tried again, and nothing is marked
        # sent. A failed send is not a send.
        record.mark_failed(str(exc)[:300])
        mailaccounts.note_failure(account, str(exc))
        AuditJob.objects.filter(pk=job.pk).update(
            state_note=f"The email was not sent: {exc}"[:400],
            error=str(exc)[:2000])
        log.info("audit %s: send failed: %s", job.pk, exc)
        raise SendRefused(f"The email was not sent. {exc}") from exc

    # Accepted by the provider. Only now is anything marked as sent.
    now = timezone.now()
    record.mark_sent(message_id=message_id)
    EmailDraft.objects.filter(pk=draft.pk).update(
        status=EmailDraft.Status.SENT, sent_at=now, error_message="",
        sent_account=account)
    AuditJob.objects.filter(pk=job.pk).update(
        state=AuditJob.State.SENT,
        state_note=f"Sent to {job.recipient}.",
        sent_lead=record,
        sent_account=account,
        message_id=message_id[:255],
        sent_at=now,
        error="",
    )
    mailaccounts.note_success(account)
    job.refresh_from_db()
    log.info("audit %s: sent to %s from %s", job.pk, job.recipient,
             account.sender_email)
    return job
