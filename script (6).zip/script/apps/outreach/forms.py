"""
The automation campaign form.

The only form in this project, and it earns being one: fourteen fields with real
rules between them -- an end after a start, a daily target that fits inside a total,
a mailbox that can actually send, a timezone that exists. Hand-rolled validation
across that many fields is where a "start" button starts accepting configurations
that cannot run.

**Nothing invalid may reach RUNNING.** Every rule in §19 is checked here, before a
plan row exists, and the errors come back against the field that caused them. The
alternative -- a campaign that saves and then fails at 09:00 tomorrow with a
traceback in a log nobody is reading -- is the failure mode this form exists to
prevent.

The one rule that is not the user's to change: `followup_autosend`. It is on the
model so the answer to "can unattended follow-up sending be switched on?" is a
visible no rather than a missing option, and it is refused here.
"""

from __future__ import annotations

import datetime as dt
from zoneinfo import available_timezones

from django import forms
from django.utils import timezone

from apps.ai import styles
from apps.leads.scraper import CATEGORIES, MAX_LEADS
from apps.outreach.mail import accounts as mailaccounts
from apps.outreach.services.automation import schedule

from .models import AutomationPlan

#: A ceiling on the total target. Not a technical limit -- the worker would happily
#: work through 50,000 -- but a campaign that large is a decision somebody should
#: make deliberately in several campaigns rather than by typing an extra zero.
MAX_TOTAL_TARGET = 5_000

#: Above this per day and the account's own provider limit becomes the real
#: constraint, so the number would be a promise the form cannot keep.
MAX_DAILY_TARGET = MAX_LEADS


class MultiTextField(forms.Field):
    """A list of names, from either a multi-select or a comma-separated string.

    Both, because the same field serves two callers: the browser posts a JSON array
    from the chip selector, and a test or a script posts "Dallas, Houston". Neither
    is worth its own field, and normalising here keeps the plan's stored shape --
    always a list of clean strings -- true whoever wrote it.
    """

    widget = forms.SelectMultiple

    def __init__(self, *, label: str, max_items: int = 40, **kwargs):
        self.max_items = max_items
        super().__init__(label=label, **kwargs)

    def to_python(self, value) -> list[str]:
        """A clean list of names, however the value arrived.

        A multi-select posts a list; a text box or a script posts one string. Each
        item is also split on commas, because "Dallas, Houston" typed into a single
        field has to mean two cities -- storing it as one would send the geocoder
        looking for a place called "Dallas, Houston".
        """
        if value in self.empty_values:
            return []
        items = [value] if isinstance(value, str) else list(value)

        seen: list[str] = []
        lowered: set[str] = set()
        for item in items:
            for part in str(item).split(","):
                cleaned = part.strip()
                if cleaned and cleaned.casefold() not in lowered:
                    lowered.add(cleaned.casefold())
                    seen.append(cleaned)
        return seen

    def validate(self, value) -> None:
        super().validate(value)
        if self.required and not value:
            raise forms.ValidationError(
                f"Choose at least one {self.label.lower().rstrip('s')}.")
        if len(value) > self.max_items:
            raise forms.ValidationError(
                f"That is {len(value)} — {self.max_items} is the most this "
                "campaign can take. Split it into two campaigns.")


class AutomationForm(forms.Form):
    """Everything needed to run a campaign unattended, validated together."""

    # --- campaign details ---------------------------------------------------- #
    name = forms.CharField(
        label="Campaign name", max_length=120,
        help_text="Yours, for telling campaigns apart. Shown on the dashboard.")

    # --- target audience ----------------------------------------------------- #
    countries = MultiTextField(label="Countries", max_items=10)
    cities = MultiTextField(label="Cities", max_items=25)
    categories = MultiTextField(label="Business categories", max_items=15)
    quality = forms.ChoiceField(
        label="Website filter", choices=AutomationPlan.Quality.choices,
        initial=AutomationPlan.Quality.HAS_WEBSITE,
        help_text=("Only what the map data and the crawl can establish. There is "
                   "no filter for “bad website” before the site has been read."))
    discover_emails = forms.BooleanField(
        label="Use a contact address published on the website", required=False,
        initial=True,
        help_text=("Most map records list a phone and a website but no email. With "
                   "this off, the campaign skips them."))

    # --- limits -------------------------------------------------------------- #
    daily_target = forms.IntegerField(
        label="Daily target", min_value=1, max_value=MAX_DAILY_TARGET, initial=25,
        help_text="Emails per day. Enforced server-side, per campaign day.")
    total_target = forms.IntegerField(
        label="Total target", min_value=1, max_value=MAX_TOTAL_TARGET, initial=100,
        help_text="The campaign completes when it has sent this many.")
    send_gap_seconds = forms.IntegerField(
        label="Extra gap between sends", min_value=0, max_value=900, initial=0,
        required=False,
        help_text=("Seconds, on top of the provider's own pacing. Leave at 0 "
                   "unless the mailbox is new."))

    # --- schedule ------------------------------------------------------------ #
    start_date = forms.DateField(
        label="Start date", widget=forms.DateInput(attrs={"type": "date"}))
    start_time = forms.TimeField(
        label="Daily start time", initial=dt.time(9, 0),
        widget=forms.TimeInput(attrs={"type": "time"}))
    end_date = forms.DateField(
        label="End date", required=False,
        widget=forms.DateInput(attrs={"type": "date"}),
        help_text="Optional. The campaign completes after this date.")
    end_time = forms.TimeField(
        label="Daily end time", required=False,
        widget=forms.TimeInput(attrs={"type": "time"}),
        help_text="Optional. Nothing is sent after this time each day.")
    timezone_name = forms.ChoiceField(
        label="Time zone", initial=schedule.DEFAULT_ZONE,
        choices=[(name, name.replace("_", " ")) for name in schedule.COMMON_ZONES],
        help_text="The campaign's own zone. The server's is not assumed.")

    # --- sending ------------------------------------------------------------- #
    email_account = forms.ModelChoiceField(
        label="Send from", queryset=None, empty_label=None,
        help_text="Only addresses that are active and have a stored password.")
    template_key = forms.ChoiceField(
        label="Email template", choices=(), initial=styles.DEFAULT_STYLE.key)
    service_pitch = forms.CharField(
        label="What do you offer?", widget=forms.Textarea(attrs={"rows": 6}),
        help_text=("Each email connects a verified website finding to this offer. "
                   "The AI will not invent claims you have not made here."))

    # --- follow-ups ---------------------------------------------------------- #
    followups_enabled = forms.BooleanField(
        label="Prepare follow-ups", required=False, initial=True,
        help_text=("Drafts a follow-up when one comes due. Sending it is still a "
                   "click — that is not configurable."))
    followup_delay_days = forms.IntegerField(
        label="Days before the first follow-up", min_value=1, max_value=90,
        initial=3, required=False)
    followup_max = forms.IntegerField(
        label="Maximum follow-ups per lead", min_value=0, max_value=5, initial=2,
        required=False)

    def __init__(self, *args, owner=None, **kwargs):
        """`owner` is required, and is what scopes the mailbox choices.

        Ownership in the queryset rather than checked afterwards: a form that offers
        somebody else's mailbox and then rejects it has already leaked that the
        mailbox exists.
        """
        super().__init__(*args, **kwargs)
        self.owner = owner
        self.fields["email_account"].queryset = mailaccounts.accounts(owner)
        self.fields["template_key"].choices = [
            (style.key, f"{style.label} — {style.band}")
            for style in styles.STYLES.values()
        ]
        self.fields["categories"].widget.choices = [
            (name, name) for name in CATEGORIES
        ]
        if not self.is_bound:
            self.fields["start_date"].initial = timezone.localdate()

    # --- field rules --------------------------------------------------------- #

    def clean_name(self) -> str:
        name = self.cleaned_data["name"].strip()
        clash = AutomationPlan.objects.filter(owner=self.owner, name__iexact=name)
        if clash.exists():
            raise forms.ValidationError(
                "You already have a campaign with that name. Names are how the "
                "dashboard tells them apart, so they have to differ.")
        return name

    def clean_timezone_name(self) -> str:
        name = self.cleaned_data["timezone_name"]
        # Checked against the tz database rather than only against the offered
        # list: the field accepts any valid name, and an invalid one must fail here
        # rather than at 09:00 tomorrow inside the worker.
        if name not in available_timezones():
            raise forms.ValidationError(
                f"{name} is not a known timezone. Use an IANA name such as "
                "America/Chicago.")
        return name

    def clean_email_account(self):
        account = self.cleaned_data["email_account"]
        if not account.is_active:
            raise forms.ValidationError(
                f"{account.name} is switched off. Activate it in Settings, or "
                "choose another address.")
        if not account.configured:
            raise forms.ValidationError(
                f"No password is stored for {account.name}. Add one in Settings "
                "before a campaign can send from it.")
        if account.connection_status == account.Connection.FAILED:
            raise forms.ValidationError(
                f"The last connection test for {account.name} failed: "
                f"{account.connection_detail or 'no detail recorded'}. Fix it in "
                "Settings, or choose another address.")
        return account

    def clean_service_pitch(self) -> str:
        pitch = self.cleaned_data["service_pitch"].strip()
        if len(pitch) < 20:
            raise forms.ValidationError(
                "Describe what you offer in a sentence or two — the email needs "
                "it to connect a website finding to something you can do.")
        return pitch

    # --- rules between fields ------------------------------------------------ #

    def clean(self):
        data = super().clean()

        start_date = data.get("start_date")
        end_date = data.get("end_date")
        start_time = data.get("start_time")
        end_time = data.get("end_time")

        if start_date and end_date and end_date < start_date:
            self.add_error("end_date", (
                f"The campaign would end ({end_date:%d %b %Y}) before it starts "
                f"({start_date:%d %b %Y})."))

        if start_time and end_time and end_time <= start_time:
            # A window that closes before it opens is never open, so the campaign
            # would sit in SCHEDULED forever with no explanation.
            self.add_error("end_time", (
                f"The daily window would close ({end_time:%H:%M}) before it opens "
                f"({start_time:%H:%M}), so it would never be open. Overnight "
                "windows are not supported."))

        daily = data.get("daily_target")
        total = data.get("total_target")
        if daily and total and daily > total:
            self.add_error("daily_target", (
                f"The daily target ({daily}) is higher than the total ({total}), "
                "so the campaign would finish on its first day. Lower the daily "
                "target or raise the total."))

        # The mailbox's own ceiling is the real limit, and it is not ours to raise.
        account = data.get("email_account")
        if account is not None and daily:
            cap = mailaccounts.daily_cap(account)
            if daily > cap:
                self.add_error("daily_target", (
                    f"{account.name} is capped at {cap} messages a day by "
                    f"{mailaccounts.provider_of(account).label}. A daily target of "
                    f"{daily} cannot be met, and the cap is not ours to raise."))

        if data.get("followups_enabled"):
            if not data.get("followup_max"):
                data["followup_max"] = 0
            if not data.get("followup_delay_days"):
                data["followup_delay_days"] = 3

        # A campaign whose window is already entirely in the past is allowed to be
        # created, and refused by `runner.start` instead -- with the schedule's own
        # sentence, which names the date and the zone. A form field cannot say that
        # as well, because it does not know which zone the user meant until this
        # method has run.

        return data

    # --- what a valid form produces ------------------------------------------ #

    def plan_values(self) -> dict:
        """The `AutomationPlan` fields, from cleaned data.

        Kept beside the rules rather than in the view: the view's job is the
        request, and a second place that knows how a form maps onto a model is a
        second place to forget a field.
        """
        data = self.cleaned_data
        return {
            "name": data["name"],
            "countries": data["countries"],
            "cities": data["cities"],
            "categories": data["categories"],
            "quality": data["quality"],
            "discover_emails": bool(data.get("discover_emails")),
            "daily_target": data["daily_target"],
            "total_target": data["total_target"],
            "send_gap_seconds": data.get("send_gap_seconds") or 0,
            "start_date": data["start_date"],
            "start_time": data["start_time"],
            "end_date": data.get("end_date"),
            "end_time": data.get("end_time"),
            "timezone_name": data["timezone_name"],
            "email_account": data["email_account"],
            "template_key": data["template_key"],
            "followups_enabled": bool(data.get("followups_enabled")),
            "followup_delay_days": data.get("followup_delay_days") or 3,
            "followup_max": data.get("followup_max") or 0,
            # Not a choice. See the module docstring.
            "followup_autosend": False,
        }

    def summary(self) -> list[tuple[str, str]]:
        """The review panel (§22), from validated data.

        Built from `cleaned_data` rather than from the raw POST, so what it shows is
        what would actually run -- a summary of unvalidated input is a summary of
        something that may not be about to happen.
        """
        data = self.cleaned_data
        account = data.get("email_account")
        style = styles.style(data.get("template_key"))
        hours = f"{data['start_time']:%H:%M}"
        if data.get("end_time"):
            hours += f"–{data['end_time']:%H:%M}"
        days = f"{data['start_date']:%d %b %Y}"
        if data.get("end_date"):
            days += f" – {data['end_date']:%d %b %Y}"

        return [
            ("Categories", ", ".join(data["categories"])),
            ("Locations", ", ".join(data["cities"])),
            ("Countries", ", ".join(data["countries"])),
            ("Daily target", str(data["daily_target"])),
            ("Total target", str(data["total_target"])),
            ("Dates", days),
            ("Daily window", hours),
            ("Time zone", data["timezone_name"]),
            ("Send from", f"{account.name} <{account.sender_email}>"
                          if account else "—"),
            ("Email template", f"{style.label} ({style.band})"),
            ("Follow-ups", ("prepared for your approval"
                            if data.get("followups_enabled") else "off")),
        ]
