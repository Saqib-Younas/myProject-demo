"""
The configuration page, and the mailboxes this workspace sends from.

Sending, scraping and crawling settings are read-only here -- they come from `.env`,
and a browser form that could rewrite an SMTP password would put it on the network for
no reason. The two things that *are* editable are the AI credential pool (whose
endpoints live in `apps.ai.views`) and the sending addresses below.

A password is posted once, encrypted server-side, and never sent back: every response
carries a masked hint instead.
"""

from __future__ import annotations

import os

from django.conf import settings as django_settings
from django.db import IntegrityError
from django.http import HttpRequest, HttpResponse, JsonResponse
from django.shortcuts import render
from django.views.decorators.http import require_GET, require_POST

from apps import ai
from apps.ai import credentials
from apps.auditing import crawler
from apps.outreach.mail import accounts as mailaccounts
from apps.outreach.mail import followups as followup_rules
from apps.outreach.mail import inbox
from apps.outreach.mail import providers as smtp_provider_table
from apps.outreach.models import (
    Campaign,
    SentLead,
)
from apps.outreach.services import history

from .shared import (
    _json,
    _my_account,
)


def _credential_ui_enabled() -> bool:
    """Whether the write endpoints are available.

    A deployment that wants credentials to come only from `.env` can set
    OUTREACH_CREDENTIALS_UI=0 and close this surface entirely. On by default,
    because the feature is useless off -- and now safe by default too, since
    every credential belongs to the account that added it.
    """
    return os.environ.get("OUTREACH_CREDENTIALS_UI", "1") != "0"
def _accounts_payload(request: HttpRequest) -> dict:
    return {
        "accounts": mailaccounts.all_statuses(request.user),
        "summary": mailaccounts.summary(request.user),
    }
@require_POST
def account_save(request: HttpRequest) -> JsonResponse:
    """Create or update one sending account.

    The one request that carries a password. An empty password field on an update
    means "leave the stored one alone" -- the form cannot show it, so empty cannot
    mean "clear it", and clearing has its own endpoint.
    """
    payload = _json(request)
    account = None
    if payload.get("id"):
        try:
            account = _my_account(request, int(payload["id"]))
        except (TypeError, ValueError):
            return JsonResponse({"error": "Unknown account."}, status=400)

    try:
        saved = mailaccounts.save_account(
            request.user,
            account=account,
            name=str(payload.get("name", "")),
            sender_name=str(payload.get("sender_name", "")),
            sender_email=str(payload.get("sender_email", "")),
            provider=str(payload.get("provider", "")),
            password=str(payload.get("password", "")),
            username=str(payload.get("username", "")),
            smtp_host=str(payload.get("smtp_host", "")),
            smtp_port=payload.get("smtp_port"),
            imap_host=str(payload.get("imap_host", "")),
            imap_port=payload.get("imap_port"),
            signature=str(payload.get("signature", "")),
            reply_to=str(payload.get("reply_to", "")),
            daily_limit=payload.get("daily_limit"),
            followup_max=payload.get("followup_max"),
            followup_delays=str(payload.get("followup_delays", "")),
            is_active=payload.get("is_active", True),
        )
    except mailaccounts.AccountError as exc:
        # AccountError is written by our own code and never carries a password.
        return JsonResponse({"error": str(exc)}, status=400)
    except IntegrityError:
        return JsonResponse({
            "error": "You already have an account with that name or that email "
                     "address.",
        }, status=409)

    return JsonResponse({
        "saved": True,
        "message": f"{saved.name} saved."
                   + ("" if saved.configured else
                      " Add a password before it can send."),
        "account": mailaccounts.account_status(saved),
        **_accounts_payload(request),
    })
@require_GET
def account_edit(request: HttpRequest, pk: int) -> JsonResponse:
    """The current values of one sending address, so the form can fill itself.

    A GET, because it changes nothing -- and scoped through `_my_account`, so an id in
    the URL grants nothing on its own.

    **No password.** `mailaccounts.editable_fields()` cannot return one, and that is the
    whole reason the form treats an empty password field as "keep the stored one": there
    is nothing to round-trip, so there is no endpoint that needs to hand one back. What
    it does return is `configured` and `masked`, which is enough for the form to say
    which password it is keeping without revealing it.
    """
    account = _my_account(request, pk)
    return JsonResponse({"account": mailaccounts.editable_fields(account)})


@require_POST
def account_active(request: HttpRequest, pk: int) -> JsonResponse:
    """Switch one account on or off.

    Off is not deletion: sent history, scheduled follow-ups and reply state all
    survive. Only future sends stop.
    """
    account = _my_account(request, pk)
    enabled = bool(_json(request).get("enabled"))

    try:
        mailaccounts.set_active(request.user, account, enabled)
    except mailaccounts.AccountError as exc:
        return JsonResponse({"error": str(exc)}, status=400)

    running = Campaign.objects.filter(
        sending_accounts=account, phase=Campaign.Phase.SENDING).count()
    message = f"{account.name} is now {'active' if enabled else 'inactive'}."
    if not enabled and running:
        message += (f" {running} campaign(s) are sending right now -- no further "
                    "emails will go out from this address, and nothing already "
                    "sent is affected.")

    return JsonResponse({"message": message, **_accounts_payload(request)})
@require_POST
def account_test(request: HttpRequest, pk: int) -> JsonResponse:
    """Authenticate against SMTP, and read the mailbox, without sending anything."""
    account = _my_account(request, pk)

    try:
        status, message = mailaccounts.test_connection(request.user, account)
    except mailaccounts.AccountError as exc:
        return JsonResponse({"error": str(exc)}, status=400)

    return JsonResponse({
        "result": status,
        "message": message,
        "account": mailaccounts.account_status(account),
        **_accounts_payload(request),
    }, status=200 if status in ("ok", "blocked") else 502)
@require_POST
def account_forget(request: HttpRequest, pk: int) -> JsonResponse:
    """Forget the stored password, keeping the account and its history."""
    account = _my_account(request, pk)

    try:
        mailaccounts.clear_secret(request.user, account)
    except mailaccounts.AccountError as exc:
        return JsonResponse({"error": str(exc)}, status=400)

    return JsonResponse({
        "message": f"The password for {account.name} has been removed. The "
                   "account and its history are untouched.",
        **_accounts_payload(request),
    })
@require_POST
def account_delete(request: HttpRequest, pk: int) -> JsonResponse:
    """Delete an account that has never sent anything.

    An address with history is deactivated instead. Deleting it would orphan the
    sent records that prove who was contacted and when, which is the one thing in
    this application that must not become guesswork.
    """
    account = _my_account(request, pk)
    sent = SentLead.objects.filter(
        owner=request.user, sender_email__iexact=account.sender_email).count()

    if sent:
        return JsonResponse({
            "error": f"{account.name} has sent {sent} email(s). Deleting it would "
                     "orphan that history -- switch it off instead, which stops "
                     "future sends and keeps the record.",
        }, status=409)

    name = account.name
    account.delete()
    return JsonResponse({
        "deleted": True,
        "message": f"{name} deleted.",
        **_accounts_payload(request),
    })
def _imap_label(smtp_provider) -> str:
    """Where replies would be read from, or "" when nothing is configured."""
    if smtp_provider is None:
        return ""
    try:
        host, port = inbox.resolve_imap(smtp_provider)
    except inbox.InboxError:
        return ""
    return f"{host}:{port}"
@require_GET
def settings_view(request: HttpRequest) -> HttpResponse:
    """The current configuration, and the AI credential pool.

    Sending, scraping and crawling settings are read-only here: they come from
    `.env`, and a browser form that could rewrite an SMTP password would put it
    on the network for no reason.

    AI credentials are the exception, and the reason is that they are per
    account: this page shows each provider with the credentials this user has
    added under it, which of them is active, and how each has been behaving. No
    key is ever sent back -- only masked hints.
    """
    from apps.leads import scraper

    ai_ready, ai_source, ai_advice = ai.describe_credentials()
    active = ai.provider()

    # One list, from the credential resolver, so the cards, the selector and the
    # provider the pipeline will actually use cannot disagree.
    # Explicitly scoped to this account rather than relying on the middleware's
    # context: the owner is the one argument that must never be left implicit.
    providers = credentials.all_statuses(request.user)
    for entry in providers:
        entry["active"] = entry["name"] == active
        entry["effective_model"] = (
            ai.model() if entry["name"] == active
            else (entry["model"] or entry["default_model"])
        )

    provider_key = django_settings.OUTREACH_PROVIDER
    smtp_provider = smtp_provider_table.PROVIDERS.get(provider_key)
    host = os.environ.get("OUTREACH_SMTP_HOST", "")
    port = os.environ.get("OUTREACH_SMTP_PORT", "")
    if smtp_provider and not host:
        host, port = smtp_provider.host, smtp_provider.port

    # Which database is live, for the staff-only card. Read here rather than in a
    # template tag because `apps.core.database` is where the question is answered and
    # the view is the place that calls it.
    from apps.core import database as database_settings

    return render(request, "outreach/settings.html", {
        "nav": "settings",
        "database_active_label": database_settings.label(database_settings.active()),
        "database_description": database_settings.active_description(),
        "database_selection": database_settings.selection(),
        "database_pending": database_settings.pending_restart(),
        "ai_ready": ai_ready,
        "ai_source": ai_source,
        "ai_advice": ai_advice,
        "providers": providers,
        "active_provider": active,
        "active_model": ai.model() if ai_ready else "",
        "credential_ui": _credential_ui_enabled(),
        "credential_total": sum(e["credential_count"] for e in providers),
        "credential_events": credentials.events(request.user, limit=12),
        # The workspace's sending addresses. Same parent/child shape as the AI
        # credentials above it, and the same rule: a masked hint, never a password.
        "email_accounts": mailaccounts.all_statuses(request.user),
        "account_summary": mailaccounts.summary(request.user),
        "smtp_providers": list(smtp_provider_table.PROVIDERS.values()),
        "sender_name": django_settings.OUTREACH_SENDER_NAME,
        "sender_email": django_settings.OUTREACH_SENDER_EMAIL,
        "sender_company": django_settings.OUTREACH_SENDER_COMPANY,
        "smtp_provider": smtp_provider,
        "smtp_provider_key": provider_key,
        "smtp_host": f"{host}:{port}" if host else "not configured",
        "smtp_password_set": bool(os.environ.get("OUTREACH_SMTP_PASSWORD")),
        "send_blocked": getattr(django_settings, "OUTREACH_BLOCK_SEND", False),
        "osm_contact": django_settings.OSM_CONTACT_EMAIL,
        "max_leads": scraper.MAX_LEADS,
        "history": history.stats(request.user),
        "followup_max": followup_rules.max_followups(),
        "followup_delays": list(django_settings.OUTREACH_FOLLOWUP_DELAYS),
        "imap_host": _imap_label(smtp_provider),
        "crawl": {
            "target": crawler.TARGET_INTERNAL,
            "max_pages": crawler.MAX_PAGES,
            "delay": crawler.HOST_DELAY,
            "context_budget": crawler.CONTEXT_BUDGET,
        },
    })
