"""
The outreach screens, one module per screen.

Split from a single 2,400-line file. The names are re-exported here so `urls.py` and
`config/urls.py` keep importing `views.dashboard` -- and so a reader who knows the old
module still finds everything.

    shared.py        request helpers and the owner-scoped lookups
    dashboard.py     the authenticated home
    leads.py         the lead table, one lead in detail, re-analysis, re-scoring
    campaigns.py     create, set up, run, watch, control, report
    drafts.py        review a draft, approve, send
    followups.py     replies, and the follow-ups a person sends
    suppressions.py  the do-not-contact list and the history export
    settings.py      configuration and sending addresses
    automation.py    unattended campaigns
    websiteaudit.py  auditing one submitted URL

Views here stay thin: they read the request, call a service, and render. Anything that
decides something belongs in `services/`, and anything that queries belongs in
`selectors.py`.
"""

from .campaigns import (
    campaign_accounts,
    campaign_dashboard,
    campaign_history,
    campaign_status,
    cancel,
    report,
    resume,
    run,
    setup,
    start,
    state,
    workspace,
)
from .dashboard import dashboard
from .drafts import approve_all, draft_action, send
from .followups import check_inbox, followup_action, followup_create, followups
from .leads import lead_detail, lead_lifecycle, lead_reanalyse, leads, rescore
from .settings import (
    account_active,
    account_delete,
    account_edit,
    account_forget,
    account_save,
    account_test,
    settings_view,
)
from .shared import MAX_LEADS_PER_CAMPAIGN
from .suppressions import (
    history_excel,
    suppress_add,
    suppress_remove,
    suppressions,
)

__all__ = [
    "dashboard",
    "leads", "lead_detail", "lead_reanalyse", "lead_lifecycle", "rescore",
    "start", "setup", "run", "workspace", "state", "campaign_status",
    "campaign_dashboard", "cancel", "resume", "report", "campaign_history",
    "campaign_accounts",
    "draft_action", "approve_all", "send",
    "followups", "check_inbox", "followup_create", "followup_action",
    "suppressions", "suppress_add", "suppress_remove", "history_excel",
    "settings_view", "account_save", "account_edit", "account_active",
    "account_test",
    "account_forget", "account_delete",
    "MAX_LEADS_PER_CAMPAIGN",
]
