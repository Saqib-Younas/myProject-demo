"""
The do-not-contact list, and the sending history export.

Together because they are the two halves of "who has been contacted, and who must not
be": the export is the record, and the list is the rule. Adding an address here beats
every other check in the application, including a deliberate re-contact.
"""

from __future__ import annotations

from django.db import models
from django.http import (
    FileResponse,
    HttpRequest,
    HttpResponse,
    JsonResponse,
)
from django.shortcuts import get_object_or_404, render
from django.views.decorators.http import require_GET, require_POST

from apps.core import paging
from apps.outreach.models import (
    EmailDraft,
    Suppression,
)
from apps.outreach.services import history

from .shared import (
    _json,
    _valid_email,
)


@require_GET
def suppressions(request: HttpRequest) -> HttpResponse:
    """The do-not-contact list: who may never be emailed, and why."""
    entries = Suppression.objects.filter(owner=request.user)

    search = (request.GET.get("q") or "").strip()
    if search:
        entries = entries.filter(
            models.Q(email__icontains=search)
            | models.Q(domain__icontains=search))

    paging_context = paging.page_context(request, entries, label="entries")
    return render(request, "outreach/suppressions.html", {
        "nav": "suppressions",
        "rows": paging_context["rows"],
        "paging": paging_context,
        "search": search,
        "reasons": Suppression.Reason.choices,
        "total": Suppression.objects.filter(owner=request.user).count(),
        # Counted over every rule rather than the page: "how many are domain-wide"
        # is a fact about the list, and answering it from one page of it would be a
        # different number that looks like the same one.
        "domain_rules": Suppression.objects.filter(
            owner=request.user, email="").count(),
    })
@require_POST
def suppress_add(request: HttpRequest) -> JsonResponse:
    """Add an address or a domain to the do-not-contact list."""
    payload = _json(request)
    target = str(payload.get("target", "")).strip()
    if not target:
        return JsonResponse(
            {"error": "Enter an email address or a domain."}, status=400)

    is_email = "@" in target
    if is_email and not _valid_email(target):
        return JsonResponse({"error": f"{target} is not a valid email address."},
                            status=400)

    try:
        row, created = history.suppress(
            request.user,
            email=target if is_email else "",
            domain="" if is_email else target,
            reason=str(payload.get("reason", "")).strip(),
            note=str(payload.get("note", "")).strip(),
        )
    except ValueError as exc:
        return JsonResponse({"error": str(exc)}, status=400)

    # Anything already queued or drafted for this target drops out now, rather
    # than at send time -- there is no reason to keep spending AI calls on it.
    swept = 0
    blocklist = history.SuppressionIndex(request.user)
    for draft in EmailDraft.objects.filter(
        campaign__owner=request.user,
    ).exclude(
        status__in=(EmailDraft.Status.SENT, EmailDraft.Status.SENDING,
                    EmailDraft.Status.SUPPRESSED),
    ).exclude(email=""):
        blocked = blocklist.match(email=draft.email, website=draft.website)
        if blocked:
            EmailDraft.objects.filter(pk=draft.pk).update(
                status=EmailDraft.Status.SUPPRESSED,
                force_contact=False,
                error_message=blocked.sentence(),
            )
            swept += 1

    return JsonResponse({
        "created": created,
        "target": row.target,
        "scope": row.scope,
        "swept": swept,
        "total": Suppression.objects.filter(owner=request.user).count(),
    })
@require_POST
def suppress_remove(request: HttpRequest, pk: int) -> JsonResponse:
    """Remove an entry. Existing drafts stay suppressed until re-selected."""
    row = get_object_or_404(Suppression, pk=pk, owner=request.user)
    target = row.target
    row.delete()
    return JsonResponse({
        "removed": target,
        "total": Suppression.objects.filter(owner=request.user).count(),
    })
@require_GET
def history_excel(request: HttpRequest) -> HttpResponse:
    """Download the Excel history, refreshing it first."""
    try:
        history.export_excel(request.user)
    except Exception as exc:  # noqa: BLE001 - still serve whatever exists
        if not history.excel_path(request.user).exists():
            return HttpResponse(
                f"Could not build the Excel history: {exc}",
                status=500, content_type="text/plain",
            )

    path = history.excel_path(request.user)
    if not path.exists():
        return HttpResponse(
            "No emails have been sent yet, so there is no history to export.",
            status=404, content_type="text/plain",
        )
    return FileResponse(
        path.open("rb"), as_attachment=True, filename=history.EXCEL_NAME,
        content_type=("application/vnd.openxmlformats-officedocument"
                      ".spreadsheetml.sheet"),
    )
