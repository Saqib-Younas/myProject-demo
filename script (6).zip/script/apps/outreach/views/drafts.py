"""
Reviewing a draft, and sending the approved ones.

`draft_action` is one endpoint with an action name rather than eight endpoints, because
every one of them does the same three things -- find the draft scoped to the user,
change one field, return the redrawn row.

`send` starts the bulk send. It does not send: it hands the campaign to the runner and
returns, because SMTP for 200 leads is not a request.
"""

from __future__ import annotations

import os

from django.http import HttpRequest, JsonResponse
from django.views.decorators.http import require_POST

from apps.outreach.mail import providers
from apps.outreach.models import (
    EmailDraft,
    SentLead,
    Suppression,
)
from apps.outreach.services import history
from apps.outreach.services import pipeline as runner

from .campaigns import _draft_json, _previous_contacts
from .shared import (
    _json,
    _my_campaign,
    _my_draft,
)


@require_POST
def draft_action(request: HttpRequest, pk: int, action: str) -> JsonResponse:
    """Edit, regenerate, approve or reject a single email."""
    draft = _my_draft(request, pk)
    campaign = draft.campaign
    payload = _json(request)

    if draft.status in (EmailDraft.Status.SENT, EmailDraft.Status.SENDING):
        return JsonResponse(
            {"error": "That email has already been sent."}, status=409)

    if action == "save":
        subject = str(payload.get("subject", "")).strip()
        body = str(payload.get("body", "")).strip()
        if not subject or not body:
            return JsonResponse(
                {"error": "Subject and body cannot be empty."}, status=400)
        draft.subject = subject[:400]
        draft.body = body
        draft.edited = True
        if draft.status == EmailDraft.Status.FAILED:
            draft.status = EmailDraft.Status.GENERATED
        draft.error_message = ""
        draft.save(update_fields=["subject", "body", "edited", "status",
                                 "error_message"])

    elif action == "regenerate":
        hint = str(payload.get("hint", "")).strip()[:500]
        draft.regenerations += 1
        draft.save(update_fields=["regenerations"])
        if not runner.generate_draft(draft, campaign, retry_hint=hint):
            draft.refresh_from_db()
            return JsonResponse({"error": draft.error_message}, status=502)

    elif action == "rereview":
        # Re-run the website review, then rebuild the email from the new
        # findings -- useful when the first review came back thin or failed.
        if not draft.analysis_context:
            return JsonResponse({
                "error": "There is no crawled website material to review. "
                         f"{draft.analysis_note}",
            }, status=400)
        runner.review_draft(draft)
        draft.refresh_from_db()
        if not draft.findings:
            return JsonResponse(
                {"error": draft.error_message or "The review found nothing."},
                status=502)
        if not runner.generate_draft(draft, campaign):
            draft.refresh_from_db()
            return JsonResponse({"error": draft.error_message}, status=502)

    elif action == "approve":
        if not draft.subject or not draft.body:
            return JsonResponse(
                {"error": "This email has no content to approve yet."}, status=400)
        draft.status = EmailDraft.Status.APPROVED
        draft.save(update_fields=["status"])

    elif action == "reject":
        draft.status = EmailDraft.Status.REJECTED
        draft.save(update_fields=["status"])

    elif action == "recontact":
        # The deliberate re-contact workflow. It overrules the sending history
        # only: tier 3 matches on business name and city, which occasionally
        # blocks two genuinely different businesses, and this is how the user
        # says so. A suppressed address is never reachable this way.
        if draft.status == EmailDraft.Status.SUPPRESSED:
            return JsonResponse({
                "error": "This address is on the do-not-contact list. Remove it "
                         "there first if that entry is wrong.",
            }, status=403)
        if draft.status != EmailDraft.Status.DUPLICATE:
            return JsonResponse(
                {"error": "This lead is not blocked as already contacted."},
                status=400)
        if not draft.email:
            return JsonResponse(
                {"error": "This lead has no email address."}, status=400)

        reason = str(payload.get("reason", "")).strip()
        if len(reason) < 10:
            return JsonResponse({
                "error": "Give a reason of at least 10 characters -- it is kept "
                         "with the send record.",
            }, status=400)

        blocked = history.SuppressionIndex(request.user).match(
            email=draft.email, website=draft.website)
        if blocked:
            return JsonResponse({"error": blocked.sentence()}, status=403)

        draft.force_contact = True
        draft.force_reason = reason[:300]
        draft.status = EmailDraft.Status.PENDING
        draft.error_message = ""
        draft.sequence = 0          # _queue_for gives it a place at the end
        draft.processed_at = None
        draft.save(update_fields=["force_contact", "force_reason", "status",
                                  "error_message", "sequence", "processed_at"])

        if not runner.start_pipeline(campaign, resume=True):
            return JsonResponse({
                "error": "The lead is queued, but another job is running for "
                         "this campaign. Resume once it finishes.",
            }, status=409)

    elif action == "suppress":
        # Add this lead to the do-not-contact list, from the card in front of
        # you -- the point where "take me off your list" actually gets handled.
        if not draft.email:
            return JsonResponse(
                {"error": "This lead has no email address to suppress."},
                status=400)
        scope = str(payload.get("scope", "email")).strip()
        history.suppress(
            request.user,
            email="" if scope == "domain" else draft.email,
            domain=SentLead.domain_of(draft.website)
                   or draft.email.split("@")[-1],
            reason=str(payload.get("reason", "")).strip()
                   or Suppression.Reason.UNSUBSCRIBED,
            note=str(payload.get("note", "")).strip(),
            business_name=draft.business_name,
            campaign_label=campaign.label,
        )
        EmailDraft.objects.filter(pk=draft.pk).update(
            status=EmailDraft.Status.SUPPRESSED,
            force_contact=False,
            error_message="Added to the do-not-contact list.",
        )

    else:
        return JsonResponse({"error": f"Unknown action {action!r}."}, status=400)

    draft.refresh_from_db()
    return JsonResponse({
        "draft": _draft_json(draft, _previous_contacts(campaign)),
        "counts": campaign.counts(),
    })
@require_POST
def approve_all(request: HttpRequest, campaign_id) -> JsonResponse:
    """Approve every drafted email that has not been rejected or sent."""
    campaign = _my_campaign(request, campaign_id)
    updated = campaign.drafts.filter(
        status=EmailDraft.Status.GENERATED,
    ).exclude(subject="").update(status=EmailDraft.Status.APPROVED)
    return JsonResponse({"approved": updated, "counts": campaign.counts()})
@require_POST
def send(request: HttpRequest, campaign_id) -> JsonResponse:
    """Start the bulk send over the user's own SMTP account."""
    campaign = _my_campaign(request, campaign_id)

    if runner.is_running(campaign.id):
        return JsonResponse(
            {"error": "This campaign is already sending."}, status=409)
    if not campaign.drafts.filter(status=EmailDraft.Status.APPROVED).exists():
        return JsonResponse(
            {"error": "Approve at least one email before sending."}, status=400)

    payload = _json(request)
    # The password is used for this run and never written to the database.
    password = (str(payload.get("password", "")).strip()
                or os.environ.get("OUTREACH_SMTP_PASSWORD", ""))
    if not password:
        return JsonResponse({
            "error": "Enter the SMTP password or app password for "
                     f"{campaign.sender_email}.",
        }, status=400)

    provider = providers.PROVIDERS.get(campaign.provider)
    host = os.environ.get("OUTREACH_SMTP_HOST", "")
    port = int(os.environ.get("OUTREACH_SMTP_PORT", "0") or 0)
    if provider and provider.key == "custom" and not host:
        return JsonResponse({
            "error": "Set OUTREACH_SMTP_HOST (and OUTREACH_SMTP_PORT) for a "
                     "custom SMTP server, then restart the server.",
        }, status=400)

    if not runner.start_send(campaign, password, host=host, port=port):
        return JsonResponse({"error": "A job is already running."}, status=409)

    return JsonResponse({"started": True, "counts": campaign.counts()})
