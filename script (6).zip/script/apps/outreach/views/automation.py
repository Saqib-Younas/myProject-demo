"""
The automation screens: create a campaign, watch it, control it.

Split out of `views.py` rather than added to it -- that module is already 2,400
lines and these four views share a subject with each other rather than with the
manual workflow.

The rule that shapes all of them: **the browser displays the worker's state and does
not produce it.** Creating a campaign writes a plan and sets a status; the worker
notices on its next pass. The dashboard polls a JSON endpoint that counts rows.
Nothing here crawls, writes an email, opens SMTP or increments a counter -- so a
dashboard left open overnight shows what happened, and a dashboard nobody opened
misses nothing.
"""

from __future__ import annotations

from django.conf import settings as django_settings
from django.db import transaction
from django.db.models import Count
from django.http import HttpRequest, HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.decorators.http import require_GET, require_POST

from apps import ai
from apps.ai import styles
from apps.core import paging
from apps.leads import places
from apps.leads.scraper import CATEGORIES
from apps.outreach.forms import AutomationForm
from apps.outreach.mail import accounts as mailaccounts
from apps.outreach.models import AutomationPlan, Campaign, EmailDraft
from apps.outreach.services import campaigns as campaign_ops
from apps.outreach.services.automation import events as event_log
from apps.outreach.services.automation import leads as prospecting
from apps.outreach.services.automation import runner as automation
from apps.outreach.services.automation import schedule


def _my_plan(request: HttpRequest, pk: int) -> AutomationPlan:
    """One plan, scoped to the signed-in account.

    404 rather than 403, and the ownership is in the query rather than checked
    afterwards: an id in a URL grants nothing, and a 403 would confirm the campaign
    exists.
    """
    return get_object_or_404(
        AutomationPlan.objects.select_related("campaign", "email_account"),
        pk=pk, owner=request.user)


# --------------------------------------------------------------------------- #
# The list
# --------------------------------------------------------------------------- #

@require_GET
def automation_list(request: HttpRequest) -> HttpResponse:
    """Every automation campaign, with its status and its progress."""
    plans = (AutomationPlan.objects
             .filter(owner=request.user)
             .select_related("campaign", "email_account"))

    context = paging.page_context(request, plans, label="campaigns")
    rows = [_row(plan) for plan in context["rows"]]

    return render(request, "outreach/automation_list.html", {
        "nav": "automation",
        "rows": rows,
        "paging": context,
        "accounts": mailaccounts.all_statuses(request.user),
    })


def _row(plan: AutomationPlan) -> dict:
    """One line of the list: enough to see whether it is working."""
    sent = plan.sent_total
    today = plan.days.filter(day=schedule.local_date(plan)).first()
    return {
        "plan": plan,
        "campaign": plan.campaign,
        "sent": sent,
        "total_target": plan.total_target,
        "percent": min(100, round(100 * sent / max(1, plan.total_target))),
        "today": today.sent if today else 0,
        "daily_target": plan.daily_target,
        "window": schedule.state(plan),
        "controls": campaign_ops.controls(plan.campaign),
    }


# --------------------------------------------------------------------------- #
# Creating one
# --------------------------------------------------------------------------- #

def automation_new(request: HttpRequest) -> HttpResponse:
    """The configuration form, and the campaign it creates.

    One view for both directions on purpose: a POST that fails validation has to
    come back as the same page with the same values and the errors against the
    fields that caused them, and splitting it in two is how that stops working.
    """
    accounts = mailaccounts.all_statuses(request.user)
    usable = [row for row in accounts if row["sendable"]]

    if request.method == "POST":
        form = AutomationForm(request.POST, owner=request.user)
        if form.is_valid():
            plan = _create(request, form)
            return redirect("outreach:automation_view", pk=plan.pk)
    else:
        form = AutomationForm(owner=request.user,
                             initial={"service_pitch": ai.DEFAULT_OFFER})

    return render(request, "outreach/automation_form.html", {
        "nav": "automation",
        "form": form,
        "accounts": accounts,
        "can_send": bool(usable),
        "categories": list(CATEGORIES),
        "countries": list(places.country_choices()),
        "zones": list(schedule.COMMON_ZONES),
        "styles": list(styles.STYLES.values()),
    })


@transaction.atomic
def _create(request: HttpRequest, form: AutomationForm) -> AutomationPlan:
    """Write the campaign and its plan. One transaction, or neither.

    A plan without its campaign is unreachable and a campaign without its plan is a
    manual campaign somebody did not ask for, so the two are written together or not
    at all.
    """
    values = form.plan_values()
    account = values["email_account"]

    campaign = Campaign.objects.create(
        owner=request.user,
        # The first of each, so the existing campaign label reads sensibly. The
        # full lists live on the plan; this is the human name for the row.
        country=(values["countries"] or [""])[0][:120],
        city=(values["cities"] or [""])[0][:120],
        category=(values["categories"] or [""])[0][:120],
        sender_name=account.sender_name or request.user.get_full_name(),
        sender_email=account.sender_email,
        sender_company=django_settings.OUTREACH_SENDER_COMPANY,
        provider=account.provider,
        service_pitch=form.cleaned_data["service_pitch"],
        # Draft until the user presses Start. Creating a campaign is not starting
        # one, and a form submit that began sending would be a surprise.
        status=Campaign.Status.DRAFT,
        phase=Campaign.Phase.SETUP,
    )
    # Which mailbox may send, recorded the same way a manual campaign records it, so
    # `_sending_identity` and `sending_accounts` resolve it identically.
    campaign.sending_accounts.set([account])

    plan = AutomationPlan.objects.create(
        campaign=campaign, owner=request.user, **values)

    # Write down every (country, city, category) it will search, so the dashboard
    # can say how much ground is left before the first pass runs.
    prospecting.ensure_searches(plan)

    event_log.record(campaign, event_log.Kind.SCHEDULE,
                     f"Campaign created: {plan.name}",
                     detail=f"{schedule.describe(plan)}; "
                            f"{plan.daily_target}/day up to {plan.total_target}")
    return plan


# --------------------------------------------------------------------------- #
# Watching one
# --------------------------------------------------------------------------- #

@require_GET
def automation_view(request: HttpRequest, pk: int) -> HttpResponse:
    """The campaign dashboard: the figures, the schedule, and the activity log."""
    plan = _my_plan(request, pk)
    return render(request, "outreach/automation.html", {
        "nav": "automation",
        "plan": plan,
        "campaign": plan.campaign,
        "figures": figures(plan),
        "window": schedule.state(plan),
        "events": event_log.recent(plan.campaign, limit=40),
        "controls": campaign_ops.controls(plan.campaign),
        "searches": plan.searches.all()[:60],
        "account_report": mailaccounts.selection_report(plan.campaign),
    })


def figures(plan: AutomationPlan) -> dict:
    """Everything §3 asks for, counted from the tables on each request.

    Not kept as counters on the plan. The one number that *is* stored -- the day
    row's `reserved` -- is stored because it has to be enforced atomically, and even
    that is reported beside `sent`, which is counted, so a drift between them would
    be visible rather than hidden.
    """
    campaign = plan.campaign
    drafts = campaign.drafts
    today = plan.days.filter(day=schedule.local_date(plan)).first()
    dashboard = campaign_ops.dashboard(campaign)

    by_status = dict(drafts.values_list("status")
                     .annotate(n=Count("status"))
                     .values_list("status", "n"))

    return {
        # --- targets --------------------------------------------------------- #
        "sent": dashboard["initial_sent"],
        "total_target": plan.total_target,
        "remaining": plan.remaining_total,
        "percent": min(100, round(100 * dashboard["initial_sent"]
                                  / max(1, plan.total_target))),
        "today_sent": today.sent if today else 0,
        "today_reserved": today.reserved if today else 0,
        "today_skipped": today.skipped if today else 0,
        "today_failed": today.failed if today else 0,
        "daily_target": plan.daily_target,
        "today_remaining": max(
            0, plan.daily_target - (today.reserved if today else 0)),

        # --- the pipeline ---------------------------------------------------- #
        "pool": by_status.get(EmailDraft.Status.PENDING, 0),
        "audited": drafts.exclude(analysis_status="").count(),
        "processed": drafts.exclude(processed_at=None).count(),
        "skipped": sum(by_status.get(status, 0) for status in (
            EmailDraft.Status.NO_EMAIL, EmailDraft.Status.EXCLUDED,
            EmailDraft.Status.DUPLICATE, EmailDraft.Status.SUPPRESSED)),
        "failed": by_status.get(EmailDraft.Status.FAILED, 0),
        "held": by_status.get(EmailDraft.Status.GENERATED, 0),

        # --- what came back -------------------------------------------------- #
        "replies": dashboard["replies"],
        "bounced": dashboard["bounced"],
        "opted_out": dashboard["opted_out"],
        "awaiting": dashboard["awaiting_reply"],
        "followups_ready": dashboard["followups_ready"],
        "followups_sent": dashboard["followups_sent"],

        # --- where it is up to ----------------------------------------------- #
        "searches_left": prospecting.searches_left(plan),
        "searches_total": plan.searches.count(),
        "last_activity": plan.last_activity_at or event_log.last_activity(campaign),
        "next_run": plan.next_run_at,
        "completion_reason": plan.completion_reason,
        "capacity_today": (mailaccounts.remaining_today(plan.email_account)
                           if plan.email_account else 0),
    }


@require_GET
def automation_state(request: HttpRequest, pk: int) -> JsonResponse:
    """The dashboard's live figures, for polling.

    Read-only, and deliberately so: a page that could make the worker do something
    by being open would make "is it running?" unanswerable.
    """
    plan = _my_plan(request, pk)
    window = schedule.state(plan)
    return JsonResponse({
        "status": plan.campaign.status,
        "status_label": plan.campaign.get_status_display(),
        "status_note": plan.campaign.status_note,
        "may_send": plan.campaign.may_send,
        "window": {
            "open": window.open,
            "finished": window.finished,
            "reason": window.reason,
            "next_open": (window.next_open.isoformat()
                          if window.next_open else None),
        },
        "figures": _jsonable(figures(plan)),
        "events": [
            {
                "kind": row.kind,
                "message": row.message,
                "detail": row.detail,
                "at": row.created_at.isoformat(),
                "time": row.created_at.astimezone(
                    schedule.zone(plan.timezone_name)).strftime("%H:%M"),
                "bad": row.is_bad,
            }
            for row in event_log.recent(plan.campaign, limit=25)
        ],
    })


def _jsonable(values: dict) -> dict:
    """Datetimes as ISO strings; everything else as it is."""
    out = {}
    for key, value in values.items():
        out[key] = value.isoformat() if hasattr(value, "isoformat") else value
    return out


# --------------------------------------------------------------------------- #
# Controlling one
# --------------------------------------------------------------------------- #

@require_POST
def automation_start(request: HttpRequest, pk: int) -> JsonResponse:
    """Hand a configured campaign to the worker.

    Does no work. The campaign becomes active -- or scheduled, if its window has
    not opened -- and the worker picks it up on its next pass. Saying so plainly is
    the point: a button that appeared to start sending would be describing something
    that has not happened.
    """
    plan = _my_plan(request, pk)

    blocked = _cannot_start(plan)
    if blocked:
        return JsonResponse({"error": blocked}, status=409)

    try:
        message = automation.start(plan)
    except campaign_ops.TransitionError as exc:
        return JsonResponse({"error": str(exc)}, status=409)

    plan.campaign.refresh_from_db()
    return JsonResponse({
        "started": True,
        "message": message,
        "status": plan.campaign.status,
        "status_label": plan.campaign.get_status_display(),
        "dashboard_url": reverse("outreach:automation_view", args=[plan.pk]),
    })


def _cannot_start(plan: AutomationPlan) -> str:
    """"" if this campaign may start, otherwise the sentence saying why not.

    §19 again, at the last moment. The form checked all of this when the campaign
    was created, and any of it can have changed since -- an account switched off, a
    password cleared, a start date that has passed. A campaign must not enter
    RUNNING on the strength of a check made last week.
    """
    account = plan.email_account
    if account is None:
        return ("This campaign has no sending address. Add one in Settings and "
                "create the campaign again.")
    account.refresh_from_db()
    if not account.is_active:
        return f"{account.name} is switched off. Activate it in Settings first."
    if not account.configured:
        return (f"No password is stored for {account.name}. Add one in Settings "
                "first.")
    if not (plan.countries and plan.cities and plan.categories):
        return ("This campaign has nothing to search for. It needs at least one "
                "country, city and category.")
    if plan.daily_target < 1 or plan.total_target < 1:
        return "Both targets have to be at least 1."
    if not ai.describe_credentials()[0]:
        return ("No AI provider is configured, so no email could be written. Add "
                "a credential in Settings first.")
    return ""
