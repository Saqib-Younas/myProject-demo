"""
The screens for auditing one submitted website.

Four pages and five endpoints, and the shape of all of them follows from one rule:
**the person decides.** The worker crawls, reviews and drafts; the browser shows what
it produced and offers a Send button. Nothing here sends without a request that says
so explicitly, and the send endpoint refuses a request that does not carry the
confirmation.

The other rule is that the status is real. `audit_state` counts rows and reads the
job's own state -- it never advances anything, and a page left open does not make the
audit progress any faster than a page nobody opened.
"""

from __future__ import annotations

from django.http import HttpRequest, HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.decorators.http import require_GET, require_POST

from apps.ai import styles
from apps.auditing import contacts, crawler, measurements, safeurl, scoring
from apps.core import paging
from apps.outreach.mail import accounts as mailaccounts
from apps.outreach.mail import auditsend
from apps.outreach.models import AuditJob, EmailAccount
from apps.outreach.services import websiteaudit as siteaudit


def _my_job(request: HttpRequest, pk: int) -> AuditJob:
    """One audit, scoped to the signed-in account. 404, never 403."""
    return get_object_or_404(
        AuditJob.objects.select_related("draft", "owner", "sent_account"),
        pk=pk, owner=request.user)


def _json(request: HttpRequest) -> dict:
    import json

    try:
        return json.loads(request.body or b"{}")
    except json.JSONDecodeError:
        return {}


# --------------------------------------------------------------------------- #
# Starting one
# --------------------------------------------------------------------------- #

def audit_new(request: HttpRequest) -> HttpResponse:
    """The form: one field, one button (§1).

    No country, no city, no category, no map. The URL is the target, and asking for
    anything else would be asking the user to describe a business the crawl is about
    to describe by itself.
    """
    error = ""
    submitted = ""

    if request.method == "POST":
        submitted = (request.POST.get("url") or "").strip()
        try:
            job = siteaudit.create(request.user, submitted)
        except safeurl.UnsafeUrl as exc:
            error = str(exc)
        else:
            # Started immediately so the status page has something to show, and
            # also left queued for `run_audits` -- whichever gets there first
            # claims it, and the other finds it taken.
            siteaudit.start_in_background(job)
            return redirect("outreach:audit_view", pk=job.pk)

    return render(request, "outreach/audit_new.html", {
        "nav": "audit",
        "error": error,
        "submitted": submitted,
        "accounts": mailaccounts.all_statuses(request.user),
        "recent": AuditJob.objects.filter(owner=request.user)[:8],
        # Shown on the form so the crawl's limits are stated rather than
        # discovered, and read from the analyzer so the page cannot claim a limit
        # the crawler does not have.
        "limits": {
            "pages": crawler.MAX_PAGES,
            "depth": crawler.MAX_DEPTH,
            "timeout": crawler.TIMEOUT,
        },
    })


@require_GET
def audit_list(request: HttpRequest) -> HttpResponse:
    """Every website this account has audited."""
    jobs = (AuditJob.objects.filter(owner=request.user)
            .select_related("draft", "sent_account"))
    context = paging.page_context(request, jobs, label="audits")
    return render(request, "outreach/audit_list.html", {
        "nav": "audit",
        "rows": context["rows"],
        "paging": context,
    })


# --------------------------------------------------------------------------- #
# Watching and reviewing one
# --------------------------------------------------------------------------- #

@require_GET
def audit_view(request: HttpRequest, pk: int) -> HttpResponse:
    """One audit: the status while it runs, the results and the email after."""
    job = _my_job(request, pk)
    accounts = mailaccounts.all_statuses(request.user)
    usable = [row for row in accounts if row["sendable"]]

    return render(request, "outreach/audit.html", {
        "nav": "audit",
        "job": job,
        "draft": job.draft,
        "findings": _findings(job),
        "shortlist": _shortlist(job),
        "page_checks": _page_checks(job),
        "contacts": _contact_view(job),
        "accounts": accounts,
        "can_send": bool(usable),
        "account": usable[0] if usable else None,
        "blocked": siteaudit.blocked_reason(job) if job.reviewable else "",
        "style": styles.BRIEF,
    })


#: The page kinds worth reporting on by name (§4). Ordered by how much a business
#: owner cares, not by the crawler's scoring. Every one is a kind `analyzer` knows
#: how to recognise -- asserted below, so a rename there does not leave this list
#: quietly asking about pages the crawler never looks for.
REPORTED_KINDS = ("contact", "about", "services", "pricing", "faq",
                  "testimonials", "team")

assert set(REPORTED_KINDS) <= {kind for kind, _pattern, _score in measurements.PAGE_KINDS}


def _page_checks(job: AuditJob) -> list[dict]:
    """Which useful pages were found, and which were not.

    "Pricing page: not found" is a finding in itself -- for a trade business it is
    one of the most common reasons a visitor leaves -- so the absence is reported
    rather than left out.
    """
    seen = job.pages_seen or {}
    rows = [{"kind": "home", "label": "Homepage",
             "url": seen.get("home", ""), "found": "home" in seen}]
    for kind in REPORTED_KINDS:
        rows.append({
            "kind": kind,
            "label": f"{kind.replace('_', ' ').capitalize()} page",
            "url": seen.get(kind, ""),
            "found": kind in seen,
        })
    # Anything else the crawl happened to read, so nothing is hidden.
    for kind, url in seen.items():
        if kind not in REPORTED_KINDS and kind != "home":
            rows.append({"kind": kind, "label": kind.capitalize(),
                        "url": url, "found": True})
    return rows


def _findings(job: AuditJob) -> dict:
    """Confirmed findings by priority, with the unverified ones kept apart (§11).

    The separation is the point. A finding with evidence is something to say to a
    business owner; one without is a note to ourselves, and mixing them would make
    the confirmed list untrustworthy.
    """
    from apps import ai

    confirmed: dict[str, list] = {"high": [], "medium": [], "low": []}
    unverified: list = []

    for finding in job.findings:
        if ai.is_unverified(finding) or not (finding.evidence or "").strip():
            unverified.append(finding)
            continue
        bucket = (finding.priority or "medium").lower()
        confirmed.setdefault(bucket, []).append(finding)

    # Ordered bands rather than a dict, so the template renders a list instead of
    # filtering keys it should not have to know about.
    bands = [(level.upper(), confirmed.get(level, []))
             for level in ("high", "medium", "low")]
    return {
        "bands": [(label, rows) for label, rows in bands if rows],
        "unverified": unverified,
        "confirmed_count": sum(len(rows) for _label, rows in bands),
    }


def _shortlist(job: AuditJob) -> list:
    """The one to three findings the email is built on."""
    if job.draft_id is None:
        return []
    return scoring.rank_for_email(job.draft.finding_objects,
                                 limit=styles.BRIEF.max_findings)


def _contact_view(job: AuditJob) -> dict:
    """The contact details, ready for the template."""
    details = job.contact_details()
    by_kind: dict[str, list] = {}
    for row in details:
        by_kind.setdefault(row.get("kind", "other"), []).append(row)

    return {
        "emails": by_kind.get(contacts.EMAIL, []),
        "phones": by_kind.get(contacts.PHONE, []),
        "addresses": by_kind.get(contacts.ADDRESS, []),
        "socials": by_kind.get(contacts.SOCIAL, []),
        "hours": by_kind.get(contacts.HOURS, []),
        "people": by_kind.get(contacts.PERSON, []),
        "pages_checked": job.contact_pages,
        "found_email": bool(by_kind.get(contacts.EMAIL)),
    }


@require_GET
def audit_state(request: HttpRequest, pk: int) -> JsonResponse:
    """The job's live state, for the status page to poll.

    Read-only. It reports what the worker has done; it cannot make the worker do
    anything, which is what makes "is it still running?" answerable.
    """
    job = _my_job(request, pk)
    return JsonResponse({
        "state": job.state,
        "state_label": job.get_state_display(),
        "note": job.state_note,
        "percent": job.progress_percent,
        "running": job.running,
        "reviewable": job.reviewable,
        "failed": job.failed,
        "sent": job.is_sent,
        "failure": job.failure,
        "failure_label": job.get_failure_display() if job.failure else "",
        "error": job.error,
        "site": job.site,
        "pages_found": job.pages_found,
        "pages_crawled": job.pages_crawled,
        "pages_seen": job.pages_seen or {},
        "page_checks": _page_checks(job),
        "findings": len(job.findings),
        "no_findings": job.no_findings,
        "recipient": job.recipient,
        "business_name": job.business_name,
        "subject": job.draft.subject if job.draft_id else "",
        "reload": job.reviewable or job.failed or job.is_sent,
    })


# --------------------------------------------------------------------------- #
# Editing the draft
# --------------------------------------------------------------------------- #

@require_POST
def audit_save(request: HttpRequest, pk: int) -> JsonResponse:
    """Save the recipient, subject and body as the user edited them (§14).

    The user's text wins. Nothing is re-validated against the writing rules here --
    those exist to stop a *machine* sending something vague, and a person who has
    read the email and changed it is the authority this workflow defers to.
    """
    job = _my_job(request, pk)
    if job.is_sent:
        return JsonResponse(
            {"error": "This email has already been sent, so it cannot be "
                      "edited."}, status=409)
    if job.draft_id is None:
        return JsonResponse({"error": "There is no draft to save."}, status=409)

    payload = _json(request)
    recipient = str(payload.get("recipient", "")).strip()
    subject = str(payload.get("subject", "")).strip()
    body = str(payload.get("body", ""))

    if recipient:
        if "@" not in recipient or " " in recipient:
            return JsonResponse(
                {"error": f"{recipient} is not an email address."}, status=400)
        # Typed by hand, so the next crawl must not overwrite it (§17).
        manual = recipient.casefold() != (job.recipient or "").casefold()
        AuditJob.objects.filter(pk=job.pk).update(
            recipient=recipient[:254],
            recipient_manual=job.recipient_manual or manual)
        job.draft.email = recipient[:254]

    job.draft.subject = subject[:400]
    job.draft.body = body
    job.draft.edited = True
    job.draft.save(update_fields=["email", "subject", "body", "edited"])
    job.refresh_from_db()

    return JsonResponse({
        "saved": True,
        "message": "Draft saved.",
        "recipient": job.recipient,
        "blocked": siteaudit.blocked_reason(job),
    })


@require_POST
def audit_regenerate(request: HttpRequest, pk: int) -> JsonResponse:
    """Write the email again from the same findings (§14).

    The site is not re-crawled and the findings are not re-derived: this is "say it
    differently", and re-reading somebody's website to reword our own email would
    spend their bandwidth on our indecision.
    """
    job = _my_job(request, pk)
    if job.is_sent:
        return JsonResponse(
            {"error": "This email has already been sent."}, status=409)

    ok, message = siteaudit.regenerate(job, str(_json(request).get("hint", "")))
    if not ok:
        return JsonResponse({"error": message}, status=502)

    job.refresh_from_db()
    return JsonResponse({
        "message": message,
        "subject": job.draft.subject,
        "body": job.draft.body,
        "observation": job.draft.observation,
    })


# --------------------------------------------------------------------------- #
# Sending, after a person says so
# --------------------------------------------------------------------------- #

@require_POST
def audit_send(request: HttpRequest, pk: int) -> JsonResponse:
    """Send the email. Requires an explicit confirmation in the request (§15).

    The confirmation is a field in the body rather than a second endpoint, so a
    request that reaches here by accident -- a replayed fetch, a double submit, a
    script -- does not send anything. The browser shows the recipient and subject
    and asks; this checks that the answer came back.
    """
    job = _my_job(request, pk)
    payload = _json(request)

    if not payload.get("confirm"):
        return JsonResponse({
            "error": "Not sent: the send was not confirmed.",
            "confirm": {
                "recipient": job.recipient,
                "subject": job.draft.subject if job.draft_id else "",
            },
        }, status=400)

    account = _account(request, payload.get("account"))
    if account is None:
        return JsonResponse({
            "error": "No sending address is available. Add one in Settings.",
        }, status=409)

    try:
        auditsend.send(job, account)
    except auditsend.SendRefused as exc:
        return JsonResponse({"error": str(exc)}, status=409)

    job.refresh_from_db()
    return JsonResponse({
        "sent": True,
        "message": f"Sent to {job.recipient}.",
        "state": job.state,
        "state_label": job.get_state_display(),
        "message_id": job.message_id,
        "sent_at": job.sent_at.isoformat() if job.sent_at else "",
        "url": reverse("outreach:audit_view", args=[job.pk]),
    })


def _account(request: HttpRequest, wanted) -> EmailAccount | None:
    """The mailbox to send from: the one asked for, or the first that can send.

    Scoped to the signed-in account in the query, so an id in the request body
    grants nothing.
    """
    if wanted:
        try:
            return mailaccounts.accounts(request.user).get(pk=int(wanted))
        except (TypeError, ValueError, EmailAccount.DoesNotExist):
            return None
    usable = [row for row in mailaccounts.accounts(request.user) if row.sendable]
    return usable[0] if usable else None


@require_POST
def audit_retry(request: HttpRequest, pk: int) -> JsonResponse:
    """Queue a failed or finished audit to run again.

    A fresh crawl of the same URL. Offered after a failure -- a site that timed out
    once may answer now -- and after a successful audit, for a site that has since
    been changed.
    """
    job = _my_job(request, pk)
    if job.running:
        return JsonResponse({"error": "This audit is already running."},
                            status=409)
    if job.is_sent:
        return JsonResponse({
            "error": "This audit's email has been sent. Start a new audit for a "
                     "fresh look at the site.",
        }, status=409)

    AuditJob.objects.filter(pk=job.pk).update(
        state=AuditJob.State.QUEUED, state_note="Queued again.", failure="",
        error="", pages_crawled=0, pages_found=0, pages_seen={},
        no_findings=False, finished_at=None, locked_by="", locked_until=None)
    job.refresh_from_db()
    siteaudit.start_in_background(job)

    return JsonResponse({"message": f"Auditing {job.site} again.",
                         "state": job.state})
