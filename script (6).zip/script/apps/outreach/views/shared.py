"""
Small things every view module needs.

Two kinds, and both are here so that no view module has to define them again:

  * **`_json`** -- read a JSON body without raising on a malformed one.
  * **the `_my_*` lookups** -- fetch one object *scoped to the signed-in account*.
    Ownership is in the query rather than checked afterwards, and a miss is a 404
    rather than a 403: an id in a URL grants nothing, and a 403 would confirm the
    object exists.
"""

from __future__ import annotations

from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from django.http import HttpRequest
from django.shortcuts import get_object_or_404

from apps.core.http import json_body
from apps.outreach import selectors as pipeline
from apps.outreach.models import (
    Campaign,
    EmailAccount,
    EmailDraft,
    FollowUp,
    SentLead,
)

#: A cap on how many leads one campaign may carry, so a runaway
#: selection cannot become a 5,000-lead campaign by accident.
MAX_LEADS_PER_CAMPAIGN = 300


def _json(request: HttpRequest) -> dict:
    """Read a JSON body, tolerating a malformed one."""
    return json_body(request)
def _valid_email(value: str) -> bool:
    try:
        validate_email(value)
    except ValidationError:
        return False
    return True
def _my_campaign(request: HttpRequest, campaign_id) -> Campaign:
    return get_object_or_404(Campaign, pk=campaign_id, owner=request.user)
def _my_draft(request: HttpRequest, pk: int) -> EmailDraft:
    return get_object_or_404(
        EmailDraft.objects.select_related("campaign"),
        pk=pk, campaign__owner=request.user,
    )
def _my_lead(request: HttpRequest, pk: int) -> SentLead:
    return get_object_or_404(SentLead, pk=pk, owner=request.user)
def _my_followup(request: HttpRequest, pk: int) -> FollowUp:
    return get_object_or_404(
        FollowUp.objects.select_related("lead", "campaign"),
        pk=pk, owner=request.user,
    )
def _filters_from(request: HttpRequest) -> dict:
    """The filter set carried in the query string, validated against the lists."""
    def pick(name: str, options, default: str = "all") -> str:
        value = (request.GET.get(name) or default).strip().lower()
        return value if value in {key for key, _label in options} else default

    return {
        "website": pick("website", pipeline.WEBSITE_FILTERS),
        "priority": pick("priority", pipeline.PRIORITY_FILTERS),
        "outreach": pick("outreach", pipeline.OUTREACH_FILTERS),
        "whatsapp": pick("whatsapp", pipeline.WHATSAPP_FILTERS),
        "country": (request.GET.get("country") or "").strip()[:120],
        "category": (request.GET.get("category") or "").strip()[:120],
        "search": (request.GET.get("q") or "").strip()[:120],
        "sort": pick("sort", pipeline.SORTS, "score"),
    }
def _my_account(request: HttpRequest, pk: int) -> EmailAccount:
    """One of this workspace's accounts, or 404.

    404 rather than 403: "forbidden" would confirm that an account with that id
    exists and belongs to somebody else.
    """
    return get_object_or_404(EmailAccount, pk=pk, owner=request.user)
