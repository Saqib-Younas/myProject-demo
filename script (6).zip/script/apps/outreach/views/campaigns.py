"""
A campaign from creation to report.

The lifecycle in one place: `start` builds one from selected leads, `setup` collects
the sender and the offer, `run` hands it to the pipeline, `workspace` and `state` show
it working, `campaign_status` and `cancel`/`resume` control it, and `report` is what is
left afterwards.

`_state` is the payload the workspace polls. It reports what the pipeline has done and
cannot make it do anything -- which is what makes the progress on screen worth
believing.
"""

from __future__ import annotations

import os

from django.conf import settings as django_settings
from django.db import IntegrityError, models, transaction
from django.http import HttpRequest, HttpResponse, JsonResponse
from django.shortcuts import redirect, render
from django.urls import reverse
from django.views.decorators.http import require_GET, require_POST

from apps import ai
from apps.ai import credentials
from apps.core import paging
from apps.outreach.mail import accounts as mailaccounts
from apps.outreach.mail import followups as followup_rules
from apps.outreach.mail import providers
from apps.outreach.models import (
    Campaign,
    EmailDraft,
    FollowUp,
)
from apps.outreach.services import campaigns, history
from apps.outreach.services import pipeline as runner

from .shared import (
    MAX_LEADS_PER_CAMPAIGN,
    _json,
    _my_campaign,
    _valid_email,
)


def _started(draft: EmailDraft, current_id: int | None) -> bool:
    """Has this lead's own analyse-and-write cycle begun?

    The workspace only shows cards for leads the run has reached, so the list
    grows one company at a time instead of opening as a wall of empty cards.
    A lead from a campaign that predates sequential processing has no
    `processed_at`, so the status check keeps its card visible too.
    """
    return (
        draft.processed_at is not None
        or draft.pk == current_id
        or draft.status != EmailDraft.Status.PENDING
    )
def _draft_json(draft: EmailDraft, contacted: dict[str, str],
                current_id: int | None = None) -> dict:
    return {
        "id": draft.pk,
        "sequence": draft.sequence,
        "started": _started(draft, current_id),
        "processed": draft.processed_at is not None,
        "business_name": draft.business_name,
        "email": draft.email,
        "website": draft.website,
        "category": draft.category,
        "address": draft.address,
        "phone": draft.phone,
        "status": draft.status,
        "status_label": draft.get_status_display(),
        "subject": draft.subject,
        "body": draft.body,
        "observation": draft.observation,
        "analysis_status": draft.analysis_status,
        "analysis_note": draft.analysis_note,
        "has_material": draft.has_website_material,
        "business_summary": draft.business_summary,
        "findings": draft.findings or [],
        "findings_used": draft.findings_used or [],
        "pages_read": draft.pages_read or [],
        "pages_discovered": draft.pages_discovered,
        "edited": draft.edited,
        "regenerations": draft.regenerations,
        "error_message": draft.error_message,
        "force_contact": draft.force_contact,
        "force_reason": draft.force_reason,
        # A duplicate can be overridden with a written reason; a suppression
        # cannot, so the UI must be able to tell them apart.
        "can_recontact": draft.status == EmailDraft.Status.DUPLICATE,
        "sent_at": draft.sent_at.isoformat() if draft.sent_at else None,
        "previously_contacted": contacted.get(draft.email.lower(), ""),
    }
def _previous_contacts(campaign: Campaign) -> dict[str, str]:
    """Addresses this project has already emailed in an *earlier* campaign."""
    rows = (
        EmailDraft.objects
        .filter(status=EmailDraft.Status.SENT)
        .exclude(campaign_id=campaign.pk)
        .values_list("email", "sent_at")
    )
    seen: dict[str, str] = {}
    for email, sent_at in rows:
        key = (email or "").lower()
        if key and key not in seen:
            seen[key] = sent_at.date().isoformat() if sent_at else "earlier"
    return seen
def _state(campaign: Campaign) -> dict:
    contacted = _previous_contacts(campaign)
    drafts = sorted(campaign.drafts.all(),
                    key=lambda d: (d.sequence or 10**6, d.business_name))
    current_id = campaign.current_draft_id
    return {
        "campaign": {
            "id": str(campaign.id),
            "label": campaign.label,
            "phase": campaign.phase,
            "phase_label": campaign.get_phase_display(),
            "error": campaign.error,
            "sender_name": campaign.sender_name,
            "sender_email": campaign.sender_email,
            "provider": campaign.provider,
            "provider_label": (
                providers.PROVIDERS[campaign.provider].label
                if campaign.provider in providers.PROVIDERS else ""
            ),
            "running": runner.is_running(campaign.id),
            # Work that claims to be running but is not -- almost always a
            # server restart mid-campaign. The workspace offers to pick it up.
            "stalled": runner.stalled(campaign),
            # Paused, cancelling, cancelled or running, with the facts behind it.
            # The panel reads this rather than interpreting the phase string, so
            # the server stays the only thing that decides what a run's state is.
            "control": campaign.control_state(),
        },
        "counts": campaign.counts(),
        "progress": campaign.progress(),
        "drafts": [_draft_json(d, contacted, current_id)
                   for d in drafts if d.in_workflow],
        "skipped": [
            _draft_json(d, contacted, current_id)
            for d in drafts if not d.in_workflow
        ],
    }
@require_POST
def start(request: HttpRequest) -> JsonResponse:
    """Create a campaign from the leads ticked on the results page."""
    payload = _json(request)
    leads = payload.get("leads") or []
    if not isinstance(leads, list) or not leads:
        return JsonResponse({"error": "No leads were selected."}, status=400)
    if len(leads) > MAX_LEADS_PER_CAMPAIGN:
        return JsonResponse(
            {"error": f"Select at most {MAX_LEADS_PER_CAMPAIGN} leads per campaign."},
            status=400,
        )

    area = payload.get("area") or {}
    with transaction.atomic():
        campaign = Campaign.objects.create(
            owner=request.user,
            country=str(area.get("country", ""))[:120],
            city=str(area.get("city", ""))[:120],
            category=str(payload.get("category", ""))[:120],
        )

        # One history snapshot for the whole batch rather than a query per lead.
        index = history.Index(request.user)
        blocklist = history.SuppressionIndex(request.user)
        seen: set[str] = set()
        blocked = 0
        suppressed = 0
        for lead in leads:
            if not isinstance(lead, dict):
                continue
            email = str(lead.get("email", "")).strip()
            key = email.lower()
            note = ""

            if not email or not _valid_email(email):
                status = EmailDraft.Status.NO_EMAIL
                email = ""
            elif stop := blocklist.match(email=email,
                                         website=str(lead.get("website", ""))):
                # The do-not-contact list is absolute and is checked first, so
                # its record is never overwritten by a weaker duplicate match.
                status = EmailDraft.Status.SUPPRESSED
                note = stop.sentence()
                suppressed += 1
            elif key in seen:
                # Two map pins sharing one address: keep the first.
                status = EmailDraft.Status.DUPLICATE
                note = "Skipped: another selected lead uses this address."
            else:
                match = index.match(
                    email=email,
                    website=str(lead.get("website", "")),
                    business_name=str(lead.get("business_name", "")),
                    city=str(lead.get("city", "")),
                )
                if match:
                    # Already contacted: recorded, but kept out of the workflow
                    # so it costs no crawl and no AI call.
                    status = EmailDraft.Status.DUPLICATE
                    note = (
                        "Skipped: already contacted — "
                        + history.MATCH_LABELS.get(match.matched_by, match.matched_by)
                        + (f" on {match.sent_date}" if match.sent_date else "")
                        + (f" in {match.campaign_label}" if match.campaign_label else "")
                    )
                    blocked += 1
                else:
                    seen.add(key)
                    status = EmailDraft.Status.PENDING

            try:
                # Savepoint per row: a stray collision skips that lead instead
                # of rolling back the whole campaign.
                with transaction.atomic():
                    EmailDraft.objects.create(
                        campaign=campaign,
                        business_name=str(lead.get("business_name", ""))[:255] or "Unnamed",
                        email=email,
                        website=str(lead.get("website", ""))[:500],
                        category=str(lead.get("category", ""))[:160],
                        address=str(lead.get("address", ""))[:400],
                        phone=str(lead.get("phone", ""))[:80],
                        city=str(lead.get("city", ""))[:160],
                        country=str(lead.get("country", ""))[:160],
                        latitude=lead.get("latitude"),
                        longitude=lead.get("longitude"),
                        source=str(lead.get("source", ""))[:500],
                        status=status,
                        error_message=note,
                    )
            except IntegrityError:
                continue  # unique constraint caught a duplicate address

    return JsonResponse({
        "campaign_id": str(campaign.id),
        "setup_url": reverse("outreach:setup", args=[campaign.id]),
        "eligible": campaign.drafts.filter(status=EmailDraft.Status.PENDING).count(),
        "already_contacted": blocked,
        "suppressed": suppressed,
    })
@require_GET
def setup(request: HttpRequest, campaign_id) -> HttpResponse:
    campaign = _my_campaign(request, campaign_id)
    if campaign.phase != Campaign.Phase.SETUP:
        return redirect("outreach:workspace", campaign_id=campaign.id)

    drafts = list(campaign.drafts.all())

    # One row per selected lead with the badge it should wear. Built here rather
    # than in the template: the state depends on the sending history, and the
    # template language cannot do a keyed lookup.
    icons = {"ready": "mail", "contacted": "clock", "invalid": "alert",
             "sent": "check-circle", "failed": "x-circle", "sending": "send"}
    rows = []
    for draft in drafts:
        state = draft.contact_state
        rows.append({
            "draft": draft,
            "state": state,
            "label": history.STATES[state]["label"],
            "icon": icons.get(state, "info"),
            "selectable": draft.status == EmailDraft.Status.PENDING,
            "note": draft.error_message if state == "contacted" else "",
        })
    # Contactable leads first; the rest are context, not choices.
    rows.sort(key=lambda r: (0 if r["selectable"] else 1,
                             r["draft"].business_name.casefold()))

    eligible = [d for d in drafts if d.status == EmailDraft.Status.PENDING]
    blocked = [d for d in drafts if d.status == EmailDraft.Status.DUPLICATE]

    # A campaign started earlier keeps whatever it was given; a fresh one is
    # pre-filled from the configured identity in settings.
    return render(request, "outreach/setup.html", {
        "campaign": campaign,
        "all_drafts": rows,
        "blocked_count": len(blocked),
        "eligible": eligible,
        "ineligible": [d for d in drafts if not d.in_workflow],
        "providers": providers.PROVIDERS.values(),
        "sender_name": campaign.sender_name or django_settings.OUTREACH_SENDER_NAME,
        "sender_email": campaign.sender_email or django_settings.OUTREACH_SENDER_EMAIL,
        "sender_company": campaign.sender_company or django_settings.OUTREACH_SENDER_COMPANY,
        "chosen_provider": campaign.provider or django_settings.OUTREACH_PROVIDER,
        "default_offer": campaign.service_pitch or ai.DEFAULT_OFFER,
        "nav": "search",
        # So the screen can show which AI provider is about to write the emails,
        # and whether it is actually usable, before anything is spent.
        "ai_provider": credentials.status(ai.provider(), request.user)
                       if credentials.known(ai.provider()) else None,
        "ai_model": ai.model() if ai.describe_credentials()[0] else "",
        # §4: the addresses this campaign may send from. Empty means "use the
        # single sender configured in .env", which is what every campaign did
        # before accounts existed.
        "email_accounts": mailaccounts.all_statuses(request.user),
        "chosen_accounts": set(
            campaign.sending_accounts.values_list("pk", flat=True)),
        "account_report": mailaccounts.selection_report(campaign),
    })
@require_POST
def run(request: HttpRequest, campaign_id) -> JsonResponse:
    """Save sender settings and start analysis + generation."""
    campaign = _my_campaign(request, campaign_id)
    if campaign.phase != Campaign.Phase.SETUP:
        return JsonResponse(
            {"error": "This campaign has already been started."}, status=409)

    payload = _json(request)
    sender_name = str(payload.get("sender_name", "")).strip()
    sender_email = str(payload.get("sender_email", "")).strip()
    provider = str(payload.get("provider", "")).strip()
    service_pitch = str(payload.get("service_pitch", "")).strip()
    selected = payload.get("selected")

    if not sender_name:
        return JsonResponse({"error": "Enter the sender name."}, status=400)
    if not _valid_email(sender_email):
        return JsonResponse({"error": "Enter a valid sender email address."}, status=400)
    if provider not in providers.PROVIDERS:
        return JsonResponse({"error": "Choose an email provider."}, status=400)
    if len(service_pitch) < 20:
        return JsonResponse({
            "error": "Describe what you offer in a sentence or two -- the AI "
                     "needs it to explain how you can help each business.",
        }, status=400)

    if not isinstance(selected, list) or not selected:
        return JsonResponse({"error": "Select at least one lead."}, status=400)

    # Fail fast on an unconfigured provider. Without this, every lead in the run
    # would be crawled and then fail its AI call with the same message -- paying
    # for the crawls to learn something knowable in advance.
    active = ai.provider()
    resolved = credentials.resolve(active, request.user)
    if not resolved.usable:
        return JsonResponse({
            "error": credentials.NOT_CONFIGURED_TEMPLATE.format(
                label=credentials.spec(active).label
                if credentials.known(active) else active),
            "settings_url": reverse("outreach:settings"),
        }, status=400)

    ids = {int(i) for i in selected if str(i).isdigit()}
    eligible = campaign.drafts.filter(status=EmailDraft.Status.PENDING)
    keep = eligible.filter(pk__in=ids)
    if not keep.exists():
        return JsonResponse({"error": "None of the selected leads are usable."},
                            status=400)

    with transaction.atomic():
        # Deselected leads stay on the record, marked as not chosen.
        eligible.exclude(pk__in=ids).update(status=EmailDraft.Status.EXCLUDED)
        campaign.sender_name = sender_name[:120]
        campaign.sender_email = sender_email
        campaign.sender_company = str(payload.get("sender_company", "")).strip()[:160]
        campaign.provider = provider
        campaign.service_pitch = service_pitch
        campaign.save(update_fields=[
            "sender_name", "sender_email", "sender_company", "provider",
            "service_pitch",
        ])

    runner.start_pipeline(campaign)
    return JsonResponse({
        "workspace_url": reverse("outreach:workspace", args=[campaign.id]),
        "queued": keep.count(),
    })
@require_GET
def workspace(request: HttpRequest, campaign_id) -> HttpResponse:
    campaign = _my_campaign(request, campaign_id)
    if campaign.phase == Campaign.Phase.SETUP:
        return redirect("outreach:setup", campaign_id=campaign.id)
    return render(request, "outreach/workspace.html", {
        "nav": "search",
        "campaign": campaign,
        "provider": providers.PROVIDERS.get(campaign.provider),
        "has_smtp_password_env": bool(os.environ.get("OUTREACH_SMTP_PASSWORD")),
        # Shown under every draft: it is appended at send time, so the review
        # screen has to show it or the review is of the wrong text.
    })
@require_GET
def state(request: HttpRequest, campaign_id) -> JsonResponse:
    campaign = _my_campaign(request, campaign_id)
    return JsonResponse(_state(campaign))
@require_POST
def campaign_status(request: HttpRequest, campaign_id, action: str) -> JsonResponse:
    """Activate, pause, resume or stop a campaign (§22).

    Status is the operator's decision and is separate from `phase`, which is what
    the machinery is doing. Pausing stops new sends and stops the follow-up worker
    touching this campaign; it changes nothing else, so resuming continues from
    where it stopped rather than starting again.

    `resume` and `activate` are the same transition under two names, because they
    are the same thing to the database and different things to a person: one is
    "start this", the other "carry on".
    """
    campaign = _my_campaign(request, campaign_id)
    note = str(_json(request).get("note", ""))[:300]

    wanted = {
        "activate": Campaign.Status.ACTIVE,
        "resume": Campaign.Status.ACTIVE,
        "pause": Campaign.Status.PAUSED,
        "stop": Campaign.Status.STOPPED,
        "complete": Campaign.Status.COMPLETED,
    }.get(action)

    if wanted is None:
        return JsonResponse({
            "error": "Unknown action. Use activate, resume, pause, stop or "
                     "complete.",
        }, status=400)

    try:
        campaigns.set_status(campaign, wanted, note=note)
    except campaigns.TransitionError as exc:
        return JsonResponse({"error": str(exc)}, status=409)

    pending = FollowUp.objects.filter(
        campaign=campaign, status__in=FollowUp.REVIEWABLE).count()
    message = campaigns.WORDING.get(wanted, campaign.get_status_display())
    if wanted == Campaign.Status.PAUSED and pending:
        message += (f" {pending} follow-up(s) already prepared stay where they "
                    "are; they will not be sent while it is paused.")

    return JsonResponse({
        "status": campaign.status,
        "status_label": campaign.get_status_display(),
        "may_send": campaign.may_send,
        "message": message,
        "dashboard": campaigns.dashboard(campaign),
    })
@require_GET
def campaign_dashboard(request: HttpRequest, campaign_id) -> JsonResponse:
    """The §21 figures for one campaign, counted from the tables."""
    campaign = _my_campaign(request, campaign_id)
    return JsonResponse({
        "status": campaign.status,
        "status_label": campaign.get_status_display(),
        "status_note": campaign.status_note,
        "may_send": campaign.may_send,
        "dashboard": campaigns.dashboard(campaign),
        "accounts": mailaccounts.selection_report(campaign)["usable"],
    })
@require_POST
def cancel(request: HttpRequest, campaign_id) -> JsonResponse:
    """Stop the lead-processing job for this campaign.

    Two paths, because the answer depends on whether anything is actually
    running:

      * **a worker is running** -- the request is recorded as CANCEL_REQUESTED
        and the worker settles it. It checks before each lead and before each
        page fetch, so nothing new starts, and the lead in flight is abandoned
        without a completion stamp rather than half-saved.
      * **nothing is running** -- a paused run, or one whose process died. There
        is nobody to notice the request, so it is settled here.

    Idempotent by construction: a campaign that is already cancelled, or already
    cancelling, is reported as such and nothing is written. Pressing Cancel twice
    cannot restart anything or corrupt the state, which is the property the brief
    asks for.

    What it deliberately does not touch: the completion stamps. Every lead that
    finished stays finished, and a later resume starts from the first one that did
    not.
    """
    campaign = _my_campaign(request, campaign_id)

    if campaign.is_cancelled:
        return JsonResponse({
            "cancelled": True, "already": True,
            "message": "Processing was already cancelled.",
            "state": _state(campaign),
        })

    if campaign.phase not in Campaign.CANCELLABLE_PHASES:
        if campaign.phase == Campaign.Phase.SENDING:
            # A different animal: some of those emails are already delivered.
            return JsonResponse({
                "error": "A send is in progress and cannot be cancelled here. "
                         "It stops on its own; anything already delivered is "
                         "recorded in the history.",
            }, status=409)
        return JsonResponse({
            "error": "There is no lead processing to cancel for this campaign.",
        }, status=409)

    running = runner.is_running(campaign.id)

    if campaign.is_cancelling:
        # A previous press is still being acted on. Not an error -- say where it
        # is, and settle it if the worker has since disappeared.
        if running:
            return JsonResponse({
                "cancelled": False, "already": True,
                "message": "Cancelling — finishing the current lead.",
                "state": _state(campaign),
            })
        runner.mark_cancelled(campaign)
        campaign.refresh_from_db()
        return JsonResponse({
            "cancelled": True, "message": "Processing cancelled.",
            "state": _state(campaign),
        })

    if running:
        Campaign.objects.filter(
            pk=campaign.pk, phase__in=Campaign.CANCELLABLE_PHASES,
        ).update(phase=Campaign.Phase.CANCEL_REQUESTED, current_step="")
        campaign.refresh_from_db()
        return JsonResponse({
            "cancelled": False,
            "message": "Cancelling — no further leads will be started.",
            "state": _state(campaign),
        })

    # Paused, or the worker is gone. Nobody is watching for the request, so it
    # is applied directly.
    runner.mark_cancelled(campaign)
    campaign.refresh_from_db()
    unfinished = campaign.unfinished_count()
    return JsonResponse({
        "cancelled": True,
        "message": ("Processing cancelled."
                    + (f" {unfinished} lead(s) were not processed."
                       if unfinished else "")),
        "state": _state(campaign),
    })
@require_POST
def resume(request: HttpRequest, campaign_id) -> JsonResponse:
    """Pick up a campaign that stopped before the end of its queue.

    Three reasons a campaign is sitting still, and all three land here:

      * **paused by a rate limit** -- resumed once the retry window has passed.
        The window is enforced server-side: a browser that resumed early would
        walk straight into the same refusal.
      * **cancelled** -- resumed only because the user asked again, explicitly.
        Nothing auto-resumes a cancelled run; that is the point of cancelling.
      * **stalled** -- the process died mid-run. Offered as before.

    Leads already finished are skipped in every case, so resuming costs nothing
    for work already paid for. A stalled *send* is different: the password is not
    stored, so it cannot be resumed silently -- the queue is released back to
    approved and the user presses Send again.
    """
    campaign = _my_campaign(request, campaign_id)
    kind = runner.stalled(campaign)

    if campaign.is_paused:
        if runner.is_running(campaign.id):
            return JsonResponse({
                "error": "This campaign is waiting out a rate limit and will "
                         "carry on by itself.",
                "state": _state(campaign),
            }, status=409)

        remaining = campaign.retry_seconds
        forced = bool(_json(request).get("force"))
        if remaining and not forced:
            return JsonResponse({
                "error": (f"The AI provider asked to wait {remaining} more "
                          "second(s). Processing resumes automatically when the "
                          "window passes."),
                "retry_seconds": remaining,
                "state": _state(campaign),
            }, status=409)

        if not runner.start_pipeline(campaign, resume=True):
            return JsonResponse({"error": "A job is already running."}, status=409)
        return JsonResponse({"resumed": "pipeline",
                             "remaining": campaign.unfinished_count()})

    if campaign.is_cancelled:
        unfinished = campaign.unfinished_count()
        if not unfinished:
            return JsonResponse({
                "error": "Every lead in this campaign was already processed.",
            }, status=400)
        if not runner.start_pipeline(campaign, resume=True):
            return JsonResponse({"error": "A job is already running."}, status=409)
        return JsonResponse({"resumed": "pipeline", "remaining": unfinished})

    if not kind:
        if runner.is_running(campaign.id):
            return JsonResponse(
                {"error": "This campaign is already running."}, status=409)
        return JsonResponse(
            {"error": "There is nothing to resume for this campaign."}, status=400)

    if kind == "send":
        released = campaign.drafts.filter(
            status=EmailDraft.Status.SENDING,
        ).update(status=EmailDraft.Status.APPROVED)
        Campaign.objects.filter(pk=campaign.pk).update(
            phase=Campaign.Phase.REVIEW,
            error=("The send was interrupted. "
                   f"{released} email(s) were returned to the approved queue -- "
                   "press Send to continue. Anything already delivered is "
                   "recorded in the history and will not be sent twice."),
            current_draft=None, current_step="",
        )
        return JsonResponse({"resumed": "send", "released": released,
                             "counts": campaign.counts()})

    remaining = campaign.drafts.filter(
        sequence__gt=0, processed_at__isnull=True,
    ).exclude(status__in=(EmailDraft.Status.EXCLUDED,
                          EmailDraft.Status.DUPLICATE,
                          EmailDraft.Status.SUPPRESSED,
                          EmailDraft.Status.NO_EMAIL)).count()

    if not runner.start_pipeline(campaign, resume=True):
        return JsonResponse({"error": "A job is already running."}, status=409)

    return JsonResponse({"resumed": "pipeline", "remaining": remaining})
@require_GET
def report(request: HttpRequest, campaign_id) -> HttpResponse:
    campaign = _my_campaign(request, campaign_id)
    drafts = list(campaign.drafts.all())
    return render(request, "outreach/report.html", {
        "nav": "history",
        "campaign": campaign,
        "counts": campaign.counts(),
        # §21: counted from the tables on every request. §22: only the controls the
        # transition table would accept from where this campaign is now.
        "dashboard": campaigns.dashboard(campaign),
        "controls": campaigns.controls(campaign),
        "accounts": mailaccounts.selection_report(campaign),
        # What came back after the send, for this campaign only.
        "replies": followup_rules.stats(request.user, campaign),
        "sent": [d for d in drafts if d.status == EmailDraft.Status.SENT],
        "failed": [d for d in drafts if d.status == EmailDraft.Status.FAILED],
        "other": [d for d in drafts
                  if d.status not in (EmailDraft.Status.SENT,
                                      EmailDraft.Status.FAILED)],
    })
@require_GET
def campaign_history(request: HttpRequest) -> HttpResponse:
    """The campaigns list.

    Named `campaign_history` rather than `history` so it does not shadow the
    `history` module imported at the top of this file -- it did, and every view
    that used the module broke.
    """
    # Server-side pagination, 20 by default. The slice this replaces silently
    # omitted every campaign past the fiftieth, which is the worst kind of limit:
    # the page loaded fine and the records were simply missing.
    #
    # `counts()` runs one query per campaign, which is affordable for a page of 20
    # and was not for an unbounded list -- so paginating made the page cheaper as
    # well as complete.
    # Named `matching` rather than `campaigns`, which is the module this view now
    # needs for the controls -- the local shadowed it.
    matching = Campaign.objects.filter(owner=request.user)

    status = (request.GET.get("status") or "").strip()
    if status in dict(Campaign.Status.choices):
        matching = matching.filter(status=status)

    search = (request.GET.get("q") or "").strip()
    if search:
        matching = matching.filter(
            models.Q(city__icontains=search)
            | models.Q(country__icontains=search)
            | models.Q(category__icontains=search))

    paging_context = paging.page_context(request, matching, label="campaigns")
    # The controls come from the transition table (§22), so a button is only shown
    # for something `set_status` would accept.
    rows = [(c, c.counts(), campaigns.controls(c))
            for c in paging_context["rows"]]
    totals = {
        # The page's figures. The total number of campaigns is in
        # `paging.total`; these are the ones on screen, and saying so avoids
        # implying the sums cover everything.
        "campaigns": len(rows),
        "leads": sum(counts["total"] for _c, counts, _controls in rows),
        "sent": sum(counts["sent"] for _c, counts, _controls in rows),
        "failed": sum(counts["failed"] for _c, counts, _controls in rows),
    }
    return render(request, "outreach/history.html", {
        "paging": paging_context,
        "statuses": Campaign.Status.choices,
        "status": status,
        "search": search,
        "rows": rows,
        "totals": totals if rows else None,
        "nav": "history",
    })
@require_POST
def campaign_accounts(request: HttpRequest, campaign_id) -> JsonResponse:
    """Choose which accounts a campaign may send from.

    Recording a selection is not granting permission: `sending_accounts()`
    re-checks active, configured and under-limit when the send actually starts.
    """
    campaign = _my_campaign(request, campaign_id)
    wanted = _json(request).get("accounts")
    if not isinstance(wanted, list):
        return JsonResponse({"error": "Select at least one account."}, status=400)

    ids = {int(value) for value in wanted if str(value).isdigit()}
    chosen = list(mailaccounts.accounts(request.user).filter(pk__in=ids))
    campaign.sending_accounts.set(chosen)

    report = mailaccounts.selection_report(campaign)
    if chosen and not report["usable"]:
        blocked = ", ".join(
            f"{row['account'].name} ({row['reason']})"
            for row in report["rows"] if not row["usable"])
        message = (f"{len(chosen)} account(s) selected, but none can send: "
                   f"{blocked}.")
    elif chosen:
        message = (f"{report['usable']} of {report['selected']} selected "
                   f"account(s) can send, with room for {report['capacity']} "
                   "email(s) today.")
    else:
        message = ("No accounts selected. This campaign will use the sender "
                   "configured in .env.")

    return JsonResponse({
        "message": message,
        "selected": sorted(account.pk for account in chosen),
        "usable": report["usable"],
        "capacity": report["capacity"],
    })
