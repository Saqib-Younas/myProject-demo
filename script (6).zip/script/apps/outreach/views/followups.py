"""
Replies, and the follow-ups a person decides to send.

The rule this module exists to keep: **a follow-up is prepared by machine and sent by a
person.** `followup_create` drafts one, `followup_action` saves, regenerates or cancels
it, and `_send_followup` is reached only by an explicit `send` action -- never by a
timer, never by a worker.
"""

from __future__ import annotations

import os

from django.conf import settings as django_settings
from django.db import IntegrityError, transaction
from django.http import HttpRequest, HttpResponse, JsonResponse
from django.shortcuts import render
from django.utils import timezone
from django.views.decorators.http import require_GET, require_POST

from apps import ai
from apps.core import paging
from apps.outreach.mail import accounts as mailaccounts
from apps.outreach.mail import compose, inbox, providers, transport
from apps.outreach.mail import followups as followup_rules
from apps.outreach.models import (
    Campaign,
    FollowUp,
)

from .shared import (
    _json,
    _my_followup,
    _my_lead,
)


def _followup_json(followup: FollowUp) -> dict:
    return {
        "id": followup.pk,
        "lead_id": followup.lead_id,
        "number": followup.number,
        "email": followup.email,
        "subject": followup.subject,
        "body": followup.body,
        "status": followup.status,
        "status_label": followup.get_status_display(),
        "reply_state": followup.reply_state,
        "edited": followup.edited,
        "regenerations": followup.regenerations,
        "error_message": followup.error_message,
        "created_at": followup.created_at.isoformat() if followup.created_at else None,
        "sent_at": followup.sent_at.isoformat() if followup.sent_at else None,
    }
@require_GET
def followups(request: HttpRequest) -> HttpResponse:
    """Replies and follow-ups: what came back, and what may be followed up."""
    only = request.GET.get("filter", "all")
    if only not in followup_rules.FILTERS:
        only = "all"

    campaign = None
    campaign_id = request.GET.get("campaign", "")
    if campaign_id:
        campaign = Campaign.objects.filter(
            pk=campaign_id, owner=request.user).first()

    # `rows()` decides eligibility per lead in Python, so the filtering cannot be
    # pushed into SQL and the list is built in full before it is paginated. Pages
    # still bound what is rendered and, more usefully, the summary states the real
    # total instead of leaving the screen to imply it holds everything.
    found = followup_rules.rows(request.user, campaign=campaign, only=only)
    paging_context = paging.page_context(request, found, label="leads")

    return render(request, "outreach/followups.html", {
        "nav": "followups",
        "rows": paging_context["rows"],
        "paging": paging_context,
        "stats": followup_rules.stats(request.user, campaign),
        "filter": only,
        "filters": followup_rules.FILTER_LABELS,
        "campaign": campaign,
        "campaigns": Campaign.objects.filter(
            owner=request.user).exclude(sender_email="")[:50],
        "reasons": followup_rules.REASONS,
        "has_smtp_password_env": bool(os.environ.get("OUTREACH_SMTP_PASSWORD")),
    })
@require_POST
def check_inbox(request: HttpRequest) -> JsonResponse:
    """Read the sending account's inbox once and record what came back.

    Only replies to emails sent from here are examined; anything else is dropped
    without being stored. Nothing is sent, and nothing in the mailbox is marked
    read or modified.
    """
    payload = _json(request)
    password = (str(payload.get("password", "")).strip()
                or os.environ.get("OUTREACH_SMTP_PASSWORD", ""))
    if not password:
        return JsonResponse({
            "error": "Enter the mailbox password (the same app password used "
                     f"for sending {django_settings.OUTREACH_SENDER_EMAIL}).",
        }, status=400)

    try:
        result = inbox.check(password=password, owner=request.user)
    except inbox.InboxError as exc:
        return JsonResponse({"error": str(exc)}, status=502)

    return JsonResponse({
        "summary": result.summary(),
        "examined": result.examined,
        "matched": result.matched,
        "replied": result.replied,
        "bounced": result.bounced,
        "unsubscribed": result.unsubscribed,
        "changed": result.changed[:20],
        "stats": followup_rules.stats(request.user),
    })
@require_POST
def followup_create(request: HttpRequest, pk: int) -> JsonResponse:
    """Generate a follow-up for one lead. Saves it as a draft; sends nothing."""
    lead = _my_lead(request, pk)
    verdict = followup_rules.eligibility(lead)
    if not verdict.eligible:
        return JsonResponse({"error": verdict.label}, status=409)

    original = lead.draft            # the EmailDraft this send came from
    days_since = 0
    if verdict.last_contact_at:
        days_since = max(0, (timezone.now() - verdict.last_contact_at).days)

    campaign = lead.campaign
    try:
        email = ai.follow_up(
            business_name=lead.business_name,
            category=getattr(original, "category", "") or "",
            city=lead.city,
            country=lead.country,
            website=lead.website,
            sender_name=getattr(campaign, "sender_name", "")
                        or django_settings.OUTREACH_SENDER_NAME,
            sender_company=getattr(campaign, "sender_company", "")
                           or django_settings.OUTREACH_SENDER_COMPANY,
            sender_email=getattr(campaign, "sender_email", "")
                         or django_settings.OUTREACH_SENDER_EMAIL,
            service_pitch=getattr(campaign, "service_pitch", "") or "",
            original_subject=lead.subject or getattr(original, "subject", ""),
            original_body=getattr(original, "body", "") or "",
            observation=getattr(original, "observation", "") or "",
            findings=original.finding_objects if original else [],
            business_summary=getattr(original, "business_summary", "") or "",
            days_since=days_since,
            number=verdict.next_number,
            campaign_label=lead.campaign_label,
        )
    except ai.AiError as exc:
        return JsonResponse({"error": str(exc)}, status=502)

    try:
        with transaction.atomic():
            followup = FollowUp.objects.create(
                lead=lead,
                owner=request.user,
                campaign=campaign,
                campaign_label=lead.campaign_label,
                number=verdict.next_number,
                email=lead.email,
                subject=email.subject,
                body=email.body,
            )
    except IntegrityError:
        # Two clicks raced; the first one's draft is the one to review.
        existing = lead.followups.filter(
            number=verdict.next_number).exclude(
            status=FollowUp.Status.CANCELLED).first()
        if existing is None:
            return JsonResponse(
                {"error": "Could not create the follow-up. Reload and retry."},
                status=409)
        return JsonResponse({"followup": _followup_json(existing),
                             "angle": "", "created": False})

    return JsonResponse({
        "followup": _followup_json(followup),
        "angle": email.observation,
        "created": True,
        "eligibility": followup_rules.eligibility(lead).as_dict(),
    })
@require_POST
def followup_action(request: HttpRequest, pk: int, action: str) -> JsonResponse:
    """Edit, regenerate, cancel or send one follow-up draft."""
    followup = _my_followup(request, pk)
    payload = _json(request)

    if followup.status in (FollowUp.Status.SENT, FollowUp.Status.SENDING):
        return JsonResponse(
            {"error": "That follow-up has already been sent."}, status=409)

    if action == "save":
        subject = str(payload.get("subject", "")).strip()
        body = str(payload.get("body", "")).strip()
        if not subject or not body:
            return JsonResponse(
                {"error": "Subject and body cannot be empty."}, status=400)
        followup.subject = subject[:400]
        followup.body = body
        followup.edited = True
        followup.status = FollowUp.Status.DRAFT
        followup.error_message = ""
        followup.save(update_fields=["subject", "body", "edited", "status",
                                     "error_message"])

    elif action == "regenerate":
        hint = str(payload.get("hint", "")).strip()[:500]
        lead = followup.lead
        original = lead.draft
        campaign = followup.campaign
        days_since = max(0, (timezone.now()
                             - (lead.sent_at or lead.reserved_at)).days)
        try:
            email = ai.follow_up(
                business_name=lead.business_name,
                category=getattr(original, "category", "") or "",
                city=lead.city, country=lead.country, website=lead.website,
                sender_name=getattr(campaign, "sender_name", "")
                            or django_settings.OUTREACH_SENDER_NAME,
                sender_company=getattr(campaign, "sender_company", "")
                               or django_settings.OUTREACH_SENDER_COMPANY,
                sender_email=getattr(campaign, "sender_email", "")
                             or django_settings.OUTREACH_SENDER_EMAIL,
                service_pitch=getattr(campaign, "service_pitch", "") or "",
                original_subject=lead.subject or getattr(original, "subject", ""),
                original_body=getattr(original, "body", "") or "",
                observation=getattr(original, "observation", "") or "",
                findings=original.finding_objects if original else [],
                business_summary=getattr(original, "business_summary", "") or "",
                days_since=days_since, number=followup.number,
                campaign_label=lead.campaign_label, retry_hint=hint,
            )
        except ai.AiError as exc:
            return JsonResponse({"error": str(exc)}, status=502)

        followup.subject = email.subject
        followup.body = email.body
        followup.edited = False
        followup.regenerations += 1
        followup.error_message = ""
        followup.save(update_fields=["subject", "body", "edited",
                                     "regenerations", "error_message"])

    elif action == "cancel":
        # Cancelled rather than deleted: the number is freed for another attempt
        # and the record of the decision survives.
        followup.status = FollowUp.Status.CANCELLED
        followup.error_message = "Cancelled before sending."
        followup.save(update_fields=["status", "error_message"])

    elif action == "send":
        return _send_followup(request, followup, payload)

    else:
        return JsonResponse({"error": f"Unknown action {action!r}."}, status=400)

    followup.refresh_from_db()
    return JsonResponse({
        "followup": _followup_json(followup),
        "eligibility": followup_rules.eligibility(followup.lead).as_dict(),
        "stats": followup_rules.stats(request.user),
    })
def _send_followup(request: HttpRequest, followup: FollowUp,
                   payload: dict) -> JsonResponse:
    """Send one follow-up, but only after re-checking everything.

    The order here is the whole safety story: check, then claim, then check
    again is not needed -- the claim is a conditional UPDATE, so exactly one
    caller can move the row out of `draft`, and the check happens before the
    connection opens.
    """
    password = (str(payload.get("password", "")).strip()
                or os.environ.get("OUTREACH_SMTP_PASSWORD", ""))
    if not password:
        return JsonResponse({
            "error": "Enter the SMTP password to send this follow-up.",
        }, status=400)

    # The final check, immediately before SMTP. Everything it looks at can have
    # changed while the draft sat in review -- that is exactly why it is here.
    try:
        lead = followup_rules.check_before_send(followup)
    except followup_rules.Blocked as exc:
        FollowUp.objects.filter(pk=followup.pk).update(
            status=FollowUp.Status.CANCELLED, error_message=str(exc)[:2000])
        return JsonResponse({"error": str(exc), "cancelled": True}, status=409)

    if not followup_rules.claim(followup):
        return JsonResponse(
            {"error": "This follow-up is already being sent."}, status=409)

    campaign = followup.campaign
    provider_key = (getattr(campaign, "provider", "")
                    or django_settings.OUTREACH_PROVIDER)
    sender_email = (getattr(campaign, "sender_email", "")
                    or django_settings.OUTREACH_SENDER_EMAIL)
    sender_name = (getattr(campaign, "sender_name", "")
                   or django_settings.OUTREACH_SENDER_NAME)

    # The account that sent the original, where there is one. A follow-up from a
    # different address is a different conversation as far as the recipient's
    # mail client is concerned, and as far as they are concerned too.
    account = followup.sender_account
    reply_to = ""
    signature = ""
    if account is not None and account.sendable:
        stored = mailaccounts.password_of(account)
        if stored:
            password = stored
        provider_key = account.provider
        sender_email = account.sender_email
        sender_name = account.sender_name or sender_name
        reply_to = account.reply_to
        signature = account.signature
    elif account is not None:
        why = ("it is inactive" if not account.is_active
               else "it has no usable credential")
        return JsonResponse({
            "error": f"{account.name} cannot send at the moment -- {why}. "
                     "Nothing was sent.",
        }, status=409)

    try:
        provider = providers.provider_for(provider_key)
        with transport.Session(
            provider, sender_email, password,
            host=(account.smtp_host if account is not None
                  else os.environ.get("OUTREACH_SMTP_HOST", "")),
            port=((account.smtp_port or 0) if account is not None
                  else int(os.environ.get("OUTREACH_SMTP_PORT", "0") or 0)),
        ) as session:
            message_id = session.send(
                to_email=followup.email, subject=followup.subject,
                body=compose.with_signature(followup.body, signature),
                sender_name=sender_name,
                reply_to=reply_to,
                # §16: this belongs in the conversation the first email started.
                # Written when the follow-up was prepared, from the Message-IDs
                # already recorded -- never invented, because a fabricated id
                # breaks threading rather than fixing it.
                in_reply_to=followup.in_reply_to or lead.message_id or "",
                references=(followup.references
                            or followup_rules.reference_chain(lead)),
            )
    except transport.SendError as exc:
        followup_rules.release(followup)
        return JsonResponse({"error": str(exc)}, status=502)
    except Exception as exc:  # noqa: BLE001 - one rejected recipient
        message = f"{type(exc).__name__}: {exc}"
        followup.mark_failed(message)
        return JsonResponse({"error": message}, status=502)

    followup.mark_sent(message_id=message_id)
    # Delivery is what SMTP accepted; a reply is a separate thing that may never
    # come. Two fields, because one cannot say both.
    FollowUp.objects.filter(pk=followup.pk).update(
        delivery_status="accepted", last_attempt_at=timezone.now())
    followup.refresh_from_db()
    # §9: the next one is scheduled from what was just sent. Returns None once the
    # lead has had its allowance, which is how the sequence ends -- by there being
    # nothing to schedule rather than by anything having to remember to stop.
    followup_rules.schedule_next(lead)
    return JsonResponse({
        "followup": _followup_json(followup),
        "eligibility": followup_rules.eligibility(lead).as_dict(),
        "stats": followup_rules.stats(request.user),
        "sent": True,
    })
