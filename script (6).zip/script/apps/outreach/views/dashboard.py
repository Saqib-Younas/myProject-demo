"""
The authenticated home.

Totals, the five queues, the best prospects, and whether the AI provider is usable.
Everything on it is counted from the tables on each request.
"""

from __future__ import annotations

from django.http import HttpRequest, HttpResponse
from django.shortcuts import render
from django.views.decorators.http import require_GET

from apps import ai
from apps.ai import credentials
from apps.outreach import selectors as pipeline
from apps.outreach.mail import followups as followup_rules
from apps.outreach.models import (
    Campaign,
)
from apps.outreach.services import history


@require_GET
def dashboard(request: HttpRequest) -> HttpResponse:
    """The sales-intelligence home: totals, queues, and the best prospects."""
    summary = pipeline.summary(request.user)
    top = pipeline.filtered(request.user, sort="score")[:8]

    return render(request, "outreach/dashboard.html", {
        "nav": "dashboard",
        "summary": summary,
        "queues": pipeline.queues(request.user),
        "top": top,
        "history": history.stats(request.user),
        "replies": followup_rules.stats(request.user),
        "campaigns": Campaign.objects.filter(owner=request.user)[:6],
        "ai_provider": (credentials.status(ai.provider(), request.user)
                        if credentials.known(ai.provider()) else None),
    })
