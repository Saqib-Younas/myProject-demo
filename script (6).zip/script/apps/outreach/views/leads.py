"""
The lead intelligence table, and one lead in detail.

The table is a filtered, sorted, paginated read -- the query itself lives in
`selectors` -- and the detail page is the audit, the scores and the reasons behind
them. `lead_reanalyse` is the one endpoint here that spends money: it crawls.
"""

from __future__ import annotations

from django.conf import settings as django_settings
from django.http import HttpRequest, HttpResponse, JsonResponse
from django.shortcuts import render
from django.views.decorators.http import require_GET, require_POST

from apps import ai
from apps.auditing import scoring
from apps.core import paging
from apps.outreach import selectors as pipeline
from apps.outreach.models import (
    MANUAL_LIFECYCLE,
    Campaign,
    EmailDraft,
    Lifecycle,
)
from apps.outreach.services import intelligence

from .campaigns import _previous_contacts
from .shared import (
    _filters_from,
    _json,
    _my_draft,
)


@require_GET
def leads(request: HttpRequest) -> HttpResponse:
    """The lead intelligence table: every lead, filtered and sorted."""
    active = _filters_from(request)
    campaign = None
    campaign_id = request.GET.get("campaign", "")
    if campaign_id:
        campaign = Campaign.objects.filter(
            pk=campaign_id, owner=request.user).first()

    rows = pipeline.filtered(request.user, campaign=campaign, **active)
    total = pipeline.base(request.user).count()

    # Server-side pagination, 20 by default (§7). This replaced a hard cap of 300,
    # which kept the useful top of the sorted list but made lead 301 unreachable --
    # no page, no link, only a flag saying more existed. Page one is still the top
    # of the same sorted list; the rest is now reachable.
    paging_context = paging.page_context(request, rows, label="leads")

    return render(request, "outreach/leads.html", {
        "nav": "leads",
        "rows": paging_context["rows"],
        "paging": paging_context,
        "count": paging_context["total"],
        "total": total,
        "capped": False,
        "active": active,
        "campaign": campaign,
        "choices": pipeline.choices(request.user),
        "website_filters": pipeline.WEBSITE_FILTERS,
        "priority_filters": pipeline.PRIORITY_FILTERS,
        "outreach_filters": pipeline.OUTREACH_FILTERS,
        "whatsapp_filters": pipeline.WHATSAPP_FILTERS,
        "sorts": pipeline.SORTS,
        "queues": pipeline.queues(request.user),
        "summary": pipeline.summary(request.user),
    })
@require_GET
def lead_detail(request: HttpRequest, pk: int) -> HttpResponse:
    """One lead's full intelligence. Reads the cached audit; never crawls."""
    draft = _my_draft(request, pk)

    # Re-score on open. Arithmetic only, and it keeps a lead current when the
    # thresholds or the scoring rules have changed since it was last written.
    if draft.classification:
        intelligence.apply(draft)
        draft.refresh_from_db()

    audit = draft.audit
    contacted = _previous_contacts(draft.campaign)
    history_rows = list(draft.history_rows.order_by("-reserved_at")[:5])

    return render(request, "outreach/lead_detail.html", {
        "nav": "leads",
        "draft": draft,
        "audit": audit,
        "campaign": draft.campaign,
        "sub_scores": draft.sub_score_rows,
        # The findings grouped by priority, with which of the six review areas
        # the audit actually reached. Built from the findings already stored --
        # opening this page never crawls and never calls the AI.
        "report": ai.audit_report(draft.finding_objects),
        "detail": draft.score_detail or {},
        "findings": draft.findings or (audit.findings if audit else []),
        "evidenced": [f for f in (draft.findings or
                                  (audit.findings if audit else []))
                      if f.get("evidence")],
        "lifecycle_steps": draft.lifecycle_steps,
        "lifecycle_choices": Lifecycle.choices,
        "manual_stages": [c.value for c in MANUAL_LIFECYCLE],
        "history_rows": history_rows,
        "previously_contacted": contacted.get(draft.email.lower(), ""),
        "ready": scoring.is_ready(draft.score_readiness),
        "readiness_min": int(getattr(django_settings,
                                     "OUTREACH_READINESS_MIN", 60)),
    })
@require_POST
def lead_reanalyse(request: HttpRequest, pk: int) -> JsonResponse:
    """Crawl this lead's website again, review it, and re-score.

    The only path in the application that spends a crawl on a single lead, and it
    exists precisely so that opening a page does not. Synchronous because the user
    asked and is waiting; the crawl is capped at a handful of pages.
    """
    draft = _my_draft(request, pk)

    if not draft.website:
        return JsonResponse({
            "error": "This lead has no website address to analyse.",
        }, status=400)

    try:
        audit = intelligence.audit_website(
            request.user, draft.website, refresh=True,
            business_name=draft.business_name, category=draft.category,
            city=draft.city, country=draft.country,
        )
    except Exception as exc:  # noqa: BLE001 - a crawl can fail in many ways
        return JsonResponse({
            "error": f"The website could not be analysed: {exc}",
        }, status=502)

    if audit is None:
        return JsonResponse({
            "error": "That website address could not be understood.",
        }, status=400)

    # The audit is the lead's own evidence now, so copy the parts the draft owns.
    draft.analysis_status = audit.status
    draft.analysis_note = audit.detail[:400]
    draft.pages_read = audit.pages
    draft.pages_discovered = audit.pages_discovered
    # Taken wholesale, empty included: the audit is now this lead's current
    # evidence, and keeping findings the fresh crawl did not reproduce would show
    # the user claims that are no longer true.
    draft.findings = audit.findings
    draft.business_summary = audit.business_summary
    draft.save(update_fields=["analysis_status", "analysis_note", "pages_read",
                             "pages_discovered", "findings",
                             "business_summary"])

    intelligence.apply(draft, audit=audit)
    draft.refresh_from_db()

    message = (f"{draft.business_name}: {audit.get_status_display().lower()}, "
               f"{len(audit.pages)} page(s) read")
    if audit.findings:
        message += f", {len(audit.findings)} finding(s)."
    else:
        # Said out loud rather than left as a silently empty list: the user asked
        # for an analysis and should know the review half of it did not produce
        # anything.
        message += ", but the review produced no findings."

    return JsonResponse({
        "message": message,
        "findings": len(audit.findings),
        "lead": _lead_json(draft),
        "reload": True,
    })
@require_POST
def lead_lifecycle(request: HttpRequest, pk: int) -> JsonResponse:
    """Move a lead to a stage a person has judged."""
    draft = _my_draft(request, pk)
    payload = _json(request)
    stage = str(payload.get("stage", "")).strip()

    try:
        intelligence.set_lifecycle(draft, stage,
                                   note=str(payload.get("note", "")))
    except ValueError as exc:
        return JsonResponse({"error": str(exc)}, status=400)

    draft.refresh_from_db()
    return JsonResponse({
        "message": f"{draft.business_name} moved to "
                   f"{draft.get_lifecycle_display()}.",
        "lead": _lead_json(draft),
    })
@require_POST
def rescore(request: HttpRequest) -> JsonResponse:
    """Re-score every lead this account owns. Arithmetic only -- no crawling.

    Wanted after changing the priority thresholds, which otherwise apply only to
    leads scored from then on.
    """
    count = 0
    for draft in pipeline.base(request.user).iterator():
        intelligence.apply(draft)
        count += 1

    return JsonResponse({
        "message": f"Re-scored {count} lead(s) against the current thresholds.",
        "summary": pipeline.summary(request.user),
    })
def _lead_json(draft: EmailDraft) -> dict:
    """The safe shape of one lead for a JSON response."""
    return {
        "id": draft.pk,
        "business_name": draft.business_name,
        "classification": draft.classification,
        "classification_label": draft.classification_label,
        "priority": draft.priority,
        "priority_label": draft.priority_label,
        "score_overall": draft.score_overall,
        "score_website": draft.score_website,
        "score_value": draft.score_value,
        "score_readiness": draft.score_readiness,
        "recommended_service": draft.recommended_service,
        "why_prospect": draft.why_prospect,
        "lifecycle": draft.lifecycle,
        "lifecycle_label": draft.get_lifecycle_display(),
        "main_issue": draft.main_issue,
    }
