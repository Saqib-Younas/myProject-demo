"""
Verify the configured SMTP credential without emailing anybody.

    python manage.py smtp_check

Opens the provider's SMTP connection, runs STARTTLS, authenticates, and quits.
No message is sent and no recipient is contacted. Run this after changing the
sender address or rotating the app password.
"""

from __future__ import annotations

import os

from django.conf import settings
from django.core.management.base import BaseCommand

from apps.outreach.mail import providers, transport


class Command(BaseCommand):
    help = "Check that the configured sender can authenticate over SMTP."

    def handle(self, *args, **options) -> None:
        ok = self.style.SUCCESS
        bad = self.style.ERROR
        warn = self.style.WARNING

        email = settings.OUTREACH_SENDER_EMAIL
        provider_key = settings.OUTREACH_PROVIDER
        password = os.environ.get("OUTREACH_SMTP_PASSWORD", "")

        self.stdout.write(self.style.MIGRATE_HEADING("Configured sender"))
        self.stdout.write(f"  name     : {settings.OUTREACH_SENDER_NAME}")
        self.stdout.write(f"  email    : {email}")
        self.stdout.write(f"  company  : {settings.OUTREACH_SENDER_COMPANY or '(none)'}")
        self.stdout.write(f"  provider : {provider_key}")

        try:
            provider = providers.provider_for(provider_key)
        except transport.SendError as exc:
            self.stdout.write(bad(f"  {exc}"))
            return

        host, port = providers.resolve_host(
            provider,
            os.environ.get("OUTREACH_SMTP_HOST", ""),
            int(os.environ.get("OUTREACH_SMTP_PORT", "0") or 0),
        )
        self.stdout.write(f"  server   : {host}:{port}")
        self.stdout.write(f"  rate     : 1 message / {provider.delay}s, "
                          f"{provider.daily_cap}/day")

        if not password:
            self.stdout.write(warn(
                "\n  OUTREACH_SMTP_PASSWORD is not set. Put it in .env, or you "
                "will have to type it on the send screen every run."
            ))
            return

        normalised = providers.normalise_password(password)
        self.stdout.write(
            f"  password : {len(normalised)} chars"
            + (" (de-spaced app password)" if normalised != password.strip() else "")
        )

        self.stdout.write(self.style.MIGRATE_HEADING("\nAuthenticating (no email sent)"))
        try:
            with transport.Session(provider, email, password, host=host, port=port):
                self.stdout.write(ok(f"  login accepted for {email}"))
        except transport.SendError as exc:
            self.stdout.write(bad(f"  {exc}"))
            self.stdout.write(warn(
                "\n  For Gmail: the password must be a 16-character App Password "
                "from https://myaccount.google.com/apppasswords (2-Step "
                "Verification must be on). Account passwords are always rejected."
            ))
            return

        self.stdout.write(ok("\nReady to send."))
