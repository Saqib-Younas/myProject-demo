"""
Copy this application's data from SQLite into Postgres, and prove it arrived.

    # 1. point at the new database and build the schema there
    export DATABASE_URL="postgresql://...@db.<ref>.supabase.co:5432/postgres"
    python manage.py migrate

    # 2. copy the rows out of the old file
    export SQLITE_SOURCE=outreach.sqlite3
    python manage.py db_transfer --dry-run     # says what it would do
    python manage.py db_transfer

    # 3. check it again later, or after anything suspicious
    python manage.py db_transfer --verify-only

Why a command rather than `dumpdata | loaddata`: three things go wrong with that
pair and each one is silent.

  * **Sequences.** `loaddata` writes explicit primary keys and leaves the Postgres
    sequences at 1, so the next `INSERT` collides with row 1 and the application
    looks broken in a way that has nothing to do with the migration. This resets
    every sequence at the end.
  * **Foreign keys.** Rows have to arrive parents-first or the constraints reject
    them. This orders the tables by their dependencies and defers constraint
    checking inside the transaction as well.
  * **Proof.** A migration that "worked" is worth nothing without a comparison.
    This counts every table on both sides, then re-reads a sample of real rows
    field by field, and refuses to report success unless both agree.

Everything happens in one transaction. A failure anywhere leaves Postgres exactly
as it was, and the SQLite file is only ever read.
"""

from __future__ import annotations

import contextlib

from django.apps import apps
from django.core.management.base import BaseCommand, CommandError
from django.db import connections, router, transaction

from apps.core import dburl

#: Tables that must not be copied, and why. All three are rebuilt by `migrate` or
#: are worthless to carry over, and copying them causes real problems:
#:
#:   contenttypes / auth.Permission -- created by migrate with their own ids. Copied
#:     rows collide, and nothing in this application references them by id.
#:   sessions -- a session is a browser cookie's other half. Moving them would
#:     carry logins across databases for no benefit; users sign in again.
#:   admin.LogEntry -- points at content types by id, so it cannot survive the
#:     remapping above. Not present in this project, excluded for the day it is.
SKIP_MODELS = {
    "contenttypes.ContentType",
    "auth.Permission",
    "sessions.Session",
    "admin.LogEntry",
}

#: How many rows to re-read and compare field by field, per table. Enough to catch
#: a type or encoding problem; small enough to run in a second.
SAMPLE_SIZE = 5


class Command(BaseCommand):
    help = ("Copy every table from a SQLite file into the configured database, "
            "then verify the result.")

    def add_arguments(self, parser) -> None:
        parser.add_argument(
            "--source", default="sqlite_source",
            help="Connection alias to read from. Defaults to sqlite_source, "
                 "which settings configures from SQLITE_SOURCE.",
        )
        parser.add_argument(
            "--target", default="default",
            help="Connection alias to write to. Defaults to default.",
        )
        parser.add_argument(
            "--dry-run", action="store_true",
            help="Report what would be copied without writing anything.",
        )
        parser.add_argument(
            "--verify-only", action="store_true",
            help="Compare the two databases without copying. Safe at any time.",
        )
        parser.add_argument(
            "--batch", type=int, default=500,
            help="Rows per INSERT batch. Lower it if the pooler complains.",
        )
        parser.add_argument(
            "--allow-nonempty", action="store_true",
            help="Copy into a target that already holds rows. Off by default: "
                 "a half-migrated database is worse than an empty one.",
        )

    # --- plumbing --------------------------------------------------------- #

    def handle(self, *args, **options) -> None:
        self.ok = self.style.SUCCESS
        self.warn = self.style.WARNING
        self.bad = self.style.ERROR

        source = options["source"]
        target = options["target"]

        for alias in (source, target):
            if alias not in connections:
                raise CommandError(
                    f"No database connection called {alias!r}. "
                    "Set SQLITE_SOURCE for the source and DATABASE_URL for the "
                    "target, then try again."
                )
        if source == target:
            raise CommandError("The source and the target are the same database.")

        self.stdout.write(self.style.MIGRATE_HEADING("Databases"))
        self.stdout.write(f"  from  {dburl.describe(connections[source].settings_dict)}")
        self.stdout.write(f"  to    {dburl.describe(connections[target].settings_dict)}")

        target_config = connections[target].settings_dict
        if dburl.pooled(target_config):
            # Transaction-mode pooling and a long single transaction do not mix
            # well, and it is the wrong connection for schema work in any case.
            self.stdout.write(self.warn(
                "\n  The target is the transaction-mode pooler (port 6543). Use "
                "the direct connection (db.<ref>.supabase.co:5432) for the "
                "migration, and the pooler for the running application."))

        self._check_schema(target)

        models = self._ordered_models(target)
        if options["verify_only"]:
            self._verify(source, target, models)
            return

        self._preflight(source, target, models, options)
        if options["dry_run"]:
            self.stdout.write(self.warn("\nDry run: nothing was written."))
            return

        self._copy(source, target, models, options["batch"])
        self._reset_sequences(target, models)
        ok = self._verify(source, target, models)
        if not ok:
            raise CommandError(
                "The copy finished but verification failed. The target database "
                "has been rolled back; nothing was kept."
            )

    def _check_schema(self, target: str) -> None:
        """Refuse to copy into a database whose schema is not up to date."""
        from django.db.migrations.executor import MigrationExecutor

        executor = MigrationExecutor(connections[target])
        pending = executor.migration_plan(executor.loader.graph.leaf_nodes())
        if pending:
            raise CommandError(
                f"{len(pending)} migration(s) have not been applied to the "
                "target. Run `python manage.py migrate` against it first -- the "
                "tables have to exist before the rows can arrive."
            )

    def _ordered_models(self, target: str) -> list:
        """Every model to copy, parents before children.

        A topological sort over the *mandatory* foreign keys only. Nullable ones
        are left out of the graph on purpose, and that is what makes a cyclic
        schema copyable: `Campaign.current_draft` points at EmailDraft while
        `EmailDraft.campaign` points back at Campaign, so no order satisfies both,
        but `current_draft` is nullable -- so it is written as NULL and filled in
        afterwards by `_fill_deferred`.

        Relying on `constraint_checks_disabled()` instead would have been wrong in
        a way that only showed up on the real target: on SQLite it is a PRAGMA and
        works, on Postgres it does nothing, because switching foreign keys off
        needs rights the application role will not have.
        """
        wanted = [
            model for model in apps.get_models()
            if model._meta.label not in SKIP_MODELS
            and model._meta.managed
            and router.allow_migrate_model(target, model)
        ]
        by_label = {model._meta.label: model for model in wanted}

        ordered: list = []
        placed: set[str] = set()

        def place(model, seen: frozenset = frozenset()) -> None:
            label = model._meta.label
            if label in placed or label in seen:
                return
            for field in self._parent_fields(model, mandatory_only=True):
                parent = field.related_model
                if parent is not model and parent._meta.label in by_label:
                    place(parent, seen | {label})
            if label not in placed:
                placed.add(label)
                ordered.append(model)

        for model in wanted:
            place(model)
        return ordered

    @staticmethod
    def _parent_fields(model, *, mandatory_only: bool = False) -> list:
        """The model's own foreign keys, optionally only the NOT NULL ones."""
        return [
            field for field in model._meta.fields
            if field.is_relation and field.many_to_one
            and (not mandatory_only or not field.null)
        ]

    def _deferred_fields(self, model, order: list) -> list:
        """Nullable foreign keys that point at a table copied later than this one.

        These are the references that cannot be satisfied at insert time. They are
        nulled on the way in and restored once every row exists.
        """
        position = {m._meta.label: i for i, m in enumerate(order)}
        mine = position.get(model._meta.label, 0)
        return [
            field for field in self._parent_fields(model)
            if field.null
            and position.get(field.related_model._meta.label, -1) > mine
        ]

    # --- before anything is written --------------------------------------- #

    def _preflight(self, source: str, target: str, models: list,
                   options: dict) -> None:
        self.stdout.write(self.style.MIGRATE_HEADING("\nTo copy"))
        total = 0
        for model in models:
            count = model.objects.using(source).count()
            total += count
            if count:
                self.stdout.write(f"  {model._meta.label:34} {count:>7}")
        self.stdout.write(f"  {'TOTAL':34} {total:>7}")

        if not total:
            raise CommandError(
                "The source database has no rows in any application table. "
                "Check SQLITE_SOURCE points at the right file."
            )

        occupied = [
            (model._meta.label, model.objects.using(target).count())
            for model in models
            if model.objects.using(target).count()
        ]
        if occupied and not options["allow_nonempty"]:
            listing = ", ".join(f"{label} ({count})" for label, count in occupied)
            raise CommandError(
                f"The target already holds rows: {listing}. Copying on top of "
                "them would duplicate or collide. Either start from an empty "
                "database (`manage.py flush`, or a fresh Supabase project), or "
                "pass --allow-nonempty if you know what you are doing."
            )

        # A user's groups and permissions are many-to-many through tables that
        # reference the permission ids `migrate` created, and those are not the
        # ids the old database used. Empty is the normal case for this
        # application -- the one account is a superuser -- so this warns rather
        # than refusing.
        User = apps.get_model("auth", "User")
        with_extras = sum(
            1 for user in User.objects.using(source).all()
            if user.groups.using(source).exists()
            or user.user_permissions.using(source).exists()
        )
        if with_extras:
            self.stdout.write(self.warn(
                f"\n  {with_extras} account(s) have groups or explicit "
                "permissions. Those links reference permission ids that differ "
                "between databases and are NOT copied -- reassign them by hand "
                "afterwards."))

    # --- the copy --------------------------------------------------------- #

    def _copy(self, source: str, target: str, models: list, batch: int) -> None:
        self.stdout.write(self.style.MIGRATE_HEADING("\nCopying"))
        connection = connections[target]

        #: (model, pk, field name, value) for every reference nulled on the way in.
        deferred: list[tuple] = []

        with self._preserve_timestamps(models) as frozen, \
             transaction.atomic(using=target):
            if frozen:
                self.stdout.write(
                    f"  {'(timestamps preserved)':34} {len(frozen):>7} field(s)")
            for model in models:
                rows = list(model.objects.using(source).all())
                if not rows:
                    continue

                blanked = self._deferred_fields(model, models)
                for row in rows:
                    for field in blanked:
                        value = getattr(row, field.attname)
                        if value is None:
                            continue
                        deferred.append(
                            (model, row.pk, field.attname, value))
                        setattr(row, field.attname, None)

                model.objects.using(target).bulk_create(rows, batch_size=batch)
                note = (f"  ({len(blanked)} reference(s) filled in afterwards)"
                        if blanked else "")
                self.stdout.write(
                    f"  {model._meta.label:34} {len(rows):>7} copied{note}")

            self._copy_m2m(source, target, models)
            self._fill_deferred(target, deferred)

            # Everything is in place, so ask the database to confirm it. Inside the
            # transaction, which is what makes a broken reference a rollback rather
            # than a half-migrated database.
            for model in models:
                connection.check_constraints(
                    table_names=[model._meta.db_table])

    @staticmethod
    @contextlib.contextmanager
    def _preserve_timestamps(models: list):
        """Stop `auto_now_add` and `auto_now` rewriting the values being copied.

        `DateTimeField.pre_save` replaces the value whenever the flag is set and
        the row is new -- and every row in a copy is new, so without this every
        `created_at` in the new database would say "the day of the migration" and
        the real history would be gone. The row counts would still have matched.

        Restored in a `finally`: these are class-level attributes, so leaving them
        off would silently break stamping for anything else this process does.
        """
        touched = []
        for model in models:
            for field in model._meta.fields:
                if getattr(field, "auto_now_add", False) or getattr(
                        field, "auto_now", False):
                    touched.append((field, field.auto_now_add, field.auto_now))
                    field.auto_now_add = False
                    field.auto_now = False
        try:
            yield [field for field, _add, _now in touched]
        finally:
            for field, was_add, was_now in touched:
                field.auto_now_add = was_add
                field.auto_now = was_now

    def _fill_deferred(self, target: str, deferred: list) -> None:
        """Restore the references that were nulled to break the insert cycle."""
        if not deferred:
            return
        for model, pk, attname, value in deferred:
            model.objects.using(target).filter(pk=pk).update(**{attname: value})
        self.stdout.write(
            f"  {'(deferred references)':34} {len(deferred):>7} restored")

    def _copy_m2m(self, source: str, target: str, models: list) -> None:
        """The through tables Django manages itself.

        `bulk_create` does not touch many-to-many links, so they are copied here.
        Rows referencing an excluded table (permissions, content types) are
        skipped rather than failing -- their ids do not mean the same thing in the
        new database.
        """
        for model in models:
            for field in model._meta.many_to_many:
                through = field.remote_field.through
                if not through._meta.auto_created:
                    continue          # an explicit through model; copied already
                other = field.related_model._meta.label
                if other in SKIP_MODELS:
                    continue
                rows = list(through.objects.using(source).all())
                if not rows:
                    continue
                through.objects.using(target).bulk_create(rows, batch_size=500)
                self.stdout.write(
                    f"  {through._meta.label:34} {len(rows):>7} copied (m2m)")

    def _reset_sequences(self, target: str, models: list) -> None:
        """Move every sequence past the highest id that was just inserted.

        The step that `loaddata` leaves out and that nothing notices until the
        first new row: with explicit primary keys copied in, the sequence is still
        at 1, and the next INSERT raises a duplicate-key error on a table that
        looks perfectly healthy.
        """
        connection = connections[target]
        if connection.vendor != "postgresql":
            return

        self.stdout.write(self.style.MIGRATE_HEADING("\nSequences"))
        statements = connection.ops.sequence_reset_sql(self.style, models)
        if not statements:
            self.stdout.write("  none to reset")
            return
        with connection.cursor() as cursor:
            for statement in statements:
                cursor.execute(statement)
        self.stdout.write(self.ok(f"  {len(statements)} sequence(s) reset"))

    # --- proof ------------------------------------------------------------ #

    def _verify(self, source: str, target: str, models: list) -> bool:
        """Row counts, then real rows field by field. True if both agree."""
        self.stdout.write(self.style.MIGRATE_HEADING("\nVerifying"))
        problems: list[str] = []

        for model in models:
            here = model.objects.using(source).count()
            there = model.objects.using(target).count()
            mark = self.ok("ok") if here == there else self.bad("MISMATCH")
            if here or there:
                self.stdout.write(
                    f"  {model._meta.label:34} {here:>6} -> {there:>6}  {mark}")
            if here != there:
                problems.append(
                    f"{model._meta.label}: {here} rows in the source, {there} in "
                    "the target")

        mismatches = self._compare_samples(source, target, models)
        problems.extend(mismatches)

        if problems:
            self.stdout.write(self.bad("\nVerification failed:"))
            for problem in problems[:20]:
                self.stdout.write(self.bad(f"  - {problem}"))
            if len(problems) > 20:
                self.stdout.write(self.bad(
                    f"  ... and {len(problems) - 20} more"))
            return False

        self.stdout.write(self.ok(
            "\nEvery table matches, and the sampled rows are identical field by "
            "field."))
        return True

    def _compare_samples(self, source: str, target: str, models: list) -> list[str]:
        """Re-read real rows from both sides and compare every concrete field.

        Counts alone would miss the failures that actually happen in a
        SQLite-to-Postgres move: a datetime losing its timezone, a JSON column
        arriving as the string "{}", a boolean stored as 0. So this reads the rows
        back out of both databases and compares the values.
        """
        problems: list[str] = []
        for model in models:
            fields = [f for f in model._meta.fields]
            pk = model._meta.pk.name
            sample = list(
                model.objects.using(source).order_by(pk)[:SAMPLE_SIZE])
            if not sample:
                continue

            for row in sample:
                try:
                    other = model.objects.using(target).get(pk=row.pk)
                except model.DoesNotExist:
                    problems.append(
                        f"{model._meta.label} row {row.pk} is missing from the "
                        "target")
                    continue
                for field in fields:
                    mine = getattr(row, field.attname)
                    theirs = getattr(other, field.attname)
                    if mine != theirs:
                        problems.append(
                            f"{model._meta.label} row {row.pk}: "
                            f"{field.name} differs "
                            f"({self._short(mine)} vs {self._short(theirs)})")
        return problems

    @staticmethod
    def _short(value) -> str:
        """A value, trimmed. Never long enough to dump a credential or a body."""
        text = repr(value)
        return text if len(text) <= 60 else text[:57] + "..."
