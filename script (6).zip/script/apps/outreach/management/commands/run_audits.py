"""
The website-audit worker.

Runs queued audits: crawl, review, contact extraction, email draft. It stops at
*ready for review* — there is no code path in it that opens SMTP, and a test asserts
that. The email is sent by a person pressing Send, and by nothing else.

Two reasons it exists when submitting a URL already starts a thread:

  * **A restart must not lose a job.** A thread dies with its process. A queued row
    does not, and this picks it up.
  * **Several web workers.** The thread runs inside whichever one served the
    request; a scheduled worker is where the work belongs in a deployment with more
    than one.

    python manage.py run_audits                 # one pass -- for cron
    python manage.py run_audits --loop           # continuously -- for a service

Safe to run alongside the in-process threads and alongside a second copy of itself:
each job is claimed with a conditional UPDATE, so two workers never crawl the same
site twice.
"""

from __future__ import annotations

import signal
import time

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand, CommandError

from apps.outreach import tasks
from apps.outreach.services import websiteaudit as siteaudit


class Command(BaseCommand):
    help = ("Run queued website audits: crawl, review, extract contacts and draft "
            "the email. Sends nothing -- the email needs a person's click.")

    def add_arguments(self, parser) -> None:
        parser.add_argument(
            "--user", default="",
            help="Only this account's audits (email or username).")
        parser.add_argument(
            "--job", default="", help="One audit, by id.")
        parser.add_argument(
            "--limit", type=int, default=5,
            help=("Most audits to run in one pass (default 5). Each one is a "
                  "crawl of somebody else's website, so a pass stays small."))
        parser.add_argument(
            "--loop", action="store_true",
            help="Keep running, one pass per interval, until interrupted.")
        parser.add_argument(
            "--interval", type=float, default=30.0,
            help="Seconds between passes in --loop mode (default 30).")

    def handle(self, *args, **options) -> None:
        owner = self._owner(options["user"])
        limit = max(1, options["limit"])

        if options["job"]:
            self._one(options["job"])
            return

        if options["loop"]:
            self._loop(owner, limit, options["interval"])
            return

        # Through `tasks`, not the service: the task records the WorkerRun the
        # Follow-Ups page reports.
        self._report(tasks.run_audits(owner=owner, limit=limit))

    # --- one pass ----------------------------------------------------------- #

    def _report(self, outcomes) -> None:
        if not outcomes:
            self.stdout.write("No audits are waiting.")
            return
        for outcome in outcomes:
            style = (self.style.ERROR if outcome.state == "failed"
                     else self.style.SUCCESS)
            self.stdout.write(style(f"  {outcome.line()}"))
        self.stdout.write(
            f"Ran {len(outcomes)} audit(s). Nothing was sent -- each one is "
            "waiting for somebody to read it.")

    def _one(self, raw: str) -> None:
        from apps.outreach.models import AuditJob

        try:
            job = AuditJob.objects.get(pk=int(raw))
        except (TypeError, ValueError):
            raise CommandError(f"--job takes an audit id, not {raw!r}.") from None
        except AuditJob.DoesNotExist:
            raise CommandError(f"No audit with id {raw}.") from None

        self._report([siteaudit.run_job(job)])

    # --- the long-running shape --------------------------------------------- #

    def _loop(self, owner, limit: int, interval: float) -> None:
        stopping = {"now": False}

        def ask_to_stop(_signum, _frame):
            if stopping["now"]:
                raise KeyboardInterrupt
            stopping["now"] = True
            self.stdout.write(self.style.WARNING(
                "\nFinishing the current audit, then stopping. Interrupt again "
                "to stop immediately."))

        for name in ("SIGINT", "SIGTERM"):
            if hasattr(signal, name):
                signal.signal(getattr(signal, name), ask_to_stop)

        self.stdout.write(
            f"Audit worker running, one pass every {interval:.0f}s. Ctrl-C to "
            "stop.")
        try:
            while not stopping["now"]:
                try:
                    outcomes = tasks.run_audits(owner=owner, limit=limit)
                except Exception:  # noqa: BLE001 - outlives one bad pass
                    self.stderr.write(self.style.ERROR(
                        "A pass failed; carrying on."))
                    outcomes = []
                for outcome in outcomes:
                    self.stdout.write(f"  {outcome.line()}")
                if stopping["now"]:
                    break
                time.sleep(max(5.0, interval))
        except KeyboardInterrupt:
            pass
        self.stdout.write("Worker stopped.")

    # --- arguments ---------------------------------------------------------- #

    def _owner(self, value: str):
        if not value:
            return None
        model = get_user_model()
        found = (model.objects.filter(email__iexact=value).first()
                 or model.objects.filter(username__iexact=value).first())
        if found is None:
            raise CommandError(f"No account matches {value!r}.")
        return found
