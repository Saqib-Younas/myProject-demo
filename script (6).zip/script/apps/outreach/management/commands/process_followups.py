"""
Prepare due follow-ups in the background. Send nothing.

    python manage.py process_followups              # every account
    python manage.py process_followups --user you@example.com
    python manage.py process_followups --dry-run    # decide, write nothing
    python manage.py process_followups --limit 50

Run it from cron, a systemd timer, Task Scheduler or the Docker host -- every 15
minutes is plenty:

    */15 * * * * /opt/leadmapper/bin/manage process_followups

**What it does and does not do.** It finds the leads whose follow-up window has
opened, runs every safety check, writes the draft with the AI, and leaves it at
DUE. It does not send. A person opens the Follow-ups screen, reads what was written
and clicks Send.

That division is the point. The worker exists so nobody has to keep a browser open
waiting for a 48-hour timer -- not so nobody has to read the email before it goes
to a stranger. Everything that costs money or takes time happens in the service; the
judgement stays with a person.

**This module is the terminal, not the work.** Arguments in, `tasks.prepare_followups`
called, outcomes printed. The deciding -- what is due, what may be claimed, what gets
written down -- lives in `apps/outreach/services/followups.py`, where the automation
runner reads it too. It used to live here, and the runner had to instantiate this
command class and call an underscore method on it to reach it.
"""

from __future__ import annotations

from django.core.management.base import BaseCommand, CommandError

from apps.outreach import tasks
from apps.outreach.services import followups


class Command(BaseCommand):
    help = ("Prepare follow-ups whose window has opened: check, draft, and mark "
            "them ready for review. Sends nothing.")

    def add_arguments(self, parser) -> None:
        parser.add_argument(
            "--user", default="",
            help="Only this account's leads (email or username). Every account "
                 "by default.",
        )
        parser.add_argument(
            "--limit", type=int, default=100,
            help="Most follow-ups to prepare in one run. Keeps a single run "
                 "bounded so a backlog is worked through over several.",
        )
        parser.add_argument(
            "--dry-run", action="store_true",
            help="Decide and report without writing anything or calling the AI.",
        )

    def handle(self, *args, **options) -> None:
        owner = self._owner(options["user"])
        if owner is None and not followups.owners_with_history():
            self.stdout.write("No accounts to process.")
            return

        outcomes = tasks.prepare_followups(
            owner=owner, limit=options["limit"], dry_run=options["dry_run"])

        for outcome in outcomes:
            style = self.style.ERROR if outcome.bad else (
                self.style.SUCCESS if outcome.result == "prepared" else str)
            self.stdout.write(style(outcome.line()))

        totals = followups.counts(outcomes)
        self.stdout.write(self.style.MIGRATE_HEADING("\nTotal"))
        self.stdout.write(
            f"  considered {totals['considered']}, prepared "
            f"{totals['prepared']}, skipped {totals['skipped']}, failed "
            f"{totals['failed']}")
        if options["dry_run"]:
            self.stdout.write(self.style.WARNING(
                "  dry run: nothing was written."))
        elif totals["prepared"]:
            self.stdout.write(self.style.SUCCESS(
                f"  {totals['prepared']} follow-up(s) are ready to review. "
                "Nothing has been sent -- open the Follow-ups screen to send "
                "them."))

    def _owner(self, identifier: str):
        """The one account asked for, or None for all of them."""
        if not identifier:
            return None
        found = followups.owner_named(identifier)
        if found is None:
            raise CommandError(f"No account matches {identifier!r}.")
        return found
