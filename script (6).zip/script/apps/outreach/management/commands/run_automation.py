"""
The automation worker.

Thin on purpose. Everything it knows how to do is "ask `automation.runner` for a
pass and print what happened" -- the deciding, the claiming, the stopping and the
sending all live in the services, where they can be tested without a subprocess and
read without scrolling past argument parsing.

Two ways to run it, and they are the same work either way:

    python manage.py run_automation              # one pass, then exit -- for cron
    python manage.py run_automation --loop       # passes forever -- for a service

Cron is the recommended shape, for the same reason `process_followups` is: a process
that exits cannot leak, cannot hold a database connection open overnight, and is
restarted by the next tick if it dies. `--loop` exists for a supervised container
where a scheduler is inconvenient.

Running two of these at once is safe. It is also the case the concurrency work
exists for: the plan lease, the lead claim, the day-slot reservation and the address
reservation are each a conditional write, so two workers produce one email per lead
and one email per allowance slot. That is asserted by tests, not hoped for.

Nothing here sends a follow-up. The worker may prepare one; a person sends it.
"""

from __future__ import annotations

import signal

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand, CommandError

from apps.outreach.services.automation import runner


class Command(BaseCommand):
    help = ("Run one pass of the outreach automation: pick up each campaign that "
            "is inside its schedule and has allowance left, and process leads "
            "until a stop condition is reached.")

    def add_arguments(self, parser) -> None:
        parser.add_argument(
            "--user", default="",
            help=("Only this account's campaigns (email or username). Every "
                  "account by default."),
        )
        parser.add_argument(
            "--campaign", default="",
            help="Only this automation plan, by id. Ignores whose it is not.",
        )
        parser.add_argument(
            "--limit", type=int, default=runner.PASS_LIMIT,
            help=(f"Most leads to process per campaign in one pass (default "
                  f"{runner.PASS_LIMIT}). Keeps a pass short enough to notice a "
                  "Pause."),
        )
        parser.add_argument(
            "--loop", action="store_true",
            help="Keep running, one pass per interval, until interrupted.",
        )
        parser.add_argument(
            "--interval", type=float, default=60.0,
            help="Seconds between passes in --loop mode (default 60).",
        )
        parser.add_argument(
            "--dry-run", action="store_true",
            help=("Decide and report without crawling, calling an AI provider, "
                  "sending anything or writing a counter."),
        )

    def handle(self, *args, **options) -> None:
        owner = self._owner(options["user"])
        plan_id = self._plan_id(options["campaign"])
        limit = max(1, options["limit"])

        if options["loop"]:
            self._loop(owner, limit, options["interval"])
            return

        reports = runner.run_once(owner=owner, limit=limit,
                                 dry_run=options["dry_run"], plan_id=plan_id)
        self._report(reports, dry_run=options["dry_run"])

    # --- one pass ----------------------------------------------------------- #

    def _report(self, reports, *, dry_run: bool) -> None:
        if not reports:
            self.stdout.write("No campaigns are scheduled or active.")
            return

        sent = sum(r.sent for r in reports)
        skipped = sum(r.skipped for r in reports)
        failed = sum(r.failed for r in reports)
        added = sum(r.prospected for r in reports)

        for report in reports:
            style = (self.style.SUCCESS if report.sent
                     else self.style.WARNING if report.failed
                     else self.style.HTTP_INFO)
            self.stdout.write(style(f"  {report.line()}"))
            for note in report.notes:
                self.stdout.write(f"      {note}")
            if report.completed:
                self.stdout.write(self.style.SUCCESS(
                    f"      completed: {report.stopped_because}"))

        prepared = sum(r.followups for r in reports)
        prefix = "Would process" if dry_run else "Processed"
        self.stdout.write(
            f"{prefix} {len(reports)} campaign(s): {sent} sent, {skipped} "
            f"skipped, {failed} failed, {added} prospect(s) added.")
        if prepared:
            self.stdout.write(
                f"{prepared} follow-up(s) prepared and waiting for approval. "
                "Nothing was sent -- open the Replies screen to send them.")
        if dry_run:
            self.stdout.write(self.style.WARNING(
                "Dry run: nothing was crawled, written, sent or counted."))

    # --- the long-running shape --------------------------------------------- #

    def _loop(self, owner, limit: int, interval: float) -> None:
        """Passes until a signal arrives.

        The stop flag is checked between passes rather than inside one, so an
        interrupt never abandons a lead half-processed -- a lead that has been
        crawled and written but not recorded is the one state worth avoiding.
        """
        stopping = {"now": False}

        def ask_to_stop(_signum, _frame):
            if stopping["now"]:
                raise KeyboardInterrupt
            stopping["now"] = True
            self.stdout.write(self.style.WARNING(
                "\nFinishing the current lead, then stopping. Interrupt again to "
                "stop immediately."))

        for name in ("SIGINT", "SIGTERM"):
            if hasattr(signal, name):
                signal.signal(getattr(signal, name), ask_to_stop)

        self.stdout.write(
            f"Automation worker running, one pass every {interval:.0f}s. "
            "Ctrl-C to stop.")
        try:
            runner.run_forever(owner=owner, interval=interval, limit=limit,
                              stop=lambda: stopping["now"])
        except KeyboardInterrupt:
            self.stdout.write(self.style.WARNING("Stopped."))
        self.stdout.write("Worker stopped.")

    # --- arguments ---------------------------------------------------------- #

    def _owner(self, value: str):
        if not value:
            return None
        model = get_user_model()
        found = (model.objects.filter(email__iexact=value).first()
                 or model.objects.filter(username__iexact=value).first())
        if found is None:
            raise CommandError(f"No account matches {value!r}.")
        return found

    def _plan_id(self, value: str):
        if not value:
            return None
        try:
            return int(value)
        except (TypeError, ValueError):
            raise CommandError(
                f"--campaign takes an automation plan id, not {value!r}."
            ) from None
