"""Per-lead sequential run: the position of each lead and the step in flight."""

import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("outreach", "0005_sentlead_uid"),
    ]

    operations = [
        migrations.AddField(
            model_name="emaildraft",
            name="sequence",
            field=models.PositiveIntegerField(default=0),
        ),
        migrations.AddField(
            model_name="emaildraft",
            name="processed_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="campaign",
            name="current_step",
            field=models.CharField(blank=True, max_length=12),
        ),
        migrations.AddField(
            model_name="campaign",
            name="current_draft",
            field=models.ForeignKey(
                blank=True, null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="+", to="outreach.emaildraft",
            ),
        ),
    ]
