"""
Parent/child AI credentials, owned by an account.

Written by hand rather than generated, because two of the changes need a decision
that `makemigrations` can only ask about interactively:

  * `label` is new and non-nullable. Existing rows get "Credential 1", which is
    what the user would have called their only key anyway.
  * `AiSelection` had a hard-coded primary key of 1 and becomes one row per
    account. There is nothing worth migrating in it -- it holds a provider name
    that Settings can re-pick in one click -- so the old row is dropped rather
    than guessed at an owner for.

Existing credentials keep working: they gain a label, stay active, and belong to
nobody until `manage.py claim_data` assigns them, exactly like the campaigns and
history did when accounts arrived.
"""

import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("outreach", "0012_lead_intelligence"),
    ]

    operations = [
        # --- the old single-credential shape comes apart ------------------- #
        migrations.RemoveConstraint(
            model_name="providercredential",
            name="one_active_credential_per_provider",
        ),
        migrations.AlterField(
            model_name="providercredential",
            name="provider",
            field=models.CharField(db_index=True, max_length=32),
        ),
        migrations.AlterField(
            model_name="providercredential",
            name="is_active",
            field=models.BooleanField(db_index=True, default=False),
        ),

        # --- the child's own identity -------------------------------------- #
        migrations.AddField(
            model_name="providercredential",
            name="owner",
            field=models.ForeignKey(
                blank=True, null=True, db_index=True,
                on_delete=django.db.models.deletion.CASCADE,
                related_name="ai_credentials", to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name="providercredential",
            name="label",
            field=models.CharField(default="Credential 1", max_length=80),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name="providercredential",
            name="description",
            field=models.CharField(blank=True, max_length=300),
        ),
        migrations.AddField(
            model_name="providercredential",
            name="allow_fallback",
            field=models.BooleanField(default=False),
        ),

        # --- usage, all of it safe to display ----------------------------- #
        migrations.AddField(
            model_name="providercredential",
            name="last_used_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="providercredential",
            name="last_success_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="providercredential",
            name="last_error_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="providercredential",
            name="request_count",
            field=models.PositiveIntegerField(default=0),
        ),
        migrations.AddField(
            model_name="providercredential",
            name="error_count",
            field=models.PositiveIntegerField(default=0),
        ),
        migrations.AddField(
            model_name="providercredential",
            name="last_error_category",
            field=models.CharField(blank=True, max_length=32),
        ),
        migrations.AddField(
            model_name="providercredential",
            name="last_error_detail",
            field=models.CharField(blank=True, max_length=300),
        ),

        migrations.AlterModelOptions(
            name="providercredential",
            options={"ordering": ("provider", "-is_active", "label")},
        ),

        # One active child per provider per account, and distinct labels within
        # a provider. Both in the database, so two tabs cannot race past them.
        migrations.AddConstraint(
            model_name="providercredential",
            constraint=models.UniqueConstraint(
                condition=models.Q(("is_active", True)),
                fields=("owner", "provider"),
                name="one_active_credential_per_provider_per_owner"),
        ),
        migrations.AddConstraint(
            model_name="providercredential",
            constraint=models.UniqueConstraint(
                fields=("owner", "provider", "label"),
                name="one_label_per_provider_per_owner"),
        ),
        migrations.AddIndex(
            model_name="providercredential",
            index=models.Index(fields=["owner", "provider", "is_active"],
                               name="pc_owner_prov_active_idx"),
        ),

        # --- the audit trail ---------------------------------------------- #
        migrations.CreateModel(
            name="CredentialEvent",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True,
                                           serialize=False, verbose_name="ID")),
                ("provider", models.CharField(db_index=True, max_length=32)),
                ("label", models.CharField(blank=True, max_length=80)),
                ("kind", models.CharField(choices=[
                    ("created", "Added"), ("activated", "Activated"),
                    ("deactivated", "Deactivated"), ("deleted", "Deleted"),
                    ("tested", "Connection tested"), ("used", "Request succeeded"),
                    ("error", "Request failed"),
                    ("fallback", "Fell back to another credential"),
                ], max_length=16)),
                ("category", models.CharField(blank=True, max_length=32)),
                ("detail", models.CharField(blank=True, max_length=300)),
                ("created_at", models.DateTimeField(auto_now_add=True,
                                                    db_index=True)),
                ("credential", models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name="events", to="outreach.providercredential")),
                ("owner", models.ForeignKey(
                    blank=True, null=True, db_index=True,
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name="credential_events",
                    to=settings.AUTH_USER_MODEL)),
            ],
            options={"ordering": ("-created_at",)},
        ),
        migrations.AddIndex(
            model_name="credentialevent",
            index=models.Index(fields=["owner", "provider", "-created_at"],
                               name="ce_owner_prov_time_idx"),
        ),

        # --- the provider choice becomes per-account ----------------------- #
        migrations.RunSQL(
            # The old table held one row keyed on a literal 1. There is nothing
            # to migrate: it stores a provider name, and Settings re-picks it in
            # one click. Cleared rather than guessed an owner for.
            sql="DELETE FROM outreach_aiselection;",
            reverse_sql=migrations.RunSQL.noop,
        ),
        migrations.RemoveField(model_name="aiselection", name="id"),
        migrations.AddField(
            model_name="aiselection",
            name="id",
            field=models.BigAutoField(auto_created=True, primary_key=True,
                                      serialize=False, verbose_name="ID"),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name="aiselection",
            name="owner",
            field=models.OneToOneField(
                blank=True, null=True,
                on_delete=django.db.models.deletion.CASCADE,
                related_name="ai_selection", to=settings.AUTH_USER_MODEL),
        ),
    ]
