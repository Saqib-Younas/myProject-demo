"""
The credential models leave this app's state.

The other half of `ai.0001_move_ai_credentials`: again `SeparateDatabaseAndState` with
no database operations, so the tables stay exactly as they are and only Django's idea
of which app owns them changes.

Giving them up *after* `ai` has taken them is what keeps the graph unambiguous -- two
apps may not describe the same table at the same time.
"""
from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        # The models must exist in `ai`'s state before they stop existing here.
        ("ai", "0001_move_ai_credentials"),

        ('outreach', '0022_audit_jobs'),
    ]

    operations = [
        migrations.SeparateDatabaseAndState(
            # Nothing. The tables already exist, with their rows in them.
            database_operations=[],
            state_operations=[
                migrations.RemoveField(
                    model_name='aiselection',
                    name='owner',
                ),
                migrations.RemoveIndex(
                    model_name='credentialevent',
                    name='ce_owner_prov_time_idx',
                ),
                migrations.RemoveIndex(
                    model_name='providercredential',
                    name='pc_owner_prov_active_idx',
                ),
                migrations.RemoveConstraint(
                    model_name='providercredential',
                    name='one_active_credential_per_provider_per_owner',
                ),
                migrations.RemoveConstraint(
                    model_name='providercredential',
                    name='one_label_per_provider_per_owner',
                ),
                migrations.DeleteModel(
                    name='AiSelection',
                ),
                migrations.RemoveField(
                    model_name='providercredential',
                    name='owner',
                ),
                migrations.DeleteModel(
                    name='CredentialEvent',
                ),
                migrations.DeleteModel(
                    name='ProviderCredential',
                ),
            ],
        ),
    ]
