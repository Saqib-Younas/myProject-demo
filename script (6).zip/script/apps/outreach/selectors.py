"""
Queries for the lead-intelligence screens: filters, sorting, queues, totals.

All of it in one module so the dashboard cards, the table and the smart queues
cannot disagree about what "hot" means. Every function takes the owner and starts
from `EmailDraft.objects.filter(campaign__owner=owner)`, so there is no query here
that could return another account's leads.

Filters combine. `USA + Restaurants + no website + hot` is four filters over one
queryset, not a special case, because the moment they stop composing somebody has
to write the fifteenth combination by hand.
"""

from __future__ import annotations

from django.db.models import Count, Q, QuerySet

from apps.auditing import scoring

from .models import EmailDraft, Lifecycle, ReplyState, SentLead


def base(owner) -> QuerySet[EmailDraft]:
    """Every lead belonging to this account. The root of everything below."""
    if owner is None or not getattr(owner, "pk", None):
        return EmailDraft.objects.none()
    return (EmailDraft.objects
            .filter(campaign__owner=owner)
            .select_related("campaign", "audit"))


# --------------------------------------------------------------------------- #
# Filters
# --------------------------------------------------------------------------- #

#: Website status. Keys are what the URL carries; the label is what the chip says.
WEBSITE_FILTERS = (
    ("all", "All"),
    ("found", "Website found"),
    ("none", "No website"),
    ("unverified", "Unverified"),
)

PRIORITY_FILTERS = (
    ("all", "All"),
    (scoring.HOT, "Hot"),
    (scoring.WARM, "Warm"),
    (scoring.LOW, "Low"),
    (scoring.SKIP, "Skip"),
)

#: Outreach state, expressed in the vocabulary a salesperson uses rather than the
#: draft statuses underneath.
OUTREACH_FILTERS = (
    ("all", "All"),
    ("not_contacted", "Not contacted"),
    ("email_ready", "Email ready"),
    ("sent", "Sent"),
    ("follow_up_due", "Follow-up due"),
    ("replied", "Replied"),
    ("positive", "Positive"),
    ("negative", "Negative"),
    ("converted", "Converted"),
    ("do_not_contact", "Do not contact"),
)

#: WhatsApp. The detection that fills these in is Task 3; until then every lead
#: answers "unknown", which is the honest answer rather than a guess.
WHATSAPP_FILTERS = (
    ("all", "All"),
    ("available", "Available"),
    ("unavailable", "Unavailable"),
    ("unknown", "Unknown"),
)

SORTS = (
    ("score", "Highest score"),
    ("score_asc", "Lowest score"),
    ("website", "Website score"),
    ("value", "Business value"),
    ("priority", "Priority"),
    ("newest", "Newest"),
    ("outreach", "Outreach status"),
    ("name", "Business name"),
)

_SORT_FIELDS = {
    "score": ("-score_overall", "business_name"),
    "score_asc": ("score_overall", "business_name"),
    "website": ("-score_website", "-score_overall"),
    "value": ("-score_value", "-score_overall"),
    "priority": ("priority", "-score_overall"),
    "newest": ("-campaign__created_at", "-id"),
    "outreach": ("lifecycle", "-score_overall"),
    "name": ("business_name", "-score_overall"),
}


def apply_website_filter(rows: QuerySet, value: str) -> QuerySet:
    return {
        "found": lambda q: q.filter(classification=scoring.WEBSITE_FOUND),
        "none": lambda q: q.filter(classification=scoring.NO_WEBSITE_OPPORTUNITY),
        "unverified": lambda q: q.filter(classification=scoring.WEBSITE_UNVERIFIED),
    }.get(value, lambda q: q)(rows)


def apply_priority_filter(rows: QuerySet, value: str) -> QuerySet:
    if value in (scoring.HOT, scoring.WARM, scoring.LOW, scoring.SKIP):
        return rows.filter(priority=value)
    return rows


def apply_outreach_filter(rows: QuerySet, value: str) -> QuerySet:
    """Outreach state, mapped onto the machinery underneath.

    `positive` and `negative` are the only two that cannot be derived: whether a
    reply was encouraging is a judgement, so they read the lifecycle stages a
    person set rather than guessing from the text of the reply.
    """
    Status = EmailDraft.Status
    mapping = {
        "not_contacted": lambda q: q.filter(
            lifecycle__in=(Lifecycle.NEW, Lifecycle.ANALYZING,
                           Lifecycle.ANALYZED, Lifecycle.QUALIFIED)),
        "email_ready": lambda q: q.filter(lifecycle=Lifecycle.EMAIL_READY),
        "sent": lambda q: q.filter(status=Status.SENT),
        "follow_up_due": lambda q: q.filter(lifecycle=Lifecycle.FOLLOW_UP),
        "replied": lambda q: q.filter(lifecycle__in=(
            Lifecycle.REPLIED, Lifecycle.INTERESTED, Lifecycle.MEETING,
            Lifecycle.WON)),
        "positive": lambda q: q.filter(lifecycle__in=(
            Lifecycle.INTERESTED, Lifecycle.MEETING, Lifecycle.WON)),
        "negative": lambda q: q.filter(lifecycle=Lifecycle.LOST),
        "converted": lambda q: q.filter(lifecycle=Lifecycle.WON),
        "do_not_contact": lambda q: q.filter(
            Q(lifecycle=Lifecycle.DO_NOT_CONTACT)
            | Q(status=Status.SUPPRESSED)),
    }
    return mapping.get(value, lambda q: q)(rows)


def apply_whatsapp_filter(rows: QuerySet, value: str) -> QuerySet:
    """Placeholder until Task 3 adds detection.

    `unknown` matches everything and the other two match nothing, because no lead
    has any WhatsApp evidence yet. Answering "available" for a lead nobody has
    checked would be exactly the guess the brief forbids.
    """
    if value in ("available", "unavailable"):
        return rows.none()
    return rows


def filtered(owner, *, website: str = "all", priority: str = "all",
             outreach: str = "all", whatsapp: str = "all",
             country: str = "", category: str = "", campaign=None,
             search: str = "", sort: str = "score") -> QuerySet[EmailDraft]:
    """One queryset from any combination of filters."""
    rows = base(owner)

    if campaign is not None:
        rows = rows.filter(campaign=campaign)

    rows = apply_website_filter(rows, website)
    rows = apply_priority_filter(rows, priority)
    rows = apply_outreach_filter(rows, outreach)
    rows = apply_whatsapp_filter(rows, whatsapp)

    if country:
        rows = rows.filter(country__iexact=country)
    if category:
        rows = rows.filter(category__iexact=category)
    if search:
        rows = rows.filter(
            Q(business_name__icontains=search)
            | Q(email__icontains=search)
            | Q(website__icontains=search)
            | Q(city__icontains=search))

    order = _SORT_FIELDS.get(sort, _SORT_FIELDS["score"])
    return rows.order_by(*order)


def choices(owner) -> dict[str, list[str]]:
    """The countries and categories this account actually has leads in.

    Built from the data rather than from the full 252-country list, because a
    dropdown of countries with no leads in them is a dropdown of dead ends.
    """
    rows = base(owner)
    return {
        "countries": sorted(
            {c for c in rows.values_list("country", flat=True) if c}),
        "categories": sorted(
            {c for c in rows.values_list("category", flat=True) if c}),
    }


# --------------------------------------------------------------------------- #
# Dashboard totals
# --------------------------------------------------------------------------- #

def summary(owner) -> dict:
    """The dashboard cards, in as few queries as the answers allow."""
    rows = base(owner)

    by_class = dict(rows.values_list("classification").annotate(n=Count("id")))
    by_priority = dict(rows.values_list("priority").annotate(n=Count("id")))
    by_lifecycle = dict(rows.values_list("lifecycle").annotate(n=Count("id")))
    by_status = dict(rows.values_list("status").annotate(n=Count("id")))

    sent_leads = SentLead.objects.filter(owner=owner) if (
        owner is not None and getattr(owner, "pk", None)) else SentLead.objects.none()
    replies = dict(
        sent_leads.filter(status=SentLead.Status.SENT)
        .values_list("reply_state").annotate(n=Count("id")))

    ready = rows.filter(lifecycle=Lifecycle.EMAIL_READY).count()

    return {
        "total": sum(by_class.values()) or rows.count(),
        "website_found": by_class.get(scoring.WEBSITE_FOUND, 0),
        "no_website": by_class.get(scoring.NO_WEBSITE_OPPORTUNITY, 0),
        "unverified": by_class.get(scoring.WEBSITE_UNVERIFIED, 0),
        "unclassified": by_class.get("", 0),
        "hot": by_priority.get(scoring.HOT, 0),
        "warm": by_priority.get(scoring.WARM, 0),
        "low": by_priority.get(scoring.LOW, 0),
        "skip": by_priority.get(scoring.SKIP, 0),
        "emails_ready": ready,
        "emails_sent": by_status.get(EmailDraft.Status.SENT, 0),
        "replies": replies.get(ReplyState.REPLIED, 0),
        "positive": by_lifecycle.get(Lifecycle.INTERESTED, 0)
                    + by_lifecycle.get(Lifecycle.MEETING, 0)
                    + by_lifecycle.get(Lifecycle.WON, 0),
        "meetings": by_lifecycle.get(Lifecycle.MEETING, 0),
        "converted": by_lifecycle.get(Lifecycle.WON, 0),
        "lost": by_lifecycle.get(Lifecycle.LOST, 0),
        "do_not_contact": by_lifecycle.get(Lifecycle.DO_NOT_CONTACT, 0)
                          + by_status.get(EmailDraft.Status.SUPPRESSED, 0),
        "bounced": replies.get(ReplyState.BOUNCED, 0),
        "unsubscribed": replies.get(ReplyState.UNSUBSCRIBED, 0),
        "thresholds": scoring.default_thresholds(),
    }


# --------------------------------------------------------------------------- #
# Smart queues
# --------------------------------------------------------------------------- #

#: The working order the queues impose. Each one is a filter over the same
#: queryset, so a lead is in exactly one of the first four and the counts add up.
QUEUES = (
    {
        "key": "hot_website",
        "icon": "🔥",
        "label": "Hot website leads",
        "blurb": "A verified site with real, evidenced problems. The easiest "
                 "conversation to open, because the opening line writes itself.",
        "filters": {"website": "found", "priority": scoring.HOT},
    },
    {
        "key": "no_website",
        "icon": "🌐",
        "label": "No website opportunities",
        "blurb": "No verified website at all. Nothing to critique -- the whole "
                 "thing is the opportunity.",
        "filters": {"website": "none"},
    },
    {
        "key": "warm",
        "icon": "⭐",
        "label": "Warm leads",
        "blurb": "Worth contacting, but after the hot list.",
        "filters": {"priority": scoring.WARM},
    },
    {
        "key": "unverified",
        "icon": "⚠️",
        "label": "Unverified websites",
        "blurb": "The site could not be read. Check by hand before writing "
                 "anything about it -- unknown is not the same as absent.",
        "filters": {"website": "unverified"},
    },
    {
        "key": "skip",
        "icon": "🚫",
        "label": "Skip",
        "blurb": "Low opportunity on the available evidence. Left visible rather "
                 "than hidden, so the judgement can be checked.",
        "filters": {"priority": scoring.SKIP},
    },
)


def queues(owner) -> list[dict]:
    """Each queue with its live count and the filter link that opens it."""
    out = []
    for queue in QUEUES:
        out.append({
            **queue,
            "count": filtered(owner, **queue["filters"]).count(),
            "query": "&".join(f"{k}={v}" for k, v in queue["filters"].items()),
        })
    return out


def queue(key: str) -> dict | None:
    return next((q for q in QUEUES if q["key"] == key), None)
