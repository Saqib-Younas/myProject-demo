"""
The campaign activity log.

One function, because the value is in being used everywhere rather than in being
clever: every decision the worker makes writes a line, including the dull ones.
An unattended run that logs only failures cannot answer "what did it do at 09:14",
and that is the question somebody actually asks.

Writing an event must never be the reason a campaign stops. A log row is an
account of work, not the work, so a failure to write one is swallowed with a
warning to the process log -- the alternative is a campaign that dies because its
diary was full.
"""

from __future__ import annotations

import logging

from apps.outreach.models import CampaignEvent

log = logging.getLogger(__name__)

Kind = CampaignEvent.Kind


def record(campaign, kind: str, message: str, *, detail: str = "",
           draft=None) -> CampaignEvent | None:
    """Write one line of what happened. Returns the row, or None if it could not.

    `message` is the sentence a person reads on the dashboard: what happened, in
    the terms they configured the campaign in. `detail` carries the part only
    somebody debugging wants -- a provider's error text, a measured number, the
    name of the rule that fired.
    """
    try:
        return CampaignEvent.objects.create(
            campaign=campaign,
            owner_id=campaign.owner_id,
            draft=draft,
            kind=kind,
            message=(message or "")[:400],
            detail=(detail or "")[:400],
        )
    except Exception:  # noqa: BLE001 - the log is not the work
        log.exception("could not record a %s event for campaign %s",
                      kind, campaign.pk)
        return None


def recent(campaign, limit: int = 50):
    """The latest events, newest first."""
    return list(campaign.events.all()[:limit])


def last_activity(campaign):
    """When something last happened, or None."""
    row = campaign.events.first()
    return row.created_at if row else None
