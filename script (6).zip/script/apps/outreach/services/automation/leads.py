"""
Filling the prospect pool.

An automation campaign is configured with countries, cities and categories rather
than with a list of businesses, so somebody has to turn the one into the other. That
is this module: it takes the next unsearched (country, city, category) combination,
runs the same public-map search the Lead search page runs, and writes the results
into the campaign as `EmailDraft` rows -- the same rows a manual campaign holds, so
everything downstream is unchanged.

Three things worth knowing about the design:

**Searching costs somebody else's bandwidth.** Each combination is a geocode against
Nominatim and a query against Overpass, both free services with published usage
policies that `leads.scraper` already respects. So each combination is recorded
before it is tried and marked afterwards, and a campaign never repeats a search it
has already made. That is also what gives "no eligible businesses remaining" a real
meaning: every combination has been tried, not merely the ones we felt like trying.

**The pool is topped up, not pre-filled.** A campaign with 40 combinations and a
total target of 100 should not spend 40 searches before it sends anything. One
search runs when the pool is low, and the campaign gets on with the leads it has.

**Filtering happens here, not later.** A lead that fails a check the map data can
answer -- no website when the campaign asked for one, an address already contacted,
an address on the do-not-contact list -- is written with the status that says so
rather than as a pending lead that will be skipped after being crawled. Recording it
costs a row and saves a crawl.
"""

from __future__ import annotations

import logging

from django.db import IntegrityError, transaction
from django.utils import timezone

from apps.leads import places, scraper
from apps.outreach.models import AutomationPlan, EmailDraft, ProspectSearch
from apps.outreach.services import history

from . import events

log = logging.getLogger(__name__)

#: How many leads one search asks the map for. Above the daily target so a single
#: city can feed a whole day, and well under `scraper.MAX_LEADS` so the Overpass
#: query stays a small one.
SEARCH_SIZE = 60

#: Top the pool up when it falls below this many workable leads. One day's target
#: is the wrong threshold -- it would run a search after every lead once the pool
#: emptied -- so it is a flat number that gives the worker room to keep moving.
LOW_WATER = 5


def combinations(plan: AutomationPlan) -> list[tuple[str, str, str]]:
    """Every (country, city, category) this plan will look through.

    Cities are matched to the country they belong to where the reference data
    knows, so "Dallas, Manchester" against "United States, United Kingdom" produces
    two searches rather than four. Where it does not know -- a city the offline
    dataset has never heard of -- the pair is kept for every selected country and
    the geocoder gets to decide. Guessing wrong there costs one failed search;
    dropping the city would silently lose part of what the user asked for.
    """
    countries = [c for c in (plan.countries or []) if c] or [""]
    cities = [c for c in (plan.cities or []) if c]
    categories = [c for c in (plan.categories or []) if c]

    out: list[tuple[str, str, str]] = []
    for city in cities:
        owners = [country for country in countries
                  if _belongs(city, country)] or countries
        for country in owners:
            for category in categories:
                out.append((country, city, category))
    return out


def _belongs(city: str, country: str) -> bool:
    """Does the reference data place this city in this country?

    False also when it simply does not know the city, which is why the caller
    treats an empty result as "keep every country" rather than as "no match".
    """
    if not country:
        return True
    code = places.code_for(country)
    if not code:
        return False
    return city.casefold() in {name.casefold()
                               for name in places.city_names_for(code)}


def ensure_searches(plan: AutomationPlan) -> int:
    """Write down every combination this plan will search. Returns how many are new.

    Idempotent: the unique constraint on (plan, country, city, category) means a
    second call adds nothing, so a worker may call it on every pass without
    accumulating duplicates or needing to remember whether it already did.
    """
    existing = set(
        plan.searches.values_list("country", "city", "category"))
    fresh = [combo for combo in combinations(plan) if combo not in existing]
    if not fresh:
        return 0

    ProspectSearch.objects.bulk_create(
        [ProspectSearch(plan=plan, country=country, city=city, category=category)
         for country, city, category in fresh],
        ignore_conflicts=True,
    )
    return len(fresh)


def pool_size(plan: AutomationPlan) -> int:
    """Leads waiting to be worked on."""
    return plan.campaign.drafts.filter(status=EmailDraft.Status.PENDING).count()


def searches_left(plan: AutomationPlan) -> int:
    return plan.searches.filter(status=ProspectSearch.Status.PENDING).count()


def claim_search(plan: AutomationPlan) -> ProspectSearch | None:
    """Take the next unsearched combination, or None.

    A conditional UPDATE, so two workers looking at the same plan cannot both spend
    a geocode on the same city. Whoever loses gets the next combination instead of
    a duplicate of the first.
    """
    while True:
        row = plan.searches.filter(
            status=ProspectSearch.Status.PENDING).order_by("pk").first()
        if row is None:
            return None
        taken = ProspectSearch.objects.filter(
            pk=row.pk, status=ProspectSearch.Status.PENDING,
        ).update(status=ProspectSearch.Status.RUNNING,
                 attempts=row.attempts + 1,
                 last_attempt_at=timezone.now())
        if taken:
            row.refresh_from_db()
            return row
        # Somebody else took it between the read and the update. Look again.


def fill(plan: AutomationPlan, *, wanted: int = SEARCH_SIZE) -> int:
    """Run one search and add what it found. Returns the number of leads added.

    Never raises for a search's own problems: a place the geocoder cannot find, a
    category nothing is tagged with, every Overpass mirror busy -- each is recorded
    against the combination and the campaign moves on to the next one. A campaign
    must not end because one city was unmapped.
    """
    ensure_searches(plan)
    search = claim_search(plan)
    if search is None:
        return 0

    try:
        _area, found = scraper.search(
            search.country, search.city, search.category, wanted)
    except scraper.ScrapeError as exc:
        ProspectSearch.objects.filter(pk=search.pk).update(
            status=ProspectSearch.Status.FAILED, detail=str(exc)[:300])
        events.record(
            plan.campaign, events.Kind.SKIPPED,
            f"Search failed: {search.category} in {search.city}",
            detail=str(exc))
        return 0
    except Exception as exc:  # noqa: BLE001 - one unmapped city, not the campaign
        log.exception("prospect search failed for plan %s", plan.pk)
        ProspectSearch.objects.filter(pk=search.pk).update(
            status=ProspectSearch.Status.FAILED,
            detail=f"{type(exc).__name__}: {exc}"[:300])
        events.record(
            plan.campaign, events.Kind.ERROR,
            f"Search failed: {search.category} in {search.city}",
            detail=f"{type(exc).__name__}: {exc}")
        return 0

    added = _absorb(plan, search, found)

    ProspectSearch.objects.filter(pk=search.pk).update(
        status=(ProspectSearch.Status.DONE if found
                else ProspectSearch.Status.EMPTY),
        found=len(found), added=added,
        detail=("" if added else
                "Nothing usable: every result was already contacted, "
                "suppressed, or had no way to reach it."),
    )
    events.record(
        plan.campaign, events.Kind.PROSPECTED,
        f"{added} new prospect(s) from {search.category} in {search.city}",
        detail=f"{len(found)} found on the map, {added} added to the campaign")
    return added


def _absorb(plan: AutomationPlan, search: ProspectSearch, found: list) -> int:
    """Turn map results into drafts. Returns how many are workable.

    The checks here are the ones the map data can answer on its own, and each
    result is stored with the status that says which one it failed -- a lead is
    never silently dropped, because "why is this business not in my campaign" is a
    question the campaign should be able to answer.
    """
    campaign = plan.campaign
    owner = campaign.owner
    index = history.Index(owner)
    blocklist = history.SuppressionIndex(owner)
    seen = set(
        campaign.drafts.exclude(email="").values_list("email", flat=True))
    seen = {value.casefold() for value in seen}

    added = 0
    for lead in found:
        row = lead.as_dict() if hasattr(lead, "as_dict") else dict(lead)
        email = (row.get("email") or "").strip()
        website = (row.get("website") or "").strip()
        key = email.casefold()

        status, note = EmailDraft.Status.PENDING, ""

        if plan.quality != AutomationPlan.Quality.ANY and not website:
            # The campaign asked for businesses with a website. Nothing measurable
            # can be said about one without, and the audit email has no subject.
            status = EmailDraft.Status.EXCLUDED
            note = "No website listed, and this campaign only contacts businesses that have one."
        elif not email and not (website and plan.discover_emails):
            status = EmailDraft.Status.NO_EMAIL
            note = ("No public email address, and no website to find one on."
                    if not website else
                    "No public email address, and this campaign does not read "
                    "contact addresses from websites.")
        elif email and (stop := blocklist.match(email=email, website=website)):
            status = EmailDraft.Status.SUPPRESSED
            note = stop.sentence()
        elif email and key in seen:
            status = EmailDraft.Status.DUPLICATE
            note = "Another lead in this campaign uses this address."
        elif match := index.match(email=email, website=website,
                                  business_name=row.get("business_name", ""),
                                  city=row.get("city", "")):
            status = EmailDraft.Status.DUPLICATE
            note = ("Already contacted — "
                    + history.MATCH_LABELS.get(match.matched_by, match.matched_by)
                    + (f" on {match.sent_date}" if match.sent_date else ""))

        if status == EmailDraft.Status.PENDING:
            if key:
                seen.add(key)
            added += 1

        try:
            with transaction.atomic():
                EmailDraft.objects.create(
                    campaign=campaign,
                    business_name=str(row.get("business_name", ""))[:255] or "Unnamed",
                    email=email if status != EmailDraft.Status.NO_EMAIL else "",
                    website=website[:500],
                    category=str(row.get("category", ""))[:160]
                             or search.category[:160],
                    address=str(row.get("address", ""))[:400],
                    phone=str(row.get("phone", ""))[:80],
                    city=str(row.get("city", ""))[:160] or search.city[:160],
                    country=str(row.get("country", ""))[:160]
                            or search.country[:160],
                    latitude=row.get("latitude"),
                    longitude=row.get("longitude"),
                    source=str(row.get("source", ""))[:500],
                    status=status,
                    error_message=note,
                )
        except IntegrityError:
            # (campaign, email) is unique: this business is already in the
            # campaign from an earlier search of an overlapping area.
            if status == EmailDraft.Status.PENDING:
                added -= 1
            continue

    return added


def top_up(plan: AutomationPlan) -> int:
    """Fill the pool if it is running low. Returns leads added.

    Called by the worker between leads. One search per call, deliberately: a
    campaign should start sending in the first minute rather than after forty
    geocodes.
    """
    if pool_size(plan) >= LOW_WATER:
        return 0
    return fill(plan)


def exhausted(plan: AutomationPlan) -> bool:
    """Nothing left to work on, and nowhere left to look.

    Both halves matter. An empty pool with searches left is a campaign that needs a
    search, not one that is finished -- and calling it finished is how a campaign
    with 39 unsearched cities reports "no eligible businesses remaining" after the
    first one.
    """
    return pool_size(plan) == 0 and searches_left(plan) == 0
