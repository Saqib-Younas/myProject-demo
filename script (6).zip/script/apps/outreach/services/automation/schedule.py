"""
When an automation campaign may run, in its own timezone.

Every function here is pure: given a plan and an instant, it answers a question.
Nothing is written, nothing is cached, and the answer depends on no state other
than the plan's own configuration -- which is what makes the worker's decisions
reproducible and the tests able to ask about 3pm on a Tuesday in Chicago.

**The timezone is the campaign's, never the server's.** A campaign configured
09:00-17:00 America/Chicago must send at nine in Chicago whether the box is in
Ireland or Ohio, and whether or not Chicago is currently on daylight time. So
every comparison here happens between aware datetimes, and the local wall clock is
reconstructed in the campaign's zone rather than assumed from `timezone.now()`.
Naive comparison is the bug this module exists to prevent: it works in
development, where the server is in the same zone as the user, and sends at 3am
once it is deployed anywhere else.

Two edges worth naming, because they are real and not hypothetical:

  * **Spring forward.** In a zone that skips 02:00-03:00, a window opening at
    02:30 names a wall-clock time that does not exist on that date. `zoneinfo`
    resolves it to a real instant anyway, and since the window is a range rather
    than a moment, the run simply opens at the equivalent instant. No special case
    is needed, and inventing one would be worse than the edge.
  * **Autumn back.** A repeated hour means a window can be open for an hour longer
    on that date. Deliberately left alone: sending for 61 minutes inside a
    nine-hour window is not a problem worth code, and `fold` handling would add a
    branch nobody could test the value of.
"""

from __future__ import annotations

import datetime as dt
from dataclasses import dataclass
from zoneinfo import ZoneInfo, available_timezones

from django.utils import timezone

#: Offered in the form, in the order somebody scanning a list would want them.
#: Not the whole tz database -- 600 entries in a dropdown is not a choice, it is a
#: search problem -- but any valid zone name is accepted by `valid_zone`, so a
#: campaign in Asia/Kolkata is configurable even though it is not on this list.
COMMON_ZONES: tuple[str, ...] = (
    "America/New_York",
    "America/Chicago",
    "America/Denver",
    "America/Phoenix",
    "America/Los_Angeles",
    "America/Anchorage",
    "America/Toronto",
    "America/Vancouver",
    "America/Mexico_City",
    "America/Sao_Paulo",
    "Europe/London",
    "Europe/Dublin",
    "Europe/Lisbon",
    "Europe/Madrid",
    "Europe/Paris",
    "Europe/Amsterdam",
    "Europe/Berlin",
    "Europe/Rome",
    "Europe/Stockholm",
    "Europe/Warsaw",
    "Europe/Athens",
    "Europe/Istanbul",
    "Africa/Lagos",
    "Africa/Johannesburg",
    "Africa/Cairo",
    "Asia/Jerusalem",
    "Asia/Dubai",
    "Asia/Karachi",
    "Asia/Kolkata",
    "Asia/Dhaka",
    "Asia/Bangkok",
    "Asia/Singapore",
    "Asia/Hong_Kong",
    "Asia/Shanghai",
    "Asia/Tokyo",
    "Asia/Seoul",
    "Australia/Perth",
    "Australia/Brisbane",
    "Australia/Sydney",
    "Australia/Melbourne",
    "Pacific/Auckland",
    "UTC",
)

#: The default when nothing else is known. UTC rather than the server's zone: a
#: server zone is an accident of hosting, and a campaign that silently inherits it
#: sends at a different time after a migration to another region.
DEFAULT_ZONE = "UTC"

#: The end of a day when no daily cutoff was configured. A second before midnight
#: rather than midnight itself, so "closes at" never reads as the following day.
LAST_MOMENT = dt.time(23, 59, 59)


class ScheduleError(ValueError):
    """A schedule that cannot be interpreted, with a sentence a person can read."""


def valid_zone(name: str) -> bool:
    return bool(name) and name in available_timezones()


def zone(name: str) -> ZoneInfo:
    """The campaign's zone, or a readable error.

    An unknown zone is refused rather than quietly replaced with UTC. Substituting
    a zone would move every send by hours without saying so.
    """
    try:
        return ZoneInfo(name)
    except Exception as exc:  # noqa: BLE001 - ZoneInfoNotFoundError and friends
        raise ScheduleError(
            f"{name!r} is not a known timezone. Use a name from the IANA "
            "database, such as America/Chicago."
        ) from exc


def now_local(plan, at: dt.datetime | None = None) -> dt.datetime:
    """`at` (or the present) as a wall clock in the campaign's zone."""
    moment = at or timezone.now()
    if timezone.is_naive(moment):
        # Only reachable from a caller that built a datetime by hand. Assumed to
        # be UTC rather than local, because assuming local is how a naive
        # datetime becomes a wrong answer that looks right in development.
        moment = moment.replace(tzinfo=dt.timezone.utc)
    return moment.astimezone(zone(plan.timezone_name or DEFAULT_ZONE))


def local_date(plan, at: dt.datetime | None = None) -> dt.date:
    """The campaign's own date. What "today's target" is counted against."""
    return now_local(plan, at).date()


def window(plan, day: dt.date) -> tuple[dt.datetime, dt.datetime]:
    """(opens, closes) for one campaign-local date, as aware datetimes."""
    tz = zone(plan.timezone_name or DEFAULT_ZONE)
    opens = dt.datetime.combine(day, plan.start_time, tzinfo=tz)
    closes = dt.datetime.combine(day, plan.end_time or LAST_MOMENT, tzinfo=tz)
    return opens, closes


@dataclass(frozen=True)
class Window:
    """What the schedule says right now.

    `open` is the only field the worker acts on. The rest exist so the dashboard
    and the event log can explain the decision rather than just report it -- "not
    yet: opens 09:00 tomorrow" is a different thing to a user from "finished: the
    end date has passed", and a single boolean cannot tell them apart.
    """

    open: bool
    reason: str
    finished: bool = False
    opens_at: dt.datetime | None = None
    closes_at: dt.datetime | None = None
    next_open: dt.datetime | None = None


def state(plan, at: dt.datetime | None = None) -> Window:
    """Is this campaign allowed to work at `at`, and if not, why not."""
    local = now_local(plan, at)
    today = local.date()

    # Finished beats everything: an end date in the past is not "closed until
    # tomorrow", and offering a next opening for a campaign that can never open
    # again would be a lie the dashboard then displays.
    if plan.end_date and today > plan.end_date:
        return Window(
            open=False, finished=True,
            reason=(f"The campaign's end date ({plan.end_date:%d %b %Y}) has "
                    "passed."),
        )

    if today < plan.start_date:
        opens, closes = window(plan, plan.start_date)
        return Window(
            open=False, opens_at=opens, closes_at=closes, next_open=opens,
            reason=(f"Not started yet: begins {opens:%d %b %Y at %H:%M %Z}."),
        )

    opens, closes = window(plan, today)

    if local < opens:
        return Window(
            open=False, opens_at=opens, closes_at=closes, next_open=opens,
            reason=f"Outside today's window: opens at {opens:%H:%M %Z}.",
        )

    if local > closes:
        # The last day's cutoff is the end of the campaign, not a wait for a
        # tomorrow that is not allowed to happen.
        if plan.end_date and today >= plan.end_date:
            return Window(
                open=False, finished=True, opens_at=opens, closes_at=closes,
                reason=(f"The campaign's final window closed at "
                        f"{closes:%H:%M %Z} on {closes:%d %b %Y}."),
            )
        tomorrow, _closes = window(plan, today + dt.timedelta(days=1))
        return Window(
            open=False, opens_at=opens, closes_at=closes, next_open=tomorrow,
            reason=(f"Today's window closed at {closes:%H:%M %Z}. Opens again "
                    f"{tomorrow:%d %b at %H:%M %Z}."),
        )

    return Window(
        open=True, opens_at=opens, closes_at=closes,
        reason=f"Open until {closes:%H:%M %Z}.",
    )


def next_open(plan, at: dt.datetime | None = None) -> dt.datetime | None:
    """When work may next begin, or None if it never may again."""
    verdict = state(plan, at)
    if verdict.open:
        return now_local(plan, at)
    return verdict.next_open


def tomorrow_open(plan, at: dt.datetime | None = None) -> dt.datetime | None:
    """When the *next* day's window opens, or None if there is not one.

    Asked when today's allowance is spent, which is the one case `next_open` cannot
    answer: the window is still open, so "when does it next open" is "now" -- true,
    and useless to somebody who cannot send again until tomorrow.
    """
    day = local_date(plan, at) + dt.timedelta(days=1)
    if plan.end_date and day > plan.end_date:
        return None
    return window(plan, day)[0]


def describe(plan) -> str:
    """The schedule in one line, for a summary panel or an event."""
    days = f"{plan.start_date:%d %b %Y}"
    if plan.end_date:
        days += f" – {plan.end_date:%d %b %Y}"
    hours = f"{plan.start_time:%H:%M}"
    if plan.end_time:
        hours += f"–{plan.end_time:%H:%M}"
    return f"{days}, {hours} {plan.timezone_name}"
