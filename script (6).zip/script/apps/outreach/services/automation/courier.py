"""
The sending side of an unattended run.

One authenticated SMTP session, held open across a run of leads, with the pacing
and the ceilings that keep a real mailbox out of trouble. Everything about *which*
address is allowed to send is `mailaccounts`' answer, not this module's -- it asks,
and refuses to send when the answer is no.

What this module is careful about:

**Spacing.** A provider that accepts twenty messages in four seconds will start
filtering the domain that sent them. Each provider preset already carries a
`delay`; a campaign may ask for more, never less.

**The ceiling is the provider's.** `mailaccounts.daily_cap` takes the lower of the
account's own limit and the provider's published one. A campaign cannot raise it,
because it is not ours to raise -- that is somebody else's service, and asking it
to break its own rules is the definition of the thing the brief rules out.

**Reserving the address comes first.** `history.reserve` inserts a row against a
unique constraint before SMTP is opened. That insert is what makes a second email
to the same person impossible -- across two workers, two campaigns, and a task
retried after a crash halfway through. If the insert fails the send never happens,
which is the correct order: a duplicate reservation is a skipped lead, while a
duplicate send is an email a stranger already read.

**A failed send is not a sent email.** The draft goes back to approved, the history
row is marked failed so the address is free for a later attempt, and the campaign
carries on. What it must never do is count.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass

from django.utils import timezone

from apps.outreach.mail import accounts as mailaccounts
from apps.outreach.mail import compose, followups, transport
from apps.outreach.models import EmailDraft
from apps.outreach.services import history

log = logging.getLogger(__name__)

#: A send that fails this many times in a row is not a bad recipient, it is a
#: broken account or a provider outage. The campaign stops and says so, because
#: continuing means burning the remaining leads against the same wall.
MAX_CONSECUTIVE_FAILURES = 3


class AccountUnavailable(RuntimeError):
    """The campaign's mailbox cannot send, with a sentence saying why."""


@dataclass
class Result:
    """What happened to one send."""

    sent: bool
    reason: str = ""
    message_id: str = ""
    #: True when the problem is the account or the provider rather than this
    #: recipient -- the caller stops the run rather than moving to the next lead.
    fatal: bool = False


class Courier:
    """One SMTP session, opened on first use and closed with the run.

    Lazy on purpose: a worker pass that finds nothing to send should not
    authenticate against anybody's mail server, and a campaign whose window closed
    two minutes ago should not open a connection to discover that.
    """

    def __init__(self, plan):
        self.plan = plan
        self.campaign = plan.campaign
        self.account = plan.email_account
        self.session: transport.Session | None = None
        self.sent = 0
        self.failures = 0
        self._last_send: float | None = None

    # --- lifecycle ---------------------------------------------------------- #

    def __enter__(self) -> "Courier":
        return self

    def __exit__(self, *exc_info) -> bool:
        self.close()
        return False

    def close(self) -> None:
        if self.session is not None:
            try:
                self.session.__exit__(None, None, None)
            except Exception:  # noqa: BLE001 - closing a socket, not the work
                log.debug("SMTP session closed untidily", exc_info=True)
            self.session = None

    # --- what the account will allow --------------------------------------- #

    def check(self) -> str:
        """"" if this account can send right now, otherwise why not.

        Read before every lead, not once at the start: an account switched off, or
        one that reaches its daily ceiling mid-run, must stop the run at that point
        rather than at the end of it.
        """
        account = self.account
        if account is None:
            return ("This campaign has no sending address. Choose one in the "
                    "campaign's settings.")

        account.refresh_from_db()
        if not account.is_active:
            return f"{account.name} has been switched off."
        if not account.configured:
            return f"No password is stored for {account.name}."
        if account.connection_status == account.Connection.FAILED:
            return (f"The last connection test for {account.name} failed: "
                    f"{account.connection_detail or 'no detail recorded'}.")
        if mailaccounts.remaining_today(account) <= 0:
            return (f"{account.name} has reached its daily limit of "
                    f"{mailaccounts.daily_cap(account)} messages.")
        return ""

    def remaining_today(self) -> int:
        return (mailaccounts.remaining_today(self.account)
                if self.account is not None else 0)

    # --- sending ------------------------------------------------------------ #

    def _open(self) -> transport.Session:
        if self.session is not None:
            return self.session

        account = self.account
        password = mailaccounts.password_of(account)
        if not password:
            raise AccountUnavailable(
                f"No usable password is stored for {account.name}.")

        session = transport.Session(
            mailaccounts.provider_of(account),
            account.sender_email,
            password,
            host=account.smtp_host,
            port=account.smtp_port or 0,
            username=account.username or account.sender_email,
        )
        try:
            session.__enter__()
        except transport.SendError as exc:
            raise AccountUnavailable(str(exc)) from exc
        self.session = session
        return session

    def _pace(self) -> None:
        """Wait out whatever spacing this provider and campaign ask for."""
        gap = max(mailaccounts.provider_of(self.account).delay,
                  float(self.plan.send_gap_seconds or 0))
        if self._last_send is None or gap <= 0:
            return
        waited = time.monotonic() - self._last_send
        if waited < gap:
            time.sleep(gap - waited)

    def send(self, draft: EmailDraft) -> Result:
        """Send one draft. Records the outcome; never raises for one recipient.

        The order is the whole point: claim the draft, reserve the address, open the
        session, send, record. Every step before the send is one that can refuse,
        and each of them refusing means no email rather than a half-recorded one.
        """
        blocked = self.check()
        if blocked:
            return Result(sent=False, reason=blocked, fatal=True)

        # Draft-level claim: approved -> sending, conditionally. A second worker
        # that reached this lead at the same moment gets nothing.
        claimed = EmailDraft.objects.filter(
            pk=draft.pk, status=EmailDraft.Status.APPROVED,
        ).update(status=EmailDraft.Status.SENDING) == 1
        if not claimed:
            return Result(sent=False,
                          reason="Another worker is already sending this lead.")

        draft.refresh_from_db()

        # Address-level reservation: an insert against a unique constraint, and
        # the thing that makes a duplicate send impossible rather than unlikely.
        try:
            record = history.reserve(draft, sender_account=self.account,
                                    sender_email=self.account.sender_email)
        except history.DoNotContact as exc:
            EmailDraft.objects.filter(pk=draft.pk).update(
                status=EmailDraft.Status.SUPPRESSED,
                error_message=str(exc)[:2000])
            return Result(sent=False, reason=str(exc))
        except history.AlreadyContacted as exc:
            EmailDraft.objects.filter(pk=draft.pk).update(
                status=EmailDraft.Status.DUPLICATE,
                error_message=str(exc)[:2000])
            return Result(sent=False, reason=str(exc))

        try:
            session = self._open()
        except AccountUnavailable as exc:
            record.mark_failed(str(exc))
            self._release(draft)
            return Result(sent=False, reason=str(exc), fatal=True)

        self._pace()

        try:
            message_id = session.send(
                to_email=draft.email,
                subject=draft.subject,
                body=compose.with_signature(draft.body, self.account.signature),
                sender_name=(self.account.sender_name
                             or self.campaign.sender_name),
                reply_to=self.account.reply_to,
            )
        except transport.SendError as exc:
            # Session-level: the connection or the login, not this recipient.
            record.mark_failed(str(exc)[:300])
            self._release(draft)
            self.close()
            self.failures += 1
            return Result(sent=False, reason=str(exc),
                          fatal=self.failures >= MAX_CONSECUTIVE_FAILURES)
        except Exception as exc:  # noqa: BLE001 - one refused recipient
            message = f"{type(exc).__name__}: {exc}"
            record.mark_failed(message[:300])
            EmailDraft.objects.filter(pk=draft.pk).update(
                status=EmailDraft.Status.FAILED,
                error_message=message[:2000])
            self.failures += 1
            mailaccounts.note_failure(self.account, message)
            return Result(sent=False, reason=message,
                          fatal=self.failures >= MAX_CONSECUTIVE_FAILURES)

        self._last_send = time.monotonic()
        self.failures = 0
        self.sent += 1

        # Recorded before anything else: a reply can only be matched to this email
        # by the Message-ID it will quote.
        record.mark_sent(message_id=message_id)
        EmailDraft.objects.filter(pk=draft.pk).update(
            status=EmailDraft.Status.SENT,
            sent_at=timezone.now(),
            error_message="",
            sent_account=self.account,
        )
        mailaccounts.note_success(self.account)

        # §9: when the next follow-up becomes due, written from the send that just
        # happened. Preparing it is the worker's job; sending it is not.
        if self.plan.followups_enabled:
            try:
                followups.schedule_next(record)
            except Exception:  # noqa: BLE001 - an email that went out has gone out
                log.exception("could not schedule a follow-up for %s", record.pk)

        return Result(sent=True, message_id=message_id)

    def _release(self, draft: EmailDraft) -> None:
        """Put a claimed draft back, so a later run can try it again."""
        EmailDraft.objects.filter(
            pk=draft.pk, status=EmailDraft.Status.SENDING,
        ).update(status=EmailDraft.Status.APPROVED)
