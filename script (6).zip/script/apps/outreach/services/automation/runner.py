"""
The loop: which campaign, which lead, and when to stop.

This is the only module that decides anything about a *campaign*. Everything below
it decides about one lead, one search or one send, and everything above it -- the
management command, the views -- only asks this to run.

The shape of one pass over one campaign:

    lease the plan            so a second worker leaves it alone
    check the operator        paused, stopped and completed all mean stop
    check the schedule        outside the window means stop, in the campaign's zone
    check the targets         total reached means finish, daily reached means wait
    check the mailbox         unusable means stop, with the reason on the dashboard
    then, per lead:
        reserve a day slot    a conditional UPDATE; the database decides
        claim the lead        a conditional UPDATE; the database decides again
        process it            crawl, review, write, validate, send
        record the outcome    on the draft, in the day row, in the event log
        release the slot      if nothing was sent, so a skip costs no allowance

Every stop condition in §5 is in `_halt`, in one place, checked before every lead
rather than once at the top. A campaign paused at 09:14 must stop at 09:14 and not
after the forty leads that were left in the pass.

**Nothing here trusts a Python variable across a boundary.** The daily target, the
lead claim and the address reservation are all conditional writes, so two workers
racing produce one email and a task retried after a crash produces none.
"""

from __future__ import annotations

import logging
import os
import socket
import time
import uuid
from dataclasses import dataclass, field
from datetime import timedelta

from django.db import transaction
from django.db.models import Q
from django.utils import timezone

from apps.outreach.models import AutomationPlan, Campaign, EmailDraft
from apps.outreach.services import campaigns as campaign_ops
from apps.outreach.services import pipeline as manual_runner

from . import courier as courier_module
from . import events, leads, process, schedule

log = logging.getLogger(__name__)

#: How long a worker's claim on a plan lasts. Long enough that a slow lead -- a
#: crawl plus two AI calls -- cannot expire mid-flight, short enough that a worker
#: killed by a deploy does not leave a campaign stuck for an hour.
LEASE_SECONDS = 600

#: Most leads one pass will do before returning, whatever the targets say. A pass
#: that never returns cannot notice a Pause, and a cron-driven worker that runs for
#: an hour overlaps the next one for fifty minutes.
PASS_LIMIT = 25

#: Most follow-ups one pass will draft. Small: a follow-up costs an AI call, and a
#: campaign that has just spent its daily allowance on first contacts should not then
#: spend twenty more here. A backlog is worked through over several passes.
FOLLOWUP_LIMIT = 5

#: A pass that finds nothing to do returns immediately rather than polling.
IDLE = "idle"


def worker_id() -> str:
    """Who holds the lease. Host, pid and a short random part.

    The random part matters: two workers started by the same cron entry in the same
    container share host and pid namespace, and a lease that cannot tell them apart
    is not a lease.
    """
    return f"{socket.gethostname()}/{os.getpid()}/{uuid.uuid4().hex[:6]}"


@dataclass
class Report:
    """What one pass did, for the command's output and for the tests."""

    plan_id: int | None = None
    campaign: str = ""
    sent: int = 0
    skipped: int = 0
    failed: int = 0
    prospected: int = 0
    followups: int = 0
    stopped_because: str = ""
    completed: bool = False
    notes: list[str] = field(default_factory=list)

    @property
    def processed(self) -> int:
        return self.sent + self.skipped + self.failed

    def line(self) -> str:
        return (f"{self.campaign or 'campaign'}: {self.sent} sent, "
                f"{self.skipped} skipped, {self.failed} failed"
                + (f" -- {self.stopped_because}" if self.stopped_because else ""))


# --------------------------------------------------------------------------- #
# Choosing what to work on
# --------------------------------------------------------------------------- #

def due_plans(owner=None):
    """Plans that might have work, least recently active first.

    Only the campaign status is filtered in SQL. The schedule cannot be -- it
    depends on each campaign's own timezone, and expressing "is 14:05 in Chicago
    inside 09:00-17:00" in a query would mean storing UTC offsets that go stale
    twice a year. So the cheap filter runs in the database and the timezone-aware
    one runs in Python, over a handful of rows.

    Least recently active first, so a campaign that has been waiting gets its turn
    before one that has just had a pass. Otherwise two campaigns with the same
    schedule would starve the second one forever.
    """
    query = (AutomationPlan.objects
             .select_related("campaign", "email_account", "owner")
             .filter(campaign__status__in=(Campaign.Status.ACTIVE,
                                          Campaign.Status.SCHEDULED))
             .order_by("last_activity_at", "pk"))
    if owner is not None:
        query = query.filter(owner=owner)
    return query


def claim(plan: AutomationPlan, who: str, *, seconds: int = LEASE_SECONDS) -> bool:
    """Take the lease on this plan. False means another worker holds it.

    A conditional UPDATE against the current lease: free, expired, or already ours.
    A lease rather than a lock because a worker cannot be relied on to release one
    -- it may be killed mid-lead -- and a campaign that needs a human to unstick it
    is worse than one that waits ten minutes.
    """
    now = timezone.now()
    until = now + timedelta(seconds=seconds)
    # Free, expired, or already ours. All three in the WHERE clause, so the
    # database decides -- reading the lease and then writing it would let two
    # workers both see it free.
    free = (Q(locked_until__isnull=True) | Q(locked_until__lt=now)
            | Q(locked_by=who))
    taken = (AutomationPlan.objects
             .filter(pk=plan.pk).filter(free)
             .update(locked_by=who, locked_until=until))
    if taken:
        plan.locked_by = who
        plan.locked_until = until
    return bool(taken)


def release(plan: AutomationPlan) -> None:
    """Give the lease back, so the next pass can start immediately."""
    AutomationPlan.objects.filter(pk=plan.pk, locked_by=plan.locked_by).update(
        locked_by="", locked_until=None)


# --------------------------------------------------------------------------- #
# Stop conditions
# --------------------------------------------------------------------------- #

@dataclass(frozen=True)
class Halt:
    """A reason to stop, and what it means for the campaign."""

    reason: str
    #: True when the campaign is finished rather than merely waiting.
    complete: bool = False


def _halt(plan: AutomationPlan, courier: courier_module.Courier | None,
          done_this_pass: int) -> Halt | None:
    """Every §5 stop condition, in one place. None means carry on.

    Checked before each lead, not once per pass. A campaign paused while a pass is
    running must stop at the next lead boundary -- which is the earliest moment it
    can stop without abandoning a lead half-processed.
    """
    campaign = plan.campaign
    campaign.refresh_from_db(fields=["status", "status_note"])

    # 1. The operator's decision beats everything, including the schedule and the
    #    targets. Paused means paused now, not at the end of the pass.
    if campaign.status == Campaign.Status.PAUSED:
        return Halt("Paused" + (f": {campaign.status_note}"
                                if campaign.status_note else "."))
    if campaign.status == Campaign.Status.STOPPED:
        return Halt("Stopped by hand.")
    if campaign.status == Campaign.Status.COMPLETED:
        return Halt(plan.completion_reason or "Already completed.",
                    complete=True)
    if campaign.status not in (Campaign.Status.ACTIVE, Campaign.Status.SCHEDULED):
        return Halt(f"The campaign is {campaign.get_status_display().lower()}.")

    # 2. The total target. Checked from the sent drafts, so it cannot drift.
    if plan.target_reached:
        return Halt(f"Total target of {plan.total_target} reached.",
                    complete=True)

    # 3. The window, in the campaign's own timezone.
    window = schedule.state(plan)
    if window.finished:
        return Halt(window.reason, complete=True)
    if not window.open:
        return Halt(window.reason)

    # 4. Today's allowance. Read without creating the row: deciding whether a
    #    campaign may work must not write anything, or a dry run leaves counters
    #    behind for a day it never worked. `_one` creates the row when it actually
    #    reserves a slot, which is the only moment the count matters.
    today = plan.days.filter(day=schedule.local_date(plan)).first()
    if today is not None and today.reserved >= plan.daily_target:
        # Tomorrow's opening, not `window.next_open`: the window is still open, so
        # that would answer "now" -- correct and useless to somebody who cannot send
        # again until the next day.
        again = schedule.tomorrow_open(plan)
        return Halt(
            f"Today's target of {plan.daily_target} is used up. "
            + (f"Resumes {again:%d %b at %H:%M %Z}." if again else
               "The campaign ends today, so this was its last window."))

    # 5. The mailbox. Read every time: an account switched off, or one that hits
    #    its provider ceiling mid-run, stops the campaign at that point.
    if courier is not None:
        unusable = courier.check()
        if unusable:
            return Halt(unusable)

    # 6. Nothing left to work on, and nowhere left to look.
    if leads.exhausted(plan):
        return Halt("No eligible businesses remaining.", complete=True)

    # 7. This pass has done enough. Not a campaign condition -- the next pass
    #    picks up where this one stopped.
    if done_this_pass >= PASS_LIMIT:
        return Halt(f"Pass limit of {PASS_LIMIT} lead(s) reached.")

    return None


# --------------------------------------------------------------------------- #
# Claiming one lead
# --------------------------------------------------------------------------- #

def claim_lead(plan: AutomationPlan) -> EmailDraft | None:
    """Take the next workable lead, or None.

    The claim is a conditional UPDATE from `pending` to `crawling`-in-progress --
    represented by `processed_at` being set with the status still pending would be
    ambiguous, so the lead moves to `sending`-adjacent states only later. What
    matters is that exactly one worker can observe a row as claimable and change
    it: the second gets rowcount zero and asks for the next lead instead.

    Ordered by score where one has been worked out, then by insertion. A lead that
    a previous pass already scored highly is worth contacting before an unscored
    one -- and on the first pass nothing is scored, so it is insertion order, which
    is the map's own "best contact details first" ordering.
    """
    while True:
        row = (plan.campaign.drafts
               .filter(status=EmailDraft.Status.PENDING, claimed_by="")
               .order_by("-score_overall", "pk")
               .first())
        if row is None:
            return None
        stamp = timezone.now()
        taken = (EmailDraft.objects
                 .filter(pk=row.pk, status=EmailDraft.Status.PENDING,
                         claimed_by="")
                 .update(claimed_by=plan.locked_by or "worker",
                         claimed_at=stamp))
        if taken:
            row.refresh_from_db()
            return row
        # Somebody else took it between the read and the update. Next one.


def unclaim(draft: EmailDraft) -> None:
    """Let go of a lead without having finished it.

    Only ever called for a lead that is still pending -- one that got as far as
    being crawled or written keeps its progress, and the claim marker is cleared so
    a later pass can carry on from where this one stopped.
    """
    EmailDraft.objects.filter(pk=draft.pk).update(claimed_by="", claimed_at=None)


# --------------------------------------------------------------------------- #
# One pass over one campaign
# --------------------------------------------------------------------------- #

def run_plan(plan: AutomationPlan, *, who: str = "", limit: int = PASS_LIMIT,
             dry_run: bool = False) -> Report:
    """Work one campaign for as long as its own rules allow.

    Returns rather than looping forever: the caller decides whether to come back,
    and a pass that ends is a pass that can notice a Pause, a redeployment or a
    changed configuration.
    """
    from apps.outreach.models import WorkerRun

    who = who or worker_id()
    report = Report(plan_id=plan.pk, campaign=plan.name)

    if not claim(plan, who):
        # Losing the claim is the ordinary case when two passes overlap, not a failure,
        # so it is deliberately not recorded as a run: a status panel counting these
        # would report a worker failing every five minutes when it is working correctly.
        report.stopped_because = "Another worker is running this campaign."
        report.notes.append(report.stopped_because)
        return report

    # Recorded here rather than in the command, so a pass started from a thread or a
    # `--loop` shows up on the Follow-Ups page's worker panel too.
    run = WorkerRun.begin(WorkerRun.Job.AUTOMATION, owner=plan.owner, worker=who,
                          dry_run=dry_run)
    try:
        result = _work(plan, report, limit=limit, dry_run=dry_run)
    except Exception as exc:                      # noqa: BLE001 - recorded, then re-raised
        run.finish(ok=False, detail=f"{type(exc).__name__}: {exc}")
        raise
    finally:
        release(plan)

    run.finish(ok=True,
               considered=result.sent + result.skipped + result.failed,
               succeeded=result.sent, skipped=result.skipped,
               failed=result.failed, detail=result.stopped_because or "")
    return result


def _work(plan: AutomationPlan, report: Report, *, limit: int,
          dry_run: bool) -> Report:
    campaign = plan.campaign

    # A scheduled campaign becomes active the moment its window first opens. The
    # status is the operator's, but "scheduled" is a statement about time, and time
    # has passed -- so the worker makes the transition and says so.
    if campaign.status == Campaign.Status.SCHEDULED and schedule.state(plan).open:
        if not dry_run:
            campaign_ops.set_status(campaign, Campaign.Status.ACTIVE,
                                    note="Started by the scheduler.")
            events.record(campaign, events.Kind.STARTED,
                          f"Campaign started: {plan.name}",
                          detail=schedule.describe(plan))

    courier = courier_module.Courier(plan)
    try:
        with courier:
            _loop(plan, report, courier, limit=limit, dry_run=dry_run)
    except manual_runner.RateLimited as limited:
        # The provider, not this campaign. Recorded and left alone: the next pass
        # tries again, and the existing pause machinery already carries the
        # retry-after logic for interactive runs.
        report.stopped_because = f"AI provider rate limit: {limited}"
        events.record(campaign, events.Kind.QUOTA,
                      "Paused on an AI provider limit",
                      detail=str(limited))
    except Exception as exc:  # noqa: BLE001 - one campaign, not the worker
        log.exception("automation pass failed for plan %s", plan.pk)
        report.stopped_because = f"{type(exc).__name__}: {exc}"
        events.record(campaign, events.Kind.ERROR, "The campaign stopped",
                      detail=report.stopped_because)

    # Follow-ups that have come due, prepared and left for a person. Deliberately
    # after the sending loop: first contact is what the targets are about, and a
    # pass that stopped early for a rate limit should not then make more AI calls.
    if (not dry_run and plan.followups_enabled and not report.stopped_because
            .startswith("AI provider")):
        try:
            report.followups = process.prepare_followups(plan, FOLLOWUP_LIMIT)
        except Exception:  # noqa: BLE001 - a follow-up is not the campaign
            log.exception("could not prepare follow-ups for plan %s", plan.pk)

    if not dry_run:
        AutomationPlan.objects.filter(pk=plan.pk).update(
            last_activity_at=timezone.now(),
            next_run_at=schedule.next_open(plan))
    return report


def _loop(plan: AutomationPlan, report: Report,
          courier: courier_module.Courier, *, limit: int, dry_run: bool) -> None:
    """Lead after lead, until a stop condition says otherwise."""
    while True:
        halt = _halt(plan, courier, report.processed)
        if halt is not None:
            report.stopped_because = halt.reason
            if halt.complete and not dry_run:
                _complete(plan, halt.reason)
                report.completed = True
            elif not dry_run:
                events.record(plan.campaign, events.Kind.SCHEDULE
                              if "window" in halt.reason.lower()
                              else events.Kind.QUOTA,
                              halt.reason)
            return

        if report.processed >= limit:
            report.stopped_because = f"Pass limit of {limit} lead(s) reached."
            return

        # Top the pool up before claiming, so an empty pool becomes a search
        # rather than a premature "no businesses remaining".
        if not dry_run:
            added = leads.top_up(plan)
            report.prospected += added

        draft = claim_lead(plan)
        if draft is None:
            if leads.searches_left(plan):
                # More places to look, but this pass has spent its search. The
                # next one will find them.
                report.stopped_because = ("Waiting for the next prospect search.")
                return
            report.stopped_because = "No eligible businesses remaining."
            if not dry_run:
                _complete(plan, report.stopped_because)
                report.completed = True
            return

        if dry_run:
            report.notes.append(f"would process {draft.business_name}")
            unclaim(draft)
            report.skipped += 1
            continue

        _one(plan, report, courier, draft)


def _one(plan: AutomationPlan, report: Report,
         courier: courier_module.Courier, draft: EmailDraft) -> None:
    """One lead: reserve the allowance, process, record, release if unused."""
    today = plan.day(schedule.local_date(plan))

    # The day slot is taken before any work happens. Reserving after processing
    # would mean two workers could both finish a lead and both send, having each
    # seen 24 of 25 used.
    if not today.reserve(plan.daily_target):
        report.stopped_because = (
            f"Today's target of {plan.daily_target} is used up.")
        unclaim(draft)
        return

    verdict = process.eligibility(plan, draft)
    if not verdict.ok:
        process.refuse(plan, draft, verdict)
        today.release()
        today.record(process.SKIPPED)
        report.skipped += 1
        return

    try:
        outcome = process.process(plan, draft, courier)
    except manual_runner.RateLimited:
        # Nothing was sent, so the slot goes back and the lead stays claimable.
        today.release()
        unclaim(draft)
        raise
    except Exception:
        # An unexpected failure must not quietly shrink today's allowance. The
        # slot goes back; the lead keeps whatever progress it made, so the next
        # pass carries on rather than re-crawling.
        today.release()
        today.record(process.FAILED)
        raise

    if outcome.result == process.SENT:
        today.record(process.SENT)
        report.sent += 1
    else:
        # A skipped or failed lead does not spend the day's allowance: the
        # allowance limits emails, not attempts.
        today.release()
        today.record(outcome.result)
        if outcome.result == process.FAILED:
            report.failed += 1
        else:
            report.skipped += 1

    if outcome.fatal:
        report.stopped_because = outcome.reason
        # A mailbox or provider problem, not this lead's. The campaign pauses
        # itself so a person sees it rather than the worker retrying into a wall.
        _pause(plan, outcome.reason)


def _complete(plan: AutomationPlan, reason: str) -> None:
    """Mark the campaign finished, with the reason it finished for.

    Idempotent: a campaign already completed keeps the reason it completed with,
    because the first reason is the true one and a later pass would overwrite it
    with "already completed".
    """
    plan.campaign.refresh_from_db(fields=["status"])
    if plan.campaign.status == Campaign.Status.COMPLETED:
        return

    AutomationPlan.objects.filter(pk=plan.pk).update(completion_reason=reason[:300])
    plan.completion_reason = reason
    try:
        campaign_ops.set_status(plan.campaign, Campaign.Status.COMPLETED,
                                note=reason)
    except campaign_ops.TransitionError:
        # A campaign somebody stopped by hand in the same second. Their decision
        # wins; the reason is already recorded on the plan.
        log.info("plan %s could not be completed from %s", plan.pk,
                 plan.campaign.status)
        return
    events.record(plan.campaign, events.Kind.COMPLETED,
                  f"Campaign completed: {reason}")


def _pause(plan: AutomationPlan, reason: str) -> None:
    """Pause the campaign because something outside this lead went wrong."""
    try:
        campaign_ops.set_status(plan.campaign, Campaign.Status.PAUSED,
                                note=reason[:300])
    except campaign_ops.TransitionError:
        return
    events.record(plan.campaign, events.Kind.PAUSED,
                  "Campaign paused automatically", detail=reason)


# --------------------------------------------------------------------------- #
# One pass over everything
# --------------------------------------------------------------------------- #

def run_once(*, owner=None, limit: int = PASS_LIMIT, dry_run: bool = False,
             plan_id: int | None = None, who: str = "") -> list[Report]:
    """One pass over every campaign that might have work.

    The entry point the management command calls. Returns a report per campaign it
    touched, including the ones it decided not to work on -- "nothing happened
    because the window is closed" is the answer somebody is looking for when they
    ask why nothing happened.
    """
    who = who or worker_id()
    reports: list[Report] = []

    query = due_plans(owner)
    if plan_id is not None:
        query = AutomationPlan.objects.filter(pk=plan_id).select_related(
            "campaign", "email_account", "owner")

    for plan in query:
        window = schedule.state(plan)
        if not window.open and not window.finished:
            # Cheap and common: outside its hours. Recorded in the report so the
            # command can say so, but not in the event log -- a campaign with a
            # nine-hour window would otherwise write 900 rows a day saying nothing.
            reports.append(Report(plan_id=plan.pk, campaign=plan.name,
                                 stopped_because=window.reason))
            if not dry_run:
                AutomationPlan.objects.filter(pk=plan.pk).update(
                    next_run_at=window.next_open)
            continue
        reports.append(run_plan(plan, who=who, limit=limit, dry_run=dry_run))

    return reports


def run_forever(*, owner=None, interval: float = 60.0, limit: int = PASS_LIMIT,
                stop=None) -> None:
    """Passes until told otherwise, for a supervised long-running worker.

    `stop` is a callable checked between passes, so a signal handler or a test can
    end the loop at a safe point. There is no sleep inside a pass: a lead that has
    started is finished before anything is allowed to interrupt it.
    """
    while True:
        if stop is not None and stop():
            return
        try:
            run_once(owner=owner, limit=limit)
        except Exception:  # noqa: BLE001 - the worker outlives one bad pass
            log.exception("automation pass failed")
        if stop is not None and stop():
            return
        time.sleep(max(5.0, interval))


# --------------------------------------------------------------------------- #
# Starting and stopping, from the UI
# --------------------------------------------------------------------------- #

def start(plan: AutomationPlan) -> str:
    """Put a configured campaign into the worker's hands. Returns what happened.

    Does no work itself. A campaign becomes ACTIVE (or SCHEDULED, if its window has
    not opened yet) and the worker picks it up on its next pass -- which is the
    honest shape, because the browser is not where the work happens and a page that
    appeared to do it would be lying about what it started.
    """
    window = schedule.state(plan)
    if window.finished:
        raise campaign_ops.TransitionError(
            f"This campaign cannot start: {window.reason}")

    with transaction.atomic():
        wanted = (Campaign.Status.ACTIVE if window.open
                  else Campaign.Status.SCHEDULED)
        campaign_ops.set_status(
            plan.campaign, wanted,
            note=("Started." if window.open else window.reason))
        AutomationPlan.objects.filter(pk=plan.pk).update(
            completion_reason="", next_run_at=window.next_open or timezone.now())
        leads.ensure_searches(plan)

    events.record(
        plan.campaign,
        events.Kind.STARTED if window.open else events.Kind.SCHEDULE,
        f"Campaign {'started' if window.open else 'scheduled'}: {plan.name}",
        detail=schedule.describe(plan))

    if window.open:
        return (f"{plan.name} is running. The worker will begin within a minute, "
                f"and will send up to {plan.daily_target} email(s) today.")
    return f"{plan.name} is scheduled. {window.reason}"
