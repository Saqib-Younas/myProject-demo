"""
Unattended outreach: one configuration, then a worker that keeps going.

The manual workflow is a person driving each step. This package is the same steps
with the person replaced by a schedule and two targets -- and deliberately nothing
else replaced. Every stage a campaign goes through here is the stage the manual
flow already uses: `analyzer` crawls, `ai` audits and writes, `intelligence`
scores, `history` reserves the address, `sender` sends. What is new is only the
deciding: which lead next, whether now is inside the window, whether today's
allowance is used up, and when to stop.

The modules, smallest responsibility first:

  * `schedule` -- timezone-aware window arithmetic. Pure functions over a plan: is
    it open now, when does it next open, has it finished. No database writes.
  * `events` -- the campaign activity log. One row per thing that happened, which
    is what makes an unattended run inspectable afterwards.
  * `leads` -- filling the prospect pool from the public map data, one
    (country, city, category) at a time.
  * `process` -- one lead the whole way through, and the eligibility checks in
    front of it. Never raises for one lead's own problems.
  * `courier` -- the SMTP side: one authenticated session, spaced sends, the
    account's own daily ceiling.
  * `runner` -- the loop that owns all of the above, and the only place that
    decides to stop.

Two rules run through the whole package:

  **The database decides, never a Python variable.** A daily target is enforced by
  a conditional `UPDATE` on a per-day row, a lead is claimed by a conditional
  `UPDATE` on its status, and an address is reserved by an insert against a unique
  constraint. Two workers racing produce one email, and a retried task produces no
  second anything.

  **A follow-up is still a person's decision.** The worker may prepare one; it has
  no path that sends one. That rule predates this package and is not weakened by
  it.
"""

from . import courier, events, leads, process, runner, schedule  # noqa: F401

__all__ = ["courier", "events", "leads", "process", "runner", "schedule"]
