"""
One lead, from the pool to sent -- or to a recorded reason why not.

Two responsibilities, in the order they happen:

**Eligibility.** Every check that can be answered before spending a crawl or an AI
call, each with a sentence saying which one refused. A lead is never dropped
silently: the draft's own status and `error_message` carry the reason, and an event
row puts it on the dashboard. "Why did nothing happen for this business" has to have
an answer, and the answer has to be specific.

**Processing.** Crawl, review, score, write, validate, send. Every step is the
existing manual one -- `runner.crawl_draft`, `runner.review_draft`,
`intelligence.apply`, `runner.generate_draft`, then `courier` -- because an
unattended email must be exactly the email a person would have reviewed. Nothing
here writes prompt text, decides which findings matter, or has an opinion about a
website.

**This module never raises for one lead's own problems.** A site that will not
load, a review that came back empty, a model that refused, an address the provider
rejected: each is recorded against that draft and the campaign moves to the next
lead. The only exceptions that leave here are the ones that mean the *campaign*
cannot continue -- a rate-limited provider, an unusable mailbox -- and those are
raised deliberately, as themselves.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from django.db import IntegrityError, transaction
from django.utils import timezone

from apps import ai
from apps.ai import styles
from apps.auditing import scoring
from apps.outreach.mail import followups
from apps.outreach.models import AutomationPlan, EmailDraft
from apps.outreach.services import followups as followup_service
from apps.outreach.services import history, intelligence
from apps.outreach.services import pipeline as runner

from . import courier as courier_module
from . import events

log = logging.getLogger(__name__)

#: Outcomes, and the vocabulary the day counters use.
SENT = "sent"
SKIPPED = "skipped"
FAILED = "failed"


@dataclass(frozen=True)
class Verdict:
    """Whether a lead may be worked on, and the sentence if not."""

    ok: bool
    reason: str = ""
    #: The draft status that records this refusal, where there is a fitting one.
    status: str = ""


@dataclass(frozen=True)
class Outcome:
    """What happened to one lead."""

    result: str
    reason: str = ""
    draft_id: int | None = None
    #: True when the campaign should stop rather than move to the next lead.
    fatal: bool = False


# --------------------------------------------------------------------------- #
# Eligibility
# --------------------------------------------------------------------------- #

def eligibility(plan: AutomationPlan, draft: EmailDraft, *,
                blocklist=None, index=None) -> Verdict:
    """May this lead be contacted by this campaign?

    Ordered by what it costs to find out. The campaign's own filters and the
    lead's own fields are free; the suppression list and the sending history are one
    query each and are passed in when a run is checking many leads.

    The email address is checked last of the lead's own fields, and not fatally:
    a lead with a website but no listed address is still workable when the campaign
    is allowed to read a contact address from the site -- which is most of them,
    because map records carry phone numbers far more often than emails. The check
    happens again after the crawl, where it becomes final.
    """
    if draft.status not in (EmailDraft.Status.PENDING,
                            EmailDraft.Status.CRAWLED,
                            EmailDraft.Status.ANALYSED,
                            EmailDraft.Status.GENERATED,
                            EmailDraft.Status.APPROVED):
        return Verdict(False, f"Already {draft.get_status_display().lower()}.")

    # What the campaign asked for. A lead that drifted in from an overlapping
    # search of a neighbouring area is not this campaign's to contact.
    if plan.countries and draft.country and not _matches(draft.country,
                                                         plan.countries):
        return Verdict(False,
                       f"{draft.country} is not one of this campaign's countries.",
                       EmailDraft.Status.EXCLUDED)
    if plan.cities and draft.city and not _matches(draft.city, plan.cities):
        return Verdict(False,
                       f"{draft.city} is not one of this campaign's cities.",
                       EmailDraft.Status.EXCLUDED)
    if plan.categories and draft.category and not _matches(draft.category,
                                                           plan.categories):
        return Verdict(False,
                       f"{draft.category} is not one of this campaign's "
                       "categories.", EmailDraft.Status.EXCLUDED)

    if plan.quality != AutomationPlan.Quality.ANY and not draft.website:
        return Verdict(False,
                       "No website, and this campaign only contacts businesses "
                       "that have one.", EmailDraft.Status.EXCLUDED)

    if not draft.email and not (draft.website and plan.discover_emails):
        return Verdict(False, "No email address, and no website to find one on."
                       if not draft.website else
                       "No email address, and this campaign does not read contact "
                       "addresses from websites.", EmailDraft.Status.NO_EMAIL)

    if draft.email:
        blocklist = blocklist or history.SuppressionIndex(plan.owner)
        stop = blocklist.match(email=draft.email, website=draft.website)
        if stop:
            return Verdict(False, stop.sentence(), EmailDraft.Status.SUPPRESSED)

        index = index or history.Index(plan.owner)
        match = index.match(email=draft.email, website=draft.website,
                            business_name=draft.business_name, city=draft.city)
        if match:
            return Verdict(
                False,
                "Already contacted — "
                + history.MATCH_LABELS.get(match.matched_by, match.matched_by)
                + (f" on {match.sent_date}" if match.sent_date else ""),
                EmailDraft.Status.DUPLICATE)

    return Verdict(True)


def _matches(value: str, wanted: list[str]) -> bool:
    """Loose containment, both ways.

    The map data and the user's selection describe the same place in different
    words -- "United States" against "United States of America", "Dallas" against
    "Dallas, Texas" -- so an exact comparison would exclude most of what the
    campaign asked for. Substring either way is imprecise in the harmless
    direction: it lets a near-match through, and the campaign's own searches are
    what put the lead in the pool in the first place.
    """
    subject = (value or "").casefold().strip()
    if not subject:
        return True
    for candidate in wanted:
        other = (candidate or "").casefold().strip()
        if not other:
            continue
        if subject == other or subject in other or other in subject:
            return True
    return False


def refuse(plan: AutomationPlan, draft: EmailDraft, verdict: Verdict) -> Outcome:
    """Record an ineligible lead, on the draft and in the log."""
    if verdict.status:
        EmailDraft.objects.filter(pk=draft.pk).update(
            status=verdict.status, error_message=verdict.reason[:2000],
            processed_at=timezone.now())
    events.record(plan.campaign, events.Kind.SKIPPED,
                  f"Lead skipped: {draft.business_name}",
                  detail=verdict.reason, draft=draft)
    return Outcome(SKIPPED, verdict.reason, draft.pk)


# --------------------------------------------------------------------------- #
# Processing one lead
# --------------------------------------------------------------------------- #

def process(plan: AutomationPlan, draft: EmailDraft,
            courier: courier_module.Courier) -> Outcome:
    """Take one lead the whole way. Returns what happened.

    Raises only `runner.RateLimited`, which is about the provider rather than this
    lead and belongs to the loop that owns the queue.
    """
    campaign = plan.campaign
    events.record(campaign, events.Kind.SELECTED,
                  f"Lead selected: {draft.business_name}",
                  detail=draft.website or draft.email, draft=draft)

    # --- crawl ------------------------------------------------------------- #
    if draft.status == EmailDraft.Status.PENDING:
        try:
            runner.crawl_draft(draft)
        except Exception as exc:  # noqa: BLE001 - one unreachable website
            log.exception("crawl failed for draft %s", draft.pk)
            return _fail(plan, draft, f"Website crawl failed: {exc}")
        draft.refresh_from_db()
        events.record(campaign, events.Kind.CRAWLED,
                      f"Website crawl finished: {len(draft.pages_read or [])} "
                      f"page(s) read",
                      detail=draft.analysis_note, draft=draft)

    # An address published on the business's own site, where the map had none.
    # Only ever from the pages actually fetched -- never guessed, never
    # constructed from the domain.
    if not draft.email and plan.discover_emails:
        found = _discovered_email(draft)
        if found:
            try:
                # Per-campaign uniqueness is a constraint, not a hope: two
                # businesses can publish the same address -- a franchise pair, or
                # one company with two map pins -- and the second one is a
                # duplicate rather than a reason to stop.
                with transaction.atomic():
                    EmailDraft.objects.filter(pk=draft.pk).update(email=found)
            except IntegrityError:
                return refuse(plan, draft, Verdict(
                    False,
                    f"{found} is already in this campaign under another business.",
                    EmailDraft.Status.DUPLICATE))
            draft.refresh_from_db()
            events.record(campaign, events.Kind.CRAWLED,
                          f"Contact address found on the website: {found}",
                          draft=draft)

    if not draft.email:
        return refuse(plan, draft, Verdict(
            False, "No contact address is published on the website.",
            EmailDraft.Status.NO_EMAIL))

    # The checks that could not run before the address was known.
    verdict = eligibility(plan, draft)
    if not verdict.ok:
        return refuse(plan, draft, verdict)

    # --- review ------------------------------------------------------------ #
    if draft.status in (EmailDraft.Status.PENDING, EmailDraft.Status.CRAWLED):
        try:
            runner.review_draft(draft, retries=1, pause_on_limit=True)
        except runner.RateLimited:
            raise
        except Exception as exc:  # noqa: BLE001
            log.exception("review failed for draft %s", draft.pk)
            return _fail(plan, draft, f"Website review failed: {exc}")
        draft.refresh_from_db()
        events.record(campaign, events.Kind.FINDINGS,
                      f"{len(draft.findings or [])} finding(s) identified",
                      detail=_finding_summary(draft), draft=draft)

    # --- score ------------------------------------------------------------- #
    try:
        intelligence.apply(draft)
        draft.refresh_from_db()
    except Exception:  # noqa: BLE001 - scoring must not lose the crawl
        log.exception("could not score draft %s", draft.pk)

    # --- write ------------------------------------------------------------- #
    if draft.status != EmailDraft.Status.GENERATED:
        try:
            written = runner.generate_draft(
                draft, campaign, retries=1, pause_on_limit=True,
                style=styles.style(plan.template_key))
        except runner.RateLimited:
            raise
        except Exception as exc:  # noqa: BLE001
            log.exception("generation failed for draft %s", draft.pk)
            return _fail(plan, draft, f"Email generation failed: {exc}")
        draft.refresh_from_db()
        if not written:
            return _fail(plan, draft,
                         draft.error_message or "No email could be written.")
        events.record(campaign, events.Kind.GENERATED,
                      f"Email written: {draft.subject}",
                      detail=draft.observation, draft=draft)
        try:
            intelligence.apply(draft)
            draft.refresh_from_db()
        except Exception:  # noqa: BLE001
            log.exception("could not re-score draft %s", draft.pk)

    EmailDraft.objects.filter(pk=draft.pk).update(processed_at=timezone.now())

    # --- validate ---------------------------------------------------------- #
    problem = validate(draft, plan)
    if problem:
        # Not a failure of the machinery: a draft that does not meet the rules is
        # held for a person rather than sent. It stays visible in the workspace,
        # where it can be edited and approved by hand.
        EmailDraft.objects.filter(pk=draft.pk).update(
            status=EmailDraft.Status.GENERATED,
            error_message=f"Held for review: {problem}"[:2000])
        events.record(campaign, events.Kind.SKIPPED,
                      f"Not sent, held for review: {draft.business_name}",
                      detail=problem, draft=draft)
        return Outcome(SKIPPED, problem, draft.pk)

    # --- send -------------------------------------------------------------- #
    EmailDraft.objects.filter(
        pk=draft.pk, status=EmailDraft.Status.GENERATED,
    ).update(status=EmailDraft.Status.APPROVED)
    draft.refresh_from_db()

    result = courier.send(draft)
    if result.sent:
        events.record(campaign, events.Kind.SENT,
                      f"Email sent to {draft.email}",
                      detail=draft.subject, draft=draft)
        return Outcome(SENT, draft_id=draft.pk)

    kind = events.Kind.FAILED if result.fatal else events.Kind.SKIPPED
    events.record(campaign, kind,
                  f"Not sent: {draft.business_name}",
                  detail=result.reason, draft=draft)
    return Outcome(FAILED if result.fatal else SKIPPED, result.reason, draft.pk,
                   fatal=result.fatal)


def validate(draft: EmailDraft, plan: AutomationPlan) -> str:
    """"" if this draft may be sent unattended, otherwise what is wrong with it.

    The last gate before an email reaches a stranger with nobody having read it. The
    generation step already retries a draft that breaks the writing rules; this
    decides what to do when it still does, and the answer is to hold it rather than
    send it. An email nobody would have approved should not go out because a worker
    was running instead of a person.
    """
    if not draft.email:
        return "No recipient address."
    if not draft.subject.strip():
        return "No subject line."
    if not draft.body.strip():
        return "No body."

    style = styles.style(plan.template_key)
    shortlist = scoring.rank_for_email(draft.finding_objects,
                                       limit=style.max_findings)

    # The evidence rule, at the last possible moment: an email that claims a
    # website problem must be traceable to a finding the crawl actually produced.
    written = ai.GeneratedEmail(draft.subject, draft.body, draft.observation,
                                list(draft.findings_used or []))
    problem = ai.draft_problem(written, shortlist, style, draft.business_name)
    if problem:
        return problem
    return ""


def _fail(plan: AutomationPlan, draft: EmailDraft, reason: str) -> Outcome:
    """Record a lead the machinery could not get through."""
    EmailDraft.objects.filter(pk=draft.pk).update(
        status=EmailDraft.Status.FAILED, error_message=reason[:2000],
        processed_at=timezone.now())
    events.record(plan.campaign, events.Kind.FAILED,
                  f"Lead failed: {draft.business_name}", detail=reason,
                  draft=draft)
    return Outcome(FAILED, reason, draft.pk)


def _finding_summary(draft: EmailDraft) -> str:
    """The first couple of findings, for the event detail line."""
    findings = [f.get("issue", "") for f in (draft.findings or [])][:2]
    return "; ".join(part for part in findings if part)


#: Preferred over a named individual's mailbox: a business publishes these for
#: exactly this purpose, and a stranger writing to `sarah@` has picked a person.
ROLE_ADDRESSES = ("info", "contact", "hello", "enquiries", "inquiries",
                  "office", "admin", "sales", "mail", "team", "support")


def _discovered_email(draft: EmailDraft) -> str:
    """A contact address the crawl found published on the site.

    Read from `discovered_emails`, which `crawl_draft` filled from the `mailto:`
    links on the pages it actually fetched. Nothing is constructed here: no
    info@domain guess, no pattern applied to a person's name. A business that
    published no address is skipped, which is the correct outcome -- an address we
    invented is not a contact detail.
    """
    candidates = [
        str(address).strip() for address in (draft.discovered_emails or [])
        if "@" in str(address)
    ]
    for candidate in candidates:
        if candidate.split("@")[0].lower() in ROLE_ADDRESSES:
            return candidate
    return candidates[0] if candidates else ""


# --------------------------------------------------------------------------- #
# Follow-ups: prepared, never sent
# --------------------------------------------------------------------------- #

def prepare_followups(plan: AutomationPlan, limit: int = 10) -> int:
    """Draft the follow-ups that have come due for this campaign.

    The rule this respects is older than automation and is not weakened by it: a
    follow-up is prepared by machine and sent by a person. There is no path from
    here to SMTP -- the drafts are marked ready and wait on the Follow-ups screen
    for somebody to press Send.

    Calls the same service the cron job calls, so there is one implementation of "what
    is due and what may be prepared" rather than two that drift. It used to reach that
    implementation by instantiating the management command; the service moved out of the
    command precisely because of this call.
    """
    if not plan.followups_enabled:
        return 0

    prepared = 0
    blocklist = followups.blocklist_for(plan.owner)

    leads = [
        lead for lead in plan.campaign.sent_leads.all()[:limit * 4]
        if followups.eligibility(lead, blocklist=blocklist).eligible
    ][:limit]

    for lead in leads:
        try:
            if (followup_service.prepare_one(plan.owner, lead).result
                    == "prepared"):
                prepared += 1
                events.record(
                    plan.campaign, events.Kind.FOLLOWUP,
                    f"Follow-up prepared for {lead.business_name} — waiting for "
                    "your approval",
                    detail="Nothing is sent until you press Send follow-up.")
        except Exception:  # noqa: BLE001 - one lead, not the campaign
            log.exception("could not prepare a follow-up for lead %s", lead.pk)
    return prepared
