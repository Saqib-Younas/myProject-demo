"""
Background jobs: analyse-then-generate, and the bulk send.

Both run in a daemon thread so the page can poll progress while they work. The
drafts table is the single source of truth for progress -- the browser polls
counts computed from it, which means a reload mid-run shows the real state and a
server restart cannot leave the UI claiming work is still happening.

One job per campaign at a time, enforced by `_running`.

Two things can stop a run before it reaches the end of the queue, and both are
normal rather than failures:

  * **the AI provider says no** -- a rate limit or a spent allowance. The run
    parks itself, records where it got to and why, and either waits out a short
    window or stops until the user acts. It never keeps firing requests at a
    provider that has just refused one.
  * **the user presses Cancel** -- checked before every lead and before every
    page fetch, so nothing new is started once it has been asked for.

Cancellation wins. A job asleep until a retry window wakes, sees the request, and
stops instead of resuming. Neither path ever re-does a lead that already finished:
the completion stamp is the record, and both paths leave it alone.
"""

from __future__ import annotations

import logging
import threading
import time
from datetime import timedelta

from django.db import connections, models, transaction
from django.utils import timezone

from apps import ai
from apps.ai import context as aicontext
from apps.auditing import crawler
from apps.outreach.mail import accounts as mailaccounts
from apps.outreach.mail import compose, followups, providers, transport
from apps.outreach.models import Campaign, EmailDraft
from apps.outreach.services import history, intelligence

log = logging.getLogger(__name__)

_lock = threading.Lock()
_running: set[str] = set()

#: How long to wait before a second attempt at a transient AI failure. Applies to
#: dropped connections and truncated replies -- a rate limit is handled by pausing
#: the whole run instead, because retrying it per lead is exactly the hammering
#: this must not do. Tests set this to 0.
AI_RETRY_DELAY = 20.0

#: Phases that mean "a background job should be running right now".
WORKING_PHASES = (Campaign.Phase.CRAWLING, Campaign.Phase.ANALYSING,
                  Campaign.Phase.GENERATING)

#: The longest a paused job will hold its worker thread waiting for a retry
#: window. Beyond this it records the pause and exits: a thread asleep for an
#: hour survives no restart and tells the user nothing a stored timestamp does
#: not. The workspace resumes it when the window opens, and "Resume now" is
#: always there.
MAX_INLINE_WAIT = 300.0

#: Backoff for providers that do not say how long to wait: 30s, 60s, 120s, 240s,
#: capped. Used only as a fallback -- `Retry-After` wins whenever it is given,
#: because the provider knows and this does not.
BACKOFF_BASE = 30.0
BACKOFF_CAP = 900.0

#: How often a waiting job looks up to see whether Cancel was pressed. One second
#: is responsive enough to feel immediate and cheap enough to ignore.
WAIT_TICK = 1.0

#: How many times one run will park and try again before it stays parked.
#:
#: Without a cap, a provider that refuses every attempt produces park -> wait ->
#: retry -> refuse without end, re-crawling the same website each time round --
#: which is the repeated retrying this is all meant to avoid, reached by a longer
#: route. After this many, the run stays PAUSED_RATE_LIMIT and waits for a person:
#: five refusals spread over an escalating backoff is no longer a burst, it is a
#: limit that needs a different key or a smaller list.
MAX_PAUSES = 5


class Cancelled(Exception):
    """The user pressed Cancel. Raised inside a lead, caught by the loop."""


class RateLimited(Exception):
    """The provider refused on grounds of allowance, not correctness.

    Deliberately not an `AiError`: the per-lead handlers catch `AiError` and
    record it on the draft, which is right for "this website broke the model" and
    wrong for "the provider is rate limiting everything". This one has to reach
    the loop that owns the queue.
    """

    def __init__(self, error):
        super().__init__(str(error))
        self.error = error
        self.category = getattr(error, "category", "") or "rate_limit"
        self.retry_after = getattr(error, "retry_after", None)
        self.quota = bool(getattr(error, "quota_exhausted", False))


def is_running(campaign_id) -> bool:
    with _lock:
        return str(campaign_id) in _running


def stalled(campaign: Campaign) -> str:
    """"pipeline", "send" or "" -- work that claims to be running but is not.

    `_running` lives in this process, so a server restart mid-campaign leaves the
    phase saying `crawling` with no thread behind it. Without this the campaign
    is stuck: the UI waits forever for progress that will never arrive.
    """
    if is_running(campaign.id):
        return ""
    if campaign.phase in WORKING_PHASES:
        return "pipeline"
    if campaign.phase == Campaign.Phase.SENDING:
        return "send"
    return ""


def _call_ai(func, *, retries: int = 0, pause_on_limit: bool = False):
    """Call an AI function, retrying a transient failure.

    Only errors the backend marked `retryable` are retried. A missing API key or
    an oversized context fails the same way every time, and retrying it once per
    lead would add minutes to a run to reach the same conclusion.

    `pause_on_limit` changes what happens to a rate limit, and only to a rate
    limit: instead of sleeping and trying the same request again, it is raised as
    `RateLimited` for the run to park on. Retrying inside the lead is precisely
    the "keep sending requests at a provider that just refused one" the brief
    rules out -- and 25 leads each retrying once is 25 more refused requests.
    Interactive callers leave it off and get the error to show the user.
    """
    attempt = 0
    while True:
        try:
            return func()
        except ai.AiError as exc:
            if pause_on_limit and getattr(exc, "rate_limited", False):
                raise RateLimited(exc) from exc
            if attempt >= retries or not getattr(exc, "retryable", False):
                raise
            attempt += 1
            log.info("transient AI failure (%s) -- retrying in %ss",
                     exc, AI_RETRY_DELAY)
            if AI_RETRY_DELAY:
                time.sleep(AI_RETRY_DELAY)


# --------------------------------------------------------------------------- #
# Run control: cancelling, and parking on a rate limit
# --------------------------------------------------------------------------- #

def _phase_of(campaign: Campaign) -> str:
    """This campaign's phase as the database has it right now.

    Read fresh every time rather than from the in-memory object: Cancel arrives
    on a different thread through an HTTP request, so the worker's own copy is
    exactly the thing that cannot be trusted here.
    """
    return (Campaign.objects.filter(pk=campaign.pk)
            .values_list("phase", flat=True).first() or "")


def cancel_requested(campaign: Campaign) -> bool:
    """Has Cancel been pressed (or already applied)?"""
    return _phase_of(campaign) in (Campaign.Phase.CANCEL_REQUESTED,
                                   Campaign.Phase.CANCELLED)


def _check_cancel(campaign: Campaign) -> None:
    if cancel_requested(campaign):
        raise Cancelled()


def mark_cancelled(campaign: Campaign) -> None:
    """Settle the run as CANCELLED. Idempotent, and it finalises nothing else.

    Every lead that finished keeps its completion stamp, so a later resume picks
    up from the first unfinished one and pays for nothing twice.
    """
    Campaign.objects.filter(pk=campaign.pk).update(
        phase=Campaign.Phase.CANCELLED,
        cancelled_at=timezone.now(),
        current_step="",
        pause_reason="", pause_detail="", retry_at=None,
        error="",
    )
    log.info("campaign %s cancelled by the user", campaign.pk)


def _backoff(pause_count: int) -> float:
    """30s, 60s, 120s, 240s ... capped. The fallback when nobody said how long."""
    return min(BACKOFF_CAP, BACKOFF_BASE * (2 ** max(0, pause_count)))


def _pause_delay(campaign: Campaign, limit: RateLimited) -> float:
    """How long to wait, honouring the provider's own answer first."""
    if limit.retry_after and limit.retry_after > 0:
        # A provider that says "8.5s" knows; a formula does not. One second is
        # added because a wait that ends a moment too early buys another refusal.
        return min(BACKOFF_CAP, float(limit.retry_after) + 1.0)
    return _backoff(campaign.pause_count)


def _park(campaign: Campaign, limit: RateLimited) -> tuple[float, bool]:
    """Record the pause. Returns (delay, parked).

    Written to the database before anything waits, so the page shows
    "Paused -- AI rate limit" and a countdown immediately, and so a restart
    mid-wait leaves a run that can still be resumed rather than one that looks
    like it is working.

    `parked` is False when a cancel arrived while the refused request was in
    flight. The update excludes the stopping phases for exactly that case: writing
    "paused" over "cancelling" would lose the press, and the wait that followed
    would look at the phase it had just written and decide to carry on.
    """
    delay = _pause_delay(campaign, limit)
    reason = Campaign.Pause.QUOTA if limit.quota else Campaign.Pause.RATE_LIMIT
    retry_at = timezone.now() + timedelta(seconds=delay)

    updated = Campaign.objects.filter(pk=campaign.pk).exclude(
        phase__in=(Campaign.Phase.CANCEL_REQUESTED, Campaign.Phase.CANCELLED),
    ).update(
        phase=Campaign.Phase.PAUSED_RATE_LIMIT,
        pause_reason=reason,
        pause_detail=str(limit.error)[:300],
        retry_at=None if limit.quota else retry_at,
        pause_count=models.F("pause_count") + 1,
        current_step="",
    )
    if not updated:
        return delay, False

    campaign.refresh_from_db(fields=["pause_count"])
    log.info("campaign %s paused (%s) for %.0fs", campaign.pk, reason, delay)
    return delay, True


def _hold(campaign: Campaign, limit: RateLimited) -> bool:
    """Park on a rate limit. True if the run may carry on from the same lead.

    False means the worker should exit -- either the user cancelled, or this is
    not a wait worth holding a thread for:

      * a **quota** is not waitable at all. Sleeping for a daily reset would
        occupy a thread for hours to no purpose, so the run stops and the message
        tells the user to wait for the reset or switch provider.
      * a **long** window (over MAX_INLINE_WAIT) is recorded and left to the
        workspace or to "Resume now".
      * a run that has already parked MAX_PAUSES times stays parked. Five
        refusals across an escalating backoff is not a burst.

    A short window is waited out here, in one-second slices, checking Cancel on
    every one. That is what makes cancellation take precedence over the retry.
    """
    # Cancellation first. A press that landed while the refused request was in
    # flight must not be overwritten by the pause that follows it.
    if cancel_requested(campaign):
        mark_cancelled(campaign)
        return False

    delay, parked = _park(campaign, limit)
    if not parked:
        # A cancel arrived between the check above and the write.
        mark_cancelled(campaign)
        return False

    if limit.quota or delay > MAX_INLINE_WAIT:
        return False

    if campaign.pause_count >= MAX_PAUSES:
        Campaign.objects.filter(pk=campaign.pk).update(
            pause_detail=(
                f"Paused after {campaign.pause_count} rate limits in this run. "
                "Waiting again would only ask the same question -- try a "
                "different credential or a smaller list, then resume."
            )[:300],
        )
        log.info("campaign %s stays paused after %s rate limits",
                 campaign.pk, campaign.pause_count)
        return False

    deadline = time.monotonic() + delay
    while time.monotonic() < deadline:
        if cancel_requested(campaign):
            mark_cancelled(campaign)
            return False
        time.sleep(min(WAIT_TICK, max(0.0, deadline - time.monotonic())))

    if cancel_requested(campaign):
        mark_cancelled(campaign)
        return False

    # Back to work, on the same lead the limit interrupted.
    Campaign.objects.filter(pk=campaign.pk).update(
        phase=Campaign.Phase.CRAWLING, pause_reason="", pause_detail="",
        retry_at=None)
    log.info("campaign %s resuming after a rate limit", campaign.pk)
    return True


def _claim(campaign_id) -> bool:
    with _lock:
        key = str(campaign_id)
        if key in _running:
            return False
        _running.add(key)
        return True


def _release(campaign_id) -> None:
    with _lock:
        _running.discard(str(campaign_id))


def _spawn(target, campaign, *args) -> bool:
    """Start a background job unless one is already running for this campaign."""
    if not _claim(campaign.id):
        return False

    def wrapper():
        # A thread does not inherit the request's context, so the campaign's owner
        # is bound here. Without it, every AI call in this job would resolve
        # credentials with no account in context and fall back to `.env`.
        try:
            with aicontext.acting_as(campaign.owner):
                target(campaign, *args)
        except Exception:  # noqa: BLE001 - a crashed thread must not vanish
            log.exception("outreach job failed for campaign %s", campaign.id)
            Campaign.objects.filter(pk=campaign.pk).update(
                phase=Campaign.Phase.FAILED,
                error="The background job crashed. Check the server log.",
            )
        finally:
            _release(campaign.id)
            connections.close_all()  # do not leak this thread's DB connection

    threading.Thread(target=wrapper, daemon=True).start()
    return True


# --------------------------------------------------------------------------- #
# Analyse -> generate
# --------------------------------------------------------------------------- #

def start_pipeline(campaign: Campaign, *, resume: bool = False) -> bool:
    return _spawn(_pipeline, campaign, resume)


def _queue_for(campaign: Campaign, resume: bool) -> list[EmailDraft]:
    """The leads this run has to work through, in order.

    A fresh run takes every queued lead and stamps the running order. A resumed
    run keeps the order it already had and takes only what is unfinished, so the
    leads already paid for are not crawled or drafted a second time.
    """
    if not resume:
        queue = list(campaign.drafts.filter(status=EmailDraft.Status.PENDING))
        for position, draft in enumerate(queue, start=1):
            draft.sequence = position
            draft.processed_at = None
            draft.save(update_fields=["sequence", "processed_at"])
        return queue

    unfinished = (EmailDraft.Status.PENDING, EmailDraft.Status.CRAWLED,
                  EmailDraft.Status.ANALYSED, EmailDraft.Status.GENERATED)
    resumed = list(
        campaign.drafts.filter(sequence__gt=0, processed_at__isnull=True,
                               status__in=unfinished).order_by("sequence")
    )
    # A lead unblocked by "Contact anyway" after the run finished has no place in
    # the order yet; give it one at the end so it is processed like any other.
    highest = max((d.sequence for d in campaign.drafts.all()), default=0)
    for draft in campaign.drafts.filter(sequence=0,
                                        status=EmailDraft.Status.PENDING):
        highest += 1
        draft.sequence = highest
        draft.processed_at = None
        draft.save(update_fields=["sequence", "processed_at"])
        resumed.append(draft)
    return resumed


def _pipeline(campaign: Campaign, resume: bool = False) -> None:
    """Work through the selected leads one at a time, start to finish.

    One lead is taken all the way -- crawl its site, review it for issues, write
    its email, save the result -- before the next lead is touched. Nothing is
    batched by stage. That is deliberate on three counts:

    * the findings and the email for a company appear together, as soon as that
      company is done, instead of every card sitting empty until the last crawl
      finishes;
    * a lead that fails costs only itself, and the run carries on;
    * `current_draft` and `current_step` always name one lead and one step, so
      the progress panel can say exactly which website is being read right now.
    """
    queue = _queue_for(campaign, resume)

    Campaign.objects.filter(pk=campaign.pk).update(
        phase=Campaign.Phase.CRAWLING, error="",
        current_draft=None, current_step="",
        pause_reason="", pause_detail="", retry_at=None, cancelled_at=None)

    campaign.refresh_from_db()  # pick up the sender settings the view just saved

    failures = 0
    attempted = 0
    # An index rather than a for-loop, because a rate limit has to be able to
    # come back to the *same* lead once the window passes rather than skip it.
    position = 0
    while position < len(queue):
        draft = queue[position]

        # Before each lead, per the brief. A cancel that arrived while the
        # previous lead was being written stops the run here, and nothing new
        # is started.
        if cancel_requested(campaign):
            mark_cancelled(campaign)
            return

        try:
            attempted += 1
            if not process_draft(draft, campaign, resume=resume):
                failures += 1
        except Cancelled:
            # Raised from inside the lead: its partial work is discarded or kept
            # by the step that owned it, and no completion stamp was written, so
            # a resume will pick this lead up again.
            mark_cancelled(campaign)
            return
        except RateLimited as limit:
            attempted -= 1          # this lead has not had its turn yet
            if not _hold(campaign, limit):
                return              # cancelled, or parked for the user to resume
            continue                # window passed: the same lead, again
        position += 1

    error = ""
    if failures and attempted and failures == attempted:
        # Every single one failed -- almost always a missing API key.
        first = campaign.drafts.exclude(error_message="").first()
        error = first.error_message if first else "Email generation failed."

    Campaign.objects.filter(pk=campaign.pk).update(
        phase=Campaign.Phase.REVIEW, error=error,
        current_draft=None, current_step="",
        pause_reason="", pause_detail="", retry_at=None)


def _step(campaign: Campaign, draft: EmailDraft, step: str,
          phase: str = "") -> None:
    """Publish which lead and which step are in flight."""
    fields = {"current_draft": draft, "current_step": step}
    if phase:
        fields["phase"] = phase
    Campaign.objects.filter(pk=campaign.pk).update(**fields)


def process_draft(draft: EmailDraft, campaign: Campaign, *,
                  resume: bool = False) -> bool:
    """One lead, the whole way through. Returns False if no email was written.

    Never raises for this lead's own problems: an unreachable website, a review
    that came back empty and a refused AI call are all recorded on the draft and
    the run moves on to the next lead. One bad website must not end a campaign.

    On a resumed run the lead's own status says which steps it already got
    through, so an interrupted campaign does not re-crawl or re-draft work that
    was already paid for. The status is set by each step as it completes, which
    makes it the record of where the lead stopped.
    """
    done = draft.status if resume else EmailDraft.Status.PENDING

    if done == EmailDraft.Status.PENDING:
        _step(campaign, draft, "crawl", Campaign.Phase.CRAWLING)
        # The crawl is the one long step that can be interrupted part-way, so it
        # is handed the cancellation check rather than only being wrapped by it.
        if not crawl_draft(draft, should_stop=lambda: cancel_requested(campaign)):
            raise Cancelled()

    # Between steps: an AI call that has not started need never start.
    _check_cancel(campaign)

    if done in (EmailDraft.Status.PENDING, EmailDraft.Status.CRAWLED):
        _step(campaign, draft, "review", Campaign.Phase.ANALYSING)
        review_draft(draft, retries=1, pause_on_limit=True)

    # Classified and scored before the email is written, because *which* email to
    # write depends on the classification: a business with no verified website
    # gets a completely different approach from one with a site full of problems.
    # Arithmetic over what was just measured -- no crawling, no AI call.
    _step(campaign, draft, "score")
    try:
        draft.refresh_from_db()
        intelligence.apply(draft)
    except Exception:  # noqa: BLE001 - scoring must not lose the crawl
        log.exception("could not score draft %s", draft.pk)

    if done == EmailDraft.Status.GENERATED:
        # Only the completion stamp was missing -- the email is already written.
        written = bool(draft.subject)
    else:
        _check_cancel(campaign)
        _step(campaign, draft, "generate", Campaign.Phase.GENERATING)
        draft.refresh_from_db()
        written = generate_draft(draft, campaign, retries=1, pause_on_limit=True)
        # Re-score once the email exists: readiness counts the observation, and
        # the lifecycle moves to "email ready" only once there is an email.
        try:
            draft.refresh_from_db()
            intelligence.apply(draft)
        except Exception:  # noqa: BLE001
            log.exception("could not re-score draft %s", draft.pk)

    # Saved: everything this lead produced is already committed, so the stamp is
    # the last thing to happen and is what marks the lead complete.
    _step(campaign, draft, "save")
    EmailDraft.objects.filter(pk=draft.pk).update(processed_at=timezone.now())
    return written


def crawl_draft(draft: EmailDraft, should_stop=None) -> bool:
    """Discover and read one lead's website. Never fails the pipeline.

    False means the crawl was cancelled part-way and **nothing was saved**. A
    half-read site stored as though it were the whole site would be analysed on
    fewer pages than it deserved, and the draft would then be skipped as
    "already crawled" on the resume -- paying for the cancellation twice. Leaving
    the lead untouched costs only the fetches already made.
    """
    result = crawler.analyse(draft.website, should_stop=should_stop)
    if result.stopped:
        return False

    draft.analysis_status = result.status
    draft.analysis_note = result.summary()[:400]
    draft.analysis_context = result.as_context()
    # The measured facts travel with the page they were measured on. Kept
    # rather than left inside `analysis_context`, because the scoring step and
    # the email step both need them as data, not as formatted prose.
    draft.pages_read = [
        {"url": p.url, "kind": p.kind, "facts": dict(p.facts or {})}
        for p in result.pages
    ]
    draft.pages_discovered = result.discovered
    # Addresses the site publishes for contact. Recorded whether or not this lead
    # needs one: it costs a column, and re-reading a website to find an address we
    # already saw costs a crawl.
    draft.discovered_emails = list(result.emails_found or [])
    draft.status = EmailDraft.Status.CRAWLED
    draft.save(update_fields=[
        "analysis_status", "analysis_note", "analysis_context", "pages_read",
        "pages_discovered", "discovered_emails", "status",
    ])
    return True


def review_draft(draft: EmailDraft, *, retries: int = 0,
                 pause_on_limit: bool = False) -> bool:
    """Turn crawled pages into evidence-backed findings.

    A site that could not be crawled is not an error -- it moves straight to the
    email stage with no findings, and the email is written without implying the
    website was seen.
    """
    if not draft.analysis_context:
        draft.findings = []
        draft.status = EmailDraft.Status.ANALYSED
        draft.save(update_fields=["findings", "status"])
        return True

    try:
        result = _call_ai(lambda: ai.audit(
            business_name=draft.business_name,
            category=draft.category,
            city=draft.city,
            country=draft.country,
            website=draft.website,
            site_context=draft.analysis_context,
            pages_read=len(draft.pages_read or []),
            discovered=draft.pages_discovered,
        ), retries=retries, pause_on_limit=pause_on_limit)
    except ai.AiError as exc:
        # Record the reason, but let the email stage proceed without findings
        # rather than dropping the lead entirely.
        draft.findings = []
        draft.error_message = f"Website review failed: {exc}"
        draft.status = EmailDraft.Status.ANALYSED
        draft.save(update_fields=["findings", "error_message", "status"])
        return False

    draft.business_summary = result.business_summary
    draft.findings = [f.as_dict() for f in result.findings]
    draft.status = EmailDraft.Status.ANALYSED
    draft.error_message = ""
    draft.save(update_fields=[
        "business_summary", "findings", "status", "error_message",
    ])
    return True


def generate_draft(draft: EmailDraft, campaign: Campaign,
                   retry_hint: str = "", *, retries: int = 0,
                   pause_on_limit: bool = False, style=None) -> bool:
    """Write one email from the findings. False and records the error on failure.

    `retries` is 1 from the pipeline and 0 from the interactive Regenerate
    button: a background run should ride out a dropped connection, but a user
    waiting on a click should get the error rather than an unexplained pause.

    `pause_on_limit` is set only by the pipeline, and turns a provider rate limit
    into `RateLimited` for the run to park on rather than an error recorded
    against this one lead.

    `style` is the approved template the campaign chose -- it sets the length asked
    for and how many findings the shape can carry, and nothing else. None means the
    default, which is what every manual campaign uses.
    """
    from apps.ai import styles
    from apps.auditing import scoring

    chosen = style or styles.DEFAULT_STYLE

    if draft.classification == scoring.NO_WEBSITE_OPPORTUNITY:
        return _generate_no_website(draft, campaign, retry_hint, retries=retries,
                                    pause_on_limit=pause_on_limit)

    # The shortlist, not the whole audit. Ten findings in a prompt produce an
    # email that mentions three of them badly; the ranking picks the ones that
    # matter commercially and the prompt is built on those. One decision, made
    # in `scoring`, where it can be read and tested.
    shortlist = scoring.rank_for_email(draft.finding_objects,
                                       limit=chosen.max_findings)
    pages = list(draft.pages_read or [])

    # This lead's own measurements first -- they are its own evidence. A shared
    # audit fills in for a lead whose own crawl came back empty, which is the
    # same precedence the scoring step uses.
    signals = draft.measured_signals
    if not signals or not pages:
        audit = intelligence.cached_audit(campaign.owner, draft.website)
        if audit is not None:
            signals = signals or (audit.signals or {})
            pages = pages or list(audit.pages or [])

    # What may honestly be said about the platform. KEEP is the usual answer and
    # means the email says nothing about technology at all.
    advice = scoring.platform_advice(signals)
    platform_note = advice["summary"] if advice["say"] else ""

    # A fix that recommends a rebuild the crawl cannot support stays in the audit,
    # where the operator can see and judge it, but does not reach the email. The
    # internal analysis may be opinionated; the client email may not.
    for finding in shortlist:
        problem = scoring.unsupported_replatform(finding, advice)
        if problem:
            log.info("draft %s: a fix %s -- withheld from the email",
                     draft.pk, problem)
            finding.suggested_improvement = (
                "Improve this where the site already is; no platform change is "
                "needed."
            )

    def write(hint: str):
        return _call_ai(lambda: ai.generate(
            business_name=draft.business_name,
            category=draft.category,
            city=draft.city,
            country=draft.country,
            website=draft.website,
            sender_name=campaign.sender_name,
            sender_company=campaign.sender_company,
            sender_email=campaign.sender_email,
            service_pitch=campaign.service_pitch,
            findings=shortlist,
            business_summary=draft.business_summary,
            site_note=draft.analysis_note or "website not read",
            retry_hint=hint,
            pages=pages,
            signals=signals,
            platform_note=platform_note,
            style=chosen,
        ), retries=retries, pause_on_limit=pause_on_limit)

    try:
        email = write(retry_hint)

        # Two failures this pipeline exists to prevent: "I noticed some issues
        # with your website", which says nothing that required looking, and the
        # corporate register that makes a one-to-one email read as mass-sent.
        # Both are checked rather than hoped for, and both are reported in one
        # note -- so a draft with both problems costs one more AI call, not two.
        problem = ai.draft_problem(email, shortlist, chosen,
                                   draft.business_name)
        if problem:
            log.info("draft %s needs a rewrite (%s)", draft.pk, problem)
            combined = f"{retry_hint} {problem}".strip() if retry_hint else problem
            email = write(combined)
            problem = ai.draft_problem(email, shortlist, chosen,
                                       draft.business_name)
            if problem:
                # Recorded on the draft rather than discarded: the email may
                # still be usable, and a person is going to read it before it is
                # sent. Saying so beats silently approving a vague draft.
                log.warning("draft %s still reads poorly: %s", draft.pk, problem)
    except ai.AiError as exc:
        draft.error_message = str(exc)
        draft.save(update_fields=["error_message"])
        return False

    draft.subject = email.subject[:400]
    draft.body = email.body
    draft.observation = email.observation[:600]
    draft.findings_used = email.findings_used
    draft.status = EmailDraft.Status.GENERATED
    draft.edited = False
    draft.error_message = ""
    draft.save(update_fields=[
        "subject", "body", "observation", "findings_used", "status", "edited",
        "error_message",
    ])
    return True


def _generate_no_website(draft: EmailDraft, campaign: Campaign,
                        retry_hint: str = "", *, retries: int = 0,
                        pause_on_limit: bool = False) -> bool:
    """Workflow B: an email to a business with no verified website.

    Kept separate from the website path rather than branching inside it. The two
    emails share no material -- one is built on measured findings, the other on
    what a website could make easier -- and a single function with an `if` in the
    middle is how the wrong one eventually gets sent.
    """
    try:
        email = _call_ai(lambda: ai.no_website_email(
            business_name=draft.business_name,
            category=draft.category,
            city=draft.city,
            country=draft.country,
            phone=draft.phone,
            benefits=draft.benefits or [],
            sender_name=campaign.sender_name,
            sender_company=campaign.sender_company,
            sender_email=campaign.sender_email,
            service_pitch=campaign.service_pitch,
            retry_hint=retry_hint,
        ), retries=retries, pause_on_limit=pause_on_limit)
    except ai.AiError as exc:
        draft.error_message = str(exc)
        draft.save(update_fields=["error_message"])
        return False

    draft.subject = email.subject[:400]
    draft.body = email.body
    draft.observation = email.observation[:600]
    draft.findings_used = email.findings_used
    draft.status = EmailDraft.Status.GENERATED
    draft.edited = False
    draft.error_message = ""
    draft.save(update_fields=[
        "subject", "body", "observation", "findings_used", "status", "edited",
        "error_message",
    ])
    return True


# --------------------------------------------------------------------------- #
# Bulk send
# --------------------------------------------------------------------------- #

def start_send(campaign: Campaign, password: str, *, host: str = "",
               port: int = 0) -> bool:
    return _spawn(_send_all, campaign, password, host, port)


def sent_today(sender_email: str) -> int:
    """How many messages this address has sent today, across all campaigns."""
    start = timezone.localtime().replace(hour=0, minute=0, second=0, microsecond=0)
    return EmailDraft.objects.filter(
        campaign__sender_email__iexact=sender_email,
        status=EmailDraft.Status.SENT,
        sent_at__gte=start,
    ).count()


def _claim_draft(draft_id: int) -> bool:
    """Move one draft approved -> sending, atomically.

    The conditional UPDATE is what stops a second Send click, a double-submit,
    or two threads from sending the same email twice: only one caller can
    observe the row in `approved` and change it.
    """
    return EmailDraft.objects.filter(
        pk=draft_id, status=EmailDraft.Status.APPROVED,
    ).update(status=EmailDraft.Status.SENDING) == 1


def _sending_identity(campaign: Campaign):
    """(account, provider, sender_email, sender_name, login) for this send.

    Two shapes, and the first one is the one that keeps every existing campaign
    working:

      * **no accounts selected** -- the deployment's sender from the campaign
        record and `.env`, exactly as before. `account` is None.
      * **accounts selected** -- the first one that may actually send, checked
        again here rather than trusted from the setup screen. An account switched
        off between setup and sending is refused, and if none of the selected
        accounts can send, that is an error with a reason rather than a silent
        fall back to an address the user did not choose.

    One account per run, not round-robin. Rotating addresses inside a single
    campaign is a deliverability decision with real consequences, and it is not one
    to make implicitly on the user's behalf.
    """
    selected = mailaccounts.for_campaign(campaign)
    if not selected:
        provider = providers.provider_for(campaign.provider
                                       or providers.DEFAULT_PROVIDER)
        return None, provider, campaign.sender_email, campaign.sender_name, ""

    usable = mailaccounts.sending_accounts(campaign)
    if not usable:
        report = mailaccounts.selection_report(campaign)
        blocked = "; ".join(
            f"{row['account'].name}: {row['reason']}"
            for row in report["rows"] if not row["usable"])
        raise mailaccounts.NoSendingAccount(
            f"None of the {len(selected)} account(s) chosen for this campaign can "
            f"send. {blocked}. Nothing was sent."
        )

    account = usable[0]
    provider = mailaccounts.provider_of(account)
    return (account, provider, account.sender_email,
            account.sender_name or campaign.sender_name,
            account.username or account.sender_email)


def _send_all(campaign: Campaign, password: str, host: str, port: int) -> None:
    # §5: only an ACTIVE campaign sends. Paused and Stopped were halted by a
    # person, and Draft and Scheduled have not started -- so this refuses rather
    # than sending, and says which it was.
    campaign.refresh_from_db(fields=["status", "status_note"])
    if not campaign.may_send:
        _finish(campaign, (
            f"This campaign is {campaign.get_status_display().lower()}, so "
            "nothing was sent."
            + (f" ({campaign.status_note})" if campaign.status_note else "")
            + " Activate it to send."
        ))
        return

    Campaign.objects.filter(pk=campaign.pk).update(
        phase=Campaign.Phase.SENDING, error="")

    # Sweep the queue against the history first, so anything contacted since the
    # campaign was built drops out before a connection is opened.
    pre_skipped = history.mark_campaign_duplicates(campaign)

    # Which address is sending. A campaign that has chosen accounts uses one of
    # them, with its own credentials and its own daily limit; a campaign that has
    # not behaves exactly as it did before email accounts existed.
    try:
        account, provider, sender_email, sender_name, login = _sending_identity(
            campaign)
    except mailaccounts.NoSendingAccount as exc:
        _finish(campaign, str(exc))
        return

    if account is not None:
        password = mailaccounts.password_of(account)
        host, port = account.smtp_host, account.smtp_port or 0
        budget = mailaccounts.remaining_today(account)
        cap_note = (f"{account.name} ({sender_email}) is capped at "
                    f"{mailaccounts.daily_cap(account)} messages a day")
        if not password:
            _finish(campaign, (
                f"No usable password is stored for {account.name}. Add one in "
                "Settings, or clear the campaign's account selection to use the "
                "address configured in .env."
            ))
            return
    else:
        budget = provider.daily_cap - sent_today(sender_email)
        cap_note = (f"{provider.label} is capped at {provider.daily_cap} "
                    "messages a day for one account")

    queue = list(
        campaign.drafts.filter(status=EmailDraft.Status.APPROVED)
        .values_list("id", flat=True)
    )
    skipped = pre_skipped

    if budget <= 0:
        _finish(campaign, (
            f"Daily limit reached: {cap_note}. {len(queue)} approved email(s) are "
            "still queued -- send them tomorrow."
        ))
        return

    try:
        with transport.Session(provider, sender_email, password,
                            host=host, port=port, username=login) as session:
            sent = 0
            for draft_id in queue:
                if sent >= budget:
                    break
                if not _claim_draft(draft_id):
                    continue  # somebody else already took this one

                draft = EmailDraft.objects.get(pk=draft_id)

                # The final duplicate check, immediately before SMTP. Reserving
                # the address in the history is what makes a second send
                # impossible -- for a double-clicked button, a second campaign
                # carrying the same lead, or another thread sending right now.
                try:
                    record = history.reserve(
                        draft, sender_account=account,
                        sender_email=sender_email)
                except history.DoNotContact as exc:
                    # A suppression, not a duplicate. Recorded as its own state
                    # so it is never mistaken for something re-contactable.
                    EmailDraft.objects.filter(pk=draft_id).update(
                        status=EmailDraft.Status.SUPPRESSED,
                        error_message=str(exc)[:2000],
                    )
                    skipped += 1
                    continue
                except history.AlreadyContacted as exc:
                    EmailDraft.objects.filter(pk=draft_id).update(
                        status=EmailDraft.Status.DUPLICATE,
                        error_message=str(exc)[:2000],
                    )
                    skipped += 1
                    continue

                try:
                    message_id = session.send(
                        to_email=draft.email,
                        subject=draft.subject,
                        # The account's signature, where it has one. Appended by
                        # the sender alongside the reply line, so a body that
                        # already carries it is not given a second copy.
                        body=compose.with_signature(
                            draft.body,
                            account.signature if account else ""),
                        sender_name=sender_name,
                    )
                except transport.SendError:
                    # Session-level problem: release both claims and stop.
                    record.mark_failed("Send aborted before delivery.")
                    _release_draft(draft_id)
                    raise
                except Exception as exc:  # noqa: BLE001 - one bad recipient
                    # A rejected recipient must not stop the other 99. Marking
                    # the record failed frees the address for a later retry.
                    message = f"{type(exc).__name__}: {exc}"
                    record.mark_failed(message)
                    EmailDraft.objects.filter(pk=draft_id).update(
                        status=EmailDraft.Status.FAILED,
                        error_message=message[:2000],
                    )
                else:
                    # Stored before anything else: a reply can only be matched
                    # to this email by the Message-ID it quotes.
                    record.mark_sent(message_id=message_id)
                    EmailDraft.objects.filter(pk=draft_id).update(
                        status=EmailDraft.Status.SENT,
                        sent_at=timezone.now(),
                        error_message="",
                        # Which account actually sent it -- section 17. Recorded
                        # here rather than at approval: the campaign's selection
                        # can change between the two, and the question this
                        # answers is "who sent it", not "who was allowed to".
                        # None on the path where no accounts are configured.
                        sent_account=account,
                    )
                    # §9: the follow-up schedule exists from here, written from the
                    # send that just happened rather than recomputed by whoever
                    # asks next. Deliberately not fatal -- an email that went out
                    # has gone out, and losing the schedule is worth a log line,
                    # not an exception that would leave the record half-written.
                    try:
                        followups.schedule_next(record)
                    except Exception:  # noqa: BLE001
                        log.exception("could not schedule a follow-up for %s",
                                      record.pk)
                    sent += 1

                time.sleep(provider.delay)  # stay inside the provider's rate
    except transport.SendError as exc:
        _finish(campaign, str(exc))
        return

    leftover = campaign.drafts.filter(status=EmailDraft.Status.APPROVED).count()
    notes = []
    if leftover:
        notes.append(
            f"Stopped at the daily cap for {provider.label} "
            f"({provider.daily_cap}/day). {leftover} approved email(s) remain "
            "queued -- run Send again tomorrow."
        )
    if skipped:
        notes.append(
            f"{skipped} lead(s) were skipped because the address had already "
            "been contacted."
        )
    _finish(campaign, " ".join(notes))


def _release_draft(draft_id: int) -> None:
    EmailDraft.objects.filter(
        pk=draft_id, status=EmailDraft.Status.SENDING,
    ).update(status=EmailDraft.Status.APPROVED)


def _finish(campaign: Campaign, error: str) -> None:
    with transaction.atomic():
        # Anything left mid-flight after the loop exits was never handed over.
        campaign.drafts.filter(status=EmailDraft.Status.SENDING).update(
            status=EmailDraft.Status.APPROVED)
        Campaign.objects.filter(pk=campaign.pk).update(
            phase=Campaign.Phase.DONE, error=error, finished_at=timezone.now())

    # Refresh the spreadsheet once, at the end of the run. A failure here must
    # never lose a send that already happened -- the database is the record.
    try:
        result = history.export_excel(campaign.owner)
        log.info("sent_leads.xlsx: +%s row(s), %s total",
                 result["added"], result["total"])
    except Exception:  # noqa: BLE001
        log.exception("could not update the Excel history export")
