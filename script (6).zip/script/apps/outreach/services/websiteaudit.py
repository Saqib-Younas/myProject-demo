"""
Auditing one submitted website: `SpecificWebsiteAuditService`.

The orchestrator, and nothing more. Every step it runs already existed:

    safeurl.check          the URL is a public website and not a private address
    crawler.analyse       the crawl -- robots, limits, one host, progress reported
    contacts.harvest_page  contact details, off the pages while they are in memory
    runner.review_draft    the AI audit, evidence-only, findings with ids
    intelligence.apply     scoring and classification
    scoring.rank_for_email the commercial shortlist
    runner.generate_draft  the email, in the brief 90-150 word template
    intelligence.remember  the shared per-domain audit cache

There is no crawler here, no prompt, no finding logic and no SMTP. What this module
contributes is the order, the job's state, and the decisions about stopping:

  * A URL that cannot be audited is refused with a specific reason (§19), not a
    stack trace and not a half-audit built from missing data.
  * A crawl that succeeded but found nothing worth saying produces **no email**
    (§18). Generating one anyway would mean inventing a problem, which is the one
    thing the whole audit pipeline exists to prevent.
  * A site that published no address produces an audit with no recipient (§17), and
    the person can type one. Nothing is guessed.
  * **It never sends.** There is no code path from here to SMTP. Sending is
    `sending.send_audit`, called only by the view behind the confirmation step.
"""

from __future__ import annotations

import logging
import os
import socket
import uuid
from dataclasses import dataclass
from datetime import timedelta

import requests
from django.db.models import Q
from django.utils import timezone

from apps.ai import styles
from apps.auditing import contacts, crawler, safeurl, scoring
from apps.outreach.models import AuditJob, Campaign, EmailDraft
from apps.outreach.services import history, intelligence
from apps.outreach.services import pipeline as runner

log = logging.getLogger(__name__)

#: The label of the container campaign every audited website's draft belongs to.
#: One per account, reused: `EmailDraft` needs a campaign, and this workflow is not
#: a campaign, so it gets a permanent holder rather than one campaign per URL --
#: which would put a row on the Campaigns page for every website ever audited.
HOLDER_CITY = "Website audits"

#: How long a worker's claim on a job lasts. A crawl of eight pages with a one
#: second delay plus two AI calls is a couple of minutes; ten is room to spare
#: without leaving a crashed job stuck for an hour.
LEASE_SECONDS = 600


def worker_id() -> str:
    return f"{socket.gethostname()}/{os.getpid()}/{uuid.uuid4().hex[:6]}"


@dataclass
class Outcome:
    """What one audit run produced, for the caller's log line."""

    job_id: int
    state: str
    reason: str = ""
    findings: int = 0
    recipient: str = ""

    def line(self) -> str:
        return (f"audit {self.job_id}: {self.state}"
                + (f" -- {self.reason}" if self.reason else "")
                + (f" ({self.findings} finding(s))" if self.findings else ""))


# --------------------------------------------------------------------------- #
# Creating a job
# --------------------------------------------------------------------------- #

def create(owner, submitted: str) -> AuditJob:
    """Validate a submitted URL and queue an audit. Raises `safeurl.UnsafeUrl`.

    The URL is checked *before* a row exists, so an address that cannot be audited
    produces an error on the form rather than a failed job in a list. Everything
    after this point is the worker's.
    """
    target = safeurl.check(submitted)
    return AuditJob.objects.create(
        owner=owner,
        submitted_url=(submitted or "").strip()[:500],
        url=target.url[:500],
        site=target.site[:255],
        state=AuditJob.State.QUEUED,
        state_note="Waiting for the worker to pick it up.",
    )


def holder(owner) -> Campaign:
    """The container campaign for this account's website audits.

    `get_or_create` on a fixed label, and left in DRAFT status forever. That
    matters: DRAFT means `may_send` is false, so the bulk send path, the automation
    worker and the follow-up worker all refuse to touch it. The only thing that
    sends from these drafts is the audit's own Send button, one at a time, with a
    person's click behind each one.
    """
    from django.conf import settings as django_settings

    campaign, _created = Campaign.objects.get_or_create(
        owner=owner, city=HOLDER_CITY, category="Specific website audit",
        defaults={
            "country": "",
            "sender_name": django_settings.OUTREACH_SENDER_NAME,
            "sender_email": django_settings.OUTREACH_SENDER_EMAIL,
            "sender_company": django_settings.OUTREACH_SENDER_COMPANY,
            "provider": django_settings.OUTREACH_PROVIDER,
            "service_pitch": _pitch(),
            "status": Campaign.Status.DRAFT,
            "phase": Campaign.Phase.SETUP,
        },
    )
    return campaign


def _pitch() -> str:
    from apps import ai

    return ai.DEFAULT_OFFER


# --------------------------------------------------------------------------- #
# Claiming one
# --------------------------------------------------------------------------- #

def claimable():
    """Jobs a worker may pick up, oldest first.

    Queued ones, and ones a previous worker left mid-run with an expired lease --
    a process killed during a crawl cannot tidy up after itself, and a job nobody
    will ever finish is worse than one that is tried again.
    """
    now = timezone.now()
    stale = Q(state__in=AuditJob.WORKING) & (
        Q(locked_until__isnull=True) | Q(locked_until__lt=now))
    return (AuditJob.objects
            .filter(Q(state__in=AuditJob.CLAIMABLE) | stale)
            .select_related("owner", "draft")
            .order_by("created_at", "pk"))


def claim(job: AuditJob, who: str, *, seconds: int = LEASE_SECONDS) -> bool:
    """Take this job. False means another worker has it.

    A conditional UPDATE against both the state and the lease, so two workers
    starting at the same moment cannot both crawl the same site -- which would be
    two sets of requests to somebody else's server and two AI bills for one answer.
    """
    now = timezone.now()
    free = (Q(locked_until__isnull=True) | Q(locked_until__lt=now)
            | Q(locked_by=who))
    taken = (AuditJob.objects
             .filter(pk=job.pk)
             .filter(Q(state__in=AuditJob.CLAIMABLE)
                     | Q(state__in=AuditJob.WORKING))
             .filter(free)
             .update(locked_by=who,
                     locked_until=now + timedelta(seconds=seconds),
                     started_at=job.started_at or now))
    if taken:
        job.refresh_from_db()
    return bool(taken)


# --------------------------------------------------------------------------- #
# The service
# --------------------------------------------------------------------------- #

class SpecificWebsiteAuditService:
    """One audit, start to finish, without sending anything.

    Instantiated per job. Every step writes its result to the job before the next
    one starts, so a crash leaves a state that says how far it got rather than a
    row that claims to be running.
    """

    def __init__(self, job: AuditJob):
        self.job = job
        self.owner = job.owner
        self.harvest = contacts.Harvest()

    # --- state bookkeeping -------------------------------------------------- #

    def _state(self, state: str, note: str = "", **fields) -> None:
        AuditJob.objects.filter(pk=self.job.pk).update(
            state=state, state_note=note[:400], **fields)
        self.job.state = state
        self.job.state_note = note
        for key, value in fields.items():
            setattr(self.job, key, value)

    def _fail(self, kind: str, message: str) -> Outcome:
        """Record a specific reason and stop (§19).

        No audit is produced from missing data: a job that could not read the site
        has no findings, and pretending otherwise is how an email ends up citing a
        problem nobody measured.
        """
        AuditJob.objects.filter(pk=self.job.pk).update(
            state=AuditJob.State.FAILED,
            failure=kind,
            state_note=message[:400],
            error=message,
            finished_at=timezone.now(),
            locked_by="", locked_until=None,
        )
        self.job.state = AuditJob.State.FAILED
        log.info("audit %s failed (%s): %s", self.job.pk, kind, message)
        return Outcome(self.job.pk, AuditJob.State.FAILED, message)

    # --- the run ------------------------------------------------------------ #

    def run(self) -> Outcome:
        """Crawl, analyse, extract, draft. Returns what happened.

        Never raises for anything about the submitted website: an unreachable site,
        a site that says no, a model that refuses -- each becomes a state and a
        sentence. The only exceptions that escape are programming errors, which the
        worker logs and turns into a FAILED job.
        """
        try:
            target = safeurl.check(self.job.url or self.job.submitted_url)
        except safeurl.InvalidUrl as exc:
            return self._fail(AuditJob.Failure.INVALID, str(exc))
        except safeurl.UnsafeUrl as exc:
            return self._fail(AuditJob.Failure.UNSAFE, str(exc))

        AuditJob.objects.filter(pk=self.job.pk).update(
            url=target.url[:500], site=target.site[:255])
        self.job.url, self.job.site = target.url, target.site

        result = self._crawl(target)
        if result is None:
            return Outcome(self.job.pk, self.job.state, self.job.state_note)

        draft = self._draft_for(target, result)
        self._analyse(draft, result)
        contact = self._contacts(draft, target)
        return self._write_email(draft, contact)

    # --- step 1: crawl ------------------------------------------------------- #

    def _crawl(self, target: safeurl.Target):
        """Fetch the site, reporting progress. None means the job has failed."""
        self._state(AuditJob.State.CRAWLING,
                    f"Reading {target.site}…", pages_crawled=0, pages_found=0,
                    pages_seen={})

        def progress(event: dict) -> None:
            """Written to the row as it happens, so §4 can be true."""
            stage = event.get("stage")
            if stage == "discovered":
                AuditJob.objects.filter(pk=self.job.pk).update(
                    pages_found=int(event.get("count") or 0) + 1)
                return
            if stage not in ("home", "page"):
                return

            url = str(event.get("url") or "")
            kind = str(event.get("kind") or "other")
            # Contact extraction happens here because this is the only moment the
            # page's HTML exists. Storing every page's markup for a caller that
            # may not want it would be the alternative.
            contacts.harvest_page(self.harvest, event.get("html") or "", url,
                                  kind, target.site)

            seen = dict(self.job.pages_seen or {})
            seen.setdefault(kind, url)
            self.job.pages_seen = seen
            AuditJob.objects.filter(pk=self.job.pk).update(
                pages_crawled=(self.job.pages_crawled or 0) + 1,
                pages_seen=seen,
                state_note=f"Read {kind}: {url}"[:400],
            )
            self.job.pages_crawled = (self.job.pages_crawled or 0) + 1

        try:
            result = crawler.analyse(target.url, guard=safeurl.guard,
                                      progress=progress)
        except requests.Timeout as exc:
            self._fail(AuditJob.Failure.TIMEOUT,
                       f"{target.site} did not respond in time ({exc}).")
            return None
        except Exception as exc:  # noqa: BLE001 - one website, not the worker
            log.exception("audit %s: crawl failed", self.job.pk)
            self._fail(AuditJob.Failure.ERROR,
                       f"Could not read {target.site}: {exc}")
            return None

        self.job.refresh_from_db()

        if result.status == crawler.BLOCKED:
            kind = (AuditJob.Failure.ROBOTS if "robots" in result.detail.lower()
                    else AuditJob.Failure.UNSAFE
                    if "not allowed" in result.detail.lower()
                    or "points at" in result.detail.lower()
                    else AuditJob.Failure.DENIED)
            self._fail(kind, result.summary())
            return None

        if result.status != crawler.OK or not result.pages:
            detail = result.summary().lower()
            kind = (AuditJob.Failure.TIMEOUT if "timed out" in detail
                    or "timeout" in detail else
                    AuditJob.Failure.REDIRECTS if "redirect" in detail else
                    AuditJob.Failure.NOT_HTML if "not an html" in detail else
                    AuditJob.Failure.SERVER if "500" in detail
                    or "server error" in detail else
                    AuditJob.Failure.UNREACHABLE)
            self._fail(kind, result.summary())
            return None

        return result

    # --- step 2: the evidence record ---------------------------------------- #

    def _draft_for(self, target: safeurl.Target,
                   result: crawler.SiteAnalysis) -> EmailDraft:
        """The `EmailDraft` this audit's evidence and email live on.

        Reused rather than invented: it already holds crawl output, findings,
        subject, body, status and the sent account, and everything downstream --
        scoring, ranking, generation, the lead pages -- reads it.
        """
        campaign = holder(self.owner)
        business = self._business_name(target, result)

        draft = self.job.draft
        if draft is None:
            draft = EmailDraft.objects.create(
                campaign=campaign,
                business_name=business[:255],
                website=target.url[:500],
                category="Specific website audit",
                source=target.url[:500],
                status=EmailDraft.Status.PENDING,
            )
            AuditJob.objects.filter(pk=self.job.pk).update(draft=draft)
            self.job.draft = draft

        # The crawl's own fields, written the same way `runner.crawl_draft` writes
        # them, so every reader sees the shape it expects.
        draft.business_name = business[:255]
        draft.analysis_status = result.status
        draft.analysis_note = result.summary()[:400]
        draft.analysis_context = result.as_context()
        draft.pages_read = [
            {"url": p.url, "kind": p.kind, "facts": dict(p.facts or {})}
            for p in result.pages
        ]
        draft.pages_discovered = result.discovered
        draft.discovered_emails = [
            d.value for d in self.harvest.of(contacts.EMAIL)
        ] or list(result.emails_found or [])
        draft.status = EmailDraft.Status.CRAWLED
        draft.save(update_fields=[
            "business_name", "analysis_status", "analysis_note",
            "analysis_context", "pages_read", "pages_discovered",
            "discovered_emails", "status",
        ])
        return draft

    def _business_name(self, target: safeurl.Target,
                       result: crawler.SiteAnalysis) -> str:
        """What to call this business, from what the site said about itself.

        Structured data first -- the business wrote its own name there -- then the
        home page title, then the domain. Never invented: the domain is a fact even
        when it is not a name.
        """
        stated = self.harvest.of(contacts.BUSINESS)
        if stated:
            return stated[0].value

        title = result.pages[0].title if result.pages else ""
        if title:
            # Titles are usually "Name | Tagline" or "Name - Something".
            head = title.split("|")[0].split("–")[0].split(" - ")[0].strip()
            if 2 <= len(head) <= 80:
                return head
        return target.site

    # --- step 3: the AI review ---------------------------------------------- #

    def _analyse(self, draft: EmailDraft, result: crawler.SiteAnalysis) -> None:
        """Findings from the evidence, then scoring. Never invents anything.

        A review that fails leaves the job with no findings rather than with made-up
        ones, and the crawl is kept -- it is the expensive part, and the pages are
        still worth showing.
        """
        self._state(AuditJob.State.ANALYZING,
                    f"Reviewing {len(result.pages)} page(s) of evidence…")

        try:
            runner.review_draft(draft, retries=1)
        except Exception:  # noqa: BLE001 - a failed review keeps the crawl
            log.exception("audit %s: review failed", self.job.pk)
        draft.refresh_from_db()

        try:
            intelligence.apply(draft)
            draft.refresh_from_db()
        except Exception:  # noqa: BLE001 - scoring must not lose the crawl
            log.exception("audit %s: scoring failed", self.job.pk)

        # The shared per-domain audit, so a lead on this domain benefits from an
        # audit somebody ran by hand -- and vice versa.
        try:
            audit = intelligence.remember(
                self.owner, draft.website, result,
                findings=list(draft.findings or []),
                summary=draft.business_summary,
            )
            if audit is not None:
                AuditJob.objects.filter(pk=self.job.pk).update(audit=audit)
                EmailDraft.objects.filter(pk=draft.pk).update(audit=audit)
        except Exception:  # noqa: BLE001 - the cache is a convenience
            log.exception("audit %s: could not store the shared audit",
                          self.job.pk)

    # --- step 4: contacts --------------------------------------------------- #

    def _contacts(self, draft: EmailDraft, target: safeurl.Target) -> dict:
        """Rank what was found and choose a recipient. Never guesses one (§9)."""
        contacts.rank(self.harvest, target.site)
        summary = contacts.summary(self.harvest)

        chosen = summary.get("email", "")
        business = summary.get("business_name") or draft.business_name
        person = summary.get("person_name", "")
        best = self.harvest.best_email
        if best is not None and best.label and " " in best.label:
            # A name published beside the address itself beats a name found
            # elsewhere on the site: it is the one the page connected to it.
            person = best.label

        fields = {
            "contacts": self.harvest.as_dict(),
            "business_name": business[:255],
            "contact_name": person[:160],
            "state": AuditJob.State.CONTACTS_FOUND,
            "state_note": (f"Found {chosen}" if chosen else
                           "No public email address was found."),
        }
        # A recipient a person typed is never overwritten by the crawl (§17).
        if not self.job.recipient_manual:
            fields["recipient"] = chosen

        AuditJob.objects.filter(pk=self.job.pk).update(**fields)
        self.job.refresh_from_db()

        if chosen and not self.job.recipient_manual:
            EmailDraft.objects.filter(pk=draft.pk).update(email=chosen)
            draft.refresh_from_db()
        return summary

    # --- step 5: the email -------------------------------------------------- #

    def _write_email(self, draft: EmailDraft, contact: dict) -> Outcome:
        """Draft the email, or explain why there is nothing to say.

        §18 is the important branch: a crawl that found nothing worth raising
        produces no email at all. The alternative is asking a model to write about
        problems it has not been given, which is exactly how an invented finding
        reaches a stranger's inbox.
        """
        findings = draft.finding_objects
        shortlist = scoring.rank_for_email(
            findings, limit=styles.BRIEF.max_findings)

        if not shortlist:
            AuditJob.objects.filter(pk=self.job.pk).update(
                state=AuditJob.State.READY,
                no_findings=True,
                state_note=("No strong evidence-based website issues were found "
                            "in the pages reviewed."),
                finished_at=timezone.now(),
                locked_by="", locked_until=None,
            )
            self.job.refresh_from_db()
            return Outcome(self.job.pk, AuditJob.State.READY,
                           "no evidence-based findings", 0,
                           self.job.recipient)

        self._state(AuditJob.State.DRAFT_READY, "Writing the email…")

        written = False
        try:
            written = runner.generate_draft(
                draft, holder(self.owner), retries=1,
                style=styles.BRIEF)
        except Exception:  # noqa: BLE001 - the audit survives a failed draft
            log.exception("audit %s: email generation failed", self.job.pk)
        draft.refresh_from_db()

        if not written:
            # The audit is still worth having: the findings are real and the
            # contact details are real. Only the email is missing, and there is a
            # Regenerate button for that.
            AuditJob.objects.filter(pk=self.job.pk).update(
                state=AuditJob.State.READY,
                state_note=("The audit is ready. The email could not be written "
                            "-- try Regenerate."),
                error=draft.error_message[:2000],
                finished_at=timezone.now(),
                locked_by="", locked_until=None,
            )
            self.job.refresh_from_db()
            return Outcome(self.job.pk, AuditJob.State.READY,
                           "email generation failed", len(shortlist),
                           self.job.recipient)

        try:
            intelligence.apply(draft)
        except Exception:  # noqa: BLE001
            log.exception("audit %s: re-scoring failed", self.job.pk)

        EmailDraft.objects.filter(pk=draft.pk).update(
            processed_at=timezone.now())
        AuditJob.objects.filter(pk=self.job.pk).update(
            state=AuditJob.State.READY,
            no_findings=False,
            state_note="Ready for your review.",
            finished_at=timezone.now(),
            locked_by="", locked_until=None,
        )
        self.job.refresh_from_db()
        return Outcome(self.job.pk, AuditJob.State.READY, "", len(shortlist),
                       self.job.recipient)


# --------------------------------------------------------------------------- #
# Running jobs
# --------------------------------------------------------------------------- #

def run_job(job: AuditJob, *, who: str = "") -> Outcome:
    """Claim and run one job. Safe to call from two workers at once."""
    who = who or worker_id()
    if not claim(job, who):
        return Outcome(job.pk, job.state, "another worker has this job")

    service = SpecificWebsiteAuditService(job)
    try:
        return service.run()
    except Exception as exc:  # noqa: BLE001 - one job, not the worker
        log.exception("audit %s crashed", job.pk)
        return service._fail(AuditJob.Failure.ERROR,
                             f"{type(exc).__name__}: {exc}")


def run_pending(*, owner=None, limit: int = 5, who: str = "") -> list[Outcome]:
    """One pass over the queue. What the worker command calls."""
    who = who or worker_id()
    query = claimable()
    if owner is not None:
        query = query.filter(owner=owner)

    done: list[Outcome] = []
    for job in query[:limit]:
        done.append(run_job(job, who=who))
    return done


def start_in_background(job: AuditJob) -> bool:
    """Run this job in a thread, so the page can be watched immediately.

    The same shape the manual pipeline uses: a daemon thread inside the web
    process, with the database connection closed on the way out. It is not the only
    way the job gets done -- `manage.py run_audits` picks up anything left queued,
    which is what makes a restart survivable and what a deployment with several web
    workers should rely on.
    """
    return runner._spawn(_run_and_close, job)


def _run_and_close(job: AuditJob) -> None:
    from django.db import connections

    try:
        run_job(job)
    finally:
        for connection in connections.all():
            connection.close()


# --------------------------------------------------------------------------- #
# Regenerating the email, on request
# --------------------------------------------------------------------------- #

def regenerate(job: AuditJob, hint: str = "") -> tuple[bool, str]:
    """Write the email again from the same findings. (ok, message).

    The findings are not re-derived and the site is not re-crawled: this is "say it
    differently", not "look again". Re-crawling would spend somebody else's
    bandwidth to answer a question about our own wording.
    """
    draft = job.draft
    if draft is None:
        return False, "There is no audit to write an email from yet."

    shortlist = scoring.rank_for_email(
        draft.finding_objects, limit=styles.BRIEF.max_findings)
    if not shortlist:
        return False, ("There are no evidence-based findings to write about, so "
                       "there is nothing to say that would be true.")

    try:
        written = runner.generate_draft(draft, holder(job.owner), hint,
                                       retries=1, style=styles.BRIEF)
    except Exception as exc:  # noqa: BLE001
        log.exception("audit %s: regenerate failed", job.pk)
        return False, f"The email could not be written: {exc}"

    draft.refresh_from_db()
    if not written:
        return False, (draft.error_message
                       or "The email could not be written. Try again.")
    return True, "A new draft is ready."


def blocked_reason(job: AuditJob) -> str:
    """"" if this audit's email may be sent, otherwise why not.

    The suppression list is absolute here as everywhere: an address on it is not
    sendable by any route, including a person typing it in by hand.
    """
    if job.is_sent:
        return "This audit's email has already been sent."
    if not job.recipient:
        return ("No recipient. Choose an address that was found on the site, or "
                "enter one.")
    if job.draft_id is None or not (job.draft.subject or "").strip():
        return "There is no email draft to send yet."

    blocked = history.SuppressionIndex(job.owner).match(
        email=job.recipient, website=job.url)
    if blocked:
        return blocked.sentence()
    return ""
