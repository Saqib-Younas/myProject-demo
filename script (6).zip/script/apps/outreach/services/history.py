"""
Sending history: who has been contacted, and the checks that keep it that way.

Duplicate protection is deliberately layered, because each layer catches a case
the others cannot:

  1. **Search time** -- results are annotated so an already-contacted business is
     visible before the user selects anything.
  2. **Campaign creation** -- matched leads are stored as `duplicate` and never
     enter the workflow, so no crawl, no AI spend, no draft.
  3. **Immediately before SMTP** -- the send loop reserves the address in the
     database and only then opens the connection. This is the layer that holds
     when two sending threads race, when Send is double-clicked, or when the same
     address arrives via a second campaign.

The database is the source of truth. The Excel file is a human-readable export of
it, appended to rather than rewritten.

Matching runs in three tiers, strongest first, because they are not equally
reliable: an address is an address, a shared domain is strong evidence, and a
name-plus-city collision is a good hint that occasionally catches two genuinely
different businesses. The tier that matched is recorded and shown, so the user can
judge a weak match rather than being silently blocked by it.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from django.conf import settings
from django.db import IntegrityError, transaction
from django.utils import timezone

from apps.outreach.models import Campaign, EmailDraft, SentLead, Suppression

log = logging.getLogger(__name__)

#: Badge vocabulary shared by the templates and the JSON API.
STATES = {
    "new": {"label": "New", "pill": "pill-ok"},
    "ready": {"label": "Ready to contact", "pill": "pill-brand"},
    "contacted": {"label": "Already contacted", "pill": "pill-warn"},
    "suppressed": {"label": "Do not contact", "pill": "pill-err"},
    "invalid": {"label": "Invalid email", "pill": "pill"},
    "sending": {"label": "Sending", "pill": "pill-brand"},
    "sent": {"label": "Sent", "pill": "pill-ok"},
    "failed": {"label": "Failed", "pill": "pill-err"},
}

MATCH_LABELS = {
    "email": "same email address",
    "domain": "same website domain",
    "name_city": "same business name and city",
}

EXCEL_NAME = "sent_leads.xlsx"

HEADERS = (
    "Record ID", "Business Name", "Email", "Website", "Country", "City",
    "Campaign", "Campaign ID", "Sent Date", "Sent Time", "Email Subject",
    "Status", "Error",
)


@dataclass(frozen=True)
class Match:
    """Why a lead counts as already contacted."""

    matched_by: str          # email | domain | name_city
    business_name: str
    email: str
    sent_date: str
    campaign_label: str
    status: str

    def as_dict(self) -> dict:
        return {
            "matched_by": self.matched_by,
            "matched_by_label": MATCH_LABELS.get(self.matched_by, self.matched_by),
            "business_name": self.business_name,
            "email": self.email,
            "sent_date": self.sent_date,
            "campaign": self.campaign_label,
            "status": self.status,
        }


def _key(value: str) -> str:
    return (value or "").strip().casefold()


class Index:
    """An in-memory snapshot of one user's history, for checking a batch of leads.

    Built once per request rather than querying per lead: a 300-lead search would
    otherwise be 900 queries. Only rows that actually block a send are loaded --
    a `failed` row is history, not a block.

    `owner` is required. Passing None builds an empty index rather than an index
    of everybody's history, so a caller that forgets to supply the user gets "no
    matches" instead of another account's prospect list.
    """

    def __init__(self, owner, rows=None):
        if rows is None:
            rows = (SentLead.objects.filter(owner=owner)
                    .exclude(status=SentLead.Status.FAILED)
                    if owner is not None and getattr(owner, "pk", None)
                    else SentLead.objects.none())
        self.by_email: dict[str, Match] = {}
        self.by_domain: dict[str, Match] = {}
        self.by_name_city: dict[tuple[str, str], Match] = {}

        for row in rows:
            match = Match(
                matched_by="email",
                business_name=row.business_name,
                email=row.email,
                sent_date=row.sent_date.isoformat() if row.sent_date else "",
                campaign_label=row.campaign_label or "",
                status=row.status,
            )
            email = _key(row.email)
            if email:
                self.by_email.setdefault(email, match)
            if row.domain:
                self.by_domain.setdefault(
                    _key(row.domain), Match(**{**match.__dict__, "matched_by": "domain"}))
            if row.business_name and row.city:
                self.by_name_city.setdefault(
                    (_key(row.business_name), _key(row.city)),
                    Match(**{**match.__dict__, "matched_by": "name_city"}),
                )

    def __len__(self) -> int:
        return len(self.by_email)

    def match(self, *, email: str = "", website: str = "",
              business_name: str = "", city: str = "") -> Match | None:
        """Three tiers, strongest first. None means safe to contact."""
        key = _key(email)
        if key and key in self.by_email:
            return self.by_email[key]

        domain = _key(SentLead.domain_of(website))
        if domain and domain in self.by_domain:
            return self.by_domain[domain]

        pair = (_key(business_name), _key(city))
        if pair[0] and pair[1] and pair in self.by_name_city:
            return self.by_name_city[pair]

        return None


# --------------------------------------------------------------------------- #
# The do-not-contact list
# --------------------------------------------------------------------------- #

@dataclass(frozen=True)
class Blocked:
    """Why an address must not be contacted at all."""

    matched_by: str          # email | domain
    target: str
    reason: str
    reason_label: str
    note: str

    def as_dict(self) -> dict:
        return {
            "matched_by": self.matched_by,
            "target": self.target,
            "reason": self.reason,
            "reason_label": self.reason_label,
            "note": self.note,
        }

    def sentence(self) -> str:
        where = ("this address is on the do-not-contact list"
                 if self.matched_by == "email"
                 else f"the domain {self.target} is on the do-not-contact list")
        return (f"Do not contact: {where} ({self.reason_label.lower()})"
                + (f" — {self.note}" if self.note else ""))


class SuppressionIndex:
    """An in-memory snapshot of one user's do-not-contact list.

    Two tiers only, and no name-and-city tier on purpose. The history's third
    tier is a *hint* the user is allowed to overrule; a do-not-contact rule is
    not, so it must never rest on a guess as loose as two businesses sharing a
    name in one city.

    Scoped to the owner: one user's removal request is not another user's, and a
    shared list would leak which businesses somebody else has been emailing.
    """

    def __init__(self, owner, rows=None):
        if rows is None:
            rows = (Suppression.objects.filter(owner=owner)
                    if owner is not None and getattr(owner, "pk", None)
                    else Suppression.objects.none())
        self.by_email: dict[str, Blocked] = {}
        self.by_domain: dict[str, Blocked] = {}

        for row in rows:
            blocked = Blocked(
                matched_by="email" if row.email else "domain",
                target=row.target,
                reason=row.reason,
                reason_label=row.get_reason_display(),
                note=row.note,
            )
            if row.email:
                self.by_email.setdefault(_key(row.email), blocked)
            if row.domain:
                self.by_domain.setdefault(
                    _key(row.domain),
                    Blocked(**{**blocked.__dict__, "matched_by": "domain",
                               "target": row.domain}),
                )

    def __len__(self) -> int:
        return len(self.by_email) + len(self.by_domain)

    def match(self, *, email: str = "", website: str = "") -> Blocked | None:
        """None means this address is not suppressed."""
        key = _key(email)
        if key and key in self.by_email:
            return self.by_email[key]

        # An address's own domain counts, not just the website field: somebody
        # who suppressed `acme.com` should not be reachable at `info@acme.com`
        # because the map listing happened to omit a website.
        for candidate in (SentLead.domain_of(website),
                          key.split("@")[-1] if "@" in key else ""):
            domain = _key(candidate).removeprefix("www.")
            if domain and domain in self.by_domain:
                return self.by_domain[domain]

        return None


def suppress(owner, *, email: str = "", domain: str = "", reason: str = "",
             note: str = "", business_name: str = "",
             campaign_label: str = "") -> tuple[Suppression, bool]:
    """Add a do-not-contact entry. Returns (row, created).

    Idempotent: suppressing the same target twice updates the reason rather than
    failing, because the useful outcome is "this address is blocked", not "your
    request was rejected".
    """
    email = (email or "").strip()
    domain = _key(domain).removeprefix("www.")
    if not email and not domain:
        raise ValueError("Give an email address or a domain to suppress.")
    if reason not in Suppression.Reason.values:
        reason = Suppression.Reason.UNSUBSCRIBED

    lookup = ({"owner": owner, "email__iexact": email} if email
              else {"owner": owner, "domain": domain, "email": ""})
    defaults = {
        "reason": reason,
        "note": note[:400],
        "business_name": business_name[:255],
        "campaign_label": campaign_label[:255],
    }
    if email:
        defaults["domain"] = domain or _key(email.split("@")[-1])

    existing = Suppression.objects.filter(**lookup).first()
    if existing:
        for field, value in defaults.items():
            setattr(existing, field, value)
        existing.save(update_fields=list(defaults))
        return existing, False

    create = {"owner": owner, "email": email,
              "domain": defaults.pop("domain", domain), **defaults}
    return Suppression.objects.create(**create), True


def annotate_leads(leads: list[dict], owner=None) -> dict[str, int]:
    """Tag scraped lead dicts in place with their contact state.

    Adds `contact_state`, `state_label` and (when matched) `history` to every
    lead, and returns the counts the search screen reports.
    """
    index = Index(owner)
    blocklist = SuppressionIndex(owner)
    counts = {"total": len(leads), "available": 0, "contacted": 0, "invalid": 0,
              "suppressed": 0}

    for lead in leads:
        email = (lead.get("email") or "").strip()
        if not email:
            lead["contact_state"] = "invalid"
            counts["invalid"] += 1
        else:
            # The do-not-contact list is checked first: it is the stronger rule,
            # and its badge must not be masked by an already-contacted match.
            blocked = blocklist.match(email=email, website=lead.get("website", ""))
            if blocked:
                lead["contact_state"] = "suppressed"
                lead["suppression"] = blocked.as_dict()
                counts["suppressed"] += 1
                lead["state_label"] = STATES["suppressed"]["label"]
                continue

            match = index.match(
                email=email,
                website=lead.get("website", ""),
                business_name=lead.get("business_name", ""),
                city=lead.get("city", ""),
            )
            if match:
                lead["contact_state"] = "contacted"
                lead["history"] = match.as_dict()
                counts["contacted"] += 1
            else:
                lead["contact_state"] = "new"
                counts["available"] += 1
        lead["state_label"] = STATES[lead["contact_state"]]["label"]

    return counts


# --------------------------------------------------------------------------- #
# The pre-send reservation
# --------------------------------------------------------------------------- #

class AlreadyContacted(Exception):
    """This address is already spoken for. Do not open an SMTP connection."""


class DoNotContact(AlreadyContacted):
    """This address is on the do-not-contact list. No override applies.

    A subclass so existing callers that stop on AlreadyContacted keep working,
    while the send loop can record it as the different thing it is.
    """


def reserve(draft: EmailDraft, *, sender_account=None,
            sender_email: str = "") -> SentLead:
    """Claim an address in the history before sending to it.

    `sender_account` and `sender_email` record which address is about to send.
    Both, on purpose: the FK answers "everything this account has sent", and the
    text survives the account being deleted -- a history that changes when a row
    elsewhere is removed is not a history.

    Creating the row is the lock. The unique constraint covers every status
    except `failed`, so a second caller -- another thread, another campaign, a
    double-clicked button -- gets an IntegrityError instead of a second email.

    Raises DoNotContact if the address is suppressed, AlreadyContacted if it is
    taken. The suppression check is first and is not affected by
    `draft.force_contact`: the override exists for the sending history, and a
    do-not-contact rule is not the sending history.
    """
    if not draft.email:
        raise AlreadyContacted("This draft has no email address.")

    owner = draft.campaign.owner if draft.campaign_id else None
    blocked = SuppressionIndex(owner).match(email=draft.email,
                                            website=draft.website)
    if blocked:
        raise DoNotContact(blocked.sentence())

    try:
        with transaction.atomic():
            return SentLead.objects.create(
                status=SentLead.Status.SENDING,
                owner=owner,
                recontact=draft.force_contact,
                recontact_reason=draft.force_reason if draft.force_contact else "",
                sender_account=sender_account,
                # Falls back to the campaign's address, which is what a
                # deployment with no email accounts configured sends from.
                sender_email=(sender_email
                              or (draft.campaign.sender_email
                                  if draft.campaign_id else "")),
                **draft.as_history_kwargs()
            )
    except IntegrityError:
        if draft.force_contact:
            # The per-campaign re-contact constraint fired: this campaign has
            # already reserved this address once.
            raise AlreadyContacted(
                f"{draft.email} has already been re-contacted in this campaign."
            ) from None
        existing = (
            SentLead.objects
            .filter(owner=owner, email__iexact=draft.email, recontact=False)
            .exclude(status=SentLead.Status.FAILED)
            .first()
        )
        if existing is None:
            # The constraint fired but the row is gone -- a concurrent failure
            # released it between the insert and this lookup. Treat as taken;
            # the next run can retry cleanly.
            raise AlreadyContacted("That address was being sent to concurrently.")
        when = existing.sent_date.isoformat() if existing.sent_date else "earlier"
        raise AlreadyContacted(
            f"{draft.email} already has a {existing.get_status_display().lower()} "
            f"record from {when} ({existing.campaign_label or 'an earlier campaign'})."
        ) from None


def blocked_reason(draft: EmailDraft) -> str:
    """A read-only check for the UI. reserve() is what actually protects."""
    owner = draft.campaign.owner if draft.campaign_id else None
    blocked = SuppressionIndex(owner).match(email=draft.email,
                                            website=draft.website)
    if blocked:
        return blocked.sentence()

    match = Index(owner).match(
        email=draft.email, website=draft.website,
        business_name=draft.business_name, city=draft.city,
    )
    if match is None:
        return ""
    return (f"Already contacted — {MATCH_LABELS.get(match.matched_by, match.matched_by)}"
            f"{', ' + match.sent_date if match.sent_date else ''}")


def mark_campaign_duplicates(campaign: Campaign) -> int:
    """Move uncontactable drafts out of the workflow. Returns how many.

    Covers both rules: suppressed addresses become `suppressed`, and
    already-contacted ones become `duplicate`. A draft carrying an explicit
    `force_contact` is exempt from the second but never from the first.
    """
    index = Index(campaign.owner)
    blocklist = SuppressionIndex(campaign.owner)
    moved = 0
    for draft in campaign.drafts.filter(
        status__in=(EmailDraft.Status.PENDING, EmailDraft.Status.APPROVED,
                    EmailDraft.Status.GENERATED, EmailDraft.Status.CRAWLED,
                    EmailDraft.Status.ANALYSED)
    ):
        blocked = blocklist.match(email=draft.email, website=draft.website)
        if blocked:
            EmailDraft.objects.filter(pk=draft.pk).update(
                status=EmailDraft.Status.SUPPRESSED,
                error_message=blocked.sentence(),
            )
            moved += 1
            continue

        if draft.force_contact:
            continue

        match = index.match(
            email=draft.email, website=draft.website,
            business_name=draft.business_name, city=draft.city,
        )
        if match is None:
            continue
        EmailDraft.objects.filter(pk=draft.pk).update(
            status=EmailDraft.Status.DUPLICATE,
            error_message=(
                f"Skipped: already contacted ({MATCH_LABELS.get(match.matched_by)})"
                + (f" on {match.sent_date}" if match.sent_date else "")
                + (f" in {match.campaign_label}" if match.campaign_label else "")
            ),
        )
        moved += 1
    return moved


# --------------------------------------------------------------------------- #
# Excel export
# --------------------------------------------------------------------------- #

def excel_path(owner=None):
    """One workbook per user.

    A single shared file would put one account's prospect list in another's
    download. The owner's id is in the name rather than their email, so the
    filename does not carry personal data.
    """
    if owner is None or not getattr(owner, "pk", None):
        return settings.EXPORT_DIR / EXCEL_NAME
    stem, _, suffix = EXCEL_NAME.rpartition(".")
    return settings.EXPORT_DIR / f"{stem}_{owner.pk}.{suffix}"


def _row_values(row: SentLead) -> list:
    return [
        str(row.uid),
        row.business_name,
        row.email,
        row.website,
        row.country,
        row.city,
        row.campaign_label,
        str(row.campaign_id) if row.campaign_id else "",
        row.sent_date.isoformat() if row.sent_date else "",
        row.sent_time.strftime("%H:%M:%S") if row.sent_time else "",
        row.subject,
        row.get_status_display(),
        row.error_message,
    ]


def export_excel(owner=None, force: bool = False) -> dict:
    """Append new history rows to exports/sent_leads.xlsx.

    Genuinely appends: the first column carries the database row id, so an
    existing sheet is read, the ids already present are skipped, and only new
    rows are written. Nothing previously exported is touched, and running it
    twice adds nothing the second time.
    """
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    path = excel_path(owner)
    path.parent.mkdir(parents=True, exist_ok=True)

    workbook = None
    existing_ids: set[str] = set()

    if path.exists() and not force:
        try:
            workbook = load_workbook(path)
            sheet = workbook.active
            header = [c.value for c in sheet[1]] if sheet.max_row else []
            if header[:1] != [HEADERS[0]]:
                # Not a sheet we wrote. Start a new one rather than corrupt it.
                workbook = None
            else:
                for row in sheet.iter_rows(min_row=2, max_col=1,
                                           values_only=True):
                    if row[0]:
                        existing_ids.add(str(row[0]))
        except Exception as exc:  # noqa: BLE001 - a damaged file must not stop a send
            log.warning("could not read %s (%s) -- rebuilding", path, exc)
            workbook = None

    if workbook is None:
        workbook = Workbook()
        sheet = workbook.active
        sheet.title = "Sent leads"
        sheet.append(list(HEADERS))
        header_fill = PatternFill("solid", fgColor="5A45D7")
        for index, _name in enumerate(HEADERS, start=1):
            cell = sheet.cell(row=1, column=index)
            cell.font = Font(bold=True, color="FFFFFF", size=10)
            cell.fill = header_fill
            cell.alignment = Alignment(vertical="center")
        sheet.freeze_panes = "A2"
        widths = (10, 34, 30, 30, 16, 18, 26, 34, 12, 10, 46, 10, 40)
        for index, width in enumerate(widths, start=1):
            sheet.column_dimensions[get_column_letter(index)].width = width
        existing_ids = set()
    else:
        sheet = workbook.active

    rows = (
        SentLead.objects
        .filter(owner=owner)
        .exclude(status=SentLead.Status.SENDING)
        .order_by("pk")
    )
    added = 0
    stamped: list[int] = []
    for row in rows:
        if str(row.uid) in existing_ids:
            continue
        sheet.append(_row_values(row))
        stamped.append(row.pk)
        added += 1

    workbook.save(path)

    if stamped:
        SentLead.objects.filter(pk__in=stamped).update(exported_at=timezone.now())

    return {"path": str(path), "added": added, "total": sheet.max_row - 1}


def stats(owner=None) -> dict:
    """Headline history figures for one user's settings screen."""
    mine = SentLead.objects.filter(owner=owner)
    return {
        "sent": mine.filter(status=SentLead.Status.SENT).count(),
        "failed": mine.filter(status=SentLead.Status.FAILED).count(),
        "in_flight": mine.filter(status=SentLead.Status.SENDING).count(),
        "domains": (
            mine.filter(status=SentLead.Status.SENT)
            .exclude(domain="").values("domain").distinct().count()
        ),
        "excel": str(excel_path(owner)),
        "excel_exists": excel_path(owner).exists(),
        "suppressed": Suppression.objects.filter(owner=owner).count(),
        "recontacts": mine.filter(recontact=True).count(),
    }
