"""
Campaign status transitions, and the figures a dashboard shows.

Status is the operator's decision -- active, paused, stopped -- and lives here
rather than in a view so that the follow-up worker, the send path and the screen all
ask the same question and get the same answer.

The rule that matters (§5, §22): **only an ACTIVE campaign sends anything.** Pausing
stops new sends and stops the follow-up worker touching it, and changes nothing
else: every sent record, every scheduled follow-up and every reply stays exactly
where it was, so resuming continues rather than restarts.
"""

from __future__ import annotations

from django.utils import timezone

from apps.outreach.models import Campaign, EmailDraft, FollowUp, ReplyState, SentLead


class TransitionError(RuntimeError):
    """The campaign cannot go from where it is to where you asked."""


#: Which statuses a campaign may be moved *from*, keyed by where it is going.
#: Written out rather than inferred, because "resume a completed campaign" and
#: "pause a draft" are the kind of thing that quietly half-works when the rules are
#: implicit. Every status appears as a key: a destination missing from this table
#: would be reachable from anywhere, which is how a finished campaign ends up back
#: in draft with its sent history still attached.
ALLOWED = {
    # Nothing that has started sending can go back to being unstarted. The one
    # exception is un-scheduling, which is a cancelled intention, not a rollback.
    Campaign.Status.DRAFT: (Campaign.Status.SCHEDULED,),
    Campaign.Status.SCHEDULED: (Campaign.Status.DRAFT, Campaign.Status.ACTIVE,
                                Campaign.Status.PAUSED,
                                Campaign.Status.STOPPED),
    Campaign.Status.ACTIVE: (Campaign.Status.DRAFT, Campaign.Status.SCHEDULED,
                             Campaign.Status.PAUSED, Campaign.Status.STOPPED,
                             Campaign.Status.COMPLETED,
                             Campaign.Status.FAILED),
    Campaign.Status.PAUSED: (Campaign.Status.ACTIVE, Campaign.Status.SCHEDULED,
                             Campaign.Status.COMPLETED,
                             Campaign.Status.FAILED),
    Campaign.Status.STOPPED: (Campaign.Status.ACTIVE, Campaign.Status.PAUSED,
                              Campaign.Status.SCHEDULED, Campaign.Status.DRAFT,
                              Campaign.Status.FAILED),
    # Both are outcomes the machinery reaches, not controls a person presses, so
    # they are only reachable from a campaign that was actually running.
    Campaign.Status.COMPLETED: (Campaign.Status.ACTIVE, Campaign.Status.PAUSED),
    Campaign.Status.FAILED: (Campaign.Status.ACTIVE, Campaign.Status.PAUSED,
                             Campaign.Status.SCHEDULED),
}

#: How each transition reads to a person.
WORDING = {
    Campaign.Status.ACTIVE: (
        "Active. New sends and follow-up preparation are allowed again, "
        "continuing from where it stopped -- nothing already sent is repeated."),
    Campaign.Status.PAUSED: (
        "Paused. No further emails will be sent and no follow-ups will be "
        "prepared. Everything already sent, scheduled or replied to is kept."),
    Campaign.Status.STOPPED: (
        "Stopped. Nothing further will be sent. The history is kept, and it can "
        "be reactivated if that turns out to be wrong."),
    Campaign.Status.COMPLETED: "Completed.",
}


#: The controls §22 asks for, as (action, destination). `activate` and `resume` are
#: the same transition under two names -- the same thing to the database, and
#: different things to a person: one is "start this", the other "carry on".
CONTROLS = (
    ("activate", Campaign.Status.ACTIVE),
    ("pause", Campaign.Status.PAUSED),
    ("stop", Campaign.Status.STOPPED),
)

#: What "activate" is called, given where the campaign is now. A stopped campaign
#: being switched back on is not the same event as one starting for the first time,
#: and a button that says "Activate" on both reads as a mistake in one of them.
ACTIVATE_LABEL = {
    Campaign.Status.PAUSED: ("resume", "Resume"),
    Campaign.Status.STOPPED: ("resume", "Reactivate"),
    Campaign.Status.COMPLETED: ("resume", "Reopen"),
    Campaign.Status.FAILED: ("resume", "Try again"),
}

CONTROL_LABELS = {"pause": "Pause", "stop": "Stop"}

#: What each control will do, in one line, for the button's tooltip. The same
#: promises `WORDING` makes after the fact, phrased before it.
CONTROL_HINTS = {
    "activate": "Allow this campaign to send and to prepare follow-ups.",
    "resume": "Carry on from where it stopped. Nothing already sent is repeated.",
    "pause": "Stop new sends and follow-up preparation. Everything already sent, "
             "scheduled or replied to is kept.",
    "stop": "Stop this campaign for good. The history is kept, and it can be "
            "reactivated if that turns out to be wrong.",
}


def controls(campaign: Campaign) -> list[dict]:
    """The controls that would actually work on this campaign right now.

    Read from `ALLOWED`, so a button is only ever offered for a transition
    `set_status` would accept. Offering one it would refuse is worse than offering
    nothing: the person presses it, gets an error, and learns not to trust the row.
    """
    offered = []
    for action, destination in CONTROLS:
        if campaign.status == destination:
            continue
        if campaign.status not in ALLOWED.get(destination, ()):
            continue
        name, label = action, CONTROL_LABELS.get(action, action.title())
        if action == "activate":
            name, label = ACTIVATE_LABEL.get(campaign.status, (action, "Activate"))
        offered.append({
            "action": name,
            "label": label,
            "hint": CONTROL_HINTS.get(name, ""),
            "danger": name == "stop",
        })
    return offered


def set_status(campaign: Campaign, status: str, *, note: str = "") -> Campaign:
    """Move a campaign to a new status, or refuse with a reason.

    Refusing is the useful part. "Resume" on a campaign that was never started
    means something different from "resume" on a paused one, and a transition table
    is how that stays true as more statuses arrive.
    """
    if status not in dict(Campaign.Status.choices):
        raise TransitionError(f"{status!r} is not a campaign status.")

    if campaign.status == status:
        return campaign          # idempotent: pressing Pause twice is not an error

    allowed = ALLOWED.get(status, ())
    if campaign.status not in allowed:
        raise TransitionError(
            f"A {campaign.get_status_display().lower()} campaign cannot be moved "
            f"to {dict(Campaign.Status.choices)[status].lower()}."
        )

    Campaign.objects.filter(pk=campaign.pk).update(
        status=status,
        status_note=note[:300],
        status_changed_at=timezone.now(),
    )
    campaign.refresh_from_db(
        fields=["status", "status_note", "status_changed_at"])
    return campaign


def dashboard(campaign: Campaign) -> dict:
    """The figures from §21, for one campaign.

    Counted from the tables rather than kept as counters. A counter beside the data
    is a second answer waiting to disagree with it, and these numbers are the ones
    somebody uses to decide whether the campaign is working.
    """
    drafts = campaign.drafts
    leads = SentLead.objects.filter(campaign=campaign)
    followups = FollowUp.objects.filter(campaign=campaign)

    sent = leads.filter(status=SentLead.Status.SENT)
    replied = sent.filter(reply_state=ReplyState.REPLIED)

    return {
        "leads": drafts.count(),
        "initial_sent": sent.count(),
        "awaiting_reply": sent.filter(
            reply_state=ReplyState.NO_REPLY).count(),
        "followups_ready": followups.filter(
            status__in=FollowUp.REVIEWABLE).count(),
        "followups_sent": followups.filter(
            status=FollowUp.Status.SENT).count(),
        "followups_skipped": followups.filter(
            status=FollowUp.Status.SKIPPED).count(),
        "replies": replied.count(),
        "bounced": sent.filter(
            reply_state=ReplyState.BOUNCED).count(),
        "opted_out": sent.filter(
            reply_state=ReplyState.UNSUBSCRIBED).count(),
        "failed": (drafts.filter(status=EmailDraft.Status.FAILED).count()
                   + leads.filter(status=SentLead.Status.FAILED).count()),
        # A conversation is complete once they answered: there is nothing left for
        # the machinery to do, and a follow-up would be wrong.
        "completed": replied.count(),
        "suppressed": drafts.filter(
            status=EmailDraft.Status.SUPPRESSED).count(),
    }
