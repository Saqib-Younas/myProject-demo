"""Where the decisions are.
from apps.outreach.services import intelligence
from apps.outreach.services import history

    campaigns.py     status transitions, and the figures a dashboard shows
    history.py       who has been contacted, and the reservation that stops a second
    intelligence.py  applying scores and classifications to a lead
    pipeline.py      one lead: crawl -> review -> score -> write -> send
    websiteaudit.py  the submitted-URL workflow, from validation to a draft
    automation/      unattended campaigns: schedule, prospects, worker

A view calls into here and renders the answer. Nothing in a view decides anything, and
nothing here knows about an `HttpRequest`."""
