"""
Preparing the follow-ups that have come due. Sending none of them.

This was the body of the `process_followups` management command, and it moved here for
a reason worth recording: the automation runner already needed it, and the only way to
reach it was to instantiate a `BaseCommand` and call an underscore method on it. The
command's `__init__` carried a docstring explaining that its output helpers had to be
set up eagerly *because a service calls into it* -- which is the sound a layer makes
when it is the wrong way round. Now the command and the runner both call the same
functions, and neither owns them.

**The division of labour, unchanged.** Everything expensive happens here -- the
eligibility checks, the claim, the AI call, the draft. Nothing here sends. A prepared
follow-up sits at DUE until a person opens the Follow-ups screen, reads what was
written and presses Send. The worker exists so nobody has to keep a browser open
waiting on a 48-hour timer, not so nobody has to read the email before it goes to a
stranger.

**Idempotent.** Two workers at once, or one cron run overlapping the last, must not
produce two drafts or two sends for the same schedule. `claim` is a conditional UPDATE:
only the worker that observes the row in its previous state may move it on, and the
loser skips. Where there is no row to claim, creation races on the unique constraint
over (lead, number) and exactly one insert wins. The database decides, not the timing.

**What it says out loud.** Nothing here writes to a terminal. Each lead produces an
`Outcome` carrying a sentence written for a person, and the caller decides whether that
sentence goes to stdout, into a campaign's event log, or nowhere. That is what let the
runner stop pretending to be a management command.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from django.db import models, transaction
from django.utils import timezone

from apps import ai
from apps.outreach.mail import accounts as mailaccounts
from apps.outreach.mail import followups as followup_rules
from apps.outreach.models import FollowUp, SentLead

log = logging.getLogger(__name__)

#: How many attempts a single follow-up gets before it is left alone. A failure that
#: repeats is a failure, and the alternative is drafting the same email every fifteen
#: minutes for a week.
MAX_ATTEMPTS = 3

#: Rows that stand for a follow-up which has not happened yet, and whose number the
#: next run therefore takes over rather than stepping past: a schedule written at send
#: time, a window that opened while something was in the way, and an attempt that did
#: not get there.
UNSPENT = (FollowUp.Status.WAITING, FollowUp.Status.SKIPPED, FollowUp.Status.FAILED)


@dataclass(frozen=True)
class Halt:
    """A reason not to prepare a follow-up, and whether it needs writing down."""

    reason: str
    record: bool = True


@dataclass(frozen=True)
class Outcome:
    """What happened to one lead, and the sentence that explains it.

    `result` is one of `prepared`, `skipped` or `failed` -- the three things a run can
    do with a lead, and the keys the caller counts. `note` is the reason, written for
    whoever reads it rather than for a log parser. `bad` marks the outcomes a terminal
    should colour red; a skip is ordinary and a failure is not.
    """

    label: str
    number: int
    result: str
    note: str = ""
    bad: bool = False

    def line(self) -> str:
        """One line, the way the command has always printed it."""
        return f"{self.label} (follow-up {self.number}): {self.note or self.result}"


def counts(outcomes: list[Outcome]) -> dict[str, int]:
    """The four figures a run reports."""
    tally = {"prepared": 0, "skipped": 0, "failed": 0, "considered": len(outcomes)}
    for outcome in outcomes:
        if outcome.result in tally:
            tally[outcome.result] += 1
    return tally


# --------------------------------------------------------------------------- #
# Who and what is due
# --------------------------------------------------------------------------- #

def owners_with_history() -> list:
    """Every account that could have a follow-up due.

    Only accounts that have actually sent something can, so the rest are not worth
    waking the AI for.
    """
    from django.contrib.auth import get_user_model

    return list(get_user_model().objects.filter(
        sent_leads__isnull=False).distinct())


def owner_named(identifier: str):
    """The account with this email or username, or None."""
    from django.contrib.auth import get_user_model

    model = get_user_model()
    return (model.objects.filter(email__iexact=identifier).first()
            or model.objects.filter(username__iexact=identifier).first())


def due_leads(owner, limit: int) -> list[SentLead]:
    """Leads whose next follow-up window has opened.

    The eligibility rules live in `mail.followups.eligibility` and are shared with the
    screen, so the worker and the page cannot disagree about what "due" means. This
    only narrows the set the database has to hand over.
    """
    candidates = (
        SentLead.objects
        .filter(owner=owner, status=SentLead.Status.SENT)
        .select_related("draft", "campaign")
        .order_by("reserved_at")
    )

    blocklist = followup_rules.blocklist_for(owner)
    due: list[SentLead] = []
    for lead in candidates.iterator(chunk_size=200):
        if followup_rules.eligibility(lead, blocklist=blocklist).eligible:
            due.append(lead)
        if len(due) >= limit:
            break
    return due


# --------------------------------------------------------------------------- #
# One follow-up
# --------------------------------------------------------------------------- #

def prepare_one(owner, lead: SentLead, *, dry_run: bool = False) -> Outcome:
    """Check, draft and mark one follow-up due."""
    number = next_number(lead)
    label = f"  {lead.business_name or lead.email}"

    stopped = halted(lead)
    if stopped:
        if stopped.record and not dry_run:
            record_skip(owner, lead, number, stopped.reason)
        return Outcome(label, number, "skipped", f"skipped -- {stopped.reason}")

    if dry_run:
        return Outcome(label, number, "prepared", "would prepare")

    followup = claim(owner, lead, number)
    if followup is None:
        # Another worker took it between the query and the claim. Not an error --
        # the whole point of the claim is that this is survivable.
        return Outcome(label, number, "skipped", "already being prepared elsewhere")

    try:
        write(followup, lead)
    except Exception as exc:                     # noqa: BLE001
        record_failure(followup, exc)
        return Outcome(label, number, "failed", f"failed -- {exc}", bad=True)

    return Outcome(label, number, "prepared", "ready to review")


def halted(lead: SentLead) -> Halt | None:
    """Why this follow-up must not be prepared, or None.

    The checks in the order that costs least: the cheap database facts before anything
    that would call an AI provider. Reply and opt-out are already covered by
    `mail.followups.eligibility`; these are the ones it does not know about, because
    they belong to the campaign and the sending account rather than to the lead.

    `record` says whether the reason is worth a row. It is when nothing in the table
    would otherwise explain the silence, and it is not when a row already says the same
    thing -- writing "one is already waiting" beside the one that is waiting adds a
    second answer to a question already answered, and the worker runs often enough for
    that to accumulate.
    """
    campaign = lead.campaign
    # `may_follow_up`, not `may_send`: a completed campaign may not contact anybody
    # new, and still owes a follow-up to the people it already emailed.
    if campaign is not None and not campaign.may_follow_up:
        return Halt(f"the campaign is {campaign.get_status_display().lower()}"
                    + (f" ({campaign.status_note})" if campaign.status_note else ""))

    if campaign is not None:
        selected = mailaccounts.for_campaign(campaign)
        if selected and not mailaccounts.sending_accounts(campaign):
            return Halt("no active sending account is available")

    if lead.followups.filter(
            status__in=(FollowUp.Status.PROCESSING, FollowUp.Status.SENDING,
                        FollowUp.Status.DUE, FollowUp.Status.DRAFT)).exists():
        return Halt("one is already waiting to be reviewed", record=False)

    recent = lead.followups.order_by("-created_at").first()
    if recent is not None and recent.attempts >= MAX_ATTEMPTS:
        # The failed row carries the error already.
        return Halt(f"the last one failed {recent.attempts} times -- left alone "
                    "until somebody looks at it", record=False)

    return None


def next_number(lead: SentLead) -> int:
    """Which follow-up this would be.

    The lowest unspent number where there is one -- stepping over it would strand that
    row, and the unique constraint would then read every later attempt at that number
    as "another worker has it", forever.

    Otherwise one past the highest number on record. A cancelled row is not on the
    record: cancelling frees the number deliberately.
    """
    unspent = lead.followups.filter(status__in=UNSPENT).order_by("number").first()
    if unspent is not None:
        return unspent.number

    highest = lead.followups.exclude(
        status=FollowUp.Status.CANCELLED).order_by("-number").first()
    return (highest.number + 1) if highest is not None else 1


@transaction.atomic
def claim(owner, lead: SentLead, number: int):
    """Take the row into PROCESSING, or return None if somebody else has it.

    Exactly one worker may act on one schedule, two ways round the same rule:

      * an unspent row (scheduled, skipped or failed) is claimed by a conditional
        UPDATE, which only the worker that observes it in that state can win;
      * with no such row, creation races on the unique constraint over (lead, number),
        and exactly one insert succeeds.

    The database decides in both cases, not the timing.
    """
    from django.db import IntegrityError

    taken = FollowUp.objects.filter(
        lead=lead, number=number, status__in=UNSPENT,
    ).update(
        status=FollowUp.Status.PROCESSING,
        attempts=models.F("attempts") + 1,
        last_attempt_at=timezone.now(),
    )
    if taken:
        # A reused row carries its own history: the skip reason or the error from last
        # time is cleared, because it is about to be tried again and a stale reason
        # beside a fresh attempt reads as the current one.
        FollowUp.objects.filter(lead=lead, number=number).update(
            skip_reason="", error_message="", sender_account=account_for(lead))
        return lead.followups.filter(number=number).first()
    if lead.followups.filter(number=number).exclude(
            status=FollowUp.Status.CANCELLED).exists():
        # A row exists in some other state: another worker claimed the schedule
        # between the check and here.
        return None

    try:
        return FollowUp.objects.create(
            lead=lead,
            owner=owner,
            campaign=lead.campaign,
            campaign_label=lead.campaign_label,
            number=number,
            email=lead.email,
            subject="",
            body="",
            status=FollowUp.Status.PROCESSING,
            scheduled_for=timezone.now(),
            attempts=1,
            last_attempt_at=timezone.now(),
            sender_account=account_for(lead),
        )
    except IntegrityError:
        return None


def account_for(lead: SentLead):
    """Which account should send it: the one that sent the original."""
    if lead.sender_account_id:
        return lead.sender_account
    campaign = lead.campaign
    if campaign is None:
        return None
    usable = mailaccounts.sending_accounts(campaign)
    return usable[0] if usable else None


def write(followup: FollowUp, lead: SentLead) -> None:
    """Draft the follow-up and leave it for a person.

    The AI sees the original email and everything since, because a follow-up that
    ignores what was already said is worse than none.
    """
    history = followup_rules.conversation(lead)
    draft = lead.draft

    email = ai.follow_up(
        business_name=lead.business_name,
        category=draft.category if draft else "",
        city=lead.city,
        country=lead.country,
        website=lead.website,
        original_subject=lead.subject,
        original_body=draft.body if draft else "",
        observation=draft.observation if draft else "",
        findings=draft.finding_objects if draft else [],
        days_since=followup_rules.days_since(lead),
        number=followup.number,
        sender_name=sender_name(followup, lead),
        sender_company=(lead.campaign.sender_company if lead.campaign_id else ""),
        sender_email=(followup.sender_account.sender_email
                      if followup.sender_account_id
                      else (lead.sender_email or "")),
        service_pitch=(lead.campaign.service_pitch if lead.campaign_id else ""),
        conversation=history,
    )

    FollowUp.objects.filter(pk=followup.pk).update(
        subject=email.subject[:400],
        body=email.body,
        status=FollowUp.Status.DUE,
        error_message="",
        # The follow-up belongs in the conversation the first email started.
        in_reply_to=lead.message_id or "",
        references=followup_rules.reference_chain(lead),
    )


def sender_name(followup: FollowUp, lead: SentLead) -> str:
    if followup.sender_account_id and followup.sender_account.sender_name:
        return followup.sender_account.sender_name
    return lead.campaign.sender_name if lead.campaign_id else ""


# --------------------------------------------------------------------------- #
# Outcomes worth a row
# --------------------------------------------------------------------------- #

def record_skip(owner, lead: SentLead, number: int, reason: str) -> None:
    """Write down that this was passed over, and why.

    A skipped follow-up with no record is indistinguishable from a bug, and this is the
    row that answers "why did nothing happen for this lead". Only written once per
    reason -- a campaign paused for a month should not produce a thousand identical
    rows.
    """
    already = lead.followups.filter(
        number=number, status=FollowUp.Status.SKIPPED).first()
    if already is not None:
        if already.skip_reason != reason[:300]:
            FollowUp.objects.filter(pk=already.pk).update(
                skip_reason=reason[:300], last_attempt_at=timezone.now())
        return

    FollowUp.objects.create(
        lead=lead, owner=owner, campaign=lead.campaign,
        campaign_label=lead.campaign_label, number=number,
        email=lead.email, subject="", body="",
        status=FollowUp.Status.SKIPPED,
        skip_reason=reason[:300],
        scheduled_for=timezone.now(),
        last_attempt_at=timezone.now(),
    )


def record_failure(followup: FollowUp, error: Exception) -> None:
    """Record a failed preparation, bounded by MAX_ATTEMPTS.

    The row stays FAILED rather than being deleted: the next run reads `attempts` and
    stops trying once it has tried enough, which is what stops a broken lead consuming
    an AI call every fifteen minutes forever.
    """
    message = str(error)[:300]
    log.warning("follow-up %s could not be prepared: %s", followup.pk, message)
    FollowUp.objects.filter(pk=followup.pk).update(
        status=FollowUp.Status.FAILED,
        error_message=message,
        last_attempt_at=timezone.now(),
    )
