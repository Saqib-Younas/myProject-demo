from django.apps import AppConfig


class OutreachConfig(AppConfig):
    name = "apps.outreach"
    verbose_name = "Email outreach"
    default_auto_field = "django.db.models.BigAutoField"

    def ready(self) -> None:
        """Give the website reader the same contact address as the scraper.

        Anything we fetch should carry a way to reach whoever is running it, so
        a site owner who wants to be left alone has somebody to tell.
        """
        from django.conf import settings

        from apps.auditing import crawler

        crawler.CONTACT = settings.OSM_CONTACT_EMAIL
