"""
Pagination, campaign status, the follow-up worker, and threading.

Four features, one file, because they only matter together: the worker prepares
follow-ups, the campaign's status decides whether it may, threading decides whether
the result reads as a conversation, and pagination decides whether anybody can find
any of it.

The rules that carry weight here:

  * **20 per page, and the count is real.** The slices this replaced silently
    omitted records -- worse than a visible limit.
  * **Only an ACTIVE campaign sends.** Paused stops the send path *and* the worker,
    and changes nothing else.
  * **The worker prepares; a person sends.** It drafts, checks and marks DUE. There
    is no code path in it that opens SMTP, and a test asserts that.
  * **One schedule, at most one send.** Two workers racing produce one draft.

Nothing here opens a socket or calls a provider.
"""

from __future__ import annotations

from datetime import timedelta
from unittest import mock

from django.core.management import call_command
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from apps import ai
from apps.core import paging
from apps.core.testing import EMAIL_BODY, OtherUser, SignedIn
from apps.outreach.mail import accounts as mailaccounts
from apps.outreach.mail import compose, followups, transport
from apps.outreach.models import Campaign, EmailDraft, FollowUp, ReplyState, SentLead
from apps.outreach.services import campaigns
from apps.outreach.services import followups as followup_service
from apps.outreach.services import pipeline as runner

from .factories import make_campaign, make_draft


def sent_lead(owner, campaign=None, *, email="lead@example.test", days_ago=3,
              **fields) -> SentLead:
    """A lead that was emailed `days_ago` days ago and never replied."""
    draft = fields.pop("draft", None)
    lead = SentLead.objects.create(
        owner=owner, campaign=campaign, email=email,
        business_name=fields.pop("business_name", "Bella Cucina"),
        subject="A few things I noticed on your website",
        status=SentLead.Status.SENT,
        message_id=fields.pop("message_id", "<first@bella.example>"),
        draft=draft,
        **fields)
    when = timezone.now() - timedelta(days=days_ago)
    SentLead.objects.filter(pk=lead.pk).update(
        reserved_at=when, sent_at=when, sent_date=when.date())
    lead.refresh_from_db()
    return lead


# --------------------------------------------------------------------------- #
# Sections 6 and 7
# --------------------------------------------------------------------------- #

class PaginationHelperTests(TestCase):
    def _request(self, query=""):
        from django.test import RequestFactory

        return RequestFactory().get(f"/?{query}")

    def test_twenty_per_page_by_default(self):
        self.assertEqual(paging.DEFAULT_PAGE_SIZE, 20)
        self.assertEqual(paging.page_size(self._request()), 20)

    def test_the_offered_sizes_are_honoured(self):
        for size in (20, 50, 100):
            with self.subTest(size=size):
                self.assertEqual(
                    paging.page_size(self._request(f"per_page={size}")), size)

    def test_an_unoffered_size_falls_back_to_the_default(self):
        """Otherwise `?per_page=100000` is an unbounded query with extra steps."""
        for query in ("per_page=5000", "per_page=abc", "per_page=-1",
                      "per_page="):
            with self.subTest(query=query):
                self.assertEqual(paging.page_size(self._request(query)), 20)

    def test_a_nonsense_page_number_lands_on_page_one(self):
        page, _paginator = paging.paginate(
            self._request("page=nonsense"), list(range(50)))

        self.assertEqual(page.number, 1)

    def test_a_page_past_the_end_lands_on_the_last_page(self):
        """A stale bookmark after rows were deleted should show something."""
        page, paginator = paging.paginate(
            self._request("page=9999"), list(range(50)))

        self.assertEqual(page.number, paginator.num_pages)

    def test_the_filters_survive_a_page_change(self):
        """Losing the filter on page 2 is what makes pagination feel broken."""
        query = paging.preserved_query(
            self._request("q=delft&priority=hot&page=3"))

        self.assertIn("q=delft", query)
        self.assertIn("priority=hot", query)
        self.assertNotIn("page=3", query)
        self.assertTrue(query.endswith("&"))

    def test_a_long_list_does_not_print_every_page_number(self):
        page, paginator = paging.paginate(
            self._request("page=50"), list(range(2000)))
        numbers = paging.window(page, paginator)

        self.assertIn(1, numbers)
        self.assertIn(100, numbers)
        self.assertIn(50, numbers)
        self.assertIn(None, numbers)              # the gap
        self.assertLess(len(numbers), 15)

    def test_the_summary_counts_from_one(self):
        context = paging.page_context(
            self._request("page=2"), list(range(47)), label="campaigns")

        self.assertEqual(context["summary"], "Showing 21–40 of 47 campaigns")

    def test_an_empty_list_says_so(self):
        context = paging.page_context(self._request(), [], label="leads")

        self.assertEqual(context["summary"], "No leads yet")
        self.assertEqual(context["total"], 0)


class PaginatedPageTests(SignedIn):
    def test_the_campaigns_page_shows_twenty_and_says_the_total(self):
        for index in range(25):
            make_campaign(city=f"City{index}")

        response = self.client.get(reverse("outreach:history"))

        self.assertEqual(len(response.context["rows"]), 20)
        self.assertEqual(response.context["paging"]["total"], 25)
        self.assertContains(response, "Showing 1–20 of 25 campaigns")

    def test_page_two_holds_the_rest(self):
        for index in range(25):
            make_campaign(city=f"City{index}")

        response = self.client.get(reverse("outreach:history") + "?page=2")

        self.assertEqual(len(response.context["rows"]), 5)

    def test_search_narrows_the_total(self):
        make_campaign(city="Delft")
        make_campaign(city="Berlin")

        response = self.client.get(reverse("outreach:history") + "?q=delft")

        self.assertEqual(response.context["paging"]["total"], 1)

    def test_a_status_filter_narrows_the_total(self):
        make_campaign(city="A", status=Campaign.Status.ACTIVE)
        make_campaign(city="B", status=Campaign.Status.PAUSED)

        response = self.client.get(reverse("outreach:history") + "?status=paused")

        self.assertEqual(response.context["paging"]["total"], 1)

    def test_another_workspaces_campaigns_are_never_counted(self):
        make_campaign(city="Mine")
        other = OtherUser()
        make_campaign(city="Theirs", owner=other.user)

        response = self.client.get(reverse("outreach:history"))

        self.assertEqual(response.context["paging"]["total"], 1)

    def test_the_leads_table_paginates(self):
        campaign = make_campaign()
        for index in range(25):
            make_draft(campaign, business_name=f"Shop {index}",
                       email=f"shop{index}@example.test")

        response = self.client.get(reverse("outreach:leads"))

        self.assertEqual(len(response.context["rows"]), 20)
        self.assertEqual(response.context["paging"]["total"], 25)


# --------------------------------------------------------------------------- #
# Section 5 and 22
# --------------------------------------------------------------------------- #

class CampaignStatusTests(SignedIn):
    def test_a_new_campaign_is_active(self):
        """The migration default. Silently pausing existing campaigns would be
        the worst possible choice."""
        self.assertEqual(make_campaign().status, Campaign.Status.ACTIVE)
        self.assertTrue(make_campaign().may_send)

    def test_only_an_active_campaign_may_send(self):
        for status, expected in (
            (Campaign.Status.ACTIVE, True),
            (Campaign.Status.PAUSED, False),
            (Campaign.Status.STOPPED, False),
            (Campaign.Status.DRAFT, False),
            (Campaign.Status.SCHEDULED, False),
            (Campaign.Status.COMPLETED, False),
            (Campaign.Status.FAILED, False),
        ):
            with self.subTest(status=status):
                self.assertEqual(
                    make_campaign(status=status, city=status).may_send, expected)

    def test_pausing_and_resuming(self):
        campaign = make_campaign()

        campaigns.set_status(campaign, Campaign.Status.PAUSED,
                             note="checking the copy")
        self.assertFalse(campaign.may_send)
        self.assertEqual(campaign.status_note, "checking the copy")

        campaigns.set_status(campaign, Campaign.Status.ACTIVE)
        self.assertTrue(campaign.may_send)

    def test_setting_the_same_status_twice_is_not_an_error(self):
        campaign = make_campaign()

        campaigns.set_status(campaign, Campaign.Status.ACTIVE)

        self.assertEqual(campaign.status, Campaign.Status.ACTIVE)

    def test_an_impossible_transition_is_refused_with_a_reason(self):
        campaign = make_campaign(status=Campaign.Status.COMPLETED)

        with self.assertRaises(campaigns.TransitionError) as caught:
            campaigns.set_status(campaign, Campaign.Status.DRAFT)

        self.assertIn("completed", str(caught.exception))

    def test_an_unknown_status_is_refused(self):
        with self.assertRaises(campaigns.TransitionError):
            campaigns.set_status(make_campaign(), "sideways")

    def test_the_endpoint_pauses_and_resumes(self):
        campaign = make_campaign()

        paused = self.client.post(
            reverse("outreach:campaign_status", args=[campaign.id, "pause"]),
            data={"note": "on hold"}, content_type="application/json")

        campaign.refresh_from_db()
        self.assertEqual(paused.status_code, 200)
        self.assertEqual(campaign.status, Campaign.Status.PAUSED)
        self.assertIn("No further emails", paused.json()["message"])

        resumed = self.client.post(
            reverse("outreach:campaign_status", args=[campaign.id, "resume"]),
            data={}, content_type="application/json")

        campaign.refresh_from_db()
        self.assertEqual(resumed.status_code, 200)
        self.assertTrue(campaign.may_send)

    def test_an_unknown_action_is_refused(self):
        campaign = make_campaign()

        response = self.client.post(
            reverse("outreach:campaign_status", args=[campaign.id, "sideways"]),
            data={}, content_type="application/json")

        self.assertEqual(response.status_code, 400)

    def test_another_workspace_cannot_pause_a_campaign(self):
        campaign = make_campaign()
        other = OtherUser()

        response = other.client.post(
            reverse("outreach:campaign_status", args=[campaign.id, "pause"]),
            data={}, content_type="application/json")

        campaign.refresh_from_db()
        self.assertEqual(response.status_code, 404)
        self.assertEqual(campaign.status, Campaign.Status.ACTIVE)

    def test_a_paused_campaign_sends_nothing(self):
        from apps.outreach.services import pipeline as runner

        campaign = make_campaign(phase=Campaign.Phase.REVIEW,
                                 status=Campaign.Status.PAUSED)
        make_draft(campaign, status=EmailDraft.Status.APPROVED)

        runner._send_all(campaign, "pw", "", 0)

        campaign.refresh_from_db()
        self.assertIn("paused", campaign.error.lower())
        self.assertEqual(
            SentLead.objects.filter(status=SentLead.Status.SENT).count(), 0)

    def test_a_paused_campaign_blocks_a_manual_follow_up_send(self):
        """The click is exactly where somebody might not have noticed."""
        campaign = make_campaign(status=Campaign.Status.PAUSED)
        lead = sent_lead(self.user, campaign)
        followup = FollowUp.objects.create(
            lead=lead, owner=self.user, campaign=campaign, number=1,
            email=lead.email, subject="Re: x", body=EMAIL_BODY,
            status=FollowUp.Status.DUE)

        with self.assertRaises(followups.Blocked) as caught:
            followups.check_before_send(followup)

        self.assertIn("paused", str(caught.exception).lower())


class DashboardTests(SignedIn):
    def test_the_figures_come_from_the_tables(self):
        campaign = make_campaign()
        for index in range(4):
            make_draft(campaign, business_name=f"Shop {index}",
                       email=f"shop{index}@example.test")

        replied = sent_lead(self.user, campaign, email="a@example.test",
                            reply_state=ReplyState.REPLIED)
        sent_lead(self.user, campaign, email="b@example.test")
        sent_lead(self.user, campaign, email="c@example.test",
                  reply_state=ReplyState.UNSUBSCRIBED)

        figures = campaigns.dashboard(campaign)

        self.assertEqual(figures["leads"], 4)
        self.assertEqual(figures["initial_sent"], 3)
        self.assertEqual(figures["replies"], 1)
        self.assertEqual(figures["opted_out"], 1)
        self.assertEqual(figures["awaiting_reply"], 1)
        self.assertEqual(figures["completed"], 1)
        self.assertIsNotNone(replied.pk)

    def test_the_endpoint_returns_them(self):
        campaign = make_campaign()

        response = self.client.get(
            reverse("outreach:campaign_dashboard", args=[campaign.id]))

        self.assertEqual(response.status_code, 200)
        self.assertIn("dashboard", response.json())
        self.assertTrue(response.json()["may_send"])


# --------------------------------------------------------------------------- #
# Sections 9 to 20: the worker
# --------------------------------------------------------------------------- #

class WorkerTests(SignedIn):
    """It prepares. It does not send."""

    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(self.campaign, subject="A few things I noticed",
                                body=EMAIL_BODY)
        self.lead = sent_lead(self.user, self.campaign, draft=self.draft)

    def _run(self, **kwargs):
        written = ai.GeneratedEmail(
            "Re: A few things I noticed on your website",
            "Hi again,\n\nJust following up on the booking link.\n\nSam",
            "the booking link", ["AUD-001"])
        with mock.patch.object(ai, "follow_up", return_value=written) as write:
            call_command("process_followups", verbosity=0, **kwargs)
        return write

    def test_a_due_follow_up_is_prepared_and_left_for_review(self):
        self._run()

        followup = FollowUp.objects.get()
        self.assertEqual(followup.status, FollowUp.Status.DUE)
        self.assertEqual(followup.number, 1)
        self.assertTrue(followup.body)

    def test_it_sends_nothing(self):
        """The whole division of labour, asserted rather than assumed."""
        with mock.patch.object(transport.Session, "__enter__") as connect:
            self._run()

        connect.assert_not_called()
        self.assertEqual(
            FollowUp.objects.filter(status=FollowUp.Status.SENT).count(), 0)

    def test_a_dry_run_writes_nothing(self):
        with mock.patch.object(ai, "follow_up") as write:
            call_command("process_followups", dry_run=True, verbosity=0)

        write.assert_not_called()
        self.assertEqual(FollowUp.objects.count(), 0)

    def test_a_lead_that_replied_is_left_alone(self):
        SentLead.objects.filter(pk=self.lead.pk).update(
            reply_state=ReplyState.REPLIED)

        write = self._run()

        write.assert_not_called()
        self.assertEqual(
            FollowUp.objects.filter(status=FollowUp.Status.DUE).count(), 0)

    def test_a_lead_that_opted_out_is_left_alone(self):
        SentLead.objects.filter(pk=self.lead.pk).update(
            reply_state=ReplyState.UNSUBSCRIBED)

        write = self._run()

        write.assert_not_called()

    def test_a_bounced_address_is_left_alone(self):
        SentLead.objects.filter(pk=self.lead.pk).update(
            reply_state=ReplyState.BOUNCED)

        write = self._run()

        write.assert_not_called()

    def test_a_paused_campaign_stops_the_worker_and_records_why(self):
        campaigns.set_status(self.campaign, Campaign.Status.PAUSED,
                             note="reviewing the copy")

        write = self._run()

        write.assert_not_called()
        skipped = FollowUp.objects.get(status=FollowUp.Status.SKIPPED)
        self.assertIn("paused", skipped.skip_reason)
        self.assertIn("reviewing the copy", skipped.skip_reason)

    def test_a_skip_reason_is_not_written_again_every_run(self):
        """A campaign paused for a month must not produce a thousand rows."""
        campaigns.set_status(self.campaign, Campaign.Status.PAUSED)

        self._run()
        self._run()
        self._run()

        self.assertEqual(
            FollowUp.objects.filter(status=FollowUp.Status.SKIPPED).count(), 1)

    def test_a_window_that_has_not_opened_is_not_prepared(self):
        SentLead.objects.filter(pk=self.lead.pk).update(
            reserved_at=timezone.now(), sent_at=timezone.now(),
            sent_date=timezone.localdate())

        write = self._run()

        write.assert_not_called()

    def test_one_already_waiting_is_not_duplicated(self):
        self._run()
        write = self._run()

        write.assert_not_called()
        self.assertEqual(FollowUp.objects.count(), 1)

    def test_two_workers_racing_produce_one_draft(self):
        """§20. The unique constraint decides, not the timing."""
        from django.db import IntegrityError

        first = self._run()
        self.assertEqual(first.call_count, 1)

        # A second worker that got past the "already waiting" check -- simulated by
        # claiming directly, which is what the constraint has to survive.
        duplicate = followup_service.claim(self.user, self.lead, 1)
        self.assertIsNone(duplicate)
        self.assertEqual(FollowUp.objects.count(), 1)
        self.assertIsNotNone(IntegrityError)

    def test_the_conversation_is_given_to_the_ai(self):
        """§12: a follow-up written without the thread repeats the first email."""
        write = self._run()

        conversation = write.call_args.kwargs["conversation"]
        self.assertTrue(conversation)
        self.assertEqual(conversation[0]["stage"], "the first email")
        self.assertIn(EMAIL_BODY[:40], conversation[0]["body"])

    def test_the_threading_headers_are_recorded(self):
        """§16: the follow-up belongs in the conversation already started."""
        self._run()

        followup = FollowUp.objects.get()
        self.assertEqual(followup.in_reply_to, "<first@bella.example>")
        self.assertIn("<first@bella.example>", followup.references)

    def test_a_failure_is_recorded_and_bounded(self):
        """§19: the same email is not drafted every fifteen minutes forever."""
        from apps.outreach.services.followups import MAX_ATTEMPTS

        with mock.patch.object(ai, "follow_up",
                               side_effect=ai.AiError("provider down")):
            call_command("process_followups", verbosity=0)

        followup = FollowUp.objects.get()
        self.assertEqual(followup.status, FollowUp.Status.FAILED)
        self.assertIn("provider down", followup.error_message)
        self.assertEqual(followup.attempts, 1)
        self.assertLessEqual(followup.attempts, MAX_ATTEMPTS)

    def test_a_repeatedly_failing_follow_up_is_left_alone(self):
        from apps.outreach.services.followups import MAX_ATTEMPTS

        FollowUp.objects.create(
            lead=self.lead, owner=self.user, campaign=self.campaign, number=1,
            email=self.lead.email, subject="", body="",
            status=FollowUp.Status.FAILED, attempts=MAX_ATTEMPTS)

        write = self._run()

        write.assert_not_called()

    def test_only_one_workspaces_leads_are_touched(self):
        other = OtherUser()
        theirs = sent_lead(other.user, email="theirs@example.test")

        self._run(user=self.user.email)

        self.assertEqual(theirs.followups.count(), 0)
        self.assertEqual(self.lead.followups.count(), 1)

    def test_an_unknown_user_is_an_error_not_a_silent_no_op(self):
        from django.core.management.base import CommandError

        with self.assertRaises(CommandError):
            call_command("process_followups", user="nobody@example.test",
                         verbosity=0)

    def test_no_active_sending_account_stops_it(self):
        account = mailaccounts.save_account(
            self.user, name="Sales", sender_name="Sam",
            sender_email="sales@company.test", provider="gmail",
            password="abcd efgh ijkl mnop")
        self.campaign.sending_accounts.set([account])
        mailaccounts.set_active(self.user, account, False)

        write = self._run()

        write.assert_not_called()
        skipped = FollowUp.objects.get(status=FollowUp.Status.SKIPPED)
        self.assertIn("no active sending account", skipped.skip_reason)


class ScheduleTests(SignedIn):
    def test_the_first_window_is_forty_eight_hours(self):
        """§9, with the delay configured to 2 days."""
        campaign = make_campaign()
        lead = sent_lead(self.user, campaign, days_ago=0)

        due = followups.next_due(lead)

        self.assertIsNotNone(due)
        self.assertAlmostEqual(
            (due - (lead.sent_at or lead.reserved_at)).days, 2)

    def test_a_replied_lead_has_no_next_window(self):
        lead = sent_lead(self.user, reply_state=ReplyState.REPLIED)

        self.assertIsNone(followups.next_due(lead))

    def test_the_allowance_runs_out(self):
        lead = sent_lead(self.user)

        self.assertIsNone(
            followups.next_due(lead, number=followups.max_followups() + 1))


class WrittenScheduleTests(SignedIn):
    """§9: the schedule is written when the email goes out.

    A stored date is one answer to "when is this due". Recomputing it wherever it
    is asked for is several, and they drift the moment a delay setting changes.
    """

    def setUp(self):
        self.campaign = make_campaign()
        self.lead = sent_lead(self.user, self.campaign, days_ago=0)

    def test_sending_writes_one_waiting_row_with_its_date(self):
        row = followups.schedule_next(self.lead)

        self.assertIsNotNone(row)
        self.assertEqual(row.status, FollowUp.Status.WAITING)
        self.assertEqual(row.number, 1)
        self.assertEqual(row.scheduled_for, followups.next_due(self.lead))
        self.assertEqual(FollowUp.objects.count(), 1)

    def test_the_row_is_not_a_draft_and_not_reviewable(self):
        """It is a note about the future. Nothing should offer to send it."""
        followups.schedule_next(self.lead)

        self.assertEqual(
            FollowUp.objects.filter(status__in=FollowUp.REVIEWABLE).count(), 0)
        self.assertEqual(
            followups.rows(self.user)[0]["draft"], None)

    def test_writing_it_twice_writes_one_row(self):
        first = followups.schedule_next(self.lead)
        second = followups.schedule_next(self.lead)

        self.assertEqual(first.pk, second.pk)
        self.assertEqual(FollowUp.objects.count(), 1)

    def test_a_replied_lead_gets_no_schedule(self):
        SentLead.objects.filter(pk=self.lead.pk).update(
            reply_state=ReplyState.REPLIED)
        self.lead.refresh_from_db()

        self.assertIsNone(followups.schedule_next(self.lead))
        self.assertEqual(FollowUp.objects.count(), 0)

    def test_a_row_being_reviewed_keeps_its_date(self):
        """Moving a date somebody is acting on is worse than not storing one."""
        row = followups.schedule_next(self.lead)
        original = row.scheduled_for
        FollowUp.objects.filter(pk=row.pk).update(status=FollowUp.Status.DUE)

        again = followups.schedule_next(self.lead)

        self.assertEqual(again.pk, row.pk)
        self.assertEqual(again.scheduled_for, original)

    def test_a_bulk_send_leaves_a_schedule_behind(self):
        """The send path calls it, rather than something else remembering to."""
        from .factories import FakeSession

        draft = make_draft(self.campaign, business_name="Bakery",
                           email="bakery@example.test",
                           status=EmailDraft.Status.APPROVED)
        self.assertTrue(draft.pk)

        with mock.patch.object(transport, "Session", return_value=FakeSession()), \
             mock.patch.object(runner.time, "sleep"):
            runner._send_all(self.campaign, "pw", "", 0)

        lead = SentLead.objects.get(email="bakery@example.test")
        row = lead.followups.get()
        self.assertEqual(row.status, FollowUp.Status.WAITING)
        self.assertEqual(row.scheduled_for, followups.next_due(lead))

    def test_a_send_still_counts_when_the_schedule_cannot_be_written(self):
        """An email that has gone out has gone out. Nothing undoes that."""
        from .factories import FakeSession

        make_draft(self.campaign, business_name="Bakery",
                   email="bakery@example.test",
                   status=EmailDraft.Status.APPROVED)

        with mock.patch.object(transport, "Session", return_value=FakeSession()), \
             mock.patch.object(runner.time, "sleep"), \
             mock.patch.object(followups, "schedule_next",
                               side_effect=RuntimeError("no")):
            runner._send_all(self.campaign, "pw", "", 0)

        self.assertEqual(self.campaign.counts()["sent"], 1)


class UnspentNumberTests(SignedIn):
    """One follow-up number, one row -- reused rather than stepped over.

    The unique constraint on (lead, number) leaves no choice: stepping past a row
    that stands for a follow-up which has not happened strands it, and every later
    attempt at that number then collides with it and reads as "somebody else has
    it" -- forever, with nothing on screen to say why.
    """

    def setUp(self):
        self.campaign = make_campaign()
        self.lead = sent_lead(self.user, self.campaign, days_ago=3)

    def _prepared(self, **kwargs):
        written = ai.GeneratedEmail(
            "Re: A few things I noticed on your website",
            "Hi again,\n\nJust following up on the booking link.\n\nSam",
            "the booking link", ["AUD-001"])
        with mock.patch.object(ai, "follow_up", return_value=written):
            call_command("process_followups", verbosity=0, **kwargs)

    def test_a_written_schedule_is_claimed_not_duplicated(self):
        followups.schedule_next(self.lead)

        self._prepared()

        row = FollowUp.objects.get()
        self.assertEqual(row.status, FollowUp.Status.DUE)
        self.assertEqual(row.number, 1)

    def test_a_skipped_number_is_used_again_once_the_reason_clears(self):
        campaigns.set_status(self.campaign, Campaign.Status.PAUSED)
        self._prepared()
        skipped = FollowUp.objects.get()
        self.assertEqual(skipped.status, FollowUp.Status.SKIPPED)

        campaigns.set_status(self.campaign, Campaign.Status.ACTIVE)
        self._prepared()

        row = FollowUp.objects.get()
        self.assertEqual(row.pk, skipped.pk)
        self.assertEqual(row.number, 1)
        self.assertEqual(row.status, FollowUp.Status.DUE)
        self.assertEqual(row.skip_reason, "")

    def test_a_failed_attempt_is_retried_at_the_same_number(self):
        with mock.patch.object(ai, "follow_up", side_effect=RuntimeError("nope")):
            call_command("process_followups", verbosity=0)
        failed = FollowUp.objects.get()
        self.assertEqual(failed.status, FollowUp.Status.FAILED)

        self._prepared()

        row = FollowUp.objects.get()
        self.assertEqual(row.pk, failed.pk)
        self.assertEqual(row.number, 1)
        self.assertEqual(row.error_message, "")

    def test_a_cancelled_number_is_free_again(self):
        followups.schedule_next(self.lead)
        FollowUp.objects.update(status=FollowUp.Status.CANCELLED)

        self.assertEqual(followup_service.next_number(self.lead), 1)

    def test_a_sent_follow_up_advances_the_number(self):
        row = followups.schedule_next(self.lead)
        FollowUp.objects.filter(pk=row.pk).update(status=FollowUp.Status.SENT)

        self.assertEqual(followup_service.next_number(self.lead), 2)


class ThreadingTests(TestCase):
    """§16: a follow-up belongs in the same conversation."""

    def test_the_headers_are_set_when_supplied(self):
        message = compose.build_message(
            sender_name="Sam", sender_email="sam@agency.test",
            to_email="lead@example.test", subject="Re: a note",
            body="Hello", in_reply_to="<first@agency.test>",
            references="<first@agency.test> <second@agency.test>")

        self.assertEqual(message["In-Reply-To"], "<first@agency.test>")
        self.assertIn("<second@agency.test>", message["References"])

    def test_references_falls_back_to_the_parent(self):
        message = compose.build_message(
            sender_name="Sam", sender_email="sam@agency.test",
            to_email="lead@example.test", subject="Re: a note",
            body="Hello", in_reply_to="<first@agency.test>")

        self.assertEqual(message["References"], "<first@agency.test>")

    def test_a_first_email_carries_no_threading_headers(self):
        message = compose.build_message(
            sender_name="Sam", sender_email="sam@agency.test",
            to_email="lead@example.test", subject="A note", body="Hello")

        self.assertIsNone(message["In-Reply-To"])
        self.assertIsNone(message["References"])

    def test_a_reply_to_is_only_set_when_it_differs(self):
        same = compose.build_message(
            sender_name="Sam", sender_email="sam@agency.test",
            to_email="lead@example.test", subject="s", body="b",
            reply_to="sam@agency.test")
        different = compose.build_message(
            sender_name="Sam", sender_email="sam@agency.test",
            to_email="lead@example.test", subject="s", body="b",
            reply_to="hello@agency.test")

        self.assertIsNone(same["Reply-To"])
        self.assertEqual(different["Reply-To"], "hello@agency.test")

    def test_the_reference_chain_never_invents_an_id(self):
        """A fabricated Message-ID breaks threading rather than fixing it."""
        from apps.core.testing import make_user

        owner = make_user()
        lead = sent_lead(owner, message_id="")

        self.assertEqual(followups.reference_chain(lead), "")
