"""
The screens for sending addresses, campaign controls and the progress figures.

Endpoints for all three existed before any of them were on a page, which is a state
worth testing against: a working endpoint nobody can reach is indistinguishable from
a missing feature, and a page that renders is not the same as a page that renders the
right thing.

What these tests are actually protecting:

  * **No password reaches a browser.** Not the plaintext, not the ciphertext, not on
    the page, not in any JSON. Asserted by looking for them, rather than by trusting
    that no template mentions them.
  * **A control is only offered when it would work.** The buttons come from the same
    transition table `set_status` checks, so a row cannot offer something the server
    would refuse.
  * **The figures are the tables.** Every number on the progress card is counted on
    request, so a test can move a record and watch the figure follow.

Nothing here opens a socket.
"""

from __future__ import annotations

from django.test import TestCase
from django.urls import reverse

from apps.core.testing import OtherUser, SignedIn
from apps.outreach.mail import accounts as mailaccounts
from apps.outreach.models import (
    Campaign,
    EmailAccount,
    EmailDraft,
    FollowUp,
    ReplyState,
    SentLead,
)
from apps.outreach.services import campaigns

from .factories import make_campaign, make_draft
from .test_campaign_ops import sent_lead

PASSWORD = "abcd efgh ijkl mnop"


def account(owner, *, name="Sales", email="james@example.test",
            password=PASSWORD, **fields) -> EmailAccount:
    return mailaccounts.save_account(
        owner, name=name, sender_name="James Wilson", sender_email=email,
        provider="gmail", password=password, **fields)


# --------------------------------------------------------------------------- #
# Sections 1-3: the sending addresses on the settings page
# --------------------------------------------------------------------------- #

class SendingAddressPageTests(SignedIn):
    def setUp(self):
        self.account = account(self.user)
        self.page = self.client.get(reverse("outreach:settings"))
        self.body = self.page.content.decode()

    def test_the_section_is_on_the_page(self):
        self.assertContains(self.page, "Sending addresses")
        self.assertContains(self.page, 'id="email-accounts"')
        self.assertContains(self.page, "accounts.js")

    def test_the_address_is_shown_with_its_capacity(self):
        self.assertIn("Sales", self.body)
        self.assertIn("james@example.test", self.body)
        self.assertIn("Gmail", self.body)
        # The provider's cap, not an invented one.
        self.assertIn(str(mailaccounts.daily_cap(self.account)), self.body)

    def test_no_form_of_the_password_is_on_the_page(self):
        """The one assertion this whole section exists to keep."""
        stored = EmailAccount.objects.get(pk=self.account.pk)

        for secret in (PASSWORD, PASSWORD.replace(" ", ""), stored.secret):
            with self.subTest(secret=secret[:8]):
                self.assertNotIn(secret, self.body)

    def test_the_masked_hint_is_shown_instead(self):
        self.assertIn(self.account.hint, self.body)
        self.assertIn("mnop", self.account.hint)      # the last four, and no more

    def test_another_workspaces_addresses_are_not_listed(self):
        other = OtherUser()
        account(other.user, name="Theirs", email="them@example.test")

        body = self.client.get(reverse("outreach:settings")).content.decode()

        self.assertNotIn("them@example.test", body)

    def test_an_address_with_no_password_says_so(self):
        mailaccounts.clear_secret(self.user, self.account)

        page = self.client.get(reverse("outreach:settings"))

        self.assertContains(page, "no password")

    def test_the_capacity_line_counts_only_usable_addresses(self):
        mailaccounts.set_active(self.user, self.account, False)

        page = self.client.get(reverse("outreach:settings"))

        self.assertEqual(page.context["account_summary"]["usable"], 0)
        self.assertEqual(page.context["account_summary"]["capacity"], 0)

    def test_saving_returns_the_list_without_the_password(self):
        response = self.client.post(
            reverse("outreach:account_save"),
            data={"name": "Second", "sender_email": "second@example.test",
                  "sender_name": "James", "provider": "gmail",
                  "password": "qrst uvwx yzab cdef"},
            content_type="application/json")

        self.assertEqual(response.status_code, 200)
        payload = response.content.decode()
        self.assertNotIn("qrst uvwx yzab cdef", payload)
        self.assertNotIn("qrstuvwxyzabcdef", payload)
        self.assertIn("accounts", response.json())
        self.assertIn("summary", response.json())


# --------------------------------------------------------------------------- #
# Section 4: which addresses a campaign may send from
# --------------------------------------------------------------------------- #

class CampaignAccountPickerTests(SignedIn):
    def setUp(self):
        self.account = account(self.user)
        self.campaign = make_campaign(phase=Campaign.Phase.SETUP)
        make_draft(self.campaign)

    def _setup_page(self):
        return self.client.get(
            reverse("outreach:setup", args=[self.campaign.id]))

    def test_the_picker_lists_the_workspaces_addresses(self):
        page = self._setup_page()

        self.assertContains(page, "account-check")
        self.assertContains(page, "james@example.test")
        self.assertContains(page, "Send from")

    def test_nothing_selected_says_the_env_sender_will_be_used(self):
        page = self._setup_page()

        self.assertEqual(page.context["chosen_accounts"], set())
        self.assertContains(page, "sender configured in")

    def test_a_selection_is_shown_as_ticked_when_the_page_comes_back(self):
        self.campaign.sending_accounts.set([self.account])

        page = self._setup_page()

        self.assertEqual(page.context["chosen_accounts"], {self.account.pk})

    def test_choosing_reports_what_can_actually_send(self):
        response = self.client.post(
            reverse("outreach:campaign_accounts", args=[self.campaign.id]),
            data={"accounts": [self.account.pk]},
            content_type="application/json")

        self.assertEqual(response.status_code, 200)
        body = response.json()
        self.assertEqual(body["selected"], [self.account.pk])
        self.assertEqual(body["usable"], 1)
        self.assertIn("can send", body["message"])

    def test_choosing_an_address_that_cannot_send_says_why(self):
        mailaccounts.set_active(self.user, self.account, False)

        response = self.client.post(
            reverse("outreach:campaign_accounts", args=[self.campaign.id]),
            data={"accounts": [self.account.pk]},
            content_type="application/json")

        self.assertEqual(response.json()["usable"], 0)
        self.assertIn("inactive", response.json()["message"])

    def test_an_unusable_address_is_still_listed_and_visibly_unusable(self):
        """Hiding it leaves somebody wondering where their mailbox went."""
        mailaccounts.clear_secret(self.user, self.account)

        page = self._setup_page()

        self.assertContains(page, "james@example.test")
        self.assertContains(page, "no password saved")

    def test_another_workspaces_address_cannot_be_selected(self):
        other = OtherUser()
        theirs = account(other.user, name="Theirs", email="them@example.test")

        self.client.post(
            reverse("outreach:campaign_accounts", args=[self.campaign.id]),
            data={"accounts": [theirs.pk]},
            content_type="application/json")

        self.assertEqual(list(self.campaign.sending_accounts.all()), [])


# --------------------------------------------------------------------------- #
# Section 22: the controls
# --------------------------------------------------------------------------- #

class ControlOfferTests(TestCase):
    """A button is offered only for a transition `set_status` would accept."""

    def _actions(self, status):
        return {control["action"]
                for control in campaigns.controls(Campaign(status=status))}

    def test_an_active_campaign_can_be_paused_or_stopped(self):
        self.assertEqual(self._actions(Campaign.Status.ACTIVE),
                         {"pause", "stop"})

    def test_a_paused_campaign_offers_resume_rather_than_activate(self):
        offered = campaigns.controls(Campaign(status=Campaign.Status.PAUSED))
        labels = {control["action"]: control["label"] for control in offered}

        self.assertEqual(labels["resume"], "Resume")
        self.assertNotIn("pause", labels)

    def test_a_stopped_campaign_offers_reactivate(self):
        offered = campaigns.controls(Campaign(status=Campaign.Status.STOPPED))

        self.assertEqual([c["label"] for c in offered], ["Reactivate"])

    def test_a_draft_campaign_offers_activate(self):
        offered = campaigns.controls(Campaign(status=Campaign.Status.DRAFT))
        labels = {control["action"]: control["label"] for control in offered}

        self.assertEqual(labels["activate"], "Activate")

    def test_every_offered_control_is_one_the_table_accepts(self):
        """The point of deriving them: no button that returns an error."""
        for status, _label in Campaign.Status.choices:
            for control in campaigns.controls(Campaign(status=status)):
                destination = {
                    "activate": Campaign.Status.ACTIVE,
                    "resume": Campaign.Status.ACTIVE,
                    "reopen": Campaign.Status.ACTIVE,
                    "pause": Campaign.Status.PAUSED,
                    "stop": Campaign.Status.STOPPED,
                }[control["action"]]
                with self.subTest(status=status, action=control["action"]):
                    self.assertIn(status, campaigns.ALLOWED[destination])

    def test_every_control_explains_itself(self):
        for status, _label in Campaign.Status.choices:
            for control in campaigns.controls(Campaign(status=status)):
                with self.subTest(status=status, action=control["action"]):
                    self.assertTrue(control["hint"])


class ControlPageTests(SignedIn):
    def test_the_campaigns_list_shows_the_status_and_the_controls(self):
        make_campaign(city="Delft", status=Campaign.Status.ACTIVE)

        page = self.client.get(reverse("outreach:history"))

        self.assertContains(page, "status-pill")
        self.assertContains(page, "campaign-control")
        self.assertContains(page, "campaigns.js")
        self.assertContains(page, "Pause")

    def test_a_paused_campaign_shows_resume_and_not_pause(self):
        make_campaign(city="Delft", status=Campaign.Status.PAUSED)

        page = self.client.get(reverse("outreach:history"))
        row = page.content.decode()

        self.assertIn('data-action="resume"', row)
        self.assertNotIn('data-action="pause"', row)

    def test_the_status_filter_is_on_the_page(self):
        page = self.client.get(reverse("outreach:history") + "?status=paused")

        self.assertContains(page, "Any status")
        self.assertContains(page, 'value="paused" selected')

    def test_the_search_term_survives_in_the_box(self):
        page = self.client.get(reverse("outreach:history") + "?q=delft")

        self.assertContains(page, 'value="delft"')

    def test_the_report_page_offers_the_controls_too(self):
        campaign = make_campaign(status=Campaign.Status.ACTIVE)

        page = self.client.get(reverse("outreach:report", args=[campaign.id]))

        self.assertContains(page, f'data-campaign="{campaign.id}"')
        self.assertContains(page, "campaign-control")

    def test_a_halted_campaign_says_nothing_will_be_sent(self):
        campaign = make_campaign(status=Campaign.Status.PAUSED)

        page = self.client.get(reverse("outreach:report", args=[campaign.id]))

        # One line of the banner; the sentence wraps in the template.
        self.assertContains(page, "no follow-ups will be prepared")

    def test_another_workspaces_campaign_cannot_be_controlled(self):
        other = OtherUser()
        theirs = make_campaign(city="Theirs", owner=other.user)

        response = self.client.post(
            reverse("outreach:campaign_status", args=[theirs.id, "pause"]),
            data={}, content_type="application/json")

        self.assertEqual(response.status_code, 404)
        theirs.refresh_from_db()
        self.assertEqual(theirs.status, Campaign.Status.ACTIVE)


# --------------------------------------------------------------------------- #
# Section 21: the figures
# --------------------------------------------------------------------------- #

class ProgressCardTests(SignedIn):
    def setUp(self):
        self.campaign = make_campaign()
        make_draft(self.campaign, status=EmailDraft.Status.SENT)
        self.lead = sent_lead(self.user, self.campaign)

    def _card(self):
        return self.client.get(reverse("outreach:report",
                                       args=[self.campaign.id]))

    def test_the_figures_are_on_the_page(self):
        page = self._card()

        self.assertContains(page, "Progress")
        self.assertEqual(page.context["dashboard"]["initial_sent"], 1)
        self.assertEqual(page.context["dashboard"]["awaiting_reply"], 1)

    def test_a_reply_moves_between_two_figures(self):
        """Counted from the rows, so moving a record moves the number."""
        SentLead.objects.filter(pk=self.lead.pk).update(
            reply_state=ReplyState.REPLIED)

        figures = self._card().context["dashboard"]

        self.assertEqual(figures["replies"], 1)
        self.assertEqual(figures["awaiting_reply"], 0)
        self.assertEqual(figures["completed"], 1)

    def test_a_prepared_follow_up_is_counted_as_waiting_for_review(self):
        FollowUp.objects.create(
            lead=self.lead, owner=self.user, campaign=self.campaign,
            number=1, email=self.lead.email, subject="Re:", body="Hi again",
            status=FollowUp.Status.DUE)

        self.assertEqual(self._card().context["dashboard"]["followups_ready"], 1)

    def test_a_scheduled_follow_up_is_not_counted_as_ready(self):
        """WAITING is a note about the future, not something to approve."""
        FollowUp.objects.create(
            lead=self.lead, owner=self.user, campaign=self.campaign,
            number=1, email=self.lead.email, subject="", body="",
            status=FollowUp.Status.WAITING)

        self.assertEqual(self._card().context["dashboard"]["followups_ready"], 0)

    def test_the_sending_addresses_are_reported(self):
        chosen = account(self.user)
        self.campaign.sending_accounts.set([chosen])

        page = self._card()

        self.assertEqual(page.context["account_report"]["usable"]
                         if "account_report" in page.context
                         else page.context["accounts"]["usable"], 1)


# --------------------------------------------------------------------------- #
# Section 7: the last two lists
# --------------------------------------------------------------------------- #

class RemainingPaginationTests(SignedIn):
    def test_the_do_not_contact_list_paginates(self):
        from apps.outreach.models import Suppression

        for index in range(25):
            Suppression.objects.create(
                owner=self.user, email=f"no{index}@example.test",
                reason=Suppression.Reason.MANUAL)

        page = self.client.get(reverse("outreach:suppressions"))

        self.assertEqual(len(page.context["rows"]), 20)
        self.assertEqual(page.context["paging"]["total"], 25)
        self.assertContains(page, "Showing 1–20 of 25 entries")

    def test_the_badge_counts_the_list_and_not_the_page(self):
        from apps.outreach.models import Suppression

        for index in range(25):
            Suppression.objects.create(
                owner=self.user, domain=f"shop{index}.example",
                reason=Suppression.Reason.MANUAL)

        body = self.client.get(reverse("outreach:suppressions")).content.decode()

        self.assertIn('<span class="badge">25</span>', body)

    def test_searching_the_do_not_contact_list_narrows_it(self):
        from apps.outreach.models import Suppression

        Suppression.objects.create(owner=self.user, email="a@delft.example",
                                   reason=Suppression.Reason.MANUAL)
        Suppression.objects.create(owner=self.user, email="b@berlin.example",
                                   reason=Suppression.Reason.MANUAL)

        page = self.client.get(reverse("outreach:suppressions") + "?q=delft")

        self.assertEqual(page.context["paging"]["total"], 1)

    def test_the_domain_rule_count_covers_every_page(self):
        from apps.outreach.models import Suppression

        for index in range(25):
            Suppression.objects.create(
                owner=self.user, domain=f"shop{index}.example",
                reason=Suppression.Reason.MANUAL)

        page = self.client.get(reverse("outreach:suppressions"))

        self.assertEqual(page.context["domain_rules"], 25)

    def test_the_follow_ups_screen_paginates(self):
        campaign = make_campaign()
        for index in range(25):
            sent_lead(self.user, campaign, email=f"lead{index}@example.test",
                      business_name=f"Shop {index}")

        page = self.client.get(reverse("outreach:followups"))

        self.assertEqual(len(page.context["rows"]), 20)
        self.assertEqual(page.context["paging"]["total"], 25)
