"""
A campaign, a draft and a fake SMTP session.

`make_campaign` uses `default_user()` for the owner rather than making a fresh account,
which is the detail that makes ownership filtering behave in tests the way it behaves
in the application: the campaign belongs to whoever is driving `self.client`. A fixture
owned by somebody else would be filtered out of every page it appears on, and the test
would pass for the wrong reason.
"""

from __future__ import annotations

import smtplib

from apps.auditing import crawler
from apps.core.testing import default_user
from apps.outreach.models import Campaign, EmailDraft


def make_campaign(**overrides) -> Campaign:
    values = dict(
        # Owned by the account driving the test client, so ownership filtering
        # behaves as it does in the application rather than hiding the fixture.
        owner=default_user(),
        city="Delft", country="Netherlands", category="Restaurants",
        sender_name="Sam Rivers", sender_email="sam@agency.test",
        sender_company="Northline", provider="gmail",
        service_pitch="We build fast websites with online booking for restaurants.",
        phase=Campaign.Phase.REVIEW,
    )
    values.update(overrides)
    return Campaign.objects.create(**values)
def make_draft(campaign: Campaign, **overrides) -> EmailDraft:
    values = dict(
        business_name="Bella Cucina",
        email="ciao@bella.example",
        website="https://bella.example",
        category="Restaurant",
        city="Delft",
        country="Netherlands",
        subject="Online booking for Bella Cucina",
        body="Hello,\n\nI saw your wood-fired pizza page.\n\nSam",
        observation="wood-fired pizza since 1998",
        analysis_status=crawler.OK,
        analysis_context="--- HOME PAGE\nWood-fired pizza since 1998",
        status=EmailDraft.Status.GENERATED,
    )
    values.update(overrides)
    return EmailDraft.objects.create(campaign=campaign, **values)
class FakeSession:
    """Records sends; can be told to fail for specific recipients."""

    def __init__(self, fail_for=(), raise_on_enter=None):
        self.fail_for = set(fail_for)
        self.raise_on_enter = raise_on_enter
        self.sent: list[str] = []

    def __enter__(self):
        if self.raise_on_enter:
            raise self.raise_on_enter
        return self

    def __exit__(self, *exc_info):
        return False

    def send(self, *, to_email, subject, body, sender_name):
        if to_email in self.fail_for:
            raise smtplib.SMTPRecipientsRefused({to_email: (550, b"No such user")})
        self.sent.append(to_email)
