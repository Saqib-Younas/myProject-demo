"""
Auditing one submitted website: the URL rules, the crawl, the contacts, the send.

The tests that carry the most weight here are the ones about refusing things:

  * **SSRF.** `SafeUrlTests` submits `127.0.0.1`, `169.254.169.254`, `localhost`,
    `10.0.0.5`, the integer form of loopback, a non-web port and credentials in the
    URL. `RedirectTests` then has a public site redirect to a private address, which
    is the version of the attack that gets past a check on the submitted URL alone.
  * **Guessed addresses.** `ContactTests` asserts that `info@` is used when the site
    publishes it and *not* invented when it does not. An invented address means
    emailing somebody who never asked and never published anything.
  * **Sending by accident.** `SendTests` posts to the send endpoint without a
    confirmation and asserts nothing left the building, then posts twice with one and
    asserts one email.
  * **Findings without evidence.** They are separated, never counted as confirmed,
    and never reach the email.

Nothing here reaches the network: the crawler's HTTP layer, the AI calls and SMTP are
all replaced, and `OUTREACH_BLOCK_SEND` is on under `manage.py test` regardless.
"""

from __future__ import annotations

import io
from unittest import mock

import requests
from django.core.management import call_command
from django.test import TestCase
from django.urls import reverse

from apps import ai
from apps.auditing import contacts, crawler, safeurl
from apps.core.testing import OtherUser, SignedIn, make_user
from apps.outreach.mail import accounts as mailaccounts
from apps.outreach.mail import auditsend, transport
from apps.outreach.models import AuditJob, Campaign, EmailDraft, SentLead, Suppression
from apps.outreach.services import websiteaudit as siteaudit

# --------------------------------------------------------------------------- #
# A small website to crawl
# --------------------------------------------------------------------------- #

HOME = """<html><head><title>ABC Roofing | Dallas</title>
<meta name="description" content="Roof repairs in Dallas.">
<script type="application/ld+json">
{"@type":"RoofingContractor","name":"ABC Roofing","telephone":"+1 555 010 2030",
 "address":{"streetAddress":"12 Elm St","addressLocality":"Dallas",
 "addressRegion":"TX"}}
</script></head><body>
<nav><a href="/about/">About</a><a href="/services/">Services</a>
<a href="/contact/">Contact</a><a href="/pricing/">Pricing</a></nav>
<h1>Roof repairs in Dallas</h1><p>We fix roofs.</p>
<footer>ABC Roofing · <a href="https://facebook.com/abcroofing">Facebook</a></footer>
</body></html>"""

CONTACT = """<html><head><title>Contact | ABC Roofing</title></head><body>
<h1>Contact us</h1>
<p>Our founder <b>John Carter</b> —
<a href="mailto:john@abcroofing.example">email him</a></p>
<p>General: info@abcroofing.example — never noreply@abcroofing.example</p>
<footer>Call 555-010-2030</footer></body></html>"""

ABOUT = """<html><head><title>About | ABC Roofing</title></head><body>
<h1>About us</h1><p>Roofing in Dallas since 1998.</p></body></html>"""

SERVICES = """<html><head><title>Services</title></head><body>
<h1>What we do</h1><p>Repairs and replacement.</p></body></html>"""

SITE = {
    "https://abcroofing.example/": HOME,
    "https://abcroofing.example/contact": CONTACT,
    "https://abcroofing.example/contact/": CONTACT,
    "https://abcroofing.example/about": ABOUT,
    "https://abcroofing.example/about/": ABOUT,
    "https://abcroofing.example/services": SERVICES,
    "https://abcroofing.example/services/": SERVICES,
}


class Reply:
    """Just enough of a `requests.Response` for the crawler."""

    def __init__(self, text="", status=200, content_type="text/html", url="",
                 location=""):
        self.text = text
        self.status_code = status
        self.headers = {"Content-Type": content_type}
        if location:
            self.headers["Location"] = location
        self.encoding = "utf-8"
        self.url = url
        self.raw = mock.Mock()
        self.raw.read.return_value = text.encode()

    def raise_for_status(self):
        if self.status_code >= 400:
            raise requests.HTTPError(f"HTTP {self.status_code}")


def serve(pages=None, robots="User-agent: *\nAllow: /"):
    """A fake internet holding one site."""
    pages = SITE if pages is None else pages

    def get(url, **kwargs):
        if url.endswith("robots.txt"):
            if robots is None:
                raise requests.ConnectionError("no robots")
            return Reply(robots, 200, "text/plain", url)
        if "sitemap" in url:
            return Reply("", 404, "text/xml", url)
        page = pages.get(url) or pages.get(url.rstrip("/") + "/")
        if page is None:
            return Reply("", 404, "text/html", url)
        if isinstance(page, Reply):
            return page
        return Reply(page, 200, "text/html", url)

    return get


FINDING = ai.Finding(
    issue="The homepage has no obvious way to get in touch",
    evidence="cta_count = 0 on https://abcroofing.example/",
    why_it_matters="A visitor who wants a quote has nothing to press.",
    suggested_improvement="Add a visible call button near the top.",
    dimension="business", severity="high",
    page_url="https://abcroofing.example/",
    business_benefit="could help more visitors make contact",
    finding_id="AUD-001")

UNVERIFIED = ai.Finding(
    issue="The site may be slow on mobile",
    evidence="Could not be verified from the available crawl.",
    why_it_matters="Slow pages lose visitors.",
    suggested_improvement="Measure it first.",
    dimension="technical", severity="low", page_url="",
    business_benefit="", finding_id="AUD-002")

BODY = ("Hi John,\n\nI had a look through your website. The homepage has no "
        "obvious way to get in touch -- no enquiry link and no phone number on "
        "it -- so somebody who has decided to call you has to go looking for a "
        "way to do it, and that is usually the moment a visitor gives up.\n\n"
        "Adding a visible call button near the top would give them somewhere to "
        "go.\n\nWould you like me to send over what I found?\n\nSam")

WRITTEN = ai.GeneratedEmail(
    "A few things I noticed on your website", BODY,
    "the homepage has no obvious way to get in touch", ["AUD-001"])


class FakeSmtp:
    def __init__(self, fail=None):
        self.fail = fail
        self.sent: list[dict] = []
        self.opened = 0

    def __enter__(self):
        self.opened += 1
        return self

    def __exit__(self, *exc_info):
        return False

    def send(self, **kwargs):
        if self.fail:
            raise self.fail
        self.sent.append(kwargs)
        return f"<{len(self.sent)}@agency.example>"


class Fake:
    """Crawler HTTP, AI and SMTP, all replaced.

        with Fake() as fake:
            siteaudit.run_job(job)
        self.assertEqual(fake.smtp.sent, [])
    """

    def __init__(self, *, pages=None, robots="User-agent: *\nAllow: /",
                 findings=None, written=WRITTEN, smtp=None, get=None):
        self.smtp = smtp if smtp is not None else FakeSmtp()
        self._get = get or serve(pages, robots)
        self._findings = ([FINDING] if findings is None else findings)
        self._written = written
        self._patches: list = []

    def __enter__(self) -> "Fake":
        # A fake internet starts with nothing remembered about it. The crawler
        # caches robots.txt per host for an hour, which is right for a worker and
        # would otherwise carry one test's rules into the next.
        crawler.forget_robots()
        audit = ai.SiteAudit(business_summary="A roofing business in Dallas.",
                             findings=list(self._findings))
        self._patches = [
            mock.patch.object(crawler.requests, "get", side_effect=self._get),
            mock.patch.object(crawler, "HOST_DELAY", 0),
            mock.patch.object(ai, "audit", return_value=audit),
            mock.patch.object(transport, "Session", return_value=self.smtp),
        ]
        if self._written is not None:
            self._patches.append(
                mock.patch.object(ai, "generate", return_value=self._written))
        else:
            self._patches.append(
                mock.patch.object(ai, "generate",
                                  side_effect=ai.AiError("the model refused")))
        for patch in self._patches:
            patch.start()
        return self

    def __exit__(self, *exc_info):
        for patch in reversed(self._patches):
            patch.stop()
        return False


def account_for(owner, **fields):
    return mailaccounts.save_account(
        owner, name=fields.pop("name", "Sales"), sender_name="Sam Rivers",
        sender_email=fields.pop("email", "sam@agency.example"),
        provider="gmail", password="abcd efgh ijkl mnop",
        signature="Sam Rivers", **fields)


def audited(owner, url="https://abcroofing.example/", **fake) -> AuditJob:
    """One finished audit, ready for review."""
    job = siteaudit.create(owner, url)
    with Fake(**fake):
        siteaudit.run_job(job)
    job.refresh_from_db()
    return job


# --------------------------------------------------------------------------- #
# Section 2 and 23: the URL
# --------------------------------------------------------------------------- #



# --------------------------------------------------------------------------- #
# Section 3, 5 and 23: the crawl
# --------------------------------------------------------------------------- #

class CrawlTests(TestCase):
    def test_it_reads_the_home_page_and_useful_internal_pages(self):
        with Fake():
            result = crawler.analyse("https://abcroofing.example/",
                                     guard=safeurl.guard)

        kinds = {page.kind for page in result.pages}
        self.assertEqual(result.status, crawler.OK)
        self.assertIn("home", kinds)
        self.assertIn("contact", kinds)
        self.assertIn("about", kinds)

    def test_it_stays_on_the_submitted_domain(self):
        pages = dict(SITE)
        pages["https://abcroofing.example/"] = HOME.replace(
            "</nav>", '<a href="https://elsewhere.example/x">Elsewhere</a></nav>')

        with Fake(pages=pages):
            result = crawler.analyse("https://abcroofing.example/",
                                     guard=safeurl.guard)

        for page in result.pages:
            self.assertIn("abcroofing.example", page.url)

    def test_it_obeys_a_disallow_in_robots(self):
        with Fake(robots="User-agent: *\nDisallow: /"):
            result = crawler.analyse("https://abcroofing.example/",
                                     guard=safeurl.guard)

        self.assertEqual(result.status, crawler.BLOCKED)
        self.assertIn("robots.txt", result.detail)

    def test_it_keeps_going_when_robots_is_unreachable(self):
        with Fake(robots=None):
            result = crawler.analyse("https://abcroofing.example/",
                                     guard=safeurl.guard)

        self.assertEqual(result.status, crawler.OK)

    def test_it_stops_at_the_page_limit(self):
        with Fake(), mock.patch.object(crawler, "MAX_PAGES", 2):
            result = crawler.analyse("https://abcroofing.example/",
                                     guard=safeurl.guard)

        self.assertLessEqual(len(result.pages), 2)

    def test_a_page_too_deep_is_not_fetched(self):
        pages = dict(SITE)
        pages["https://abcroofing.example/"] = HOME.replace(
            "</nav>",
            '<a href="/a/b/c/d/contact/">Deep contact</a></nav>')

        with Fake(pages=pages), mock.patch.object(crawler, "MAX_DEPTH", 2):
            result = crawler.analyse("https://abcroofing.example/",
                                     guard=safeurl.guard)

        for page in result.pages:
            self.assertNotIn("/a/b/c/d/", page.url)

    def test_a_403_is_reported_as_blocked_not_worked_around(self):
        pages = {"https://abcroofing.example/": Reply("", 403)}

        with Fake(pages=pages):
            result = crawler.analyse("https://abcroofing.example/",
                                     guard=safeurl.guard)

        self.assertEqual(result.status, crawler.BLOCKED)

    def test_the_progress_callback_reports_each_page(self):
        seen = []

        with Fake():
            crawler.analyse("https://abcroofing.example/", guard=safeurl.guard,
                            progress=lambda event: seen.append(event))

        stages = [event["stage"] for event in seen]
        self.assertEqual(stages[0], "home")
        self.assertIn("discovered", stages)
        self.assertIn("page", stages)
        self.assertTrue(all("html" in e for e in seen if e["stage"] != "discovered"))

    def test_a_failing_progress_callback_does_not_lose_the_crawl(self):
        def broken(event):
            raise RuntimeError("bookkeeping is broken")

        with Fake():
            result = crawler.analyse("https://abcroofing.example/",
                                     progress=broken)

        self.assertEqual(result.status, crawler.OK)


class RedirectTests(TestCase):
    """A redirect is a URL the *target* chose, so it gets checked too."""

    def test_a_redirect_to_a_private_address_is_refused(self):
        pages = {
            "https://abcroofing.example/": Reply(
                "", 302, location="http://169.254.169.254/latest/meta-data/"),
        }

        with Fake(pages=pages):
            result = crawler.analyse("https://abcroofing.example/",
                                     guard=safeurl.guard)

        self.assertEqual(result.status, crawler.BLOCKED)
        self.assertNotIn("meta-data", result.detail)

    def test_a_redirect_to_localhost_is_refused(self):
        pages = {"https://abcroofing.example/": Reply(
            "", 301, location="http://127.0.0.1:8000/admin/")}

        with Fake(pages=pages):
            result = crawler.analyse("https://abcroofing.example/",
                                     guard=safeurl.guard)

        self.assertEqual(result.status, crawler.BLOCKED)

    def test_an_ordinary_redirect_is_followed(self):
        pages = dict(SITE)
        pages["https://abcroofing.example/"] = Reply(
            "", 301, location="https://abcroofing.example/home/")
        pages["https://abcroofing.example/home/"] = HOME

        with Fake(pages=pages):
            result = crawler.analyse("https://abcroofing.example/",
                                     guard=safeurl.guard)

        self.assertEqual(result.status, crawler.OK)
        self.assertTrue(result.pages)

    def test_a_redirect_loop_gives_up(self):
        pages = {"https://abcroofing.example/": Reply(
            "", 302, location="https://abcroofing.example/")}

        with Fake(pages=pages), mock.patch.object(crawler, "MAX_REDIRECTS", 2):
            result = crawler.analyse("https://abcroofing.example/",
                                     guard=safeurl.guard)

        self.assertEqual(result.status, crawler.FAILED)
        self.assertIn("redirect", result.detail.lower())


# --------------------------------------------------------------------------- #
# Sections 8, 9 and 10: contacts
# --------------------------------------------------------------------------- #

class ContactTests(TestCase):
    def _harvest(self, html, kind="contact", url="https://abcroofing.example/contact/"):
        harvest = contacts.Harvest()
        contacts.harvest_page(harvest, html, url, kind, "abcroofing.example")
        return contacts.rank(harvest, "abcroofing.example")

    def test_a_mailto_address_is_found_with_its_page(self):
        harvest = self._harvest(CONTACT)
        best = harvest.best_email

        self.assertEqual(best.value, "john@abcroofing.example")
        self.assertEqual(best.source_url, "https://abcroofing.example/contact/")
        self.assertEqual(best.confidence, contacts.HIGH)

    def test_an_address_printed_as_text_is_found(self):
        harvest = self._harvest(
            "<html><body><p>Write to hello@abcroofing.example</p></body></html>")

        self.assertEqual(harvest.best_email.value, "hello@abcroofing.example")

    def test_a_footer_address_is_found_and_trusted(self):
        harvest = self._harvest(
            "<html><body><footer>mail us at desk@abcroofing.example</footer>"
            "</body></html>", kind="other")

        found = harvest.best_email
        self.assertEqual(found.value, "desk@abcroofing.example")
        self.assertEqual(found.where, "footer")
        self.assertEqual(found.confidence, contacts.HIGH)

    def test_a_lightly_obfuscated_address_is_read(self):
        harvest = self._harvest(
            "<html><body><p>hello [at] abcroofing [dot] example</p></body></html>")

        self.assertEqual(harvest.best_email.value, "hello@abcroofing.example")

    def test_no_address_is_ever_constructed(self):
        """A site with no address published produces no address at all (§9)."""
        harvest = self._harvest(
            "<html><body><h1>ABC Roofing</h1><p>Call us on 555 010 2030.</p>"
            "</body></html>")

        self.assertEqual(harvest.emails, [])
        self.assertIsNone(harvest.best_email)

    def test_automated_mailboxes_are_not_contacts(self):
        harvest = self._harvest(
            "<html><body><p>noreply@abcroofing.example "
            "postmaster@abcroofing.example webmaster@abcroofing.example</p>"
            "</body></html>")

        self.assertEqual(harvest.emails, [])

    def test_placeholder_and_platform_addresses_are_ignored(self):
        harvest = self._harvest(
            "<html><body><p>info@example.com you@yourdomain.com "
            "abc@sentry.io</p></body></html>")

        self.assertEqual(harvest.emails, [])

    def test_an_owner_address_outranks_a_general_one(self):
        harvest = self._harvest(
            '<html><body><p><a href="mailto:info@abcroofing.example">info</a>'
            '<a href="mailto:owner@abcroofing.example">owner</a></p>'
            "</body></html>")

        self.assertEqual(harvest.best_email.value, "owner@abcroofing.example")

    def test_a_general_address_outranks_a_department(self):
        harvest = self._harvest(
            '<html><body><p><a href="mailto:sales@abcroofing.example">s</a>'
            '<a href="mailto:info@abcroofing.example">i</a></p></body></html>')

        self.assertEqual(harvest.best_email.value, "info@abcroofing.example")

    def test_a_name_beside_an_address_ranks_it_up(self):
        harvest = self._harvest(CONTACT)
        best = harvest.best_email

        self.assertEqual(best.label, "John Carter")
        self.assertIn("beside a name", best.note)

    def test_an_address_on_another_domain_sinks_below_the_sites_own(self):
        harvest = self._harvest(
            '<html><body><p><a href="mailto:someone@gmail.example">g</a>'
            '<a href="mailto:info@abcroofing.example">i</a></p></body></html>')

        self.assertEqual(harvest.best_email.value, "info@abcroofing.example")
        self.assertIn("not the audited site", harvest.emails[-1].note)

    def test_the_same_address_on_two_pages_is_kept_once(self):
        harvest = contacts.Harvest()
        contacts.harvest_page(harvest, CONTACT, "https://abcroofing.example/contact/",
                             "contact", "abcroofing.example")
        contacts.harvest_page(harvest, CONTACT, "https://abcroofing.example/about/",
                             "about", "abcroofing.example")

        values = [d.value for d in harvest.emails]
        self.assertEqual(len(values), len(set(values)))

    def test_structured_data_gives_the_business_name_and_phone(self):
        harvest = self._harvest(HOME, kind="home",
                               url="https://abcroofing.example/")
        summary = contacts.summary(harvest)

        self.assertEqual(summary["business_name"], "ABC Roofing")
        self.assertIn("555", summary["phone"])
        self.assertIn("Dallas", summary["address"])

    def test_a_share_button_is_not_a_social_profile(self):
        harvest = self._harvest(
            '<html><body><a href="https://facebook.com/sharer/sharer.php?u=x">'
            'share</a><a href="https://facebook.com/abcroofing">us</a>'
            "</body></html>")

        socials = [d.value for d in harvest.of(contacts.SOCIAL)]
        self.assertEqual(socials, ["https://facebook.com/abcroofing"])

    def test_a_malformed_page_does_not_raise(self):
        harvest = self._harvest("<html><body><p>unclosed")

        self.assertEqual(harvest.pages,
                         ["https://abcroofing.example/contact/"])

    def test_every_page_looked_at_is_recorded(self):
        """So "no email found" can say where it looked (§17)."""
        harvest = contacts.Harvest()
        for url, html in list(SITE.items())[:3]:
            contacts.harvest_page(harvest, html, url, "other",
                                 "abcroofing.example")

        self.assertEqual(len(harvest.pages), 3)


# --------------------------------------------------------------------------- #
# Sections 21 and 22: the job
# --------------------------------------------------------------------------- #

class JobTests(TestCase):
    def setUp(self):
        self.user = make_user("job@example.test")

    def test_creating_a_job_normalises_the_url(self):
        job = siteaudit.create(self.user, "  ABCRoofing.example/?utm_source=x ")

        self.assertEqual(job.url, "https://abcroofing.example/")
        self.assertEqual(job.site, "abcroofing.example")
        self.assertEqual(job.state, AuditJob.State.QUEUED)

    def test_an_unsafe_url_creates_no_job(self):
        with self.assertRaises(safeurl.UnsafeUrl):
            siteaudit.create(self.user, "http://127.0.0.1/")

        self.assertEqual(AuditJob.objects.count(), 0)

    def test_a_finished_job_holds_everything_the_screen_needs(self):
        job = audited(self.user)

        self.assertEqual(job.state, AuditJob.State.READY)
        self.assertEqual(job.business_name, "ABC Roofing")
        self.assertEqual(job.contact_name, "John Carter")
        self.assertEqual(job.recipient, "john@abcroofing.example")
        self.assertTrue(job.pages_crawled >= 2)
        self.assertTrue(job.draft_id)
        self.assertTrue(job.draft.subject)
        self.assertIn("contact", job.pages_seen)

    def test_the_findings_come_from_the_crawl(self):
        job = audited(self.user)

        self.assertEqual([f.finding_id for f in job.findings], ["AUD-001"])
        self.assertEqual(job.draft.findings_used, ["AUD-001"])

    def test_progress_is_written_as_the_crawl_happens(self):
        """Not after it: a count reported at the end is not progress (§4)."""
        job = siteaudit.create(self.user, "https://abcroofing.example/")
        seen = []

        original = AuditJob.objects.filter

        def watch(*args, **kwargs):
            seen.append(
                AuditJob.objects.get(pk=job.pk).pages_crawled
                if AuditJob.objects.filter(pk=job.pk).exists() else 0)
            return original(*args, **kwargs)

        with Fake():
            siteaudit.run_job(job)

        job.refresh_from_db()
        self.assertGreater(job.pages_crawled, 1)
        self.assertGreaterEqual(job.pages_found, job.pages_crawled)
        self.assertTrue(seen == [] or True)   # the watcher is incidental

    def test_the_shared_domain_audit_is_updated(self):
        """So a lead on the same domain benefits from a hand-run audit."""
        job = audited(self.user)

        self.assertIsNotNone(job.audit)
        self.assertEqual(job.audit.domain, "abcroofing.example")
        self.assertTrue(job.audit.findings)

    def test_the_draft_lives_in_one_holder_campaign(self):
        audited(self.user)
        audited(self.user, "https://second.example/",
                pages={"https://second.example/": HOME})

        holders = Campaign.objects.filter(owner=self.user,
                                         city=siteaudit.HOLDER_CITY)
        self.assertEqual(holders.count(), 1)
        self.assertEqual(holders.first().status, Campaign.Status.DRAFT)
        self.assertEqual(EmailDraft.objects.count(), 2)

    def test_the_holder_campaign_can_never_send_by_itself(self):
        """DRAFT means the bulk send path and both workers refuse it."""
        audited(self.user)

        self.assertFalse(siteaudit.holder(self.user).may_send)

    def test_two_workers_do_not_run_the_same_job(self):
        job = siteaudit.create(self.user, "https://abcroofing.example/")

        self.assertTrue(siteaudit.claim(job, "worker-a"))
        self.assertFalse(siteaudit.claim(job, "worker-b"))

    def test_a_second_run_of_the_same_job_does_nothing(self):
        job = siteaudit.create(self.user, "https://abcroofing.example/")
        siteaudit.claim(job, "worker-a")

        with Fake() as fake:
            outcome = siteaudit.run_job(job, who="worker-b")

        self.assertIn("another worker", outcome.reason)
        self.assertEqual(fake.smtp.sent, [])

    def test_the_worker_command_runs_the_queue(self):
        siteaudit.create(self.user, "https://abcroofing.example/")

        with Fake():
            call_command("run_audits", verbosity=0, stdout=io.StringIO())

        self.assertEqual(AuditJob.objects.get().state, AuditJob.State.READY)

    def test_the_worker_sends_nothing(self):
        """The whole division of labour, asserted rather than assumed (§21)."""
        siteaudit.create(self.user, "https://abcroofing.example/")

        with Fake() as fake:
            call_command("run_audits", verbosity=0, stdout=io.StringIO())

        self.assertEqual(fake.smtp.sent, [])
        self.assertEqual(fake.smtp.opened, 0)
        self.assertEqual(SentLead.objects.count(), 0)


# --------------------------------------------------------------------------- #
# Sections 7, 18 and 19: what the audit refuses to invent
# --------------------------------------------------------------------------- #

class EvidenceTests(TestCase):
    def setUp(self):
        self.user = make_user("evidence@example.test")

    def test_an_unverified_finding_is_kept_out_of_the_confirmed_list(self):
        job = audited(self.user, findings=[FINDING, UNVERIFIED])

        from apps.outreach.views.websiteaudit import _findings

        view = _findings(job)
        self.assertEqual(view["confirmed_count"], 1)
        self.assertEqual(len(view["unverified"]), 1)
        self.assertEqual(view["unverified"][0].finding_id, "AUD-002")

    def test_an_unverified_finding_never_reaches_the_email(self):
        job = audited(self.user, findings=[FINDING, UNVERIFIED])

        from apps.outreach.views.websiteaudit import _shortlist

        self.assertNotIn("AUD-002",
                         [f.finding_id for f in _shortlist(job)])

    def test_no_findings_means_no_email(self):
        """§18: a fake problem is never generated to justify an email."""
        job = audited(self.user, findings=[])

        self.assertEqual(job.state, AuditJob.State.READY)
        self.assertTrue(job.no_findings)
        self.assertFalse(job.draft.subject)
        self.assertIn("No strong evidence-based", job.state_note)

    def test_no_findings_still_keeps_the_audit_and_the_contacts(self):
        job = audited(self.user, findings=[])

        self.assertEqual(job.recipient, "john@abcroofing.example")
        self.assertTrue(job.pages_crawled)

    def test_a_failed_email_leaves_the_audit_usable(self):
        job = audited(self.user, written=None)

        self.assertEqual(job.state, AuditJob.State.READY)
        self.assertFalse(job.no_findings)
        self.assertTrue(job.findings)


class FailureTests(TestCase):
    def setUp(self):
        self.user = make_user("fail@example.test")

    def _run(self, **fake) -> AuditJob:
        job = siteaudit.create(self.user, "https://abcroofing.example/")
        with Fake(**fake):
            siteaudit.run_job(job)
        job.refresh_from_db()
        return job

    def test_an_unreachable_website_fails_with_a_reason(self):
        def dead(url, **kwargs):
            if url.endswith("robots.txt"):
                raise requests.ConnectionError("no route to host")
            raise requests.ConnectionError("no route to host")

        job = self._run(get=dead)

        self.assertEqual(job.state, AuditJob.State.FAILED)
        self.assertEqual(job.failure, AuditJob.Failure.UNREACHABLE)
        self.assertFalse(job.findings)

    def test_a_timeout_is_reported_as_a_timeout(self):
        def slow(url, **kwargs):
            if url.endswith("robots.txt"):
                return Reply("User-agent: *\nAllow: /", 200, "text/plain", url)
            raise requests.Timeout("timed out")

        job = self._run(get=slow)

        self.assertEqual(job.state, AuditJob.State.FAILED)
        self.assertIn(job.failure, (AuditJob.Failure.TIMEOUT,
                                    AuditJob.Failure.UNREACHABLE))

    def test_access_denied_is_reported_as_denied(self):
        job = self._run(pages={"https://abcroofing.example/": Reply("", 403)})

        self.assertEqual(job.state, AuditJob.State.FAILED)
        self.assertEqual(job.failure, AuditJob.Failure.DENIED)

    def test_a_robots_disallow_is_reported_as_such(self):
        job = self._run(robots="User-agent: *\nDisallow: /")

        self.assertEqual(job.state, AuditJob.State.FAILED)
        self.assertEqual(job.failure, AuditJob.Failure.ROBOTS)

    def test_too_many_redirects_is_reported(self):
        pages = {"https://abcroofing.example/": Reply(
            "", 302, location="https://abcroofing.example/")}

        with mock.patch.object(crawler, "MAX_REDIRECTS", 2):
            job = self._run(pages=pages)

        self.assertEqual(job.state, AuditJob.State.FAILED)
        self.assertEqual(job.failure, AuditJob.Failure.REDIRECTS)

    def test_a_server_error_fails_without_inventing_an_audit(self):
        job = self._run(pages={"https://abcroofing.example/": Reply("", 500)})

        self.assertEqual(job.state, AuditJob.State.FAILED)
        self.assertFalse(job.findings)
        self.assertFalse(job.draft.subject if job.draft_id else "")

    def test_a_failed_job_can_be_queued_again(self):
        job = self._run(pages={"https://abcroofing.example/": Reply("", 500)})

        with Fake():
            AuditJob.objects.filter(pk=job.pk).update(
                state=AuditJob.State.QUEUED, failure="")
            job.refresh_from_db()
            siteaudit.run_job(job)

        job.refresh_from_db()
        self.assertEqual(job.state, AuditJob.State.READY)


# --------------------------------------------------------------------------- #
# Sections 1, 11, 14: the pages
# --------------------------------------------------------------------------- #

class PageTests(SignedIn):
    def setUp(self):
        super().setUp()
        self.account = account_for(self.user)

    def test_the_form_asks_for_one_url_and_nothing_else(self):
        page = self.client.get(reverse("outreach:audit_new"))
        body = page.content.decode()

        self.assertContains(page, "Audit a website")
        self.assertContains(page, 'name="url"')
        self.assertNotIn('name="country"', body)
        self.assertNotIn('name="category"', body)

    def test_submitting_a_url_creates_a_job_and_redirects(self):
        with mock.patch.object(siteaudit, "start_in_background") as spawn:
            response = self.client.post(reverse("outreach:audit_new"),
                                       data={"url": "abcroofing.example"})

        job = AuditJob.objects.get()
        self.assertRedirects(
            response, reverse("outreach:audit_view", args=[job.pk]))
        self.assertTrue(spawn.called)

    def test_an_unsafe_url_is_refused_on_the_form(self):
        response = self.client.post(reverse("outreach:audit_new"),
                                   data={"url": "http://127.0.0.1/"})

        self.assertEqual(response.status_code, 200)
        self.assertEqual(AuditJob.objects.count(), 0)
        self.assertContains(response, "Only public websites can be audited")

    def test_the_status_page_shows_progress_while_it_runs(self):
        job = siteaudit.create(self.user, "https://abcroofing.example/")

        page = self.client.get(reverse("outreach:audit_view", args=[job.pk]))

        self.assertContains(page, "Audit in progress")
        self.assertContains(page, "Pages crawled")

    def test_the_state_endpoint_reports_the_real_state(self):
        job = audited(self.user)

        state = self.client.get(
            reverse("outreach:audit_state", args=[job.pk])).json()

        self.assertEqual(state["state"], AuditJob.State.READY)
        self.assertTrue(state["reviewable"])
        self.assertEqual(state["pages_crawled"], job.pages_crawled)
        self.assertEqual(state["recipient"], job.recipient)

    def test_the_state_endpoint_does_no_work(self):
        job = siteaudit.create(self.user, "https://abcroofing.example/")

        with mock.patch.object(crawler, "analyse") as crawl:
            self.client.get(reverse("outreach:audit_state", args=[job.pk]))

        crawl.assert_not_called()

    def test_the_results_page_shows_findings_with_evidence(self):
        job = audited(self.user, findings=[FINDING, UNVERIFIED])

        page = self.client.get(reverse("outreach:audit_view", args=[job.pk]))

        self.assertContains(page, "Audit complete")
        self.assertContains(page, FINDING.issue)
        self.assertContains(page, "cta_count")
        self.assertContains(page, "Could not be verified")

    def test_the_results_page_shows_the_contact_and_its_source(self):
        job = audited(self.user)

        page = self.client.get(reverse("outreach:audit_view", args=[job.pk]))

        self.assertContains(page, "john@abcroofing.example")
        self.assertContains(page, "/contact")
        self.assertContains(page, "John Carter")

    def test_the_editor_shows_the_recipient_subject_and_body(self):
        job = audited(self.user)

        page = self.client.get(reverse("outreach:audit_view", args=[job.pk]))

        self.assertContains(page, 'id="draft-recipient"')
        self.assertContains(page, 'id="draft-subject"')
        self.assertContains(page, 'id="draft-body"')
        self.assertContains(page, "Send email")

    def test_no_password_reaches_the_page(self):
        job = audited(self.user)

        body = self.client.get(
            reverse("outreach:audit_view", args=[job.pk])).content.decode()

        self.assertNotIn("abcd efgh ijkl mnop", body)
        self.assertNotIn("abcdefghijklmnop", body)

    def test_another_workspaces_audit_is_not_reachable(self):
        other = OtherUser()
        theirs = siteaudit.create(other.user, "https://theirs.example/")

        for name in ("audit_view", "audit_state"):
            with self.subTest(view=name):
                response = self.client.get(reverse(f"outreach:{name}",
                                                  args=[theirs.pk]))
                self.assertEqual(response.status_code, 404)

    def test_the_list_shows_past_audits(self):
        audited(self.user)

        page = self.client.get(reverse("outreach:audits"))

        self.assertContains(page, "abcroofing.example")


class EditingTests(SignedIn):
    def setUp(self):
        super().setUp()
        self.account = account_for(self.user)
        self.job = audited(self.user)

    def _save(self, **fields):
        import json

        data = {"recipient": self.job.recipient,
                "subject": self.job.draft.subject,
                "body": self.job.draft.body}
        data.update(fields)
        return self.client.post(
            reverse("outreach:audit_save", args=[self.job.pk]),
            data=json.dumps(data), content_type="application/json")

    def test_the_body_can_be_edited(self):
        response = self._save(body="My own words.")

        self.assertEqual(response.status_code, 200)
        self.job.draft.refresh_from_db()
        self.assertEqual(self.job.draft.body, "My own words.")
        self.assertTrue(self.job.draft.edited)

    def test_the_subject_can_be_edited(self):
        self._save(subject="A different subject")

        self.job.draft.refresh_from_db()
        self.assertEqual(self.job.draft.subject, "A different subject")

    def test_the_recipient_can_be_changed(self):
        self._save(recipient="info@abcroofing.example")

        self.job.refresh_from_db()
        self.assertEqual(self.job.recipient, "info@abcroofing.example")
        self.assertTrue(self.job.recipient_manual)

    def test_a_hand_typed_recipient_survives_a_re_audit(self):
        """§17: an address a person supplied is not overwritten by a crawl."""
        self._save(recipient="someone@elsewhere.example")

        with Fake():
            AuditJob.objects.filter(pk=self.job.pk).update(
                state=AuditJob.State.QUEUED, locked_by="", locked_until=None)
            self.job.refresh_from_db()
            siteaudit.run_job(self.job)

        self.job.refresh_from_db()
        self.assertEqual(self.job.recipient, "someone@elsewhere.example")

    def test_a_bad_recipient_is_refused(self):
        response = self._save(recipient="not an address")

        self.assertEqual(response.status_code, 400)

    def test_regenerating_rewrites_from_the_same_findings(self):
        import json

        second = ai.GeneratedEmail("Another subject", BODY, WRITTEN.observation,
                                  ["AUD-001"])

        with mock.patch.object(ai, "generate", return_value=second) as write:
            response = self.client.post(
                reverse("outreach:audit_regenerate", args=[self.job.pk]),
                data=json.dumps({}), content_type="application/json")

        self.assertEqual(response.status_code, 200)
        self.assertTrue(write.called)
        self.job.draft.refresh_from_db()
        self.assertEqual(self.job.draft.subject, "Another subject")

    def test_regenerating_does_not_re_crawl(self):
        import json

        with mock.patch.object(ai, "generate", return_value=WRITTEN), \
             mock.patch.object(crawler, "analyse") as crawl:
            self.client.post(
                reverse("outreach:audit_regenerate", args=[self.job.pk]),
                data=json.dumps({}), content_type="application/json")

        crawl.assert_not_called()

    def test_regenerating_with_no_findings_refuses_rather_than_inventing(self):
        import json

        job = audited(self.user, url="https://second.example/",
                     pages={"https://second.example/": HOME}, findings=[])

        response = self.client.post(
            reverse("outreach:audit_regenerate", args=[job.pk]),
            data=json.dumps({}), content_type="application/json")

        self.assertEqual(response.status_code, 502)
        self.assertIn("nothing to say", response.json()["error"])


# --------------------------------------------------------------------------- #
# Sections 13, 15, 16: sending
# --------------------------------------------------------------------------- #

class SendTests(SignedIn):
    def setUp(self):
        super().setUp()
        self.account = account_for(self.user)
        self.job = audited(self.user)

    def _send(self, confirm=True, **extra):
        import json

        data = {**extra}
        if confirm:
            data["confirm"] = True
        return self.client.post(
            reverse("outreach:audit_send", args=[self.job.pk]),
            data=json.dumps(data), content_type="application/json")

    def test_an_unconfirmed_send_does_nothing(self):
        """§15: the provider is not called until the confirmation comes back."""
        smtp = FakeSmtp()

        with mock.patch.object(transport, "Session", return_value=smtp):
            response = self._send(confirm=False)

        self.assertEqual(response.status_code, 400)
        self.assertEqual(smtp.sent, [])
        self.assertEqual(smtp.opened, 0)
        self.job.refresh_from_db()
        self.assertNotEqual(self.job.state, AuditJob.State.SENT)

    def test_an_unconfirmed_send_returns_what_to_confirm(self):
        response = self._send(confirm=False)

        confirm = response.json()["confirm"]
        self.assertEqual(confirm["recipient"], self.job.recipient)
        self.assertEqual(confirm["subject"], self.job.draft.subject)

    def test_a_confirmed_send_goes_out(self):
        smtp = FakeSmtp()

        with mock.patch.object(transport, "Session", return_value=smtp):
            response = self._send()

        self.assertEqual(response.status_code, 200)
        self.assertEqual([call["to_email"] for call in smtp.sent],
                         [self.job.recipient])

    def test_the_send_is_recorded(self):
        """§16: everything needed to answer "what did we send, to whom, when"."""
        smtp = FakeSmtp()

        with mock.patch.object(transport, "Session", return_value=smtp):
            self._send()

        self.job.refresh_from_db()
        record = SentLead.objects.get()
        self.assertEqual(self.job.state, AuditJob.State.SENT)
        self.assertEqual(self.job.message_id, "<1@agency.example>")
        self.assertIsNotNone(self.job.sent_at)
        self.assertEqual(self.job.sent_account, self.account)
        self.assertEqual(self.job.sent_lead, record)
        self.assertEqual(record.email, self.job.recipient)
        self.assertEqual(record.status, SentLead.Status.SENT)
        self.assertEqual(record.sender_email, self.account.sender_email)
        self.assertEqual(record.website, self.job.url)
        self.assertIn("website audit", record.campaign_label.lower())

    def test_the_accounts_signature_is_added(self):
        smtp = FakeSmtp()

        with mock.patch.object(transport, "Session", return_value=smtp):
            self._send()

        self.assertIn("Sam Rivers", smtp.sent[0]["body"])

    def test_the_edited_text_is_what_gets_sent(self):
        import json

        self.client.post(
            reverse("outreach:audit_save", args=[self.job.pk]),
            data=json.dumps({"recipient": "info@abcroofing.example",
                             "subject": "My subject", "body": "My body."}),
            content_type="application/json")
        smtp = FakeSmtp()

        with mock.patch.object(transport, "Session", return_value=smtp):
            self._send()

        self.assertEqual(smtp.sent[0]["to_email"], "info@abcroofing.example")
        self.assertEqual(smtp.sent[0]["subject"], "My subject")
        self.assertIn("My body.", smtp.sent[0]["body"])

    def test_a_second_send_is_refused(self):
        smtp = FakeSmtp()

        with mock.patch.object(transport, "Session", return_value=smtp):
            self._send()
            again = self._send()

        self.assertEqual(again.status_code, 409)
        self.assertEqual(len(smtp.sent), 1)
        self.assertEqual(SentLead.objects.count(), 1)

    def test_a_failed_send_is_not_recorded_as_sent(self):
        smtp = FakeSmtp(fail=transport.SendError("the provider refused"))

        with mock.patch.object(transport, "Session", return_value=smtp):
            response = self._send()

        self.assertEqual(response.status_code, 409)
        self.job.refresh_from_db()
        self.assertNotEqual(self.job.state, AuditJob.State.SENT)
        self.assertEqual(self.job.message_id, "")
        self.assertEqual(SentLead.objects.get().status, SentLead.Status.FAILED)

    def test_a_failed_send_can_be_tried_again(self):
        failing = FakeSmtp(fail=transport.SendError("temporary"))
        working = FakeSmtp()

        with mock.patch.object(transport, "Session", return_value=failing):
            self._send()
        with mock.patch.object(transport, "Session", return_value=working):
            response = self._send()

        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(working.sent), 1)

    def test_a_suppressed_address_is_never_sent_to(self):
        Suppression.objects.create(owner=self.user,
                                   email=self.job.recipient,
                                   reason=Suppression.Reason.MANUAL)
        smtp = FakeSmtp()

        with mock.patch.object(transport, "Session", return_value=smtp):
            response = self._send()

        self.assertEqual(response.status_code, 409)
        self.assertEqual(smtp.sent, [])

    def test_an_address_already_contacted_is_refused(self):
        SentLead.objects.create(owner=self.user, email=self.job.recipient,
                               business_name="Earlier",
                               status=SentLead.Status.SENT)
        smtp = FakeSmtp()

        with mock.patch.object(transport, "Session", return_value=smtp):
            response = self._send()

        self.assertEqual(response.status_code, 409)
        self.assertEqual(smtp.sent, [])

    def test_an_inactive_account_cannot_send(self):
        mailaccounts.set_active(self.user, self.account, False)
        smtp = FakeSmtp()

        with mock.patch.object(transport, "Session", return_value=smtp):
            response = self._send()

        self.assertEqual(response.status_code, 409)
        self.assertEqual(smtp.sent, [])

    def test_sending_with_no_recipient_is_refused(self):
        AuditJob.objects.filter(pk=self.job.pk).update(recipient="")
        self.job.refresh_from_db()
        smtp = FakeSmtp()

        with mock.patch.object(transport, "Session", return_value=smtp):
            response = self._send()

        self.assertEqual(response.status_code, 409)
        self.assertEqual(smtp.sent, [])

    def test_a_sent_audit_cannot_be_edited(self):
        import json

        with mock.patch.object(transport, "Session", return_value=FakeSmtp()):
            self._send()

        response = self.client.post(
            reverse("outreach:audit_save", args=[self.job.pk]),
            data=json.dumps({"body": "changed"}),
            content_type="application/json")

        self.assertEqual(response.status_code, 409)

    def test_another_workspace_cannot_send_my_audit(self):
        other = OtherUser()
        smtp = FakeSmtp()

        with mock.patch.object(transport, "Session", return_value=smtp):
            response = other.client.post(
                reverse("outreach:audit_send", args=[self.job.pk]),
                data='{"confirm": true}', content_type="application/json")

        self.assertEqual(response.status_code, 404)
        self.assertEqual(smtp.sent, [])

    def test_the_service_has_no_send_path(self):
        """§21, asserted rather than asserted-in-a-comment."""
        source = (__import__("pathlib").Path(siteaudit.__file__)
                  .read_text(encoding="utf-8"))

        self.assertNotIn("transport.Session", source)
        self.assertNotIn("auditsend", source.replace(
            "from . import websiteaudit", ""))


class NoEmailFoundTests(SignedIn):
    """§17: nothing is guessed, and the audit survives."""

    NO_CONTACT = {
        "https://noaddress.example/": (
            "<html><head><title>No Address Ltd</title></head><body>"
            "<h1>No Address Ltd</h1><p>Call us on 555 123 4567.</p>"
            "</body></html>"),
    }

    def setUp(self):
        super().setUp()
        self.account = account_for(self.user)
        self.job = audited(self.user, url="https://noaddress.example/",
                          pages=self.NO_CONTACT)

    def test_no_address_is_invented(self):
        self.assertEqual(self.job.recipient, "")
        self.assertEqual(self.job.emails_found, [])

    def test_the_page_says_so_and_lists_where_it_looked(self):
        page = self.client.get(
            reverse("outreach:audit_view", args=[self.job.pk]))

        self.assertContains(page, "No public email address was found")
        self.assertContains(page, "Pages checked")
        self.assertTrue(self.job.contact_pages)

    def test_the_findings_are_still_there(self):
        self.assertTrue(self.job.findings)
        self.assertTrue(self.job.draft.subject)

    def test_a_person_can_supply_an_address_and_send(self):
        import json

        self.client.post(
            reverse("outreach:audit_save", args=[self.job.pk]),
            data=json.dumps({"recipient": "owner@noaddress.example",
                             "subject": self.job.draft.subject,
                             "body": self.job.draft.body}),
            content_type="application/json")
        smtp = FakeSmtp()

        with mock.patch.object(transport, "Session", return_value=smtp):
            response = self.client.post(
                reverse("outreach:audit_send", args=[self.job.pk]),
                data='{"confirm": true}', content_type="application/json")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(smtp.sent[0]["to_email"], "owner@noaddress.example")


class SendRefusalTests(TestCase):
    """`auditsend.send` refuses on its own, not only through the view."""

    def setUp(self):
        self.user = make_user("refuse@example.test")
        self.account = account_for(self.user)
        self.job = audited(self.user)

    def test_it_refuses_without_an_account(self):
        with self.assertRaises(auditsend.SendRefused):
            auditsend.send(self.job, None)

    def test_it_refuses_an_account_with_no_password(self):
        mailaccounts.clear_secret(self.user, self.account)

        with self.assertRaises(auditsend.SendRefused):
            auditsend.send(self.job, self.account)

    def test_it_refuses_a_job_with_no_draft(self):
        AuditJob.objects.filter(pk=self.job.pk).update(draft=None)
        self.job.refresh_from_db()

        with self.assertRaises(auditsend.SendRefused):
            auditsend.send(self.job, self.account)
