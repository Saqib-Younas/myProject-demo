"""
One lead, all the way through: crawl, review, write, send.

With all three externals stubbed, so it runs offline and costs nothing. The guarantees
under test are the ones that would quietly do the wrong thing if they broke: one bad
address must not stop the loop, the same campaign must not reach the same lead twice,
and the leads go through one at a time rather than batched by stage.
"""

from __future__ import annotations

from unittest import mock

from django.db import IntegrityError, transaction
from django.urls import reverse
from django.utils import timezone

from apps import ai
from apps.ai.tests.factories import make_findings
from apps.auditing import crawler, measurements, scoring
from apps.core.testing import EMAIL_BODY, SignedIn
from apps.outreach.mail import providers, transport
from apps.outreach.models import Campaign, EmailDraft
from apps.outreach.services import pipeline as runner

from .factories import FakeSession, make_campaign, make_draft


class BulkSendTests(SignedIn):
    """runner._send_all -- the loop that must not stop on one bad address."""

    def setUp(self):
        self.campaign = make_campaign()
        self.drafts = [
            make_draft(self.campaign, business_name=f"Shop {i}",
                       email=f"shop{i}@example.test",
                       status=EmailDraft.Status.APPROVED)
            for i in range(4)
        ]

    def _run(self, session):
        with mock.patch.object(transport, "Session", return_value=session), \
             mock.patch.object(runner.time, "sleep"):
            runner._send_all(self.campaign, "pw", "", 0)
        self.campaign.refresh_from_db()

    def test_all_approved_emails_are_sent(self):
        session = FakeSession()
        self._run(session)

        self.assertEqual(len(session.sent), 4)
        self.assertEqual(self.campaign.counts()["sent"], 4)
        self.assertEqual(self.campaign.phase, Campaign.Phase.DONE)

    def test_one_rejected_recipient_does_not_stop_the_rest(self):
        session = FakeSession(fail_for={"shop1@example.test"})
        self._run(session)

        counts = self.campaign.counts()
        self.assertEqual(counts["sent"], 3)
        self.assertEqual(counts["failed"], 1)
        self.assertEqual(len(session.sent), 3)

        failed = self.campaign.drafts.get(email="shop1@example.test")
        self.assertEqual(failed.status, EmailDraft.Status.FAILED)
        self.assertIn("SMTPRecipientsRefused", failed.error_message)

    def test_sent_drafts_record_a_timestamp_and_no_error(self):
        self._run(FakeSession())
        draft = self.campaign.drafts.filter(status=EmailDraft.Status.SENT).first()

        self.assertIsNotNone(draft.sent_at)
        self.assertEqual(draft.error_message, "")

    def test_auth_failure_stops_the_run_and_explains_itself(self):
        session = FakeSession(raise_on_enter=transport.SendError("login rejected"))
        self._run(session)

        self.assertEqual(self.campaign.counts()["sent"], 0)
        self.assertIn("login rejected", self.campaign.error)
        self.assertEqual(self.campaign.phase, Campaign.Phase.DONE)
        # Nothing was consumed -- the drafts are still approved and sendable.
        self.assertEqual(self.campaign.counts()["approved"], 4)

    def test_daily_cap_stops_sending_and_says_what_is_left(self):
        capped = providers.Provider(
            "gmail", "Gmail", "smtp.gmail.com", 587, delay=0, daily_cap=2,
            note="test cap",
        )
        session = FakeSession()

        with mock.patch.dict(providers.PROVIDERS, {"gmail": capped}), \
             mock.patch.object(transport, "Session", return_value=session), \
             mock.patch.object(runner.time, "sleep"):
            runner._send_all(self.campaign, "pw", "", 0)

        self.campaign.refresh_from_db()
        self.assertEqual(len(session.sent), 2)
        self.assertEqual(self.campaign.counts()["sent"], 2)
        self.assertEqual(self.campaign.counts()["approved"], 2)
        self.assertIn("daily cap", self.campaign.error.lower())

    def test_sent_today_counts_only_todays_sends(self):
        draft = self.drafts[0]
        draft.status = EmailDraft.Status.SENT
        draft.sent_at = timezone.now()
        draft.save()

        self.assertEqual(runner.sent_today("sam@agency.test"), 1)
        self.assertEqual(runner.sent_today("someone@else.test"), 0)
class DoubleSendGuardTests(SignedIn):
    """The brief's "do not send the same campaign to the same lead twice"."""

    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(self.campaign, status=EmailDraft.Status.APPROVED)

    def test_a_draft_can_only_be_claimed_once(self):
        self.assertTrue(runner._claim_draft(self.draft.pk))
        # A second claim -- a double-click, or a second thread -- finds nothing.
        self.assertFalse(runner._claim_draft(self.draft.pk))

    def test_an_already_sent_draft_cannot_be_claimed(self):
        EmailDraft.objects.filter(pk=self.draft.pk).update(
            status=EmailDraft.Status.SENT)

        self.assertFalse(runner._claim_draft(self.draft.pk))

    def test_a_second_send_run_sends_nothing_new(self):
        session_one, session_two = FakeSession(), FakeSession()

        for session in (session_one, session_two):
            with mock.patch.object(transport, "Session", return_value=session), \
                 mock.patch.object(runner.time, "sleep"):
                runner._send_all(self.campaign, "pw", "", 0)

        self.assertEqual(len(session_one.sent), 1)
        self.assertEqual(len(session_two.sent), 0)
        self.campaign.refresh_from_db()
        self.assertEqual(self.campaign.counts()["sent"], 1)

    def test_one_email_cannot_enter_the_same_campaign_twice(self):

        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                make_draft(self.campaign, business_name="Copycat")

    def test_leads_without_an_email_do_not_collide(self):
        make_draft(self.campaign, business_name="A", email="",
                   status=EmailDraft.Status.NO_EMAIL)
        make_draft(self.campaign, business_name="B", email="",
                   status=EmailDraft.Status.NO_EMAIL)

        self.assertEqual(self.campaign.drafts.filter(email="").count(), 2)
class PipelineTests(SignedIn):
    """crawl -> review -> generate, with all three externals stubbed."""

    def setUp(self):
        self.campaign = make_campaign(phase=Campaign.Phase.SETUP)
        self.draft = make_draft(self.campaign, subject="", body="",
                                observation="", analysis_context="",
                                analysis_status="",
                                status=EmailDraft.Status.PENDING)

    def _analysis(self, status=crawler.OK, pages=2):
        return crawler.SiteAnalysis(
            status, f"Read {pages} page(s).",
            [measurements.Page(f"https://bella.example/{i}", "home" if not i else "services",
                           "Bella Cucina", "", ["Wood-fired pizza"],
                           "Hand-made sourdough.", {"cta_count": 0})
             for i in range(pages)],
            discovered=11,
        ) if status == crawler.OK else crawler.SiteAnalysis(status, "blocked.")

    def _audit(self):
        return ai.SiteAudit("A family pizzeria.", make_findings(9))

    def _email(self):
        return ai.GeneratedEmail(
            "Booking for Bella Cucina", "Hi.\n\nSam", "no call to action",
            ["Issue 0"])

    def test_all_three_stages_run_and_land_in_review(self):
        with mock.patch.object(crawler, "analyse", return_value=self._analysis()), \
             mock.patch.object(ai, "audit", return_value=self._audit()), \
             mock.patch.object(ai, "generate", return_value=self._email()):
            runner._pipeline(self.campaign)

        self.campaign.refresh_from_db()
        self.draft.refresh_from_db()
        self.assertEqual(self.campaign.phase, Campaign.Phase.REVIEW)
        self.assertEqual(self.draft.status, EmailDraft.Status.GENERATED)
        self.assertEqual(self.draft.subject, "Booking for Bella Cucina")
        self.assertEqual(len(self.draft.findings), 9)
        self.assertEqual(self.draft.business_summary, "A family pizzeria.")
        self.assertEqual(self.draft.findings_used, ["Issue 0"])
        self.assertEqual(self.draft.pages_discovered, 11)
        self.assertEqual(len(self.draft.pages_read), 2)

    def test_the_review_receives_the_crawled_context_not_the_raw_url(self):
        with mock.patch.object(crawler, "analyse", return_value=self._analysis()), \
             mock.patch.object(ai, "audit", return_value=self._audit()) as audit, \
             mock.patch.object(ai, "generate", return_value=self._email()):
            runner._pipeline(self.campaign)

        kwargs = audit.call_args.kwargs
        self.assertIn("cta_count=0", kwargs["site_context"])
        self.assertEqual(kwargs["pages_read"], 2)
        self.assertEqual(kwargs["discovered"], 11)

    def test_the_email_stage_receives_the_ranked_shortlist(self):
        """Not all nine findings -- the two or three worth an email.

        Ten findings in a prompt produce an email that mentions three of them
        badly. The commercial ranking happens in `scoring`, and the email stage
        receives only its shortlist, so the prompt is built on the findings that
        matter to the business rather than on everything that was measurable.
        """
        with mock.patch.object(crawler, "analyse", return_value=self._analysis()), \
             mock.patch.object(ai, "audit", return_value=self._audit()), \
             mock.patch.object(ai, "generate", return_value=self._email()) as generate:
            runner._pipeline(self.campaign)

        kwargs = generate.call_args.kwargs
        findings = kwargs["findings"]
        self.assertEqual(len(findings), scoring.EMAIL_FINDING_LIMIT)
        self.assertIsInstance(findings[0], ai.Finding)
        self.assertEqual(kwargs["business_summary"], "A family pizzeria.")

    def test_the_email_stage_receives_the_structured_evidence(self):
        """Section 5: not just a URL -- the pages read, and what was measured."""
        with mock.patch.object(crawler, "analyse", return_value=self._analysis()), \
             mock.patch.object(ai, "audit", return_value=self._audit()), \
             mock.patch.object(ai, "generate", return_value=self._email()) as generate:
            runner._pipeline(self.campaign)

        kwargs = generate.call_args.kwargs
        self.assertTrue(kwargs["pages"])
        self.assertTrue(all("url" in page for page in kwargs["pages"]))
        self.assertIn("cta_count", kwargs["signals"])

    def test_a_blocked_website_skips_the_review_and_still_emails(self):
        with mock.patch.object(crawler, "analyse",
                               return_value=self._analysis(crawler.BLOCKED)), \
             mock.patch.object(ai, "audit") as audit, \
             mock.patch.object(ai, "generate",
                               return_value=ai.GeneratedEmail("Q", EMAIL_BODY, "none", [])) as generate:
            runner._pipeline(self.campaign)

        self.draft.refresh_from_db()
        self.assertEqual(self.draft.analysis_status, crawler.BLOCKED)
        self.assertEqual(self.draft.status, EmailDraft.Status.GENERATED)
        # No material means no review call at all, and no findings to email from.
        audit.assert_not_called()
        self.assertEqual(generate.call_args.kwargs["findings"], [])
        self.assertEqual(self.draft.findings, [])
        self.assertEqual(self.draft.observation, "none")

    def test_a_failed_review_still_lets_the_email_stage_run(self):
        with mock.patch.object(crawler, "analyse", return_value=self._analysis()), \
             mock.patch.object(ai, "audit", side_effect=ai.AiError("quota")), \
             mock.patch.object(ai, "generate",
                               return_value=ai.GeneratedEmail("Q", EMAIL_BODY, "none", [])):
            runner._pipeline(self.campaign)

        self.draft.refresh_from_db()
        self.assertEqual(self.draft.status, EmailDraft.Status.GENERATED)
        self.assertEqual(self.draft.findings, [])

    def test_generation_failure_surfaces_on_the_campaign(self):
        with mock.patch.object(crawler, "analyse",
                               return_value=self._analysis(crawler.NO_WEBSITE)), \
             mock.patch.object(ai, "generate",
                               side_effect=ai.AiError("Set GROQ_API_KEY")):
            runner._pipeline(self.campaign)

        self.campaign.refresh_from_db()
        self.draft.refresh_from_db()
        self.assertEqual(self.campaign.phase, Campaign.Phase.REVIEW)
        self.assertIn("GROQ_API_KEY", self.campaign.error)
        self.assertIn("GROQ_API_KEY", self.draft.error_message)
class SequentialPipelineTests(SignedIn):
    """One lead all the way through, then the next. Never batched by stage."""

    NAMES = (("Alpha Cafe", "alpha"), ("Beta Bakery", "beta"),
             ("Gamma Grill", "gamma"))

    def setUp(self):
        self.campaign = make_campaign(phase=Campaign.Phase.SETUP)
        for name, slug in self.NAMES:
            make_draft(
                self.campaign, business_name=name,
                email=f"hi@{slug}.example", website=f"https://{slug}.example",
                subject="", body="", observation="", analysis_context="",
                analysis_status="", status=EmailDraft.Status.PENDING,
            )
        self.calls = []

    def _analysis(self, url, status=crawler.OK):
        if status != crawler.OK:
            return crawler.SiteAnalysis(status, "Website unavailable.")
        return crawler.SiteAnalysis(
            status, "Read 2 page(s).",
            [measurements.Page(f"{url}/{kind}", kind, "Title", "", ["Heading"],
                           "Some prose.", {"cta_count": 0})
             for kind in ("home", "services")],
            discovered=7,
        )

    def _run(self, analyse=None, audit=None, generate=None):
        """Run the pipeline with the three externals recording their order."""
        def default_analyse(url, **kwargs):
            # **kwargs swallows `should_stop`, which the pipeline now passes so
            # a cancel can interrupt a crawl between page fetches.
            self.calls.append(("analyse", url))
            return self._analysis(url)

        def default_audit(**kwargs):
            self.calls.append(("audit", kwargs["website"]))
            return ai.SiteAudit("A local eatery.", make_findings(9))

        def default_generate(**kwargs):
            self.calls.append(("generate", kwargs["website"]))
            return ai.GeneratedEmail(
                f"A quick idea for {kwargs['business_name']}",
                EMAIL_BODY, "no call to action", ["Issue 0"])

        with mock.patch.object(crawler, "analyse",
                               side_effect=analyse or default_analyse), \
             mock.patch.object(ai, "audit", side_effect=audit or default_audit), \
             mock.patch.object(ai, "generate",
                               side_effect=generate or default_generate):
            runner._pipeline(self.campaign)

    def test_each_lead_is_finished_before_the_next_one_is_started(self):
        self._run()

        # The whole point: no lead's crawl happens before the previous lead's
        # email has been written.
        self.assertEqual(self.calls, [
            ("analyse", "https://alpha.example"),
            ("audit", "https://alpha.example"),
            ("generate", "https://alpha.example"),
            ("analyse", "https://beta.example"),
            ("audit", "https://beta.example"),
            ("generate", "https://beta.example"),
            ("analyse", "https://gamma.example"),
            ("audit", "https://gamma.example"),
            ("generate", "https://gamma.example"),
        ])

    def test_the_running_order_is_stamped_and_every_lead_is_marked_saved(self):
        self._run()

        rows = list(self.campaign.drafts.order_by("sequence")
                    .values_list("sequence", "business_name"))
        self.assertEqual(rows, [(1, "Alpha Cafe"), (2, "Beta Bakery"),
                                (3, "Gamma Grill")])
        for draft in self.campaign.drafts.all():
            self.assertIsNotNone(draft.processed_at, draft.business_name)
            self.assertEqual(draft.status, EmailDraft.Status.GENERATED)
            self.assertTrue(draft.subject)
            self.assertEqual(len(draft.findings), 9)

        # Nothing is left claiming to be in flight.
        self.campaign.refresh_from_db()
        self.assertEqual(self.campaign.phase, Campaign.Phase.REVIEW)
        self.assertIsNone(self.campaign.current_draft_id)
        self.assertEqual(self.campaign.current_step, "")

    def test_progress_names_the_lead_and_the_step_in_flight(self):
        seen = {}

        def generate(**kwargs):
            if kwargs["business_name"] == "Beta Bakery":
                # Snapshot what the progress panel would be told, mid-run.
                seen.update(Campaign.objects.get(pk=self.campaign.pk).progress())
            return ai.GeneratedEmail("Subject", EMAIL_BODY, "none", [])

        self._run(generate=generate)

        self.assertEqual(seen["total"], 3)
        self.assertEqual(seen["done"], 1)
        self.assertEqual(seen["position"], 2)
        self.assertEqual(seen["percent"], 67)
        self.assertEqual(seen["step"], "generate")
        self.assertEqual(seen["current"]["business_name"], "Beta Bakery")
        self.assertEqual(seen["current"]["website"], "https://beta.example")
        self.assertEqual(seen["next"]["business_name"], "Gamma Grill")
        self.assertFalse(seen["finished"])
        self.assertEqual([step["state"] for step in seen["steps"]],
                         ["done", "done", "current", "waiting", "waiting"])
        self.assertEqual([lead["state"] for lead in seen["leads"]],
                         ["completed", "current", "waiting"])

    def test_progress_reads_as_complete_once_the_run_finishes(self):
        self._run()

        progress = Campaign.objects.get(pk=self.campaign.pk).progress()
        self.assertEqual(progress["position"], 3)
        self.assertEqual(progress["percent"], 100)
        self.assertTrue(progress["finished"])
        self.assertIsNone(progress["current"])
        self.assertIsNone(progress["next"])
        self.assertEqual({lead["state"] for lead in progress["leads"]},
                         {"completed"})
        self.assertEqual([step["state"] for step in progress["steps"]],
                         ["done"] * len(progress["steps"]))

    def test_an_unreachable_website_does_not_stop_the_campaign(self):
        def analyse(url, **kwargs):
            self.calls.append(("analyse", url))
            status = crawler.BLOCKED if "beta" in url else crawler.OK
            return self._analysis(url, status)

        self._run(analyse=analyse)

        # Nothing was reviewed for Beta -- there was no material to review --
        # but the other two leads were processed normally either side of it.
        self.assertEqual([url for kind, url in self.calls if kind == "audit"],
                         ["https://alpha.example", "https://gamma.example"])
        self.assertEqual(
            [url for kind, url in self.calls if kind == "generate"],
            ["https://alpha.example", "https://beta.example",
             "https://gamma.example"])

        beta = self.campaign.drafts.get(business_name="Beta Bakery")
        self.assertEqual(beta.analysis_status, crawler.BLOCKED)
        self.assertEqual(beta.findings, [])
        self.assertTrue(beta.subject)            # still got an email
        self.assertIsNotNone(beta.processed_at)  # and was saved and moved past
        self.assertEqual(beta.status, EmailDraft.Status.GENERATED)

        self.campaign.refresh_from_db()
        self.assertEqual(self.campaign.phase, Campaign.Phase.REVIEW)
        self.assertEqual(self.campaign.error, "")

    def test_one_failed_email_leaves_the_other_leads_drafted(self):
        def generate(**kwargs):
            if kwargs["business_name"] == "Beta Bakery":
                raise ai.AiError("rate limited")
            return ai.GeneratedEmail("Subject", EMAIL_BODY, "none", [])

        self._run(generate=generate)

        beta = self.campaign.drafts.get(business_name="Beta Bakery")
        self.assertEqual(beta.subject, "")
        self.assertIn("rate limited", beta.error_message)
        self.assertIsNotNone(beta.processed_at)

        others = self.campaign.drafts.exclude(business_name="Beta Bakery")
        for draft in others:
            self.assertEqual(draft.status, EmailDraft.Status.GENERATED)
            self.assertTrue(draft.subject)

        # One failure out of three is not a campaign-level error.
        self.campaign.refresh_from_db()
        self.assertEqual(self.campaign.error, "")

        progress = Campaign.objects.get(pk=self.campaign.pk).progress()
        states = {lead["business_name"]: lead["state"]
                  for lead in progress["leads"]}
        self.assertEqual(states["Beta Bakery"], "failed")
        self.assertEqual(states["Alpha Cafe"], "completed")
class AiRetryTests(SignedIn):
    """One retry for a transient AI failure, none for a permanent one."""

    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(self.campaign, subject="", body="",
                                observation="")
        self.email = ai.GeneratedEmail("Subject", EMAIL_BODY, "none", [])

    def _generate(self, side_effect, **kwargs):
        with mock.patch.object(runner, "AI_RETRY_DELAY", 0), \
             mock.patch.object(ai, "generate", side_effect=side_effect) as call:
            ok = runner.generate_draft(self.draft, self.campaign, **kwargs)
        return ok, call

    def test_a_transient_failure_is_retried_and_can_succeed(self):
        ok, call = self._generate(
            [ai.AiError("rate limited", retryable=True), self.email],
            retries=1)

        self.assertTrue(ok)
        self.assertEqual(call.call_count, 2)
        self.draft.refresh_from_db()
        self.assertEqual(self.draft.subject, "Subject")
        self.assertEqual(self.draft.error_message, "")

    def test_a_permanent_failure_is_not_retried(self):
        ok, call = self._generate(
            ai.AiError("Set GROQ_API_KEY in .env"), retries=1)

        self.assertFalse(ok)
        self.assertEqual(call.call_count, 1)
        self.draft.refresh_from_db()
        self.assertIn("GROQ_API_KEY", self.draft.error_message)

    def test_the_retry_is_given_up_after_one_attempt(self):
        ok, call = self._generate(
            ai.AiError("still rate limited", retryable=True), retries=1)

        self.assertFalse(ok)
        self.assertEqual(call.call_count, 2)
        self.draft.refresh_from_db()
        self.assertIn("still rate limited", self.draft.error_message)

    def test_the_interactive_path_does_not_retry(self):
        """A user waiting on a click gets the error, not a silent 20s pause."""
        ok, call = self._generate(
            [ai.AiError("rate limited", retryable=True), self.email])

        self.assertFalse(ok)
        self.assertEqual(call.call_count, 1)

    def test_the_review_stage_retries_too(self):
        self.draft.analysis_context = "### PAGE 1 -- HOME"
        self.draft.save(update_fields=["analysis_context"])
        audit = ai.SiteAudit("A cafe.", make_findings(5))

        with mock.patch.object(runner, "AI_RETRY_DELAY", 0), \
             mock.patch.object(ai, "audit",
                              side_effect=[ai.AiError("429", retryable=True),
                                           audit]) as call:
            runner.review_draft(self.draft, retries=1)

        self.assertEqual(call.call_count, 2)
        self.draft.refresh_from_db()
        self.assertEqual(len(self.draft.findings), 5)

    def test_the_pipeline_asks_for_a_retry(self):
        EmailDraft.objects.filter(pk=self.draft.pk).update(
            status=EmailDraft.Status.PENDING, analysis_context="",
            analysis_status="")
        self.draft.refresh_from_db()

        with mock.patch.object(runner, "AI_RETRY_DELAY", 0), \
             mock.patch.object(crawler, "analyse", return_value=crawler.SiteAnalysis(
                 crawler.NO_WEBSITE, "no website")), \
             mock.patch.object(ai, "generate",
                               side_effect=[ai.AiError("429", retryable=True),
                                            self.email]) as call:
            runner._pipeline(self.campaign)

        self.assertEqual(call.call_count, 2)
        self.draft.refresh_from_db()
        self.assertEqual(self.draft.status, EmailDraft.Status.GENERATED)

    def test_backends_mark_rate_limits_as_retryable(self):
        self.assertTrue(ai.AiError("x", retryable=True).retryable)
        self.assertFalse(ai.AiError("x").retryable)
class RereviewTests(SignedIn):
    """The Re-review action re-runs the review, then rebuilds the email."""

    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(
            self.campaign,
            analysis_context="### PAGE 1 -- HOME\nMeasured signals: cta_count=0",
        )

    def _act(self, action="rereview", **body):
        return self.client.post(
            reverse("outreach:draft_action", args=[self.draft.pk, action]),
            data=body, content_type="application/json",
        )

    def test_rereview_replaces_the_findings_and_the_email(self):
        audit = ai.SiteAudit("Pizzeria.", make_findings(8))
        email = ai.GeneratedEmail("Fresh", EMAIL_BODY, "no CTA", ["Issue 0"])

        with mock.patch.object(ai, "audit", return_value=audit), \
             mock.patch.object(ai, "generate", return_value=email):
            response = self._act()

        self.assertEqual(response.status_code, 200)
        self.draft.refresh_from_db()
        self.assertEqual(len(self.draft.findings), 8)
        self.assertEqual(self.draft.subject, "Fresh")
        self.assertEqual(response.json()["draft"]["findings"][0]["issue"], "Issue 0")

    def test_rereview_without_crawled_material_is_refused(self):
        EmailDraft.objects.filter(pk=self.draft.pk).update(
            analysis_context="", analysis_note="robots.txt disallows")

        response = self._act()

        self.assertEqual(response.status_code, 400)
        self.assertIn("no crawled website material", response.json()["error"])

    def test_a_failing_rereview_reports_the_reason(self):
        with mock.patch.object(ai, "audit", side_effect=ai.AiError("quota hit")):
            response = self._act()

        self.assertEqual(response.status_code, 502)
        self.assertIn("quota hit", response.json()["error"])
class CountsTests(SignedIn):
    def test_counts_group_drafts_by_state(self):
        campaign = make_campaign()
        states = [
            EmailDraft.Status.APPROVED, EmailDraft.Status.APPROVED,
            EmailDraft.Status.SENT, EmailDraft.Status.FAILED,
            EmailDraft.Status.REJECTED, EmailDraft.Status.NO_EMAIL,
        ]
        for i, status in enumerate(states):
            make_draft(campaign, business_name=f"B{i}",
                       email=f"b{i}@x.test" if status != EmailDraft.Status.NO_EMAIL else "",
                       status=status)

        counts = campaign.counts()
        self.assertEqual(counts["total"], 6)
        self.assertEqual(counts["approved"], 2)
        self.assertEqual(counts["sent"], 1)
        self.assertEqual(counts["failed"], 1)
        self.assertEqual(counts["rejected"], 1)
        self.assertEqual(counts["no_email"], 1)
        self.assertEqual(counts["remaining"], 2)
