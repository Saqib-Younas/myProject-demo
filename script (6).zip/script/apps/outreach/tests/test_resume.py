"""
Picking up a run whose background thread died with the server.

A restart in the middle of a campaign is ordinary, and the state that survives it is in
the database rather than in a thread. These are the tests that say so: what `/state`
reports while a run is in flight, and what happens when somebody presses Resume.
"""

from __future__ import annotations

from unittest import mock

from django.urls import reverse
from django.utils import timezone

from apps import ai
from apps.ai.tests.factories import make_findings
from apps.auditing import crawler, measurements
from apps.core.testing import EMAIL_BODY, SignedIn
from apps.outreach.models import Campaign, EmailDraft
from apps.outreach.services import pipeline as runner

from .factories import make_campaign, make_draft


class ResumeTests(SignedIn):
    """Picking up a run whose background thread died with the server."""

    NAMES = (("Alpha Cafe", "alpha"), ("Beta Bakery", "beta"),
             ("Gamma Grill", "gamma"))

    def setUp(self):
        self.campaign = make_campaign(phase=Campaign.Phase.CRAWLING)
        self.drafts = {}
        for position, (name, slug) in enumerate(self.NAMES, start=1):
            self.drafts[name] = make_draft(
                self.campaign, business_name=name,
                email=f"hi@{slug}.example", website=f"https://{slug}.example",
                subject="", body="", observation="", analysis_context="",
                analysis_status="", status=EmailDraft.Status.PENDING,
                sequence=position,
            )
        self.calls = []

    def _finish(self, name, **fields):
        """Mark a lead as already completed by an earlier, interrupted run."""
        fields.setdefault("processed_at", timezone.now())
        EmailDraft.objects.filter(pk=self.drafts[name].pk).update(**fields)

    def _run(self):
        def analyse(url, **kwargs):
            self.calls.append(("analyse", url))
            return crawler.SiteAnalysis(
                crawler.OK, "Read 1 page(s).",
                [measurements.Page(url, "home", "T", "", ["H"], "prose",
                               {"cta_count": 0})],
                discovered=4)

        def audit(**kwargs):
            self.calls.append(("audit", kwargs["website"]))
            return ai.SiteAudit("A cafe.", make_findings(9))

        def generate(**kwargs):
            self.calls.append(("generate", kwargs["website"]))
            # A valid reply: it names what it used. An email that reports
            # "observation: none" while holding findings is a wrong answer and
            # would (correctly) be regenerated once.
            return ai.GeneratedEmail(
                "Subject", EMAIL_BODY, "no obvious way to get in touch",
                ["Issue 0"])

        with mock.patch.object(crawler, "analyse", side_effect=analyse), \
             mock.patch.object(ai, "audit", side_effect=audit), \
             mock.patch.object(ai, "generate", side_effect=generate):
            runner._pipeline(self.campaign, resume=True)

    # --- detection -------------------------------------------------------- #

    def test_a_working_phase_with_no_thread_is_stalled(self):
        for phase in (Campaign.Phase.CRAWLING, Campaign.Phase.ANALYSING,
                      Campaign.Phase.GENERATING):
            with self.subTest(phase=phase):
                self.campaign.phase = phase
                self.assertEqual(runner.stalled(self.campaign), "pipeline")

    def test_a_stalled_send_is_reported_separately(self):
        self.campaign.phase = Campaign.Phase.SENDING
        self.assertEqual(runner.stalled(self.campaign), "send")

    def test_a_finished_or_waiting_campaign_is_not_stalled(self):
        for phase in (Campaign.Phase.SETUP, Campaign.Phase.REVIEW,
                      Campaign.Phase.DONE, Campaign.Phase.FAILED):
            with self.subTest(phase=phase):
                self.campaign.phase = phase
                self.assertEqual(runner.stalled(self.campaign), "")

    def test_a_running_campaign_is_not_stalled(self):
        with mock.patch.object(runner, "is_running", return_value=True):
            self.assertEqual(runner.stalled(self.campaign), "")

    # --- what a resumed run does and does not repeat ----------------------- #

    def test_finished_leads_are_not_crawled_or_drafted_again(self):
        self._finish("Alpha Cafe", status=EmailDraft.Status.GENERATED,
                     subject="Already written")

        self._run()

        self.assertEqual([url for _kind, url in self.calls], [
            "https://beta.example", "https://beta.example",
            "https://beta.example", "https://gamma.example",
            "https://gamma.example", "https://gamma.example",
        ])
        # And the finished lead's email was left exactly as it was.
        self.drafts["Alpha Cafe"].refresh_from_db()
        self.assertEqual(self.drafts["Alpha Cafe"].subject, "Already written")

    def test_a_lead_interrupted_after_its_crawl_is_not_crawled_again(self):
        EmailDraft.objects.filter(pk=self.drafts["Alpha Cafe"].pk).update(
            status=EmailDraft.Status.CRAWLED,
            analysis_context="### PAGE 1 -- HOME\nMeasured signals: cta_count=0",
            analysis_status=crawler.OK,
        )
        self._finish("Beta Bakery", status=EmailDraft.Status.GENERATED,
                     subject="Done")
        self._finish("Gamma Grill", status=EmailDraft.Status.GENERATED,
                     subject="Done")

        self._run()

        # The crawl is the expensive part and it was already paid for.
        self.assertEqual(self.calls, [
            ("audit", "https://alpha.example"),
            ("generate", "https://alpha.example"),
        ])

    def test_a_lead_interrupted_after_its_review_only_needs_the_email(self):
        EmailDraft.objects.filter(pk=self.drafts["Alpha Cafe"].pk).update(
            status=EmailDraft.Status.ANALYSED,
            analysis_context="### PAGE 1 -- HOME",
            findings=[f.as_dict() for f in make_findings(4)],
        )
        for name in ("Beta Bakery", "Gamma Grill"):
            self._finish(name, status=EmailDraft.Status.GENERATED, subject="Done")

        self._run()

        self.assertEqual(self.calls, [("generate", "https://alpha.example")])
        self.drafts["Alpha Cafe"].refresh_from_db()
        self.assertEqual(len(self.drafts["Alpha Cafe"].findings), 4)

    def test_a_lead_that_only_missed_its_completion_stamp_costs_nothing(self):
        EmailDraft.objects.filter(pk=self.drafts["Alpha Cafe"].pk).update(
            status=EmailDraft.Status.GENERATED, subject="Written already",
        )
        for name in ("Beta Bakery", "Gamma Grill"):
            self._finish(name, status=EmailDraft.Status.GENERATED, subject="Done")

        self._run()

        self.assertEqual(self.calls, [])
        self.drafts["Alpha Cafe"].refresh_from_db()
        self.assertIsNotNone(self.drafts["Alpha Cafe"].processed_at)
        self.assertEqual(self.drafts["Alpha Cafe"].subject, "Written already")

    def test_the_running_order_is_kept_rather_than_restamped(self):
        self._finish("Alpha Cafe", status=EmailDraft.Status.GENERATED,
                     subject="Done")

        self._run()

        rows = dict(self.campaign.drafts.values_list("business_name", "sequence"))
        self.assertEqual(rows, {"Alpha Cafe": 1, "Beta Bakery": 2,
                                "Gamma Grill": 3})

    def test_the_run_lands_back_in_review_with_nothing_in_flight(self):
        self._run()

        self.campaign.refresh_from_db()
        self.assertEqual(self.campaign.phase, Campaign.Phase.REVIEW)
        self.assertIsNone(self.campaign.current_draft_id)
        self.assertEqual(self.campaign.current_step, "")

    def test_a_lead_unblocked_after_the_run_is_given_a_place_at_the_end(self):
        """"Contact anyway" clears the sequence; the resumed run assigns one."""
        for name in ("Alpha Cafe", "Beta Bakery", "Gamma Grill"):
            self._finish(name, status=EmailDraft.Status.GENERATED, subject="Done")
        late = make_draft(self.campaign, business_name="Delta Deli",
                          email="hi@delta.example", website="https://delta.example",
                          subject="", body="", analysis_context="",
                          analysis_status="", status=EmailDraft.Status.PENDING,
                          sequence=0, force_contact=True,
                          force_reason="different business, same name")

        self._run()

        late.refresh_from_db()
        self.assertEqual(late.sequence, 4)
        self.assertEqual(late.status, EmailDraft.Status.GENERATED)
        self.assertIsNotNone(late.processed_at)
        self.assertEqual([url for _kind, url in self.calls],
                         ["https://delta.example"] * 3)
class ResumeEndpointTests(SignedIn):
    """POST /outreach/<id>/resume."""

    def setUp(self):
        self.campaign = make_campaign(phase=Campaign.Phase.CRAWLING)
        self.draft = make_draft(self.campaign, subject="", body="",
                                status=EmailDraft.Status.PENDING, sequence=1)

    def _post(self):
        return self.client.post(
            reverse("outreach:resume", args=[self.campaign.id]))

    def test_a_stalled_pipeline_is_restarted_in_resume_mode(self):
        with mock.patch.object(runner, "start_pipeline",
                               return_value=True) as start:
            response = self._post()

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["resumed"], "pipeline")
        self.assertEqual(response.json()["remaining"], 1)
        self.assertTrue(start.call_args.kwargs["resume"])

    def test_a_campaign_that_is_not_stalled_is_refused(self):
        Campaign.objects.filter(pk=self.campaign.pk).update(
            phase=Campaign.Phase.REVIEW)

        response = self._post()

        self.assertEqual(response.status_code, 400)
        self.assertIn("nothing to resume", response.json()["error"])

    def test_a_running_campaign_is_refused(self):
        with mock.patch.object(runner, "is_running", return_value=True):
            response = self._post()

        self.assertEqual(response.status_code, 409)

    def test_a_stalled_send_releases_the_queue_instead_of_resending(self):
        """The password is never stored, so a send cannot resume itself."""
        Campaign.objects.filter(pk=self.campaign.pk).update(
            phase=Campaign.Phase.SENDING)
        stuck = make_draft(self.campaign, business_name="Stuck Co",
                           email="stuck@x.example", website="https://x.example",
                           status=EmailDraft.Status.SENDING)

        with mock.patch.object(runner, "start_pipeline") as start:
            response = self._post()

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["resumed"], "send")
        self.assertEqual(response.json()["released"], 1)
        start.assert_not_called()

        stuck.refresh_from_db()
        self.campaign.refresh_from_db()
        self.assertEqual(stuck.status, EmailDraft.Status.APPROVED)
        self.assertEqual(self.campaign.phase, Campaign.Phase.REVIEW)
        self.assertIn("interrupted", self.campaign.error)

    def test_the_state_endpoint_reports_the_stall(self):
        response = self.client.get(
            reverse("outreach:state", args=[self.campaign.id]))

        self.assertEqual(response.json()["campaign"]["stalled"], "pipeline")
class ProgressStateTests(SignedIn):
    """What /state hands the progress panel while a run is in flight."""

    def setUp(self):
        self.campaign = make_campaign(phase=Campaign.Phase.ANALYSING)
        self.done = make_draft(
            self.campaign, business_name="Alpha Cafe", email="a@alpha.example",
            sequence=1, processed_at=timezone.now(),
            status=EmailDraft.Status.GENERATED)
        self.current = make_draft(
            self.campaign, business_name="Beta Bakery", email="b@beta.example",
            sequence=2, subject="", body="", status=EmailDraft.Status.PENDING)
        self.waiting = make_draft(
            self.campaign, business_name="Gamma Grill", email="c@gamma.example",
            sequence=3, subject="", body="", status=EmailDraft.Status.PENDING)
        self.campaign.current_draft = self.current
        self.campaign.current_step = "review"
        self.campaign.save(update_fields=["current_draft", "current_step"])

    def _state(self):
        response = self.client.get(
            reverse("outreach:state", args=[self.campaign.id]))
        self.assertEqual(response.status_code, 200)
        return response.json()

    def test_progress_is_exposed_for_the_panel(self):
        progress = self._state()["progress"]
        self.assertEqual(progress["total"], 3)
        self.assertEqual(progress["done"], 1)
        self.assertEqual(progress["position"], 2)
        self.assertEqual(progress["current"]["business_name"], "Beta Bakery")
        self.assertEqual(progress["step"], "review")
        # Five steps now: crawl, review, generate, score, save.
        self.assertEqual([step["state"] for step in progress["steps"]],
                         ["done", "current", "waiting", "waiting", "waiting"])
        self.assertEqual(progress["next"]["business_name"], "Gamma Grill")

    def test_only_leads_the_run_has_reached_get_a_card(self):
        started = {draft["business_name"]: draft["started"]
                   for draft in self._state()["drafts"]}
        self.assertTrue(started["Alpha Cafe"])    # finished
        self.assertTrue(started["Beta Bakery"])   # in flight
        self.assertFalse(started["Gamma Grill"])  # still queued

    def test_cards_arrive_in_running_order(self):
        names = [draft["business_name"] for draft in self._state()["drafts"]]
        self.assertEqual(names, ["Alpha Cafe", "Beta Bakery", "Gamma Grill"])
