"""
Unattended running: the schedule, the limits, the claims, and the stopping.

This file is long because the feature's value is in what it refuses to do. Sending
one email from a background worker is a few lines; sending exactly the configured
number, only inside the configured hours, only once per business, and stopping for
the right reason is the whole thing -- and each of those is a separate way to be
wrong.

The tests that matter most, and what they would catch:

  * **Two workers, one email.** `ConcurrencyTests` runs the claim twice against the
    same lead and the same day slot. Without the conditional writes both would win,
    and the second email would already be in somebody's inbox before anybody noticed.
  * **The daily target is a limit, not a suggestion.** `DailyTargetTests` reserves 25
    slots and asserts the 26th is refused -- including when two workers ask at the
    same moment.
  * **The timezone is the campaign's.** `ScheduleTests` asks about 3pm in Chicago
    from a server running in UTC. A naive comparison passes in development and sends
    at 3am in production.
  * **A follow-up is never sent by a machine.** `FollowUpTests` asserts the worker
    prepares one and that no path in it opens SMTP.
  * **One bad lead is one bad lead.** `FailureTests` breaks the crawler, the model
    and the mail server in turn and asserts the campaign carries on -- and that a
    failure is never counted as a send.

Nothing here reaches the network. The map search, the crawler, the AI calls and SMTP
are all replaced, and `OUTREACH_BLOCK_SEND` is on under `manage.py test` regardless.
"""

from __future__ import annotations

import datetime as dt
from unittest import mock
from zoneinfo import ZoneInfo

from django.core.management import call_command
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from apps import ai
from apps.ai import styles
from apps.auditing import crawler, measurements
from apps.core.testing import EMAIL_BODY, OtherUser, SignedIn, make_user
from apps.leads.scraper import Area, Lead
from apps.outreach.forms import AutomationForm
from apps.outreach.mail import accounts as mailaccounts
from apps.outreach.mail import transport
from apps.outreach.models import (
    AutomationDay,
    AutomationPlan,
    Campaign,
    CampaignEvent,
    EmailDraft,
    FollowUp,
    ProspectSearch,
    SentLead,
    Suppression,
)
from apps.outreach.services.automation import courier as courier_module
from apps.outreach.services.automation import events as event_log
from apps.outreach.services.automation import leads as prospecting
from apps.outreach.services.automation import process, schedule
from apps.outreach.services.automation import runner as automation

CHICAGO = ZoneInfo("America/Chicago")

#: A day the tests treat as "now" wherever the schedule matters. Fixed rather than
#: relative: a test that asks "is the window open?" needs a known answer, and
#: `timezone.now()` gives a different one every day the suite runs.
INSIDE = dt.datetime(2026, 8, 21, 10, 0, tzinfo=CHICAGO)     # inside 09:00-17:00
BEFORE = dt.datetime(2026, 8, 21, 7, 30, tzinfo=CHICAGO)     # before it opens
AFTER = dt.datetime(2026, 8, 21, 18, 30, tzinfo=CHICAGO)     # after it closes


# --------------------------------------------------------------------------- #
# Fixtures
# --------------------------------------------------------------------------- #

def account_for(owner, **fields):
    return mailaccounts.save_account(
        owner, name=fields.pop("name", "Sales"),
        sender_name="James Wilson",
        sender_email=fields.pop("email", "james@example.test"),
        provider="gmail", password="abcd efgh ijkl mnop",
        signature="James Wilson", **fields)


def make_plan(owner, *, account=None, **fields) -> AutomationPlan:
    """A configured, started campaign, ready for the worker."""
    account = account or account_for(owner)
    campaign = Campaign.objects.create(
        owner=owner, country="United States", city="Dallas",
        category="Plumbing", sender_name="James Wilson",
        sender_email=account.sender_email, provider="gmail",
        service_pitch=ai.DEFAULT_OFFER,
        status=fields.pop("status", Campaign.Status.ACTIVE))
    campaign.sending_accounts.set([account])

    values = {
        "name": fields.pop("name", "HVAC Dallas outreach"),
        "countries": ["United States"],
        "cities": ["Dallas"],
        "categories": ["Plumbing"],
        "quality": AutomationPlan.Quality.HAS_WEBSITE,
        "daily_target": 3,
        "total_target": 5,
        "start_date": dt.date(2026, 8, 20),
        "start_time": dt.time(9, 0),
        "end_date": dt.date(2026, 8, 30),
        "end_time": dt.time(17, 0),
        "timezone_name": "America/Chicago",
        "email_account": account,
        "template_key": styles.CONSULTATIVE.key,
    }
    values.update(fields)
    return AutomationPlan.objects.create(
        campaign=campaign, owner=owner, **values)


def seal(plan: AutomationPlan) -> AutomationPlan:
    """Mark every area as already searched.

    The state a campaign reaches once it has worked through its list, and the one a
    test needs when it wants a pool of exactly the leads it created: without this the
    worker tops the pool up from a search, which is correct behaviour and makes
    "assert two emails" impossible to write.
    """
    prospecting.ensure_searches(plan)
    plan.searches.update(status=ProspectSearch.Status.DONE)
    return plan


def make_lead(plan, index: int = 0, **fields) -> EmailDraft:
    """One workable lead in the campaign's pool."""
    defaults = {
        "business_name": f"Shop {index}",
        "email": f"shop{index}@example.test",
        "website": f"https://shop{index}.example",
        "category": "Plumbing",
        "city": "Dallas",
        "country": "United States",
        "status": EmailDraft.Status.PENDING,
    }
    defaults.update(fields)
    return EmailDraft.objects.create(campaign=plan.campaign, **defaults)


#: The finding every fake audit returns. `finding_id` is set because the real
#: `parse_audit` assigns one, and the traceability check resolves the email's
#: `findings_used` against it -- a fixture without an id fails validation for a
#: reason that has nothing to do with the test.
FINDING = ai.Finding(
    issue="The homepage has no obvious way to get in touch",
    evidence="cta_count = 0 on the homepage",
    why_it_matters="A visitor who wants a quote has nothing to press.",
    suggested_improvement="Add a visible call button near the top.",
    dimension="business", severity="high",
    page_url="https://shop0.example/",
    business_benefit="could help more visitors make contact",
    finding_id="AUD-001")

WRITTEN = ai.GeneratedEmail(
    "A few things I noticed on your website", EMAIL_BODY,
    "the homepage has no obvious way to get in touch", ["AUD-001"])


class FakeSmtp:
    """Records what was sent. Never opens a socket."""

    def __init__(self, fail_for=(), raise_on_enter=None):
        self.fail_for = set(fail_for)
        self.raise_on_enter = raise_on_enter
        self.sent: list[str] = []
        self.bodies: list[str] = []
        self.opened = 0

    def __enter__(self):
        self.opened += 1
        if self.raise_on_enter:
            raise self.raise_on_enter
        return self

    def __exit__(self, *exc_info):
        return False

    def send(self, *, to_email, subject, body, sender_name, reply_to="",
             in_reply_to="", references=""):
        if to_email in self.fail_for:
            raise transport.SendError(f"{to_email} was refused.")
        self.sent.append(to_email)
        self.bodies.append(body)
        return f"<{len(self.sent)}@example.test>"


def site(website: str, **facts) -> crawler.SiteAnalysis:
    measured = {"load_ms": 5200, "cta_count": 0, "viewport_meta": 0,
                "word_count": 120}
    measured.update(facts)
    slug = website.rstrip("/").split("//")[-1].split(".")[0] or "site"
    return crawler.SiteAnalysis(
        crawler.OK, "read 1 page",
        [measurements.Page(url=website, kind="home", title=slug, description="",
                       headings=["Welcome"], text="We fix boilers in Dallas.",
                       facts=measured)],
        [f"hello@{slug}.example"], 1, False)


class Pipeline:
    """Every outside edge of the pipeline, replaced.

        with Pipeline() as fake:
            automation.run_once(...)
        self.assertEqual(fake.smtp.sent, ["shop0@example.test"])

    One object rather than six nested `mock.patch` calls in every test: the
    combination is the same every time, and a test that has to restate it is a test
    that will eventually restate it slightly differently.
    """

    def __init__(self, *, analyse=None, audit=None, generate=None, smtp=None,
                 at: dt.datetime | None = INSIDE, found=None):
        self.smtp = smtp if smtp is not None else FakeSmtp()
        self._analyse = analyse or (lambda website, *a, **k: site(website))
        self._audit = audit or (lambda **k: ai.SiteAudit(
            business_summary="A plumbing business in Dallas.",
            findings=[FINDING]))
        self._generate = generate or (lambda **k: WRITTEN)
        self._at = at
        self._found = found
        self._patches: list = []
        self.searches = 0

    def _search(self, country, city, category, limit):
        self.searches += 1
        if self._found is not None:
            return self._found(country, city, category, limit)
        base = self.searches * 10
        area = Area(city=city, country=country, label=city, lat=1.0, lon=2.0,
                    bbox=(0, 0, 1, 1))
        return area, [
            Lead(business_name=f"Shop {base + i}", category=category,
                 country=country, city=city, address="1 Main St", phone="555",
                 email=f"shop{base + i}@example.test",
                 website=f"https://shop{base + i}.example",
                 latitude=1.0, longitude=2.0, source="https://osm.example")
            for i in range(4)
        ]

    def __enter__(self) -> "Pipeline":
        self._patches = [
            mock.patch("apps.leads.scraper.search", side_effect=self._search),
            mock.patch.object(crawler, "analyse", side_effect=self._analyse),
            mock.patch.object(ai, "audit", side_effect=self._audit),
            mock.patch.object(ai, "generate", side_effect=self._generate),
            mock.patch.object(transport, "Session", return_value=self.smtp),
            # No real sleeping: the courier's spacing is asserted by what it asks
            # for, not by making the suite wait for it.
            mock.patch("apps.outreach.services.automation.courier.time.sleep"),
        ]
        if self._at is not None:
            self._patches.append(
                mock.patch.object(schedule, "now_local", return_value=self._at))
        for patch in self._patches:
            patch.start()
        return self

    def __exit__(self, *exc_info):
        for patch in reversed(self._patches):
            patch.stop()
        return False


# --------------------------------------------------------------------------- #
# Section 14: the schedule, in the campaign's own timezone
# --------------------------------------------------------------------------- #

class ScheduleTests(TestCase):
    """The arithmetic the whole feature rests on.

    A server in UTC deciding whether it is 09:00 in Chicago is the one calculation
    here that is wrong by default: `timezone.now()` is right, `datetime.now()` is
    right in development and wrong in production, and comparing a naive local time
    to an aware one raises. So these tests ask from outside the zone on purpose.
    """

    def setUp(self):
        self.user = make_user("sched@example.test")
        self.plan = make_plan(self.user)

    def test_inside_the_window_it_is_open(self):
        self.assertTrue(schedule.state(self.plan, INSIDE).open)

    def test_before_the_window_it_is_not(self):
        verdict = schedule.state(self.plan, BEFORE)

        self.assertFalse(verdict.open)
        self.assertIn("09:00", verdict.reason)
        self.assertEqual(verdict.next_open.astimezone(CHICAGO).hour, 9)

    def test_after_the_window_it_opens_again_tomorrow(self):
        verdict = schedule.state(self.plan, AFTER)

        self.assertFalse(verdict.open)
        self.assertFalse(verdict.finished)
        self.assertEqual(verdict.next_open.astimezone(CHICAGO).date(),
                         dt.date(2026, 8, 22))

    def test_the_question_is_asked_in_the_campaigns_zone_not_the_servers(self):
        """15:00 UTC is 10:00 in Chicago, which is inside 09:00-17:00.

        The same instant is outside the window for a campaign configured in
        Europe/Berlin, and a naive comparison cannot tell the two apart.
        """
        instant = dt.datetime(2026, 8, 21, 16, 0, tzinfo=dt.timezone.utc)

        self.assertTrue(schedule.state(self.plan, instant).open)   # 11:00 Chicago

        self.plan.timezone_name = "Europe/Berlin"                  # 18:00 there
        self.assertFalse(schedule.state(self.plan, instant).open)

    def test_a_naive_datetime_is_read_as_utc_not_as_local(self):
        """Assuming local is how a naive value becomes a wrong answer."""
        naive = dt.datetime(2026, 8, 21, 15, 0)

        self.assertEqual(schedule.now_local(self.plan, naive).hour, 10)

    def test_the_closing_time_is_part_of_the_window(self):
        """"Until 17:00" includes 17:00; the minute after it does not."""
        self.assertTrue(schedule.state(
            self.plan, dt.datetime(2026, 8, 21, 17, 0, tzinfo=CHICAGO)).open)
        self.assertFalse(schedule.state(
            self.plan, dt.datetime(2026, 8, 21, 17, 1, tzinfo=CHICAGO)).open)

    def test_before_the_start_date_it_has_not_started(self):
        verdict = schedule.state(
            self.plan, dt.datetime(2026, 8, 19, 10, 0, tzinfo=CHICAGO))

        self.assertFalse(verdict.open)
        self.assertIn("Not started yet", verdict.reason)

    def test_after_the_end_date_it_is_finished(self):
        verdict = schedule.state(
            self.plan, dt.datetime(2026, 9, 1, 10, 0, tzinfo=CHICAGO))

        self.assertTrue(verdict.finished)
        self.assertIn("end date", verdict.reason)
        self.assertIsNone(verdict.next_open)

    def test_the_last_days_cutoff_finishes_the_campaign(self):
        """Not "opens again tomorrow" when there is no tomorrow to open in."""
        verdict = schedule.state(
            self.plan, dt.datetime(2026, 8, 30, 18, 0, tzinfo=CHICAGO))

        self.assertTrue(verdict.finished)
        self.assertIsNone(verdict.next_open)

    def test_no_end_time_means_until_midnight(self):
        self.plan.end_time = None

        self.assertTrue(schedule.state(self.plan, AFTER).open)

    def test_the_local_date_is_the_campaigns_date(self):
        """Just after midnight in Chicago is still the previous day in UTC."""
        instant = dt.datetime(2026, 8, 22, 4, 30, tzinfo=dt.timezone.utc)

        self.assertEqual(schedule.local_date(self.plan, instant),
                         dt.date(2026, 8, 21))

    def test_an_unknown_zone_is_refused_rather_than_replaced(self):
        self.plan.timezone_name = "Mars/Olympus_Mons"

        with self.assertRaises(schedule.ScheduleError):
            schedule.state(self.plan)

    def test_a_window_across_a_spring_forward_still_opens(self):
        """02:30 does not exist in Chicago on 8 March 2026. It still resolves."""
        self.plan.start_time = dt.time(2, 30)
        self.plan.end_time = dt.time(4, 0)
        self.plan.start_date = dt.date(2026, 3, 1)

        verdict = schedule.state(
            self.plan, dt.datetime(2026, 3, 8, 3, 30, tzinfo=CHICAGO))

        self.assertTrue(verdict.open)


# --------------------------------------------------------------------------- #
# Section 19: configuration validation
# --------------------------------------------------------------------------- #

class FormValidationTests(TestCase):
    def setUp(self):
        self.user = make_user("form@example.test")
        self.account = account_for(self.user)

    def _data(self, **overrides):
        data = {
            "name": "HVAC Dallas",
            "countries": "United States",
            "cities": "Dallas, Houston",
            "categories": "Plumbing",
            "quality": AutomationPlan.Quality.HAS_WEBSITE,
            "discover_emails": "on",
            "daily_target": "25",
            "total_target": "500",
            "send_gap_seconds": "0",
            "start_date": "2026-08-20",
            "start_time": "09:00",
            "end_date": "2026-08-30",
            "end_time": "17:00",
            "timezone_name": "America/Chicago",
            "email_account": str(self.account.pk),
            "template_key": "consultative",
            "service_pitch": ai.DEFAULT_OFFER,
            "followups_enabled": "on",
            "followup_delay_days": "3",
            "followup_max": "2",
        }
        data.update(overrides)
        return {key: value for key, value in data.items() if value is not None}

    def _form(self, **overrides):
        return AutomationForm(self._data(**overrides), owner=self.user)

    def test_a_complete_configuration_is_valid(self):
        form = self._form()

        self.assertTrue(form.is_valid(), form.errors)

    def test_a_comma_separated_list_becomes_a_list(self):
        """"Dallas, Houston" is two cities, not one place with a comma in it."""
        form = self._form()
        form.is_valid()

        self.assertEqual(form.cleaned_data["cities"], ["Dallas", "Houston"])

    def test_duplicates_in_a_list_are_dropped(self):
        form = self._form(cities="Dallas, dallas, Houston")
        form.is_valid()

        self.assertEqual(form.cleaned_data["cities"], ["Dallas", "Houston"])

    def test_a_target_source_is_required(self):
        for field in ("countries", "cities", "categories"):
            with self.subTest(field=field):
                form = self._form(**{field: ""})

                self.assertFalse(form.is_valid())
                self.assertIn(field, form.errors)

    def test_a_daily_target_of_zero_is_refused(self):
        form = self._form(daily_target="0")

        self.assertFalse(form.is_valid())
        self.assertIn("daily_target", form.errors)

    def test_a_total_target_of_zero_is_refused(self):
        form = self._form(total_target="0")

        self.assertFalse(form.is_valid())
        self.assertIn("total_target", form.errors)

    def test_an_end_date_before_the_start_is_refused(self):
        form = self._form(start_date="2026-08-30", end_date="2026-08-20")

        self.assertFalse(form.is_valid())
        self.assertIn("before it starts", str(form.errors["end_date"]))

    def test_a_window_that_closes_before_it_opens_is_refused(self):
        """It would never be open, and the campaign would wait forever."""
        form = self._form(start_time="17:00", end_time="09:00")

        self.assertFalse(form.is_valid())
        self.assertIn("never be open", str(form.errors["end_time"]))

    def test_a_daily_target_above_the_total_is_refused(self):
        form = self._form(daily_target="50", total_target="20")

        self.assertFalse(form.is_valid())
        self.assertIn("higher than the total", str(form.errors["daily_target"]))

    def test_a_daily_target_above_the_accounts_cap_is_refused(self):
        """The mailbox's ceiling is not ours to raise.

        Set on the account rather than taken from the provider preset: Gmail's 400 is
        above the form field's own maximum, so a provider-sized number would be
        rejected for being large rather than for exceeding the mailbox.
        """
        self.account.daily_limit = 5
        self.account.save(update_fields=["daily_limit"])

        form = self._form(daily_target="10", total_target="100")

        self.assertFalse(form.is_valid())
        self.assertIn("not ours to raise", str(form.errors["daily_target"]))

    def test_an_unknown_timezone_is_refused(self):
        form = AutomationForm(self._data(), owner=self.user)
        form.data = form.data.copy()
        form.data["timezone_name"] = "Mars/Olympus_Mons"

        self.assertFalse(form.is_valid())
        self.assertIn("timezone_name", form.errors)

    def test_an_inactive_account_is_refused(self):
        mailaccounts.set_active(self.user, self.account, False)

        form = self._form()

        self.assertFalse(form.is_valid())
        self.assertIn("switched off", str(form.errors["email_account"]))

    def test_an_account_with_no_password_is_refused(self):
        mailaccounts.clear_secret(self.user, self.account)

        form = self._form()

        self.assertFalse(form.is_valid())
        self.assertIn("No password", str(form.errors["email_account"]))

    def test_another_accounts_mailbox_is_not_selectable(self):
        other = OtherUser()
        theirs = account_for(other.user, name="Theirs",
                             email="them@example.test")

        form = self._form(email_account=str(theirs.pk))

        self.assertFalse(form.is_valid())
        self.assertIn("email_account", form.errors)

    def test_an_empty_offer_is_refused(self):
        form = self._form(service_pitch="Websites.")

        self.assertFalse(form.is_valid())
        self.assertIn("service_pitch", form.errors)

    def test_two_campaigns_cannot_share_a_name(self):
        make_plan(self.user, name="HVAC Dallas", account=self.account)

        form = self._form(name="HVAC Dallas")

        self.assertFalse(form.is_valid())
        self.assertIn("already have a campaign", str(form.errors["name"]))

    def test_unattended_follow_up_sending_is_not_offered(self):
        form = self._form()
        form.is_valid()

        self.assertNotIn("followup_autosend", form.fields)
        self.assertFalse(form.plan_values()["followup_autosend"])


# --------------------------------------------------------------------------- #
# Section 1 and 22: creating one through the UI
# --------------------------------------------------------------------------- #

class CreationTests(SignedIn):
    def setUp(self):
        super().setUp()
        self.account = account_for(self.user)

    def _post(self, **overrides):
        data = {
            "name": "HVAC Dallas outreach",
            "countries": "United States",
            "cities": "Dallas, Houston",
            "categories": "Plumbing, Roofing",
            "quality": AutomationPlan.Quality.HAS_WEBSITE,
            "discover_emails": "on",
            "daily_target": "25",
            "total_target": "500",
            "start_date": "2026-08-20",
            "start_time": "09:00",
            "end_date": "2026-08-30",
            "end_time": "17:00",
            "timezone_name": "America/Chicago",
            "email_account": str(self.account.pk),
            "template_key": "consultative",
            "service_pitch": ai.DEFAULT_OFFER,
            "followups_enabled": "on",
            "followup_delay_days": "3",
            "followup_max": "2",
        }
        data.update(overrides)
        return self.client.post(reverse("outreach:automation_new"), data=data)

    def test_the_form_page_renders(self):
        page = self.client.get(reverse("outreach:automation_new"))

        self.assertContains(page, "Create automation campaign")
        self.assertContains(page, "Target audience")
        self.assertContains(page, "automation_form.js")

    def test_it_creates_a_plan_and_a_campaign(self):
        response = self._post()

        self.assertEqual(response.status_code, 302)
        plan = AutomationPlan.objects.get()
        self.assertEqual(plan.name, "HVAC Dallas outreach")
        self.assertEqual(plan.cities, ["Dallas", "Houston"])
        self.assertEqual(plan.categories, ["Plumbing", "Roofing"])
        self.assertEqual(plan.timezone_name, "America/Chicago")
        self.assertEqual(plan.owner, self.user)
        self.assertEqual(plan.campaign.owner, self.user)

    def test_a_new_campaign_is_a_draft_and_sends_nothing(self):
        """Creating is not starting. A form submit must not begin emailing."""
        self._post()
        plan = AutomationPlan.objects.get()

        self.assertEqual(plan.campaign.status, Campaign.Status.DRAFT)
        self.assertFalse(plan.campaign.may_send)
        self.assertEqual(SentLead.objects.count(), 0)

    def test_the_chosen_mailbox_is_recorded_the_way_a_manual_campaign_records_it(self):
        self._post()
        plan = AutomationPlan.objects.get()

        self.assertEqual(list(plan.campaign.sending_accounts.all()),
                         [self.account])
        self.assertEqual(plan.email_account, self.account)

    def test_every_area_to_search_is_written_down(self):
        """Two cities and two categories is four searches, once each."""
        self._post()
        plan = AutomationPlan.objects.get()

        self.assertEqual(plan.searches.count(), 4)
        self.assertEqual(
            plan.searches.filter(status=ProspectSearch.Status.PENDING).count(), 4)

    def test_an_invalid_configuration_comes_back_with_its_values(self):
        response = self._post(daily_target="0")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(AutomationPlan.objects.count(), 0)
        self.assertContains(response, "HVAC Dallas outreach")

    def test_creating_it_is_recorded(self):
        self._post()

        event = CampaignEvent.objects.get()
        self.assertIn("Campaign created", event.message)

    def test_the_list_shows_it(self):
        self._post()

        page = self.client.get(reverse("outreach:automation"))

        self.assertContains(page, "HVAC Dallas outreach")
        self.assertContains(page, "Draft")

    def test_another_workspaces_campaign_is_not_listed(self):
        other = OtherUser()
        make_plan(other.user, name="Theirs")

        page = self.client.get(reverse("outreach:automation"))

        self.assertNotContains(page, "Theirs")

    def test_another_workspaces_dashboard_is_not_reachable(self):
        other = OtherUser()
        theirs = make_plan(other.user, name="Theirs")

        response = self.client.get(
            reverse("outreach:automation_view", args=[theirs.pk]))

        self.assertEqual(response.status_code, 404)


# --------------------------------------------------------------------------- #
# Starting: the last-moment checks
# --------------------------------------------------------------------------- #

class StartTests(SignedIn):
    def setUp(self):
        super().setUp()
        self.account = account_for(self.user)
        self.plan = make_plan(self.user, account=self.account,
                             status=Campaign.Status.DRAFT)

    def _start(self):
        return self.client.post(
            reverse("outreach:automation_start", args=[self.plan.pk]),
            data="{}", content_type="application/json")

    def _with_credentials(self):
        return mock.patch.object(ai, "describe_credentials",
                                 return_value=(True, "test", ""))

    def test_starting_inside_the_window_makes_it_active(self):
        with self._with_credentials(), \
             mock.patch.object(schedule, "now_local", return_value=INSIDE):
            response = self._start()

        self.assertEqual(response.status_code, 200)
        self.plan.campaign.refresh_from_db()
        self.assertEqual(self.plan.campaign.status, Campaign.Status.ACTIVE)

    def test_starting_before_the_window_schedules_it(self):
        with self._with_credentials(), \
             mock.patch.object(schedule, "now_local", return_value=BEFORE):
            response = self._start()

        self.plan.campaign.refresh_from_db()
        self.assertEqual(self.plan.campaign.status, Campaign.Status.SCHEDULED)
        self.assertIn("scheduled", response.json()["message"])

    def test_a_campaign_whose_end_has_passed_cannot_start(self):
        with self._with_credentials(), \
             mock.patch.object(
                 schedule, "now_local",
                 return_value=dt.datetime(2026, 9, 5, 10, 0, tzinfo=CHICAGO)):
            response = self._start()

        self.assertEqual(response.status_code, 409)
        self.plan.campaign.refresh_from_db()
        self.assertEqual(self.plan.campaign.status, Campaign.Status.DRAFT)

    def test_a_mailbox_switched_off_since_creation_stops_the_start(self):
        mailaccounts.set_active(self.user, self.account, False)

        with self._with_credentials():
            response = self._start()

        self.assertEqual(response.status_code, 409)
        self.assertIn("switched off", response.json()["error"])
        self.plan.campaign.refresh_from_db()
        self.assertEqual(self.plan.campaign.status, Campaign.Status.DRAFT)

    def test_a_password_cleared_since_creation_stops_the_start(self):
        mailaccounts.clear_secret(self.user, self.account)

        with self._with_credentials():
            response = self._start()

        self.assertEqual(response.status_code, 409)
        self.assertIn("No password", response.json()["error"])

    def test_no_ai_credential_stops_the_start(self):
        with mock.patch.object(ai, "describe_credentials",
                               return_value=(False, "", "add one")):
            response = self._start()

        self.assertEqual(response.status_code, 409)
        self.assertIn("No AI provider", response.json()["error"])

    def test_starting_does_no_work_itself(self):
        """The browser must not be where the campaign runs."""
        with self._with_credentials(), \
             mock.patch.object(schedule, "now_local", return_value=INSIDE), \
             mock.patch.object(crawler, "analyse") as crawl:
            self._start()

        crawl.assert_not_called()
        self.assertEqual(EmailDraft.objects.count(), 0)


# --------------------------------------------------------------------------- #
# Section 8: lead eligibility
# --------------------------------------------------------------------------- #

class EligibilityTests(TestCase):
    def setUp(self):
        self.user = make_user("elig@example.test")
        self.plan = make_plan(self.user)

    def _verdict(self, **fields):
        return process.eligibility(self.plan, make_lead(self.plan, **fields))

    def test_a_workable_lead_is_eligible(self):
        self.assertTrue(self._verdict().ok)

    def test_no_email_and_no_website_is_refused(self):
        """The website rule refuses it first, which is the more specific reason."""
        verdict = self._verdict(email="", website="")

        self.assertFalse(verdict.ok)
        self.assertEqual(verdict.status, EmailDraft.Status.EXCLUDED)

    def test_no_email_and_no_website_says_no_email_when_a_site_was_not_required(self):
        self.plan.quality = AutomationPlan.Quality.ANY

        verdict = self._verdict(email="", website="")

        self.assertFalse(verdict.ok)
        self.assertEqual(verdict.status, EmailDraft.Status.NO_EMAIL)

    def test_no_email_but_a_website_is_workable_when_discovery_is_on(self):
        """The address may be published on the site. It is checked again after."""
        self.assertTrue(self._verdict(email="").ok)

    def test_no_email_and_discovery_off_is_refused(self):
        self.plan.discover_emails = False

        verdict = self._verdict(email="")

        self.assertFalse(verdict.ok)
        self.assertEqual(verdict.status, EmailDraft.Status.NO_EMAIL)

    def test_a_suppressed_address_is_refused(self):
        Suppression.objects.create(owner=self.user, email="no@example.test",
                                   reason=Suppression.Reason.MANUAL)

        verdict = self._verdict(email="no@example.test")

        self.assertFalse(verdict.ok)
        self.assertEqual(verdict.status, EmailDraft.Status.SUPPRESSED)

    def test_an_already_contacted_address_is_refused(self):
        SentLead.objects.create(owner=self.user, email="seen@example.test",
                                business_name="Seen", status=SentLead.Status.SENT)

        verdict = self._verdict(email="seen@example.test")

        self.assertFalse(verdict.ok)
        self.assertEqual(verdict.status, EmailDraft.Status.DUPLICATE)

    def test_a_bounced_address_is_refused(self):
        """A bounce writes a suppression, which is what refuses it here."""
        Suppression.objects.create(owner=self.user, email="gone@example.test",
                                   reason=Suppression.Reason.BOUNCED)

        verdict = self._verdict(email="gone@example.test")

        self.assertFalse(verdict.ok)
        self.assertEqual(verdict.status, EmailDraft.Status.SUPPRESSED)

    def test_a_lead_outside_the_campaigns_cities_is_refused(self):
        verdict = self._verdict(city="Reykjavik")

        self.assertFalse(verdict.ok)
        self.assertEqual(verdict.status, EmailDraft.Status.EXCLUDED)

    def test_a_lead_outside_the_campaigns_countries_is_refused(self):
        verdict = self._verdict(country="Iceland")

        self.assertFalse(verdict.ok)

    def test_a_lead_outside_the_campaigns_categories_is_refused(self):
        verdict = self._verdict(category="Florists")

        self.assertFalse(verdict.ok)

    def test_a_near_match_on_a_place_name_is_accepted(self):
        """The map and the user describe the same place in different words."""
        self.assertTrue(self._verdict(city="Dallas, Texas").ok)
        self.assertTrue(
            self._verdict(index=2, country="United States of America").ok)

    def test_no_website_is_refused_when_the_campaign_asked_for_one(self):
        verdict = self._verdict(website="", email="has@example.test")

        self.assertFalse(verdict.ok)
        self.assertEqual(verdict.status, EmailDraft.Status.EXCLUDED)

    def test_no_website_is_fine_when_the_campaign_takes_any_business(self):
        self.plan.quality = AutomationPlan.Quality.ANY

        self.assertTrue(self._verdict(website="", email="has@example.test").ok)

    def test_an_already_sent_lead_is_not_reprocessed(self):
        verdict = self._verdict(status=EmailDraft.Status.SENT)

        self.assertFalse(verdict.ok)

    def test_a_refusal_is_recorded_on_the_draft_and_in_the_log(self):
        draft = make_lead(self.plan, city="Reykjavik")

        process.refuse(self.plan, draft, process.eligibility(self.plan, draft))

        draft.refresh_from_db()
        self.assertEqual(draft.status, EmailDraft.Status.EXCLUDED)
        self.assertIn("Reykjavik", draft.error_message)
        self.assertTrue(CampaignEvent.objects.filter(
            kind=CampaignEvent.Kind.SKIPPED).exists())


# --------------------------------------------------------------------------- #
# Sections 6 and 7: the limits, and two workers
# --------------------------------------------------------------------------- #

class DailyTargetTests(TestCase):
    """The daily target has to hold when two workers ask at the same moment."""

    def setUp(self):
        self.user = make_user("daily@example.test")
        self.plan = make_plan(self.user, daily_target=3)
        self.day = self.plan.day(dt.date(2026, 8, 21))

    def test_slots_are_handed_out_up_to_the_target(self):
        taken = [self.day.reserve(3) for _ in range(5)]

        self.assertEqual(taken, [True, True, True, False, False])
        self.day.refresh_from_db()
        self.assertEqual(self.day.reserved, 3)

    def test_two_workers_asking_together_get_one_slot_between_them(self):
        """The whole reason this is a row and not a Python variable."""
        self.day.reserve(3)
        self.day.reserve(3)

        first = AutomationDay.objects.get(pk=self.day.pk)
        second = AutomationDay.objects.get(pk=self.day.pk)
        self.assertEqual(first.reserved, 2)          # both see the same state

        got = [first.reserve(3), second.reserve(3)]

        self.assertEqual(sorted(got), [False, True])
        self.assertEqual(AutomationDay.objects.get(pk=self.day.pk).reserved, 3)

    def test_a_released_slot_can_be_used_again(self):
        for _ in range(3):
            self.day.reserve(3)
        self.day.release()

        self.assertTrue(self.day.reserve(3))

    def test_releasing_twice_cannot_widen_the_limit(self):
        self.day.reserve(3)
        self.day.release()
        self.day.release()

        self.day.refresh_from_db()
        self.assertEqual(self.day.reserved, 0)

    def test_a_target_of_zero_hands_out_nothing(self):
        self.assertFalse(self.day.reserve(0))

    def test_each_campaign_day_has_its_own_allowance(self):
        for _ in range(3):
            self.day.reserve(3)

        tomorrow = self.plan.day(dt.date(2026, 8, 22))

        self.assertTrue(tomorrow.reserve(3))
        self.assertEqual(AutomationDay.objects.count(), 2)

    def test_the_day_is_the_campaigns_own_date(self):
        """Just after midnight in Chicago is a new campaign day."""
        instant = dt.datetime(2026, 8, 22, 5, 30, tzinfo=dt.timezone.utc)

        self.assertEqual(schedule.local_date(self.plan, instant),
                         dt.date(2026, 8, 22))


class ConcurrencyTests(TestCase):
    """Two workers must never process -- or email -- the same lead."""

    def setUp(self):
        self.user = make_user("race@example.test")
        self.plan = seal(make_plan(self.user))
        self.draft = make_lead(self.plan)

    def test_only_one_worker_claims_a_lead(self):
        self.plan.locked_by = "worker-a"
        first = automation.claim_lead(self.plan)

        self.plan.locked_by = "worker-b"
        second = automation.claim_lead(self.plan)

        self.assertIsNotNone(first)
        self.assertIsNone(second)
        self.assertEqual(first.pk, self.draft.pk)

    def test_a_released_lead_can_be_claimed_again(self):
        self.plan.locked_by = "worker-a"
        claimed = automation.claim_lead(self.plan)
        automation.unclaim(claimed)

        self.assertIsNotNone(automation.claim_lead(self.plan))

    def test_only_one_worker_leases_a_campaign(self):
        self.assertTrue(automation.claim(self.plan, "worker-a"))
        self.assertFalse(automation.claim(self.plan, "worker-b"))

    def test_the_same_worker_may_renew_its_own_lease(self):
        automation.claim(self.plan, "worker-a")

        self.assertTrue(automation.claim(self.plan, "worker-a"))

    def test_an_expired_lease_is_taken_over(self):
        """A worker killed mid-lead cannot release anything."""
        automation.claim(self.plan, "worker-a", seconds=-1)

        self.assertTrue(automation.claim(self.plan, "worker-b"))

    def test_a_second_pass_on_a_leased_campaign_does_nothing(self):
        automation.claim(self.plan, "worker-a")

        report = automation.run_plan(self.plan, who="worker-b")

        self.assertIn("Another worker", report.stopped_because)
        self.assertEqual(report.sent, 0)

    def test_two_passes_over_the_same_campaign_send_one_email_each_lead(self):
        """The end-to-end version: run twice, count the emails."""
        with Pipeline() as fake:
            automation.run_once(owner=self.user, limit=1)
            automation.run_once(owner=self.user, limit=1)

        self.assertEqual(len(fake.smtp.sent), len(set(fake.smtp.sent)))
        self.assertEqual(
            SentLead.objects.filter(email=self.draft.email).count(), 1)


# --------------------------------------------------------------------------- #
# Sections 4, 5, 11: the worker doing the work
# --------------------------------------------------------------------------- #

class WorkerTests(TestCase):
    def setUp(self):
        self.user = make_user("work@example.test")
        self.account = account_for(self.user)
        self.plan = seal(make_plan(self.user, account=self.account,
                                   daily_target=2, total_target=10))
        self.draft = make_lead(self.plan)

    def test_one_lead_goes_all_the_way_to_sent(self):
        with Pipeline() as fake:
            reports = automation.run_once(owner=self.user, limit=1)

        self.assertEqual(fake.smtp.sent, [self.draft.email])
        self.assertEqual(reports[0].sent, 1)
        self.draft.refresh_from_db()
        self.assertEqual(self.draft.status, EmailDraft.Status.SENT)
        self.assertIsNotNone(self.draft.sent_at)

    def test_the_send_is_recorded_in_the_history(self):
        with Pipeline():
            automation.run_once(owner=self.user, limit=1)

        record = SentLead.objects.get()
        self.assertEqual(record.email, self.draft.email)
        self.assertEqual(record.status, SentLead.Status.SENT)
        self.assertEqual(record.sender_email, self.account.sender_email)
        self.assertTrue(record.message_id)

    def test_the_email_is_built_from_the_verified_finding(self):
        with Pipeline() as fake:
            automation.run_once(owner=self.user, limit=1)

        self.draft.refresh_from_db()
        self.assertEqual(self.draft.findings_used, ["AUD-001"])
        self.assertIn("get in touch", fake.smtp.bodies[0])

    def test_the_accounts_signature_is_appended(self):
        with Pipeline() as fake:
            automation.run_once(owner=self.user, limit=1)

        self.assertIn("James Wilson", fake.smtp.bodies[0])

    def test_the_day_counter_follows_the_send(self):
        with Pipeline():
            automation.run_once(owner=self.user, limit=1)

        day = AutomationDay.objects.get()
        self.assertEqual((day.reserved, day.sent), (1, 1))

    def test_the_account_counters_follow_the_send(self):
        with Pipeline():
            automation.run_once(owner=self.user, limit=1)

        self.account.refresh_from_db()
        self.assertEqual(self.account.sent_count, 1)

    def test_it_stops_at_the_daily_target(self):
        for index in range(1, 5):
            make_lead(self.plan, index)

        with Pipeline() as fake:
            reports = automation.run_once(owner=self.user, limit=10)

        self.assertEqual(len(fake.smtp.sent), 2)          # daily_target
        self.assertIn("Today's target", reports[0].stopped_because)

    def test_the_daily_limit_message_says_when_it_resumes(self):
        """Not "when the window opens" -- the window is open; the allowance is not."""
        for index in range(1, 5):
            make_lead(self.plan, index)

        with Pipeline():
            reports = automation.run_once(owner=self.user, limit=10)

        self.assertIn("22 Aug at 09:00", reports[0].stopped_because)

    def test_a_final_day_says_so_rather_than_promising_tomorrow(self):
        self.plan.end_date = dt.date(2026, 8, 21)
        self.plan.save(update_fields=["end_date"])
        for index in range(1, 5):
            make_lead(self.plan, index)

        with Pipeline():
            reports = automation.run_once(owner=self.user, limit=10)

        self.assertIn("last window", reports[0].stopped_because)

    def test_it_completes_at_the_total_target(self):
        self.plan.total_target = 2
        self.plan.daily_target = 5
        self.plan.save()
        for index in range(1, 4):
            make_lead(self.plan, index)

        with Pipeline() as fake:
            automation.run_once(owner=self.user, limit=10)

        self.assertEqual(len(fake.smtp.sent), 2)
        self.plan.campaign.refresh_from_db()
        self.plan.refresh_from_db()
        self.assertEqual(self.plan.campaign.status, Campaign.Status.COMPLETED)
        self.assertIn("Total target of 2 reached", self.plan.completion_reason)

    def test_it_sends_nothing_outside_the_window(self):
        with Pipeline(at=AFTER) as fake:
            reports = automation.run_once(owner=self.user, limit=5)

        self.assertEqual(fake.smtp.sent, [])
        self.assertIn("window closed", reports[0].stopped_because)

    def test_it_sends_nothing_before_the_window_opens(self):
        with Pipeline(at=BEFORE) as fake:
            automation.run_once(owner=self.user, limit=5)

        self.assertEqual(fake.smtp.sent, [])

    def test_the_end_date_completes_the_campaign(self):
        with Pipeline(at=dt.datetime(2026, 9, 2, 10, 0, tzinfo=CHICAGO)) as fake:
            automation.run_once(owner=self.user, limit=5)

        self.assertEqual(fake.smtp.sent, [])
        self.plan.campaign.refresh_from_db()
        self.assertEqual(self.plan.campaign.status, Campaign.Status.COMPLETED)

    def test_a_scheduled_campaign_becomes_active_when_its_window_opens(self):
        self.plan.campaign.status = Campaign.Status.SCHEDULED
        self.plan.campaign.save(update_fields=["status"])
        make_lead(self.plan, 1)          # so the pass does not finish the campaign

        with Pipeline():
            automation.run_once(owner=self.user, limit=1)

        self.plan.campaign.refresh_from_db()
        self.assertEqual(self.plan.campaign.status, Campaign.Status.ACTIVE)

    def test_it_never_touches_a_manual_campaign(self):
        """A campaign with no plan is not the worker's business."""
        manual = Campaign.objects.create(owner=self.user, city="Berlin",
                                        status=Campaign.Status.ACTIVE)
        EmailDraft.objects.create(campaign=manual, business_name="Manual",
                                 email="manual@example.test",
                                 website="https://manual.example",
                                 status=EmailDraft.Status.PENDING)

        with Pipeline() as fake:
            automation.run_once(owner=self.user, limit=5)

        self.assertNotIn("manual@example.test", fake.smtp.sent)

    def test_the_command_runs_a_pass(self):
        with Pipeline() as fake:
            call_command("run_automation", verbosity=0)

        self.assertEqual(fake.smtp.sent, [self.draft.email])

    def test_a_dry_run_changes_nothing(self):
        with Pipeline() as fake:
            call_command("run_automation", dry_run=True, verbosity=0)

        self.assertEqual(fake.smtp.sent, [])
        self.draft.refresh_from_db()
        self.assertEqual(self.draft.status, EmailDraft.Status.PENDING)
        self.assertEqual(AutomationDay.objects.count(), 0)


# --------------------------------------------------------------------------- #
# Section 13: pause, resume, stop
# --------------------------------------------------------------------------- #

class PauseResumeTests(TestCase):
    def setUp(self):
        self.user = make_user("pause@example.test")
        self.plan = seal(make_plan(self.user, daily_target=5, total_target=10))
        for index in range(3):
            make_lead(self.plan, index)

    def _pause(self):
        from apps.outreach.services import campaigns as campaign_ops

        campaign_ops.set_status(self.plan.campaign, Campaign.Status.PAUSED,
                               note="reviewing the copy")

    def test_a_paused_campaign_processes_nothing(self):
        self._pause()

        with Pipeline() as fake:
            reports = automation.run_once(owner=self.user, limit=5)

        self.assertEqual(fake.smtp.sent, [])
        self.assertEqual(reports, [])          # not even picked up

    def test_pausing_mid_pass_stops_at_the_next_lead(self):
        """Not after the forty leads that were left in the pass."""
        original = process.process
        calls = {"n": 0}

        def pause_after_first(plan, draft, courier):
            calls["n"] += 1
            outcome = original(plan, draft, courier)
            if calls["n"] == 1:
                self._pause()
            return outcome

        with Pipeline() as fake, \
             mock.patch.object(process, "process", side_effect=pause_after_first):
            automation.run_once(owner=self.user, limit=5)

        self.assertEqual(len(fake.smtp.sent), 1)

    def test_resuming_continues_rather_than_restarting(self):
        with Pipeline() as fake:
            automation.run_once(owner=self.user, limit=1)
            first = list(fake.smtp.sent)
            self._pause()
            automation.run_once(owner=self.user, limit=5)

            from apps.outreach.services import campaigns as campaign_ops
            campaign_ops.set_status(self.plan.campaign, Campaign.Status.ACTIVE)
            automation.run_once(owner=self.user, limit=5)

        self.assertEqual(fake.smtp.sent[:1], first)
        self.assertEqual(len(fake.smtp.sent), len(set(fake.smtp.sent)))
        self.assertEqual(SentLead.objects.count(), len(fake.smtp.sent))

    def test_pausing_keeps_everything_already_done(self):
        with Pipeline():
            automation.run_once(owner=self.user, limit=1)
        sent_before = SentLead.objects.count()

        self._pause()

        self.assertEqual(SentLead.objects.count(), sent_before)
        self.assertEqual(
            EmailDraft.objects.filter(status=EmailDraft.Status.SENT).count(), 1)

    def test_a_stopped_campaign_processes_nothing(self):
        from apps.outreach.services import campaigns as campaign_ops

        campaign_ops.set_status(self.plan.campaign, Campaign.Status.STOPPED)

        with Pipeline() as fake:
            automation.run_once(owner=self.user, limit=5)

        self.assertEqual(fake.smtp.sent, [])


# --------------------------------------------------------------------------- #
# Section 17: failures
# --------------------------------------------------------------------------- #

class FailureTests(TestCase):
    def setUp(self):
        self.user = make_user("fail@example.test")
        self.account = account_for(self.user)
        self.plan = seal(make_plan(self.user, account=self.account,
                                   daily_target=5, total_target=10))
        self.first = make_lead(self.plan, 0)
        self.second = make_lead(self.plan, 1)

    def test_one_unreachable_website_does_not_stop_the_campaign(self):
        def crawl(website, *a, **k):
            if "shop0" in website:
                raise OSError("connection reset")
            return site(website)

        with Pipeline(analyse=crawl) as fake:
            automation.run_once(owner=self.user, limit=5)

        self.assertEqual(fake.smtp.sent, [self.second.email])
        self.first.refresh_from_db()
        self.assertEqual(self.first.status, EmailDraft.Status.FAILED)
        self.assertIn("crawl failed", self.first.error_message)

    def test_a_failed_lead_is_not_counted_as_sent(self):
        def crawl(website, *a, **k):
            raise OSError("connection reset")

        with Pipeline(analyse=crawl):
            reports = automation.run_once(owner=self.user, limit=5)

        self.assertEqual(reports[0].sent, 0)
        self.assertEqual(SentLead.objects.count(), 0)
        day = AutomationDay.objects.get()
        self.assertEqual((day.sent, day.reserved), (0, 0))

    def test_an_ai_failure_skips_the_lead_and_carries_on(self):
        def write(**kwargs):
            if "Shop 0" in kwargs.get("business_name", ""):
                raise ai.AiError("the model refused")
            return WRITTEN

        with Pipeline(generate=write) as fake:
            automation.run_once(owner=self.user, limit=5)

        self.assertEqual(fake.smtp.sent, [self.second.email])
        self.first.refresh_from_db()
        self.assertNotEqual(self.first.status, EmailDraft.Status.SENT)

    def test_a_provider_rate_limit_stops_the_pass_without_losing_the_lead(self):
        from apps.ai.base import RATE_LIMIT, AiError

        def write(**kwargs):
            raise AiError("slow down", retryable=True, category=RATE_LIMIT)

        with Pipeline(generate=write) as fake:
            reports = automation.run_once(owner=self.user, limit=5)

        self.assertEqual(fake.smtp.sent, [])
        self.assertIn("rate limit", reports[0].stopped_because.lower())
        self.first.refresh_from_db()
        self.assertEqual(self.first.claimed_by, "")       # claimable again
        day = AutomationDay.objects.get()
        self.assertEqual(day.reserved, 0)                # slot given back

    def test_one_refused_recipient_does_not_stop_the_rest(self):
        with Pipeline(smtp=FakeSmtp(fail_for={self.first.email})) as fake:
            automation.run_once(owner=self.user, limit=5)

        self.assertEqual(fake.smtp.sent, [self.second.email])

    def test_a_mailbox_that_cannot_authenticate_pauses_the_campaign(self):
        broken = FakeSmtp(raise_on_enter=transport.SendError("login rejected"))

        with Pipeline(smtp=broken) as fake:
            automation.run_once(owner=self.user, limit=5)

        self.assertEqual(fake.smtp.sent, [])
        self.plan.campaign.refresh_from_db()
        self.assertEqual(self.plan.campaign.status, Campaign.Status.PAUSED)
        self.assertIn("login rejected", self.plan.campaign.status_note)

    def test_an_account_switched_off_mid_run_stops_the_campaign(self):
        original = process.process

        def switch_off_after_first(plan, draft, courier):
            outcome = original(plan, draft, courier)
            mailaccounts.set_active(self.user, self.account, False)
            return outcome

        with Pipeline() as fake, \
             mock.patch.object(process, "process",
                               side_effect=switch_off_after_first):
            reports = automation.run_once(owner=self.user, limit=5)

        self.assertEqual(len(fake.smtp.sent), 1)
        self.assertIn("switched off", reports[0].stopped_because)

    def test_a_failed_send_frees_the_address_for_a_later_attempt(self):
        with Pipeline(smtp=FakeSmtp(fail_for={self.first.email})):
            automation.run_once(owner=self.user, limit=5)

        record = SentLead.objects.filter(email=self.first.email).first()
        self.assertIsNotNone(record)
        self.assertEqual(record.status, SentLead.Status.FAILED)

    def test_a_lead_is_never_left_claimed_by_a_dead_pass(self):
        def explode(**kwargs):
            raise RuntimeError("something unexpected")

        with Pipeline(audit=explode):
            automation.run_once(owner=self.user, limit=5)

        self.first.refresh_from_db()
        self.assertNotEqual(self.first.status, EmailDraft.Status.SENT)


# --------------------------------------------------------------------------- #
# Section 10: the validation gate
# --------------------------------------------------------------------------- #

class ValidationGateTests(TestCase):
    """An email nobody would have approved must not go out unattended."""

    def setUp(self):
        self.user = make_user("gate@example.test")
        self.plan = make_plan(self.user)
        self.draft = make_lead(self.plan)

    def test_a_vague_email_is_held_rather_than_sent(self):
        vague = ai.GeneratedEmail(
            "Your website", "Hi there,\n\nI noticed some issues with your website "
            "and I would love to help.\n\nSam", "none", [])

        with Pipeline(generate=lambda **k: vague) as fake:
            automation.run_once(owner=self.user, limit=1)

        self.assertEqual(fake.smtp.sent, [])
        self.draft.refresh_from_db()
        self.assertEqual(self.draft.status, EmailDraft.Status.GENERATED)
        self.assertIn("Held for review", self.draft.error_message)

    def test_an_email_claiming_an_unverified_finding_is_held(self):
        stray = ai.GeneratedEmail(
            WRITTEN.subject, WRITTEN.body, WRITTEN.observation, ["AUD-999"])

        with Pipeline(generate=lambda **k: stray) as fake:
            automation.run_once(owner=self.user, limit=1)

        self.assertEqual(fake.smtp.sent, [])
        self.draft.refresh_from_db()
        self.assertIn("does not match any verified finding",
                      self.draft.error_message)

    def test_a_held_email_still_counts_as_no_send(self):
        vague = ai.GeneratedEmail("Your website", "Hi.\n\nSam", "none", [])

        with Pipeline(generate=lambda **k: vague):
            reports = automation.run_once(owner=self.user, limit=1)

        self.assertEqual(reports[0].sent, 0)
        self.assertEqual(SentLead.objects.count(), 0)

    def test_the_brief_template_accepts_a_short_email(self):
        """And the consultative one does not -- the band is the template's."""
        short = ai.GeneratedEmail(
            WRITTEN.subject,
            "Hi there,\n\nI had a look through your website. The homepage has no "
            "obvious way to get in touch -- no enquiry link and no phone number "
            "on it -- so somebody who has decided to call you has to go looking "
            "for a way to do it, and that is usually the moment they give up. "
            "Adding a visible call button near the top would give them somewhere "
            "to go.\n\nWould you be open to a quick call this week?\n\nSam",
            "the homepage has no obvious way to get in touch", ["AUD-001"])

        self.assertTrue(process.validate(
            _drafted(self.draft, short), _plan_with(self.plan, "brief")) == "",
            process.validate(_drafted(self.draft, short),
                             _plan_with(self.plan, "brief")))
        self.assertIn("not enough to explain", process.validate(
            _drafted(self.draft, short), _plan_with(self.plan, "consultative")))


def _drafted(draft: EmailDraft, email: ai.GeneratedEmail) -> EmailDraft:
    """A draft carrying one generated email, without saving it."""
    draft.subject = email.subject
    draft.body = email.body
    draft.observation = email.observation
    draft.findings_used = list(email.findings_used)
    draft.findings = [FINDING.as_dict()]
    return draft


def _plan_with(plan: AutomationPlan, key: str) -> AutomationPlan:
    plan.template_key = key
    return plan


# --------------------------------------------------------------------------- #
# Section 18: idempotency
# --------------------------------------------------------------------------- #

class IdempotencyTests(TestCase):
    def setUp(self):
        self.user = make_user("idem@example.test")
        self.plan = seal(make_plan(self.user, daily_target=5, total_target=10))
        self.draft = make_lead(self.plan)

    def test_running_the_worker_twice_sends_once(self):
        with Pipeline() as fake:
            automation.run_once(owner=self.user, limit=5)
            automation.run_once(owner=self.user, limit=5)

        self.assertEqual(fake.smtp.sent.count(self.draft.email), 1)
        self.assertEqual(SentLead.objects.count(), 1)

    def test_a_second_pass_does_not_re_crawl_a_finished_lead(self):
        with Pipeline() as fake:
            automation.run_once(owner=self.user, limit=5)
            first = fake.searches
            automation.run_once(owner=self.user, limit=5)

        self.draft.refresh_from_db()
        self.assertEqual(self.draft.status, EmailDraft.Status.SENT)
        self.assertGreaterEqual(fake.searches, first)

    def test_the_day_counters_are_not_double_counted(self):
        with Pipeline():
            automation.run_once(owner=self.user, limit=5)
            automation.run_once(owner=self.user, limit=5)

        day = AutomationDay.objects.get()
        self.assertEqual(day.sent, 1)

    def test_completing_twice_keeps_the_first_reason(self):
        self.plan.total_target = 1
        self.plan.save()

        with Pipeline():
            automation.run_once(owner=self.user, limit=5)
            automation.run_once(owner=self.user, limit=5)

        self.plan.refresh_from_db()
        self.assertIn("Total target of 1 reached", self.plan.completion_reason)


# --------------------------------------------------------------------------- #
# Prospecting: filling the pool
# --------------------------------------------------------------------------- #

class ProspectingTests(TestCase):
    def setUp(self):
        self.user = make_user("pool@example.test")
        self.plan = make_plan(self.user, cities=["Dallas", "Houston"],
                             categories=["Plumbing", "Roofing"])

    def test_every_combination_is_written_down_once(self):
        prospecting.ensure_searches(self.plan)
        prospecting.ensure_searches(self.plan)

        self.assertEqual(self.plan.searches.count(), 4)

    def test_a_search_fills_the_pool(self):
        with Pipeline():
            added = prospecting.fill(self.plan)

        self.assertEqual(added, 4)
        self.assertEqual(prospecting.pool_size(self.plan), 4)

    def test_a_search_is_never_repeated(self):
        with Pipeline() as fake:
            prospecting.fill(self.plan)
            prospecting.fill(self.plan)

        self.assertEqual(fake.searches, 2)
        self.assertEqual(
            self.plan.searches.filter(
                status=ProspectSearch.Status.PENDING).count(), 2)

    def test_two_workers_do_not_run_the_same_search(self):
        prospecting.ensure_searches(self.plan)

        first = prospecting.claim_search(self.plan)
        second = prospecting.claim_search(self.plan)

        self.assertNotEqual(first.pk, second.pk)

    def test_an_already_contacted_business_is_recorded_not_queued(self):
        SentLead.objects.create(owner=self.user, email="shop10@example.test",
                                business_name="Shop 10",
                                status=SentLead.Status.SENT)

        with Pipeline():
            prospecting.fill(self.plan)

        row = EmailDraft.objects.get(email="shop10@example.test")
        self.assertEqual(row.status, EmailDraft.Status.DUPLICATE)
        self.assertIn("Already contacted", row.error_message)

    def test_a_suppressed_business_is_recorded_not_queued(self):
        Suppression.objects.create(owner=self.user, email="shop11@example.test",
                                   reason=Suppression.Reason.MANUAL)

        with Pipeline():
            prospecting.fill(self.plan)

        row = EmailDraft.objects.get(email="shop11@example.test")
        self.assertEqual(row.status, EmailDraft.Status.SUPPRESSED)

    def test_a_business_with_no_website_is_excluded_when_one_was_asked_for(self):
        def found(country, city, category, limit):
            area = Area(city=city, country=country, label=city, lat=1.0, lon=2.0,
                        bbox=(0, 0, 1, 1))
            return area, [Lead(business_name="No Site", category=category,
                               country=country, city=city, address="", phone="",
                               email="nosite@example.test", website="",
                               latitude=1.0, longitude=2.0, source="")]

        with Pipeline(found=found):
            prospecting.fill(self.plan)

        row = EmailDraft.objects.get(email="nosite@example.test")
        self.assertEqual(row.status, EmailDraft.Status.EXCLUDED)

    def test_a_failed_search_is_recorded_and_does_not_raise(self):
        from apps.leads.scraper import ScrapeError

        def broken(country, city, category, limit):
            raise ScrapeError("Nominatim could not find that place.")

        with Pipeline(found=broken):
            added = prospecting.fill(self.plan)

        self.assertEqual(added, 0)
        self.assertTrue(self.plan.searches.filter(
            status=ProspectSearch.Status.FAILED).exists())

    def test_the_pool_is_topped_up_only_when_it_runs_low(self):
        for index in range(prospecting.LOW_WATER + 1):
            make_lead(self.plan, index)

        with Pipeline() as fake:
            prospecting.top_up(self.plan)

        self.assertEqual(fake.searches, 0)

    def test_exhausted_means_nothing_left_and_nowhere_to_look(self):
        prospecting.ensure_searches(self.plan)
        self.assertFalse(prospecting.exhausted(self.plan))

        self.plan.searches.update(status=ProspectSearch.Status.DONE)
        self.assertTrue(prospecting.exhausted(self.plan))

    def test_a_campaign_with_nothing_left_completes(self):
        prospecting.ensure_searches(self.plan)
        self.plan.searches.update(status=ProspectSearch.Status.EMPTY)

        with Pipeline():
            automation.run_once(owner=self.user, limit=5)

        self.plan.campaign.refresh_from_db()
        self.plan.refresh_from_db()
        self.assertEqual(self.plan.campaign.status, Campaign.Status.COMPLETED)
        self.assertIn("No eligible businesses", self.plan.completion_reason)

    def test_cities_are_matched_to_the_country_that_has_them(self):
        plan = make_plan(self.user, name="Two countries",
                        account=account_for(self.user, name="Second",
                                            email="second@example.test"),
                        countries=["United States", "United Kingdom"],
                        cities=["Dallas", "Manchester"],
                        categories=["Plumbing"])

        pairs = {(country, city)
                 for country, city, _category in prospecting.combinations(plan)}

        self.assertIn(("United States", "Dallas"), pairs)
        self.assertIn(("United Kingdom", "Manchester"), pairs)
        self.assertNotIn(("United Kingdom", "Dallas"), pairs)


# --------------------------------------------------------------------------- #
# Section 12: sending controls
# --------------------------------------------------------------------------- #

class SendingControlTests(TestCase):
    def setUp(self):
        self.user = make_user("send@example.test")
        self.account = account_for(self.user)
        self.plan = seal(make_plan(self.user, account=self.account,
                                   daily_target=5, total_target=10))

    def test_the_courier_refuses_an_inactive_account(self):
        mailaccounts.set_active(self.user, self.account, False)

        blocked = courier_module.Courier(self.plan).check()

        self.assertIn("switched off", blocked)

    def test_the_courier_refuses_an_account_at_its_daily_cap(self):
        cap = mailaccounts.daily_cap(self.account)
        for index in range(cap):
            SentLead.objects.create(
                owner=self.user, email=f"used{index}@example.test",
                business_name="Used", status=SentLead.Status.SENT,
                sender_email=self.account.sender_email)

        blocked = courier_module.Courier(self.plan).check()

        self.assertIn("daily limit", blocked)

    def test_sends_are_spaced_by_at_least_the_providers_delay(self):
        make_lead(self.plan, 0)
        make_lead(self.plan, 1)

        with Pipeline(), mock.patch(
                "apps.outreach.services.automation.courier.time.sleep") as slept:
            automation.run_once(owner=self.user, limit=5)

        self.assertTrue(slept.called)
        # The gap minus whatever already elapsed: asserting the whole gap would be
        # asserting that the courier ignores the time the last send took.
        gap = mailaccounts.provider_of(self.account).delay
        waited = max(call.args[0] for call in slept.call_args_list)
        self.assertGreater(waited, 0)
        self.assertLessEqual(waited, gap)
        self.assertGreater(waited, gap - 1.0)

    def test_a_campaigns_extra_gap_is_respected(self):
        self.plan.send_gap_seconds = 30
        self.plan.save()
        make_lead(self.plan, 0)
        make_lead(self.plan, 1)

        with Pipeline(), mock.patch(
                "apps.outreach.services.automation.courier.time.sleep") as slept:
            automation.run_once(owner=self.user, limit=5)

        self.assertGreaterEqual(
            max(call.args[0] for call in slept.call_args_list), 29)

    def test_the_session_is_opened_once_for_a_run_of_leads(self):
        for index in range(3):
            make_lead(self.plan, index)

        with Pipeline() as fake:
            automation.run_once(owner=self.user, limit=5)

        self.assertEqual(len(fake.smtp.sent), 3)
        self.assertEqual(fake.smtp.opened, 1)


# --------------------------------------------------------------------------- #
# Section 20: follow-ups stay manual
# --------------------------------------------------------------------------- #

class FollowUpTests(TestCase):
    def setUp(self):
        self.user = make_user("follow@example.test")
        self.plan = seal(make_plan(self.user, daily_target=5, total_target=10))
        self.draft = make_lead(self.plan)

    def test_sending_schedules_the_next_follow_up_without_sending_it(self):
        with Pipeline():
            automation.run_once(owner=self.user, limit=1)

        row = FollowUp.objects.get()
        self.assertEqual(row.status, FollowUp.Status.WAITING)
        self.assertIsNotNone(row.scheduled_for)

    def test_the_worker_has_no_path_that_sends_a_follow_up(self):
        with Pipeline():
            automation.run_once(owner=self.user, limit=1)

        self.assertEqual(
            FollowUp.objects.filter(status=FollowUp.Status.SENT).count(), 0)

    def test_a_due_follow_up_is_prepared_and_left_for_approval(self):
        with Pipeline():
            automation.run_once(owner=self.user, limit=1)

        lead = SentLead.objects.get()
        SentLead.objects.filter(pk=lead.pk).update(
            reserved_at=timezone.now() - dt.timedelta(days=30),
            sent_at=timezone.now() - dt.timedelta(days=30),
            sent_date=(timezone.now() - dt.timedelta(days=30)).date())

        with mock.patch.object(ai, "follow_up", return_value=WRITTEN):
            prepared = process.prepare_followups(self.plan)

        self.assertEqual(prepared, 1)
        row = FollowUp.objects.get(number=1)
        self.assertEqual(row.status, FollowUp.Status.DUE)
        self.assertEqual(
            FollowUp.objects.filter(status=FollowUp.Status.SENT).count(), 0)

    def test_a_pass_prepares_a_due_follow_up_without_sending_it(self):
        """Wired into the pass, so a deployment running only this worker gets them."""
        # A spare lead, so the campaign is still active for the second pass rather
        # than completed for having run out of prospects.
        make_lead(self.plan, 1)
        with Pipeline():
            automation.run_once(owner=self.user, limit=1)

        lead = SentLead.objects.get()
        SentLead.objects.filter(pk=lead.pk).update(
            reserved_at=timezone.now() - dt.timedelta(days=30),
            sent_at=timezone.now() - dt.timedelta(days=30),
            sent_date=(timezone.now() - dt.timedelta(days=30)).date())
        FollowUp.objects.all().delete()

        with Pipeline() as fake, mock.patch.object(ai, "follow_up",
                                                   return_value=WRITTEN):
            reports = automation.run_once(owner=self.user, limit=1)

        self.assertEqual(reports[0].followups, 1)
        # One prepared for the backdated lead. The other row is the schedule the
        # second lead's own send wrote, which is a different thing.
        self.assertEqual(FollowUp.objects.get(lead=lead).status,
                         FollowUp.Status.DUE)
        self.assertEqual(
            FollowUp.objects.filter(status=FollowUp.Status.SENT).count(), 0)
        self.assertNotIn(lead.email, fake.smtp.sent)

    def test_a_completed_campaign_still_follows_up_on_what_it_sent(self):
        """Reaching a target is finishing, not abandoning the people contacted."""
        from apps.outreach.services import campaigns as campaign_ops

        campaign_ops.set_status(self.plan.campaign, Campaign.Status.COMPLETED,
                               note="Total target reached.")

        self.assertTrue(self.plan.campaign.may_follow_up)
        self.assertFalse(self.plan.campaign.may_send)

    def test_a_paused_campaign_follows_up_on_nothing(self):
        """Pausing is a person stopping everything, and it stops this too."""
        from apps.outreach.services import campaigns as campaign_ops

        campaign_ops.set_status(self.plan.campaign, Campaign.Status.PAUSED)

        self.assertFalse(self.plan.campaign.may_follow_up)

    def test_a_completed_campaigns_follow_up_is_still_prepared(self):
        with Pipeline():
            automation.run_once(owner=self.user, limit=1)

        lead = SentLead.objects.first()
        SentLead.objects.filter(pk=lead.pk).update(
            reserved_at=timezone.now() - dt.timedelta(days=30),
            sent_at=timezone.now() - dt.timedelta(days=30),
            sent_date=(timezone.now() - dt.timedelta(days=30)).date())
        FollowUp.objects.all().delete()

        from apps.outreach.services import campaigns as campaign_ops

        campaign_ops.set_status(self.plan.campaign, Campaign.Status.COMPLETED,
                               note="Total target reached.")

        with mock.patch.object(ai, "follow_up", return_value=WRITTEN):
            prepared = process.prepare_followups(self.plan)

        self.assertEqual(prepared, 1)
        self.assertEqual(FollowUp.objects.get(lead=lead).status,
                         FollowUp.Status.DUE)

    def test_a_paused_campaigns_follow_up_is_not_prepared(self):
        with Pipeline():
            automation.run_once(owner=self.user, limit=1)

        lead = SentLead.objects.first()
        SentLead.objects.filter(pk=lead.pk).update(
            reserved_at=timezone.now() - dt.timedelta(days=30),
            sent_at=timezone.now() - dt.timedelta(days=30),
            sent_date=(timezone.now() - dt.timedelta(days=30)).date())
        FollowUp.objects.all().delete()

        from apps.outreach.services import campaigns as campaign_ops

        campaign_ops.set_status(self.plan.campaign, Campaign.Status.PAUSED)

        with mock.patch.object(ai, "follow_up", return_value=WRITTEN) as write:
            prepared = process.prepare_followups(self.plan)

        self.assertEqual(prepared, 0)
        write.assert_not_called()

    def test_follow_ups_can_be_switched_off_entirely(self):
        self.plan.followups_enabled = False
        self.plan.save()

        with Pipeline():
            automation.run_once(owner=self.user, limit=1)

        self.assertEqual(FollowUp.objects.count(), 0)


# --------------------------------------------------------------------------- #
# Sections 3 and 16: the dashboard and the log
# --------------------------------------------------------------------------- #

class DashboardTests(SignedIn):
    def setUp(self):
        super().setUp()
        self.plan = seal(make_plan(self.user, daily_target=5, total_target=10))
        self.draft = make_lead(self.plan)
        # A second lead so a one-lead pass does not exhaust the pool and complete
        # the campaign -- which is right, and not what these tests are watching.
        make_lead(self.plan, 1)

    def test_the_dashboard_renders_before_anything_has_happened(self):
        page = self.client.get(
            reverse("outreach:automation_view", args=[self.plan.pk]))

        self.assertContains(page, self.plan.name)
        self.assertContains(page, "Progress")
        self.assertContains(page, "America/Chicago")

    def test_the_figures_follow_the_work(self):
        # Read inside the fixture: "today" is the campaign's own date, so a page
        # rendered outside the frozen clock is reporting a different day -- which is
        # correct, and not what this test is about.
        with Pipeline():
            automation.run_once(owner=self.user, limit=1)
            page = self.client.get(
                reverse("outreach:automation_view", args=[self.plan.pk]))
            figures = page.context["figures"]

        self.assertEqual(figures["sent"], 1)
        self.assertEqual(figures["today_sent"], 1)
        self.assertEqual(figures["audited"], 1)
        self.assertEqual(figures["remaining"], 9)

    def test_the_state_endpoint_reports_the_same_numbers(self):
        with Pipeline():
            automation.run_once(owner=self.user, limit=1)
            state = self.client.get(
                reverse("outreach:automation_state", args=[self.plan.pk])).json()

        self.assertEqual(state["figures"]["sent"], 1)
        self.assertEqual(state["status"], "active")
        self.assertTrue(state["events"])

    def test_the_state_endpoint_does_no_work(self):
        with mock.patch.object(crawler, "analyse") as crawl:
            self.client.get(
                reverse("outreach:automation_state", args=[self.plan.pk]))

        crawl.assert_not_called()

    def test_no_password_reaches_the_dashboard(self):
        body = self.client.get(
            reverse("outreach:automation_view", args=[self.plan.pk])
        ).content.decode()

        self.assertNotIn("abcd efgh ijkl mnop", body)
        self.assertNotIn("abcdefghijklmnop", body)

    def test_another_workspaces_state_is_not_readable(self):
        other = OtherUser()
        theirs = make_plan(other.user, name="Theirs")

        response = self.client.get(
            reverse("outreach:automation_state", args=[theirs.pk]))

        self.assertEqual(response.status_code, 404)


class EventLogTests(TestCase):
    def setUp(self):
        self.user = make_user("log@example.test")
        self.plan = seal(make_plan(self.user, daily_target=5, total_target=10))
        self.draft = make_lead(self.plan)

    def test_the_whole_journey_of_one_lead_is_recorded(self):
        with Pipeline():
            automation.run_once(owner=self.user, limit=1)

        kinds = list(CampaignEvent.objects.values_list("kind", flat=True))

        for expected in (CampaignEvent.Kind.SELECTED, CampaignEvent.Kind.CRAWLED,
                         CampaignEvent.Kind.FINDINGS,
                         CampaignEvent.Kind.GENERATED, CampaignEvent.Kind.SENT):
            with self.subTest(kind=expected):
                self.assertIn(expected, kinds)

    def test_a_skip_says_which_rule_refused(self):
        make_lead(self.plan, 1, city="Reykjavik")

        with Pipeline():
            automation.run_once(owner=self.user, limit=5)

        skip = CampaignEvent.objects.filter(
            kind=CampaignEvent.Kind.SKIPPED).first()
        self.assertIn("Reykjavik", skip.detail)

    def test_an_event_names_the_lead_it_was_about(self):
        with Pipeline():
            automation.run_once(owner=self.user, limit=1)

        selected = CampaignEvent.objects.filter(
            kind=CampaignEvent.Kind.SELECTED).first()
        self.assertEqual(selected.draft_id, self.draft.pk)
        self.assertIn("Shop 0", selected.message)

    def test_a_failure_to_log_does_not_stop_the_campaign(self):
        with Pipeline() as fake, \
             mock.patch.object(CampaignEvent.objects, "create",
                               side_effect=RuntimeError("log is full")):
            automation.run_once(owner=self.user, limit=1)

        self.assertEqual(fake.smtp.sent, [self.draft.email])

    def test_the_log_survives_the_lead_being_deleted(self):
        with Pipeline():
            automation.run_once(owner=self.user, limit=1)
        before = CampaignEvent.objects.count()

        EmailDraft.objects.filter(pk=self.draft.pk).delete()

        self.assertEqual(CampaignEvent.objects.count(), before)
        self.assertIsNone(
            CampaignEvent.objects.filter(
                kind=CampaignEvent.Kind.SELECTED).first().draft_id)


# --------------------------------------------------------------------------- #
# Section 21: completion
# --------------------------------------------------------------------------- #

class CompletionTests(TestCase):
    def setUp(self):
        self.user = make_user("done@example.test")
        self.plan = seal(make_plan(self.user, daily_target=5, total_target=1))
        make_lead(self.plan)

    def test_reaching_the_total_says_so(self):
        with Pipeline():
            automation.run_once(owner=self.user, limit=5)

        self.plan.refresh_from_db()
        self.plan.campaign.refresh_from_db()
        self.assertEqual(self.plan.campaign.status, Campaign.Status.COMPLETED)
        self.assertIn("Total target of 1 reached", self.plan.completion_reason)
        self.assertIn("Total target", self.plan.campaign.status_note)

    def test_the_reason_is_shown_on_the_dashboard(self):
        with Pipeline():
            automation.run_once(owner=self.user, limit=5)

        from django.test import Client

        client = Client()
        client.force_login(self.user)
        page = client.get(reverse("outreach:automation_view",
                                 args=[self.plan.pk]))

        self.assertContains(page, "Total target of 1 reached")

    def test_a_completed_campaign_does_no_more_work(self):
        with Pipeline() as fake:
            automation.run_once(owner=self.user, limit=5)
            make_lead(self.plan, 9)
            automation.run_once(owner=self.user, limit=5)

        self.assertEqual(len(fake.smtp.sent), 1)

    def test_completion_is_recorded_in_the_log(self):
        with Pipeline():
            automation.run_once(owner=self.user, limit=5)

        self.assertTrue(CampaignEvent.objects.filter(
            kind=CampaignEvent.Kind.COMPLETED).exists())


class SendingAddressPrerequisiteTests(SignedIn):
    """The new-plan form has to say that a sending address is needed.

    Without one the "Send from" dropdown is empty, and submitting produces only
    "This field is required" -- an error that names the field but not the fix, on a page
    that cannot offer it. This was the reported symptom: a schedule set, nothing running,
    and no plan actually created.
    """

    def page(self) -> str:
        return self.client.get(reverse("outreach:automation_new")).content.decode()

    def mailbox(self, **fields):
        from apps.outreach.mail import accounts as mailaccounts

        return mailaccounts.save_account(
            self.user, name=fields.pop("name", "Sales"),
            sender_name="Sam Rivers",
            sender_email=fields.pop("sender_email", "sales@company.test"),
            provider="gmail", password=fields.pop("password", "abcd efgh ijkl mnop"),
            **fields)

    def test_with_no_address_the_page_says_so_before_the_form(self):
        body = self.page()

        self.assertIn("Add a sending address first", body)
        self.assertIn("No sending address is configured", body)
        # And points at where to do it.
        self.assertIn(reverse("outreach:settings"), body)

    def test_with_a_usable_address_the_warning_is_gone(self):
        self.mailbox()

        body = self.page()

        self.assertNotIn("Add a sending address first", body)
        self.assertNotIn("No sending address is configured", body)
        self.assertIn("sales@company.test", body)

    def test_an_address_with_no_password_is_reported_as_unusable(self):
        """Configured but not sendable -- a different problem, a different sentence."""
        self.mailbox(password="")

        body = self.page()

        self.assertIn("No configured address can send yet", body)
        self.assertNotIn("No sending address is configured", body)

    def test_a_switched_off_address_is_reported_as_unusable(self):
        self.mailbox(is_active=False)

        self.assertIn("No configured address can send yet", self.page())

    def test_submitting_without_an_address_creates_no_plan(self):
        """The behaviour is unchanged -- it is the explanation that was missing."""
        response = self.client.post(reverse("outreach:automation_new"), data={
            "name": "Delft restaurants", "countries": "Netherlands",
            "cities": "Delft", "categories": "Restaurants", "quality": "any",
            "daily_target": "10", "total_target": "100",
            "start_date": "2026-08-20", "start_time": "09:00", "end_time": "17:00",
            "timezone_name": "Europe/Amsterdam", "template_key": "consultative",
            "service_pitch": "We build fast websites with booking for restaurants.",
        })

        self.assertEqual(response.status_code, 200)
        self.assertEqual(AutomationPlan.objects.count(), 0)
        self.assertIn("email_account", response.context["form"].errors)
        # And the page it comes back with explains what to do about it.
        self.assertIn("Add a sending address first", response.content.decode())
