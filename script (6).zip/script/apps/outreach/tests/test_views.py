"""
The screens: what they show, and what they refuse to do.

Thin views are easy to test and these tests are the evidence -- each one drives a URL
and checks the page, because there is no business logic in the view to reach past.
"""

from __future__ import annotations

import os
from unittest import mock

from django.conf import settings
from django.test import override_settings
from django.urls import reverse
from django.utils import timezone

from apps import ai
from apps.core.testing import EMAIL_BODY, SignedIn
from apps.outreach.mail import compose, providers, transport
from apps.outreach.models import Campaign, EmailDraft
from apps.outreach.services import pipeline as runner

from .factories import make_campaign, make_draft


@override_settings(ALLOWED_HOSTS=["*"])
class StartTests(SignedIn):
    def _post(self, leads, **extra):
        body = {"leads": leads, "area": {"city": "Delft", "country": "NL"},
                "category": "Restaurants"}
        body.update(extra)
        return self.client.post(reverse("outreach:start"), data=body,
                                content_type="application/json")

    def test_leads_become_drafts_and_return_a_setup_url(self):
        response = self._post([
            {"business_name": "A", "email": "a@x.test", "website": "https://a.test"},
            {"business_name": "B", "email": "b@x.test"},
        ])

        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["eligible"], 2)
        self.assertIn("/setup", data["setup_url"])

        campaign = Campaign.objects.get(pk=data["campaign_id"])
        self.assertEqual(campaign.city, "Delft")
        self.assertEqual(campaign.drafts.count(), 2)

    def test_leads_without_an_email_are_marked_not_dropped(self):
        response = self._post([
            {"business_name": "A", "email": "a@x.test"},
            {"business_name": "No Email", "email": ""},
            {"business_name": "Bad Email", "email": "not-an-address"},
        ])

        campaign = Campaign.objects.get(pk=response.json()["campaign_id"])
        self.assertEqual(response.json()["eligible"], 1)
        self.assertEqual(campaign.drafts.count(), 3)
        self.assertEqual(
            campaign.drafts.filter(status=EmailDraft.Status.NO_EMAIL).count(), 2)

    def test_two_leads_sharing_an_address_keep_only_the_first(self):
        response = self._post([
            {"business_name": "Branch A", "email": "same@x.test"},
            {"business_name": "Branch B", "email": "same@x.test"},
        ])

        campaign = Campaign.objects.get(pk=response.json()["campaign_id"])
        self.assertEqual(response.json()["eligible"], 1)
        self.assertEqual(
            campaign.drafts.filter(status=EmailDraft.Status.DUPLICATE).count(), 1)

    def test_empty_selection_is_a_400(self):
        self.assertEqual(self._post([]).status_code, 400)

    def test_oversized_selection_is_a_400(self):
        leads = [{"business_name": f"B{i}", "email": f"b{i}@x.test"}
                 for i in range(400)]

        self.assertEqual(self._post(leads).status_code, 400)
@override_settings(ALLOWED_HOSTS=["*"])
class RunTests(SignedIn):
    def setUp(self):
        self.campaign = make_campaign(phase=Campaign.Phase.SETUP,
                                      sender_name="", sender_email="",
                                      provider="", service_pitch="")
        self.a = make_draft(self.campaign, business_name="A", email="a@x.test",
                            status=EmailDraft.Status.PENDING)
        self.b = make_draft(self.campaign, business_name="B", email="b@x.test",
                            status=EmailDraft.Status.PENDING)

    def _post(self, **overrides):
        body = {
            "sender_name": "Sam Rivers",
            "sender_email": "sam@agency.test",
            "sender_company": "Northline",
            "provider": "gmail",
            "service_pitch": "We build booking websites for restaurants.",
            "selected": [self.a.pk, self.b.pk],
        }
        body.update(overrides)
        return self.client.post(
            reverse("outreach:run", args=[self.campaign.id]),
            data=body, content_type="application/json",
        )

    def test_valid_settings_save_and_start_the_pipeline(self):
        with mock.patch.object(runner, "start_pipeline", return_value=True) as start:
            response = self._post()

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["queued"], 2)
        start.assert_called_once()

        self.campaign.refresh_from_db()
        self.assertEqual(self.campaign.sender_email, "sam@agency.test")
        self.assertEqual(self.campaign.provider, "gmail")

    def test_deselected_leads_are_excluded_not_deleted(self):
        with mock.patch.object(runner, "start_pipeline", return_value=True):
            self._post(selected=[self.a.pk])

        self.b.refresh_from_db()
        self.assertEqual(self.b.status, EmailDraft.Status.EXCLUDED)
        self.assertEqual(self.campaign.drafts.count(), 2)

    def test_missing_sender_name_is_a_400(self):
        self.assertEqual(self._post(sender_name="").status_code, 400)

    def test_invalid_sender_email_is_a_400(self):
        self.assertEqual(self._post(sender_email="nope").status_code, 400)

    def test_unknown_provider_is_a_400(self):
        self.assertEqual(self._post(provider="carrier-pigeon").status_code, 400)

    def test_thin_service_description_is_a_400(self):
        response = self._post(service_pitch="stuff")

        self.assertEqual(response.status_code, 400)
        self.assertIn("what you offer", response.json()["error"])

    def test_empty_selection_is_a_400(self):
        self.assertEqual(self._post(selected=[]).status_code, 400)

    def test_a_started_campaign_cannot_be_restarted(self):
        Campaign.objects.filter(pk=self.campaign.pk).update(
            phase=Campaign.Phase.REVIEW)

        self.assertEqual(self._post().status_code, 409)
@override_settings(ALLOWED_HOSTS=["*"])
class SenderDefaultsTests(SignedIn):
    """The configured identity pre-fills the form; a campaign keeps its own."""

    def setUp(self):
        self.campaign = make_campaign(phase=Campaign.Phase.SETUP,
                                      sender_name="", sender_email="",
                                      sender_company="", provider="")
        make_draft(self.campaign, status=EmailDraft.Status.PENDING)

    def _setup_page(self):
        return self.client.get(reverse("outreach:setup", args=[self.campaign.id]))

    def test_configured_sender_is_prefilled(self):
        response = self._setup_page()

        self.assertEqual(response.status_code, 200)
        body = response.content.decode()
        self.assertIn(f'value="{settings.OUTREACH_SENDER_EMAIL}"', body)
        self.assertIn(f'value="{settings.OUTREACH_SENDER_NAME}"', body)

    def test_configured_provider_is_preselected(self):
        body = self._setup_page().content.decode()

        self.assertIn(f'value="{settings.OUTREACH_PROVIDER}" selected', body)

    @override_settings(OUTREACH_SENDER_EMAIL="other@example.test",
                       OUTREACH_SENDER_NAME="Other Person")
    def test_settings_drive_the_prefill(self):
        body = self._setup_page().content.decode()

        self.assertIn('value="other@example.test"', body)
        self.assertIn('value="Other Person"', body)

    def test_a_campaign_with_its_own_sender_keeps_it(self):
        Campaign.objects.filter(pk=self.campaign.pk).update(
            sender_email="oneoff@agency.test", sender_name="One Off")

        body = self._setup_page().content.decode()

        self.assertIn('value="oneoff@agency.test"', body)
        self.assertNotIn(settings.OUTREACH_SENDER_EMAIL, body)

    def test_the_default_provider_matches_the_default_address(self):
        # A gmail.com address configured against an Outlook host would fail
        # authentication on the first send, so keep the two in step.
        domain = settings.OUTREACH_SENDER_EMAIL.rsplit("@", 1)[-1].lower()
        if domain in ("gmail.com", "googlemail.com"):
            self.assertEqual(settings.OUTREACH_PROVIDER, "gmail")
        self.assertIn(settings.OUTREACH_PROVIDER, providers.PROVIDERS)

    def test_the_submitted_sender_is_what_gets_stored(self):
        draft = self.campaign.drafts.first()
        with mock.patch.object(runner, "start_pipeline", return_value=True):
            self.client.post(
                reverse("outreach:run", args=[self.campaign.id]),
                data={
                    "sender_name": settings.OUTREACH_SENDER_NAME,
                    "sender_email": settings.OUTREACH_SENDER_EMAIL,
                    "sender_company": "Northline",
                    "provider": settings.OUTREACH_PROVIDER,
                    "service_pitch": "We build booking websites for restaurants.",
                    "selected": [draft.pk],
                },
                content_type="application/json",
            )

        self.campaign.refresh_from_db()
        self.assertEqual(self.campaign.sender_email, settings.OUTREACH_SENDER_EMAIL)
        self.assertEqual(self.campaign.provider, settings.OUTREACH_PROVIDER)

    def test_sending_from_the_configured_address_is_not_spoofing(self):
        session = transport.Session(
            providers.PROVIDERS[settings.OUTREACH_PROVIDER],
            settings.OUTREACH_SENDER_EMAIL, "app-password",
        )
        message = compose.build_message(
            sender_name=settings.OUTREACH_SENDER_NAME,
            sender_email=settings.OUTREACH_SENDER_EMAIL,
            to_email="lead@example.test", subject="Hi", body="Body",
        )

        self.assertEqual(session.username, settings.OUTREACH_SENDER_EMAIL)
        self.assertIn(settings.OUTREACH_SENDER_EMAIL, message["From"])
@override_settings(ALLOWED_HOSTS=["*"])
class DraftActionTests(SignedIn):
    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(self.campaign)

    def _act(self, action, **body):
        return self.client.post(
            reverse("outreach:draft_action", args=[self.draft.pk, action]),
            data=body, content_type="application/json",
        )

    def test_save_records_an_edit(self):
        response = self._act("save", subject="New subject", body="New body")

        self.assertEqual(response.status_code, 200)
        self.draft.refresh_from_db()
        self.assertEqual(self.draft.subject, "New subject")
        self.assertTrue(self.draft.edited)

    def test_save_rejects_empty_content(self):
        self.assertEqual(self._act("save", subject="", body="x").status_code, 400)

    def test_approve_moves_the_draft_to_approved(self):
        self._act("approve")
        self.draft.refresh_from_db()

        self.assertEqual(self.draft.status, EmailDraft.Status.APPROVED)

    def test_reject_moves_the_draft_to_rejected(self):
        self._act("reject")
        self.draft.refresh_from_db()

        self.assertEqual(self.draft.status, EmailDraft.Status.REJECTED)

    def test_regenerate_replaces_the_email_and_counts_the_attempt(self):
        new = ai.GeneratedEmail("Fresh subject", EMAIL_BODY, "their menu page")

        with mock.patch.object(ai, "generate", return_value=new) as generate:
            response = self._act("regenerate", hint="shorter")

        self.assertEqual(response.status_code, 200)
        self.draft.refresh_from_db()
        self.assertEqual(self.draft.subject, "Fresh subject")
        self.assertEqual(self.draft.regenerations, 1)
        self.assertEqual(generate.call_args.kwargs["retry_hint"], "shorter")

    def test_regenerate_failure_returns_the_reason(self):
        with mock.patch.object(ai, "generate",
                               side_effect=ai.AiError("no API key")):
            response = self._act("regenerate")

        self.assertEqual(response.status_code, 502)
        self.assertIn("no API key", response.json()["error"])

    def test_a_sent_draft_cannot_be_edited(self):
        EmailDraft.objects.filter(pk=self.draft.pk).update(
            status=EmailDraft.Status.SENT)

        self.assertEqual(self._act("save", subject="x", body="y").status_code, 409)

    def test_unknown_action_is_a_400(self):
        self.assertEqual(self._act("detonate").status_code, 400)
@override_settings(ALLOWED_HOSTS=["*"])
class WorkspaceViewTests(SignedIn):
    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(self.campaign)

    def test_state_reports_counts_and_drafts(self):
        response = self.client.get(
            reverse("outreach:state", args=[self.campaign.id]))

        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["campaign"]["phase"], "review")
        self.assertEqual(len(data["drafts"]), 1)
        self.assertEqual(data["drafts"][0]["business_name"], "Bella Cucina")
        self.assertEqual(data["counts"]["total"], 1)

    def test_state_separates_leads_that_cannot_be_emailed(self):
        make_draft(self.campaign, business_name="No Email", email="",
                   status=EmailDraft.Status.NO_EMAIL)

        data = self.client.get(
            reverse("outreach:state", args=[self.campaign.id])).json()

        self.assertEqual(len(data["drafts"]), 1)
        self.assertEqual(len(data["skipped"]), 1)

    def test_state_flags_an_address_contacted_in_an_earlier_campaign(self):
        older = make_campaign()
        make_draft(older, email="ciao@bella.example",
                   status=EmailDraft.Status.SENT, sent_at=timezone.now())

        data = self.client.get(
            reverse("outreach:state", args=[self.campaign.id])).json()

        self.assertTrue(data["drafts"][0]["previously_contacted"])

    def test_approve_all_approves_every_drafted_email(self):
        make_draft(self.campaign, business_name="Second", email="two@x.test")
        make_draft(self.campaign, business_name="Rejected", email="three@x.test",
                   status=EmailDraft.Status.REJECTED)

        response = self.client.post(
            reverse("outreach:approve_all", args=[self.campaign.id]))

        self.assertEqual(response.json()["approved"], 2)
        self.assertEqual(response.json()["counts"]["approved"], 2)

    def test_workspace_page_renders(self):
        response = self.client.get(
            reverse("outreach:workspace", args=[self.campaign.id]))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Review &amp; send")

    def test_workspace_carries_the_hooks_the_progress_panel_needs(self):
        response = self.client.get(
            reverse("outreach:workspace", args=[self.campaign.id]))

        # workspace.js looks these up by id; a rename here breaks the panel
        # silently, which is exactly the kind of thing a test should catch.
        for element_id in ("run", "run-position", "run-total", "run-current",
                           "run-pct", "run-bar", "run-seg", "run-steps",
                           "run-next", "run-queue", "run-leads"):
            self.assertContains(response, f'id="{element_id}"')

    def test_setup_redirects_once_the_campaign_has_started(self):
        response = self.client.get(
            reverse("outreach:setup", args=[self.campaign.id]))

        self.assertEqual(response.status_code, 302)

    def test_report_page_lists_outcomes(self):
        EmailDraft.objects.filter(pk=self.draft.pk).update(
            status=EmailDraft.Status.SENT, sent_at=timezone.now())

        response = self.client.get(
            reverse("outreach:report", args=[self.campaign.id]))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Bella Cucina")
        self.assertContains(response, "ciao@bella.example")

    def test_history_page_lists_campaigns(self):
        response = self.client.get(reverse("outreach:history"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Restaurants")
@override_settings(ALLOWED_HOSTS=["*"])
class SendViewTests(SignedIn):
    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(self.campaign, status=EmailDraft.Status.APPROVED)

    def _post(self, **body):
        return self.client.post(
            reverse("outreach:send", args=[self.campaign.id]),
            data=body, content_type="application/json",
        )

    def test_send_starts_the_background_run(self):
        with mock.patch.object(runner, "start_send", return_value=True) as start:
            response = self._post(password="app-password")

        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["started"])
        self.assertEqual(start.call_args[0][1], "app-password")

    def test_missing_password_is_a_400(self):
        # OUTREACH_SMTP_PASSWORD is set for real use, and the view falls back to
        # it -- so clear it to test the genuinely-unconfigured case.

        env = {k: v for k, v in os.environ.items() if k != "OUTREACH_SMTP_PASSWORD"}
        with mock.patch.dict(os.environ, env, clear=True):
            response = self._post(password="")

        self.assertEqual(response.status_code, 400)
        self.assertIn("password", response.json()["error"].lower())

    def test_the_env_password_is_used_when_the_form_leaves_it_blank(self):

        with mock.patch.dict(os.environ, {"OUTREACH_SMTP_PASSWORD": "from-env"}), \
             mock.patch.object(runner, "start_send", return_value=True) as start:
            response = self._post(password="")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(start.call_args[0][1], "from-env")

    def test_password_is_never_written_to_the_database(self):
        with mock.patch.object(runner, "start_send", return_value=True):
            self._post(password="super-secret")

        self.campaign.refresh_from_db()
        blob = " ".join(
            str(v) for v in Campaign.objects.filter(pk=self.campaign.pk).values()[0].values()
        )
        self.assertNotIn("super-secret", blob)

    def test_nothing_approved_is_a_400(self):
        EmailDraft.objects.filter(pk=self.draft.pk).update(
            status=EmailDraft.Status.GENERATED)

        response = self._post(password="pw")

        self.assertEqual(response.status_code, 400)
        self.assertIn("Approve at least one", response.json()["error"])

    def test_a_running_campaign_is_a_409(self):
        with mock.patch.object(runner, "is_running", return_value=True):
            response = self._post(password="pw")

        self.assertEqual(response.status_code, 409)
