"""
Lead classification, scoring, queues and the intelligence screens.

The tests that matter here are the ones about honesty, because that is what this
feature can most easily get wrong:

  * a site that could not be read is **unverified**, never "no website";
  * a signal that was not measured reads **Unknown**, never 0;
  * a finding with no evidence is never shown;
  * a good website is offered maintenance, not a redesign it does not need;
  * opening a lead page **never crawls** -- it would spend money on a page view.

Every score is also checked to be within 0-100 and to carry its factors, since a
score nobody can account for is a score nobody should act on.
"""

from __future__ import annotations

from unittest import mock

from django.test import override_settings
from django.urls import reverse

from apps.auditing import crawler, measurements, scoring
from apps.core.testing import EMAIL_BODY, OtherUser, SignedIn, default_user
from apps.outreach import selectors as pipeline
from apps.outreach.models import EmailDraft, Lifecycle, WebsiteAudit
from apps.outreach.services import intelligence

from .factories import make_campaign, make_draft

#: Signals as `measurements.measure()` produces them, for a site with real problems.
POOR = {
    "load_ms": 3200, "page_kb": 1900, "https": False, "external_scripts": 18,
    "viewport_meta": False, "title_length": 8, "meta_description_length": 0,
    "canonical": False, "og_tags": 0, "structured_data_blocks": 0,
    "html_lang": "MISSING", "h1_count": 0, "word_count": 150, "cta_count": 0,
    "forms": 0, "mailto_links": 0, "tel_links": 0, "images": 12,
    "images_missing_alt": 10, "trust_signal_mentions": 0, "social_links": 0,
    "vague_link_text": 6, "stylesheets": 3, "inline_style_blocks": 1,
    "fixed_width_attrs": 7,
}

GOOD = {
    "load_ms": 380, "page_kb": 420, "https": True, "external_scripts": 4,
    "viewport_meta": True, "viewport_content": "width=device-width, initial-scale=1",
    "title_length": 48, "meta_description_length": 140, "canonical": True,
    "og_tags": 6, "structured_data_blocks": 2, "html_lang": "en", "h1_count": 1,
    "word_count": 900, "cta_count": 6, "forms": 1, "form_fields_unlabelled": 0,
    "mailto_links": 1, "tel_links": 2, "map_embed": True, "images": 8,
    "images_missing_alt": 0, "images_modern_format": 6, "images_lazy_loaded": 8,
    "trust_signal_mentions": 5, "social_links": 3, "vague_link_text": 0,
    "stylesheets": 2, "inline_style_blocks": 0, "fixed_width_attrs": 0,
}

EVIDENCED = [
    {"issue": "No call to action", "evidence": "cta_count=0",
     "why_it_matters": "An interested visitor has nothing to click.",
     "suggested_improvement": "Add a booking button.", "severity": "high",
     "dimension": "calls to action"},
    {"issue": "Not set up for phones", "evidence": "viewport_meta absent",
     "why_it_matters": "Renders at desktop width.",
     "suggested_improvement": "Add a viewport tag.", "severity": "critical",
     "dimension": "mobile"},
]

UNEVIDENCED = [{"issue": "Looks dated", "evidence": "", "why_it_matters": "",
                "suggested_improvement": "", "severity": "medium"}]


class ClassificationTests(SignedIn):
    """Three outcomes, and the one that must never be confused with another."""

    def _classify(self, **kwargs):
        defaults = {"website": "https://x.test", "analysis_status": crawler.OK,
                    "pages_read": 4}
        defaults.update(kwargs)
        return scoring.classify(**defaults)

    def test_a_site_that_was_read_is_website_found(self):
        result, reason = self._classify()

        self.assertEqual(result, scoring.WEBSITE_FOUND)
        self.assertIn("read", reason)

    def test_no_listed_address_is_a_no_website_opportunity(self):
        result, _reason = self._classify(
            website="", analysis_status=crawler.NO_WEBSITE, pages_read=0)

        self.assertEqual(result, scoring.NO_WEBSITE_OPPORTUNITY)

    def test_a_blocked_site_is_unverified_never_no_website(self):
        """The distinction the brief is most emphatic about, and rightly."""
        result, reason = self._classify(
            analysis_status=crawler.BLOCKED, pages_read=0)

        self.assertEqual(result, scoring.WEBSITE_UNVERIFIED)
        self.assertNotEqual(result, scoring.NO_WEBSITE_OPPORTUNITY)
        self.assertIn("unknown", reason.lower())

    def test_a_failed_fetch_is_unverified_never_no_website(self):
        result, reason = self._classify(
            analysis_status=crawler.FAILED, pages_read=0)

        self.assertEqual(result, scoring.WEBSITE_UNVERIFIED)
        self.assertIn("unknown", reason.lower())

    def test_a_listed_address_that_resolves_to_nothing_is_unverified(self):
        """The listing says a site exists, so absence is not established."""
        result, _reason = self._classify(
            analysis_status=crawler.NO_WEBSITE, pages_read=0)

        self.assertEqual(result, scoring.WEBSITE_UNVERIFIED)

    def test_an_unanalysed_lead_is_unverified(self):
        result, reason = self._classify(analysis_status="", pages_read=0)

        self.assertEqual(result, scoring.WEBSITE_UNVERIFIED)
        self.assertIn("Not analysed", reason)

    def test_every_reason_is_recorded(self):
        for status in (crawler.OK, crawler.BLOCKED, crawler.FAILED,
                       crawler.NO_WEBSITE, ""):
            with self.subTest(status=status):
                _result, reason = self._classify(analysis_status=status,
                                                pages_read=0)
                self.assertTrue(reason)


class SubScoreTests(SignedIn):
    """Each sub-score reads only signals the crawler actually produces."""

    def test_a_poor_site_scores_low_across_the_board(self):
        assessment = scoring.assess_website(POOR)

        for key, label, _fn in scoring.SUB_SCORES:
            with self.subTest(area=label):
                self.assertTrue(assessment.sub_scores[key].measured)
                self.assertLess(assessment.sub_scores[key].value, 70)

    def test_a_good_site_scores_well(self):
        assessment = scoring.assess_website(GOOD)

        self.assertGreaterEqual(assessment.quality.value, 90)
        self.assertLessEqual(assessment.opportunity.value, 15)

    def test_nothing_measured_reads_unknown_not_zero(self):
        """0 and "not measured" are different answers and must look different."""
        assessment = scoring.assess_website({})

        for key, label, _fn in scoring.SUB_SCORES:
            with self.subTest(area=label):
                score = assessment.sub_scores[key]
                self.assertFalse(score.measured)
                self.assertEqual(score.display, "Unknown")
        self.assertFalse(assessment.quality.measured)

    def test_every_deduction_cites_its_evidence(self):
        assessment = scoring.assess_website(POOR)

        for key, label, _fn in scoring.SUB_SCORES:
            for factor in assessment.sub_scores[key].factors:
                with self.subTest(area=label, factor=factor.label):
                    self.assertTrue(factor.evidence,
                                    "a deduction with no evidence is a guess")

    def test_missing_https_dominates_the_technical_score(self):
        with_https = scoring.technical_score({**POOR, "https": True})
        without = scoring.technical_score({**POOR, "https": False})

        self.assertGreater(with_https.value, without.value + 40)

    def test_a_missing_viewport_dominates_the_mobile_score(self):
        self.assertLess(scoring.mobile_score({"viewport_meta": False}).value, 50)
        self.assertEqual(
            scoring.mobile_score({
                "viewport_meta": True,
                "viewport_content": "width=device-width, initial-scale=1"}).value,
            100)

    def test_scores_stay_inside_the_range(self):
        for signals in (POOR, GOOD, {}, {"load_ms": 99999, "page_kb": 99999}):
            assessment = scoring.assess_website(signals)
            for score in list(assessment.sub_scores.values()) + [
                    assessment.quality, assessment.opportunity]:
                self.assertGreaterEqual(score.value, 0)
                self.assertLessEqual(score.value, 100)

    def test_the_worst_page_decides_a_quality_signal(self):
        """Averaging would hide exactly the finding worth raising."""
        merged = scoring.merge_signals([{"load_ms": 300}, {"load_ms": 4200}])

        self.assertEqual(merged["load_ms"], 4200)

    def test_a_signal_missing_from_one_page_still_counts_against(self):
        merged = scoring.merge_signals([{"viewport_meta": True},
                                       {"viewport_meta": False}])

        self.assertFalse(merged["viewport_meta"])


class OpportunityTests(SignedIn):
    def test_evidenced_findings_raise_the_opportunity(self):
        from apps.ai.base import Finding

        bare = scoring.assess_website(POOR, [])
        with_findings = scoring.assess_website(
            POOR, [Finding.from_dict(f) for f in EVIDENCED])

        self.assertGreater(with_findings.opportunity.value,
                           bare.opportunity.value)

    def test_unevidenced_findings_do_not_raise_it(self):
        """A finding with no evidence is speculation and must not score."""
        from apps.ai.base import Finding

        bare = scoring.assess_website(POOR, [])
        with_junk = scoring.assess_website(
            POOR, [Finding.from_dict(f) for f in UNEVIDENCED])

        self.assertEqual(with_junk.opportunity.value, bare.opportunity.value)

    def test_business_value_uses_only_evidence_it_has(self):
        score = scoring.business_value(category="Restaurants",
                                      phone="+31 15 1", email="a@b.test",
                                      city="Delft", country="Netherlands")
        labels = " ".join(f.label for f in score.factors)

        self.assertIn("category", labels.lower())
        for invented in ("revenue", "employees", "traffic", "ranking"):
            self.assertNotIn(invented, labels.lower())

    def test_an_unknown_category_gets_a_neutral_baseline_not_a_guess(self):
        score = scoring.business_value(category="Interpretive Dance Studio")
        baseline = next(f for f in score.factors
                        if "not recognised" in f.label.lower())

        # The baseline itself is neutral. The final value is lower here only
        # because this lead publishes no contact details at all, which is a
        # separate, evidenced deduction.
        self.assertEqual(baseline.points, scoring.NEUTRAL_CATEGORY_VALUE)
        self.assertIn("neutral baseline", baseline.evidence.lower())

    def test_an_unverified_lead_cannot_outrank_an_assessed_one(self):
        value = scoring.business_value(category="Hotels & Guest Houses")
        assessed = scoring.overall_opportunity(
            classification=scoring.WEBSITE_FOUND,
            website_opportunity=scoring.assess_website(POOR).opportunity,
            missing_opportunity=scoring.Score(0, measured=False), value=value)
        unknown = scoring.overall_opportunity(
            classification=scoring.WEBSITE_UNVERIFIED,
            website_opportunity=scoring.Score(0, measured=False),
            missing_opportunity=scoring.Score(0, measured=False), value=value)

        self.assertLess(unknown.value, assessed.value)
        self.assertLessEqual(unknown.value, 55)

    def test_a_no_website_lead_is_an_opportunity_not_a_failure(self):
        score, benefits = scoring.missing_website_opportunity(
            category="Restaurants", phone="+31 15 1")

        self.assertGreater(score.value, 60)
        self.assertTrue(benefits)

    def test_benefits_are_category_specific_then_universal(self):
        score, benefits = scoring.missing_website_opportunity(
            category="Dentists")

        self.assertTrue(any("appointment" in b for b in benefits))

    def test_an_unknown_category_still_gets_universal_benefits(self):
        _score, benefits = scoring.missing_website_opportunity(category="")

        self.assertTrue(benefits)
        self.assertTrue(all(b in scoring.UNIVERSAL_BENEFITS for b in benefits))


class PriorityBandTests(SignedIn):
    def test_the_default_bands(self):
        for score, band in ((100, scoring.HOT), (80, scoring.HOT),
                            (79, scoring.WARM), (60, scoring.WARM),
                            (59, scoring.LOW), (40, scoring.LOW),
                            (39, scoring.SKIP), (0, scoring.SKIP)):
            with self.subTest(score=score):
                self.assertEqual(scoring.priority_band(score), band)

    @override_settings(OUTREACH_PRIORITY_HOT=90, OUTREACH_PRIORITY_WARM=70,
                       OUTREACH_PRIORITY_LOW=50)
    def test_the_bands_are_configurable(self):
        self.assertEqual(scoring.priority_band(85), scoring.WARM)
        self.assertEqual(scoring.priority_band(95), scoring.HOT)
        self.assertEqual(scoring.priority_band(55), scoring.LOW)


class RecommendedServiceTests(SignedIn):
    def test_a_good_site_is_offered_maintenance_not_a_rebuild(self):
        """Recommending work nobody needs is how outreach earns a reputation."""
        service, reason = scoring.recommend_service(
            classification=scoring.WEBSITE_FOUND,
            assessment=scoring.assess_website(GOOD), category="Restaurants")

        self.assertEqual(service, scoring.MAINTENANCE)
        self.assertIn("measures well", reason)

    def test_a_poor_site_is_offered_a_redesign(self):
        service, _reason = scoring.recommend_service(
            classification=scoring.WEBSITE_FOUND,
            assessment=scoring.assess_website(POOR), category="Restaurants")

        self.assertEqual(service, scoring.REDESIGN)

    def test_one_weak_area_is_offered_that_specific_fix(self):
        signals = {**GOOD, "viewport_meta": False, "fixed_width_attrs": 9}
        service, reason = scoring.recommend_service(
            classification=scoring.WEBSITE_FOUND,
            assessment=scoring.assess_website(signals), category="Restaurants")

        self.assertEqual(service, scoring.MOBILE)
        self.assertIn("mobile", reason)

    def test_no_website_is_offered_a_new_one(self):
        service, _reason = scoring.recommend_service(
            classification=scoring.NO_WEBSITE_OPPORTUNITY,
            assessment=scoring.assess_website({}), category="Restaurants")

        self.assertEqual(service, scoring.NEW_WEBSITE)

    def test_unverified_is_offered_nothing(self):
        service, reason = scoring.recommend_service(
            classification=scoring.WEBSITE_UNVERIFIED,
            assessment=scoring.assess_website({}))

        self.assertEqual(service, "")
        self.assertIn("could not be verified", reason)

    def test_every_recommendation_is_from_the_published_list(self):
        for signals in (POOR, GOOD, {**GOOD, "cta_count": 0, "forms": 0,
                                     "mailto_links": 0, "tel_links": 0}):
            service, _reason = scoring.recommend_service(
                classification=scoring.WEBSITE_FOUND,
                assessment=scoring.assess_website(signals))
            with self.subTest(service=service):
                self.assertIn(service, scoring.SERVICES)


class EmailReadinessTests(SignedIn):
    def test_no_address_means_zero(self):
        score = scoring.email_readiness(
            classification=scoring.NO_WEBSITE_OPPORTUNITY, email="")

        self.assertEqual(score.value, 0)

    def test_an_evidenced_website_lead_is_ready(self):
        from apps.ai.base import Finding

        score = scoring.email_readiness(
            classification=scoring.WEBSITE_FOUND, email="a@b.test",
            business_name="Bella", pages_read=5,
            findings=[Finding.from_dict(f) for f in EVIDENCED * 3],
            observation="no call to action", opportunity=80)

        self.assertTrue(scoring.is_ready(score.value))

    def test_an_unverified_lead_is_not_ready(self):
        """Writing about a site nobody could read risks claiming something untrue."""
        score = scoring.email_readiness(
            classification=scoring.WEBSITE_UNVERIFIED, email="a@b.test",
            business_name="Bella")

        self.assertFalse(scoring.is_ready(score.value))

    def test_a_no_website_lead_can_be_ready_without_an_audit(self):
        score = scoring.email_readiness(
            classification=scoring.NO_WEBSITE_OPPORTUNITY, email="a@b.test",
            business_name="Bella", benefits=["showing the menu"],
            opportunity=85)

        self.assertTrue(scoring.is_ready(score.value))


class ExplanationTests(SignedIn):
    def test_a_no_website_explanation_names_the_evidence(self):
        text = scoring.explain(
            classification=scoring.NO_WEBSITE_OPPORTUNITY,
            category="Restaurants", overall=85)

        self.assertIn("no verified website", text)
        self.assertIn("restaurants", text.lower())

    def test_an_unverified_explanation_claims_nothing(self):
        text = scoring.explain(classification=scoring.WEBSITE_UNVERIFIED)

        self.assertIn("unknown", text.lower())
        self.assertNotIn("high opportunity", text.lower())

    def test_a_website_explanation_names_the_weak_areas(self):
        text = scoring.explain(
            classification=scoring.WEBSITE_FOUND, category="Restaurants",
            assessment=scoring.assess_website(POOR), findings=[], overall=80)

        self.assertIn("/100", text)

    def test_a_good_site_is_described_as_little_to_fix(self):
        text = scoring.explain(
            classification=scoring.WEBSITE_FOUND,
            assessment=scoring.assess_website(GOOD), overall=30)

        self.assertIn("little to fix", text)


class ApplyTests(SignedIn):
    """intelligence.apply(): scoring one lead from what is already known."""

    def setUp(self):
        self.campaign = make_campaign()

    #: Bumped per lead so each gets its own domain and address -- one audit per
    #: (owner, domain) and one draft per (campaign, email) are both enforced by
    #: the database, and reusing a key would test the constraint rather than the
    #: scoring.
    counter = 0

    def _lead(self, **overrides):
        signals = overrides.pop("signals", None)
        findings = overrides.pop("findings", [])
        type(self).counter += 1
        host = f"lead{self.counter}.test"

        audit = None
        if signals is not None:
            assessment = scoring.assess_website(signals)
            audit = WebsiteAudit.objects.create(
                owner=default_user(), domain=host, url=f"https://{host}",
                status=overrides.get("analysis_status", crawler.OK),
                signals=signals,
                pages=[{"url": f"https://{host}", "kind": "home"}],
                pages_discovered=4, quality_score=assessment.quality.value,
                opportunity_score=assessment.opportunity.value,
                sub_scores={k: v.as_dict()
                            for k, v in assessment.sub_scores.items()},
                findings=findings)

        defaults = {
            "business_name": f"Lead {self.counter}",
            "email": f"hi@{host}",
            "website": f"https://{host}",
            "analysis_status": crawler.OK,
            "pages_read": [{"url": f"https://{host}", "kind": "home"}],
            "findings": findings, "audit": audit,
        }
        defaults.update(overrides)
        return intelligence.apply(make_draft(self.campaign, **defaults))

    def test_applying_never_crawls(self):
        with mock.patch.object(crawler, "analyse") as crawl:
            self._lead(signals=POOR)

        crawl.assert_not_called()

    def test_a_scored_lead_has_every_field_populated(self):
        lead = self._lead(signals=POOR, findings=EVIDENCED)

        self.assertEqual(lead.classification, scoring.WEBSITE_FOUND)
        self.assertTrue(lead.classification_reason)
        self.assertGreater(lead.score_overall, 0)
        self.assertGreater(lead.score_website, 0)
        self.assertGreater(lead.score_value, 0)
        self.assertTrue(lead.priority)
        self.assertTrue(lead.recommended_service)
        self.assertTrue(lead.why_prospect)
        self.assertIsNotNone(lead.scored_at)

    def test_the_score_detail_explains_every_number(self):
        lead = self._lead(signals=POOR, findings=EVIDENCED)

        for key in ("overall", "website", "quality", "value", "readiness"):
            with self.subTest(score=key):
                self.assertIn(key, lead.score_detail)
                self.assertIn("factors", lead.score_detail[key])
        self.assertIn("thresholds", lead.score_detail)

    def test_only_a_no_website_lead_gets_benefits(self):
        no_site = self._lead(website="", analysis_status=crawler.NO_WEBSITE,
                             pages_read=[])
        with_site = self._lead(signals=GOOD)

        self.assertTrue(no_site.benefits)
        self.assertEqual(with_site.benefits, [])

    def test_a_poor_site_outranks_a_good_one(self):
        poor = self._lead(signals=POOR, findings=EVIDENCED)
        good = self._lead(signals=GOOD)

        self.assertGreater(poor.score_overall, good.score_overall)

    def test_re_applying_is_stable(self):
        lead = self._lead(signals=POOR, findings=EVIDENCED)
        first = lead.score_overall
        intelligence.apply(lead)
        lead.refresh_from_db()

        self.assertEqual(lead.score_overall, first)


class LifecycleTests(SignedIn):
    def setUp(self):
        self.campaign = make_campaign()

    def test_the_lifecycle_follows_the_machinery(self):
        for status, expected in (
            (EmailDraft.Status.PENDING, Lifecycle.NEW),
            (EmailDraft.Status.CRAWLED, Lifecycle.ANALYZING),
            (EmailDraft.Status.APPROVED, Lifecycle.EMAIL_READY),
            (EmailDraft.Status.SENT, Lifecycle.CONTACTED),
            (EmailDraft.Status.REJECTED, Lifecycle.LOST),
            (EmailDraft.Status.SUPPRESSED, Lifecycle.DO_NOT_CONTACT),
        ):
            with self.subTest(status=status):
                draft = make_draft(self.campaign, status=status,
                                   email=f"{status}@x.test")
                self.assertEqual(draft.derive_lifecycle(), expected)

    def test_a_manual_stage_survives_re_scoring(self):
        """No amount of machinery can tell whether somebody is interested."""
        draft = intelligence.apply(make_draft(self.campaign))
        intelligence.set_lifecycle(draft, Lifecycle.MEETING, note="Thursday")

        intelligence.apply(draft)
        draft.refresh_from_db()

        self.assertEqual(draft.lifecycle, Lifecycle.MEETING)
        self.assertEqual(draft.lifecycle_note, "Thursday")

    def test_an_unknown_stage_is_refused(self):
        draft = make_draft(self.campaign)

        with self.assertRaises(ValueError):
            intelligence.set_lifecycle(draft, "ascended")

    def test_the_path_marks_done_current_and_waiting(self):
        draft = make_draft(self.campaign)
        intelligence.set_lifecycle(draft, Lifecycle.CONTACTED)
        states = {step["state"] for step in draft.lifecycle_steps}

        self.assertIn("done", states)
        self.assertIn("current", states)
        self.assertIn("waiting", states)

    def test_an_ended_lead_shows_one_step(self):
        draft = make_draft(self.campaign)
        intelligence.set_lifecycle(draft, Lifecycle.LOST)

        self.assertEqual(len(draft.lifecycle_steps), 1)
        self.assertEqual(draft.lifecycle_steps[0]["state"], "ended")


class QueueAndFilterTests(SignedIn):
    def setUp(self):
        self.campaign = make_campaign()
        self.found = intelligence.apply(make_draft(
            self.campaign, business_name="Found Co", email="a@found.test",
            website="https://found.test", analysis_status=crawler.OK,
            pages_read=[{"url": "https://found.test", "kind": "home"}],
            findings=EVIDENCED,
            audit=WebsiteAudit.objects.create(
                owner=default_user(), domain="found.test", signals=POOR,
                pages=[{"url": "https://found.test", "kind": "home"}],
                findings=EVIDENCED)))
        self.none = intelligence.apply(make_draft(
            self.campaign, business_name="None Co", email="a@none.test",
            website="", analysis_status=crawler.NO_WEBSITE, pages_read=[]))
        self.unverified = intelligence.apply(make_draft(
            self.campaign, business_name="Unver Co", email="a@unver.test",
            website="https://unver.test", analysis_status=crawler.BLOCKED,
            pages_read=[]))

    def test_the_website_filter_separates_the_three(self):
        self.assertEqual(
            pipeline.filtered(default_user(), website="found").count(), 1)
        self.assertEqual(
            pipeline.filtered(default_user(), website="none").count(), 1)
        self.assertEqual(
            pipeline.filtered(default_user(), website="unverified").count(), 1)

    def test_filters_combine(self):
        both = pipeline.filtered(default_user(), website="none",
                                country="Netherlands", category="Restaurant")
        neither = pipeline.filtered(default_user(), website="none",
                                   country="Germany")

        self.assertEqual(both.count(), 1)
        self.assertEqual(neither.count(), 0)

    def test_search_matches_name_email_website_and_city(self):
        for term in ("Found", "a@found", "found.test", "Delft"):
            with self.subTest(term=term):
                self.assertGreaterEqual(
                    pipeline.filtered(default_user(), search=term).count(), 1)

    def test_whatsapp_is_never_guessed(self):
        """No lead has WhatsApp evidence yet, so none may be claimed available."""
        self.assertEqual(
            pipeline.filtered(default_user(), whatsapp="available").count(), 0)
        self.assertEqual(
            pipeline.filtered(default_user(), whatsapp="unknown").count(), 3)

    def test_every_sort_orders_without_error(self):
        for key, _label in pipeline.SORTS:
            with self.subTest(sort=key):
                self.assertEqual(
                    len(list(pipeline.filtered(default_user(), sort=key))), 3)

    def test_the_score_sort_is_descending(self):
        scores = list(pipeline.filtered(default_user(), sort="score")
                      .values_list("score_overall", flat=True))

        self.assertEqual(scores, sorted(scores, reverse=True))

    def test_the_queues_cover_the_leads(self):
        counts = {q["key"]: q["count"] for q in pipeline.queues(default_user())}

        self.assertEqual(counts["no_website"], 1)
        self.assertEqual(counts["unverified"], 1)
        self.assertEqual(len(counts), 5)

    def test_the_summary_adds_up(self):
        summary = pipeline.summary(default_user())

        self.assertEqual(summary["total"], 3)
        self.assertEqual(summary["website_found"] + summary["no_website"]
                         + summary["unverified"], 3)
        self.assertEqual(summary["hot"] + summary["warm"] + summary["low"]
                         + summary["skip"], 3)

    def test_choices_come_from_the_data(self):
        choices = pipeline.choices(default_user())

        self.assertEqual(choices["countries"], ["Netherlands"])
        self.assertEqual(choices["categories"], ["Restaurant"])

    def test_another_account_sees_none_of_it(self):
        other = OtherUser()

        self.assertEqual(pipeline.base(other.user).count(), 0)
        self.assertEqual(pipeline.summary(other.user)["total"], 0)
        self.assertEqual(
            {q["count"] for q in pipeline.queues(other.user)}, {0})


class IntelligenceScreenTests(SignedIn):
    def setUp(self):
        self.campaign = make_campaign()
        self.audit = WebsiteAudit.objects.create(
            owner=default_user(), domain="x.test", url="https://x.test",
            status=crawler.OK, signals=POOR,
            pages=[{"url": "https://x.test", "kind": "home"}],
            pages_discovered=5, findings=EVIDENCED + UNEVIDENCED)
        self.lead = intelligence.apply(make_draft(
            self.campaign, website="https://x.test", analysis_status=crawler.OK,
            pages_read=[{"url": "https://x.test", "kind": "home"}],
            findings=EVIDENCED + UNEVIDENCED, audit=self.audit))

    def test_the_dashboard_renders_with_its_cards_and_queues(self):
        response = self.client.get(reverse("dashboard"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Total leads")
        self.assertContains(response, "No website")
        self.assertContains(response, "Unverified")
        self.assertContains(response, "Work queues")

    def test_the_table_renders_with_its_columns(self):
        response = self.client.get(reverse("outreach:leads"))

        self.assertEqual(response.status_code, 200)
        for column in ("Website status", "Overall", "Priority", "Main issue",
                       "Recommended", "WhatsApp"):
            with self.subTest(column=column):
                self.assertContains(response, column)

    def test_the_table_honours_a_filter_from_the_query_string(self):
        response = self.client.get(
            reverse("outreach:leads") + "?website=none")

        self.assertEqual(response.status_code, 200)
        self.assertNotContains(response, self.lead.business_name)

    def test_an_invalid_filter_value_falls_back_rather_than_erroring(self):
        response = self.client.get(
            reverse("outreach:leads") + "?website=nonsense&sort=nonsense")

        self.assertEqual(response.status_code, 200)

    def test_the_lead_page_shows_evidence_and_hides_speculation(self):
        response = self.client.get(
            reverse("outreach:lead_detail", args=[self.lead.pk]))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "cta_count=0")
        self.assertNotContains(response, "Looks dated")

    def test_the_lead_page_shows_how_a_score_was_reached(self):
        response = self.client.get(
            reverse("outreach:lead_detail", args=[self.lead.pk]))

        self.assertContains(response, "How the overall score")
        self.assertContains(response, "How business value")

    def test_opening_the_lead_page_never_crawls(self):
        """A page view must not spend a crawl and an AI call."""
        with mock.patch.object(crawler, "analyse") as crawl:
            self.client.get(reverse("outreach:lead_detail",
                                    args=[self.lead.pk]))

        crawl.assert_not_called()

    def test_reanalyse_refuses_get(self):
        response = self.client.get(
            reverse("outreach:lead_reanalyse", args=[self.lead.pk]))

        self.assertEqual(response.status_code, 405)

    def test_reanalyse_crawls_and_rescores(self):
        fresh = crawler.SiteAnalysis(
            crawler.OK, "Read 1 page(s).",
            [measurements.Page("https://x.test/", "home", "T", "", ["H"], "text",
                           GOOD)],
            discovered=4)

        with mock.patch.object(crawler, "analyse", return_value=fresh) as crawl, \
             mock.patch("apps.ai.audit", side_effect=Exception("no key")):
            response = self.client.post(
                reverse("outreach:lead_reanalyse", args=[self.lead.pk]))

        self.assertEqual(response.status_code, 200)
        crawl.assert_called_once()
        self.lead.refresh_from_db()
        self.assertLessEqual(self.lead.score_website, 20)

    def test_a_refresh_does_not_keep_findings_it_could_not_reproduce(self):
        """Evidence the fresh measurement contradicts must not survive."""
        fresh = crawler.SiteAnalysis(
            crawler.OK, "Read 1 page(s).",
            [measurements.Page("https://x.test/", "home", "T", "", ["H"], "text",
                           GOOD)],
            discovered=4)

        with mock.patch.object(crawler, "analyse", return_value=fresh), \
             mock.patch("apps.ai.audit", side_effect=Exception("no key")):
            body = self.client.post(
                reverse("outreach:lead_reanalyse",
                        args=[self.lead.pk])).json()

        self.lead.refresh_from_db()
        self.assertEqual(self.lead.findings, [])
        self.assertIn("no findings", body["message"])

    def test_a_failed_refresh_keeps_what_was_already_known(self):
        """"Could not reach it today" is no reason to erase last week's audit."""
        blocked = crawler.SiteAnalysis(crawler.BLOCKED, "Blocked by robots.txt.")

        with mock.patch.object(crawler, "analyse", return_value=blocked):
            self.client.post(
                reverse("outreach:lead_reanalyse", args=[self.lead.pk]))

        self.audit.refresh_from_db()
        self.assertEqual(self.audit.status, crawler.BLOCKED)
        self.assertTrue(self.audit.signals, "the previous signals were erased")
        self.assertTrue(self.audit.findings, "the previous findings were erased")

    def test_a_lead_with_no_website_cannot_be_reanalysed(self):
        lead = intelligence.apply(make_draft(
            self.campaign, business_name="No Site", email="b@x.test",
            website="", analysis_status=crawler.NO_WEBSITE, pages_read=[]))

        response = self.client.post(
            reverse("outreach:lead_reanalyse", args=[lead.pk]))

        self.assertEqual(response.status_code, 400)

    def test_the_lifecycle_endpoint_sets_a_stage(self):
        response = self.client.post(
            reverse("outreach:lead_lifecycle", args=[self.lead.pk]),
            data={"stage": Lifecycle.MEETING, "note": "Thursday"},
            content_type="application/json")

        self.assertEqual(response.status_code, 200)
        self.lead.refresh_from_db()
        self.assertEqual(self.lead.lifecycle, Lifecycle.MEETING)

    def test_the_lifecycle_endpoint_refuses_an_unknown_stage(self):
        response = self.client.post(
            reverse("outreach:lead_lifecycle", args=[self.lead.pk]),
            data={"stage": "ascended"}, content_type="application/json")

        self.assertEqual(response.status_code, 400)

    def test_rescoring_the_account_reports_a_count(self):
        response = self.client.post(reverse("outreach:rescore"))

        self.assertEqual(response.status_code, 200)
        self.assertIn("Re-scored", response.json()["message"])

    def test_another_account_cannot_reach_any_of_it(self):
        other = OtherUser()

        for name, args in (("lead_detail", [self.lead.pk]),
                           ("lead_reanalyse", [self.lead.pk]),
                           ("lead_lifecycle", [self.lead.pk])):
            with self.subTest(endpoint=name):
                url = reverse(f"outreach:{name}", args=args)
                got = (other.client.get(url) if name == "lead_detail"
                       else other.client.post(url, data={"stage": "won"},
                                              content_type="application/json"))
                self.assertEqual(got.status_code, 404)


class AuditCacheTests(SignedIn):
    def test_a_usable_cached_audit_is_reused_not_recrawled(self):
        WebsiteAudit.objects.create(
            owner=default_user(), domain="cached.test", status=crawler.OK,
            signals=GOOD, pages=[{"url": "https://cached.test", "kind": "home"}])

        with mock.patch.object(crawler, "analyse") as crawl:
            audit = intelligence.audit_website(
                default_user(), "https://cached.test")

        crawl.assert_not_called()
        self.assertEqual(audit.domain, "cached.test")

    def test_a_refresh_crawls_even_with_a_cache(self):
        WebsiteAudit.objects.create(
            owner=default_user(), domain="cached.test", status=crawler.OK,
            signals=GOOD, pages=[{"url": "https://cached.test", "kind": "home"}])
        fresh = crawler.SiteAnalysis(
            crawler.OK, "Read 1 page(s).",
            [measurements.Page("https://cached.test/", "home", "T", "", [], "t", POOR)],
            discovered=2)

        with mock.patch.object(crawler, "analyse", return_value=fresh) as crawl, \
             mock.patch("apps.ai.audit", side_effect=Exception("no key")):
            intelligence.audit_website(default_user(), "https://cached.test",
                                       refresh=True)

        crawl.assert_called_once()

    def test_the_cache_is_per_account(self):
        WebsiteAudit.objects.create(
            owner=default_user(), domain="shared.test", status=crawler.OK,
            signals=GOOD, pages=[{"url": "https://shared.test", "kind": "home"}])
        other = OtherUser()

        self.assertIsNotNone(
            intelligence.cached_audit(default_user(), "https://shared.test"))
        self.assertIsNone(
            intelligence.cached_audit(other.user, "https://shared.test"))

    def test_an_audit_reports_its_age_and_staleness(self):
        audit = WebsiteAudit.objects.create(
            owner=default_user(), domain="age.test", status=crawler.OK,
            signals=GOOD, pages=[{"url": "https://age.test", "kind": "home"}])

        self.assertEqual(audit.age_days, 0)
        self.assertFalse(audit.stale)

    @override_settings(OUTREACH_AUDIT_MAX_AGE_DAYS=0)
    def test_the_staleness_window_is_configurable(self):
        audit = WebsiteAudit.objects.create(
            owner=default_user(), domain="age.test", status=crawler.OK,
            signals=GOOD, pages=[{"url": "https://age.test", "kind": "home"}])

        self.assertTrue(audit.stale)


class NoWebsiteEmailTests(SignedIn):
    """Workflow B: an email that must not mention website problems."""

    def test_the_prompt_forbids_talking_about_a_website(self):
        from apps import ai

        prompt = ai.build_no_website_prompt(
            business_name="Bella", category="Restaurants", city="Delft",
            benefits=["showing the menu"])

        self.assertIn("NO VERIFIED WEBSITE", prompt)
        self.assertIn("do not speculate", prompt)

    def test_the_system_prompt_forbids_guaranteeing_outcomes(self):
        from apps import ai

        lowered = ai.NO_WEBSITE_SYSTEM.lower()
        self.assertIn("never guarantee an outcome", lowered)
        self.assertIn("conditional", lowered)

    def test_a_promised_outcome_is_refused(self):
        from apps import ai

        with self.assertRaises(ai.AiError):
            ai.parse_no_website(
                '{"subject": "An idea", "body": "We will increase your sales.",'
                ' "observation": "x", "benefits_used": []}')

    def test_conditional_language_is_accepted(self):
        from apps import ai

        parsed = ai.parse_no_website(
            '{"subject": "An idea for Bella", "body": "A site could make it '
            'easier to take bookings.", "observation": "a restaurant in Delft",'
            ' "benefits_used": ["taking table bookings"]}')

        self.assertTrue(parsed.body)
        self.assertEqual(parsed.findings_used, ["taking table bookings"])

    def test_the_runner_routes_a_no_website_lead_to_workflow_b(self):
        from apps import ai
        from apps.outreach.services import pipeline as runner

        campaign = make_campaign()
        draft = make_draft(campaign, website="", subject="", body="",
                           analysis_status=crawler.NO_WEBSITE, pages_read=[])
        intelligence.apply(draft)
        draft.refresh_from_db()

        email = ai.GeneratedEmail("An idea for Bella", EMAIL_BODY,
                                  "a restaurant in Delft", [])
        with mock.patch.object(ai, "no_website_email", return_value=email) as b, \
             mock.patch.object(ai, "generate") as a:
            runner.generate_draft(draft, campaign)

        b.assert_called_once()
        a.assert_not_called()

    def test_the_runner_routes_a_website_lead_to_workflow_a(self):
        from apps import ai
        from apps.outreach.services import pipeline as runner

        campaign = make_campaign()
        draft = make_draft(campaign, website="https://x.test", subject="",
                           body="", analysis_status=crawler.OK,
                           pages_read=[{"url": "https://x.test", "kind": "home"}])
        intelligence.apply(draft)
        draft.refresh_from_db()

        email = ai.GeneratedEmail("A quick idea", EMAIL_BODY, "no cta", [])
        with mock.patch.object(ai, "generate", return_value=email) as a, \
             mock.patch.object(ai, "no_website_email") as b:
            runner.generate_draft(draft, campaign)

        a.assert_called_once()
        b.assert_not_called()
