"""
Building a message, and opening the connection that carries it.

The composition tests are pure -- no socket, no settings -- which is the point of
`mail/compose.py` being separate from `mail/transport.py`. `SendBlockTests` is the one
that matters most: the suite must not be able to open a real SMTP connection, because
real credentials live in `.env` and the line between a failing test and mail leaving
the building should not be a mock somebody forgot.
"""

from __future__ import annotations

import smtplib
from unittest import mock

from django.conf import settings
from django.test import override_settings

from apps.core.testing import SignedIn
from apps.outreach.mail import compose, providers, transport
from apps.outreach.models import EmailDraft
from apps.outreach.services import pipeline as runner

from .factories import make_campaign, make_draft


class MessageTests(SignedIn):
    def test_from_header_is_the_authenticated_address(self):
        message = compose.build_message(
            sender_name="Sam Rivers", sender_email="sam@agency.test",
            to_email="ciao@bella.example", subject="Hello", body="Body text",
        )

        self.assertEqual(message["From"], "Sam Rivers <sam@agency.test>")
        self.assertEqual(message["To"], "ciao@bella.example")
        self.assertEqual(message["Subject"], "Hello")
        self.assertIn("mailto:sam@agency.test", message["List-Unsubscribe"])
        self.assertTrue(message.get_content().startswith("Body text"))

    # --- Auto-Submitted, which must not be set --------------------------- #
    #
    # RFC 3834's `auto-generated` is for messages an automaton produces in reply to
    # another -- vacation notices, bounces. A first contact addressed to a person, from
    # a mailbox that person can reply to, is not that. Some receivers read the header as
    # "do not reply" and some filters weigh it as a bulk signal, so it was costing
    # deliverability and buying nothing: nothing in this project reads it.

    def test_a_normal_email_is_not_marked_auto_generated(self):
        message = compose.build_message(
            sender_name="Sam Rivers", sender_email="sam@agency.test",
            to_email="ciao@bella.example", subject="Hello", body="Body text",
        )

        self.assertIsNone(message["Auto-Submitted"])
        # The serialised form too, and case-insensitively: a header re-added as
        # `auto-submitted` would still reach the recipient.
        self.assertNotIn("auto-submitted", str(message).lower())
        self.assertNotIn("auto-generated", str(message).lower())

    def test_a_follow_up_in_a_thread_is_not_marked_auto_generated(self):
        """The shape most likely to be mistaken for an automated reply."""
        message = compose.build_message(
            sender_name="Sam Rivers", sender_email="sam@agency.test",
            to_email="ciao@bella.example", subject="Re: Hello",
            body="Just following up.",
            in_reply_to="<first@agency.test>",
            references="<first@agency.test>",
        )

        self.assertIsNone(message["Auto-Submitted"])
        self.assertNotIn("auto-submitted", str(message).lower())
        # Threading is untouched by the removal.
        self.assertEqual(message["In-Reply-To"], "<first@agency.test>")
        self.assertEqual(message["References"], "<first@agency.test>")

    def test_an_email_with_a_reply_to_is_not_marked_auto_generated(self):
        message = compose.build_message(
            sender_name="Sam Rivers", sender_email="sam@agency.test",
            to_email="ciao@bella.example", subject="Hello", body="Body text",
            reply_to="replies@agency.test",
        )

        self.assertIsNone(message["Auto-Submitted"])
        self.assertNotIn("auto-submitted", str(message).lower())
        self.assertEqual(message["Reply-To"], "replies@agency.test")

    def test_the_headers_that_should_still_be_there_are(self):
        """Removing one header must not have removed a neighbour.

        `List-Unsubscribe` in particular: it was set on the line above the one that was
        deleted, and it is the header that gives a recipient a way out.
        """
        message = compose.build_message(
            sender_name="Sam Rivers", sender_email="sam@agency.test",
            to_email="ciao@bella.example", subject="Hello", body="Body text",
        )

        for header in ("From", "To", "Subject", "Date", "Message-ID",
                       "List-Unsubscribe"):
            self.assertIsNotNone(message[header], f"{header} is missing")
        self.assertIn("mailto:sam@agency.test", message["List-Unsubscribe"])
        self.assertTrue(message["Message-ID"].endswith("agency.test>"))
class BodyTests(SignedIn):
    """The body reaches the recipient exactly as it was written and approved.

    Nothing is appended to it. A standing reply invitation used to be added here --
    "If you're interested, simply reply to this email and our team will get back to you
    within 24 hours." -- and it was removed, so these tests are the guard against it, or
    anything like it, coming back. What a person approves on screen is what goes out.
    """

    def _build(self, body):
        return compose.build_message(
            sender_name="Sam Rivers", sender_email="sam@agency.test",
            to_email="ciao@bella.example", subject="Hello", body=body,
        ).get_content()

    def test_the_body_is_delivered_unchanged(self):
        body = "Hi there,\n\nShort note.\n\nSam"

        # `set_content` normalises the trailing newline; nothing else is touched.
        self.assertEqual(self._build(body).rstrip("\n"), body)

    def test_nothing_is_appended_after_the_sign_off(self):
        content = self._build("Hi there,\n\nShort note.\n\nSam")

        self.assertTrue(content.rstrip().endswith("Sam"))

    def test_the_old_reply_invitation_is_not_added(self):
        """Named in full, so a re-introduction fails here rather than in an inbox."""
        content = self._build("A hand-written note with no call to action at all.")

        self.assertNotIn("simply reply to this email", content)
        self.assertNotIn("get back to you within 24 hours", content)
        self.assertNotIn("our team", content)

    def test_a_follow_up_body_is_delivered_unchanged_too(self):
        content = compose.build_message(
            sender_name="Sam Rivers", sender_email="sam@agency.test",
            to_email="ciao@bella.example", subject="Re: Hello",
            body="Just following up.",
            in_reply_to="<first@agency.test>",
        ).get_content()

        self.assertEqual(content.rstrip("\n"), "Just following up.")
        self.assertNotIn("simply reply to this email", content)

    def test_an_empty_body_stays_empty(self):
        """No invitation to fall back on, so an empty body is empty."""
        self.assertEqual(self._build("").strip(), "")

    def test_a_signature_is_still_appended_when_one_is_set(self):
        """The signature is a different thing, and the removal did not touch it."""
        signed = compose.with_signature("Short note.\n\nSam", "Northline Ltd")

        self.assertTrue(signed.endswith("Northline Ltd"))
        self.assertEqual(compose.with_signature("Short note.", ""), "Short note.")


class PasswordNormalisationTests(SignedIn):
    """Gmail shows app passwords spaced but expects them bare."""

    def test_a_spaced_gmail_app_password_is_de_spaced(self):
        self.assertEqual(
            providers.normalise_password("abcd efgh ijkl mnop"), "abcdefghijklmnop")

    def test_an_already_bare_app_password_is_unchanged(self):
        self.assertEqual(
            providers.normalise_password("abcdefghijklmnop"), "abcdefghijklmnop")

    def test_surrounding_whitespace_is_trimmed(self):
        self.assertEqual(providers.normalise_password("  secret  "), "secret")

    def test_a_normal_password_containing_a_space_is_left_alone(self):
        # Only the exact 4x4 app-password shape is de-spaced, so a real
        # passphrase keeps its spaces.
        self.assertEqual(
            providers.normalise_password("correct horse battery staple"),
            "correct horse battery staple",
        )

    def test_case_is_preserved(self):
        self.assertEqual(
            providers.normalise_password("ABCD efgh IJKL mnop"), "ABCDefghIJKLmnop")

    def test_the_session_normalises_what_it_is_given(self):
        session = transport.Session(
            providers.PROVIDERS["gmail"], "sam@agency.test", "abcd efgh ijkl mnop")

        self.assertEqual(session.password, "abcdefghijklmnop")

    def test_empty_stays_empty_and_is_refused(self):
        self.assertEqual(providers.normalise_password("   "), "")
        with self.assertRaises(transport.SendError):
            transport.Session(providers.PROVIDERS["gmail"], "sam@agency.test", "  ")
class SessionTests(SignedIn):
    def test_sender_address_must_match_the_login(self):
        with self.assertRaises(transport.SendError) as caught:
            transport.Session(
                providers.PROVIDERS["gmail"], "boss@bigcorp.test", "pw",
                username="sam@agency.test",
            )

        self.assertIn("spoofing", str(caught.exception))

    def test_matching_address_and_login_is_accepted(self):
        session = transport.Session(
            providers.PROVIDERS["gmail"], "Sam@Agency.test", "pw",
            username="sam@agency.test",
        )

        self.assertEqual(session.host, "smtp.gmail.com")
        self.assertEqual(session.port, 587)

    def test_missing_password_is_refused(self):
        with self.assertRaises(transport.SendError):
            transport.Session(providers.PROVIDERS["gmail"], "sam@agency.test", "")

    def test_custom_provider_needs_a_host(self):
        with self.assertRaises(transport.SendError):
            transport.Session(providers.PROVIDERS["custom"], "sam@agency.test", "pw")

    def test_custom_provider_accepts_an_explicit_host(self):
        session = transport.Session(
            providers.PROVIDERS["custom"], "sam@agency.test", "pw",
            host="mail.agency.test", port=465,
        )

        self.assertEqual((session.host, session.port), ("mail.agency.test", 465))

    def test_every_provider_has_a_delay_and_a_cap(self):
        for key, provider in providers.PROVIDERS.items():
            with self.subTest(provider=key):
                self.assertGreater(provider.delay, 0)
                self.assertGreater(provider.daily_cap, 0)
class SendBlockTests(SignedIn):
    """The suite must not be able to open a real SMTP connection."""

    def test_sending_is_blocked_while_running_tests(self):
        self.assertTrue(
            settings.OUTREACH_BLOCK_SEND,
            "OUTREACH_BLOCK_SEND must be on under `manage.py test` -- real "
            "credentials live in .env and a stray send would mail live people.",
        )

    def test_entering_a_session_refuses_to_connect(self):
        session = transport.Session(
            providers.PROVIDERS["gmail"], "sam@agency.test", "app-password")

        with self.assertRaises(transport.SendError) as caught:
            with session:
                pass

        self.assertIn("blocked", str(caught.exception).lower())

    def test_a_real_send_run_reports_the_block_instead_of_sending(self):
        campaign = make_campaign()
        make_draft(campaign, status=EmailDraft.Status.APPROVED)

        with mock.patch.object(runner.time, "sleep"):
            runner._send_all(campaign, "app-password", "", 0)

        campaign.refresh_from_db()
        self.assertEqual(campaign.counts()["sent"], 0)
        self.assertIn("blocked", campaign.error.lower())
        # The draft is untouched and still sendable for real later.
        self.assertEqual(campaign.counts()["approved"], 1)

    @override_settings(OUTREACH_BLOCK_SEND=False)
    def test_the_block_can_be_lifted_for_real_use(self):
        session = transport.Session(
            providers.PROVIDERS["custom"], "sam@agency.test", "pw",
            host="127.0.0.1", port=1,
        )

        # Not blocked any more, so it gets as far as a connection attempt --
        # which fails, because nothing is listening on that port.
        with self.assertRaises(transport.SendError) as caught:
            with session:
                pass

        self.assertIn("Could not connect", str(caught.exception))
