"""
One account cannot reach another account's data.

Frontend route guards are not the subject here. Every test below is signed in as
a *valid* second user and then asks for the first user's campaign, draft, lead,
follow-up or suppression by id. A URL parameter is the easiest thing in the world
to change, so each of those has to be refused by the query itself rather than by
anything the browser was told.

404 rather than 403 throughout, deliberately: "forbidden" would confirm that an
object with that id exists and belongs to somebody else.
"""

from __future__ import annotations

from unittest import mock

from django.urls import reverse

from apps.ai import credentials
from apps.core.testing import OtherUser, SignedIn, default_user
from apps.outreach.mail import followups
from apps.outreach.models import (
    Campaign,
    EmailDraft,
    FollowUp,
    ReplyState,
    SentLead,
    Suppression,
)
from apps.outreach.services import history
from apps.outreach.services import pipeline as runner

from .factories import make_campaign, make_draft
from .test_followups import make_lead


class CampaignIsolationTests(SignedIn):
    """Campaign-scoped pages and endpoints."""

    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(self.campaign)
        self.other = OtherUser()

    def test_the_campaign_list_shows_only_my_campaigns(self):
        mine = self.client.get(reverse("outreach:history"))
        theirs = self.other.client.get(reverse("outreach:history"))

        self.assertContains(mine, self.campaign.label)
        self.assertNotContains(theirs, "Restaurants · Delft")

    def test_another_user_cannot_open_my_setup_page(self):
        response = self.other.client.get(
            reverse("outreach:setup", args=[self.campaign.id]))

        self.assertEqual(response.status_code, 404)

    def test_another_user_cannot_open_my_workspace(self):
        response = self.other.client.get(
            reverse("outreach:workspace", args=[self.campaign.id]))

        self.assertEqual(response.status_code, 404)

    def test_another_user_cannot_read_my_campaign_state(self):
        """The JSON endpoint carries every draft, so this one matters most."""
        response = self.other.client.get(
            reverse("outreach:state", args=[self.campaign.id]))

        self.assertEqual(response.status_code, 404)

    def test_another_user_cannot_read_my_report(self):
        response = self.other.client.get(
            reverse("outreach:report", args=[self.campaign.id]))

        self.assertEqual(response.status_code, 404)

    def test_another_user_cannot_start_my_campaign(self):
        with mock.patch.object(runner, "start_pipeline") as start:
            response = self.other.client.post(
                reverse("outreach:run", args=[self.campaign.id]),
                data={"sender_name": "Intruder",
                      "sender_email": "intruder@elsewhere.test",
                      "provider": "gmail",
                      "service_pitch": "Nothing to see here at all.",
                      "selected": [self.draft.pk]},
                content_type="application/json")

        self.assertEqual(response.status_code, 404)
        start.assert_not_called()

    def test_another_user_cannot_send_my_campaign(self):
        response = self.other.client.post(
            reverse("outreach:send", args=[self.campaign.id]),
            data={"password": "abcd efgh ijkl mnop"},
            content_type="application/json")

        self.assertEqual(response.status_code, 404)

    def test_another_user_cannot_approve_all_my_drafts(self):
        response = self.other.client.post(
            reverse("outreach:approve_all", args=[self.campaign.id]))

        self.assertEqual(response.status_code, 404)

    def test_another_user_cannot_resume_my_campaign(self):
        response = self.other.client.post(
            reverse("outreach:resume", args=[self.campaign.id]))

        self.assertEqual(response.status_code, 404)

    def test_i_can_still_open_my_own_campaign(self):
        """The other half of the test: scoping must not break the owner."""
        response = self.client.get(
            reverse("outreach:workspace", args=[self.campaign.id]))

        self.assertEqual(response.status_code, 200)


class DraftIsolationTests(SignedIn):
    """Per-draft actions, which take a bare integer id."""

    ACTIONS = ("save", "regenerate", "rereview", "approve", "reject",
               "recontact", "suppress")

    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(self.campaign)
        self.other = OtherUser()

    def test_no_draft_action_works_across_accounts(self):
        for action in self.ACTIONS:
            with self.subTest(action=action):
                response = self.other.client.post(
                    reverse("outreach:draft_action", args=[self.draft.pk, action]),
                    data={"subject": "Hijacked", "body": "Hijacked",
                          "reason": "because I felt like it"},
                    content_type="application/json")
                self.assertEqual(response.status_code, 404)

        self.draft.refresh_from_db()
        self.assertNotEqual(self.draft.subject, "Hijacked")
        self.assertEqual(self.draft.status, EmailDraft.Status.GENERATED)

    def test_an_approve_by_another_account_does_not_change_the_draft(self):
        self.other.client.post(
            reverse("outreach:draft_action", args=[self.draft.pk, "approve"]))

        self.draft.refresh_from_db()
        self.assertEqual(self.draft.status, EmailDraft.Status.GENERATED)

    def test_i_can_still_act_on_my_own_draft(self):
        response = self.client.post(
            reverse("outreach:draft_action", args=[self.draft.pk, "approve"]))

        self.assertEqual(response.status_code, 200)
        self.draft.refresh_from_db()
        self.assertEqual(self.draft.status, EmailDraft.Status.APPROVED)


class HistoryIsolationTests(SignedIn):
    """Sending history, suppression and the Excel export."""

    def setUp(self):
        self.lead = make_lead(days_ago=5)
        self.other = OtherUser()

    def test_my_history_does_not_block_another_users_outreach(self):
        """Per-user history is the point: their prospects are not mine."""
        theirs = history.Index(self.other.user)

        self.assertIsNone(theirs.match(email=self.lead.email))
        self.assertIsNotNone(
            history.Index(default_user()).match(email=self.lead.email))

    def test_my_suppression_list_does_not_block_another_user(self):
        history.suppress(default_user(), email="blocked@example.test")

        self.assertIsNotNone(history.SuppressionIndex(default_user())
                             .match(email="blocked@example.test"))
        self.assertIsNone(history.SuppressionIndex(self.other.user)
                          .match(email="blocked@example.test"))

    def test_the_suppression_screen_shows_only_my_entries(self):
        history.suppress(default_user(), email="mine@example.test")

        mine = self.client.get(reverse("outreach:suppressions"))
        theirs = self.other.client.get(reverse("outreach:suppressions"))

        self.assertContains(mine, "mine@example.test")
        self.assertNotContains(theirs, "mine@example.test")

    def test_another_user_cannot_remove_my_suppression(self):
        row, _created = history.suppress(default_user(),
                                         email="mine@example.test")

        response = self.other.client.post(
            reverse("outreach:suppress_remove", args=[row.pk]))

        self.assertEqual(response.status_code, 404)
        self.assertTrue(Suppression.objects.filter(pk=row.pk).exists())

    def test_two_users_may_each_suppress_the_same_address(self):
        history.suppress(default_user(), email="shared@example.test")
        history.suppress(self.other.user, email="shared@example.test")

        self.assertEqual(
            Suppression.objects.filter(email="shared@example.test").count(), 2)

    def test_two_users_may_each_contact_the_same_business(self):
        """The duplicate guard asks "have *I* emailed them", not "has anyone"."""
        theirs = SentLead.objects.create(
            owner=self.other.user, business_name=self.lead.business_name,
            email=self.lead.email, status=SentLead.Status.SENT)

        self.assertNotEqual(theirs.pk, self.lead.pk)
        self.assertEqual(
            SentLead.objects.filter(email=self.lead.email).count(), 2)

    def test_the_excel_export_is_per_account(self):
        self.assertNotEqual(history.excel_path(default_user()),
                            history.excel_path(self.other.user))

    def test_the_history_stats_count_only_my_rows(self):
        SentLead.objects.create(owner=self.other.user, business_name="Theirs",
                                email="theirs@example.test",
                                status=SentLead.Status.SENT)

        self.assertEqual(history.stats(default_user())["sent"], 1)
        self.assertEqual(history.stats(self.other.user)["sent"], 1)


class FollowUpIsolationTests(SignedIn):
    def setUp(self):
        self.lead = make_lead(days_ago=5)
        self.followup = FollowUp.objects.create(
            owner=default_user(), lead=self.lead, number=1,
            email=self.lead.email, subject="Re: idea", body="Following up.")
        self.other = OtherUser()

    def test_the_followup_screen_shows_only_my_leads(self):
        mine = self.client.get(reverse("outreach:followups"))
        theirs = self.other.client.get(reverse("outreach:followups"))

        self.assertContains(mine, self.lead.business_name)
        self.assertNotContains(theirs, self.lead.business_name)

    def test_another_user_cannot_create_a_followup_for_my_lead(self):
        response = self.other.client.post(
            reverse("outreach:followup_create", args=[self.lead.pk]))

        self.assertEqual(response.status_code, 404)

    def test_another_user_cannot_act_on_my_followup(self):
        for action in ("save", "regenerate", "cancel", "send"):
            with self.subTest(action=action):
                response = self.other.client.post(
                    reverse("outreach:followup_action",
                            args=[self.followup.pk, action]),
                    data={"subject": "Hijacked", "body": "Hijacked",
                          "password": "abcd efgh ijkl mnop"},
                    content_type="application/json")
                self.assertEqual(response.status_code, 404)

        self.followup.refresh_from_db()
        self.assertEqual(self.followup.status, FollowUp.Status.DRAFT)
        self.assertEqual(self.followup.subject, "Re: idea")

    def test_the_followup_rows_are_scoped(self):
        self.assertEqual(len(followups.rows(default_user())), 1)
        self.assertEqual(followups.rows(self.other.user), [])

    def test_the_followup_stats_are_scoped(self):
        self.assertEqual(followups.stats(default_user())["sent"], 1)
        self.assertEqual(followups.stats(self.other.user)["sent"], 0)

    def test_an_inbox_check_only_matches_my_own_sends(self):
        """A reply in my mailbox cannot be attributed to another user's lead."""
        from apps.outreach.mail import inbox

        theirs = inbox.Matcher(self.other.user)
        mine = inbox.Matcher(default_user())

        self.assertEqual(len(theirs.by_address), 0)
        self.assertGreater(len(mine.by_address), 0)


class SearchIsolationTests(SignedIn):
    """The lead search annotates against the searcher's own history."""

    def setUp(self):
        self.lead = make_lead(days_ago=1)
        self.other = OtherUser()

    def test_a_business_i_contacted_is_flagged_for_me_only(self):
        leads = [{"business_name": self.lead.business_name,
                  "email": self.lead.email, "website": self.lead.website,
                  "city": self.lead.city}]
        theirs = [dict(leads[0])]

        history.annotate_leads(leads, default_user())
        history.annotate_leads(theirs, self.other.user)

        self.assertEqual(leads[0]["contact_state"], "contacted")
        self.assertEqual(theirs[0]["contact_state"], "new")


class DashboardTests(SignedIn):
    def setUp(self):
        self.campaign = make_campaign()
        make_draft(self.campaign)
        self.other = OtherUser()

    def test_the_dashboard_reports_only_my_leads(self):
        mine = self.client.get(reverse("dashboard"))
        theirs = self.other.client.get(reverse("dashboard"))

        self.assertEqual(mine.status_code, 200)
        self.assertContains(mine, self.campaign.label)
        self.assertNotContains(theirs, self.campaign.label)
        # An account with no leads sees the empty state, not somebody else's
        # figures. The dashboard counts leads now, so that is what it says.
        self.assertContains(theirs, "No leads yet")

    def test_the_dashboard_names_the_signed_in_account(self):
        response = self.client.get(reverse("dashboard"))

        self.assertContains(response, self.user.email)

    def test_the_dashboard_is_protected(self):
        from django.test import Client

        response = Client().get(reverse("dashboard"))

        self.assertEqual(response.status_code, 302)


class CredentialScopeTests(SignedIn):
    """AI credentials belong to the account that added them.

    They used to be shared application configuration, and a test here asserted
    that -- with a comment saying it should be the first thing to fail if they
    ever became per-user. It was. What replaces it is the opposite guarantee:
    a key is one account's, and no URL, id or session belonging to another
    account can read, use or remove it.

    The deep coverage lives in `test_credentials.py`; these are the boundary
    checks that belong with the rest of the authorization suite.
    """

    def test_a_credential_has_an_owner(self):
        from apps.ai.models import ProviderCredential

        row = credentials.add(self.user, "groq", "gsk_shared_key_1234")

        self.assertEqual(ProviderCredential.objects.count(), 1)
        self.assertEqual(row.owner, self.user)

    def test_one_account_cannot_reach_anothers_credential(self):
        from apps.ai.models import ProviderCredential

        row = credentials.add(self.user, "groq", "gsk_mine_1234")
        other = OtherUser()

        for name in ("credential_activate", "credential_deactivate",
                     "credential_test", "credential_fallback",
                     "credential_delete"):
            with self.subTest(endpoint=name):
                response = other.client.post(
                    reverse(f"ai:{name}", args=[row.pk]),
                    data={}, content_type="application/json")
                # 404, not 403: 403 would confirm the credential exists.
                self.assertEqual(response.status_code, 404)

        self.assertTrue(ProviderCredential.objects.filter(pk=row.pk).exists())

    def test_one_accounts_key_is_never_resolved_for_another(self):
        credentials.add(self.user, "groq", "gsk_mine_1234")
        other = OtherUser()

        # Asserted against the key rather than usability: the developer running
        # this may well have GROQ_API_KEY in their own environment, and falling
        # back to *that* is correct. Reaching into another account's row is not.
        resolved = credentials.resolve("groq", other.user)
        self.assertNotEqual(resolved.key, "gsk_mine_1234")
        self.assertNotEqual(resolved.source, credentials.DATABASE)
        self.assertFalse(credentials.children("groq", other.user).exists())

    def test_a_signed_out_visitor_cannot_reach_the_credential_endpoints(self):
        from django.test import Client

        row = credentials.add(self.user, "groq", "gsk_mine_1234")
        anonymous = Client()

        checks = [("credential_add", "groq"),
                  ("credential_activate", row.pk),
                  ("credential_deactivate", row.pk),
                  ("credential_test", row.pk),
                  ("credential_fallback", row.pk),
                  ("credential_delete", row.pk)]
        for name, arg in checks:
            with self.subTest(endpoint=name):
                response = anonymous.post(
                    reverse(f"ai:{name}", args=[arg]),
                    data={"api_key": "gsk_intruder"},
                    content_type="application/json")
                self.assertEqual(response.status_code, 302)
                self.assertIn(reverse("login"), response["Location"])

    def test_a_signed_out_visitor_cannot_read_the_credential_history(self):
        from django.test import Client

        response = Client().get(reverse("ai:credential_events"))

        self.assertEqual(response.status_code, 302)
        self.assertIn(reverse("login"), response["Location"])
