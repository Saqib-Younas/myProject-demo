"""
Email accounts: the workspace's sending addresses.

The rules worth testing are the ones where an account must NOT send:

  * inactive — including an account switched off *after* a campaign was set up,
    which is the case a UI check alone would miss;
  * unconfigured, or configured with a password that cannot be decrypted;
  * over its daily limit, or over the provider's, whichever is lower;
  * belonging to another workspace;
  * failing its last connection test.

And the one that must never happen: a password reaching a browser, a log, an error
message or a template.

Nothing here opens a socket. `OUTREACH_BLOCK_SEND` is on under `manage.py test`,
and the connection test refuses to run because of it — which is itself tested.
"""

from __future__ import annotations

from unittest import mock

from django.test import Client
from django.urls import reverse
from django.utils import timezone

from apps.core.testing import OtherUser, SignedIn
from apps.outreach.mail import accounts as mailaccounts
from apps.outreach.mail import compose, providers, transport
from apps.outreach.models import Campaign, EmailAccount, EmailDraft, SentLead
from apps.outreach.services import pipeline as runner

from .factories import make_campaign, make_draft

PASSWORD = "abcd efgh ijkl mnop"


class AccountFactory(SignedIn):
    """Shared factory. Every test in this module needs an account or three."""

    def account(self, name="Sales", email="sales@company.test", *,
                owner=None, password=PASSWORD, **fields) -> EmailAccount:
        return mailaccounts.save_account(
            owner or self.user,
            name=name, sender_name="Sam Rivers", sender_email=email,
            provider="gmail", password=password, **fields)


class SavingTests(AccountFactory):
    def test_an_account_is_created_with_an_encrypted_password(self):
        account = self.account()

        self.assertTrue(account.secret)
        self.assertNotIn("abcd", account.secret)
        self.assertNotIn("mnop", account.secret)

    def test_only_a_masked_hint_is_kept_in_readable_form(self):
        account = self.account()

        self.assertTrue(account.hint)
        self.assertNotIn("abcd", account.hint)
        self.assertTrue(account.hint.endswith("mnop"))

    def test_the_password_round_trips_for_the_server(self):
        """Gmail app passwords are shown with spaces and used without them."""
        account = self.account()

        self.assertEqual(mailaccounts.password_of(account), "abcdefghijklmnop")

    def test_the_string_form_cannot_leak_the_password(self):
        account = self.account()

        self.assertNotIn("abcd", str(account))
        self.assertIn("sales@company.test", str(account))

    def test_an_account_belongs_to_the_workspace_that_made_it(self):
        self.assertEqual(self.account().owner, self.user)

    def test_a_login_that_differs_from_the_sender_is_refused(self):
        """The anti-spoofing rule, at save time as well as at send time."""
        with self.assertRaises(mailaccounts.AccountError) as caught:
            self.account(username="someone.else@company.test")

        self.assertIn("spoofing", str(caught.exception))

    def test_an_unknown_provider_is_refused(self):
        with self.assertRaises(mailaccounts.AccountError):
            mailaccounts.save_account(
                self.user, name="X", sender_name="S",
                sender_email="x@company.test", provider="pigeon",
                password=PASSWORD)

    def test_a_missing_name_or_address_is_refused(self):
        for field in ("name", "sender_email"):
            with self.subTest(field=field):
                kwargs = {"name": "X", "sender_name": "S",
                          "sender_email": "x@company.test",
                          "provider": "gmail", "password": PASSWORD}
                kwargs[field] = "  "
                with self.assertRaises(mailaccounts.AccountError):
                    mailaccounts.save_account(self.user, **kwargs)

    def test_an_empty_password_on_an_update_keeps_the_stored_one(self):
        """The form cannot show it, so empty means unchanged, not cleared."""
        account = self.account()
        before = account.secret

        mailaccounts.save_account(
            self.user, account=account, name="Sales renamed",
            sender_name="Sam Rivers", sender_email="sales@company.test",
            provider="gmail", password="")

        account.refresh_from_db()
        self.assertEqual(account.secret, before)
        self.assertEqual(account.name, "Sales renamed")

    def test_a_new_password_invalidates_the_previous_verdict(self):
        account = self.account()
        EmailAccount.objects.filter(pk=account.pk).update(
            connection_status=EmailAccount.Connection.OK,
            connection_detail="Connected successfully.")

        account.refresh_from_db()
        mailaccounts.save_account(
            self.user, account=account, name=account.name,
            sender_name=account.sender_name, sender_email=account.sender_email,
            provider="gmail", password="qrst uvwx yzab cdef")

        account.refresh_from_db()
        self.assertEqual(account.connection_status,
                         EmailAccount.Connection.UNTESTED)

    def test_forgetting_the_password_keeps_the_account(self):
        account = self.account()

        mailaccounts.clear_secret(self.user, account)

        account.refresh_from_db()
        self.assertEqual(account.secret, "")
        self.assertEqual(account.hint, "")
        self.assertFalse(account.configured)
        self.assertTrue(EmailAccount.objects.filter(pk=account.pk).exists())

    def test_a_rotated_secret_key_makes_the_password_unreadable_not_fatal(self):
        from django.test import override_settings

        account = self.account()

        with override_settings(SECRET_KEY="a-totally-different-secret"):
            self.assertEqual(mailaccounts.password_of(account), "")


class ParentChildTests(AccountFactory):
    """One workspace, several addresses. Several may be active at once."""

    def test_a_workspace_can_hold_several_accounts(self):
        self.account("Sales", "sales@company.test")
        self.account("Marketing", "marketing@company.test")
        self.account("Outreach", "outreach@company.test")

        self.assertEqual(mailaccounts.accounts(self.user).count(), 3)
        self.assertEqual(mailaccounts.active(self.user).count(), 3)

    def test_two_accounts_cannot_share_an_address_in_one_workspace(self):
        from django.db import IntegrityError, transaction

        self.account("Sales", "sales@company.test")

        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                self.account("Sales again", "sales@company.test")

    def test_two_workspaces_can_use_the_same_address(self):
        """The constraint is per workspace, not global."""
        self.account("Sales", "sales@company.test")
        other = OtherUser()

        self.account("Sales", "sales@company.test", owner=other.user)

        self.assertEqual(
            EmailAccount.objects.filter(
                sender_email="sales@company.test").count(), 2)

    def test_an_account_is_invisible_to_another_workspace(self):
        self.account()
        other = OtherUser()

        self.assertEqual(mailaccounts.accounts(other.user).count(), 0)

    def test_no_workspace_means_no_accounts(self):
        self.assertEqual(mailaccounts.accounts(None).count(), 0)

    def test_deactivating_is_not_deleting(self):
        account = self.account()

        mailaccounts.set_active(self.user, account, False)

        account.refresh_from_db()
        self.assertFalse(account.is_active)
        self.assertFalse(account.sendable)
        self.assertTrue(account.configured)          # the credential survives
        self.assertEqual(account.status, "inactive")

    def test_another_workspace_cannot_switch_an_account_off(self):
        account = self.account()
        stranger = OtherUser()

        with self.assertRaises(mailaccounts.AccountError):
            mailaccounts.set_active(stranger.user, account, False)

        account.refresh_from_db()
        self.assertTrue(account.is_active)


class SendabilityTests(AccountFactory):
    """The six gates from section 4, each checked on its own."""

    def test_an_active_configured_account_may_send(self):
        self.assertTrue(self.account().sendable)

    def test_an_inactive_account_may_not(self):
        account = self.account(is_active=False)

        self.assertFalse(account.sendable)

    def test_an_account_with_no_password_may_not(self):
        account = self.account(password="")

        self.assertFalse(account.configured)
        self.assertFalse(account.sendable)
        self.assertEqual(account.status, "unconfigured")

    def test_an_account_whose_last_test_failed_may_not(self):
        """A failed test is evidence. An untested one is not."""
        account = self.account()
        account.connection_status = EmailAccount.Connection.FAILED
        account.save(update_fields=["connection_status"])

        self.assertFalse(account.sendable)
        self.assertEqual(account.status, "failing")

    def test_an_untested_account_may_still_send(self):
        """Otherwise Test Connection becomes a requirement, not a diagnostic."""
        account = self.account()

        self.assertEqual(account.connection_status,
                         EmailAccount.Connection.UNTESTED)
        self.assertTrue(account.sendable)


class DailyLimitTests(AccountFactory):
    def test_the_provider_cap_applies_by_default(self):
        account = self.account()

        self.assertEqual(mailaccounts.daily_cap(account),
                         providers.PROVIDERS["gmail"].daily_cap)

    def test_a_lower_account_limit_is_honoured(self):
        account = self.account(daily_limit=25)

        self.assertEqual(mailaccounts.daily_cap(account), 25)

    def test_an_account_limit_cannot_exceed_the_providers(self):
        """The provider's cap is not ours to raise."""
        account = self.account(daily_limit=99999)

        self.assertEqual(mailaccounts.daily_cap(account),
                         providers.PROVIDERS["gmail"].daily_cap)

    def test_todays_sends_are_counted_from_the_history(self):
        account = self.account(daily_limit=3)
        for index in range(2):
            SentLead.objects.create(
                owner=self.user, email=f"lead{index}@example.test",
                sender_email=account.sender_email,
                status=SentLead.Status.SENT, reserved_at=timezone.now(),
                business_name="X", subject="S")

        self.assertEqual(mailaccounts.sent_today(account), 2)
        self.assertEqual(mailaccounts.remaining_today(account), 1)

    def test_yesterdays_sends_do_not_count(self):
        from datetime import timedelta

        account = self.account(daily_limit=3)
        old = SentLead.objects.create(
            owner=self.user, email="old@example.test",
            sender_email=account.sender_email, status=SentLead.Status.SENT,
            business_name="X", subject="S")
        # `reserved_at` is auto_now_add, so it has to be moved after creation.
        SentLead.objects.filter(pk=old.pk).update(
            reserved_at=timezone.now() - timedelta(days=1))

        self.assertEqual(mailaccounts.sent_today(account), 0)

    def test_another_workspaces_sends_do_not_count(self):
        account = self.account(daily_limit=3)
        other = OtherUser()
        SentLead.objects.create(
            owner=other.user, email="theirs@example.test",
            sender_email=account.sender_email, status=SentLead.Status.SENT,
            reserved_at=timezone.now(), business_name="X", subject="S")

        self.assertEqual(mailaccounts.sent_today(account), 0)


class ConnectionTestTests(AccountFactory):
    def test_the_test_is_refused_where_outbound_is_blocked(self):
        """The same switch that blocks sending and inbox reading."""
        account = self.account()

        status, message = mailaccounts.test_connection(self.user, account)

        self.assertEqual(status, EmailAccount.Connection.BLOCKED)
        self.assertIn("OUTREACH_BLOCK_SEND", message)

    def test_the_verdict_is_stored(self):
        account = self.account()

        mailaccounts.test_connection(self.user, account)

        account.refresh_from_db()
        self.assertEqual(account.connection_status,
                         EmailAccount.Connection.BLOCKED)
        self.assertIsNotNone(account.last_tested_at)

    def test_an_account_with_no_password_fails_without_connecting(self):
        from django.test import override_settings

        account = self.account(password="")

        with override_settings(OUTREACH_BLOCK_SEND=False):
            status, message = mailaccounts.test_connection(self.user, account)

        self.assertEqual(status, EmailAccount.Connection.FAILED)
        self.assertIn("No password is stored", message)

    def test_a_rejected_login_is_reported_without_the_password(self):
        from django.test import override_settings

        account = self.account()

        with override_settings(OUTREACH_BLOCK_SEND=False), \
             mock.patch.object(transport.Session, "__enter__",
                               side_effect=transport.SendError(
                                   "Gmail rejected the login for "
                                   "sales@company.test.")):
            status, message = mailaccounts.test_connection(self.user, account)

        self.assertEqual(status, EmailAccount.Connection.FAILED)
        self.assertIn("rejected the login", message)
        self.assertNotIn("abcd", message)

    def test_an_unexpected_library_error_is_not_leaked(self):
        from django.test import override_settings

        account = self.account()

        with override_settings(OUTREACH_BLOCK_SEND=False), \
             mock.patch.object(transport.Session, "__enter__",
                               side_effect=RuntimeError(
                                   "ssl handshake failed: abcd efgh")):
            status, message = mailaccounts.test_connection(self.user, account)

        self.assertEqual(status, EmailAccount.Connection.FAILED)
        self.assertNotIn("abcd", message)
        self.assertIn("unexpected reason", message)

    def test_another_workspace_cannot_test_an_account(self):
        account = self.account()
        stranger = OtherUser()

        with self.assertRaises(mailaccounts.AccountError):
            mailaccounts.test_connection(stranger.user, account)


class StatusShapeTests(AccountFactory):
    """`account_status()` is the only shape a browser receives."""

    def test_it_never_contains_the_password(self):
        account = self.account()
        status = mailaccounts.account_status(account)

        self.assertNotIn("abcd", repr(status))
        self.assertNotIn("abcdefghijklmnop", repr(status))
        self.assertTrue(status["masked"].endswith("mnop"))

    def test_it_carries_what_the_screen_needs(self):
        account = self.account(daily_limit=40)
        status = mailaccounts.account_status(account)

        self.assertEqual(status["name"], "Sales")
        self.assertEqual(status["provider_label"],
                         providers.PROVIDERS["gmail"].label)
        self.assertEqual(status["daily_cap"], 40)
        self.assertEqual(status["remaining_today"], 40)
        self.assertTrue(status["sendable"])

    def test_the_summary_counts_capacity(self):
        self.account("Sales", "sales@company.test", daily_limit=10)
        self.account("Marketing", "marketing@company.test", daily_limit=5)
        self.account("Old", "old@company.test", daily_limit=99,
                     is_active=False)

        summary = mailaccounts.summary(self.user)

        self.assertEqual(summary["total"], 3)
        self.assertEqual(summary["active"], 2)
        self.assertEqual(summary["usable"], 2)
        self.assertEqual(summary["capacity"], 15)


class CampaignSelectionTests(AccountFactory):
    def setUp(self):
        super().setUp()
        self.campaign = make_campaign()
        self.sales = self.account("Sales", "sales@company.test")
        self.marketing = self.account("Marketing", "marketing@company.test")

    def test_a_campaign_with_no_selection_uses_the_deployment_sender(self):
        """Every campaign made before accounts existed keeps working."""
        self.assertEqual(mailaccounts.for_campaign(self.campaign), [])

        account, provider, email, _name, _login = runner._sending_identity(
            self.campaign)

        self.assertIsNone(account)
        self.assertEqual(email, self.campaign.sender_email)

    def test_a_selected_account_is_used(self):
        self.campaign.sending_accounts.set([self.sales])

        account, _provider, email, name, login = runner._sending_identity(
            self.campaign)

        self.assertEqual(account, self.sales)
        self.assertEqual(email, "sales@company.test")
        self.assertEqual(name, "Sam Rivers")
        self.assertEqual(login, "sales@company.test")

    def test_an_account_switched_off_after_setup_cannot_send(self):
        """The case a UI check alone would miss."""
        self.campaign.sending_accounts.set([self.sales])
        mailaccounts.set_active(self.user, self.sales, False)

        self.assertEqual(mailaccounts.sending_accounts(self.campaign), [])

    def test_the_send_refuses_rather_than_substituting_an_account(self):
        """Never silently send from an address the user did not choose."""
        self.campaign.sending_accounts.set([self.sales])
        mailaccounts.set_active(self.user, self.sales, False)

        with self.assertRaises(mailaccounts.NoSendingAccount) as caught:
            runner._sending_identity(self.campaign)

        self.assertIn("inactive", str(caught.exception))
        self.assertIn("Nothing was sent", str(caught.exception))

    def test_the_remaining_active_account_is_used(self):
        self.campaign.sending_accounts.set([self.sales, self.marketing])
        mailaccounts.set_active(self.user, self.sales, False)

        account, _provider, email, _name, _login = runner._sending_identity(
            self.campaign)

        self.assertEqual(account, self.marketing)
        self.assertEqual(email, "marketing@company.test")

    def test_an_account_over_its_limit_drops_out(self):
        self.campaign.sending_accounts.set([self.sales])
        EmailAccount.objects.filter(pk=self.sales.pk).update(daily_limit=1)
        SentLead.objects.create(
            owner=self.user, email="lead@example.test",
            sender_email="sales@company.test", status=SentLead.Status.SENT,
            reserved_at=timezone.now(), business_name="X", subject="S")

        self.assertEqual(mailaccounts.sending_accounts(self.campaign), [])

    def test_the_report_explains_why_nothing_can_send(self):
        self.campaign.sending_accounts.set([self.sales, self.marketing])
        mailaccounts.set_active(self.user, self.sales, False)
        mailaccounts.clear_secret(self.user, self.marketing)

        report = mailaccounts.selection_report(self.campaign)

        self.assertEqual(report["selected"], 2)
        self.assertEqual(report["usable"], 0)
        reasons = {row["reason"] for row in report["rows"]}
        self.assertIn("inactive", reasons)
        self.assertIn("no credential saved", reasons)


class EndpointTests(AccountFactory):
    def _post(self, route, *args, **payload):
        """`route` rather than `name`: the payload has a `name` key of its own."""
        return self.client.post(
            reverse(f"outreach:{route}", args=args),
            data=payload, content_type="application/json")

    def test_saving_an_account_returns_no_password(self):
        response = self._post(
            "account_save", name="Sales", sender_name="Sam",
            sender_email="sales@company.test", provider="gmail",
            password=PASSWORD)

        self.assertEqual(response.status_code, 200)
        body = response.content.decode()
        self.assertNotIn("abcd", body)
        self.assertNotIn("abcdefghijklmnop", body)

    def test_saving_returns_the_masked_hint(self):
        response = self._post(
            "account_save", name="Sales", sender_name="Sam",
            sender_email="sales@company.test", provider="gmail",
            password=PASSWORD)

        self.assertTrue(response.json()["account"]["masked"].endswith("mnop"))

    def test_a_duplicate_address_is_a_conflict(self):
        self.account("Sales", "sales@company.test")

        response = self._post(
            "account_save", name="Second", sender_name="Sam",
            sender_email="sales@company.test", provider="gmail",
            password=PASSWORD)

        self.assertEqual(response.status_code, 409)

    def test_switching_an_account_off_warns_about_running_campaigns(self):
        account = self.account()
        campaign = make_campaign(phase=Campaign.Phase.SENDING)
        campaign.sending_accounts.set([account])

        response = self._post("account_active", account.pk, enabled=False)

        self.assertIn("no further emails", response.json()["message"])

    def test_an_account_with_history_cannot_be_deleted(self):
        account = self.account()
        SentLead.objects.create(
            owner=self.user, email="lead@example.test",
            sender_email=account.sender_email, status=SentLead.Status.SENT,
            reserved_at=timezone.now(), business_name="X", subject="S")

        response = self._post("account_delete", account.pk)

        self.assertEqual(response.status_code, 409)
        self.assertIn("orphan that history", response.json()["error"])
        self.assertTrue(EmailAccount.objects.filter(pk=account.pk).exists())

    def test_an_unused_account_can_be_deleted(self):
        account = self.account()

        response = self._post("account_delete", account.pk)

        self.assertEqual(response.status_code, 200)
        self.assertFalse(EmailAccount.objects.filter(pk=account.pk).exists())

    def test_another_workspaces_account_is_not_found(self):
        account = self.account()
        other = OtherUser()

        for name in ("account_active", "account_test", "account_forget",
                     "account_delete"):
            with self.subTest(endpoint=name):
                response = other.client.post(
                    reverse(f"outreach:{name}", args=[account.pk]),
                    data={}, content_type="application/json")
                self.assertEqual(response.status_code, 404)

    def test_the_endpoints_require_a_session(self):
        account = self.account()

        response = Client().post(
            reverse("outreach:account_test", args=[account.pk]))

        self.assertEqual(response.status_code, 302)
        self.assertIn(reverse("login"), response["Location"])

    def test_the_endpoints_refuse_get(self):
        account = self.account()

        for name, args in (("account_save", []),
                           ("account_active", [account.pk]),
                           ("account_test", [account.pk]),
                           ("account_forget", [account.pk]),
                           ("account_delete", [account.pk])):
            with self.subTest(endpoint=name):
                response = self.client.get(
                    reverse(f"outreach:{name}", args=args))
                self.assertEqual(response.status_code, 405)

    def test_choosing_accounts_for_a_campaign(self):
        campaign = make_campaign()
        sales = self.account("Sales", "sales@company.test", daily_limit=10)

        response = self._post("campaign_accounts", campaign.id,
                              accounts=[sales.pk])

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["usable"], 1)
        self.assertEqual(response.json()["capacity"], 10)
        self.assertEqual(list(campaign.sending_accounts.all()), [sales])

    def test_choosing_an_account_from_another_workspace_selects_nothing(self):
        campaign = make_campaign()
        other = OtherUser()
        theirs = self.account("Theirs", "theirs@company.test",
                              owner=other.user)

        self._post("campaign_accounts", campaign.id, accounts=[theirs.pk])

        self.assertEqual(list(campaign.sending_accounts.all()), [])

    def test_the_settings_page_never_shows_a_password(self):
        self.account()

        response = self.client.get(reverse("outreach:settings"))
        body = response.content.decode()

        self.assertNotIn("abcd", body)
        self.assertNotIn("abcdefghijklmnop", body)


class SignatureTests(SignedIn):
    def test_a_signature_is_appended_once(self):
        body = "Hello,\n\nSam"
        signed = compose.with_signature(body, "Sam Rivers\nNorthline")

        self.assertTrue(signed.endswith("Sam Rivers\nNorthline"))
        self.assertEqual(compose.with_signature(signed, "Sam Rivers\nNorthline"),
                         signed)

    def test_no_signature_leaves_the_body_alone(self):
        self.assertEqual(compose.with_signature("Hello", ""), "Hello")
        self.assertEqual(compose.with_signature("Hello", "   "), "Hello")

    def test_a_signature_already_in_the_body_is_not_repeated(self):
        body = "Hello,\n\nSam Rivers\nNorthline"

        self.assertEqual(compose.with_signature(body, "Sam Rivers\nNorthline"),
                         body.rstrip())


class SendPathTests(AccountFactory):
    """The send has to refuse rather than improvise."""

    def setUp(self):
        super().setUp()
        self.campaign = make_campaign(phase=Campaign.Phase.REVIEW)
        make_draft(self.campaign, status=EmailDraft.Status.APPROVED)

    def test_a_campaign_whose_accounts_are_all_off_sends_nothing(self):
        account = self.account()
        self.campaign.sending_accounts.set([account])
        mailaccounts.set_active(self.user, account, False)

        runner._send_all(self.campaign, "", "", 0)

        self.campaign.refresh_from_db()
        self.assertEqual(self.campaign.phase, Campaign.Phase.DONE)
        self.assertIn("can send", self.campaign.error)
        self.assertEqual(
            SentLead.objects.filter(status=SentLead.Status.SENT).count(), 0)

    def test_a_selected_account_with_no_password_sends_nothing(self):
        account = self.account(password="")
        self.campaign.sending_accounts.set([account])

        runner._send_all(self.campaign, "", "", 0)

        self.campaign.refresh_from_db()
        self.assertIn("can send", self.campaign.error)


class EditTests(AccountFactory):
    """Settings -> Sending addresses -> Edit.

    The form is the same one that adds an address; an `id` in the payload is what turns a
    create into an update. So the things worth testing are the two that could go wrong
    quietly: that the form is filled from the *stored* values rather than the displayed
    ones, and that leaving the password blank keeps the stored password instead of
    clearing it.
    """

    def _get(self, route, *args):
        return self.client.get(reverse(f"outreach:{route}", args=args))

    def _post(self, route, *args, **payload):
        return self.client.post(
            reverse(f"outreach:{route}", args=args),
            data=payload, content_type="application/json")

    # --- loading the form ------------------------------------------------- #

    def test_the_edit_endpoint_returns_every_editable_field(self):
        account = self.account(
            "Sales", "sales@company.test",
            reply_to="replies@company.test", signature="Sam Rivers, Northline",
            smtp_host="mail.company.test", smtp_port=587,
            imap_host="imap.company.test", imap_port=993,
            daily_limit=120, followup_max=3, followup_delays="2,5,9")

        payload = self._get("account_edit", account.pk).json()["account"]

        self.assertEqual(payload["id"], account.pk)
        self.assertEqual(payload["name"], "Sales")
        self.assertEqual(payload["sender_name"], "Sam Rivers")
        self.assertEqual(payload["sender_email"], "sales@company.test")
        self.assertEqual(payload["reply_to"], "replies@company.test")
        self.assertEqual(payload["signature"], "Sam Rivers, Northline")
        self.assertEqual(payload["provider"], "gmail")
        self.assertEqual(payload["smtp_host"], "mail.company.test")
        self.assertEqual(payload["smtp_port"], 587)
        self.assertEqual(payload["imap_host"], "imap.company.test")
        self.assertEqual(payload["imap_port"], 993)
        self.assertEqual(payload["daily_limit"], 120)
        self.assertEqual(payload["followup_max"], 3)
        self.assertEqual(payload["followup_delays"], "2,5,9")
        self.assertTrue(payload["is_active"])

    def test_the_edit_endpoint_never_returns_a_password(self):
        """The reason an empty password field can only mean unchanged."""
        account = self.account("Sales", "sales@company.test")

        response = self._get("account_edit", account.pk)
        payload = response.json()["account"]

        self.assertNotIn("abcd", response.content.decode())
        self.assertNotIn("abcdefghijklmnop", response.content.decode())
        self.assertNotIn("password", payload)
        self.assertNotIn("secret", payload)
        # Only the fact that one exists, and a hint.
        self.assertTrue(payload["configured"])
        self.assertTrue(payload["masked"].endswith("mnop"))

    def test_it_reports_when_no_password_is_stored(self):
        """So the form can demand one rather than offering to keep nothing."""
        account = self.account("Sales", "sales@company.test", password="")

        payload = self._get("account_edit", account.pk).json()["account"]

        self.assertFalse(payload["configured"])
        self.assertEqual(payload["masked"], "")

    def test_the_stored_daily_limit_is_returned_not_the_effective_cap(self):
        """A blank limit means use the provider preset.

        `account_status` reports the effective cap, which for a blank limit is the
        provider's own number. Filling an editable field with that would turn "use the
        default" into a hard number the next time the form was saved.
        """
        account = self.account("Sales", "sales@company.test")   # no daily_limit

        payload = self._get("account_edit", account.pk).json()["account"]

        self.assertEqual(payload["daily_limit"], "")
        self.assertEqual(mailaccounts.daily_cap(account),
                         providers.PROVIDERS["gmail"].daily_cap)

    def test_another_workspace_cannot_load_an_address(self):
        other = OtherUser()
        account = self.account("Theirs", "theirs@company.test", owner=other.user)

        self.assertEqual(self._get("account_edit", account.pk).status_code, 404)

    def test_the_edit_endpoint_refuses_a_post(self):
        account = self.account("Sales", "sales@company.test")

        self.assertEqual(self._post("account_edit", account.pk).status_code, 405)

    # --- saving an update ------------------------------------------------- #

    def test_an_update_changes_the_fields_and_makes_no_second_account(self):
        account = self.account("Sales", "sales@company.test")

        response = self._post(
            "account_save", id=account.pk, name="Sales (EU)",
            sender_name="Samantha Rivers", sender_email="sales@company.test",
            provider="gmail", password="",
            reply_to="eu@company.test", signature="Sam, EU",
            daily_limit=90, followup_max=1, followup_delays="4,11")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(EmailAccount.objects.filter(owner=self.user).count(), 1)

        account.refresh_from_db()
        self.assertEqual(account.name, "Sales (EU)")
        self.assertEqual(account.sender_name, "Samantha Rivers")
        self.assertEqual(account.reply_to, "eu@company.test")
        self.assertEqual(account.signature, "Sam, EU")
        self.assertEqual(account.daily_limit, 90)
        self.assertEqual(account.followup_max, 1)
        self.assertEqual(account.followup_delays, "4,11")

    def test_an_empty_password_on_an_update_keeps_the_stored_one(self):
        """The rule the whole form design rests on."""
        account = self.account("Sales", "sales@company.test")
        before = account.secret
        self.assertTrue(before)

        self._post("account_save", id=account.pk, name="Sales",
                   sender_name="Sam Rivers", sender_email="sales@company.test",
                   provider="gmail", password="")

        account.refresh_from_db()
        self.assertEqual(account.secret, before)
        self.assertTrue(account.configured)
        self.assertTrue(account.hint.endswith("mnop"))

    def test_a_new_password_on_an_update_replaces_the_stored_one(self):
        account = self.account("Sales", "sales@company.test")
        before = account.secret

        self._post("account_save", id=account.pk, name="Sales",
                   sender_name="Sam Rivers", sender_email="sales@company.test",
                   provider="gmail", password="zzzz yyyy xxxx wwww")

        account.refresh_from_db()
        self.assertNotEqual(account.secret, before)
        self.assertTrue(account.configured)
        self.assertTrue(account.hint.endswith("wwww"))
        # Still encrypted at rest, and the spaces a provider shows are stripped.
        self.assertNotIn("zzzz", account.secret)
        self.assertEqual(mailaccounts.decrypt(account.secret), "zzzzyyyyxxxxwwww")

    def test_updating_returns_no_password(self):
        account = self.account("Sales", "sales@company.test")

        response = self._post(
            "account_save", id=account.pk, name="Sales",
            sender_name="Sam Rivers", sender_email="sales@company.test",
            provider="gmail", password="zzzz yyyy xxxx wwww")

        body = response.content.decode()
        self.assertNotIn("zzzz", body)
        self.assertNotIn("zzzzyyyyxxxxwwww", body)

    def test_another_workspace_cannot_update_an_address(self):
        other = OtherUser()
        account = self.account("Theirs", "theirs@company.test", owner=other.user)

        response = self._post(
            "account_save", id=account.pk, name="Hijacked",
            sender_name="Sam", sender_email="theirs@company.test",
            provider="gmail", password="")

        self.assertEqual(response.status_code, 404)
        account.refresh_from_db()
        self.assertEqual(account.name, "Theirs")

    def test_an_update_cannot_set_a_login_that_differs_from_the_sender(self):
        """The anti-spoofing rule holds on an update, not only on a create."""
        account = self.account("Sales", "sales@company.test")

        response = self._post(
            "account_save", id=account.pk, name="Sales",
            sender_name="Sam Rivers", sender_email="sales@company.test",
            provider="gmail", password="", username="someone@else.test")

        self.assertEqual(response.status_code, 400)
        self.assertIn("spoofing", response.json()["error"])

    def test_an_update_keeps_the_sent_history(self):
        """Editing an address is not replacing it."""
        account = self.account("Sales", "sales@company.test")
        campaign = make_campaign()
        SentLead.objects.create(
            owner=self.user, business_name="Bella", email="ciao@bella.example",
            campaign=campaign, sender_account=account,
            sender_email=account.sender_email, status=SentLead.Status.SENT)

        self._post("account_save", id=account.pk, name="Renamed",
                   sender_name="Sam Rivers", sender_email="sales@company.test",
                   provider="gmail", password="")

        account.refresh_from_db()
        self.assertEqual(account.name, "Renamed")
        self.assertEqual(SentLead.objects.filter(sender_account=account).count(), 1)

    def test_an_active_address_stays_active_across_an_update(self):
        """The case in the request: editing the address that is currently sending."""
        account = self.account("Sales", "sales@company.test")
        self.assertTrue(account.is_active)

        self._post("account_save", id=account.pk, name="Sales",
                   sender_name="Sam Rivers", sender_email="sales@company.test",
                   provider="gmail", password="", is_active=True)

        account.refresh_from_db()
        self.assertTrue(account.is_active)
        self.assertTrue(account.sendable)


class EditFormMarkupTests(AccountFactory):
    """The page has to offer the button and the fields the JavaScript drives."""

    def page(self) -> str:
        return self.client.get(reverse("outreach:settings")).content.decode()

    def test_each_card_offers_an_edit_button(self):
        self.account("Sales", "sales@company.test")

        self.assertIn("mailbox-edit", self.page())

    def test_the_form_carries_a_hidden_id_and_the_edit_chrome(self):
        body = self.page()

        for needed in ('id="mb-id"', 'id="mailbox-cancel"',
                       'id="mailbox-edit-note"', 'id="mailbox-form-title"',
                       'id="mailbox-password-kept"', 'id="mailbox-password-mask"'):
            self.assertIn(needed, body, f"the form is missing {needed}")

    def test_the_form_has_an_input_for_every_editable_field(self):
        body = self.page()

        for name in ("name", "sender_name", "sender_email", "reply_to", "signature",
                     "provider", "password", "smtp_host", "smtp_port", "imap_host",
                     "imap_port", "daily_limit", "followup_max", "followup_delays",
                     "is_active"):
            self.assertIn(f'name="{name}"', body, f"no input for {name}")

    def test_the_page_carries_the_edit_route_for_the_javascript(self):
        self.assertIn("data-edit-url", self.page())

    def test_the_page_never_renders_a_stored_password(self):
        self.account("Sales", "sales@company.test")
        body = self.page()

        self.assertNotIn("abcd", body)
        self.assertNotIn("abcdefghijklmnop", body)
        # The password input is always empty, on a page that has an account with one.
        field = body.split('id="mb-password"', 1)[1].split(">", 1)[0]
        self.assertNotIn("value=", field)
