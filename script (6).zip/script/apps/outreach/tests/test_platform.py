"""
The technology stack, and the restraint the brief asks for around it.

§3 exists because the reflex answer to "this is WordPress" is "rebuild it in
Next.js", and a crawl almost never supports that. A crawl can establish what a site
is built on, and it can measure that pages are slow or that nothing adapts to a
phone. It cannot establish that the platform is the cause, and "newer" is not a
finding.

So the default verdict is KEEP, the email says nothing about technology unless
something was measured, and a fix that recommends a rebuild is withheld from the
client email unless several measured problems support it. Tested here because a
recommendation nobody can defend is an invented finding wearing a suit.
"""

from __future__ import annotations

from unittest import mock

from bs4 import BeautifulSoup
from django.test import TestCase

from apps import ai
from apps.ai.base import Finding, GeneratedEmail
from apps.auditing import crawler, measurements, scoring
from apps.core.testing import EMAIL_BODY, SignedIn
from apps.outreach.models import EmailDraft
from apps.outreach.services import pipeline as runner

from .factories import make_campaign, make_draft


def measure(html: str) -> dict:
    fetched = crawler.Fetched(html=html, load_ms=900, size=2048,
                              final_url="https://bella.example/")
    return measurements.measure(BeautifulSoup(html, "html.parser"), html, fetched)


def page(*fragments: str) -> str:
    return "<html><head></head><body>" + "".join(fragments) + "</body></html>"


class StackDetectionTests(TestCase):
    """Only markers actually present in the markup."""

    def test_the_platforms_a_small_business_actually_uses(self):
        cases = [
            ('<script src="/wp-content/themes/x/a.js"></script>', "WordPress"),
            ('<script src="https://cdn.shopify.com/s/a.js"></script>', "Shopify"),
            ('<img src="https://static.wixstatic.com/a.png">', "Wix"),
            ('<div class="sqs-block"></div>', "Squarespace"),
            ('<script src="/webflow.js"></script>', "Webflow"),
            ('<script src="/media/jui/js/a.js"></script>', "Joomla"),
            ('<script src="/sites/default/files/a.js"></script>', "Drupal"),
            ('<script id="__NEXT_DATA__">{}</script>', "Next.js"),
            ('<img src="https://img1.wsimg.com/a.png">', "GoDaddy Website Builder"),
        ]
        for fragment, expected in cases:
            with self.subTest(platform=expected):
                self.assertEqual(
                    measurements.detect_stack(page(fragment))["platform"], expected)

    def test_nothing_recognisable_gives_no_platform(self):
        """Silence, not a guess. Most hand-built sites match nothing."""
        self.assertEqual(
            measurements.detect_stack(page("<h1>A shop</h1>"))["platform"], "")

    def test_the_generator_tag_is_a_fallback_not_the_first_answer(self):
        """Markers are harder to fake than a meta tag a theme can set."""
        html = ('<html><head><meta name="generator" content="Wix">'
                '</head><body><script src="/wp-includes/a.js"></script>'
                "</body></html>")

        self.assertEqual(measurements.detect_stack(html)["platform"], "WordPress")

    def test_a_generator_tag_alone_still_counts(self):
        html = ('<html><head><meta name="generator" content="Drupal 10">'
                "</head><body></body></html>")

        self.assertEqual(
            measurements.detect_stack(html, "Drupal 10")["platform"], "Drupal")

    def test_the_page_builder_is_reported_alongside_the_platform(self):
        """How a WordPress site is maintained, which the platform alone hides."""
        stack = measurements.detect_stack(
            page('<div class="et_pb_row"></div>',
                 '<script src="/wp-content/a.js"></script>'))

        self.assertEqual(stack["platform"], "WordPress")
        self.assertEqual(stack["builders"], ["Divi"])

    def test_tracking_is_detected(self):
        cases = [
            ('<script src="https://www.googletagmanager.com/gtag/js?id=G-AB">'
             "</script>", "Google Analytics 4"),
            ('<script src="https://www.googletagmanager.com/gtm.js"></script>',
             "Google Tag Manager"),
            ("<script>fbq('init', '1')</script>", "Meta Pixel"),
            ('<script src="https://static.hotjar.com/c/h.js"></script>',
             "Hotjar"),
            ('<script src="https://plausible.io/js/s.js"></script>', "Plausible"),
        ]
        for fragment, expected in cases:
            with self.subTest(tool=expected):
                self.assertIn(expected,
                              measurements.detect_stack(page(fragment))["tracking"])

    def test_no_tracking_is_recorded_as_a_fact_not_an_absence(self):
        """"Nothing is measuring visitors" is a finding; a missing key is not."""
        facts = measure(page("<h1>A shop</h1>"))

        self.assertEqual(facts["tracking"], [])
        self.assertEqual(facts["tracking_count"], 0)

    def test_the_platform_reaches_the_measured_signals(self):
        facts = measure(page('<script src="/wp-content/a.js"></script>',
                             '<div class="elementor-widget"></div>'))

        self.assertEqual(facts["platform"], "WordPress")
        self.assertEqual(facts["page_builder"], ["Elementor"])


class PlatformAdviceTests(TestCase):
    """The verdict, and how hard it is to get anything other than KEEP."""

    HEALTHY = {"platform": "WordPress", "load_ms": 900, "page_kb": 800,
               "viewport_meta": True, "https": True}

    def test_a_working_wordpress_site_is_left_alone(self):
        advice = scoring.platform_advice(self.HEALTHY)

        self.assertEqual(advice["verdict"], scoring.KEEP)
        self.assertIn("reasonable choice", advice["summary"])
        self.assertIn("not the platform", advice["summary"])

    def test_a_keep_verdict_says_nothing_in_the_email(self):
        """§16: technology is not mentioned to fill a section."""
        self.assertFalse(scoring.platform_advice(self.HEALTHY)["say"])

    def test_every_established_platform_gets_the_same_benefit_of_the_doubt(self):
        for platform in ("WordPress", "Wix", "Squarespace", "Shopify",
                         "Webflow", "GoDaddy Website Builder"):
            with self.subTest(platform=platform):
                advice = scoring.platform_advice(
                    {**self.HEALTHY, "platform": platform})
                self.assertEqual(advice["verdict"], scoring.KEEP)

    def test_one_measured_problem_is_optimise_not_replace(self):
        """A slow page is a slow page. It is not an argument about platforms."""
        advice = scoring.platform_advice({**self.HEALTHY, "load_ms": 5200})

        self.assertEqual(advice["verdict"], scoring.OPTIMISE)
        self.assertTrue(advice["say"])
        self.assertIn("not the problem here", advice["summary"])
        self.assertIn("without changing platform", advice["summary"])
        self.assertIn("5200ms", advice["evidence"][0])

    def test_several_measured_problems_reach_modernise_at_most(self):
        """The strongest verdict available. There is no "rebuild in X"."""
        advice = scoring.platform_advice({
            "platform": "WordPress", "load_ms": 6000, "page_kb": 5200,
            "viewport_meta": False, "https": True})

        self.assertEqual(advice["verdict"], scoring.MODERNISE)
        self.assertEqual(len(advice["evidence"]), 3)
        self.assertIn("worth discussing only if", advice["summary"])

    def test_no_platform_detected_means_no_opinion(self):
        advice = scoring.platform_advice({"load_ms": 900})

        self.assertEqual(advice["verdict"], scoring.UNKNOWN)
        self.assertFalse(advice["say"])

    def test_no_signals_at_all_is_survivable(self):
        self.assertEqual(scoring.platform_advice({})["verdict"],
                         scoring.UNKNOWN)
        self.assertEqual(scoring.platform_advice(None)["verdict"],
                         scoring.UNKNOWN)


class ReplatformGuardTests(TestCase):
    """A rebuild recommendation needs evidence, like everything else."""

    def _finding(self, fix: str) -> Finding:
        return Finding("Something is wrong", "load_ms=5200", "It costs enquiries",
                       fix, "performance", "high")

    def setUp(self):
        self.keep = scoring.platform_advice(
            {"platform": "WordPress", "load_ms": 900, "viewport_meta": True,
             "https": True})
        self.modernise = scoring.platform_advice(
            {"platform": "WordPress", "load_ms": 6000, "page_kb": 5200,
             "viewport_meta": False})

    def test_a_rebuild_is_blocked_when_the_platform_is_fine(self):
        for fix in ("Rebuild the site in Next.js",
                    "Migrate to a headless CMS",
                    "Rewrite the front end in React",
                    "Consider a modern stack",
                    "Replatform onto Astro",
                    "Build a new website from scratch"):
            with self.subTest(fix=fix):
                problem = scoring.unsupported_replatform(
                    self._finding(fix), self.keep)
                self.assertIn("the crawl does not support", problem)

    def test_an_ordinary_fix_is_never_blocked(self):
        for fix in ("Add a booking link above the fold",
                    "Compress the images on the homepage",
                    "Write a short description for each service",
                    "Add a viewport tag so the site works on phones"):
            with self.subTest(fix=fix):
                self.assertEqual(
                    scoring.unsupported_replatform(self._finding(fix), self.keep),
                    "")

    def test_a_rebuild_is_allowed_once_several_problems_support_it(self):
        self.assertEqual(
            scoring.unsupported_replatform(
                self._finding("Rebuild the site on a modern stack"),
                self.modernise),
            "")

    def test_an_empty_fix_is_not_a_problem(self):
        self.assertEqual(
            scoring.unsupported_replatform(self._finding(""), self.keep), "")


class PlatformInThePipelineTests(SignedIn):
    """The verdict has to reach the email, and the guard has to bite."""

    def _draft(self, facts: dict, fix="Add a booking link above the fold"):
        finding = Finding("The homepage is slow", "load_ms=5200",
                          "Visitors leave before it appears", fix,
                          "performance", "high", "",
                          "Could reduce the number of people who give up.")
        return make_draft(
            self.campaign, subject="", body="",
            status=EmailDraft.Status.ANALYSED,
            pages_read=[{"url": "https://bella.example/", "kind": "home",
                         "facts": facts}],
            findings=[finding.as_dict()])

    def setUp(self):
        self.campaign = make_campaign()
        self.email = GeneratedEmail("A few things I noticed", EMAIL_BODY,
                                    "the homepage is slow", ["The homepage is slow"])

    def test_a_healthy_platform_sends_no_note_to_the_email(self):
        draft = self._draft({"platform": "WordPress", "load_ms": 900,
                             "viewport_meta": True, "https": True})

        with mock.patch.object(ai, "generate", return_value=self.email) as gen:
            runner.generate_draft(draft, self.campaign)

        self.assertEqual(gen.call_args.kwargs["platform_note"], "")

    def test_a_measured_problem_sends_the_note(self):
        draft = self._draft({"platform": "WordPress", "load_ms": 5200,
                             "viewport_meta": True, "https": True})

        with mock.patch.object(ai, "generate", return_value=self.email) as gen:
            runner.generate_draft(draft, self.campaign)

        note = gen.call_args.kwargs["platform_note"]
        self.assertIn("WordPress", note)
        self.assertIn("not the problem here", note)

    def test_an_unsupported_rebuild_never_reaches_the_email(self):
        """It stays in the audit, where the operator can judge it."""
        draft = self._draft({"platform": "WordPress", "load_ms": 900,
                             "viewport_meta": True, "https": True},
                            fix="Rebuild the whole site in Next.js")

        with mock.patch.object(ai, "generate", return_value=self.email) as gen:
            runner.generate_draft(draft, self.campaign)

        fixes = [f.suggested_improvement
                 for f in gen.call_args.kwargs["findings"]]
        self.assertNotIn("Rebuild the whole site in Next.js", fixes)
        self.assertIn("no platform change is needed", fixes[0])

        # And the audit itself is untouched -- the internal analysis may be
        # opinionated even where the client email may not.
        draft.refresh_from_db()
        self.assertEqual(draft.findings[0]["suggested_improvement"],
                         "Rebuild the whole site in Next.js")

    def test_the_prompt_carries_the_note_only_with_findings(self):
        prompt = ai.build_prompt(
            business_name="Bella", category="Restaurant", city="Delft",
            country="NL", website="https://bella.example", sender_name="Sam",
            sender_company="Northline", findings=[], pages=[], signals={},
            platform_note="WordPress is not the problem here.")

        self.assertNotIn("PLATFORM", prompt)


class FindingIdTests(TestCase):
    """Every claim in an email has to trace back to a verified finding."""

    def _findings(self, count=3) -> list:
        return [
            Finding(f"Issue {i}", f"signal_{i}=0", "why", "fix", "pricing",
                    "high")
            for i in range(count)
        ]

    def test_ids_are_assigned_in_rank_order(self):
        rows = ai.assign_ids(self._findings())

        self.assertEqual([f.finding_id for f in rows],
                         ["AUD-001", "AUD-002", "AUD-003"])

    def test_ids_do_not_change_when_reassigned(self):
        """An email written last week must still refer to the same finding."""
        rows = ai.assign_ids(self._findings())
        before = [f.finding_id for f in rows]

        self.assertEqual([f.finding_id for f in ai.assign_ids(rows)], before)

    def test_a_new_finding_takes_the_next_free_id(self):
        rows = ai.assign_ids(self._findings(2))
        rows.append(Finding("A later issue", "e", "w", "f"))

        self.assertEqual(ai.assign_ids(rows)[2].finding_id, "AUD-003")

    def test_an_email_entry_resolves_by_id(self):
        rows = ai.assign_ids(self._findings())

        self.assertIs(ai.find_by_reference("AUD-002", rows), rows[1])

    def test_an_email_entry_resolves_by_issue_text(self):
        rows = ai.assign_ids(self._findings())

        self.assertIs(ai.find_by_reference("Issue 1", rows), rows[1])
        self.assertIs(ai.find_by_reference("the site has Issue 1", rows), rows[1])

    def test_an_invented_claim_resolves_to_nothing(self):
        rows = ai.assign_ids(self._findings())

        self.assertIsNone(ai.find_by_reference("The colours feel dated", rows))
        self.assertIsNone(ai.find_by_reference("AUD-999", rows))
        self.assertIsNone(ai.find_by_reference("", rows))

    def test_an_untraceable_claim_is_reported(self):
        rows = ai.assign_ids(self._findings())
        email = GeneratedEmail("s", EMAIL_BODY, "o",
                               ["AUD-001", "The colours feel dated"])

        problem = ai.traceability_problem(email, rows)

        self.assertIn("does not match any verified finding", problem)
        self.assertIn("The colours feel dated", problem)

    def test_a_traceable_email_passes(self):
        rows = ai.assign_ids(self._findings())
        email = GeneratedEmail("s", EMAIL_BODY, "o", ["AUD-001", "Issue 2"])

        self.assertEqual(ai.traceability_problem(email, rows), "")

    def test_nothing_reported_is_not_a_traceability_failure(self):
        """A lead with no findings has nothing to trace; other checks cover it."""
        self.assertEqual(
            ai.traceability_problem(GeneratedEmail("s", "b", "none", []),
                                    self._findings()),
            "")

    def test_the_audit_assigns_ids_when_it_is_parsed(self):
        import json

        payload = json.dumps({
            "business_summary": "A pizzeria.",
            "findings": [
                {"issue": f"Issue {i}", "evidence": f"signal_{i}=0",
                 "why_it_matters": "It costs enquiries",
                 "suggested_improvement": "Fix it",
                 "business_benefit": "Could help visitors get in touch.",
                 "dimension": "calls to action", "severity": "high"}
                for i in range(3)
            ],
        })

        audit = ai.parse_audit(payload)

        self.assertEqual([f.finding_id for f in audit.findings],
                         ["AUD-001", "AUD-002", "AUD-003"])

    def test_the_id_survives_a_round_trip_through_the_database(self):
        row = ai.assign_ids(self._findings(1))[0]

        self.assertEqual(Finding.from_dict(row.as_dict()).finding_id, "AUD-001")

    def test_the_email_prompt_shows_the_ids(self):
        rows = ai.assign_ids(self._findings(2))
        prompt = ai.build_prompt(
            business_name="Bella", category="Restaurant", city="Delft",
            country="NL", website="https://bella.example", sender_name="Sam",
            sender_company="Northline", findings=rows,
            pages=[{"url": "https://bella.example/", "kind": "home"}],
            signals={"cta_count": 0})

        self.assertIn("[AUD-001]", prompt)
        self.assertIn("[AUD-002]", prompt)
        self.assertIn("list the ids you used", prompt)
