"""
Reply tracking and manual follow-ups.

The cases that matter here are the ones where a follow-up must NOT go out: the
lead replied while the draft sat in review, the address bounced, somebody asked
to be removed, the limit is reached, the same button was clicked twice. A
follow-up sent to someone who already replied is worse than no follow-up, so the
pre-send check gets more attention than the happy path.

Nothing in this module touches a real mailbox: OUTREACH_BLOCK_SEND is on under
`manage.py test`, IMAP refuses to open a socket, and the matcher is exercised
against messages built in memory.
"""

from __future__ import annotations

import email as emaillib
import os
from datetime import timedelta
from unittest import mock

from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from apps import ai
from apps.core.testing import OtherUser, SignedIn, default_user
from apps.outreach.mail import compose, followups, inbox, providers, transport
from apps.outreach.models import (
    Campaign,
    EmailDraft,
    FollowUp,
    ReplyState,
    SentLead,
    Suppression,
)
from apps.outreach.services import history

from .factories import make_campaign, make_draft

PASSWORD = "abcd efgh ijkl mnop"

#: Removes a real OUTREACH_SMTP_PASSWORD for the duration of a test. Without it,
#: "no password supplied" tests silently pass on a machine with no .env and
#: silently fail on the developer's, which is the wrong way round.
no_env_password = mock.patch.dict(os.environ, {"OUTREACH_SMTP_PASSWORD": ""},
                                  clear=False)


def make_lead(*, campaign=None, draft=None, business_name="ABC Company",
              email="abc@company.test", website="https://company.test",
              message_id="<abc-001@agency.test>", days_ago=5,
              status=SentLead.Status.SENT, **overrides) -> SentLead:
    """A delivered email, `days_ago` days old, as the send loop would leave it."""
    when = timezone.now() - timedelta(days=days_ago)
    values = dict(
        owner=default_user(),
        business_name=business_name, email=email, website=website,
        domain=SentLead.domain_of(website), country="Netherlands", city="Delft",
        campaign=campaign, campaign_label=getattr(campaign, "label", ""),
        draft=draft, subject="A quick idea for ABC Company",
        status=status, message_id=message_id,
    )
    values.update(overrides)
    lead = SentLead.objects.create(**values)
    SentLead.objects.filter(pk=lead.pk).update(
        sent_at=when, reserved_at=when, sent_date=when.date())
    lead.refresh_from_db()
    return lead


def incoming(*, sender_address="abc@company.test", subject="Re: A quick idea",
             in_reply_to="<abc-001@agency.test>", body="Yes please, go ahead.",
             extra_headers="", content_type="text/plain") -> emaillib.message.Message:
    """One inbound email, built by hand."""
    headers = [
        f"From: {sender_address}",
        "To: sam@agency.test",
        f"Subject: {subject}",
        f"Content-Type: {content_type}",
    ]
    if in_reply_to:
        headers.append(f"In-Reply-To: {in_reply_to}")
    if extra_headers:
        headers.append(extra_headers.strip())
    return emaillib.message_from_string("\r\n".join(headers) + "\r\n\r\n" + body)


# --------------------------------------------------------------------------- #
# Matching
# --------------------------------------------------------------------------- #

class ReplyMatchingTests(SignedIn):
    """What counts as a reply to something we sent, and what does not."""

    def setUp(self):
        self.lead = make_lead()

    def _classify(self, message):
        return inbox.Matcher(default_user()).classify(message)

    def test_a_quoted_message_id_is_a_match(self):
        verdict = self._classify(incoming())

        self.assertTrue(verdict.matched)
        self.assertEqual(verdict.matched_by, "message_id")
        self.assertEqual(verdict.state, ReplyState.REPLIED)
        self.assertEqual(verdict.lead.pk, self.lead.pk)

    def test_a_references_header_is_matched_too(self):
        message = incoming(in_reply_to="")
        message["References"] = "<other@x.test> <abc-001@agency.test>"

        self.assertEqual(self._classify(message).matched_by, "message_id")

    def test_a_known_sender_matches_without_threading_headers(self):
        """Some clients strip In-Reply-To. The address is still evidence."""
        verdict = self._classify(incoming(in_reply_to=""))

        self.assertTrue(verdict.matched)
        self.assertEqual(verdict.matched_by, "address")

    def test_an_unrelated_email_is_not_matched_or_stored(self):
        verdict = self._classify(incoming(
            sender_address="newsletter@somewhere.test",
            subject="Your weekly digest", in_reply_to="", body="Hello!"))

        self.assertFalse(verdict.matched)
        self.assertEqual(verdict.state, "")
        self.assertIsNone(verdict.lead)

    def test_a_matching_subject_alone_is_not_enough(self):
        """A guessable subject must never mark a lead as replied."""
        verdict = self._classify(incoming(
            sender_address="stranger@elsewhere.test",
            subject="Re: A quick idea for ABC Company", in_reply_to=""))

        self.assertFalse(verdict.matched)

    def test_a_reply_to_a_follow_up_is_attributed_to_the_lead(self):
        FollowUp.objects.create(
            owner=default_user(), lead=self.lead, number=1, email=self.lead.email,
            subject="Re: A quick idea", body="Following up.",
            status=FollowUp.Status.SENT, message_id="<fu-1@agency.test>",
            sent_at=timezone.now())

        verdict = self._classify(incoming(in_reply_to="<fu-1@agency.test>"))

        self.assertEqual(verdict.lead.pk, self.lead.pk)
        self.assertIsNotNone(verdict.followup)
        self.assertEqual(verdict.followup.number, 1)

    def test_nothing_sent_means_nothing_can_match(self):
        SentLead.objects.all().delete()
        self.assertFalse(self._classify(incoming()).matched)


class UnsubscribeDetectionTests(SignedIn):
    def setUp(self):
        self.lead = make_lead()

    def _state(self, body):
        return inbox.Matcher(default_user()).classify(incoming(body=body)).state

    def test_a_removal_request_is_an_unsubscribe(self):
        for body in ("Please remove me from your list.",
                     "unsubscribe", "Take me off this list please",
                     "Not interested, please stop emailing me."):
            with self.subTest(body=body):
                self.assertEqual(self._state(body), ReplyState.UNSUBSCRIBED)

    def test_an_ordinary_reply_is_not_an_unsubscribe(self):
        self.assertEqual(self._state("Sounds interesting, tell me more."),
                         ReplyState.REPLIED)

    def test_a_quoted_footer_does_not_read_as_a_request(self):
        """A quoted line about unsubscribing is not somebody unsubscribing.

        The opt-out route is the `List-Unsubscribe` header, and a recipient quoting
        our message back at us must not be read as a request. The quoted text here is
        the shape a mail client produces when somebody presses Reply.
        """
        body = ("Sure, send it over.\r\n\r\n"
                "> If you're interested, simply reply to this email.\r\n"
                "> To unsubscribe, reply to this address.\r\n")

        self.assertEqual(self._state(body), ReplyState.REPLIED)

    def test_a_gmail_style_quote_header_ends_the_new_text(self):
        body = ("Yes please.\r\n\r\n"
                "On Mon, 4 Aug 2025 at 10:12, Sam <sam@agency.test> wrote:\r\n"
                "Please unsubscribe me if not interested\r\n")

        self.assertEqual(self._state(body), ReplyState.REPLIED)


class BounceDetectionTests(SignedIn):
    def setUp(self):
        self.lead = make_lead()

    def test_a_permanent_failure_is_a_bounce(self):
        message = incoming(
            sender_address="MAILER-DAEMON@agency.test",
            subject="Undelivered Mail Returned to Sender",
            body="Status: 5.1.1 user unknown")

        verdict = inbox.Matcher(default_user()).classify(message)

        self.assertEqual(verdict.state, ReplyState.BOUNCED)

    def test_a_temporary_failure_is_ignored(self):
        """A 4.x.x is the mail system retrying. Closing the lead would be wrong."""
        message = incoming(
            sender_address="MAILER-DAEMON@agency.test",
            subject="Delivery Status Notification (Delay)",
            body="Status: 4.4.1 temporary failure, will retry for 48 hours")

        self.assertFalse(inbox.Matcher(default_user()).classify(message).matched)
        self.lead.refresh_from_db()
        self.assertEqual(self.lead.reply_state, ReplyState.NO_REPLY)

    def test_a_bounce_is_matched_by_the_address_inside_the_report(self):
        message = incoming(
            sender_address="postmaster@relay.test",
            subject="Delivery failure", in_reply_to="",
            body="Your message to abc@company.test failed.\nStatus: 5.0.0")

        verdict = inbox.Matcher(default_user()).classify(message)

        self.assertEqual(verdict.matched_by, "bounce_report")
        self.assertEqual(verdict.state, ReplyState.BOUNCED)


class ApplyVerdictTests(SignedIn):
    """What recording a reply changes."""

    def setUp(self):
        self.lead = make_lead()

    def test_a_reply_is_recorded_on_the_lead(self):
        inbox.apply(inbox.Matcher(default_user()).classify(
            incoming(body="Yes please, send the ideas.")))

        self.lead.refresh_from_db()
        self.assertEqual(self.lead.reply_state, ReplyState.REPLIED)
        self.assertIsNotNone(self.lead.replied_at)
        self.assertIn("send the ideas", self.lead.reply_snippet)

    def test_an_unsubscribe_lands_on_the_do_not_contact_list(self):
        """A reply asking to be removed must not need a second manual step."""
        inbox.apply(inbox.Matcher(default_user()).classify(
            incoming(body="Please remove me from your list.")))

        self.lead.refresh_from_db()
        self.assertEqual(self.lead.reply_state, ReplyState.UNSUBSCRIBED)
        entry = Suppression.objects.get()
        self.assertEqual(entry.email, "abc@company.test")
        self.assertEqual(entry.reason, Suppression.Reason.UNSUBSCRIBED)

    def test_a_bounce_is_suppressed_as_a_dead_address(self):
        inbox.apply(inbox.Matcher(default_user()).classify(incoming(
            sender_address="MAILER-DAEMON@agency.test",
            subject="Undeliverable", body="Status: 5.1.1 no such user")))

        entry = Suppression.objects.get()
        self.assertEqual(entry.reason, Suppression.Reason.BOUNCED)

    def test_a_reply_cancels_a_follow_up_still_awaiting_review(self):
        drafted = FollowUp.objects.create(
            owner=default_user(), lead=self.lead, number=1, email=self.lead.email,
            subject="Re: A quick idea", body="Following up.")

        inbox.apply(inbox.Matcher(default_user()).classify(incoming()))

        drafted.refresh_from_db()
        self.assertEqual(drafted.status, FollowUp.Status.CANCELLED)
        self.assertIn("replied", drafted.error_message)

    def test_an_unmatched_verdict_changes_nothing(self):
        inbox.apply(inbox.Verdict())

        self.lead.refresh_from_db()
        self.assertEqual(self.lead.reply_state, ReplyState.NO_REPLY)
        self.assertEqual(Suppression.objects.count(), 0)


class InboxSafetyTests(SignedIn):
    """Reading the mailbox is blocked in this environment, like sending."""

    def test_the_session_refuses_to_open_a_connection(self):
        box = inbox.Inbox(providers.PROVIDERS["gmail"], "sam@agency.test", PASSWORD)

        with self.assertRaises(inbox.InboxError) as caught:
            with box:
                pass

        self.assertIn("blocked", str(caught.exception))

    def test_check_refuses_before_touching_the_network(self):
        make_lead()
        with self.assertRaises(inbox.InboxError):
            inbox.check(password=PASSWORD, owner=default_user())

    def test_a_provider_without_imap_is_reported_not_guessed(self):
        with self.assertRaises(inbox.InboxError) as caught:
            inbox.resolve_imap(providers.PROVIDERS["custom"])

        self.assertIn("OUTREACH_IMAP_HOST", str(caught.exception))

    def test_presets_carry_their_own_imap_host(self):
        host, port = inbox.resolve_imap(providers.PROVIDERS["gmail"])

        self.assertEqual((host, port), ("imap.gmail.com", 993))

    def test_the_password_is_normalised_like_the_smtp_one(self):
        box = inbox.Inbox(providers.PROVIDERS["gmail"], "sam@agency.test", PASSWORD)

        self.assertEqual(box.password, "abcdefghijklmnop")


# --------------------------------------------------------------------------- #
# Eligibility, timing and limits
# --------------------------------------------------------------------------- #

class EligibilityTests(SignedIn):
    def test_a_silent_lead_past_the_wait_is_eligible(self):
        verdict = followups.eligibility(make_lead(days_ago=5))

        self.assertTrue(verdict.eligible)
        self.assertEqual(verdict.next_number, 1)
        self.assertEqual(verdict.sent_count, 0)

    def test_a_fresh_send_is_still_waiting(self):
        verdict = followups.eligibility(make_lead(days_ago=0))

        self.assertFalse(verdict.eligible)
        self.assertEqual(verdict.reason, "waiting")
        self.assertTrue(verdict.waiting)
        self.assertGreaterEqual(verdict.days_until, 1)
        self.assertIsNotNone(verdict.eligible_at)

    def test_a_replied_lead_is_never_eligible(self):
        lead = make_lead(days_ago=30, reply_state=ReplyState.REPLIED)

        verdict = followups.eligibility(lead)

        self.assertFalse(verdict.eligible)
        self.assertEqual(verdict.reason, "replied")
        self.assertIn("not required", verdict.label)

    def test_bounced_and_unsubscribed_leads_are_never_eligible(self):
        for state in (ReplyState.BOUNCED, ReplyState.UNSUBSCRIBED):
            with self.subTest(state=state):
                lead = make_lead(days_ago=30, reply_state=state,
                                 email=f"{state}@company.test",
                                 message_id=f"<{state}@agency.test>")
                self.assertFalse(followups.eligibility(lead).eligible)

    def test_a_suppressed_address_is_never_eligible(self):
        lead = make_lead(days_ago=30)
        history.suppress(default_user(), email=lead.email, reason="unsubscribed")

        verdict = followups.eligibility(lead)

        self.assertEqual(verdict.reason, "suppressed")

    def test_an_invalid_address_is_never_eligible(self):
        lead = make_lead(days_ago=30)
        SentLead.objects.filter(pk=lead.pk).update(email="not-an-address")
        lead.refresh_from_db()

        self.assertEqual(followups.eligibility(lead).reason, "invalid")

    def test_a_lead_whose_email_never_landed_is_not_eligible(self):
        lead = make_lead(days_ago=30, status=SentLead.Status.SENDING)

        self.assertEqual(followups.eligibility(lead).reason, "not_sent")

    def test_a_drafted_follow_up_blocks_another(self):
        lead = make_lead(days_ago=30)
        FollowUp.objects.create(owner=default_user(), lead=lead, number=1, email=lead.email,
                                subject="Re: x", body="b")

        self.assertEqual(followups.eligibility(lead).reason, "drafted")

    def test_the_limit_closes_the_lead(self):
        lead = make_lead(days_ago=60)
        for number in (1, 2):
            FollowUp.objects.create(
                owner=default_user(), lead=lead, number=number, email=lead.email, subject="Re: x",
                body="b", status=FollowUp.Status.SENT,
                sent_at=timezone.now() - timedelta(days=30))

        verdict = followups.eligibility(lead)

        self.assertEqual(verdict.reason, "limit")
        self.assertEqual(verdict.sent_count, 2)
        self.assertIn("limit reached", verdict.label)

    def test_the_wait_runs_from_the_last_message_not_the_first(self):
        """Follow-up #2 waits 7 days from follow-up #1, not from the original."""
        lead = make_lead(days_ago=30)
        FollowUp.objects.create(
            owner=default_user(), lead=lead, number=1, email=lead.email, subject="Re: x", body="b",
            status=FollowUp.Status.SENT,
            sent_at=timezone.now() - timedelta(days=2))

        verdict = followups.eligibility(lead)

        self.assertEqual(verdict.reason, "waiting")
        self.assertEqual(verdict.next_number, 2)

    def test_the_second_wait_is_the_longer_one(self):
        lead = make_lead(days_ago=30)
        FollowUp.objects.create(
            owner=default_user(), lead=lead, number=1, email=lead.email, subject="Re: x", body="b",
            status=FollowUp.Status.SENT,
            sent_at=timezone.now() - timedelta(days=8))

        self.assertTrue(followups.eligibility(lead).eligible)

    def test_a_cancelled_follow_up_frees_its_number(self):
        lead = make_lead(days_ago=30)
        FollowUp.objects.create(owner=default_user(), lead=lead, number=1, email=lead.email,
                                subject="Re: x", body="b",
                                status=FollowUp.Status.CANCELLED)

        verdict = followups.eligibility(lead)

        self.assertTrue(verdict.eligible)
        self.assertEqual(verdict.next_number, 1)

    @override_settings(OUTREACH_FOLLOWUP_MAX=0)
    def test_a_maximum_of_zero_disables_follow_ups_entirely(self):
        self.assertEqual(followups.eligibility(make_lead(days_ago=30)).reason,
                         "limit")

    @override_settings(OUTREACH_FOLLOWUP_DELAYS=[1])
    def test_a_short_delay_list_reuses_its_last_value(self):
        self.assertEqual(followups.delay_days(1), 1)
        self.assertEqual(followups.delay_days(2), 1)
        self.assertEqual(followups.delay_days(9), 1)


class PreSendCheckTests(SignedIn):
    """The check that runs immediately before SMTP."""

    def setUp(self):
        self.lead = make_lead(days_ago=5)
        self.followup = FollowUp.objects.create(
            owner=default_user(), lead=self.lead, number=1, email=self.lead.email,
            subject="Re: A quick idea", body="Just following up.")

    def test_an_eligible_lead_passes(self):
        self.assertEqual(followups.check_before_send(self.followup).pk,
                         self.lead.pk)

    def test_a_reply_that_arrived_during_review_blocks_the_send(self):
        """The case the whole check exists for."""
        SentLead.objects.filter(pk=self.lead.pk).update(
            reply_state=ReplyState.REPLIED)

        with self.assertRaises(followups.Blocked) as caught:
            followups.check_before_send(self.followup)

        self.assertIn("replied", str(caught.exception))

    def test_a_suppression_added_during_review_blocks_the_send(self):
        history.suppress(default_user(), email=self.lead.email, reason="unsubscribed")

        with self.assertRaises(followups.Blocked) as caught:
            followups.check_before_send(self.followup)

        self.assertIn("do-not-contact", str(caught.exception))

    def test_an_already_sent_follow_up_cannot_be_sent_again(self):
        FollowUp.objects.filter(pk=self.followup.pk).update(
            status=FollowUp.Status.SENT)
        self.followup.refresh_from_db()

        with self.assertRaises(followups.Blocked) as caught:
            followups.check_before_send(self.followup)

        self.assertIn("already been sent", str(caught.exception))

    def test_a_cancelled_follow_up_cannot_be_sent(self):
        FollowUp.objects.filter(pk=self.followup.pk).update(
            status=FollowUp.Status.CANCELLED)
        self.followup.refresh_from_db()

        with self.assertRaises(followups.Blocked):
            followups.check_before_send(self.followup)

    def test_reaching_the_limit_during_review_blocks_the_send(self):
        for number in (1, 2):
            FollowUp.objects.create(
                owner=default_user(), lead=self.lead, number=number + 10, email=self.lead.email,
                subject="Re: x", body="b", status=FollowUp.Status.SENT,
                sent_at=timezone.now())

        with self.assertRaises(followups.Blocked) as caught:
            followups.check_before_send(self.followup)

        self.assertIn("limit", str(caught.exception))

    def test_a_changed_recipient_blocks_the_send(self):
        SentLead.objects.filter(pk=self.lead.pk).update(
            email="somebody-else@company.test")

        with self.assertRaises(followups.Blocked) as caught:
            followups.check_before_send(self.followup)

        self.assertIn("changed", str(caught.exception))

    def test_the_waiting_period_does_not_block_an_approved_draft(self):
        """The user already waited long enough to write it; stranding it here
        would mean a draft that can never be sent."""
        SentLead.objects.filter(pk=self.lead.pk).update(sent_at=timezone.now())

        self.assertIsNotNone(followups.check_before_send(self.followup))

    def test_only_one_caller_can_claim_a_draft(self):
        self.assertTrue(followups.claim(self.followup))
        self.assertFalse(followups.claim(self.followup))

        self.followup.refresh_from_db()
        self.assertEqual(self.followup.status, FollowUp.Status.SENDING)

    def test_a_released_draft_can_be_claimed_again(self):
        followups.claim(self.followup)
        followups.release(self.followup)
        self.followup.refresh_from_db()

        self.assertTrue(followups.claim(self.followup))


class FollowUpConstraintTests(SignedIn):
    def setUp(self):
        self.lead = make_lead(days_ago=5)

    def test_two_live_follow_ups_cannot_share_a_number(self):
        from django.db import IntegrityError, transaction

        FollowUp.objects.create(owner=default_user(), lead=self.lead, number=1, email=self.lead.email,
                                subject="Re: x", body="b")
        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                FollowUp.objects.create(owner=default_user(), lead=self.lead, number=1,
                                        email=self.lead.email,
                                        subject="Re: x", body="b")

    def test_a_cancelled_row_does_not_hold_its_number(self):
        FollowUp.objects.create(owner=default_user(), lead=self.lead, number=1, email=self.lead.email,
                                subject="Re: x", body="b",
                                status=FollowUp.Status.CANCELLED)
        # No error: the number is free again.
        FollowUp.objects.create(owner=default_user(), lead=self.lead, number=1, email=self.lead.email,
                                subject="Re: x", body="b")

        self.assertEqual(self.lead.followups.count(), 2)


# --------------------------------------------------------------------------- #
# The endpoints
# --------------------------------------------------------------------------- #

class FollowUpEndpointTests(SignedIn):
    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(
            self.campaign, business_name="ABC Company",
            email="abc@company.test", website="https://company.test",
            subject="A quick idea for ABC Company",
            body="Hi ABC Team,\n\nI noticed your contact page.\n\nSam",
            observation="no call to action on the services page",
            status=EmailDraft.Status.SENT,
        )
        self.lead = make_lead(campaign=self.campaign, draft=self.draft,
                              days_ago=5)
        self.email = ai.GeneratedEmail(
            "Re: A quick idea for ABC Company",
            "Hi ABC Team,\n\nJust following up briefly.\n\nSam",
            "a smaller next step", [])

    def _create(self):
        with mock.patch.object(ai, "follow_up", return_value=self.email) as gen:
            response = self.client.post(
                reverse("outreach:followup_create", args=[self.lead.pk]))
        return response, gen

    def test_creating_a_follow_up_saves_a_draft_and_sends_nothing(self):
        response, _gen = self._create()

        self.assertEqual(response.status_code, 200)
        followup = FollowUp.objects.get()
        self.assertEqual(followup.status, FollowUp.Status.DRAFT)
        self.assertEqual(followup.number, 1)
        self.assertEqual(followup.email, "abc@company.test")
        self.assertIsNone(followup.sent_at)
        self.assertEqual(response.json()["angle"], "a smaller next step")

    def test_the_generator_is_given_the_original_email_and_the_gap(self):
        _response, gen = self._create()

        kwargs = gen.call_args.kwargs
        self.assertIn("I noticed your contact page", kwargs["original_body"])
        self.assertEqual(kwargs["original_subject"],
                         "A quick idea for ABC Company")
        self.assertEqual(kwargs["observation"],
                         "no call to action on the services page")
        self.assertEqual(kwargs["days_since"], 5)
        self.assertEqual(kwargs["number"], 1)
        self.assertEqual(kwargs["business_name"], "ABC Company")

    def test_an_ineligible_lead_is_refused(self):
        SentLead.objects.filter(pk=self.lead.pk).update(
            reply_state=ReplyState.REPLIED)

        response, gen = self._create()

        self.assertEqual(response.status_code, 409)
        gen.assert_not_called()
        self.assertEqual(FollowUp.objects.count(), 0)

    def test_a_failed_generation_does_not_leave_a_draft(self):
        with mock.patch.object(ai, "follow_up",
                               side_effect=ai.AiError("rate limited")):
            response = self.client.post(
                reverse("outreach:followup_create", args=[self.lead.pk]))

        self.assertEqual(response.status_code, 502)
        self.assertEqual(FollowUp.objects.count(), 0)

    def test_a_draft_can_be_edited(self):
        self._create()
        followup = FollowUp.objects.get()

        response = self.client.post(
            reverse("outreach:followup_action", args=[followup.pk, "save"]),
            data={"subject": "Re: Edited", "body": "Hand written."},
            content_type="application/json")

        self.assertEqual(response.status_code, 200)
        followup.refresh_from_db()
        self.assertEqual(followup.subject, "Re: Edited")
        self.assertTrue(followup.edited)

    def test_an_empty_edit_is_refused(self):
        self._create()
        followup = FollowUp.objects.get()

        response = self.client.post(
            reverse("outreach:followup_action", args=[followup.pk, "save"]),
            data={"subject": "", "body": ""}, content_type="application/json")

        self.assertEqual(response.status_code, 400)

    def test_a_draft_can_be_regenerated(self):
        self._create()
        followup = FollowUp.objects.get()
        second = ai.GeneratedEmail("Re: A quick idea for ABC Company",
                                   "Shorter version.", "shorter", [])

        with mock.patch.object(ai, "follow_up", return_value=second) as gen:
            response = self.client.post(
                reverse("outreach:followup_action",
                        args=[followup.pk, "regenerate"]),
                data={"hint": "shorter"}, content_type="application/json")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(gen.call_args.kwargs["retry_hint"], "shorter")
        followup.refresh_from_db()
        self.assertEqual(followup.body, "Shorter version.")
        self.assertEqual(followup.regenerations, 1)

    def test_a_draft_can_be_cancelled_and_frees_the_lead(self):
        self._create()
        followup = FollowUp.objects.get()

        response = self.client.post(
            reverse("outreach:followup_action", args=[followup.pk, "cancel"]))

        self.assertEqual(response.status_code, 200)
        followup.refresh_from_db()
        self.assertEqual(followup.status, FollowUp.Status.CANCELLED)
        self.assertTrue(followups.eligibility(self.lead).eligible)

    def test_an_unknown_action_is_refused(self):
        self._create()
        followup = FollowUp.objects.get()

        response = self.client.post(
            reverse("outreach:followup_action", args=[followup.pk, "explode"]))

        self.assertEqual(response.status_code, 400)


class FollowUpSendTests(SignedIn):
    """Sending needs an explicit click, a password, and a clean final check."""

    def setUp(self):
        self.campaign = make_campaign()
        self.lead = make_lead(campaign=self.campaign, days_ago=5)
        self.followup = FollowUp.objects.create(
            owner=default_user(), lead=self.lead, campaign=self.campaign, number=1,
            email=self.lead.email, subject="Re: A quick idea",
            body="Just following up.")

    def _send(self, password=PASSWORD):
        return self.client.post(
            reverse("outreach:followup_action", args=[self.followup.pk, "send"]),
            data={"password": password}, content_type="application/json")

    def test_no_password_means_no_send(self):
        with no_env_password:
            response = self._send(password="")

        self.assertEqual(response.status_code, 400)
        self.followup.refresh_from_db()
        self.assertEqual(self.followup.status, FollowUp.Status.DRAFT)

    def test_sending_is_blocked_in_this_environment(self):
        """Proof the send path cannot reach a real mail server under test."""
        response = self._send()

        self.assertEqual(response.status_code, 502)
        self.assertIn("blocked", response.json()["error"])
        self.followup.refresh_from_db()
        # Released, not lost: the draft is still there to send later.
        self.assertEqual(self.followup.status, FollowUp.Status.DRAFT)

    def test_a_reply_arriving_first_cancels_the_send(self):
        SentLead.objects.filter(pk=self.lead.pk).update(
            reply_state=ReplyState.REPLIED)

        response = self._send()

        self.assertEqual(response.status_code, 409)
        self.assertTrue(response.json()["cancelled"])
        self.followup.refresh_from_db()
        self.assertEqual(self.followup.status, FollowUp.Status.CANCELLED)

    def test_a_suppression_arriving_first_cancels_the_send(self):
        history.suppress(default_user(), email=self.lead.email, reason="unsubscribed")

        response = self._send()

        self.assertEqual(response.status_code, 409)
        self.followup.refresh_from_db()
        self.assertEqual(self.followup.status, FollowUp.Status.CANCELLED)

    def test_a_successful_send_records_its_message_id(self):
        with mock.patch.object(transport.Session, "__enter__") as enter, \
             mock.patch.object(transport.Session, "__exit__", return_value=False):
            session = mock.Mock()
            session.send.return_value = "<fu-1@agency.test>"
            enter.return_value = session

            response = self._send()

        self.assertEqual(response.status_code, 200)
        self.followup.refresh_from_db()
        self.assertEqual(self.followup.status, FollowUp.Status.SENT)
        self.assertEqual(self.followup.message_id, "<fu-1@agency.test>")
        self.assertIsNotNone(self.followup.sent_at)
        self.assertIsNotNone(self.followup.sent_date)

    def test_a_second_click_cannot_send_it_twice(self):
        with mock.patch.object(transport.Session, "__enter__") as enter, \
             mock.patch.object(transport.Session, "__exit__", return_value=False):
            session = mock.Mock()
            session.send.return_value = "<fu-1@agency.test>"
            enter.return_value = session

            first = self._send()
            second = self._send()

        self.assertEqual(first.status_code, 200)
        self.assertEqual(second.status_code, 409)
        self.assertEqual(session.send.call_count, 1)

    def test_the_next_follow_up_waits_from_this_one(self):
        with mock.patch.object(transport.Session, "__enter__") as enter, \
             mock.patch.object(transport.Session, "__exit__", return_value=False):
            session = mock.Mock()
            session.send.return_value = "<fu-1@agency.test>"
            enter.return_value = session
            self._send()

        verdict = followups.eligibility(self.lead)

        self.assertEqual(verdict.sent_count, 1)
        self.assertEqual(verdict.next_number, 2)
        self.assertEqual(verdict.reason, "waiting")


class FollowUpScreenTests(SignedIn):
    def setUp(self):
        self.lead = make_lead(days_ago=5)

    def test_the_page_renders_with_its_stats(self):
        response = self.client.get(reverse("outreach:followups"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "ABC Company")
        self.assertContains(response, "Follow-up eligible")

    def test_every_filter_renders(self):
        for name in followups.FILTERS:
            with self.subTest(filter=name):
                response = self.client.get(
                    reverse("outreach:followups") + f"?filter={name}")
                self.assertEqual(response.status_code, 200)

    def test_a_replied_lead_is_not_offered_a_follow_up(self):
        SentLead.objects.filter(pk=self.lead.pk).update(
            reply_state=ReplyState.REPLIED, reply_snippet="Yes please.")

        response = self.client.get(reverse("outreach:followups"))

        self.assertNotContains(response, "Create follow-up")
        self.assertContains(response, "not required")
        self.assertContains(response, "Yes please.")

    def test_the_ready_filter_only_keeps_eligible_leads(self):
        make_lead(days_ago=0, email="fresh@company.test",
                  message_id="<fresh@agency.test>",
                  business_name="Fresh Co", website="https://fresh.test")

        response = self.client.get(
            reverse("outreach:followups") + "?filter=ready")

        self.assertContains(response, "ABC Company")
        self.assertNotContains(response, "Fresh Co")

    def test_the_stats_agree_with_the_buttons(self):
        """`ready` is counted from the same rule the buttons use."""
        make_lead(days_ago=0, email="fresh@company.test",
                  message_id="<fresh@agency.test>", website="https://fresh.test")
        make_lead(days_ago=9, email="replied@company.test",
                  message_id="<replied@agency.test>",
                  website="https://replied.test",
                  reply_state=ReplyState.REPLIED)

        stats = followups.stats(default_user())

        self.assertEqual(stats["sent"], 3)
        self.assertEqual(stats["replied"], 1)
        self.assertEqual(stats["ready"], 1)
        self.assertEqual(stats["waiting"], 1)
        self.assertEqual(stats["max_followups"], 2)

    def test_the_inbox_check_endpoint_needs_a_password(self):
        with no_env_password:
            response = self.client.post(
                reverse("outreach:check_inbox"), data={},
                content_type="application/json")

        self.assertEqual(response.status_code, 400)

    def test_the_inbox_check_endpoint_surfaces_the_block(self):
        response = self.client.post(
            reverse("outreach:check_inbox"), data={"password": PASSWORD},
            content_type="application/json")

        self.assertEqual(response.status_code, 502)
        self.assertIn("blocked", response.json()["error"])


class FollowUpPromptTests(SignedIn):
    """The prompt has to carry what stops the follow-up repeating the first."""

    def _prompt(self, **kwargs):
        defaults = dict(
            business_name="ABC Company", original_subject="A quick idea",
            original_body="Hi ABC Team,\n\nYour contact page has no form.\n\nSam",
            observation="no contact form", days_since=3, number=1,
            sender_name="Sam", sender_company="7skysolutions",
        )
        defaults.update(kwargs)
        return ai.build_followup_prompt(**defaults)

    def test_the_original_email_is_included_and_labelled(self):
        prompt = self._prompt()

        self.assertIn("Your contact page has no form", prompt)
        self.assertIn("do not restate it", prompt)

    def test_the_gap_and_the_number_are_stated(self):
        prompt = self._prompt(days_since=7, number=2)

        self.assertIn("FOLLOW-UP NUMBER 2", prompt)
        self.assertIn("7 DAY(S) AGO", prompt)

    def test_the_system_prompt_forbids_repeating_the_original(self):
        self.assertIn("do not rewrite or restate", ai.FOLLOWUP_SYSTEM.lower())
        self.assertIn("shorter than the original", ai.FOLLOWUP_SYSTEM.lower())

    def test_the_system_prompt_forbids_mentioning_the_attempt_count(self):
        self.assertIn("how many emails have been sent",
                      ai.FOLLOWUP_SYSTEM.lower())

    def test_a_site_with_no_findings_is_stated_rather_than_implied(self):
        prompt = self._prompt(observation="", findings=[])

        self.assertIn("NO WEBSITE FINDINGS ARE AVAILABLE", prompt)

    def test_the_subject_threads_under_the_original(self):
        self.assertEqual(ai.reply_subject("A quick idea"), "Re: A quick idea")
        self.assertEqual(ai.reply_subject("Re: A quick idea"), "Re: A quick idea")
        self.assertEqual(ai.reply_subject("RE: re: A quick idea"),
                         "Re: A quick idea")

    def test_the_original_subject_wins_over_a_rewritten_one(self):
        parsed = ai.parse_followup(
            '{"subject": "Something else entirely", "body": "Hi.",'
            ' "angle": "shorter"}',
            original_subject="A quick idea for ABC")

        self.assertEqual(parsed.subject, "Re: A quick idea for ABC")

    def test_a_follow_up_with_no_body_is_rejected(self):
        with self.assertRaises(ai.AiError):
            ai.parse_followup('{"subject": "Re: x", "body": "", "angle": "y"}')

    def test_a_follow_up_body_has_nothing_appended(self):
        """A follow-up goes out as written, like a first email."""
        message = compose.build_message(
            sender_name="Sam", sender_email="sam@agency.test",
            to_email="abc@company.test", subject="Re: A quick idea",
            body="Just following up.")

        content = message.get_content()
        self.assertEqual(content.rstrip("\n"), "Just following up.")
        self.assertNotIn("simply reply to this email", content)
