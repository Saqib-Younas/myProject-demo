"""Tests for campaigns, mail, the pipeline and the screens.

`factories.py` holds the three fixtures the rest of the suite shares. Everything else
is grouped by what it tests, and the grouping is worth keeping: a 3,000-line test module
is one a reader scrolls rather than reads.
"""
