from django.urls import path

from . import views
from .views import automation as autoviews
from .views import websiteaudit as auditviews

app_name = "outreach"

urlpatterns = [
    path("start", views.start, name="start"),
    # Unattended campaigns. `automation/new` before `automation/<int:pk>` so the
    # literal path is never read as an id.
    path("automation", autoviews.automation_list, name="automation"),
    path("automation/new", autoviews.automation_new, name="automation_new"),
    path("automation/<int:pk>", autoviews.automation_view,
         name="automation_view"),
    path("automation/<int:pk>/state", autoviews.automation_state,
         name="automation_state"),
    path("automation/<int:pk>/start", autoviews.automation_start,
         name="automation_start"),
    # Auditing one submitted website. Separate from the campaigns in every way
    # that matters: its own job table, its own worker, and no path that sends
    # without somebody pressing Send.
    path("audit", auditviews.audit_list, name="audits"),
    path("audit/new", auditviews.audit_new, name="audit_new"),
    path("audit/<int:pk>", auditviews.audit_view, name="audit_view"),
    path("audit/<int:pk>/state", auditviews.audit_state, name="audit_state"),
    path("audit/<int:pk>/save", auditviews.audit_save, name="audit_save"),
    path("audit/<int:pk>/regenerate", auditviews.audit_regenerate,
         name="audit_regenerate"),
    path("audit/<int:pk>/send", auditviews.audit_send, name="audit_send"),
    path("audit/<int:pk>/retry", auditviews.audit_retry, name="audit_retry"),
    path("history", views.campaign_history, name="history"),
    path("settings", views.settings_view, name="settings"),
    path("history.xlsx", views.history_excel, name="history_excel"),
    path("leads", views.leads, name="leads"),
    path("lead/<int:pk>/intel", views.lead_detail, name="lead_detail"),
    path("lead/<int:pk>/reanalyse", views.lead_reanalyse, name="lead_reanalyse"),
    path("lead/<int:pk>/lifecycle", views.lead_lifecycle, name="lead_lifecycle"),
    path("rescore", views.rescore, name="rescore"),
    # Email accounts. The workspace is the parent; these act on one child by id,
    # and every one re-reads it scoped to the signed-in account.
    path("accounts/save", views.account_save, name="account_save"),
    path("accounts/<int:pk>/edit", views.account_edit,
         name="account_edit"),
    path("accounts/<int:pk>/active", views.account_active, name="account_active"),
    path("accounts/<int:pk>/test", views.account_test, name="account_test"),
    path("accounts/<int:pk>/forget", views.account_forget, name="account_forget"),
    path("accounts/<int:pk>/delete", views.account_delete, name="account_delete"),
    path("followups", views.followups, name="followups"),
    path("followups/check-inbox", views.check_inbox, name="check_inbox"),
    path("lead/<int:pk>/followup", views.followup_create,
         name="followup_create"),
    path("followup/<int:pk>/<str:action>", views.followup_action,
         name="followup_action"),
    path("suppressions", views.suppressions, name="suppressions"),
    path("suppressions/add", views.suppress_add, name="suppress_add"),
    path("suppressions/<int:pk>/remove", views.suppress_remove,
         name="suppress_remove"),
    path("draft/<int:pk>/<str:action>", views.draft_action, name="draft_action"),
    path("<uuid:campaign_id>/setup", views.setup, name="setup"),
    path("<uuid:campaign_id>/run", views.run, name="run"),
    path("<uuid:campaign_id>/state", views.state, name="state"),
    path("<uuid:campaign_id>/resume", views.resume, name="resume"),
    path("<uuid:campaign_id>/cancel", views.cancel, name="cancel"),
    path("<uuid:campaign_id>/accounts", views.campaign_accounts,
         name="campaign_accounts"),
    # Activate / pause / resume / stop. Status is the operator's decision, and is
    # separate from the processing phase.
    path("<uuid:campaign_id>/status/<str:action>", views.campaign_status,
         name="campaign_status"),
    path("<uuid:campaign_id>/dashboard", views.campaign_dashboard,
         name="campaign_dashboard"),
    path("<uuid:campaign_id>/approve-all", views.approve_all, name="approve_all"),
    path("<uuid:campaign_id>/send", views.send, name="send"),
    path("<uuid:campaign_id>/report", views.report, name="report"),
    path("<uuid:campaign_id>/", views.workspace, name="workspace"),
]
