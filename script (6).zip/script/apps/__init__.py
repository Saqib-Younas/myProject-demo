"""Django applications, one per business domain.

The dependency direction is one-way and worth stating, because it is what keeps the
import graph acyclic:

    core  <--  ai  <--  auditing  <--  outreach
                                          ^
                            accounts, leads

  * `core` knows nothing about the others.
  * `ai` talks to language-model providers and owns the credential pool.
  * `auditing` reads and measures websites. It imports no domain app.
  * `leads` finds businesses on public map data.
  * `outreach` is the campaign, email and automation domain, and is the only app
    that imports the others.

Nothing in `ai` or `auditing` imports `outreach`."""
