/*
 * One lead's intelligence page: re-analyse, and set a lifecycle stage.
 *
 * Both are POSTs, because both change something. Re-analysing in particular
 * spends a crawl and an AI call, so it can never be triggered by opening or
 * refreshing the page -- the button is the only way in.
 */
(function () {
  "use strict";

  var script = document.currentScript;
  var URLS = {
    reanalyse: script.dataset.reanalyseUrl,
    lifecycle: script.dataset.lifecycleUrl,
  };

  function status(node, message, kind) {
    if (!node) return;
    var icons = { info: "i-info", ok: "i-check-circle", warn: "i-alert",
                  err: "i-x-circle" };
    node.className = "banner banner-" + (kind || "info");
    node.style.marginTop = "var(--sp-3)";
    node.innerHTML = LMUI.iconMarkup(icons[kind || "info"]) +
      "<span>" + LMUI.escapeHtml(message) + "</span>";
    node.classList.remove("is-hidden");
  }

  /* --- re-analyse -------------------------------------------------------- */

  var button = document.getElementById("reanalyse");
  var box = document.getElementById("reanalyse-status");

  if (button) {
    button.addEventListener("click", function () {
      LMUI.modal({
        title: "Analyse this website again?",
        message: "Crawls the site, reviews it, and recomputes every score. This " +
                 "costs a crawl and one AI call, which is why it is not done " +
                 "automatically when the page opens.",
        iconName: "i-refresh",
        confirmLabel: "Re-analyse",
      }).then(function (go) {
        if (!go) return;
        LMUI.loading(button, true, "Analysing…");
        status(box, "Reading the website. This takes a few seconds.", "info");

        LMUI.postJson(URLS.reanalyse, {})
          .then(function (data) {
            status(box, data.message + " Reloading…", "ok");
            LMUI.ok("Website analysed", data.message);
            window.setTimeout(function () { window.location.reload(); }, 900);
          })
          .catch(function (error) {
            status(box, error.message, "err");
            LMUI.error("Could not analyse", error.message);
            LMUI.loading(button, false);
          });
      });
    });
  }

  /* --- lifecycle --------------------------------------------------------- */

  var lifeBox = document.getElementById("life-status");

  document.addEventListener("click", function (event) {
    var chip = event.target.closest(".life-set");
    if (!chip || chip.disabled) return;

    var stage = chip.dataset.stage;
    var label = chip.textContent.trim();

    LMUI.modal({
      title: "Move this lead to " + label + "?",
      message: "This is a stage the application cannot work out for itself, so " +
               "it stays where you put it and is not overwritten by later " +
               "scoring.",
      iconName: "i-target",
      confirmLabel: "Move to " + label,
      input: {
        label: "Note (optional)",
        placeholder: 'e.g. "call booked for Thursday"',
        rows: 2,
      },
    }).then(function (note) {
      if (note === false) return;
      chip.disabled = true;
      LMUI.postJson(URLS.lifecycle, { stage: stage, note: note })
        .then(function (data) {
          status(lifeBox, data.message + " Reloading…", "ok");
          LMUI.ok("Stage updated", data.message);
          window.setTimeout(function () { window.location.reload(); }, 700);
        })
        .catch(function (error) {
          chip.disabled = false;
          status(lifeBox, error.message, "err");
          LMUI.error("Could not update the stage", error.message);
        });
    });
  });
})();
