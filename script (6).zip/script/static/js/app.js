/*
 * Lead Mapper front end.
 *
 * Submits the search form to the Django backend, drops a marker for every lead
 * it gets back, and reveals the Download CSV button once the run is finished.
 */
(function () {
  "use strict";

  var form = document.getElementById("search-form");
  var submitBtn = document.getElementById("submit-btn");
  var categorySelect = document.getElementById("category");
  var customField = document.getElementById("custom-field");
  var customInput = document.getElementById("custom-category");
  var statusCard = document.getElementById("status-card");
  var statusText = document.getElementById("status-text");
  var downloadBtn = document.getElementById("download-btn");
  var resultsCard = document.getElementById("results-card");
  var resultsList = document.getElementById("results-list");
  var resultsCount = document.getElementById("results-count");
  var mapEmpty = document.getElementById("map-empty");
  var pickAll = document.getElementById("pick-all");
  var pickSummary = document.getElementById("pick-summary");
  var nextBtn = document.getElementById("next-btn");
  var countryInput = document.getElementById("country");
  var cityInput = document.getElementById("city");
  var countryNote = document.getElementById("country-note");
  var cityNote = document.getElementById("city-note");
  var leadSplit = document.getElementById("lead-split");
  var leadFilters = document.getElementById("lead-filters");
  var selectNewBtn = document.getElementById("select-new-btn");

  // The current result set, kept so the Next button can hand it to the email
  // workflow without re-running the search.
  var currentLeads = [];
  var currentArea = null;
  var currentCategory = "";
  var leadFilter = "all";

  // Badge vocabulary, mirroring STATES in outreach/history.py.
  var STATE = {
    new: { label: "New", icon: "i-check-circle" },
    ready: { label: "Ready", icon: "i-mail" },
    contacted: { label: "Already contacted", icon: "i-clock" },
    suppressed: { label: "Do not contact", icon: "i-shield" },
    invalid: { label: "No email", icon: "i-alert" },
  };

  // States that make a lead unselectable. `contacted` is a history match the
  // user may override inside a campaign; `suppressed` never is.
  var BLOCKED_STATES = { contacted: 1, suppressed: 1 };

  /* --- country and city -------------------------------------------------
   *
   * The city list depends on the country, so the city field stays disabled
   * until a country is chosen and is cleared whenever the country changes --
   * leaving a stale city behind is how you end up searching Berlin, Pakistan.
   *
   * Both fields remain free-text on purpose: the reference dataset stops at
   * roughly 15,000 population, and the geocoder resolves much smaller places.
   * Cross-country contradictions are what get rejected, not mere absence.
   */

  var script = document.currentScript;
  var CITIES_URL = script ? script.dataset.citiesUrl : "/api/cities";

  function readJson(id, fallback) {
    var node = document.getElementById(id);
    if (!node) return fallback;
    try { return JSON.parse(node.textContent) || fallback; }
    catch (error) { return fallback; }
  }

  var countryBox = LMUI.combobox(countryInput, {
    options: readJson("country-data", []),
    emptyText: "No country matches — check the spelling.",
    onSelect: function (name) { loadCities(name, { reset: true }); },
  });

  var cityBox = LMUI.combobox(cityInput, {
    options: readJson("initial-city-data", []),
    emptyText: "Not in the reference list — it will still be geocoded as typed.",
    onSelect: function () { setNote(cityNote, "", "ok"); },
  });

  function setNote(node, message, kind) {
    if (!node) return;
    node.className = "field-note" + (kind ? " is-" + kind : "");
    node.querySelector("span").textContent = message;
    node.classList.toggle("is-hidden", !message);
  }

  /** Fetch the city list for a country and rebind the city combobox. */
  function loadCities(country, options) {
    options = options || {};
    var name = (country || "").trim();

    if (options.reset) {
      cityInput.value = "";
      cityBox.clear();
    }

    if (!name) {
      cityBox.setOptions([]);
      cityInput.disabled = true;
      cityInput.placeholder = "Select a country first";
      setNote(cityNote, "", "");
      setNote(countryNote,
              "Pick a country to load its cities. Leave blank to search by " +
              "place name alone.", "");
      return Promise.resolve();
    }

    cityInput.disabled = true;
    cityInput.placeholder = "Loading cities…";
    setNote(cityNote, "Loading cities for " + name + "…", "");

    return fetch(CITIES_URL + "?country=" + encodeURIComponent(name))
      .then(function (response) { return response.json(); })
      .then(function (data) {
        var cities = data.cities || [];
        cityBox.setOptions(cities);
        cityInput.disabled = false;
        cityInput.placeholder = cities.length
          ? "Type to search " + cities.length + " cities…"
          : "Type the place name…";

        if (data.note) {
          setNote(cityNote, data.note, "warn");
        } else {
          setNote(cityNote, cities.length + " cities available — or type any " +
                  "smaller place and it will still be geocoded.", "");
        }
        setNote(countryNote, data.code
          ? "Cities loaded for " + data.country + "."
          : name + " is not in the reference data.", data.code ? "ok" : "warn");
      })
      .catch(function () {
        // A failed lookup must not lock the user out of searching.
        cityInput.disabled = false;
        cityInput.placeholder = "Type the city name…";
        setNote(cityNote,
                "Could not load the city list — type the city name instead.",
                "warn");
      });
  }

  // Typing a country by hand (rather than picking) still drives the city list,
  // but only once it resolves to something real.
  countryInput.addEventListener("change", function () {
    loadCities(countryInput.value, { reset: true });
  });

  /* --- map ------------------------------------------------------------- */

  var map = L.map("map", { zoomControl: true }).setView([20, 10], 2);

  L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution:
      '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
  }).addTo(map);

  var markerLayer = L.layerGroup().addTo(map);
  var markers = [];
  var activeMarker = null;

  var pinIcon = L.divIcon({
    className: "",
    html: '<div class="pin"></div>',
    iconSize: [26, 26],
    iconAnchor: [13, 26],
    popupAnchor: [0, -26],
  });

  /* --- helpers --------------------------------------------------------- */

  function escapeHtml(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function getCookie(name) {
    var match = document.cookie.match(
      new RegExp("(?:^|; )" + name + "=([^;]*)")
    );
    return match ? decodeURIComponent(match[1]) : "";
  }

  /** Render the status banner. `kind` is info | ok | warn | err. */
  function setStatus(message, kind) {
    kind = kind || "info";
    var iconName = { info: "i-info", ok: "i-check-circle", warn: "i-alert",
                     err: "i-x-circle" }[kind];
    statusCard.classList.remove("is-hidden");
    statusText.className = "banner banner-" + kind;
    statusText.innerHTML = LMUI.iconMarkup(iconName) +
      "<span>" + message + "</span>";
  }

  function setLoading(on) {
    LMUI.loading(submitBtn, on, "Collecting…");
  }

  function clearResults() {
    markerLayer.clearLayers();
    markers = [];
    activeMarker = null;
    resultsList.innerHTML = "";
    resultsCard.classList.add("is-hidden");
    downloadBtn.classList.add("is-hidden");
    currentLeads = [];
    currentArea = null;
    leadSplit.classList.add("is-hidden");
    leadFilters.classList.add("is-hidden");
    selectNewBtn.classList.add("is-hidden");
    if (pickAll) {
      pickAll.checked = false;
      pickAll.indeterminate = false;
    }
  }

  /* --- lead selection for the email workflow --------------------------- */

  function pickBoxes() {
    return Array.prototype.slice.call(
      resultsList.querySelectorAll(".pick:not(:disabled)")
    );
  }

  /** A lead is contactable only if it has an email and nothing blocks it. */
  function contactable(lead) {
    return Boolean(lead.email) && !BLOCKED_STATES[lead.contact_state];
  }

  /** The headline split the search screen reports. */
  function renderSplit(counts) {
    if (!counts) { leadSplit.classList.add("is-hidden"); return; }
    var cells = [
      ["split-cell", counts.total, "Found"],
      ["split-cell split-cell-ok", counts.available, "Available"],
      ["split-cell split-cell-warn", counts.contacted, "Contacted"],
    ];
    // Only shown when it applies -- an always-zero cell is noise.
    if (counts.suppressed) {
      cells.push(["split-cell split-cell-err", counts.suppressed, "Do not contact"]);
    }
    leadSplit.innerHTML = cells.map(function (row) {
      return '<div class="' + row[0] + '"><div class="split-n">' + row[1] +
        '</div><div class="split-k">' + row[2] + "</div></div>";
    }).join("");
    leadSplit.classList.remove("is-hidden");
    leadFilters.classList.remove("is-hidden");
    selectNewBtn.classList.toggle(
      "is-hidden", !(counts.contacted || counts.suppressed));
  }

  function applyLeadFilter() {
    Array.prototype.forEach.call(resultsList.children, function (li) {
      var match = leadFilter === "all" || li.dataset.state === leadFilter;
      li.classList.toggle("is-hidden", !match);
    });
  }

  function pickedIndexes() {
    return pickBoxes()
      .filter(function (box) { return box.checked; })
      .map(function (box) { return Number(box.value); });
  }

  function refreshPicks() {
    var boxes = pickBoxes();
    var picked = pickedIndexes();
    var withoutEmail = currentLeads.length - boxes.length;

    nextBtn.disabled = picked.length === 0;
    if (pickAll) {
      pickAll.checked = picked.length === boxes.length && boxes.length > 0;
      pickAll.indeterminate = picked.length > 0 && picked.length < boxes.length;
      pickAll.disabled = boxes.length === 0;
    }

    var contacted = currentLeads.filter(function (l) {
      return l.contact_state === "contacted";
    }).length;
    var suppressed = currentLeads.filter(function (l) {
      return l.contact_state === "suppressed";
    }).length;
    var noEmail = withoutEmail - contacted - suppressed;

    var text = "<b>" + picked.length + "</b> of " + boxes.length +
      " contactable lead" + (boxes.length === 1 ? "" : "s") + " selected";
    var extra = [];
    if (contacted > 0) extra.push(contacted + " already contacted");
    if (suppressed > 0) extra.push(suppressed + " on the do-not-contact list");
    if (noEmail > 0) extra.push(noEmail + " without an email");
    if (extra.length) text += " · " + extra.join(" · ");
    pickSummary.innerHTML = text;
  }

  function highlight(marker) {
    [activeMarker, marker].forEach(function (m) {
      if (!m) return;
      var el = m.getElement();
      if (el) {
        var pin = el.querySelector(".pin");
        if (pin) pin.classList.toggle("is-active", m === marker);
      }
    });
    activeMarker = marker;
  }

  /* --- rendering ------------------------------------------------------- */

  function popupHtml(lead) {
    var rows = [
      ["Address", escapeHtml(lead.address) || "—"],
      [
        "Phone",
        lead.phone
          ? '<a href="tel:' + escapeHtml(lead.phone.replace(/\s+/g, "")) + '">' +
            escapeHtml(lead.phone) + "</a>"
          : "—",
      ],
      [
        "Website",
        lead.website
          ? '<a href="' + escapeHtml(lead.website) +
            '" target="_blank" rel="noopener noreferrer">' +
            escapeHtml(lead.website.replace(/^https?:\/\//, "").replace(/\/$/, "")) +
            "</a>"
          : "—",
      ],
    ];

    if (lead.email) {
      rows.push([
        "Email",
        '<a href="mailto:' + escapeHtml(lead.email) + '">' +
          escapeHtml(lead.email) + "</a>",
      ]);
    }

    var body = rows
      .map(function (row) {
        return (
          '<div class="popup-row"><dt>' + row[0] + "</dt><dd>" + row[1] + "</dd></div>"
        );
      })
      .join("");

    return (
      '<h3 class="popup-name">' + escapeHtml(lead.business_name) + "</h3>" +
      '<span class="popup-category">' + escapeHtml(lead.category) + "</span>" +
      "<dl>" + body + "</dl>" +
      '<a class="popup-source" href="' + escapeHtml(lead.source) +
      '" target="_blank" rel="noopener noreferrer">Source: OpenStreetMap ↗</a>'
    );
  }

  function resultItem(lead, index) {
    var item = document.createElement("li");

    // Only leads with a published email can enter the email workflow, so the
    // rest get a disabled box rather than being hidden.
    var pick = document.createElement("input");
    pick.type = "checkbox";
    pick.className = "check pick";
    pick.value = String(index);
    var ok = contactable(lead);
    pick.checked = ok;
    pick.disabled = !ok;
    pick.title = ok
      ? "Include " + lead.business_name + " in an email campaign"
      : ({
          contacted: "Already contacted — excluded to prevent a duplicate email",
          suppressed: "On the do-not-contact list — never emailed",
        }[lead.contact_state] || "No public email address — cannot be emailed");
    pick.setAttribute("aria-label", pick.title);
    pick.addEventListener("change", refreshPicks);
    item.appendChild(pick);

    var button = document.createElement("button");
    button.type = "button";
    button.className = "result";

    var meta = lead.address || lead.city || "";
    var tags = [
      ["Phone", "i-phone", Boolean(lead.phone)],
      ["Email", "i-mail", Boolean(lead.email)],
      ["Site", "i-globe", Boolean(lead.website)],
    ]
      .map(function (tag) {
        return '<span class="tag' + (tag[2] ? " has" : "") + '">' +
          LMUI.iconMarkup(tag[2] ? "i-check" : tag[1]) + tag[0] + "</span>";
      })
      .join("");

    var state = lead.contact_state || (lead.email ? "new" : "invalid");
    var spec = STATE[state] || STATE.new;
    var badge = '<span class="state state-' + state + '">' +
      LMUI.iconMarkup(spec.icon) + spec.label + "</span>";

    var note = "";
    if (lead.suppression) {
      note = '<span class="history-note">Do not contact · ' +
        escapeHtml(lead.suppression.reason_label.toLowerCase()) +
        (lead.suppression.matched_by === "domain"
          ? " · whole domain " + escapeHtml(lead.suppression.target) : "") +
        (lead.suppression.note ? " · " + escapeHtml(lead.suppression.note) : "") +
        "</span>";
    } else if (lead.history) {
      note = '<span class="history-note">Sent ' +
        escapeHtml(lead.history.sent_date || "earlier") +
        (lead.history.campaign ? " · " + escapeHtml(lead.history.campaign) : "") +
        " · matched on " + escapeHtml(lead.history.matched_by_label) + "</span>";
    }

    button.innerHTML =
      '<span class="result-name"><span class="result-i">' + (index + 1) +
      "</span>" + escapeHtml(lead.business_name) + "</span>" +
      '<span class="result-meta">' + escapeHtml(lead.category) +
      (meta ? " · " + escapeHtml(meta) : "") + "</span>" + note +
      '<span class="result-tags">' + badge + tags + "</span>";

    button.addEventListener("click", function () {
      var marker = markers[index];
      map.flyTo(marker.getLatLng(), Math.max(map.getZoom(), 16), { duration: 0.6 });
      marker.openPopup();
    });

    item.appendChild(button);
    item.dataset.state = state;
    item.classList.toggle("is-contacted", state === "contacted");
    item.classList.toggle("is-suppressed", state === "suppressed");
    item.classList.toggle("is-blocked", !ok);
    return item;
  }

  function render(data) {
    var bounds = [];
    currentLeads = data.leads;
    currentArea = data.area;

    data.leads.forEach(function (lead, index) {
      var marker = L.marker([lead.latitude, lead.longitude], { icon: pinIcon })
        .bindPopup(popupHtml(lead), { maxWidth: 300, minWidth: 240 })
        .addTo(markerLayer);

      marker.on("popupopen", function () { highlight(marker); });
      marker.on("popupclose", function () { highlight(null); });

      markers.push(marker);
      bounds.push([lead.latitude, lead.longitude]);
      resultsList.appendChild(resultItem(lead, index));
    });

    resultsCount.textContent = data.count;
    resultsCard.classList.remove("is-hidden");
    mapEmpty.classList.add("is-hidden");

    renderSplit(data.history);
    leadFilter = "all";
    Array.prototype.forEach.call(leadFilters.children, function (chip) {
      chip.classList.toggle("is-active", chip.dataset.lf === "all");
    });
    applyLeadFilter();
    refreshPicks();

    if (data.history && data.history.contacted) {
      LMUI.warn(
        data.history.contacted + " lead(s) already contacted",
        "Excluded from selection so nobody receives a second email."
      );
    }

    if (bounds.length === 1) {
      map.setView(bounds[0], 15);
    } else {
      map.fitBounds(bounds, { padding: [50, 50] });
    }

    downloadBtn.href = data.download_url;
    downloadBtn.setAttribute("download", data.csv_filename);
    downloadBtn.classList.remove("is-hidden");

    var place = [data.area.city, data.area.country].filter(Boolean).join(", ");
    var shortfall =
      data.count < data.requested
        ? " That is all OpenStreetMap has mapped here for this category."
        : "";

    setStatus(
      "Collected <strong>" + data.count + "</strong> of " + data.requested +
        " requested leads in <strong>" + escapeHtml(place) + "</strong>." +
        shortfall + " The CSV <code>" + escapeHtml(data.csv_filename) +
        "</code> is ready.",
      data.count < data.requested ? "warn" : "ok"
    );
    LMUI.ok(data.count + " leads collected",
            place + " · CSV ready to download");
  }

  /* --- form ------------------------------------------------------------ */

  categorySelect.addEventListener("change", function () {
    var custom = categorySelect.value === "__custom__";
    customField.classList.toggle("is-hidden", !custom);
    if (custom) customInput.focus();
  });

  if (pickAll) {
    pickAll.addEventListener("change", function () {
      pickBoxes().forEach(function (box) { box.checked = pickAll.checked; });
      refreshPicks();
    });
  }

  leadFilters.addEventListener("click", function (event) {
    var chip = event.target.closest(".chip");
    if (!chip) return;
    leadFilter = chip.dataset.lf;
    Array.prototype.forEach.call(this.children, function (other) {
      other.classList.toggle("is-active", other === chip);
    });
    applyLeadFilter();
  });

  selectNewBtn.addEventListener("click", function () {
    pickBoxes().forEach(function (box) {
      box.checked = currentLeads[Number(box.value)].contact_state === "new";
    });
    refreshPicks();
    LMUI.info("New leads selected",
              "Already-contacted businesses stay excluded.");
  });

  // Step 1 -> 2: hand the ticked leads to the email workflow.
  nextBtn.addEventListener("click", function () {
    var picked = pickedIndexes().map(function (i) { return currentLeads[i]; });
    if (!picked.length) return;

    LMUI.loading(nextBtn, true, "Creating campaign…");
    setStatus("Creating an email campaign for " + picked.length + " lead(s)…",
              "info");

    fetch("/outreach/start", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFToken": getCookie("csrftoken"),
      },
      body: JSON.stringify({
        leads: picked,
        area: currentArea,
        category: currentCategory,
      }),
    })
      .then(function (response) {
        return response.json()
          .catch(function () {
            throw new Error("The server returned an unexpected response.");
          })
          .then(function (data) {
            if (!response.ok) throw new Error(data.error || "Could not start.");
            return data;
          });
      })
      .then(function (data) {
        window.location.href = data.setup_url;
      })
      .catch(function (error) {
        setStatus(escapeHtml(error.message), "err");
        LMUI.error("Could not start the campaign", error.message);
        LMUI.loading(nextBtn, false);
        refreshPicks();
      });
  });

  form.addEventListener("submit", function (event) {
    event.preventDefault();

    var city = cityInput.value.trim();
    var country = countryInput.value.trim();
    var category =
      categorySelect.value === "__custom__"
        ? customInput.value.trim()
        : categorySelect.value;

    if (!city) {
      setStatus("Enter a city or location to search.", "err");
      LMUI.warn("Location required", "Enter a city or location to search.");
      cityInput.focus();
      return;
    }

    // Client-side mirror of the server's check, so the mistake is caught before
    // a request goes out. The server validates again regardless -- this is a
    // convenience, not the guard.
    if (country && cityBox.getOptions().length && !cityBox.matches()) {
      setNote(cityNote,
              '"' + city + '" is not in the list for ' + country +
              " — it will be geocoded as typed.", "warn");
    }
    if (!category) {
      setStatus("Type the business category you want to collect.", "err");
      LMUI.warn("Category required", "Type the business category to collect.");
      customInput.focus();
      return;
    }

    var payload = {
      country: country,
      city: city,
      category: category,
      limit: parseInt(document.getElementById("limit").value, 10) || 50,
    };
    currentCategory = category;

    clearResults();
    setLoading(true);
    setStatus("Locating <strong>" + escapeHtml(city) + "</strong>…");

    // The Overpass call is the slow part -- say so rather than sit silent.
    var progress = window.setTimeout(function () {
      setStatus("Querying OpenStreetMap for businesses… this can take a moment.");
    }, 1200);

    fetch("/api/search", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFToken": getCookie("csrftoken"),
      },
      body: JSON.stringify(payload),
    })
      .then(function (response) {
        return response
          .json()
          .catch(function () {
            throw new Error("The server returned an unexpected response.");
          })
          .then(function (data) {
            if (!response.ok) throw new Error(data.error || "Search failed.");
            return data;
          });
      })
      .then(render)
      .catch(function (error) {
        setStatus(escapeHtml(error.message), "err");
        LMUI.error("Search failed", error.message);
      })
      .finally(function () {
        window.clearTimeout(progress);
        setLoading(false);
      });
  });

  /* --- boot ------------------------------------------------------------ */

  // Restore a category handed over in the query string, so "search again" from
  // a campaign reproduces the whole original search, not just the place.
  var initialCategory = script ? script.dataset.initialCategory : "";
  if (initialCategory) {
    var found = Array.prototype.some.call(categorySelect.options, function (o) {
      if (o.value !== initialCategory) return false;
      categorySelect.value = initialCategory;
      return true;
    });
    if (!found) {
      categorySelect.value = "__custom__";
      customField.classList.remove("is-hidden");
      customInput.value = initialCategory;
    }
  }

  // A restored country arrives with its cities already rendered server-side;
  // this just brings the notes in line.
  if (countryInput.value.trim()) {
    loadCities(countryInput.value, { reset: false });
  }

  refreshPicks();
})();
