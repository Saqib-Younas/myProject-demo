/*
 * Login and signup: live validation, password reveal, strength guidance.
 *
 * The rule this file follows: **it never decides anything.** Every check here is
 * also performed on the server, and the server's answer wins. That matters in
 * two directions --
 *
 *   * it must not block a submit the server would have accepted, so the only
 *     hard stops are the ones the server also enforces exactly (empty, email
 *     shape, minimum length, confirmation match);
 *   * it must not promise that a password is acceptable, because Django also
 *     checks it against a list of twenty thousand common passwords and against
 *     the user's own name and email. The strength meter therefore describes the
 *     password rather than approving it.
 *
 * If this file fails to load, the forms still work and are still validated.
 */
(function () {
  "use strict";

  var form = document.getElementById("auth-form");
  if (!form) return;

  var KIND = form.dataset.form;                 // "login" | "signup"
  var MIN_PASSWORD = 10;                        // matches MinimumLengthValidator
  var formError = document.getElementById("form-error");
  var submit = form.querySelector(".auth-submit");

  function field(name) {
    return form.querySelector('[data-field="' + name + '"]');
  }

  function input(name) {
    var wrap = field(name);
    return wrap ? wrap.querySelector(".input") : null;
  }

  /* --- one field's verdict ---------------------------------------------- */

  /** Show a message against a field, or clear it. */
  function judge(name, message) {
    var wrap = field(name);
    if (!wrap) return;
    var box = wrap.querySelector(".field-error");
    var control = wrap.querySelector(".input");

    if (message) {
      wrap.classList.add("is-invalid");
      wrap.classList.remove("is-valid");
      if (box) box.textContent = message;
      if (control) {
        control.setAttribute("aria-invalid", "true");
        if (box) control.setAttribute("aria-describedby", box.id);
      }
    } else {
      wrap.classList.remove("is-invalid");
      if (box) box.textContent = "";
      if (control) control.removeAttribute("aria-invalid");
    }
  }

  /** Mark a field as satisfied. Only ever "looks right so far". */
  function accept(name) {
    var wrap = field(name);
    if (!wrap) return;
    judge(name, "");
    var control = wrap.querySelector(".input");
    if (control && control.value.trim()) wrap.classList.add("is-valid");
    else wrap.classList.remove("is-valid");
  }

  /* --- the checks, mirroring the server -------------------------------- */

  // Deliberately permissive: a browser is the wrong place to be strict about
  // what an address may contain, and the server uses Django's own validator.
  var EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  var CHECKS = {
    name: function (value) {
      if (!value.trim()) return "Enter your name.";
      return "";
    },
    email: function (value) {
      if (!value.trim()) return "Enter your email address.";
      if (!EMAIL.test(value.trim())) {
        return "That does not look like an email address.";
      }
      return "";
    },
    password: function (value) {
      if (!value) return "Enter a password.";
      if (KIND === "signup" && value.length < MIN_PASSWORD) {
        return "Use at least " + MIN_PASSWORD + " characters.";
      }
      return "";
    },
    confirm_password: function (value) {
      var password = input("password");
      if (!value) return "Type the password again.";
      if (password && value !== password.value) {
        return "The two passwords do not match.";
      }
      return "";
    },
  };

  function check(name, options) {
    var control = input(name);
    if (!control) return true;
    var problem = (CHECKS[name] || function () { return ""; })(control.value);

    if (problem) {
      // While typing, an error is only *removed*, never added -- telling somebody
      // their half-typed address is invalid on the third keystroke is noise.
      if (options && options.quiet) return false;
      judge(name, problem);
      return false;
    }
    accept(name);
    return true;
  }

  /* --- password strength, as description not permission ---------------- */

  var meter = document.getElementById("pw-meter");
  var note = document.getElementById("pw-note");
  var DEFAULT_NOTE = note ? note.textContent.trim() : "";

  function describe(value) {
    if (!meter) return;

    if (!value) {
      meter.dataset.score = "0";
      if (note) note.textContent = DEFAULT_NOTE;
      return;
    }

    var classes = 0;
    if (/[a-z]/.test(value)) classes += 1;
    if (/[A-Z]/.test(value)) classes += 1;
    if (/[0-9]/.test(value)) classes += 1;
    if (/[^A-Za-z0-9]/.test(value)) classes += 1;

    var score = 1;
    var advice = "";

    if (value.length < MIN_PASSWORD) {
      score = 1;
      advice = (MIN_PASSWORD - value.length) + " more character" +
               (MIN_PASSWORD - value.length === 1 ? "" : "s") + " needed";
    } else if (/^\d+$/.test(value)) {
      // Django rejects an all-numeric password outright, so say so rather than
      // scoring it and letting the server surprise the user.
      score = 1;
      advice = "all digits — add letters";
    } else if (value.length >= 16 && classes >= 2) {
      score = 4;
      advice = "long";
    } else if (value.length >= 12 || classes >= 3) {
      score = 3;
      advice = "reasonable";
    } else {
      score = 2;
      advice = "a longer one is harder to guess";
    }

    var words = ["", "Weak", "Fair", "Good", "Strong"];
    meter.dataset.score = String(score);
    if (note) {
      note.innerHTML = "<b>" + words[score] + "</b>" +
        (advice ? " — " + escapeText(advice) : "");
    }
  }

  function escapeText(value) {
    var holder = document.createElement("span");
    holder.textContent = value;
    return holder.innerHTML;
  }

  /* --- wiring ----------------------------------------------------------- */

  Object.keys(CHECKS).forEach(function (name) {
    var control = input(name);
    if (!control) return;

    // On blur: judge it. This is the moment the user has finished with the field.
    control.addEventListener("blur", function () {
      if (control.value || control.dataset.touched) check(name);
      control.dataset.touched = "1";
    });

    // While typing: clear a message the user has just fixed, and keep the
    // strength meter and the match indicator current.
    control.addEventListener("input", function () {
      if (field(name).classList.contains("is-invalid")) check(name, { quiet: true });

      if (name === "password") {
        describe(control.value);
        var confirm = input("confirm_password");
        // Re-judge the confirmation, but only once it has been typed in.
        if (confirm && confirm.value) check("confirm_password", { quiet: true });
      }
      if (name === "confirm_password" && control.value) {
        check("confirm_password", { quiet: true });
      }
    });
  });

  // Reveal. `aria-pressed` carries the state for a screen reader; the icon and
  // the label carry it for everybody else.
  form.addEventListener("click", function (event) {
    var toggle = event.target.closest(".auth-reveal");
    if (!toggle) return;

    var control = document.getElementById(toggle.dataset.target);
    if (!control) return;

    var showing = control.type === "text";
    control.type = showing ? "password" : "text";
    toggle.setAttribute("aria-pressed", showing ? "false" : "true");
    toggle.setAttribute("aria-label", showing ? "Show password" : "Hide password");
    toggle.querySelector("use").setAttribute(
      "href", showing ? "#i-eye" : "#i-eye-off");
    // Keep the caret where it was rather than jumping to the end.
    var at = control.value.length;
    control.focus();
    try { control.setSelectionRange(at, at); } catch (error) { /* type change */ }
  });

  // Caps Lock, which is the usual reason a correctly-typed password is refused.
  var caps = document.getElementById("caps-warning");
  if (caps) {
    form.addEventListener("keyup", function (event) {
      if (typeof event.getModifierState !== "function") return;
      var on = event.getModifierState("CapsLock");
      var inPassword = event.target && event.target.type === "password";
      caps.classList.toggle("is-on", Boolean(on) && inPassword);
    });
  }

  /* --- submit ----------------------------------------------------------- */

  function showFormError(message) {
    if (!formError) return;
    formError.querySelector("span").textContent = message;
    formError.classList.remove("is-hidden");
  }

  form.addEventListener("submit", function (event) {
    // A second click while the first request is in flight would create two
    // accounts, or two login attempts.
    if (form.dataset.submitting === "1") {
      event.preventDefault();
      return;
    }

    var firstBad = null;
    Object.keys(CHECKS).forEach(function (name) {
      if (!input(name)) return;
      if (!check(name) && !firstBad) firstBad = name;
    });

    if (firstBad) {
      event.preventDefault();
      showFormError("Check the highlighted fields and try again.");
      var control = input(firstBad);
      if (control) control.focus();
      return;
    }

    form.dataset.submitting = "1";
    if (submit) {
      submit.disabled = true;
      submit.classList.add("is-loading");
      var label = submit.querySelector(".btn-label");
      if (label) {
        label.dataset.idle = label.textContent;
        label.textContent = KIND === "signup" ? "Creating…" : "Signing in…";
      }
    }
  });

  // Returning with the back button shows the cached page with the button still
  // disabled, which looks broken.
  window.addEventListener("pageshow", function (event) {
    if (!event.persisted) return;
    form.dataset.submitting = "";
    if (submit) {
      submit.disabled = false;
      submit.classList.remove("is-loading");
      var label = submit.querySelector(".btn-label");
      if (label && label.dataset.idle) label.textContent = label.dataset.idle;
    }
  });

  // A browser that restored a saved password fills the fields without firing
  // `input`, so the meter would sit at zero under a full password box.
  window.setTimeout(function () {
    var password = input("password");
    if (password && password.value) describe(password.value);
  }, 120);
})();
