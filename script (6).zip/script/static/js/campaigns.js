/*
 * Campaign controls (§22): activate, pause, resume, stop.
 *
 * Used by two screens -- a row on the campaigns list and the header of one
 * campaign's report -- so it binds one delegated listener to the document and
 * finds the campaign from the nearest `[data-campaign]` ancestor rather than
 * assuming a table.
 *
 * The rules this file keeps:
 *
 *   1. The server decides. A button posts an action and repaints from the answer;
 *      it never assumes the transition was allowed. `campaigns.controls()` only
 *      offers what the transition table accepts, and the table is checked again on
 *      the way in, so a stale page cannot force one through.
 *   2. Pausing and stopping say what they keep before they happen. Both read as
 *      destructive and neither is: every sent record, prepared follow-up and reply
 *      survives, and only future sends stop.
 *   3. Nothing is hidden afterwards. The server's own wording is shown, including
 *      the count of already-prepared follow-ups that will now sit still.
 */
(function () {
  "use strict";

  var script = document.currentScript;
  var STATUS_URL = script.dataset.statusUrl;
  if (!STATUS_URL) return;

  var ZERO_UUID = "00000000-0000-0000-0000-000000000000";

  function statusUrl(id, action) {
    return STATUS_URL.replace(ZERO_UUID, encodeURIComponent(id))
      .replace("ACTION", encodeURIComponent(action));
  }

  /* Pause and stop are worth a sentence first: both read as destructive, and what
     they actually do is stop future sends and keep everything else. */
  var ASKS = {
    pause: {
      title: "Pause this campaign?",
      message: "No further emails will be sent and no follow-ups will be " +
               "prepared. Everything already sent, scheduled or replied to is " +
               "kept, and resuming carries on from where it stopped.",
      confirmLabel: "Pause",
    },
    stop: {
      title: "Stop this campaign?",
      message: "Nothing further will be sent. The history is kept, and it can be " +
               "reactivated later if that turns out to be wrong.",
      confirmLabel: "Stop",
      confirmClass: "btn-danger-ghost",
      kind: "warn",
    },
  };

  var PILL = {
    active: "pill-ok",
    paused: "pill-warn",
    stopped: "pill-err",
    failed: "pill-err",
    completed: "pill-brand",
  };

  /**
   * Show the new status, then reload.
   *
   * Which controls a campaign offers depends on the status it is now in, and
   * working that out again in the browser is how the two drift apart -- so the
   * status is updated in place, the buttons are disabled, and the page is reloaded
   * for the set that matches. One extra request, and no second copy of the
   * transition table.
   */
  function settle(scope, data) {
    var pill = scope.querySelector(".status-pill");
    if (pill) {
      pill.className = "pill status-pill " + (PILL[data.status] || "");
      pill.textContent = data.status_label;
      if (data.status_note) pill.title = data.status_note;
    }
    scope.querySelectorAll(".campaign-control").forEach(function (button) {
      button.disabled = true;
    });
    window.setTimeout(function () { window.location.reload(); }, 1400);
  }

  function run(button, scope, action) {
    LMUI.loading(button, true, "Working…");
    LMUI.postJson(statusUrl(scope.dataset.campaign, action), {})
      .then(function (data) {
        settle(scope, data);
        LMUI.ok(data.status_label, data.message);
      })
      .catch(function (error) {
        LMUI.loading(button, false);
        // A refusal is information, not a failure: the campaign is somewhere the
        // transition is not allowed from, and the server says which.
        LMUI.error("Not changed", error.message);
      });
  }

  document.addEventListener("click", function (event) {
    var button = event.target.closest(".campaign-control");
    if (!button) return;
    var scope = button.closest("[data-campaign]");
    if (!scope || !scope.dataset.campaign) return;

    var action = button.dataset.action;
    var ask = ASKS[action];
    if (!ask) return run(button, scope, action);

    LMUI.modal(ask).then(function (ok) {
      if (ok) run(button, scope, action);
    });
  });
})();
