/*
 * Replies and follow-ups.
 *
 * Two jobs: check the inbox, and drive one follow-up draft per lead through
 * create -> review -> send. Nothing here sends without a click on Send
 * follow-up, and the server re-checks everything before it opens a connection —
 * this file is presentation only.
 */
(function () {
  "use strict";

  var script = document.currentScript;
  var CHECK_URL = script.dataset.checkUrl;
  var HAS_PASSWORD = script.dataset.hasPassword === "1";

  var $ = function (id) { return document.getElementById(id); };
  var checkBtn = $("check-inbox");
  var inboxStatus = $("inbox-status");
  var statsEl = $("fu-stats");

  function setStatus(message, kind) {
    var icons = { info: "i-info", ok: "i-check-circle", warn: "i-alert",
                  err: "i-x-circle" };
    inboxStatus.className = "banner banner-" + (kind || "info");
    inboxStatus.style.marginTop = "var(--sp-4)";
    inboxStatus.innerHTML = LMUI.iconMarkup(icons[kind || "info"]) +
      "<span>" + message + "</span>";
    inboxStatus.classList.remove("is-hidden");
  }

  function renderStats(stats) {
    if (!stats || !statsEl) return;
    Object.keys(stats).forEach(function (key) {
      var cell = statsEl.querySelector('[data-stat="' + key + '"]');
      if (cell) cell.textContent = stats[key];
    });
  }

  /** Ask for the mailbox password unless it is already in the environment. */
  function withPassword(title, message, confirmLabel) {
    if (HAS_PASSWORD) {
      return LMUI.modal({
        title: title, message: message + " Using OUTREACH_SMTP_PASSWORD.",
        kind: "warn", confirmLabel: confirmLabel,
      }).then(function (go) { return go ? "" : false; });
    }
    return LMUI.modal({
      title: title, message: message, kind: "warn", confirmLabel: confirmLabel,
      input: { label: "Mailbox password", placeholder: "App password",
               password: true },
    }).then(function (value) {
      if (value === false) return false;
      if (!value || !String(value).trim()) return false;
      return String(value).trim();
    });
  }

  /* --- inbox check ------------------------------------------------------ */

  checkBtn.addEventListener("click", function () {
    withPassword(
      "Check the inbox for replies?",
      "Reads the sending account's recent mail, records replies to emails sent " +
      "from here, and ignores everything else. Nothing is sent and nothing is " +
      "marked read.",
      "Check inbox"
    ).then(function (password) {
      if (password === false) return;
      LMUI.loading(checkBtn, true, "Checking…");
      setStatus("Reading the inbox…", "info");
      LMUI.postJson(CHECK_URL, { password: password })
        .then(function (data) {
          renderStats(data.stats);
          setStatus(LMUI.escapeHtml(data.summary), data.matched ? "ok" : "info");
          if (data.matched) {
            LMUI.ok("Inbox checked", data.summary);
            // Reply states change eligibility, so the page is rebuilt.
            window.setTimeout(function () { window.location.reload(); }, 1200);
          } else {
            LMUI.info("Inbox checked", data.summary);
          }
        })
        .catch(function (error) {
          setStatus(LMUI.escapeHtml(error.message), "err");
          LMUI.error("Could not check the inbox", error.message);
        })
        .finally(function () { LMUI.loading(checkBtn, false); });
    });
  });

  /* --- create a follow-up ----------------------------------------------- */

  document.addEventListener("click", function (event) {
    var button = event.target.closest(".fu-create");
    if (!button) return;

    LMUI.loading(button, true, "Writing…");
    LMUI.postJson(button.dataset.url)
      .then(function (data) {
        LMUI.ok("Follow-up drafted",
                (data.angle ? "New angle: " + data.angle + ". " : "") +
                "Review it, then press Send follow-up.");
        window.location.reload();
      })
      .catch(function (error) {
        LMUI.error("Could not create the follow-up", error.message);
        LMUI.loading(button, false);
      });
  });

  /* --- one drafted follow-up ------------------------------------------- */

  function action(card, name, payload, button) {
    var id = card.dataset.followup;
    return LMUI.postJson("/outreach/followup/" + id + "/" + name, payload || {});
  }

  function showError(card, message) {
    var box = card.querySelector(".fu-error");
    box.innerHTML = LMUI.iconMarkup("i-x-circle") + "<span>" +
      LMUI.escapeHtml(message) + "</span>";
    box.classList.remove("is-hidden");
  }

  Array.prototype.forEach.call(document.querySelectorAll(".fu-draft"),
    function (card) {
      var subject = card.querySelector(".fu-subject");
      var body = card.querySelector(".fu-body");
      var editBtn = card.querySelector(".fu-edit");
      var saveBtn = card.querySelector(".fu-save");
      var cancelEdit = card.querySelector(".fu-cancel-edit");
      var original = { subject: subject.value, body: body.value };

      function setEditing(on) {
        card.classList.toggle("is-editing", on);
        subject.readOnly = !on;
        body.readOnly = !on;
        editBtn.classList.toggle("is-hidden", on);
        saveBtn.classList.toggle("is-hidden", !on);
        cancelEdit.classList.toggle("is-hidden", !on);
        if (on) subject.focus();
      }

      editBtn.addEventListener("click", function () { setEditing(true); });

      cancelEdit.addEventListener("click", function () {
        subject.value = original.subject;
        body.value = original.body;
        setEditing(false);
      });

      saveBtn.addEventListener("click", function () {
        LMUI.loading(saveBtn, true);
        action(card, "save", { subject: subject.value, body: body.value })
          .then(function (data) {
            original = { subject: data.followup.subject,
                         body: data.followup.body };
            setEditing(false);
            LMUI.ok("Follow-up saved", data.followup.email);
          })
          .catch(function (error) {
            showError(card, error.message);
            LMUI.error("Could not save", error.message);
          })
          .finally(function () { LMUI.loading(saveBtn, false); });
      });

      card.querySelector(".fu-regen").addEventListener("click", function () {
        var button = this;
        LMUI.modal({
          title: "Regenerate this follow-up",
          message: "Optional: say what to change. Leave blank for a fresh " +
                   "attempt on the same material.",
          iconName: "i-refresh",
          confirmLabel: "Regenerate",
          input: { label: "Revision note",
                   placeholder: 'e.g. "shorter", "lead with the offer"',
                   rows: 3 },
        }).then(function (hint) {
          if (hint === false) return;
          LMUI.loading(button, true);
          action(card, "regenerate", { hint: hint })
            .then(function (data) {
              subject.value = data.followup.subject;
              body.value = data.followup.body;
              original = { subject: data.followup.subject,
                           body: data.followup.body };
              LMUI.ok("Follow-up regenerated", data.followup.email);
            })
            .catch(function (error) {
              showError(card, error.message);
              LMUI.error("Could not regenerate", error.message);
            })
            .finally(function () { LMUI.loading(button, false); });
        });
      });

      card.querySelector(".fu-discard").addEventListener("click", function () {
        var button = this;
        LMUI.modal({
          title: "Cancel this follow-up?",
          message: "The draft is discarded. The lead stays eligible, so you " +
                   "can write another one later.",
          kind: "warn",
          confirmLabel: "Cancel follow-up",
        }).then(function (go) {
          if (!go) return;
          LMUI.loading(button, true);
          action(card, "cancel")
            .then(function () {
              LMUI.info("Follow-up cancelled", "Nothing was sent.");
              window.location.reload();
            })
            .catch(function (error) {
              showError(card, error.message);
              LMUI.loading(button, false);
            });
        });
      });

      card.querySelector(".fu-send").addEventListener("click", function () {
        var button = this;
        var to = card.querySelector(".fu-to").value;
        withPassword(
          "Send this follow-up to " + to + "?",
          "It goes out from your own account and cannot be recalled. The " +
          "recipient's reply state, the do-not-contact list and the follow-up " +
          "limit are all re-checked first.",
          "Send follow-up"
        ).then(function (password) {
          if (password === false) return;
          LMUI.loading(button, true, "Sending…");
          action(card, "send", { password: password })
            .then(function (data) {
              renderStats(data.stats);
              LMUI.ok("Follow-up sent", data.followup.email);
              window.location.reload();
            })
            .catch(function (error) {
              showError(card, error.message);
              LMUI.error("Follow-up not sent", error.message);
              LMUI.loading(button, false);
            });
        });
      });
    });
})();
