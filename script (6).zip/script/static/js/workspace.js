/*
 * Review workspace.
 *
 * Polls /state while a background job runs, renders one card per draft, and
 * drives edit / regenerate / re-review / approve / reject and the bulk send.
 * Every figure comes from the server, so a reload mid-run shows the real state.
 *
 * Presentation only — no request here does anything the backend did not already
 * expose.
 */
(function () {
  "use strict";

  var script = document.currentScript;
  var URLS = {
    state: script.dataset.stateUrl,
    approveAll: script.dataset.approveAllUrl,
    send: script.dataset.sendUrl,
    report: script.dataset.reportUrl,
    resume: script.dataset.resumeUrl,
    cancel: script.dataset.cancelUrl,
  };

  var $ = function (id) { return document.getElementById(id); };

  var phaseLabel = $("phase-label");
  var phaseDetail = $("phase-detail");
  var phaseSpinner = $("phase-spinner");
  var phaseError = $("phase-error");
  var countersEl = $("counters");
  var progressEl = $("progress");
  var segSent = $("seg-sent");
  var segFailed = $("seg-failed");
  var legendEl = $("progress-legend");
  var draftsEl = $("drafts");
  var sendCard = $("send-card");
  var sendBtn = $("send-btn");
  var sendStatus = $("send-status");
  var passwordInput = $("smtp-password");
  var approveAllBtn = $("approve-all-btn");
  var skippedCard = $("skipped-card");
  var skippedList = $("skipped-list");
  var skippedCount = $("skipped-count");
  var stepsEl = $("steps");
  var template = $("draft-template");
  var stallEl = $("stall");
  var stallText = $("stall-text");
  var stallBtn = $("stall-btn");
  var runEl = $("run");
  var runPosition = $("run-position");
  var runTotal = $("run-total");
  var runCurrent = $("run-current");
  var runPct = $("run-pct");
  var runBar = $("run-bar");
  var runSeg = $("run-seg");
  var runStepsEl = $("run-steps");
  var runNext = $("run-next");
  var runQueue = $("run-queue");
  var runQueueLabel = $("run-queue-label");
  var runLeads = $("run-leads");
  var runCancel = $("run-cancel");
  var controlEl = $("run-control");
  var controlIcon = $("run-control-icon");
  var controlTitle = $("run-control-title");
  var controlText = $("run-control-text");
  var controlResume = $("run-control-resume");
  var controlSettings = $("run-control-settings");

  var filter = "all";
  var editing = {};      // draft id -> true while its card is in edit mode
  var timer = null;
  var lastPhase = "";
  var announcedDone = false;
  //: Set the moment Cancel is pressed, so the button stays disabled through the
  //: poll that has not come back yet. Cleared once the server confirms a settled
  //: state, which is the only thing that can confirm it.
  var cancelling = false;
  //: Guard against two auto-resumes racing when a paused window opens: the poll
  //: runs every 1.5 seconds and the resume request takes longer than that.
  var resuming = false;

  var ACTIVE_PHASES = ["crawling", "analysing", "generating", "sending"];
  //: Phases where a run exists but is not moving. The strip should not walk
  //: backwards for them, and the panel stays visible so the queue can be read.
  var STOPPED_PHASES = ["paused_rate_limit", "cancel_requested", "cancelled"];
  // Crawling, reviewing and writing are one strip step: each lead passes
  // through all three, so a strip that tracked them would walk backwards on
  // every new lead. The run panel shows which lead and which step instead.
  var STEP_ORDER = ["select", "working", "review", "sending"];
  var WORKING_PHASES = { crawling: 1, analysing: 1, generating: 1 };

  var STATUS_PILL = {
    approved: "pill-ok",
    sent: "pill-ok",
    failed: "pill-err",
    rejected: "pill",
    generated: "pill-brand",
    crawled: "pill-accent",
    analysed: "pill-accent",
    pending: "pill",
    sending: "pill-brand",
  };

  var STATUS_ICON = {
    approved: "i-check-circle",
    sent: "i-check-circle",
    failed: "i-x-circle",
    rejected: "i-x",
    generated: "i-sparkles",
    sending: "i-send",
  };

  var DETAIL = {
    crawling: "Discovering this company's own pages and reading the most useful ones.",
    analysing: "Reviewing the crawled pages for verifiable issues and opportunities.",
    generating: "Writing this company's email from the issues just found.",
    paused_rate_limit: "The AI provider asked for a pause. Nothing is lost — " +
      "processing carries on from the next unfinished lead.",
    cancel_requested: "Stopping — the lead in flight is being abandoned, and no " +
      "further leads will be started.",
    cancelled: "Processing cancelled. Everything already completed is kept.",
    review: "Edit, regenerate or approve each email, then send the approved ones.",
    sending: "Sending approved emails, pausing between each for the provider's rate limit.",
    done: "Finished. The full outcome is on the report page.",
    failed: "The run stopped early.",
  };

  /* --- header, stats, progress ----------------------------------------- */

  var STATS = [
    ["total", "Total", "i-list", ""],
    ["approved", "Approved", "i-check", ""],
    ["sent", "Sent", "i-check-circle", "stat-ok"],
    ["failed", "Failed", "i-x-circle", "stat-err"],
    ["remaining", "Queued", "i-clock", ""],
  ];

  function renderStats(counts) {
    countersEl.innerHTML = STATS.map(function (row) {
      return '<div class="stat ' + row[3] + '">' +
        '<div class="stat-k">' + LMUI.iconMarkup(row[2]) + row[1] + "</div>" +
        '<div class="stat-n">' + (counts[row[0]] || 0) + "</div>" +
        "</div>";
    }).join("");
  }

  function renderProgress(counts) {
    var sent = counts.sent || 0;
    var failed = counts.failed || 0;
    var remaining = counts.remaining || 0;
    var total = sent + failed + remaining;

    progressEl.classList.toggle("is-hidden", total === 0);
    legendEl.classList.toggle("is-hidden", total === 0);
    if (!total) return;

    var pct = function (n) { return (n / total * 100).toFixed(1) + "%"; };
    segSent.style.width = pct(sent);
    segFailed.style.width = pct(failed);

    var done = Math.round((sent + failed) / total * 100);
    progressEl.setAttribute("aria-valuenow", String(done));

    // The colours are shorthand for these labels, never a substitute.
    legendEl.innerHTML = [
      ['<span class="legend-dot legend-dot-ok"></span>', "Sent", sent],
      ['<span class="legend-dot legend-dot-err"></span>', "Failed", failed],
      ['<span class="legend-dot" style="background:var(--n-200)"></span>', "Queued", remaining],
    ].map(function (row) {
      return '<span class="legend-item">' + row[0] + row[1] +
        " <b>" + row[2] + "</b></span>";
    }).join("") + '<span class="legend-item muted">' + done + "% complete</span>";
  }

  /* --- sequential run panel -------------------------------------------- */

  var RUN_STEP_ICON = { done: "i-check", current: "i-refresh", waiting: "i-clock" };

  function renderRun(state) {
    var run = state.progress || {};
    var control = run.control || {};
    var total = run.total || 0;
    var phase = state.campaign.phase;
    // Nothing to show before a lead has been stamped, or once the campaign has
    // moved on to sending -- the send has its own bar below.
    var relevant = total > 0 && phase !== "sending" && phase !== "done";
    runEl.classList.toggle("is-hidden", !relevant);
    if (!relevant) {
      runCancel.classList.add("is-hidden");
      return;
    }

    runPosition.textContent = run.position || 0;
    runTotal.textContent = total;
    runPct.textContent = (run.percent || 0) + "%";
    runSeg.style.width = (run.percent || 0) + "%";
    runSeg.className = "progress-seg " +
      (run.finished ? "progress-seg-ok" : "progress-seg-live");
    runBar.setAttribute("aria-valuenow", String(run.percent || 0));

    // Which company is being read right now — the point of the whole panel.
    runCurrent.textContent = "";
    if (run.current) {
      runCurrent.appendChild(LMUI.svgIcon("i-globe"));
      runCurrent.appendChild(LMUI.el("b", null, run.current.business_name));
      if (run.current.website) {
        runCurrent.appendChild(document.createTextNode(" · "));
        runCurrent.appendChild(
          LMUI.el("span", "mono", LMUI.shortUrl(run.current.website)));
      }
    } else if (control.state === "cancelled") {
      runCurrent.appendChild(LMUI.svgIcon("i-x-circle"));
      runCurrent.appendChild(document.createTextNode(
        "Stopped after " + (run.done || 0) + " of " + total + " lead(s)."));
    } else if (run.finished) {
      runCurrent.appendChild(LMUI.svgIcon("i-check-circle"));
      runCurrent.appendChild(document.createTextNode(
        "All " + total + " lead(s) analysed and drafted."));
    }

    runStepsEl.innerHTML = "";
    (run.steps || []).forEach(function (step) {
      var item = LMUI.el("li", "run-step is-" + step.state);
      item.appendChild(LMUI.svgIcon(RUN_STEP_ICON[step.state] || "i-clock"));
      item.appendChild(document.createTextNode(step.label));
      runStepsEl.appendChild(item);
    });

    runNext.textContent = run.next
      ? "Next: lead " + run.next.sequence + " · " + run.next.business_name
      : "";
    runNext.classList.toggle("is-hidden", !run.next);

    var leads = run.leads || [];
    runQueue.classList.toggle("is-hidden", !leads.length);
    runQueueLabel.textContent =
      "Lead queue — " + (run.done || 0) + " of " + total + " completed";

    // Rebuilt on every poll, so hold the scroll position or a user reading
    // down a 200-lead queue is yanked back to the top every 1.5 seconds.
    var scrolled = runLeads.scrollTop;
    runLeads.innerHTML = "";
    leads.forEach(function (lead) {
      var item = LMUI.el("li", "run-lead is-" + lead.state);
      item.appendChild(LMUI.el("span", "run-lead-n", "Lead " + lead.sequence));
      item.appendChild(LMUI.el("span", "run-lead-name", lead.business_name));
      item.appendChild(LMUI.el("span", "run-lead-state", {
        completed: "completed", current: "analysing…",
        failed: "no email written", waiting: "waiting",
        paused: "paused", stopped: "not processed",
      }[lead.state] || lead.state));
      runLeads.appendChild(item);
    });
    runLeads.scrollTop = scrolled;

    // The Cancel button lives with the progress it stops, and only exists while
    // there is something to stop.
    var canCancel = control.cancellable && control.state !== "cancelled";
    runCancel.classList.toggle("is-hidden", !canCancel);
    if (canCancel) {
      // Disabled while a cancellation is genuinely in flight. Not disabled for a
      // "cancelling" campaign whose worker died with its process -- that one
      // needs a press to settle it, and a permanently greyed-out button would
      // leave it saying "Cancelling…" forever.
      var busy = cancelling ||
                 (control.state === "cancelling" && state.campaign.running);
      runCancel.disabled = busy;
      LMUI.loading(runCancel, busy, "Cancelling…");
    }
  }

  /** The banner that explains a run which is not moving. */
  function renderControl(state) {
    var control = (state.progress || {}).control || {};
    var kind = control.state;
    var known = kind === "paused" || kind === "cancelled" ||
                kind === "cancelling";

    controlEl.classList.toggle("is-hidden", !known);
    controlResume.classList.add("is-hidden");
    controlSettings.classList.add("is-hidden");
    if (!known) return;

    if (kind === "cancelling") {
      controlEl.className = "banner banner-warn control-banner";
      controlIcon.querySelector("use").setAttribute("href", "#i-clock");
      controlTitle.textContent = "Cancelling. ";
      controlText.textContent = state.campaign.running
        ? "Finishing the lead in progress; no further leads will be started, " +
          "and nothing already completed is affected."
        : "The worker has already stopped — press Cancel again to settle this.";
      return;
    }

    if (kind === "cancelled") {
      controlEl.className = "banner banner-warn control-banner";
      controlIcon.querySelector("use").setAttribute("href", "#i-x-circle");
      controlTitle.textContent = "Processing cancelled. ";
      var left = (state.progress || {}).unfinished || 0;
      controlText.textContent = left
        ? left + " lead(s) were not processed. Everything already completed is " +
          "kept — resuming starts from the first unfinished lead."
        : "Every queued lead had already been processed.";
      if (left) {
        controlResume.classList.remove("is-hidden");
        setResumeLabel("Resume processing");
      }
      return;
    }

    // Paused. Two quite different situations behind one phase.
    controlEl.className = "banner banner-warn control-banner";
    controlIcon.querySelector("use").setAttribute("href", "#i-clock");

    if (control.waitable) {
      var seconds = control.retry_seconds || 0;
      controlTitle.textContent = "Paused — AI rate limit. ";
      controlText.textContent = seconds
        ? "Waiting " + seconds + "s for the provider's retry window. " +
          "Processing resumes automatically from the first unfinished lead."
        : "The retry window has passed — picking up from the first unfinished " +
          "lead.";
      if (!seconds) {
        controlResume.classList.remove("is-hidden");
        setResumeLabel("Resume now");
      }
    } else {
      controlIcon.querySelector("use").setAttribute("href", "#i-alert");
      controlTitle.textContent = "Paused — the AI allowance is used up. ";
      controlText.textContent = (control.pause_detail ||
        "The provider's quota for this key is spent.") +
        " Waiting will not clear this before the provider's own reset — switch " +
        "provider or credential, then resume.";
      controlSettings.classList.remove("is-hidden");
      controlResume.classList.remove("is-hidden");
      setResumeLabel("Resume now");
    }
  }

  function setResumeLabel(text) {
    var label = controlResume.querySelector(".btn-label");
    if (label) label.textContent = text;
    controlResume.disabled = resuming;
    LMUI.loading(controlResume, resuming, "Working…");
  }

  function renderSteps(phase) {
    // A paused or cancelling run is still in the working step of the strip: it
    // has not moved on, and showing it back at "select" would read as a restart.
    if (WORKING_PHASES[phase] || STOPPED_PHASES.indexOf(phase) !== -1) {
      phase = "working";
    }
    var index = STEP_ORDER.indexOf(phase);
    if (phase === "done" || phase === "failed") index = STEP_ORDER.length;
    Array.prototype.forEach.call(stepsEl.children, function (li) {
      var position = STEP_ORDER.indexOf(li.dataset.step || "select");
      li.classList.toggle("is-current", position === index);
      li.classList.toggle("is-done", position < index);
    });
  }

  function renderHeader(state) {
    var campaign = state.campaign;
    var active = ACTIVE_PHASES.indexOf(campaign.phase) !== -1 && campaign.running;

    phaseLabel.textContent = campaign.phase_label;
    phaseDetail.textContent = DETAIL[campaign.phase] || "";
    phaseSpinner.classList.toggle("is-hidden", !active);
    renderSteps(campaign.phase);
    renderRun(state);
    renderControl(state);
    renderStats(state.counts);
    renderProgress(state.counts);

    var control = (state.progress || {}).control || {};
    if (control.state !== "cancelling") cancelling = false;

    // Auto-resume once a rate-limit window has passed and no worker is left to
    // do it. Deliberately a request to the server rather than a decision here:
    // the server re-checks the window, so a fast clock or an impatient tab
    // cannot walk the run back into the same refusal.
    if (control.state === "paused" && control.retry_ready &&
        control.waitable && !campaign.running && !resuming) {
      autoResume();
    }

    if (campaign.error) {
      phaseError.innerHTML = LMUI.iconMarkup("i-alert") + "<span>" +
        LMUI.escapeHtml(campaign.error) + "</span>";
      phaseError.classList.remove("is-hidden");
    } else {
      phaseError.classList.add("is-hidden");
    }

    // Work the server thinks is running but is not — a restart mid-campaign.
    var stall = campaign.stalled || "";
    stallEl.classList.toggle("is-hidden", !stall);
    if (stall) {
      stallText.textContent = stall === "send"
        ? "This send was interrupted. Anything already delivered is recorded " +
          "and will not go out twice — release the queue and send the rest."
        : "This run stopped before it finished, most likely a server restart. " +
          "Resuming picks up where it left off; leads already analysed are not " +
          "done again.";
      LMUI.loading(stallBtn, false);
      var label = stallBtn.querySelector(".btn-label");
      if (label) label.textContent = stall === "send" ? "Release queue" : "Resume";
    }

    var canSend = ["review", "sending", "done"].indexOf(campaign.phase) !== -1;
    sendCard.classList.toggle("is-hidden", !canSend);
    var sending = campaign.phase === "sending" && campaign.running;
    sendBtn.disabled = state.counts.approved === 0 || campaign.running;
    LMUI.loading(sendBtn, sending, "Sending…");

    if (campaign.phase === "done" && lastPhase === "sending" && !announcedDone) {
      announcedDone = true;
      setSendStatus(
        'Send finished. <a href="' + URLS.report + '">Open the full report</a>.',
        "ok");
      LMUI.ok("Send finished",
              state.counts.sent + " sent, " + state.counts.failed + " failed");
    }
    lastPhase = campaign.phase;
    return active;
  }

  function setSendStatus(message, kind) {
    var iconName = { info: "i-info", ok: "i-check-circle", warn: "i-alert",
                     err: "i-x-circle" }[kind || "info"];
    sendStatus.className = "banner banner-" + (kind || "info");
    sendStatus.style.marginTop = "var(--sp-4)";
    sendStatus.innerHTML = LMUI.iconMarkup(iconName) + "<span>" + message + "</span>";
    sendStatus.classList.remove("is-hidden");
  }

  /* --- findings -------------------------------------------------------- */

  function renderFindings(node, draft) {
    var block = node.querySelector(".findings-block");
    var list = node.querySelector(".d-findings");
    var findings = draft.findings || [];
    var used = draft.findings_used || [];

    block.classList.toggle("is-hidden", !findings.length);
    node.querySelector(".d-findings-count").textContent = findings.length;
    list.innerHTML = "";

    findings.forEach(function (finding) {
      var severity = finding.severity || "medium";
      var item = LMUI.el("li", "finding finding-" + severity);

      var head = LMUI.el("div", "finding-head");
      head.appendChild(LMUI.el("span", "finding-issue", finding.issue));
      head.appendChild(LMUI.el("span", "pill pill-" +
        ({ high: "err", medium: "warn", low: "" }[severity] || ""), severity));
      if (finding.dimension) {
        head.appendChild(LMUI.el("span", "pill pill-outline", finding.dimension));
      }
      // Tag the findings the email was actually built on.
      if (used.indexOf(finding.issue) !== -1) {
        var tag = LMUI.el("span", "pill pill-ok");
        tag.appendChild(LMUI.svgIcon("i-check"));
        tag.appendChild(document.createTextNode("used in email"));
        head.appendChild(tag);
      }
      item.appendChild(head);

      var detail = LMUI.el("dl", "finding-detail");
      [
        ["Evidence", finding.evidence, "evidence"],
        ["Why it matters", finding.why_it_matters, ""],
        ["Suggested fix", finding.suggested_improvement, ""],
      ].forEach(function (row) {
        if (!row[1]) return;
        detail.appendChild(LMUI.el("dt", null, row[0]));
        detail.appendChild(LMUI.el("dd", row[2], row[1]));
      });
      item.appendChild(detail);

      if (finding.page_url) {
        var link = LMUI.el("a", "finding-page");
        link.href = finding.page_url;
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        link.appendChild(LMUI.svgIcon("i-external"));
        link.appendChild(document.createTextNode(LMUI.shortUrl(finding.page_url)));
        item.appendChild(link);
      }
      list.appendChild(item);
    });

    var pages = node.querySelector(".d-pages");
    var read = draft.pages_read || [];
    pages.textContent = read.length
      ? "Pages chosen automatically: " +
        read.map(function (p) { return p.kind; }).join(", ") +
        " — " + read.length + " read of " + draft.pages_discovered + " discovered"
      : "";
  }

  /* --- one card -------------------------------------------------------- */

  function fillCard(node, draft) {
    node.dataset.status = draft.status;
    node.dataset.id = draft.id;
    node.querySelector(".draft-name").textContent = draft.business_name;
    node.querySelector(".d-email").textContent = draft.email;
    node.querySelector(".d-category").textContent = draft.category || "—";

    var site = node.querySelector(".d-website");
    site.textContent = "";
    if (draft.website) {
      var link = document.createElement("a");
      link.href = draft.website;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = LMUI.shortUrl(draft.website);
      site.appendChild(link);
    } else {
      site.textContent = "none";
    }

    var status = node.querySelector(".d-status");
    status.className = "pill d-status " + (STATUS_PILL[draft.status] || "");
    status.textContent = "";
    if (STATUS_ICON[draft.status]) {
      status.appendChild(LMUI.svgIcon(STATUS_ICON[draft.status]));
    }
    status.appendChild(document.createTextNode(draft.status_label));

    var contacted = node.querySelector(".d-contacted");
    contacted.textContent = "contacted " + draft.previously_contacted;
    contacted.classList.toggle("is-hidden", !draft.previously_contacted);

    var forced = node.querySelector(".d-forced");
    forced.classList.toggle("is-hidden", !draft.force_contact);
    if (draft.force_contact) forced.title = draft.force_reason || "";

    var analysis = node.querySelector(".d-analysis");
    analysis.querySelector("span").textContent =
      draft.analysis_note || "not crawled yet";
    analysis.classList.toggle("is-warn", !draft.has_material);

    var summary = node.querySelector(".d-summary");
    summary.textContent = draft.business_summary || "";
    summary.classList.toggle("is-hidden", !draft.business_summary);

    // An unreadable site is a normal outcome, not an error: the lead still gets
    // an email, and the reason is stated so the email can be judged fairly.
    var noweb = node.querySelector(".d-noweb");
    var unreadable = draft.processed && !draft.has_material;
    node.querySelector(".d-noweb-reason").textContent =
      draft.analysis_note ? "Reason: " + draft.analysis_note : "";
    noweb.classList.toggle("is-hidden", !unreadable);

    renderFindings(node, draft);

    var observation = node.querySelector(".d-observation");
    var obsText = observation.querySelector("span");
    var grounded = draft.observation &&
      draft.observation.toLowerCase() !== "none";
    if (grounded) {
      obsText.textContent = "Built on: " + draft.observation;
      observation.classList.remove("is-plain");
    } else {
      obsText.textContent =
        "No website findings — this email references only the map listing.";
      observation.classList.add("is-plain");
    }
    observation.classList.toggle("is-hidden", !draft.subject);

    var error = node.querySelector(".d-error");
    error.querySelector("span").textContent = draft.error_message || "";
    error.classList.toggle("is-hidden", !draft.error_message);

    node.querySelector(".d-subject").value = draft.subject || "";
    node.querySelector(".d-body").value = draft.body || "";

    var locked = draft.status === "sent" || draft.status === "sending";
    node.querySelector(".act-edit").classList.toggle("is-hidden", locked);
    node.querySelector(".act-regen").classList.toggle("is-hidden", locked);
    node.querySelector(".act-rereview").classList.toggle(
      "is-hidden", locked || !draft.has_material);
    node.querySelector(".act-approve").classList.toggle(
      "is-hidden", locked || draft.status === "approved");
    node.querySelector(".act-reject").classList.toggle(
      "is-hidden", locked || draft.status === "rejected");
    // Suppressing after a send is pointless for this email but not for the
    // next campaign, so the action stays available once sent.
    node.querySelector(".act-suppress").classList.toggle(
      "is-hidden", !draft.email || draft.status === "suppressed");
  }

  function bind(node, draft) {
    var subject = node.querySelector(".d-subject");
    var body = node.querySelector(".d-body");
    var editBtn = node.querySelector(".act-edit");
    var saveBtn = node.querySelector(".act-save");
    var cancelBtn = node.querySelector(".act-cancel");
    var original = { subject: draft.subject, body: draft.body };

    function setEditing(on) {
      editing[draft.id] = on;
      node.classList.toggle("is-editing", on);
      subject.readOnly = !on;
      body.readOnly = !on;
      editBtn.classList.toggle("is-hidden", on);
      saveBtn.classList.toggle("is-hidden", !on);
      cancelBtn.classList.toggle("is-hidden", !on);
      if (on) subject.focus();
    }

    function act(action, payload, button, successMessage) {
      LMUI.loading(button, true);
      return LMUI.postJson("/outreach/draft/" + draft.id + "/" + action, payload)
        .then(function (data) {
          editing[draft.id] = false;
          replaceCard(data.draft);
          renderStats(data.counts);
          renderProgress(data.counts);
          if (successMessage) LMUI.ok(successMessage, draft.business_name);
        })
        .catch(function (error) {
          var box = node.querySelector(".d-error");
          box.querySelector("span").textContent = error.message;
          box.classList.remove("is-hidden");
          LMUI.error(draft.business_name, error.message);
          LMUI.loading(button, false);
        });
    }

    editBtn.addEventListener("click", function () { setEditing(true); });

    cancelBtn.addEventListener("click", function () {
      subject.value = original.subject;
      body.value = original.body;
      setEditing(false);
    });

    saveBtn.addEventListener("click", function () {
      act("save", { subject: subject.value, body: body.value }, saveBtn,
          "Email saved");
    });

    node.querySelector(".act-regen").addEventListener("click", function () {
      var button = this;
      LMUI.modal({
        title: "Regenerate this email",
        message: "Optional: say what to change. Leave blank for a fresh attempt " +
                 "on the same findings.",
        iconName: "i-refresh",
        confirmLabel: "Regenerate",
        input: {
          label: "Revision note",
          placeholder: 'e.g. "shorter", "less formal", "mention their booking page"',
          rows: 3,
        },
      }).then(function (hint) {
        if (hint === false) return;   // cancelled
        act("regenerate", { hint: hint }, button, "Email regenerated");
      });
    });

    node.querySelector(".act-rereview").addEventListener("click", function () {
      var button = this;
      LMUI.modal({
        title: "Re-review this website?",
        message: "Runs the review again over the pages already crawled, then " +
                 "rewrites the email from the new findings. No extra crawling.",
        iconName: "i-scan",
        confirmLabel: "Re-review",
      }).then(function (go) {
        if (go) act("rereview", {}, button, "Website re-reviewed");
      });
    });

    node.querySelector(".act-approve").addEventListener("click", function () {
      act("approve", {}, this, "Approved");
    });

    node.querySelector(".act-reject").addEventListener("click", function () {
      act("reject", {}, this, "Rejected");
    });

    node.querySelector(".act-suppress").addEventListener("click", function () {
      var button = this;
      LMUI.modal({
        title: "Never contact " + draft.email + "?",
        message: "This goes on the do-not-contact list and applies to every " +
                 "future campaign. It cannot be overridden from a campaign — " +
                 "only by removing the entry from that list.",
        kind: "warn",
        iconName: "i-shield",
        confirmLabel: "Add to do-not-contact",
        input: {
          label: "Note (optional)",
          placeholder: 'e.g. "replied asking to be removed"',
          rows: 2,
        },
      }).then(function (note) {
        if (note === false) return;   // cancelled
        act("suppress", { note: note, reason: "unsubscribed" }, button,
            "Added to the do-not-contact list");
      });
    });

    if (editing[draft.id]) setEditing(true);
  }

  function buildCard(draft) {
    var node = template.content.firstElementChild.cloneNode(true);
    fillCard(node, draft);
    bind(node, draft);
    node.classList.toggle("is-hidden",
                          filter !== "all" && draft.status !== filter);
    return node;
  }

  function replaceCard(draft) {
    var existing = draftsEl.querySelector('[data-id="' + draft.id + '"]');
    if (existing) existing.replaceWith(buildCard(draft));
  }

  function renderDrafts(all) {
    // Never rebuild a card the user is typing into.
    var busy = Object.keys(editing).some(function (id) { return editing[id]; });
    if (busy && draftsEl.childElementCount) return;

    // One card per lead the run has actually reached, so the list grows a
    // company at a time rather than opening as a wall of empty cards.
    var drafts = all.filter(function (draft) { return draft.started; });

    draftsEl.innerHTML = "";
    if (!drafts.length) {
      draftsEl.innerHTML =
        '<div class="card"><div class="empty">' +
        '<span class="empty-art">' + LMUI.iconMarkup("i-sparkles") + "</span>" +
        "<h3>Starting on the first lead</h3>" +
        "<p>Each website is analysed and its email written before the next " +
        "lead is started. A card appears here as soon as a company is done.</p>" +
        '<div style="width:100%;max-width:420px;margin-top:var(--sp-3)">' +
        '<div class="skeleton skeleton-line"></div>' +
        '<div class="skeleton skeleton-line" style="width:72%"></div>' +
        '<div class="skeleton skeleton-line" style="width:48%"></div>' +
        "</div></div></div>";
      return;
    }
    drafts.forEach(function (draft) {
      draftsEl.appendChild(buildCard(draft));
    });
  }

  /** Ask for a written reason, then re-queue a lead the history blocked. */
  function recontact(draft, button) {
    LMUI.modal({
      title: "Contact " + draft.business_name + " anyway?",
      message: "This lead was blocked because " +
        LMUI.escapeHtml((draft.error_message || "it matched the sending history.")
          .replace(/^Skipped: /, "")) +
        " Overriding it re-queues the lead: its website is analysed and its " +
        "email written, then it appears with the others for review. The reason " +
        "you give is kept with the send record.",
      kind: "warn",
      iconName: "i-refresh",
      confirmLabel: "Contact anyway",
      input: {
        label: "Why is this not a duplicate?",
        placeholder: 'e.g. "different business, same name as the Delft branch"',
        rows: 3,
      },
    }).then(function (reason) {
      if (reason === false) return;                       // cancelled
      if (!reason || reason.trim().length < 10) {
        LMUI.warn("A reason is required",
                  "At least 10 characters — it is kept with the send record.");
        return;
      }
      LMUI.loading(button, true);
      LMUI.postJson("/outreach/draft/" + draft.id + "/recontact",
                    { reason: reason.trim() })
        .then(function () {
          LMUI.ok("Re-queued", draft.business_name +
                  " is being analysed now — it will appear above when done.");
          poll();
        })
        .catch(function (error) {
          LMUI.error("Could not re-queue", error.message);
          LMUI.loading(button, false);
        });
    });
  }

  function renderSkipped(skipped) {
    skippedCard.classList.toggle("is-hidden", !skipped.length);
    skippedCount.textContent = skipped.length;
    skippedList.innerHTML = "";

    skipped.forEach(function (draft) {
      var item = LMUI.el("li", "skipped-row");
      var icon = draft.status === "suppressed" ? "i-shield" : "i-x-circle";
      item.appendChild(LMUI.svgIcon(icon, "icon-sm"));

      var main = LMUI.el("div", "skipped-main");
      main.appendChild(LMUI.el("b", null, draft.business_name));
      main.appendChild(LMUI.el("span", "skipped-why",
        draft.error_message || draft.status_label.toLowerCase()));
      item.appendChild(main);

      // Only a history match can be overridden. A suppression is final here by
      // design — it is undone on the do-not-contact list, deliberately.
      if (draft.can_recontact) {
        var button = LMUI.el("button", "btn btn-ghost btn-sm");
        button.type = "button";
        button.appendChild(LMUI.svgIcon("i-refresh", "icon-sm"));
        button.appendChild(document.createTextNode("Contact anyway"));
        button.addEventListener("click", function () {
          recontact(draft, button);
        });
        item.appendChild(button);
      } else if (draft.status === "suppressed") {
        item.appendChild(LMUI.el("span", "pill pill-err", "do not contact"));
      }
      skippedList.appendChild(item);
    });
  }

  function applyFilter() {
    var shown = 0;
    Array.prototype.forEach.call(draftsEl.children, function (node) {
      var match = filter === "all" || node.dataset.status === filter;
      node.classList.toggle("is-hidden", !match);
      if (match) shown += 1;
    });
    return shown;
  }

  /* --- polling --------------------------------------------------------- */

  function poll() {
    fetch(URLS.state, { headers: { "X-Requested-With": "fetch" } })
      .then(function (r) { return r.json(); })
      .then(function (state) {
        var active = renderHeader(state);
        renderDrafts(state.drafts);
        renderSkipped(state.skipped);
        applyFilter();

        // Poll quickly while work is happening, slowly when it is not.
        clearTimeout(timer);
        // A paused run is polled at the fast rate as well: the countdown has
        // to tick, and the resume has to fire promptly when it reaches zero.
        var stopped = STOPPED_PHASES.indexOf(state.campaign.phase) !== -1;
        timer = setTimeout(poll, (active || stopped) ? 1500 : 8000);
      })
      .catch(function () {
        clearTimeout(timer);
        timer = setTimeout(poll, 5000);
      });
  }

  /* --- toolbar & send -------------------------------------------------- */

  $("filters").addEventListener("click", function (event) {
    var chip = event.target.closest(".chip");
    if (!chip) return;
    filter = chip.dataset.filter;
    Array.prototype.forEach.call(this.children, function (other) {
      other.classList.toggle("is-active", other === chip);
    });
    applyFilter();
  });

  runCancel.addEventListener("click", function () {
    LMUI.modal({
      title: "Cancel processing?",
      message: "Processing stops after the lead currently being worked on, and " +
               "no further leads are started. Leads already completed are kept " +
               "and are not processed again. You can resume later from the " +
               "first unfinished lead.",
      kind: "warn",
      confirmLabel: "Cancel processing",
      confirmClass: "btn-danger-ghost",
      cancelLabel: "Keep going",
    }).then(function (go) {
      if (!go) return;
      // Latched before the request, so the button cannot be pressed twice while
      // it is in flight.
      cancelling = true;
      runCancel.disabled = true;
      LMUI.loading(runCancel, true, "Cancelling…");
      LMUI.postJson(URLS.cancel, {})
        .then(function (data) {
          LMUI.warn("Cancelling", data.message);
          if (data.state) renderHeader(data.state);
          poll();
        })
        .catch(function (error) {
          cancelling = false;
          LMUI.loading(runCancel, false);
          runCancel.disabled = false;
          LMUI.error("Could not cancel", error.message);
        });
    });
  });

  /** Resume a paused or cancelled run. `force` skips a wait the user overrides. */
  function doResume(force, announce) {
    if (resuming) return;
    resuming = true;
    setResumeLabel(null);
    LMUI.postJson(URLS.resume, force ? { force: true } : {})
      .then(function (data) {
        if (announce) {
          LMUI.ok("Resumed", "Picking up from lead " +
                  ((data.remaining || 0) ? "1 of " + data.remaining +
                   " unfinished" : "the first unfinished one") + ".");
        }
        poll();
      })
      .catch(function (error) {
        if (announce) LMUI.error("Could not resume", error.message);
      })
      .finally(function () {
        resuming = false;
        setResumeLabel(null);
      });
  }

  controlResume.addEventListener("click", function () {
    // An explicit press overrides a remaining wait: the user may have just
    // switched provider, and the server still refuses if that would be wrong.
    doResume(true, true);
  });

  /** The window passed and nobody is watching. Quiet -- no toast for a resume
   *  the user did not ask for. */
  function autoResume() {
    doResume(false, false);
  }

  stallBtn.addEventListener("click", function () {
    LMUI.loading(stallBtn, true, "Working…");
    LMUI.postJson(URLS.resume)
      .then(function (data) {
        if (data.resumed === "send") {
          LMUI.info("Queue released",
                    data.released + " email(s) are approved again — press Send.");
        } else {
          LMUI.ok("Resumed", data.remaining + " lead(s) left to work through.");
        }
        stallEl.classList.add("is-hidden");
        poll();
      })
      .catch(function (error) {
        LMUI.error("Could not resume", error.message);
        LMUI.loading(stallBtn, false);
      });
  });

  approveAllBtn.addEventListener("click", function () {
    LMUI.loading(approveAllBtn, true);
    LMUI.postJson(URLS.approveAll)
      .then(function (data) {
        renderStats(data.counts);
        renderProgress(data.counts);
        if (data.approved) {
          LMUI.ok(data.approved + " email(s) approved", "Ready to send");
        } else {
          LMUI.info("Nothing to approve", "No drafted emails are waiting.");
        }
        poll();
      })
      .catch(function (error) { LMUI.error("Could not approve", error.message); })
      .finally(function () { LMUI.loading(approveAllBtn, false); });
  });

  sendBtn.addEventListener("click", function () {
    var approved = Number(
      (countersEl.querySelectorAll(".stat-n")[1] || {}).textContent || 0);

    LMUI.modal({
      title: "Send " + approved + " approved email" + (approved === 1 ? "" : "s") + "?",
      message: "Each one goes out from your own account and cannot be recalled.",
      kind: "warn",
      confirmLabel: "Send now",
      confirmClass: "btn-success",
    }).then(function (go) {
      if (!go) return;
      LMUI.loading(sendBtn, true, "Starting…");
      setSendStatus("Starting send…", "info");
      LMUI.postJson(URLS.send, { password: passwordInput.value })
        .then(function () {
          passwordInput.value = "";   // do not leave it sitting in the DOM
          announcedDone = false;
          setSendStatus("Sending. Progress updates above.", "info");
          LMUI.info("Sending started", "Progress updates as each email goes out.");
          poll();
        })
        .catch(function (error) {
          setSendStatus(LMUI.escapeHtml(error.message), "err");
          LMUI.error("Send failed to start", error.message);
          LMUI.loading(sendBtn, false);
        });
    });
  });

  poll();
})();
