/*
 * Shared UI runtime: toasts, modals and small view helpers.
 *
 * Exposed as window.LMUI and loaded on every page. It replaces the browser's
 * alert/confirm/prompt, which cannot be styled, block the whole tab, and look
 * nothing like the rest of the product. Presentational only -- no application
 * logic lives here.
 */
window.LMUI = (function () {
  "use strict";

  var ICONS = {
    info: "i-info",
    ok: "i-check-circle",
    warn: "i-alert",
    err: "i-x-circle",
  };

  function escapeHtml(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  function iconMarkup(name, className) {
    return '<svg class="icon ' + (className || "") + '" aria-hidden="true">' +
      '<use href="#' + name + '"/></svg>';
  }

  /* --- toasts ---------------------------------------------------------- */

  function toastHost() {
    var host = document.querySelector(".toasts");
    if (!host) {
      host = document.createElement("div");
      host.className = "toasts";
      host.setAttribute("role", "region");
      host.setAttribute("aria-label", "Notifications");
      document.body.appendChild(host);
    }
    return host;
  }

  /** kind is info | ok | warn | err. Errors stay until dismissed. */
  function toast(kind, title, message, options) {
    options = options || {};
    var node = document.createElement("div");
    node.className = "toast toast-" + kind;
    // Assertive for errors so a screen reader interrupts; polite otherwise.
    node.setAttribute("role", kind === "err" ? "alert" : "status");
    node.setAttribute("aria-live", kind === "err" ? "assertive" : "polite");

    node.innerHTML =
      iconMarkup(ICONS[kind] || ICONS.info, "toast-icon") +
      '<div class="toast-body"><div class="toast-title">' +
      escapeHtml(title) + "</div>" +
      (message ? '<div class="toast-msg">' + escapeHtml(message) + "</div>" : "") +
      "</div>" +
      '<button type="button" class="toast-close" aria-label="Dismiss">' +
      iconMarkup("i-x", "icon-sm") + "</button>";

    function dismiss() {
      node.classList.add("is-leaving");
      setTimeout(function () { node.remove(); }, 200);
    }

    node.querySelector(".toast-close").addEventListener("click", dismiss);
    toastHost().appendChild(node);

    var life = options.duration != null ? options.duration
      : (kind === "err" ? 0 : 5200);
    if (life > 0) setTimeout(dismiss, life);

    return { dismiss: dismiss };
  }

  /* --- modal ----------------------------------------------------------- */

  var current = null;

  function close(result) {
    if (!current) return;
    var open = current;
    current = null;
    document.removeEventListener("keydown", open.onKey);
    open.root.remove();
    if (open.previousFocus && open.previousFocus.focus) open.previousFocus.focus();
    open.resolve(result);
  }

  /**
   * Styled modal returning a promise.
   *
   * opts: {title, message, kind, iconName, confirmLabel, cancelLabel,
   *        confirmClass, input: {label, placeholder, value, rows, hint}}
   *
   * Cancel resolves false. With `input` it resolves to the trimmed string
   * (possibly ""); without, it resolves true.
   */
  function modal(opts) {
    opts = opts || {};
    if (current) close(false);

    return new Promise(function (resolve) {
      var root = document.createElement("div");
      root.className = "modal-root";
      root.setAttribute("role", "dialog");
      root.setAttribute("aria-modal", "true");
      root.setAttribute("aria-labelledby", "lmui-title");

      var hasInput = Boolean(opts.input);
      var field = "";
      if (hasInput) {
        var spec = opts.input;
        // A credential must not sit on screen in plain text, so a password
        // field is a masked single-line input rather than the textarea. Same
        // id either way, so accept() reads it without caring which it got.
        var control = spec.password
          ? '<input type="password" class="input" id="lmui-input" ' +
            'autocomplete="current-password" placeholder="' +
            escapeHtml(spec.placeholder || "") + '">'
          : '<textarea class="textarea" id="lmui-input" rows="' +
            (spec.rows || 3) + '" placeholder="' +
            escapeHtml(spec.placeholder || "") + '">' +
            escapeHtml(spec.value || "") + "</textarea>";
        field =
          '<div class="field">' +
          (spec.label ? '<label class="label" for="lmui-input">' +
            escapeHtml(spec.label) + "</label>" : "") +
          control +
          (spec.hint ? '<p class="hint">' + escapeHtml(spec.hint) + "</p>" : "") +
          "</div>";
      }

      root.innerHTML =
        '<div class="modal">' +
          '<div class="modal-head">' +
            '<div class="modal-art' +
              (opts.kind === "warn" ? " modal-art-warn" : "") + '">' +
              iconMarkup(opts.iconName ||
                (opts.kind === "warn" ? "i-alert" : "i-sparkles")) +
            "</div><div>" +
              '<h2 class="modal-title" id="lmui-title">' +
              escapeHtml(opts.title || "") + "</h2>" +
              (opts.message ? '<p class="modal-sub">' +
                escapeHtml(opts.message) + "</p>" : "") +
            "</div>" +
          "</div>" +
          (field ? '<div class="modal-body">' + field + "</div>" : "") +
          '<div class="modal-foot">' +
            '<button type="button" class="btn btn-ghost" data-act="cancel">' +
              escapeHtml(opts.cancelLabel || "Cancel") + "</button>" +
            '<button type="button" class="btn ' +
              (opts.confirmClass || "btn-primary") + '" data-act="ok">' +
              escapeHtml(opts.confirmLabel || "Confirm") + "</button>" +
          "</div>" +
        "</div>";

      function accept() {
        if (!hasInput) return close(true);
        close(root.querySelector("#lmui-input").value.trim());
      }

      function onKey(event) {
        if (event.key === "Escape") { event.preventDefault(); close(false); }
        if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) accept();
        if (event.key === "Enter" && hasInput && opts.input.password &&
            event.target && event.target.id === "lmui-input") {
          event.preventDefault();
          accept();
        }
      }

      root.querySelector('[data-act="cancel"]')
        .addEventListener("click", function () { close(false); });
      root.querySelector('[data-act="ok"]').addEventListener("click", accept);
      root.addEventListener("mousedown", function (event) {
        if (event.target === root) close(false);   // clicked the backdrop
      });

      current = {
        root: root, resolve: resolve, onKey: onKey,
        previousFocus: document.activeElement,
      };
      document.addEventListener("keydown", onKey);
      document.body.appendChild(root);

      var focusTarget = root.querySelector("#lmui-input") ||
        root.querySelector('[data-act="ok"]');
      if (focusTarget) focusTarget.focus();
    });
  }

  /* --- helpers --------------------------------------------------------- */

  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (text != null) node.textContent = text;
    return node;
  }

  function svgIcon(name, className) {
    var svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("class", "icon " + (className || ""));
    svg.setAttribute("aria-hidden", "true");
    var use = document.createElementNS("http://www.w3.org/2000/svg", "use");
    use.setAttribute("href", "#" + name);
    svg.appendChild(use);
    return svg;
  }

  function cookie(name) {
    var match = document.cookie.match(
      new RegExp("(?:^|; )" + name + "=([^;]*)"));
    return match ? decodeURIComponent(match[1]) : "";
  }

  /** POST JSON with the CSRF token, resolving to the parsed body. */
  function postJson(url, body) {
    return fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRFToken": cookie("csrftoken"),
      },
      body: JSON.stringify(body || {}),
    }).then(function (response) {
      return response.json()
        .catch(function () {
          throw new Error("The server returned an unexpected response.");
        })
        .then(function (data) {
          if (!response.ok) throw new Error(data.error || "Request failed.");
          return data;
        });
    });
  }

  /** Toggle a button's loading state without changing its width. */
  function loading(button, on, label) {
    if (!button) return;
    button.disabled = Boolean(on);
    button.classList.toggle("is-loading", Boolean(on));
    var text = button.querySelector(".btn-label");
    if (text && label) {
      if (on) {
        if (!text.dataset.idle) text.dataset.idle = text.textContent;
        text.textContent = label;
      } else if (text.dataset.idle) {
        text.textContent = text.dataset.idle;
      }
    }
  }

  function shortUrl(url) {
    return String(url || "").replace(/^https?:\/\//, "").replace(/\/$/, "");
  }

  return {
    toast: toast,
    info: function (t, m, o) { return toast("info", t, m, o); },
    ok: function (t, m, o) { return toast("ok", t, m, o); },
    warn: function (t, m, o) { return toast("warn", t, m, o); },
    error: function (t, m, o) { return toast("err", t, m, o); },
    modal: modal,
    el: el,
    svgIcon: svgIcon,
    iconMarkup: iconMarkup,
    escapeHtml: escapeHtml,
    cookie: cookie,
    postJson: postJson,
    loading: loading,
    shortUrl: shortUrl,
  };
})();
