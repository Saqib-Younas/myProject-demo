/*
 * The do-not-contact list: add an entry, remove an entry.
 *
 * Adding reloads the page rather than splicing a row in, because the server
 * also sweeps matching drafts out of open campaigns and the count it reports is
 * worth showing accurately.
 */
(function () {
  "use strict";

  var script = document.currentScript;
  var ADD_URL = script.dataset.addUrl;

  var $ = function (id) { return document.getElementById(id); };
  var target = $("sup-target");
  var reason = $("sup-reason");
  var note = $("sup-note");
  var addBtn = $("sup-add");
  var status = $("sup-status");

  function setStatus(message, kind) {
    var icons = { info: "i-info", ok: "i-check-circle", warn: "i-alert",
                  err: "i-x-circle" };
    status.className = "banner banner-" + (kind || "info");
    status.style.marginTop = "var(--sp-4)";
    status.innerHTML = LMUI.iconMarkup(icons[kind || "info"]) +
      "<span>" + message + "</span>";
    status.classList.remove("is-hidden");
  }

  function add() {
    var value = target.value.trim();
    if (!value) {
      setStatus("Enter an email address or a domain.", "warn");
      target.focus();
      return;
    }

    var wholeDomain = value.indexOf("@") === -1;
    LMUI.modal({
      title: wholeDomain ? "Block every address at " + value + "?"
                         : "Never contact " + value + "?",
      message: wholeDomain
        ? "No email will be sent to any address at this domain, in this or any " +
          "future campaign. This cannot be overridden from a campaign."
        : "No email will be sent to this address again. This cannot be " +
          "overridden from a campaign — only by removing the entry here.",
      kind: "warn",
      iconName: "i-shield",
      confirmLabel: "Add to list",
    }).then(function (go) {
      if (!go) return;
      LMUI.loading(addBtn, true, "Adding…");
      LMUI.postJson(ADD_URL, {
        target: value,
        reason: reason.value,
        note: note.value.trim(),
      })
        .then(function (data) {
          var swept = data.swept
            ? " " + data.swept + " queued lead(s) were removed from open campaigns."
            : "";
          LMUI.ok(data.created ? "Added to the list" : "Entry updated",
                  data.target + swept);
          window.location.reload();
        })
        .catch(function (error) {
          setStatus(LMUI.escapeHtml(error.message), "err");
          LMUI.error("Could not add the entry", error.message);
          LMUI.loading(addBtn, false);
        });
    });
  }

  addBtn.addEventListener("click", add);
  target.addEventListener("keydown", function (event) {
    if (event.key === "Enter") { event.preventDefault(); add(); }
  });

  var table = $("sup-table");
  if (table) {
    table.addEventListener("click", function (event) {
      var button = event.target.closest(".sup-remove");
      if (!button) return;

      LMUI.modal({
        title: "Remove " + button.dataset.target + " from the list?",
        message: "This address becomes contactable again in new searches. " +
                 "Leads already marked in a campaign stay blocked.",
        kind: "warn",
        confirmLabel: "Remove",
      }).then(function (go) {
        if (!go) return;
        LMUI.loading(button, true);
        LMUI.postJson(button.dataset.url)
          .then(function (data) {
            var row = button.closest("tr");
            if (row) row.remove();
            LMUI.ok("Removed", data.removed);
          })
          .catch(function (error) {
            LMUI.error("Could not remove", error.message);
            LMUI.loading(button, false);
          });
      });
    });
  }
})();
