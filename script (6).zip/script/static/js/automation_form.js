/*
 * The automation configuration form: chip pickers, dependent cities, and a summary.
 *
 * Three jobs, none of which is validation. Every rule that decides whether a
 * campaign may run lives on the server in `forms.AutomationForm` -- a browser check
 * is a convenience for the person typing, and treating it as the enforcement is how
 * a campaign starts with a daily target above its mailbox's ceiling.
 *
 * The pickers keep their selection in hidden inputs rather than in a JavaScript
 * array alone, so the form still posts the right thing if a redraw loses the
 * closure -- and the field on the server accepts a comma-separated string too, so a
 * browser with no JavaScript at all can still submit a campaign by typing.
 */
(function () {
  "use strict";

  var script = document.currentScript;
  var CITIES_URL = script.dataset.citiesUrl;

  var form = document.getElementById("automation-form");
  if (!form) return;

  /* --- one chip picker ---------------------------------------------------- */

  function Picker(name, inputId, chipsId) {
    this.name = name;
    this.input = document.getElementById(inputId);
    this.chips = document.getElementById(chipsId);
    this.values = [];

    if (!this.input || !this.chips) return;

    var self = this;
    this.input.addEventListener("keydown", function (event) {
      if (event.key === "Enter" || event.key === ",") {
        event.preventDefault();          // Enter must not submit the form
        self.add(self.input.value);
        self.input.value = "";
      } else if (event.key === "Backspace" && !self.input.value) {
        self.remove(self.values[self.values.length - 1]);
      }
    });
    // A datalist pick fires `change`, not `keydown`.
    this.input.addEventListener("change", function () {
      if (self.input.value) {
        self.add(self.input.value);
        self.input.value = "";
      }
    });
    this.chips.addEventListener("click", function (event) {
      var button = event.target.closest("[data-remove]");
      if (button) self.remove(button.dataset.remove);
    });
  }

  Picker.prototype.add = function (value) {
    var cleaned = (value || "").trim();
    if (!cleaned) return;
    var taken = this.values.some(function (existing) {
      return existing.toLowerCase() === cleaned.toLowerCase();
    });
    if (taken) return;
    this.values.push(cleaned);
    this.paint();
  };

  Picker.prototype.remove = function (value) {
    if (!value) return;
    this.values = this.values.filter(function (existing) {
      return existing !== value;
    });
    this.paint();
  };

  Picker.prototype.paint = function () {
    var html = "";
    for (var i = 0; i < this.values.length; i++) {
      var value = this.values[i];
      html += '<span class="chip">' + LMUI.escapeHtml(value) +
        '<button type="button" class="chip-x" data-remove="' +
        LMUI.escapeHtml(value) + '" aria-label="Remove ' +
        LMUI.escapeHtml(value) + '">&times;</button>' +
        '<input type="hidden" name="' + this.name + '" value="' +
        LMUI.escapeHtml(value) + '"></span>';
    }
    this.chips.innerHTML = html;
    if (typeof this.onchange === "function") this.onchange(this.values);
    summarise();
  };

  var countries = new Picker("countries", "pick-country", "pick-country-chips");
  var cities = new Picker("cities", "pick-city", "pick-city-chips");
  var categories = new Picker("categories", "pick-category",
                              "pick-category-chips");

  /* --- cities follow countries -------------------------------------------- */

  /*
   * The list is a convenience, never a restriction: any place name may be typed,
   * and the geocoder decides whether it exists. Restricting the field to the
   * offline dataset would silently exclude every town it has never heard of.
   */
  countries.onchange = function (values) {
    var list = document.getElementById("city-options");
    var hint = document.getElementById("city-hint");
    if (!list || !values.length || !CITIES_URL) return;

    list.innerHTML = "";
    var loaded = 0;
    values.slice(0, 4).forEach(function (country) {
      fetch(CITIES_URL + "?country=" + encodeURIComponent(country))
        .then(function (response) { return response.json(); })
        .then(function (data) {
          (data.cities || []).slice(0, 400).forEach(function (city) {
            var option = document.createElement("option");
            option.value = city.name;
            list.appendChild(option);
          });
          loaded += (data.cities || []).length;
          if (hint) {
            hint.textContent = loaded
              ? loaded + " cities known for the selected countries. Any other " +
                "place name is accepted too."
              : (data.note || "No cities in the reference data — type the place " +
                 "name and the geocoder will still try it.");
          }
        })
        .catch(function () {
          if (hint) {
            hint.textContent = "Could not load the city list. Type the place " +
              "name instead — it is accepted either way.";
          }
        });
    });
  };

  /* --- restore what the server sent back ---------------------------------- */

  /* A rejected submit comes back with the values it was given, so the pickers have
     to be rebuilt from them -- otherwise correcting one field loses the other
     twelve, which is the single most annoying thing a form can do. */
  function restore(picker, elementId) {
    var node = document.getElementById(elementId);
    if (!node) return;
    var values;
    try {
      values = JSON.parse(node.textContent);
    } catch (error) {
      return;
    }
    if (typeof values === "string") values = values.split(",");
    (values || []).forEach(function (value) { picker.add(value); });
  }

  restore(countries, "initial-countries");
  restore(cities, "initial-cities");
  restore(categories, "initial-categories");

  /* --- the review panel --------------------------------------------------- */

  function value(name) {
    var node = form.querySelector('[name="' + name + '"]');
    if (!node) return "";
    if (node.type === "checkbox") return node.checked;
    return node.value;
  }

  function row(term, detail) {
    return "<dt>" + LMUI.escapeHtml(term) + "</dt><dd>" +
      LMUI.escapeHtml(detail || "—") + "</dd>";
  }

  function summarise() {
    var panel = document.getElementById("review-summary");
    if (!panel) return;

    var account = form.querySelector('[name="email_account"]');
    var accountLabel = account && account.selectedIndex >= 0
      ? account.options[account.selectedIndex].textContent.trim() : "";
    var template = form.querySelector('[name="template_key"]:checked');
    var templateLabel = template
      ? template.closest("label").querySelector("b").textContent : "";

    var start = value("start_date");
    var end = value("end_date");
    var days = start ? (end ? start + " → " + end : start + " onwards") : "";
    var hours = value("start_time") +
      (value("end_time") ? "–" + value("end_time") : " to midnight");

    var html = "";
    html += row("Categories", categories.values.join(", "));
    html += row("Locations", cities.values.join(", "));
    html += row("Countries", countries.values.join(", "));
    html += row("Daily target", value("daily_target"));
    html += row("Total target", value("total_target"));
    html += row("Dates", days);
    html += row("Daily window", hours + " " + value("timezone_name"));
    html += row("Send from", accountLabel);
    html += row("Template", templateLabel);
    html += row("Follow-ups", value("followups_enabled")
      ? "prepared for your approval — never sent automatically" : "off");
    panel.innerHTML = html;

    var note = document.getElementById("window-note");
    if (note && value("start_time")) {
      note.textContent = "The worker may send between " + hours + " " +
        value("timezone_name") + ", up to " + (value("daily_target") || "0") +
        " a day, and stops for the day once that is reached.";
    }
  }

  form.addEventListener("input", summarise);
  form.addEventListener("change", summarise);
  summarise();
})();
