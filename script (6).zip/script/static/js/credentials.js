/*
 * The AI credential pool, and the provider selector.
 *
 * Three rules this file exists to keep:
 *
 *   1. A key is held in the input for exactly as long as it takes to POST it,
 *      then cleared from the DOM. It is never written to localStorage or
 *      sessionStorage, never put in a URL, and never logged.
 *   2. The only request that carries a key is the one that saves it. Everything
 *      else sends a credential id, and the server re-reads that credential
 *      against the signed-in account before it will act on it.
 *   3. Everything painted back into a card comes from the server's status --
 *      masked hints, labels, counters, timestamps. The browser never decides
 *      what a credential's state is; it only shows what it was told.
 *
 * `renderChild` below mirrors the markup Django writes in settings.html. The two
 * have to agree, and that duplication is the price of repainting a card without
 * reloading the page.
 */
(function () {
  "use strict";

  var script = document.currentScript;
  var URLS = {
    select: script.dataset.selectUrl,
    add: script.dataset.addUrl,               // .../<provider>/add
    activate: script.dataset.activateUrl,     // .../<id>/activate
    deactivate: script.dataset.deactivateUrl,
    test: script.dataset.testUrl,
    fallback: script.dataset.fallbackUrl,
    "delete": script.dataset.deleteUrl,
  };

  /** Substitute a provider name into an /ai/credentials/<provider>/add route. */
  function providerUrl(template, provider) {
    return template.replace("__provider__", encodeURIComponent(provider));
  }

  /** Substitute an id into a route that Django reversed with a 0 placeholder. */
  function idUrl(template, id) {
    return template.replace(/\/0\//, "/" + encodeURIComponent(id) + "/");
  }

  function card(provider) {
    return document.querySelector('.cred-card[data-provider="' + provider + '"]');
  }

  var ICONS = { info: "i-info", ok: "i-check-circle", warn: "i-alert",
                err: "i-x-circle" };

  function result(node, message, kind) {
    if (!node) return;
    node.className = "cred-result banner banner-" + (kind || "info");
    node.innerHTML = LMUI.iconMarkup(ICONS[kind || "info"]) +
      "<span>" + LMUI.escapeHtml(message) + "</span>";
    node.classList.remove("is-hidden");
  }

  /* --- painting ----------------------------------------------------------- */

  var esc = function (value) { return LMUI.escapeHtml(value == null ? "" : value); };

  /** A date, or "Unknown". Never an invented one: null stays visibly absent. */
  function day(iso) {
    return iso ? String(iso).slice(0, 10) : "Unknown";
  }

  function meta(term, value) {
    return "<div><dt>" + esc(term) + "</dt><dd>" + esc(value) + "</dd></div>";
  }

  /** One child row. Mirrors the `.cred-child` block in settings.html. */
  function renderChild(child, editable) {
    var off = editable ? "" : " disabled";
    var html = '<li class="cred-child' + (child.is_active ? " is-active" : "") +
      '" data-id="' + child.id + '" data-status="' + esc(child.status) + '">';

    html += '<div class="cred-child-head">' +
      '<span class="cred-mark" aria-hidden="true">' +
      (child.is_active ? "●" : "○") + "</span>" +
      '<span class="cred-child-name">' + esc(child.label) + "</span>";
    if (child.is_active) {
      html += '<span class="pill pill-ok">ACTIVE</span>';
    } else if (child.allow_fallback) {
      html += '<span class="pill pill-warn" title="May be used for one retry ' +
        'when the active credential is rate limited">fallback</span>';
    }
    if (child.status === "failing" || child.status === "error") {
      html += '<span class="pill pill-err" title="' +
        esc(child.last_error_detail) + '">last request failed</span>';
    }
    html += '<span class="spacer"></span><span class="mono cred-child-key">' +
      esc(child.masked || "—") + "</span></div>";

    if (child.description) {
      html += '<p class="cred-child-note">' + esc(child.description) + "</p>";
    }

    html += '<dl class="cred-child-meta">' +
      meta("Added", day(child.created_at)) +
      meta("Last used", day(child.last_used_at)) +
      meta("Requests", child.request_count) +
      meta("Failed", child.error_count) +
      meta("Model", child.model || "Provider default") +
      "</dl>";

    if (child.last_error_detail) {
      html += '<p class="cred-child-err">' +
        esc(child.last_error_category || "error") + " — " +
        esc(child.last_error_detail) + "</p>";
    }
    if (child.last_test_result) {
      html += '<p class="cred-child-test">Last test: ' +
        esc(child.last_test_result) + "</p>";
    }

    html += '<div class="cred-child-actions">';
    if (child.is_active) {
      html += '<button type="button" class="btn btn-ghost btn-sm ' +
        'cred-deactivate"' + off + ">Deactivate</button>";
    } else {
      html += '<button type="button" class="btn btn-primary btn-sm ' +
        'cred-activate"' + off + ">" + LMUI.iconMarkup("i-check", "icon-sm") +
        '<span class="btn-label">Activate</span>' +
        '<span class="spinner" aria-hidden="true"></span></button>';
    }
    html += '<button type="button" class="btn btn-outline btn-sm cred-test">' +
      LMUI.iconMarkup("i-scan", "icon-sm") +
      '<span class="btn-label">Test</span>' +
      '<span class="spinner" aria-hidden="true"></span></button>';
    if (!child.is_active) {
      html += '<button type="button" class="btn btn-ghost btn-sm cred-fallback"' +
        ' data-enabled="' + (child.allow_fallback ? "1" : "") + '"' +
        ' aria-pressed="' + (child.allow_fallback ? "true" : "false") + '"' +
        off + ">" +
        (child.allow_fallback ? "Fallback on" : "Use as fallback") + "</button>";
    }
    html += '<span class="spacer"></span>' +
      '<button type="button" class="btn btn-ghost btn-sm btn-danger-ghost ' +
      'cred-delete"' + off + ">" + LMUI.iconMarkup("i-x", "icon-sm") +
      " Delete</button>";
    html += "</div></li>";
    return html;
  }

  /** Repaint one provider card from the server's status. Never holds a key. */
  function applyStatus(status) {
    var node = card(status.name);
    if (!node) return;
    var editable = !node.querySelector(".cred-save[disabled]");

    node.dataset.source = status.source;

    var line = node.querySelector(".cred-status");
    if (line) {
      if (status.has_active) {
        line.innerHTML = '<span class="dot dot-ok"></span><b>' +
          esc(status.active_label) + '</b><span class="cred-source">active · ' +
          esc(status.masked) + "</span>";
      } else if (status.configured) {
        line.innerHTML = '<span class="dot dot-warn"></span>' +
          "<b>No active credential</b>" +
          '<span class="cred-source">using ' +
          esc((status.source_label || "").toLowerCase()) + "</span>";
      } else {
        line.innerHTML = '<span class="dot dot-off"></span>' +
          "<b>No active credential</b>";
      }
    }

    var list = node.querySelector(".cred-children");
    if (list) {
      if (status.credentials.length) {
        list.innerHTML = status.credentials.map(function (child) {
          return renderChild(child, editable);
        }).join("");
      } else {
        list.innerHTML = '<li class="cred-child cred-child-empty">' +
          "No credentials added yet.</li>";
      }
    }

    // "Make this the active credential" defaults to on only while the provider
    // has nothing active -- otherwise adding a spare would silently take over.
    var activateNew = node.querySelector(".cred-activate-new");
    if (activateNew) activateNew.checked = !status.has_active;

    var add = node.querySelector(".cred-add");
    if (add) add.open = !status.credentials.length;
  }

  function applyAll(statuses) {
    (statuses || []).forEach(applyStatus);
    // The selector's ticks come from the same statuses, so activating a
    // credential marks its provider selectable without a reload.
    (statuses || []).forEach(function (status) {
      var pick = document.querySelector(
        '.provider-pick[data-provider="' + status.name + '"]');
      if (!pick) return;
      pick.dataset.configured = status.configured ? "1" : "";
      if (status.configured) {
        pick.removeAttribute("data-blocked");
      } else {
        pick.dataset.blocked = "1";
      }
      var tick = pick.querySelector(".tick");
      if (tick) {
        tick.className = "tick " + (status.configured ? "tick-ok" : "tick-no");
        tick.textContent = status.configured ? "✓" : "✕";
        tick.title = status.configured ? "Configured" : "Not configured";
      }
    });
  }

  /* --- actions ------------------------------------------------------------ */

  function extrasOf(node) {
    var extras = {};
    Array.prototype.forEach.call(node.querySelectorAll(".cred-extra"),
      function (input) {
        if (input.value.trim()) extras[input.dataset.extra] = input.value.trim();
      });
    return extras;
  }

  /** POST to a per-credential route and repaint everything from the response. */
  function act(button, template, id, body, box, tone) {
    LMUI.loading(button, true);
    return LMUI.postJson(idUrl(template, id), body || {})
      .then(function (data) {
        applyAll(data.providers);
        result(box, data.message, tone || "ok");
        (tone === "info" ? LMUI.info : LMUI.ok)("Credentials", data.message);
        return data;
      })
      .catch(function (error) {
        result(box, error.message, "err");
        LMUI.error("Could not apply the change", error.message);
      })
      .finally(function () { LMUI.loading(button, false); });
  }

  document.addEventListener("click", function (event) {
    var node = event.target.closest(".cred-card");
    if (!node) return;
    var provider = node.dataset.provider;
    var box = node.querySelector(".cred-result");
    var row = event.target.closest(".cred-child");
    var id = row ? row.dataset.id : "";

    // Show / hide the key being typed.
    var reveal = event.target.closest(".cred-reveal");
    if (reveal) {
      var keyField = node.querySelector(".cred-key");
      var showing = keyField.type === "text";
      keyField.type = showing ? "password" : "text";
      reveal.querySelector(".cred-reveal-label").textContent =
        showing ? "Show" : "Hide";
      reveal.querySelector("use").setAttribute(
        "href", showing ? "#i-eye" : "#i-eye-off");
      return;
    }

    // Add a credential. The one request that carries a key.
    var save = event.target.closest(".cred-save");
    if (save) {
      var input = node.querySelector(".cred-key");
      var key = input.value.trim();
      if (!key) {
        result(box, "Enter an API key.", "warn");
        input.focus();
        return;
      }
      var label = node.querySelector(".cred-label");
      var desc = node.querySelector(".cred-desc");
      var wanted = node.querySelector(".cred-activate-new");

      LMUI.loading(save, true, "Saving…");
      LMUI.postJson(providerUrl(URLS.add, provider), {
        api_key: key,
        label: label ? label.value.trim() : "",
        description: desc ? desc.value.trim() : "",
        extras: extrasOf(node),
        model: (node.querySelector(".cred-model") || {}).value || "",
        activate: wanted ? wanted.checked : null,
      })
        .then(function (data) {
          input.value = "";                   // cleared the moment it is sent
          input.type = "password";
          if (label) label.value = "";
          if (desc) desc.value = "";
          var model = node.querySelector(".cred-model");
          if (model) model.value = "";
          Array.prototype.forEach.call(node.querySelectorAll(".cred-extra"),
            function (extra) { extra.value = ""; });

          applyAll(data.providers);
          var tone = data.verified && data.verified !== "ok" ? "warn" : "ok";
          result(box, data.message, tone);
          if (tone === "ok") LMUI.ok("Saved", data.message);
          else LMUI.warn("Saved, but not verified", data.message);
        })
        .catch(function (error) {
          result(box, error.message, "err");
          LMUI.error("Could not save", error.message);
        })
        .finally(function () { LMUI.loading(save, false); });
      return;
    }

    if (!row) return;

    if (event.target.closest(".cred-activate")) {
      act(event.target.closest(".cred-activate"), URLS.activate, id, {}, box);
      return;
    }

    if (event.target.closest(".cred-deactivate")) {
      var stand = event.target.closest(".cred-deactivate");
      LMUI.modal({
        title: "Deactivate this credential?",
        message: "Nothing is promoted in its place. This provider will use its " +
                 "environment variable if one is set, and otherwise have no " +
                 "credential at all until you activate another.",
        kind: "warn",
        confirmLabel: "Deactivate",
      }).then(function (go) {
        if (go) act(stand, URLS.deactivate, id, {}, box, "info");
      });
      return;
    }

    if (event.target.closest(".cred-fallback")) {
      var toggle = event.target.closest(".cred-fallback");
      act(toggle, URLS.fallback, id,
          { enabled: toggle.dataset.enabled !== "1" }, box, "info");
      return;
    }

    if (event.target.closest(".cred-delete")) {
      var remove = event.target.closest(".cred-delete");
      var active = row.classList.contains("is-active");
      LMUI.modal({
        title: "Delete this credential?",
        message: "The stored key is deleted and cannot be recovered." +
          (active
            ? " It is the ACTIVE credential: this provider will be left with " +
              "no active credential, and no other key is promoted in its place."
            : ""),
        kind: "warn",
        confirmLabel: "Delete",
        confirmClass: "btn-danger-ghost",
      }).then(function (go) {
        if (go) act(remove, URLS["delete"], id, {}, box, "info");
      });
      return;
    }

    // Test one credential. Repaints the row, because the verdict is recorded
    // against it -- but never changes which credential is active.
    var test = event.target.closest(".cred-test");
    if (test) {
      LMUI.loading(test, true, "Testing…");
      result(box, "Making a minimal request…", "info");
      LMUI.postJson(idUrl(URLS.test, id), {})
        .then(function (data) {
          applyStatus(data.status);
          result(box, data.message, data.result === "ok" ? "ok" : "warn");
          if (data.result === "ok") LMUI.ok("Connected", data.message);
          else LMUI.warn("Test finished", data.message);
        })
        .catch(function (error) {
          result(box, error.message, "err");
          LMUI.error("Test failed", error.message);
        })
        .finally(function () { LMUI.loading(test, false); });
      return;
    }
  });

  /* --- provider selector -------------------------------------------------- */

  var selector = document.getElementById("provider-select");
  var selectStatus = document.getElementById("select-status");

  function setSelectStatus(message, kind) {
    if (!selectStatus) return;
    selectStatus.className = "banner banner-" + (kind || "info");
    selectStatus.style.marginTop = "var(--sp-3)";
    selectStatus.innerHTML = LMUI.iconMarkup(ICONS[kind || "info"]) +
      "<span>" + LMUI.escapeHtml(message) + "</span>";
    selectStatus.classList.remove("is-hidden");
  }

  if (selector) {
    selector.addEventListener("click", function (event) {
      var pick = event.target.closest(".provider-pick");
      if (!pick || pick.classList.contains("is-active")) return;

      if (pick.dataset.blocked) {
        // Refused in the browser as well as on the server, so the message
        // arrives before a pointless round trip.
        setSelectStatus(pick.dataset.label + " is not configured. Please add " +
                        pick.dataset.label + " credentials in Settings.", "warn");
        return;
      }

      setSelectStatus("Switching provider…", "info");
      LMUI.postJson(URLS.select, { provider: pick.dataset.provider })
        .then(function (data) {
          setSelectStatus(data.message + " Model: " + data.model, "ok");
          LMUI.ok("Provider changed", data.message);
          window.setTimeout(function () { window.location.reload(); }, 900);
        })
        .catch(function (error) {
          setSelectStatus(error.message, "err");
          LMUI.error("Could not change provider", error.message);
        });
    });
  }
})();
