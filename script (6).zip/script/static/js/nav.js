/*
 * The mobile navigation drawer.
 *
 * The page navigates correctly with this file absent: the links are real anchors in the
 * document, and CSS alone decides whether they sit in a header row or off-canvas. All
 * this adds is opening and closing.
 *
 * What it is careful about:
 *
 *   * **The scrim is `hidden` when closed**, not just transparent. A full-screen
 *     invisible div left in the page would swallow every tap.
 *   * **Focus goes into the drawer and comes back.** Opening a menu and leaving the
 *     keyboard behind on the button is the usual bug; so is closing it and losing
 *     focus to the top of the document.
 *   * **Escape closes it**, because every overlay in this project already does.
 *   * **It closes itself at desktop width.** Resize or rotate a phone with the drawer
 *     open and the CSS puts the nav back in the header row -- leaving `nav-open` on the
 *     body would keep a scrim over a page that no longer has a drawer.
 *   * **Body scroll is locked while it is open**, so a swipe moves the drawer's own
 *     list rather than the page behind it.
 */
(function () {
  "use strict";

  var toggle = document.getElementById("nav-toggle");
  var drawer = document.getElementById("site-nav");
  var scrim = document.getElementById("nav-scrim");
  var closer = document.getElementById("nav-close");

  // Nothing to wire on a page that does not include the header.
  if (!toggle || !drawer || !scrim) return;

  // The width the CSS hands the nav back to the header row at. Kept in step with the
  // `max-width: 1023px` query by name, so the two cannot drift silently.
  var DESKTOP = window.matchMedia("(min-width: 1024px)");

  var lastFocused = null;

  function isOpen() {
    return document.body.classList.contains("nav-open");
  }

  function open() {
    if (isOpen()) return;
    lastFocused = document.activeElement;
    document.body.classList.add("nav-open");
    scrim.hidden = false;
    toggle.setAttribute("aria-expanded", "true");
    // Stops the page behind scrolling under the drawer.
    document.body.style.overflow = "hidden";
    // The close button rather than the first link: it is the control somebody
    // reaching for the keyboard most likely wants, and tabbing on reaches the links.
    (closer || drawer.querySelector(".navlink")).focus();
  }

  function close(restoreFocus) {
    if (!isOpen()) return;
    document.body.classList.remove("nav-open");
    scrim.hidden = true;
    toggle.setAttribute("aria-expanded", "false");
    document.body.style.overflow = "";
    if (restoreFocus !== false) {
      (lastFocused && document.contains(lastFocused) ? lastFocused : toggle).focus();
    }
    lastFocused = null;
  }

  toggle.addEventListener("click", function () {
    if (isOpen()) close(); else open();
  });

  if (closer) closer.addEventListener("click", function () { close(); });

  // Tapping the page outside the drawer.
  scrim.addEventListener("click", function () { close(); });

  /*
   * Selecting a page closes the drawer.
   *
   * Not strictly required -- the click navigates and the next document arrives with a
   * closed drawer -- but on a slow connection the drawer would sit there over a page
   * that is already on its way, which reads as a tap that did nothing.
   *
   * `restoreFocus: false`: returning focus to the toggle while the browser is
   * navigating away steals it from the incoming page.
   */
  drawer.addEventListener("click", function (event) {
    if (event.target.closest(".navlink")) close(false);
  });

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape" && isOpen()) {
      event.preventDefault();
      close();
    }
  });

  /*
   * Back to desktop while it is open.
   *
   * `addEventListener` on the query rather than a resize listener: it fires once when
   * the breakpoint is crossed instead of on every pixel of a drag.
   */
  function onBreakpoint(event) {
    if (event.matches) close(false);
  }
  if (DESKTOP.addEventListener) {
    DESKTOP.addEventListener("change", onBreakpoint);
  } else if (DESKTOP.addListener) {
    // Safari before 14.
    DESKTOP.addListener(onBreakpoint);
  }
})();
