/*
 * One website audit: watch it, edit the email, send it after confirming.
 *
 * The important thing this file does not do is send. The Send button opens a
 * confirmation showing the recipient and the subject, and only the answer to that
 * question puts `confirm: true` in the request — which is the field the server
 * requires. A replayed fetch, a double-click or a stray script gets a 400.
 *
 * The status half only reads. It polls one endpoint that counts rows and reports the
 * job's state; it cannot advance the audit, which is what makes the numbers on screen
 * worth believing. When the job reaches a state a person can act on, the page
 * reloads once to render the results properly rather than trying to build them here.
 */
(function () {
  "use strict";

  var script = document.currentScript;
  var URLS = {
    state: script.dataset.stateUrl,
    save: script.dataset.saveUrl,
    regenerate: script.dataset.regenerateUrl,
    send: script.dataset.sendUrl,
    retry: script.dataset.retryUrl,
  };

  var status = document.getElementById("draft-status");

  function say(message, kind) {
    if (!status) return;
    var icons = { info: "i-info", ok: "i-check-circle", warn: "i-alert",
                  err: "i-x-circle" };
    status.className = "banner banner-" + (kind || "info");
    status.innerHTML = LMUI.iconMarkup(icons[kind || "info"]) +
      "<span>" + LMUI.escapeHtml(message) + "</span>";
    status.classList.remove("is-hidden");
  }

  /* --- progress (§4) ------------------------------------------------------- */

  var FAST = 2500;
  var timer = null;

  function put(attribute, value) {
    document.querySelectorAll("[" + attribute + "]").forEach(function (node) {
      node.textContent = value;
    });
  }

  function paint(data) {
    put("data-audit-found", data.pages_found);
    put("data-audit-crawled", data.pages_crawled);
    put("data-audit-label", data.state_label);
    put("data-audit-note", data.note || "");

    var bar = document.querySelector("[data-audit-bar]");
    if (bar) bar.style.width = (data.percent || 0) + "%";

    var pill = document.querySelector(".audit-state");
    if (pill) {
      var classes = { sent: "pill-ok", failed: "pill-err",
                      ready_for_review: "pill-brand" };
      pill.className = "pill audit-state " + (classes[data.state] || "");
      pill.textContent = data.state_label;
    }

    var checks = document.querySelector("[data-audit-checks]");
    if (checks && data.page_checks) {
      var html = "";
      data.page_checks.forEach(function (check) {
        html += '<li class="page-check' + (check.found ? " is-found" : "") + '">' +
          LMUI.iconMarkup(check.found ? "i-check-circle" : "i-x", "icon-sm") +
          " " + LMUI.escapeHtml(check.label) +
          ' <span class="muted small">' +
          (check.found ? "found" : "not found") + "</span></li>";
      });
      checks.innerHTML = html;
    }

    // Done, one way or another. Reload once so the results, the contact table and
    // the editor are rendered by the template rather than assembled here.
    if (data.reload) {
      window.clearTimeout(timer);
      window.location.reload();
      return;
    }
    timer = window.setTimeout(poll, FAST);
  }

  function poll() {
    fetch(URLS.state, { headers: { "X-Requested-With": "fetch" } })
      .then(function (response) {
        if (!response.ok) throw new Error("state unavailable");
        return response.json();
      })
      .then(paint)
      .catch(function () {
        timer = window.setTimeout(poll, 8000);
      });
  }

  var progress = document.getElementById("audit-progress");
  if (progress && !progress.hidden) timer = window.setTimeout(poll, 1200);

  /* --- audit again --------------------------------------------------------- */

  ["audit-retry", "audit-retry-2"].forEach(function (id) {
    var button = document.getElementById(id);
    if (!button || !URLS.retry) return;
    button.addEventListener("click", function () {
      LMUI.loading(button, true, "Starting…");
      LMUI.postJson(URLS.retry, {})
        .then(function () { window.location.reload(); })
        .catch(function (error) {
          LMUI.loading(button, false);
          LMUI.error("Not started", error.message);
        });
    });
  });

  /* --- the editor (§14) --------------------------------------------------- */

  var recipient = document.getElementById("draft-recipient");
  var subject = document.getElementById("draft-subject");
  var body = document.getElementById("draft-body");
  var saveButton = document.getElementById("draft-save");
  var sendButton = document.getElementById("draft-send");
  var regenerateButton = document.getElementById("draft-regenerate");
  var counter = document.getElementById("word-count");

  function words() {
    return body ? (body.value.trim().split(/\s+/).filter(Boolean).length) : 0;
  }

  if (body && counter) {
    body.addEventListener("input", function () {
      counter.textContent = words();
    });
  }

  /* Picking a different address out of the ranked list (§10). */
  document.querySelectorAll(".recipient-choice").forEach(function (radio) {
    radio.addEventListener("change", function () {
      if (recipient && radio.checked) {
        recipient.value = radio.value;
        say("Recipient changed to " + radio.value +
            ". Press Save draft to keep it.", "info");
      }
    });
  });

  function payload() {
    return {
      recipient: recipient ? recipient.value.trim() : "",
      subject: subject ? subject.value : "",
      body: body ? body.value : "",
    };
  }

  function save(button, quiet) {
    LMUI.loading(button, true, "Saving…");
    return LMUI.postJson(URLS.save, payload())
      .then(function (data) {
        if (!quiet) say(data.message, "ok");
        if (data.blocked) say(data.blocked, "warn");
        return data;
      })
      .catch(function (error) {
        say(error.message, "err");
        throw error;
      })
      .then(function (data) {
        LMUI.loading(button, false);
        return data;
      }, function (error) {
        LMUI.loading(button, false);
        throw error;
      });
  }

  if (saveButton) {
    saveButton.addEventListener("click", function () {
      save(saveButton, false).catch(function () {});
    });
  }

  if (regenerateButton) {
    regenerateButton.addEventListener("click", function () {
      LMUI.modal({
        title: "Write the email again?",
        message: "It will be rewritten from the same findings — the website is " +
                 "not read again. Any edits you have made to the text will be " +
                 "replaced.",
        confirmLabel: "Regenerate",
      }).then(function (ok) {
        if (!ok) return;
        LMUI.loading(regenerateButton, true, "Writing…");
        LMUI.postJson(URLS.regenerate, {})
          .then(function (data) {
            if (subject) subject.value = data.subject || "";
            if (body) body.value = data.body || "";
            if (counter) counter.textContent = words();
            say(data.message, "ok");
          })
          .catch(function (error) { say(error.message, "err"); })
          .then(function () { LMUI.loading(regenerateButton, false); });
      });
    });
  }

  /* --- sending, after a confirmation (§15) -------------------------------- */

  if (sendButton) {
    sendButton.addEventListener("click", function () {
      var to = recipient ? recipient.value.trim() : "";
      var line = subject ? subject.value.trim() : "";

      if (!to) {
        say("Enter a recipient first. Nothing was published on the site, so " +
            "there is nobody to send to yet.", "warn");
        return;
      }

      // Saved first, so what is sent is what is on screen -- including an edit
      // somebody made and did not save.
      save(sendButton, true).then(function () {
        return LMUI.modal({
          kind: "warn",
          title: "Send this email?",
          message: "To: " + to + "\nSubject: " + line +
                   "\n\nThis sends now, from your connected mailbox.",
          confirmLabel: "Send",
        });
      }).then(function (confirmed) {
        if (!confirmed) {
          say("Not sent.", "info");
          return;
        }
        var account = document.getElementById("draft-account");
        LMUI.loading(sendButton, true, "Sending…");
        return LMUI.postJson(URLS.send, {
          // The field the server requires. Without it the request is refused,
          // which is what stops an accidental or replayed send.
          confirm: true,
          account: account ? account.value : null,
        }).then(function (data) {
          LMUI.ok("Sent", data.message);
          window.location.reload();
        }).catch(function (error) {
          LMUI.loading(sendButton, false);
          say(error.message, "err");
          LMUI.error("Not sent", error.message);
        });
      }).catch(function () {
        LMUI.loading(sendButton, false);
      });
    });
  }
})();
