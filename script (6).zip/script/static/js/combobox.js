/*
 * Searchable combobox — registers itself as LMUI.combobox.
 *
 * A native <select> is unusable at 282 countries or 3,400 cities: it only jumps
 * by first letter. A bare <datalist> gives no keyboard model and cannot be
 * styled. So this is an input plus a filtered listbox — type to narrow, arrows
 * to move, Enter to pick, Escape to close.
 *
 * It deliberately still accepts a value that is not in the list. The city
 * dataset stops at roughly 15,000 population while the geocoder happily resolves
 * far smaller places, so refusing unlisted text would make the app worse at its
 * actual job.
 *
 *   var box = LMUI.combobox(input, {options: [...], onSelect: fn});
 *   box.setOptions(next);   // when a dependent list changes
 */
window.LMUI.combobox = function (input, config) {
  "use strict";
  config = config || {};

  var options = config.options || [];
  var limit = config.limit || 60;
  var open = false;
  var active = -1;
  var shown = [];

  var wrap = document.createElement("div");
  wrap.className = "combo";
  input.parentNode.insertBefore(wrap, input);
  wrap.appendChild(input);

  var list = document.createElement("ul");
  list.className = "combo-list is-hidden";
  list.id = input.id + "-list";
  list.setAttribute("role", "listbox");
  wrap.appendChild(list);

  var empty = document.createElement("div");
  empty.className = "combo-empty is-hidden";
  wrap.appendChild(empty);

  input.setAttribute("role", "combobox");
  input.setAttribute("aria-expanded", "false");
  input.setAttribute("aria-autocomplete", "list");
  input.setAttribute("aria-controls", list.id);
  input.autocomplete = "off";

  function label(option) {
    return typeof option === "string" ? option : option.name;
  }

  function note(option) {
    if (typeof option === "string" || !option.population) return "";
    return option.population >= 1000000
      ? (option.population / 1000000).toFixed(1) + "m"
      : Math.round(option.population / 1000) + "k";
  }

  /** Prefix matches first: typing "ber" should surface Berlin before Bamberg. */
  function filter(query) {
    var q = query.trim().toLowerCase();
    if (!q) return options.slice(0, limit);
    var starts = [];
    var contains = [];
    for (var i = 0; i < options.length; i++) {
      var text = label(options[i]).toLowerCase();
      var at = text.indexOf(q);
      if (at === 0) {
        starts.push(options[i]);
      } else if (at > 0) {
        contains.push(options[i]);
      }
      if (starts.length >= limit) break;
    }
    return starts.concat(contains).slice(0, limit);
  }

  function render() {
    list.innerHTML = "";
    shown.forEach(function (option, index) {
      var item = document.createElement("li");
      item.className = "combo-item" + (index === active ? " is-active" : "");
      item.setAttribute("role", "option");
      item.setAttribute("aria-selected", index === active ? "true" : "false");
      item.textContent = label(option);

      var extra = note(option);
      if (extra) {
        var span = document.createElement("span");
        span.className = "combo-note";
        span.textContent = extra;
        item.appendChild(span);
      }

      item.addEventListener("mousedown", function (event) {
        event.preventDefault();       // keep focus in the input
        choose(index);
      });
      list.appendChild(item);
    });

    var none = shown.length === 0;
    empty.textContent = none
      ? (config.emptyText || "No match — your text is used exactly as typed.")
      : "";
    empty.classList.toggle("is-hidden", !none || !open);
    list.classList.toggle("is-hidden", none || !open);
  }

  function show() {
    if (input.disabled) return;
    open = true;
    input.setAttribute("aria-expanded", "true");
    shown = filter(input.value);
    active = shown.length ? 0 : -1;
    render();
  }

  function hide() {
    open = false;
    active = -1;
    input.setAttribute("aria-expanded", "false");
    list.classList.add("is-hidden");
    empty.classList.add("is-hidden");
  }

  function choose(index) {
    var option = shown[index];
    if (!option) return;
    input.value = label(option);
    hide();
    if (config.onSelect) config.onSelect(label(option), option);
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function move(step) {
    if (!open) {
      show();
      return;
    }
    if (!shown.length) return;
    active = (active + step + shown.length) % shown.length;
    render();
    var node = list.children[active];
    if (node) node.scrollIntoView({ block: "nearest" });
  }

  input.addEventListener("input", function () {
    show();
    if (config.onInput) config.onInput(input.value);
  });
  input.addEventListener("focus", show);
  input.addEventListener("blur", function () { setTimeout(hide, 120); });

  input.addEventListener("keydown", function (event) {
    if (event.key === "ArrowDown") {
      event.preventDefault();
      move(1);
    } else if (event.key === "ArrowUp") {
      event.preventDefault();
      move(-1);
    } else if (event.key === "Enter") {
      if (open && active >= 0) {
        event.preventDefault();
        choose(active);
      }
    } else if (event.key === "Escape" || event.key === "Tab") {
      hide();
    }
  });

  return {
    setOptions: function (next) {
      options = next || [];
      if (open) show();
    },
    getOptions: function () { return options; },
    /** Is the current text one of the offered options? */
    matches: function () {
      var value = input.value.trim().toLowerCase();
      return options.some(function (option) {
        return label(option).toLowerCase() === value;
      });
    },
    clear: function () { input.value = ""; hide(); },
    close: hide,
  };
};
