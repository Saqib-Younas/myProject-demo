/*
 * The automation dashboard: Start, and a live view of what the worker did.
 *
 * The important thing this file does *not* do is drive the campaign. There is no
 * timer here that processes leads, no counter incremented in the browser, and no
 * state that exists only while the page is open. It polls one read-only endpoint and
 * paints what came back.
 *
 * That distinction is worth being explicit about, because a dashboard that appeared
 * to run a campaign would make the one question a user actually has -- "is this
 * still going?" -- unanswerable. Close the tab and the worker carries on; open it
 * tomorrow and it shows what happened overnight.
 *
 * Polling slows down when nothing is happening: a campaign outside its window is
 * checked every couple of minutes rather than every five seconds, because the answer
 * cannot change until the window opens.
 */
(function () {
  "use strict";

  var script = document.currentScript;
  var STATE_URL = script.dataset.stateUrl;
  var START_URL = script.dataset.startUrl;

  /* --- Start --------------------------------------------------------------- */

  var startButton = document.getElementById("automation-start");
  if (startButton && START_URL) {
    startButton.addEventListener("click", function () {
      LMUI.modal({
        title: "Start this campaign?",
        message: "The background worker will begin finding businesses, reading " +
                 "their websites and sending — inside this campaign's hours and " +
                 "up to its limits. You can pause it at any time.",
        confirmLabel: "Start campaign",
      }).then(function (ok) {
        if (!ok) return;
        LMUI.loading(startButton, true, "Starting…");
        LMUI.postJson(START_URL, {})
          .then(function (data) {
            LMUI.ok(data.status_label || "Started", data.message);
            window.location.reload();
          })
          .catch(function (error) {
            LMUI.loading(startButton, false);
            LMUI.error("Not started", error.message);
          });
      });
    });
  }

  /* --- live figures -------------------------------------------------------- */

  if (!STATE_URL) return;

  var FAST = 6000;        // something is happening
  var SLOW = 120000;      // outside the window, or finished
  var timer = null;
  var lastEventAt = "";

  function put(name, text) {
    document.querySelectorAll('[data-figure="' + name + '"]').forEach(
      function (node) { node.textContent = text; });
  }

  function bar(name, done, target) {
    var fill = document.querySelector('[data-bar="' + name + '"]');
    if (!fill) return;
    var percent = target > 0 ? Math.min(100, Math.round(100 * done / target)) : 0;
    fill.style.width = percent + "%";
  }

  function paintEvents(events) {
    var list = document.getElementById("worklog");
    if (!list || !events || !events.length) return;

    // Only repaint when the newest line changed. Rewriting the list on every poll
    // would reset a scroll position and any text somebody was reading.
    if (events[0].at === lastEventAt) return;
    lastEventAt = events[0].at;

    var html = "";
    events.forEach(function (event) {
      html += '<li class="worklog-row' + (event.bad ? " is-bad" : "") + '">' +
        '<time class="worklog-time" datetime="' + LMUI.escapeHtml(event.at) +
        '">' + LMUI.escapeHtml(event.time) + "</time>" +
        '<span class="worklog-kind pill">' + LMUI.escapeHtml(event.kind) +
        "</span>" +
        '<span class="worklog-what">' + LMUI.escapeHtml(event.message) +
        (event.detail
          ? '<span class="worklog-detail">' + LMUI.escapeHtml(event.detail) +
            "</span>"
          : "") +
        "</span></li>";
    });
    list.innerHTML = html;
  }

  function paint(data) {
    var figures = data.figures || {};

    Object.keys(figures).forEach(function (key) {
      var value = figures[key];
      if (typeof value === "number" || typeof value === "string") {
        put(key, value);
      }
    });

    put("today_line", figures.today_sent + " / " + figures.daily_target);
    put("total_line", figures.sent + " / " + figures.total_target);
    bar("today", figures.today_sent, figures.daily_target);
    bar("total", figures.sent, figures.total_target);

    var pill = document.querySelector(".status-pill");
    if (pill && data.status_label) {
      var classes = { active: "pill-ok", paused: "pill-warn", stopped: "pill-err",
                      failed: "pill-err", completed: "pill-brand" };
      pill.className = "pill status-pill " + (classes[data.status] || "");
      pill.textContent = data.status_label;
    }

    var banner = document.getElementById("window-banner");
    if (banner && data.window && data.status !== "draft") {
      var span = banner.querySelector("span:last-child");
      if (span && data.window.reason) {
        var lead = data.status === "completed" ? "Completed. "
          : data.window.open ? "Running. " : "Waiting. ";
        span.textContent = lead + data.window.reason;
      }
    }

    paintEvents(data.events);

    // A campaign that cannot do anything until tomorrow does not need checking
    // every six seconds.
    var busy = data.status === "active" && data.window && data.window.open;
    schedule(busy ? FAST : SLOW);
  }

  function schedule(delay) {
    window.clearTimeout(timer);
    timer = window.setTimeout(poll, delay);
  }

  function poll() {
    fetch(STATE_URL, { headers: { "X-Requested-With": "fetch" } })
      .then(function (response) {
        if (!response.ok) throw new Error("state unavailable");
        return response.json();
      })
      .then(paint)
      .catch(function () {
        // A dropped request is not worth a toast: the next poll either works or
        // the page is gone. Back off so a server restart is not hammered.
        schedule(SLOW);
      });
  }

  // Nothing to poll for a campaign that has not been started.
  if (!document.getElementById("automation-start")) schedule(FAST);
})();
