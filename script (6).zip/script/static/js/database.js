/*
 * Settings → Database.
 *
 * Three rules, the same three the credential pool keeps:
 *
 *   1. A key is in an input for exactly as long as it takes to POST it, then cleared
 *      from the DOM. It is never put in localStorage, never in a URL, never logged.
 *   2. Nothing here decides what the state is. Every label, status line and mask
 *      painted back into the page comes from the server's response -- the browser only
 *      shows what it was told, because the browser cannot see either database.
 *   3. Switching asks first. It changes which database everybody's data is in, so it
 *      goes through a confirm dialog naming what will and will not happen.
 *
 * The page renders correctly from Django with no JavaScript at all; this file only
 * saves, tests and switches without a reload.
 */
(function () {
  "use strict";

  var URLS = {
    state: window.DB_STATE_URL,
    save: window.DB_STATE_URL.replace(/\/state$/, "/supabase"),
    test: window.DB_STATE_URL.replace(/\/state$/, "/test"),
    switch: window.DB_STATE_URL.replace(/\/state$/, "/switch")
  };

  var ICONS = { info: "i-info", ok: "i-check-circle", warn: "i-alert",
                err: "i-x-circle" };

  function $(id) { return document.getElementById(id); }

  /** Show a banner. `lines` is the per-check detail from a connection test. */
  function banner(node, message, kind, lines) {
    if (!node) return;
    node.className = "banner banner-" + (kind || "info");
    var html = LMUI.iconMarkup(ICONS[kind || "info"]) +
      "<span>" + LMUI.escapeHtml(message);
    if (lines && lines.length) {
      html += "<br>" + lines.map(function (line) {
        return "<span class=\"small\">" + LMUI.escapeHtml(line) + "</span>";
      }).join("<br>");
    }
    node.innerHTML = html + "</span>";
    node.classList.remove("is-hidden");
  }

  /* --- painting ----------------------------------------------------------- */

  /*
   * Repaint from a server payload.
   *
   * Deliberately partial: the status *text* and the selection highlight update, and
   * the rest of the page does not. A switch only takes effect on restart, so
   * repainting the whole page to look as though it had would be a lie the reload
   * would then contradict.
   */
  function paint(data) {
    if (!data) return;

    var label = $("db-active-label");
    if (label) label.textContent = data.active_label;

    var detail = $("db-active-detail");
    if (detail) detail.textContent = data.active_description;

    var summary = $("db-supabase-summary");
    if (summary && data.supabase && data.supabase.status) {
      summary.textContent = data.supabase.status.summary;
    }

    document.querySelectorAll(".db-pick").forEach(function (row) {
      var chosen = row.dataset.target === data.selection;
      row.classList.toggle("is-active", chosen);
      row.setAttribute("aria-checked", chosen ? "true" : "false");
    });

    // The restart notice appears the moment the selection and the live connection
    // disagree, which is exactly when it is true.
    var pending = $("db-pending");
    if (pending) pending.classList.toggle("is-hidden", !data.pending_restart);
  }

  /* --- actions ------------------------------------------------------------ */

  function save() {
    var button = $("db-save-supabase");
    var out = $("db-supabase-result");
    var anon = $("db-anon");
    var service = $("db-service");

    var body = {
      url: ($("db-url") || {}).value || "",
      // An empty field means "keep the stored key". That is why there is no need to
      // read one back from the server, and therefore no endpoint that returns one.
      anon_key: anon ? anon.value : "",
      service_key: service ? service.value : ""
    };

    LMUI.loading(button, true);
    LMUI.postJson(URLS.save, body)
      .then(function (data) {
        // Cleared as soon as the POST resolves, so a key is not sitting in the DOM
        // for the rest of the session.
        if (anon) anon.value = "";
        if (service) service.value = "";
        paint(data);
        banner(out, data.message, "ok");
        // "Save & Use Supabase": saving is half of what the button says.
        return switchTo("supabase", out, { saved: true });
      })
      .catch(function (error) {
        if (anon) anon.value = "";
        if (service) service.value = "";
        banner(out, error.message, "err");
      })
      .finally(function () { LMUI.loading(button, false); });
  }

  function test(target, button, out) {
    LMUI.loading(button, true);
    LMUI.postJson(URLS.test, { target: target })
      .then(function (data) {
        paint(data);
        banner(out, data.message, data.ok ? "ok" : "err", data.lines);
      })
      .catch(function (error) { banner(out, error.message, "err"); })
      .finally(function () { LMUI.loading(button, false); });
  }

  /*
   * Record a choice, after asking.
   *
   * The confirmation names the two things people assume wrongly: that data moves, and
   * that it happens now. Neither is true, and finding out afterwards is worse.
   */
  function switchTo(target, out, options) {
    options = options || {};
    var name = target === "local" ? "the local database" : "Supabase";

    var ask = options.saved
      ? Promise.resolve(true)
      : LMUI.modal({
          title: "Use " + name + "?",
          message: "No data will be copied, moved or deleted. The application keeps " +
                   "using the current database until it is restarted, and the " +
                   "selection is only recorded if " + name + " can be reached.",
          kind: "warn",
          confirmLabel: "Use " + name
        });

    return Promise.resolve(ask).then(function (agreed) {
      if (!agreed) return null;
      return LMUI.postJson(URLS.switch, { target: target })
        .then(function (data) {
          paint(data);
          banner(out, data.message, data.needs_restart ? "warn" : "ok");
          return data;
        })
        .catch(function (error) {
          // The server refused, which means nothing changed. Say which.
          banner(out, error.message, "err");
          return refresh();
        });
    });
  }

  function refresh() {
    return fetch(URLS.state, { headers: { "Accept": "application/json" } })
      .then(function (response) { return response.json(); })
      .then(function (data) { paint(data); return data; })
      .catch(function () { return null; });
  }

  /* --- wiring ------------------------------------------------------------- */

  document.addEventListener("DOMContentLoaded", function () {
    var saveButton = $("db-save-supabase");
    if (saveButton) saveButton.addEventListener("click", save);

    var testSupabase = $("db-test-supabase");
    if (testSupabase) {
      testSupabase.addEventListener("click", function () {
        test("supabase", testSupabase, $("db-supabase-result"));
      });
    }

    var checkLocal = $("db-check-local");
    if (checkLocal) {
      checkLocal.addEventListener("click", function () {
        test("local", checkLocal, $("db-local-result"));
      });
    }

    var useLocal = $("db-use-local");
    if (useLocal) {
      useLocal.addEventListener("click", function () {
        switchTo("local", $("db-local-result"), {});
      });
    }

    // The radio rows select; they do not switch. Pressing one scrolls to the section
    // that configures it, because a click that silently changed the live database
    // would be the worst possible reading of a radio button.
    document.querySelectorAll(".db-pick").forEach(function (row) {
      row.addEventListener("click", function () {
        var section = $(row.dataset.target === "local" ? "db-local" : "db-supabase");
        if (section) section.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    });
  });
})();
