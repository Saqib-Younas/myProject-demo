/*
 * The workspace's sending addresses.
 *
 * Same three rules as credentials.js, for the same reason -- a mailbox password
 * is worth more than an API key, because it can send mail as a person:
 *
 *   1. The password is held in the input for exactly as long as it takes to POST
 *      it, then cleared from the DOM. Never localStorage, never a URL, never a
 *      log line.
 *   2. Only the save request carries a password. Everything else sends an id, and
 *      the server re-reads that account against the signed-in user before acting.
 *   3. Everything painted back comes from the server's status -- the masked hint,
 *      the counters, the connection verdict. The browser never decides whether an
 *      address can send; it shows what it was told.
 *
 * `renderCard` mirrors the `.mailbox-card` markup Django writes in settings.html.
 * The two have to agree, and that duplication is the price of repainting the list
 * without reloading the page.
 */
(function () {
  "use strict";

  var script = document.currentScript;
  var URLS = {
    save: script.dataset.saveUrl,
    edit: script.dataset.editUrl,           // .../<id>/edit  (GET, no password)
    active: script.dataset.activeUrl,       // .../<id>/active
    test: script.dataset.testUrl,
    forget: script.dataset.forgetUrl,
    "delete": script.dataset.deleteUrl,
  };

  var grid = document.querySelector(".mailbox-grid");
  if (!grid) return;

  /** Substitute an id into a route Django reversed with a 0 placeholder. */
  function idUrl(template, id) {
    return template.replace(/\/0\//, "/" + encodeURIComponent(id) + "/");
  }

  var esc = function (value) { return LMUI.escapeHtml(value == null ? "" : value); };

  var ICONS = { info: "i-info", ok: "i-check-circle", warn: "i-alert",
                err: "i-x-circle" };

  function result(node, message, kind) {
    if (!node) return;
    node.className = (node.id === "mailbox-add-result"
      ? "cred-result banner banner-" : "mailbox-result banner banner-") +
      (kind || "info");
    node.innerHTML = LMUI.iconMarkup(ICONS[kind || "info"]) +
      "<span>" + esc(message) + "</span>";
    node.classList.remove("is-hidden");
  }

  /* --- painting ----------------------------------------------------------- */

  function meta(term, value) {
    return "<div><dt>" + esc(term) + "</dt><dd>" + esc(value) + "</dd></div>";
  }

  var DOTS = { active: "dot-ok", failing: "dot-err", unconfigured: "dot-warn" };

  /** One address card. Mirrors the `.mailbox-card` block in settings.html. */
  function renderCard(a) {
    var html = '<article class="mailbox-card" data-id="' + a.id +
      '" data-status="' + esc(a.status) + '">';

    html += '<header class="mailbox-head"><div><h3 class="mailbox-name">' +
      esc(a.name) +
      (a.is_active ? '<span class="pill pill-ok">ACTIVE</span>'
                   : '<span class="pill">off</span>') +
      '</h3><p class="mailbox-status"><span class="dot ' +
      (DOTS[a.status] || "dot-off") + '"></span><b>' + esc(a.sender_email) +
      '</b><span class="mailbox-source">' + esc(a.provider_label) +
      "</span></p></div>";

    if (!a.configured) {
      html += '<span class="pill pill-warn" title="No password stored — this ' +
        'address cannot send">no password</span>';
    } else if (a.connection_status === "failed") {
      html += '<span class="pill pill-err" title="' + esc(a.connection_detail) +
        '">last test failed</span>';
    } else if (a.connection_status === "ok") {
      html += '<span class="pill pill-brand">tested</span>';
    }
    html += "</header>";

    html += '<dl class="mailbox-meta">' +
      meta("Sent today", a.sent_today + " of " + a.daily_cap) +
      meta("Room today", a.remaining_today) +
      meta("Sent in total", a.sent_count) +
      meta("Failed", a.failed_count) +
      '<div><dt>Password</dt><dd class="mono">' + esc(a.masked || "—") +
      "</dd></div>" +
      meta("Reply-To", a.reply_to || "same address") +
      "</dl>";

    if (a.connection_detail) {
      html += '<p class="mailbox-test">Last test: ' +
        esc(a.connection_detail) + "</p>";
    }
    if (a.last_error) {
      html += '<p class="mailbox-err">' + esc(a.last_error) + "</p>";
    }

    html += '<div class="mailbox-actions">';
    html += a.is_active
      ? '<button type="button" class="btn btn-ghost btn-sm mailbox-off">' +
        '<span class="btn-label">Switch off</span>' +
        '<span class="spinner" aria-hidden="true"></span></button>'
      : '<button type="button" class="btn btn-primary btn-sm mailbox-on">' +
        LMUI.iconMarkup("i-check", "icon-sm") +
        '<span class="btn-label">Activate</span>' +
        '<span class="spinner" aria-hidden="true"></span></button>';
    // Mirrors settings.html. The two have to agree, which is the cost of
    // repainting a card without reloading the page.
    html += '<button type="button" class="btn btn-outline btn-sm mailbox-edit">' +
      LMUI.iconMarkup("i-edit", "icon-sm") +
      '<span class="btn-label">Edit</span>' +
      '<span class="spinner" aria-hidden="true"></span></button>';
    html += '<button type="button" class="btn btn-outline btn-sm mailbox-check">' +
      LMUI.iconMarkup("i-scan", "icon-sm") +
      '<span class="btn-label">Test connection</span>' +
      '<span class="spinner" aria-hidden="true"></span></button>' +
      '<button type="button" class="btn btn-ghost btn-sm mailbox-forget">' +
      '<span class="btn-label">Forget password</span>' +
      '<span class="spinner" aria-hidden="true"></span></button>' +
      '<span class="spacer"></span>' +
      '<button type="button" class="btn btn-ghost btn-sm btn-danger-ghost ' +
      'mailbox-delete">' + LMUI.iconMarkup("i-x", "icon-sm") +
      " Delete</button></div>";

    html += '<p class="mailbox-result banner is-hidden"></p></article>';
    return html;
  }

  /**
   * Repaint the list and the capacity line from the server's own view.
   *
   * `keep` is the id of the card whose message should survive the repaint: the
   * answer to "did the test pass" is the whole point of pressing the button, and
   * losing it to a redraw would make the button look like it did nothing.
   */
  function repaint(data, keep, message, kind) {
    if (!data || !data.accounts) return;

    if (data.accounts.length) {
      grid.innerHTML = data.accounts.map(renderCard).join("");
    } else {
      grid.innerHTML = '<p class="mailbox-empty muted">No sending addresses ' +
        "yet. Campaigns fall back to the single sender configured in " +
        "<code>.env</code> until you add one.</p>";
    }

    var summary = document.getElementById("mailbox-summary");
    if (summary && data.summary) {
      var s = data.summary;
      summary.textContent = s.total + " address" + (s.total === 1 ? "" : "es") +
        " · " + s.usable + " able to send · room for " + s.capacity +
        " more today";
    }

    if (keep && message) {
      var card = grid.querySelector('.mailbox-card[data-id="' + keep + '"]');
      if (card) result(card.querySelector(".mailbox-result"), message, kind);
    }
  }

  /* --- actions ------------------------------------------------------------ */

  /** Run one id-based action, with the button showing that it is running. */
  function act(button, card, url, body, kind) {
    var id = card.dataset.id;
    LMUI.loading(button, true);
    return LMUI.postJson(url, body || {})
      .then(function (data) {
        repaint(data, id, data.message, kind || "ok");
        return data;
      })
      .catch(function (error) {
        LMUI.loading(button, false);
        result(card.querySelector(".mailbox-result"), error.message, "err");
      });
  }

  grid.addEventListener("click", function (event) {
    var button = event.target.closest("button");
    if (!button) return;
    var card = button.closest(".mailbox-card");
    if (!card) return;
    var id = card.dataset.id;

    if (button.classList.contains("mailbox-edit")) {
      loadForEdit(button, card, id);

    } else if (button.classList.contains("mailbox-on")) {
      act(button, card, idUrl(URLS.active, id), { enabled: true });

    } else if (button.classList.contains("mailbox-off")) {
      // Switching off is not deletion, and the wording says so before it happens.
      LMUI.modal({
        kind: "warn",
        title: "Switch this address off?",
        message: "No further emails will be sent from it. Everything already " +
                 "sent, every scheduled follow-up and every reply is kept, and " +
                 "you can switch it back on at any time.",
        confirmLabel: "Switch off",
      }).then(function (ok) {
        if (ok) act(button, card, idUrl(URLS.active, id), { enabled: false },
                    "info");
      });

    } else if (button.classList.contains("mailbox-check")) {
      // Authenticates against SMTP and opens the mailbox. Sends nothing.
      var testId = id;
      LMUI.loading(button, true);
      LMUI.postJson(idUrl(URLS.test, id), {})
        .then(function (data) {
          repaint(data, testId, data.message,
                  data.result === "ok" ? "ok" : "warn");
        })
        .catch(function (error) {
          LMUI.loading(button, false);
          result(card.querySelector(".mailbox-result"), error.message, "err");
        });

    } else if (button.classList.contains("mailbox-forget")) {
      LMUI.modal({
        kind: "warn",
        title: "Forget the stored password?",
        message: "The address and its history stay. It will not be able to send " +
                 "again until a password is entered.",
        confirmLabel: "Forget it",
      }).then(function (ok) {
        if (ok) act(button, card, idUrl(URLS.forget, id), {}, "info");
      });

    } else if (button.classList.contains("mailbox-delete")) {
      LMUI.modal({
        kind: "warn",
        title: "Delete this address?",
        message: "Only possible while it has never sent anything. An address " +
                 "with history is switched off instead, so the record of who " +
                 "was contacted survives.",
        confirmLabel: "Delete",
        confirmClass: "btn-danger-ghost",
      }).then(function (ok) {
        if (!ok) return;
        LMUI.loading(button, true);
        LMUI.postJson(idUrl(URLS["delete"], id), {})
          .then(function (data) {
            repaint(data);
            LMUI.ok("Deleted", data.message);
          })
          .catch(function (error) {
            LMUI.loading(button, false);
            result(card.querySelector(".mailbox-result"), error.message, "err");
          });
      });
    }
  });

  /* --- adding ------------------------------------------------------------- */

  var form = document.querySelector("#mailbox-add .cred-add-body");
  var saveButton = document.getElementById("mailbox-save");
  var addResult = document.getElementById("mailbox-add-result");

  function field(name) {
    return form ? form.querySelector('[name="' + name + '"]') : null;
  }

  function value(name) {
    var node = field(name);
    return node ? node.value.trim() : "";
  }

  /** The provider's own note, so a Gmail app password is expected before it fails. */
  function showProviderNote() {
    var select = field("provider");
    var note = document.getElementById("mailbox-provider-note");
    if (!select || !note) return;
    var option = select.options[select.selectedIndex];
    note.textContent = option ? (option.dataset.note || "") : "";
  }

  if (form) {
    showProviderNote();
    var provider = field("provider");
    if (provider) provider.addEventListener("change", showProviderNote);
  }

  /* --- edit mode ----------------------------------------------------------
   *
   * One form for both jobs. `#mb-id` is the whole state: empty means "add", set means
   * "update that account". Nothing else in the page needs to know which mode it is in.
   *
   * The password is the part worth being careful about. Nothing ever sends one back --
   * `account_edit` cannot return one -- so on an update an empty field means "keep the
   * stored one" rather than "clear it". The form says so, and `save()` below skips the
   * "a password is required" check when an id is present. Clearing a password is a
   * separate, deliberate action: Forget password, on the card.
   */

  var idField = document.getElementById("mb-id");
  var formTitle = document.getElementById("mailbox-form-title");
  var editNote = document.getElementById("mailbox-edit-note");
  var editName = document.getElementById("mailbox-edit-name");
  var cancelButton = document.getElementById("mailbox-cancel");
  var passwordHint = document.getElementById("mailbox-password-hint");
  var passwordKept = document.getElementById("mailbox-password-kept");
  var passwordMask = document.getElementById("mailbox-password-mask");
  var addBlock = document.getElementById("mailbox-add");

  /** Every field the form owns, so filling and clearing cannot drift apart. */
  var TEXT_FIELDS = ["name", "sender_name", "sender_email", "reply_to", "signature",
                     "smtp_host", "smtp_port", "imap_host", "imap_port",
                     "daily_limit", "followup_max", "followup_delays"];

  function editing() {
    return Boolean(idField && idField.value);
  }

  /** Paint the form's chrome for whichever mode it is in. */
  function setMode(account) {
    var isEdit = Boolean(account);
    if (idField) idField.value = isEdit ? account.id : "";

    if (formTitle) {
      formTitle.textContent = isEdit
        ? "Edit " + (account.name || "sending address")
        : "Add a sending address";
    }
    if (editNote) editNote.classList.toggle("is-hidden", !isEdit);
    if (editName) editName.textContent = isEdit ? (account.name || "") : "";
    if (cancelButton) cancelButton.classList.toggle("is-hidden", !isEdit);

    var label = saveButton ? saveButton.querySelector(".btn-label") : null;
    if (label) label.textContent = isEdit ? "Update address" : "Save address";

    // Which password hint applies. Only show "a password is already stored" when one
    // actually is -- an account saved without one must still be asked for one.
    var hasStored = isEdit && account.configured;
    if (passwordHint) passwordHint.classList.toggle("is-hidden", hasStored);
    if (passwordKept) passwordKept.classList.toggle("is-hidden", !hasStored);
    if (passwordMask) passwordMask.textContent = hasStored ? (account.masked || "") : "";

    var password = field("password");
    if (password) {
      // Always empty on entering either mode: no stored password is ever put in the DOM.
      password.value = "";
      password.placeholder = hasStored
        ? "Leave blank to keep the stored password"
        : "Paste the app password";
    }
  }

  /** Fill every field from the server's own view of the account. */
  function fill(account) {
    TEXT_FIELDS.forEach(function (name) {
      var node = field(name);
      if (node) node.value = account[name] == null ? "" : account[name];
    });
    var provider = field("provider");
    if (provider && account.provider) provider.value = account.provider;
    var active = field("is_active");
    if (active) active.checked = Boolean(account.is_active);
    showProviderNote();
  }

  /** Back to a blank add form. */
  function resetForm() {
    TEXT_FIELDS.forEach(function (name) {
      var node = field(name);
      if (node) node.value = "";
    });
    var password = field("password");
    if (password) password.value = "";
    var active = field("is_active");
    if (active) active.checked = true;
    setMode(null);
  }

  if (cancelButton) {
    cancelButton.addEventListener("click", function () {
      resetForm();
      if (addResult) addResult.classList.add("is-hidden");
      if (addBlock) addBlock.open = false;
    });
  }

  /**
   * Load one account into the form.
   *
   * The values come from the server rather than from the card's own markup: a card shows
   * the effective daily cap, not the stored limit, and shows whether there is a signature
   * rather than the signature itself. Filling the form from what is on screen would
   * quietly rewrite both on the next save.
   */
  function loadForEdit(button, card, id) {
    LMUI.loading(button, true);
    fetch(idUrl(URLS.edit, id), { headers: { "Accept": "application/json" } })
      .then(function (response) {
        return response.json().then(function (data) {
          if (!response.ok) throw new Error(data.error || "Could not load it.");
          return data;
        });
      })
      .then(function (data) {
        var account = data.account;
        fill(account);
        setMode(account);
        if (addBlock) addBlock.open = true;
        if (form) form.scrollIntoView({ behavior: "smooth", block: "center" });
        var name = field("name");
        if (name) name.focus();
      })
      .catch(function (error) {
        var box = card ? card.querySelector(".mailbox-result") : null;
        result(box || addResult, error.message, "err");
      })
      .then(function () { LMUI.loading(button, false); });
  }


  if (saveButton) {
    saveButton.addEventListener("click", function () {
      var password = field("password");
      var payload = {
        // Present only when editing. `account_save` reads it and updates that
        // account; absent, it creates one.
        id: idField ? idField.value : "",
        name: value("name"),
        sender_name: value("sender_name"),
        sender_email: value("sender_email"),
        provider: value("provider"),
        password: password ? password.value : "",
        reply_to: value("reply_to"),
        signature: field("signature") ? field("signature").value : "",
        smtp_host: value("smtp_host"),
        smtp_port: value("smtp_port"),
        imap_host: value("imap_host"),
        imap_port: value("imap_port"),
        daily_limit: value("daily_limit"),
        followup_max: value("followup_max"),
        followup_delays: value("followup_delays"),
        is_active: field("is_active") ? field("is_active").checked : true,
      };

      if (!payload.name || !payload.sender_email) {
        result(addResult, "A name and a from address are both needed.", "warn");
        return;
      }
      // A password is required to create an account, and optional to update one:
      // blank on an update means "keep the stored one", which is the only thing it
      // can mean when no endpoint will ever hand one back.
      if (!payload.password && !editing()) {
        result(addResult, "Enter the app password for this mailbox. It is " +
                          "encrypted before it is stored.", "warn");
        return;
      }

      LMUI.loading(saveButton, true);
      LMUI.postJson(URLS.save, payload)
        .then(function (data) {
          // Out of the DOM the moment the request is away.
          if (password) password.value = "";
          repaint(data);
          result(addResult, data.message, "ok");
          LMUI.ok("Saved", data.message);
          // Back to a blank add form either way: an update is finished, and a
          // second address should not start half-filled with the first one's values.
          resetForm();
          // Re-shown after the reset, because the reset does not own the banner.
          result(addResult, data.message, "ok");
        })
        .catch(function (error) {
          if (password) password.value = "";
          result(addResult, error.message, "err");
        })
        .then(function () { LMUI.loading(saveButton, false); });
    });
  }
})();
