"""
Generates docs/workflow.svg and docs/workflow.png from one shared spec.

Run from the project root:

    python -m pip install pillow      # docs-time only, not an app dependency
    python docs/make_workflow.py

Both files come out of the same STAGES/geometry model on purpose. Drawing the
diagram twice by hand -- once as SVG, once as a raster -- is how the two versions
end up disagreeing about the thing they are supposed to explain.

Colours are the application's own design tokens (leads/static/leads/css/style.css)
so the diagram looks like it belongs to the product. Every phase carries a text
label as well as a colour, because a diagram that encodes meaning only in hue is
unreadable to a colour-blind reader and useless in greyscale print.
"""

from __future__ import annotations

import html
from pathlib import Path

OUT = Path(__file__).resolve().parent

# --------------------------------------------------------------------------- #
# Palette — the app's tokens
# --------------------------------------------------------------------------- #

INK = "#141930"
INK_2 = "#4C5470"
INK_3 = "#6B7490"
INK_4 = "#9AA2B8"
BORDER = "#E2E5EF"
SURFACE = "#FFFFFF"
PAGE = "#F7F8FC"

PHASES: dict[str, dict[str, str]] = {
    "discover": {"label": "1 · DISCOVER", "dark": "#4A37B4", "mid": "#6D5AE8", "tint": "#F2F1FE"},
    "qualify":  {"label": "2 · QUALIFY",  "dark": "#0C7284", "mid": "#12AFC7", "tint": "#E8FAFC"},
    "research": {"label": "3 · RESEARCH", "dark": "#3B2C8E", "mid": "#8B7AF2", "tint": "#F2F1FE"},
    "generate": {"label": "4 · GENERATE", "dark": "#4A37B4", "mid": "#6D5AE8", "tint": "#F2F1FE"},
    "review":   {"label": "5 · REVIEW",   "dark": "#9A5D02", "mid": "#C77A05", "tint": "#FDF4E3"},
    "send":     {"label": "6 · SEND",     "dark": "#0B7A3C", "mid": "#12A150", "tint": "#E8F7EF"},
    "record":   {"label": "7 · RECORD",   "dark": "#343B54", "mid": "#6B7490", "tint": "#EEF0F6"},
    "reply":    {"label": "8 · REPLIES",  "dark": "#0C7284", "mid": "#12AFC7", "tint": "#E8FAFC"},
}

# --------------------------------------------------------------------------- #
# The workflow. `note` is the plain-English "how", shown beside the box.
# --------------------------------------------------------------------------- #

STAGES: list[dict] = [
    {"phase": "discover", "title": "Lead Search",
     "lines": ["Country · City · Business category · Count"],
     "note": "Searchable country and city\npickers (~34,000 cities)"},
    {"phase": "discover", "title": "Lead Collection",
     "lines": ["Public business data from OpenStreetMap"],
     "note": "Nominatim geocodes the area,\nOverpass returns businesses"},
    {"phase": "discover", "title": "Lead Table + CSV Export",
     "lines": ["Map markers, result list, CSV written on completion"],
     "note": "CSV saved to exports/\nas soon as the search ends"},
    {"phase": "qualify", "title": "Do-Not-Contact + Duplicate Check",
     "lines": ["Against the do-not-contact list, then the sending history"],
     "note": "Suppression first (absolute), then\n3 tiers: email · domain · name+city"},
    {"phase": "qualify", "title": "Select Leads",
     "lines": ["Only leads with a public email address"],
     "note": "Already-contacted leads are\nbadged and unselectable"},
    {"phase": "research", "title": "Website Page Discovery", "loop": True,
     "lines": ["Navigation, footer, sitemap.xml, internal links"],
     "note": "Chooses a spread of page types,\nvisits home + 5 internal pages"},
    {"phase": "research", "title": "Website Analysis", "loop": True,
     "lines": ["UI/UX · content · images · CTA · navigation",
               "SEO · mobile · accessibility · performance"],
     "note": "Records measurable signals:\nalt text, load time, CTA counts"},
    {"phase": "generate", "title": "AI Findings", "loop": True,
     "lines": ["8–10 genuine opportunities, strongest first"],
     "note": "Every finding must cite evidence;\nunevidenced ones are discarded"},
    {"phase": "generate", "title": "AI Email Generation", "loop": True,
     "lines": ["One unique email per business"],
     "note": "Built on the 1–2 strongest\nfindings, tied to your offer"},
    {"phase": "generate", "title": "Save This Lead's Result", "loop": True,
     "lines": ["Pages read · findings · observation · subject · body"],
     "note": "Marked complete, and only then\ndoes the next lead begin"},
    {"phase": "review", "title": "Review · Edit · Regenerate",
     "lines": ["Every email is shown before anything is sent"],
     "note": "Re-review re-runs the analysis\nwithout re-crawling"},
    {"phase": "review", "title": "Human Approval",
     "lines": ["Approve or reject each email"],
     "note": "Nothing is sent without\nan explicit approval"},
    {"phase": "send", "title": "Final Duplicate Check",
     "lines": ["Re-checked immediately before SMTP opens"],
     "note": "Address is reserved in the\ndatabase — a second send fails"},
    {"phase": "send", "title": "Authenticated SMTP Sending",
     "lines": ["Your own account · rate limited · continues on failure",
               "Reply invitation appended to every message"],
     "note": "Gmail · Outlook · Zoho ·\nFastmail · custom SMTP"},
]

FORK = [
    {"phase": "record", "title": "Database History",
     "lines": ["Business · email · website · country · city",
               "campaign · date · time · subject · status"],
     "note": ""},
    {"phase": "record", "title": "Excel History Export",
     "lines": ["exports/sent_leads.xlsx", "New records appended, never overwritten"],
     "note": ""},
]

#: The guarantee strip. Two lines because one no longer fits the page width --
#: and a line of text running off the edge of a diagram is worse than no line.
FOOTER_LINES = (
    "Throughout: only publicly accessible pages are read · robots.txt is obeyed "
    "· CAPTCHAs, logins and paywalls are never bypassed.",
    "No lead is emailed twice · the do-not-contact list is never overridden · "
    "no follow-up is ever sent without a click.",
)
FOOTER_H = 64

#: After the campaign report: reply tracking, then the manual follow-up.
#: Drawn as a separate tail because it happens days later, on its own
#: trigger, and because the follow-up is gated on a person clicking twice.
TAIL: list[dict] = [
    {"phase": "reply", "title": "Check Inbox for Replies",
     "lines": ["Replied · Bounced · Unsubscribed · No reply"],
     "note": "Matched on the Message-ID we sent;\nunrelated mail is never stored"},
    {"phase": "reply", "title": "Manual Follow-Up",
     "lines": ["You click Create, review it, then click Send",
               "Never offered to a lead that replied · capped per lead"],
     "note": "Nothing is sent automatically —\nthe wait only makes it available"},
]


FINAL = {"phase": "record", "title": "Campaign Report",
         "lines": ["Total · Approved · Sent · Failed · Queued"],
         "note": "Per-recipient outcome, with\nthe error text for any failure"}

# --------------------------------------------------------------------------- #
# Geometry
# --------------------------------------------------------------------------- #

W = 1010
PAD_TOP = 150
BOX_W, BOX_H = 372, 82
GAP = 34
CX = 430                      # centre of the main column
RAIL_X = 52                   # phase chips
NOTE_X = 650                  # annotations
FORK_W, FORK_H = 330, 104
FORK_GAP = 44

# The per-lead loop is drawn as a band behind its stages, so the extra room has
# to be reserved in the column before anything is positioned.
LOOP_PAD_TOP = 80
LOOP_PAD_BOTTOM = 52
LOOP_LABEL = "ONE LEAD AT A TIME"
LOOP_CAPTION = ("The next lead's website is not opened until this lead's email "
                "has been written and saved.")


def layout() -> dict:
    """Positions for every element, shared by both renderers."""
    boxes, y = [], PAD_TOP
    inside_loop = False
    for stage in STAGES:
        loop = bool(stage.get("loop"))
        if loop and not inside_loop:
            y += LOOP_PAD_TOP          # room for the band's header chip
        elif inside_loop and not loop:
            y += LOOP_PAD_BOTTOM       # room for its caption
        boxes.append({**stage, "x": CX - BOX_W // 2, "y": y, "w": BOX_W, "h": BOX_H})
        y += BOX_H + GAP
        inside_loop = loop

    # The band needs three clear horizontal channels: its header chip, the
    # return path's two straights, and the caption. They collided when the band
    # was tight, so the top and bottom margins are generous on purpose.
    looped = [b for b in boxes if b.get("loop")]
    first_y = looped[0]["y"]
    last_bottom = looped[-1]["y"] + BOX_H
    band = {
        "x": CX - BOX_W // 2 - 22,
        "y": first_y - 72,
        "w": BOX_W + 44,
        "h": (last_bottom + 62) - (first_y - 72),
        "first_y": first_y,
        "last_bottom": last_bottom,
        "in_y": first_y - 22,          # return path rejoins here
        "out_y": last_bottom + 20,     # and leaves here
    }

    split_y = y + 8
    fork_y = split_y + 62
    total_fork_w = FORK_W * 2 + FORK_GAP
    fork_boxes = [
        {**FORK[0], "x": CX - total_fork_w // 2, "y": fork_y, "w": FORK_W, "h": FORK_H},
        {**FORK[1], "x": CX - total_fork_w // 2 + FORK_W + FORK_GAP, "y": fork_y,
         "w": FORK_W, "h": FORK_H},
    ]
    merge_y = fork_y + FORK_H + 46
    final_y = merge_y + 44
    final = {**FINAL, "x": CX - BOX_W // 2, "y": final_y, "w": BOX_W, "h": BOX_H}

    # The tail: what happens days later, once replies start arriving.
    tail, ty = [], final_y + BOX_H + GAP + 18
    for stage in TAIL:
        tail.append({**stage, "x": CX - BOX_W // 2, "y": ty, "w": BOX_W,
                     "h": BOX_H})
        ty += BOX_H + GAP

    return {
        "boxes": boxes,
        "band": band,
        "split_y": split_y,
        "fork": fork_boxes,
        "merge_y": merge_y,
        "final": final,
        "tail": tail,
        "height": tail[-1]["y"] + BOX_H + 42 + FOOTER_H + 34,
    }


def phase_bands(spec: dict) -> list[tuple[str, int, int, int]]:
    """(phase, top_y, bottom_y, chip_y) for every contiguous phase group.

    Includes the RECORD group, which lives in the fork and the final box rather
    than the main column -- computing bands from the main column alone left it
    unlabelled, which is exactly the colour-only encoding this diagram avoids.

    `chip_y` is separate from `top_y` because the fork row is wider than the main
    column and reaches into the rail: sitting the RECORD chip at the band top hid
    it behind the first fork card, so it is lifted into the gap above instead.
    """
    bands: list[list] = []
    for box in spec["boxes"]:
        top, bottom = box["y"], box["y"] + box["h"]
        if bands and bands[-1][0] == box["phase"]:
            bands[-1][2] = bottom
        else:
            bands.append([box["phase"], top, bottom, top])

    record_top = spec["fork"][0]["y"]
    record_bottom = spec["final"]["y"] + spec["final"]["h"]
    bands.append(["record", record_top, record_bottom, record_top - 34])

    tail = spec.get("tail") or []
    if tail:
        bands.append(["reply", tail[0]["y"],
                      tail[-1]["y"] + tail[-1]["h"], tail[0]["y"]])
    return [(p, t, b, c) for p, t, b, c in bands]


# --------------------------------------------------------------------------- #
# SVG
# --------------------------------------------------------------------------- #

def render_svg(spec: dict) -> str:
    H = spec["height"]
    out: list[str] = []
    add = out.append

    add(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
        f'viewBox="0 0 {W} {H}" font-family="Segoe UI, Helvetica, Arial, sans-serif">')
    add('<defs>')
    add('<linearGradient id="hdr" x1="0" y1="0" x2="1" y2="1">'
        '<stop offset="0" stop-color="#6D5AE8"/><stop offset="1" stop-color="#12AFC7"/>'
        '</linearGradient>')
    add('<filter id="sh" x="-20%" y="-20%" width="140%" height="160%">'
        '<feDropShadow dx="0" dy="2" stdDeviation="3" flood-color="#141930" '
        'flood-opacity="0.10"/></filter>')
    add('<marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" '
        'markerHeight="7" orient="auto-start-reverse">'
        f'<path d="M0,0 L10,5 L0,10 z" fill="{INK_4}"/></marker>')
    add('<marker id="loop-arrow" viewBox="0 0 10 10" refX="9" refY="5" '
        'markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
        f'<path d="M0,0 L10,5 L0,10 z" fill="{PHASES["research"]["dark"]}"/></marker>')
    add('</defs>')
    add(f'<rect width="{W}" height="{H}" fill="{PAGE}"/>')

    # Header
    add(f'<rect x="0" y="0" width="{W}" height="6" fill="url(#hdr)"/>')
    add(f'<text x="{RAIL_X}" y="62" font-size="30" font-weight="700" fill="{INK}">'
        'Lead Mapper — System Workflow</text>')
    add(f'<text x="{RAIL_X}" y="90" font-size="15" fill={chr(34)}{INK_3}{chr(34)}>'
        'Find business leads, research their websites, write a personalised email '
        'for each, review it, then send — without contacting anyone twice.</text>')
    add(f'<line x1="{RAIL_X}" y1="112" x2="{W - RAIL_X}" y2="112" '
        f'stroke="{BORDER}" stroke-width="1"/>')

    def box(b: dict, big: bool = False) -> None:
        phase = PHASES[b["phase"]]
        x, y, w, h = b["x"], b["y"], b["w"], b["h"]
        add('<g filter="url(#sh)">')
        add(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="14" '
            f'fill="{SURFACE}" stroke="{BORDER}"/>')
        add('</g>')
        # Phase colour rail down the left edge of the card.
        add(f'<path d="M{x},{y + 14} a14,14 0 0 1 14,-14 h6 v{h} h-6 '
            f'a14,14 0 0 1 -14,-14 z" fill="{phase["mid"]}"/>')
        add(f'<text x="{x + 34}" y="{y + 31}" font-size="16.5" font-weight="650" '
            f'fill="{INK}">{html.escape(b["title"])}</text>')
        for i, line in enumerate(b["lines"]):
            add(f'<text x="{x + 34}" y="{y + 53 + i * 17}" font-size="12.5" '
                f'fill="{INK_3}">{html.escape(line)}</text>')

    def arrow(x1: int, y1: int, x2: int, y2: int) -> None:
        add(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{INK_4}" '
            f'stroke-width="2" marker-end="url(#arrow)"/>')

    # Phase chips down the left rail
    for phase, top, bottom, chip_y in phase_bands(spec):
        meta = PHASES[phase]
        add(f'<rect x="{RAIL_X}" y="{top}" width="4" height="{bottom - top}" '
            f'rx="2" fill="{meta["tint"]}"/>')
        add(f'<rect x="{RAIL_X + 14}" y="{chip_y}" width="150" height="24" rx="12" '
            f'fill="{meta["tint"]}"/>')
        add(f'<text x="{RAIL_X + 26}" y="{chip_y + 16}" font-size="11" '
            f'font-weight="700" letter-spacing="0.6" fill="{meta["dark"]}">'
            f'{html.escape(meta["label"])}</text>')

    # The per-lead loop, drawn behind its stages.
    band = spec["band"]
    loop_dark = PHASES["research"]["dark"]
    add(f'<rect x="{band["x"]}" y="{band["y"]}" width="{band["w"]}" '
        f'height="{band["h"]}" rx="18" fill="#FBFAFF" stroke="#DCD6FA" '
        f'stroke-width="1.5" stroke-dasharray="7 5"/>')
    add(f'<rect x="{band["x"] + 14}" y="{band["y"] + 12}" width="150" height="24" '
        f'rx="12" fill="{PHASES["research"]["tint"]}"/>')
    add(f'<text x="{band["x"] + 26}" y="{band["y"] + 28}" font-size="11" '
        f'font-weight="700" letter-spacing="0.6" fill="{loop_dark}">'
        f'{html.escape(LOOP_LABEL)}</text>')
    add(f'<text x="{band["x"] + 16}" y="{band["y"] + band["h"] - 16}" '
        f'font-size="12" fill="{loop_dark}">{html.escape(LOOP_CAPTION)}</text>')

    # Return path: out of the last looped stage, back up to the first.
    lx = CX - 90
    rx = band["x"] + 13
    out_y, in_y = band["out_y"], band["in_y"]
    add(f'<path d="M{lx},{band["last_bottom"]} V{out_y} H{rx} V{in_y} H{lx}" '
        f'fill="none" stroke="{loop_dark}" stroke-width="2" '
        f'stroke-dasharray="7 5" stroke-linejoin="round"/>')
    add(f'<line x1="{lx}" y1="{in_y}" x2="{lx}" y2="{band["first_y"] - 4}" '
        f'stroke="{loop_dark}" stroke-width="2" marker-end="url(#loop-arrow)"/>')

    # Main column
    for index, b in enumerate(spec["boxes"]):
        box(b)
        if b["note"]:
            for i, line in enumerate(b["note"].split("\n")):
                add(f'<text x="{NOTE_X}" y="{b["y"] + 30 + i * 16}" font-size="12" '
                    f'fill="{INK_4}">{html.escape(line)}</text>')
        if index < len(spec["boxes"]) - 1:
            arrow(CX, b["y"] + BOX_H, CX, spec["boxes"][index + 1]["y"] - 4)

    # Fork
    last_box = spec["boxes"][-1]
    left, right = spec["fork"]
    lcx = left["x"] + left["w"] // 2
    rcx = right["x"] + right["w"] // 2
    add(f'<line x1="{CX}" y1="{last_box["y"] + BOX_H}" x2="{CX}" '
        f'y2="{spec["split_y"]}" stroke="{INK_4}" stroke-width="2"/>')
    add(f'<line x1="{lcx}" y1="{spec["split_y"]}" x2="{rcx}" '
        f'y2="{spec["split_y"]}" stroke="{INK_4}" stroke-width="2"/>')
    for cx_ in (lcx, rcx):
        arrow(cx_, spec["split_y"], cx_, left["y"] - 4)
    for b in spec["fork"]:
        box(b)

    # Merge
    bottom = left["y"] + FORK_H
    for cx_ in (lcx, rcx):
        add(f'<line x1="{cx_}" y1="{bottom}" x2="{cx_}" y2="{spec["merge_y"]}" '
            f'stroke="{INK_4}" stroke-width="2"/>')
    add(f'<line x1="{lcx}" y1="{spec["merge_y"]}" x2="{rcx}" y2="{spec["merge_y"]}" '
        f'stroke="{INK_4}" stroke-width="2"/>')
    arrow(CX, spec["merge_y"], CX, spec["final"]["y"] - 4)
    box(spec["final"])
    for i, line in enumerate(spec["final"]["note"].split("\n")):
        add(f'<text x="{NOTE_X}" y="{spec["final"]["y"] + 30 + i * 16}" '
            f'font-size="12" fill="{INK_4}">{html.escape(line)}</text>')

    # Tail: reply tracking, then the manual follow-up. The first arrow is dashed
    # because days pass here -- the diagram should not imply it follows at once.
    previous = spec["final"]
    for index, b in enumerate(spec["tail"]):
        if index == 0:
            add(f'<line x1="{CX}" y1="{previous["y"] + BOX_H}" x2="{CX}" '
                f'y2="{b["y"] - 4}" stroke="{INK_4}" stroke-width="2" '
                f'stroke-dasharray="7 5" marker-end="url(#arrow)"/>')
            add(f'<text x="{CX + 12}" y="{previous["y"] + BOX_H + 26}" '
                f'font-size="11" font-weight="700" fill="{INK_4}">'
                'DAYS LATER</text>')
        else:
            arrow(CX, previous["y"] + BOX_H, CX, b["y"] - 4)
        box(b)
        for i, line in enumerate(b["note"].split("\n")):
            add(f'<text x="{NOTE_X}" y="{b["y"] + 30 + i * 16}" font-size="12" '
                f'fill="{INK_4}">{html.escape(line)}</text>')
        previous = b

    # Footer guarantee strip
    fy = spec["tail"][-1]["y"] + BOX_H + 42
    add(f'<rect x="{RAIL_X}" y="{fy}" width="{W - RAIL_X * 2}" '
        f'height="{FOOTER_H}" rx="12" fill="#E8F7EF" stroke="#C9EBD8"/>')
    for i, line in enumerate(FOOTER_LINES):
        add(f'<text x="{RAIL_X + 18}" y="{fy + 25 + i * 19}" font-size="12.5" '
            f'fill="#0B7A3C">{html.escape(line)}</text>')

    add('</svg>')
    return "\n".join(out)


# --------------------------------------------------------------------------- #
# PNG
# --------------------------------------------------------------------------- #

def render_png(spec: dict, path: Path, scale: int = 2) -> None:
    from PIL import Image, ImageDraw, ImageFont

    H = spec["height"]

    def font(size: int, weight: str = "regular"):
        files = {"regular": "segoeui.ttf", "semibold": "seguisb.ttf",
                 "bold": "segoeuib.ttf"}
        for name in (files[weight], "segoeui.ttf"):
            try:
                return ImageFont.truetype(f"C:/Windows/Fonts/{name}", size * scale)
            except OSError:
                continue
        return ImageFont.load_default()

    f_title = font(30, "bold")
    f_sub = font(15)
    f_box = font(17, "semibold")
    f_line = font(12, "regular")
    f_note = font(12, "regular")
    f_chip = font(11, "bold")

    image = Image.new("RGB", (W * scale, H * scale), PAGE)
    draw = ImageDraw.Draw(image)
    s = lambda v: int(v * scale)   # noqa: E731 - local scale helper

    def rrect(x, y, w, h, radius, fill, outline=None, width=1):
        draw.rounded_rectangle([s(x), s(y), s(x + w), s(y + h)], radius=s(radius),
                               fill=fill, outline=outline, width=max(1, s(width)))

    def text(x, y, value, fnt, fill):
        draw.text((s(x), s(y)), value, font=fnt, fill=fill)

    def arrow(x1, y1, x2, y2, fill=INK_4):
        draw.line([s(x1), s(y1), s(x2), s(y2)], fill=fill, width=max(1, s(2)))
        head = s(6)
        if x1 == x2:                        # vertical
            draw.polygon([(s(x2), s(y2) + head), (s(x2) - head, s(y2) - head // 2),
                          (s(x2) + head, s(y2) - head // 2)], fill=fill)

    def dashed(x1, y1, x2, y2, fill, dash=7, gap=5):
        """One dashed straight segment, horizontal or vertical."""
        if x1 == x2:
            step = dash if y2 > y1 else -dash
            gap_step = gap if y2 > y1 else -gap
            pos = y1
            while (pos < y2) if y2 > y1 else (pos > y2):
                end = min(pos + step, y2) if y2 > y1 else max(pos + step, y2)
                draw.line([s(x1), s(pos), s(x1), s(end)], fill=fill,
                          width=max(1, s(2)))
                pos = end + gap_step
        else:
            step = dash if x2 > x1 else -dash
            gap_step = gap if x2 > x1 else -gap
            pos = x1
            while (pos < x2) if x2 > x1 else (pos > x2):
                end = min(pos + step, x2) if x2 > x1 else max(pos + step, x2)
                draw.line([s(pos), s(y1), s(end), s(y1)], fill=fill,
                          width=max(1, s(2)))
                pos = end + gap_step

    # Header
    for i in range(s(6)):
        t = i / max(1, s(6))
        draw.line([0, i, W * scale, i],
                  fill=(int(0x6D + (0x12 - 0x6D) * t),
                        int(0x5A + (0xAF - 0x5A) * t),
                        int(0xE8 + (0xC7 - 0xE8) * t)))
    text(RAIL_X, 36, "Lead Mapper — System Workflow", f_title, INK)
    text(RAIL_X, 76,
         "Find business leads, research their websites, write a personalised "
         "email for each, review it, then send — without contacting anyone twice.",
         f_sub, INK_3)
    draw.line([s(RAIL_X), s(112), s(W - RAIL_X), s(112)], fill=BORDER,
              width=max(1, s(1)))

    def box(b):
        phase = PHASES[b["phase"]]
        x, y, w, h = b["x"], b["y"], b["w"], b["h"]
        # Soft shadow, then the card, then the phase rail.
        rrect(x + 1, y + 3, w, h, 14, "#EDEFF6")
        rrect(x, y, w, h, 14, SURFACE, BORDER, 1)
        draw.rectangle([s(x), s(y + 14), s(x + 5), s(y + h - 14)], fill=phase["mid"])
        rrect(x, y + 12, 5, h - 24, 2, phase["mid"])
        text(x + 34, y + 18, b["title"], f_box, INK)
        for i, line in enumerate(b["lines"]):
            text(x + 34, y + 44 + i * 17, line, f_line, INK_3)

    for phase, top, bottom, chip_y in phase_bands(spec):
        meta = PHASES[phase]
        rrect(RAIL_X, top, 4, bottom - top, 2, meta["tint"])
        rrect(RAIL_X + 14, chip_y, 150, 24, 12, meta["tint"])
        text(RAIL_X + 26, chip_y + 5, meta["label"], f_chip, meta["dark"])

    # The per-lead loop, drawn behind its stages.
    band = spec["band"]
    loop_dark = PHASES["research"]["dark"]
    rrect(band["x"], band["y"], band["w"], band["h"], 18, "#FBFAFF")
    for x1, y1, x2, y2 in (
        (band["x"], band["y"], band["x"] + band["w"], band["y"]),
        (band["x"], band["y"] + band["h"], band["x"] + band["w"], band["y"] + band["h"]),
        (band["x"], band["y"], band["x"], band["y"] + band["h"]),
        (band["x"] + band["w"], band["y"], band["x"] + band["w"], band["y"] + band["h"]),
    ):
        dashed(x1, y1, x2, y2, "#DCD6FA")
    rrect(band["x"] + 14, band["y"] + 12, 150, 24, 12, PHASES["research"]["tint"])
    text(band["x"] + 26, band["y"] + 17, LOOP_LABEL, f_chip, loop_dark)
    text(band["x"] + 16, band["y"] + band["h"] - 28, LOOP_CAPTION, f_note, loop_dark)

    lx = CX - 90
    rx = band["x"] + 13
    out_y, in_y = band["out_y"], band["in_y"]
    dashed(lx, band["last_bottom"], lx, out_y, loop_dark)
    dashed(lx, out_y, rx, out_y, loop_dark)
    dashed(rx, out_y, rx, in_y, loop_dark)
    dashed(rx, in_y, lx, in_y, loop_dark)
    arrow(lx, in_y, lx, band["first_y"] - 4, fill=loop_dark)

    for index, b in enumerate(spec["boxes"]):
        box(b)
        if b["note"]:
            for i, line in enumerate(b["note"].split("\n")):
                text(NOTE_X, b["y"] + 20 + i * 16, line, f_note, INK_4)
        if index < len(spec["boxes"]) - 1:
            arrow(CX, b["y"] + BOX_H, CX, spec["boxes"][index + 1]["y"] - 4)

    last_box = spec["boxes"][-1]
    left, right = spec["fork"]
    lcx = left["x"] + left["w"] // 2
    rcx = right["x"] + right["w"] // 2
    draw.line([s(CX), s(last_box["y"] + BOX_H), s(CX), s(spec["split_y"])],
              fill=INK_4, width=max(1, s(2)))
    draw.line([s(lcx), s(spec["split_y"]), s(rcx), s(spec["split_y"])],
              fill=INK_4, width=max(1, s(2)))
    for cx_ in (lcx, rcx):
        arrow(cx_, spec["split_y"], cx_, left["y"] - 4)
    for b in spec["fork"]:
        box(b)

    bottom = left["y"] + FORK_H
    for cx_ in (lcx, rcx):
        draw.line([s(cx_), s(bottom), s(cx_), s(spec["merge_y"])], fill=INK_4,
                  width=max(1, s(2)))
    draw.line([s(lcx), s(spec["merge_y"]), s(rcx), s(spec["merge_y"])],
              fill=INK_4, width=max(1, s(2)))
    arrow(CX, spec["merge_y"], CX, spec["final"]["y"] - 4)
    box(spec["final"])
    for i, line in enumerate(spec["final"]["note"].split("\n")):
        text(NOTE_X, spec["final"]["y"] + 20 + i * 16, line, f_note, INK_4)

    previous = spec["final"]
    for index, b in enumerate(spec["tail"]):
        if index == 0:
            dashed(CX, previous["y"] + BOX_H, CX, b["y"] - 10, INK_4)
            arrow(CX, b["y"] - 10, CX, b["y"] - 4)
            text(CX + 12, previous["y"] + BOX_H + 16, "DAYS LATER", f_chip, INK_4)
        else:
            arrow(CX, previous["y"] + BOX_H, CX, b["y"] - 4)
        box(b)
        for i, line in enumerate(b["note"].split("\n")):
            text(NOTE_X, b["y"] + 20 + i * 16, line, f_note, INK_4)
        previous = b

    fy = spec["tail"][-1]["y"] + BOX_H + 42
    rrect(RAIL_X, fy, W - RAIL_X * 2, FOOTER_H, 12, "#E8F7EF", "#C9EBD8", 1)
    for i, line in enumerate(FOOTER_LINES):
        text(RAIL_X + 18, fy + 13 + i * 19, line, f_note, "#0B7A3C")

    # Drawn at 2x and downsampled, which is what makes the text edges clean.
    image.resize((W, H), Image.LANCZOS).save(path, "PNG", optimize=True)


def main() -> None:
    spec = layout()
    OUT.mkdir(parents=True, exist_ok=True)

    svg = OUT / "workflow.svg"
    svg.write_text(render_svg(spec), encoding="utf-8")
    print(f"wrote {svg}  ({svg.stat().st_size // 1024} KB)")

    png = OUT / "workflow.png"
    render_png(spec, png)
    print(f"wrote {png}  ({png.stat().st_size // 1024} KB, {W}x{spec['height']})")


if __name__ == "__main__":
    main()
