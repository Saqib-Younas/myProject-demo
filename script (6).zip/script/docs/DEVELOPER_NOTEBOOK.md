# Project Developer Notebook

**Lead Mapper** — technical handbook.

Written against the code as it stands. Every path, class and function named here was
checked to exist; every count came from running the thing. Where the code does not do
something, it says so and marks it.

**Status labels used throughout**

| Label | Meaning |
| --- | --- |
| **IMPLEMENTED** | Works, has tests, is reachable from the UI or a command |
| **PARTIALLY IMPLEMENTED** | Works for the common case; a documented gap remains |
| **DISABLED** | The code exists and is deliberately switched off |
| **NOT IMPLEMENTED** | Named somewhere (a field, a filter, a docstring) but does nothing yet |
| **PLANNED** | Discussed only; no code |

**Verified at the time of writing**

```
python manage.py test                       Ran 1642 tests — OK (skipped=6)
ruff check .                                All checks passed!
python manage.py check                      System check identified no issues
python manage.py makemigrations --check      No changes detected
```

Django 6.1 · Python 3.14 (project requires ≥3.11) · SQLite by default · no Celery, no Redis.

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Project Architecture](#2-project-architecture)
3. [Folder Structure](#3-folder-structure)
4. [Django Foundation](#4-django-foundation)
5. [Database and Models](#5-database-and-models)
6. [Business Discovery](#6-business-discovery)
7. [Website Crawler](#7-website-crawler)
8. [Website Audit / Analyzer](#8-website-audit--analyzer)
9. [AI System](#9-ai-system)
10. [Contact / Email Discovery](#10-contact--email-discovery)
11. [Email Generation](#11-email-generation)
12. [Email Sending](#12-email-sending)
13. [Email Limits and Safety](#13-email-limits-and-safety)
14. [Campaign Engine](#14-campaign-engine)
15. [Cron / Background Automation](#15-cron--background-automation)
16. [Follow-up System](#16-follow-up-system)
17. [Specific URL Audit](#17-specific-url-audit)
18. [Database Configuration](#18-database-configuration)
19. [Settings and Configuration](#19-settings-and-configuration)
20. [Security](#20-security)
21. [Error Handling](#21-error-handling)
22. [Testing](#22-testing)
23. [Debugging](#23-debugging)
24. [Common Development Tasks](#24-common-development-tasks)
25. [End-to-End Workflows](#25-end-to-end-workflows)
26. [Code Map](#26-code-map)
27. [Data Flow Map](#27-data-flow-map)
28. [External Services](#28-external-services)
29. [Technology Decisions](#29-technology-decisions)
30. [Glossary](#30-glossary)
31. [Architecture Decisions](#31-architecture-decisions)
32. [Known Limitations](#32-known-limitations)
33. [Future Roadmap](#33-future-roadmap)

---

# 1. Project Overview

### What is it?

A lead-generation and cold-outreach tool for a web-design or web-services business. It
finds local businesses on a public map, reads their websites, works out what is
measurably wrong with them, writes a personal email about what it actually found, and
sends it once a person approves — or, for a configured campaign, sends unattended within
limits that person set.

### Why does it exist?

Cold outreach that works has to be specific, and being specific by hand does not scale.
Reading one website properly takes ten minutes; a hundred takes two days. The generic
alternative — "I noticed your website could use some improvements" — is what makes cold
email spam.

The problem this solves is *evidence at volume*: every claim in every email traces back
to something the crawler measured on that specific site, and the system will refuse to
send an email whose claims it cannot support.

### Who uses it?

One operator or a small agency. Every account is its own workspace: leads, campaigns,
sending addresses and AI keys are all owned per user (`owner` foreign keys throughout).
There is no team or role model beyond Django's `is_staff`, which gates one page
(Settings → Database).

### What the user does

1. Searches for businesses by country, city and category, and selects some.
2. Sets up a campaign: who it is from, what the offer is, which mailbox sends it.
3. Presses **Run**, and the pipeline crawls, reviews and drafts one lead at a time.
4. Reads the drafts and approves or rejects them.
5. Presses **Send**.

Or, for unattended running, creates an **automation plan**: the same configuration plus a
daily window, a timezone, a daily target and a total target — then starts it once.

### What happens automatically

| Automatic | Never automatic |
| --- | --- |
| Crawling and measuring a website | Sending a follow-up (always needs a click) |
| Scoring and classifying a lead | Sending the email from a submitted-URL audit |
| Drafting the first email | Guessing an email address that was not published |
| Sending, *inside a configured automation plan* | Starting a campaign nobody configured |
| Preparing follow-up drafts | Contacting a suppressed or replied address |
| Reading the mailbox for replies and bounces | |

### Final business purpose

Turn "there are businesses near me with bad websites" into "here are 40 specific,
evidenced, personally-written emails that went out this week to people who had not been
contacted before" — without the operator reading 40 websites, and without sending
anything they would be embarrassed by.

### In simple words

It is a robot that finds local shops with weak websites, actually looks at the websites,
writes each owner a short honest email about one real problem it found, and either shows
you the email to approve or sends it for you inside limits you set.

---

# 2. Project Architecture

### The actual shape

```
                          ┌──────────────────────────────────┐
   BROWSER                │  Server-rendered HTML + vanilla  │
   (no build step)        │  JS. 25 templates, 15 JS files.  │
                          │  fetch() -> JSON endpoints.      │
                          └───────────────┬──────────────────┘
                                          │ HTTP
                          ┌───────────────▼──────────────────┐
   DJANGO 6.1             │  config/urls.py -> 69 routes     │
                          │  LoginRequiredMiddleware:        │
                          │  deny-by-default on every view   │
                          └───────────────┬──────────────────┘
                                          │
        ┌─────────────────────────────────┼─────────────────────────────────┐
        │                                 │                                 │
┌───────▼────────┐            ┌───────────▼───────────┐         ┌───────────▼─────────┐
│ VIEWS (thin)   │            │  SERVICES (decide)    │         │ SELECTORS (read)    │
│ apps/*/views/  │───────────>│ apps/outreach/        │         │ apps/outreach/      │
│ parse, call,   │            │   services/           │         │   selectors.py      │
│ render         │            │   pipeline.py         │         │ filtered, paginated │
└────────────────┘            │   followups.py        │         └─────────┬───────────┘
                              │   websiteaudit.py     │                   │
                              │   campaigns.py        │                   │
                              │   history.py          │                   │
                              │   intelligence.py     │                   │
                              │   automation/         │                   │
                              └───┬────────┬──────┬───┘                   │
                                  │        │      │                       │
              ┌───────────────────┘        │      └──────────────┐        │
              │                            │                     │        │
      ┌───────▼────────┐          ┌────────▼────────┐   ┌────────▼──────┐ │
      │ apps/auditing  │          │   apps/ai       │   │ outreach/mail │ │
      │ crawler.py     │          │ prompts.py      │   │ providers.py  │ │
      │ measurements.py│          │ client.py       │   │ compose.py    │ │
      │ scoring.py     │          │ parsing.py      │   │ transport.py  │ │
      │ contacts.py    │          │ validation.py   │   │ followups.py  │ │
      │ safeurl.py     │          │ backends/ (5)   │   │ inbox.py      │ │
      └───────┬────────┘          └────────┬────────┘   │ accounts.py   │ │
              │                            │            │ auditsend.py  │ │
              │                            │            └───────┬───────┘ │
              │                            │                    │         │
              └────────────┬───────────────┴────────────────────┬┘        │
                           │                                     │        │
                  ┌────────▼──────────┐                          │        │
                  │  apps/core        │                          │        │
                  │  secrets.py       │  Fernet at rest          │        │
                  │  database.py      │  which DB is in use      │        │
                  │  dburl.py         │  DATABASE_URL parsing    │        │
                  │  paging.py        │  pagination              │        │
                  └────────┬──────────┘                          │        │
                           │                                     │        │
      ┌────────────────────▼─────────────────────────────────────▼────────▼───┐
      │  DATABASE — 13 models, 24 migrations                                  │
      │  SQLite (outreach.sqlite3) by default; Postgres/Supabase via           │
      │  DATABASE_URL. Selected at Settings -> Database.                       │
      └───────────────────────────────────────────────────────────────────────┘

  BACKGROUND WORK — no broker, no queue
  ┌──────────────────────────────────────────────────────────────────────────┐
  │ cron / systemd timer / Task Scheduler -> manage.py <command>             │
  │   run_automation      unattended campaigns  (THE ONLY JOB THAT SENDS)    │
  │   run_audits          the submitted-URL queue                            │
  │   process_followups   drafts follow-ups, sends nothing                    │
  │   check_replies       reads IMAP for replies and bounces                  │
  │ + daemon threads in the web process for Run / Resume / --loop shapes      │
  └──────────────────────────────────────────────────────────────────────────┘

  EXTERNAL SERVICES
  ┌──────────────┬───────────────┬──────────────┬───────────────┬────────────┐
  │ Nominatim    │ Overpass API  │ AI provider  │ SMTP          │ IMAP       │
  │ (geocoding)  │ (businesses)  │ 5 supported  │ 5 providers   │ replies    │
  └──────────────┴───────────────┴──────────────┴───────────────┴────────────┘
```

### The dependency rule

`apps/__init__.py` documents it and the code obeys it:

```
core  <-  ai  <-  auditing  <-  outreach
                                   ^
                accounts, leads ---┘
```

Arrows point the way imports go. So:

- `apps/auditing` does not know what a campaign is — verified: it contains no
  `apps.outreach` import.
- `apps/ai` does not know what a website is; it receives measurements as data.
- `apps/core` imports nothing from any other app.

This is why the crawler can be tested without a database row and the prompts can be
tested without a crawl.

### What each layer is for

| Layer | Where | Rule |
| --- | --- | --- |
| Templates + JS | `templates/`, `static/js/` | Show what the server said. No business decisions. |
| Views | `apps/*/views/` | Parse the request, call a service, render. Decide nothing. |
| Selectors | `apps/outreach/selectors.py` | Complex reads: filtering, sorting, pagination. |
| Services | `apps/outreach/services/` | Every decision. No `HttpRequest` reaches here. |
| Domain libraries | `apps/auditing`, `apps/ai`, `apps/outreach/mail` | Pure-ish capability: crawl, prompt, send. |
| Shared | `apps/core` | Domain-free: encryption, DB config, pagination. |
| Background | `apps/outreach/tasks.py` + `apps/outreach/management/commands/` | Thin entry points that call services. |

### In simple words

The browser talks to Django. Django's views are deliberately stupid — they hand the work
to a "service", which is where all the thinking lives. Underneath sit three toolkits: one
that reads websites, one that talks to an AI, one that sends email. Background jobs are
just the same code run by cron on a timer, not a separate queue system.

---
# 3. Folder Structure

### The tree

```
manage.py                       defaults DJANGO_SETTINGS_MODULE to development
pyproject.toml                  project metadata + ruff configuration
requirements/
  base.txt                      the application: Django, requests, bs4, cryptography,
                                psycopg, and the 4 AI SDKs
  development.txt               base + ruff + pillow (for docs/make_workflow.py)
  production.txt                base + gunicorn
.env.example                    committed template; .env is git-ignored
.gitignore  .dockerignore
Dockerfile  docker-compose.yml  docker-compose.override.yml.example
docker/entrypoint.sh            secret-key check, collectstatic, migrate, WAL mode
docker/Caddyfile                TLS termination
README.md  DEPLOY.md  SUPABASE.md
docs/make_workflow.py           generates a workflow diagram (needs pillow)
sql/                            Supabase row-level-security policies, applied by hand
config/
  settings/{base,development,production}.py
  urls.py  wsgi.py  asgi.py
apps/
  __init__.py                   documents the dependency graph
  core/                         shared, domain-free
  ai/                           every model call
  auditing/                     reading and measuring a website
  accounts/                     sign-up, sign-in, sessions
  leads/                        finding businesses
  outreach/                     campaigns, email, follow-ups, screens
templates/                      25 server-rendered templates
static/{css,js,images}/         3 CSS files, 15 JS files. No build step.
tests/
  integration/                  settings and the DATABASE_URL switch
  e2e/                          one opt-in test that reads a real website
outreach.sqlite3                the default database
media/  exports/  staticfiles/  runtime output, git-ignored
```

### The files worth knowing

**Path:** `config/settings/base.py`
**Purpose:** Everything both environments share. Loads `.env`, assembles `DATABASES`
(SQLite, or `DATABASE_URL`, honouring the Settings → Database selection), and defines
every `OUTREACH_*` tunable.
**Important names:** `DATA_DIR`, `_SQLITE`, `_DB_SELECTION`, `OUTREACH_BLOCK_SEND`,
`OUTREACH_FOLLOWUP_DELAYS`, `OUTREACH_PRIORITY_HOT/WARM/LOW`.

**Path:** `config/settings/production.py`
**Purpose:** Refuses to start if `SECRET_KEY` is missing or starts with
`django-insecure`. SSL redirect, HSTS and the proxy header are opt-in env switches.

**Path:** `config/wsgi.py`
**Purpose:** The WSGI entry point. Defaults to **production** settings deliberately — a
WSGI server is serving real traffic, so a forgotten `DJANGO_SETTINGS_MODULE` must fail
closed rather than come up with `DEBUG = True`.

**Path:** `apps/auditing/crawler.py` (~700 lines)
**Purpose:** Fetching pages. `robots.txt`, throttling, retries, redirect limits, link
discovery, sitemap reading, page selection.
**Important names:** `analyse()`, `normalise()`, `_fetch()`, `_robots_for()`,
`_allowed()`, `discover_links()`, `discover_sitemap()`, `choose_pages()`, `classify()`,
and the status constants `OK`, `BLOCKED`, `FAILED`, `NO_WEBSITE`.

**Path:** `apps/auditing/measurements.py`
**Purpose:** Turning HTML into the facts an audit may cite.
**Important names:** `measure()`, `extract()`, `detect_stack()`, `scrape_emails()`,
`Fetched`, `Page`, and the signal tables `BUSINESS_PATTERNS`, `BUSINESS_SIGNALS`,
`CTA_PATTERN`, `TRUST_PATTERN`, `PLACEHOLDER_PATTERN`.

**Path:** `apps/auditing/scoring.py`
**Purpose:** Measurements → six sub-scores → one assessment; plus platform advice.
**Important names:** `performance_score()`, `mobile_score()`, `seo_score()`,
`ux_score()`, `conversion_score()`, `technical_score()`, `merge_signals()`,
`WebsiteAssessment`, `platform_advice()`, `unsupported_replatform()`, `classify()`.

**Path:** `apps/auditing/safeurl.py`
**Purpose:** The SSRF boundary. Every fetch of a user-submitted URL goes through it.
**Important names:** `check()`, `normalise()`, `guard()`, `same_site()`, `Target`,
`UnsafeUrl`, `InvalidUrl`, `ALLOWED_PORTS`, `BLOCKED_HOSTS`, `BLOCKED_SUFFIXES`.

**Path:** `apps/auditing/contacts.py`
**Purpose:** Harvesting published contact details with a confidence and a source.
**Important names:** `harvest_page()`, `Harvest`, `Detail`, `NEVER_WORDS`,
`PLATFORM_DOMAINS`, `OWNER_WORDS`.

**Path:** `apps/ai/prompts.py` (~800 lines)
**Purpose:** What the model is asked, and the JSON schema it must answer in.
**Important names:** `AUDIT_SYSTEM`, `AUDIT_SCHEMA`, `SYSTEM_TEMPLATE`, `system_for()`,
`SCHEMA_TEMPLATE`, `schema_for()`, `build_audit_prompt()`, `build_prompt()`,
`build_no_website_prompt()`, `attribute_pages()`, `FOLLOWUP_SYSTEM`, `MAX_FINDINGS`.

**Path:** `apps/ai/client.py`
**Purpose:** The one place a provider is called. Provider selection, model resolution,
retry and fallback.
**Important names:** `PROVIDERS`, `provider()`, `load()`, `backend()`, `model()`,
`_complete()`, `_fallback_for()`, `describe_credentials()`.

**Path:** `apps/ai/validation.py`
**Purpose:** Rejecting an answer that invented something or sounds like spam.
**Important names:** `BANNED_PHRASES`, `BANNED_STEMS`, `style_problem()`,
`draft_problem()`, `specificity_problem()`, `unhedged_benefit()`, `hedge_findings()`,
`is_unverified()`, `assign_ids()`, `GUARANTEE_PATTERNS`.

**Path:** `apps/ai/credentials.py`
**Purpose:** The per-account AI key pool: resolution order, activation, fallback,
health events. Delegates encryption to `apps/core/secrets.py`.
**Important names:** `resolve()`, `require()`, `status()`, `all_statuses()`,
`encrypt()`, `decrypt()`, `mask()`, `CredentialError`, `Spec`, `Credential`.

**Path:** `apps/outreach/services/pipeline.py` (~950 lines)
**Purpose:** One lead, all the way through: crawl → review → score → write → send.
Also the rate-limit pause/resume machinery and the background thread.
**Important names:** `start_pipeline()`, `is_running()`, `stalled()`, `_call_ai()`,
`_park()`, `_hold()`, `_backoff()`, `_claim()`, `_claim_draft()`, `_spawn()`,
`Cancelled`, `RateLimited`, `MAX_PAUSES`, `AI_RETRY_DELAY`.

**Path:** `apps/outreach/services/automation/` (7 modules)
**Purpose:** Unattended campaigns.
`runner.py` the pass loop, the plan lease, the lead claim;
`schedule.py` timezone windows; `leads.py` prospect searches and the pool;
`courier.py` the sending account and its failure counting;
`process.py` per-lead eligibility, refusal, sending, follow-up preparation;
`events.py` the campaign event log.

**Path:** `apps/outreach/services/followups.py`
**Purpose:** What is due, what may be prepared, and the claim that stops two workers
drafting the same follow-up. Sends nothing.
**Important names:** `prepare_one()`, `due_leads()`, `halted()`, `claim()`,
`next_number()`, `write()`, `record_skip()`, `record_failure()`, `MAX_ATTEMPTS`,
`UNSPENT`, `Outcome`, `Halt`.

**Path:** `apps/outreach/services/websiteaudit.py`
**Purpose:** The submitted-URL workflow.
**Important names:** `SpecificWebsiteAuditService`, `create()`, `claim()`, `run_job()`,
`run_pending()`, `start_in_background()`, `regenerate()`, `holder()`, `Outcome`.

**Path:** `apps/outreach/services/history.py`
**Purpose:** Who has been contacted, the reservation that stops a second send, the
suppression index, and the Excel export.
**Important names:** `reserve()`, `Index`, `SuppressionIndex`, `suppress()`,
`annotate_leads()`, `mark_campaign_duplicates()`, `export_excel()`, `stats()`,
`AlreadyContacted`, `DoNotContact`.

**Path:** `apps/outreach/mail/transport.py`
**Purpose:** The authenticated SMTP session — the only place a message is handed over.
**Important names:** `Session`, `Session.send()`, and the re-exported `SendError`.

**Path:** `apps/core/database.py` (~730 lines)
**Purpose:** Which database is in use, and the Settings → Database state.
**Important names:** `selection()`, `active()`, `switch()`, `local_status()`,
`supabase_status()`, `test_supabase()`, `save_supabase()`, `validate_url()`,
`supabase_config()`, `DatabaseSettingsError`, `STATE_FILENAME`.

**Path:** `apps/core/secrets.py`
**Purpose:** Fernet encryption for everything stored at rest — AI keys, mailbox
passwords, the Supabase service-role key.
**Important names:** `encrypt()`, `decrypt()`, `mask()`, `SALT`, `ITERATIONS`,
`SecretError`, `KNOWN_PREFIXES`.

### In simple words

`config/` is the wiring. `apps/core` is shared plumbing. `apps/auditing` reads websites,
`apps/ai` talks to the model, `apps/outreach` runs the campaigns and owns the screens.
Tests sit next to the code they test, except two folders at the top for things that
belong to no single app.

---

# 4. Django Foundation

### Settings — three files, one shared

**Source:** `config/settings/base.py`, `development.py`, `production.py`

`base.py` holds everything both environments share and reads `.env` itself via a private
`_load_env()` (there is no `django-environ` dependency). It defines `DATA_DIR`
(from `DJANGO_DATA_DIR`, default `BASE_DIR`), which is where the SQLite file, media,
exports and the database-selection file live.

`development.py` — `DEBUG = True`, `ALLOWED_HOSTS = ["*"]`, non-Secure cookies, and MD5
password hashing while `manage.py test` runs (PBKDF2 dominates the suite otherwise). Its
`SECRET_KEY` honours `DJANGO_SECRET_KEY` if set and otherwise falls back to an obviously
fake value.

`production.py` — raises `RuntimeError` at import if `SECRET_KEY` is empty or starts with
`django-insecure`. SSL redirect, HSTS and `SECURE_PROXY_SSL_HEADER` are opt-in via
`DJANGO_SSL_REDIRECT`, `DJANGO_HSTS_SECONDS`, `DJANGO_TRUST_PROXY_TLS`, because turning
them on before a certificate exists breaks the site and HSTS is hard to undo. Logging
goes to stdout.

Which module loads where:

| How it runs | What decides | Module |
| --- | --- | --- |
| `manage.py` | `manage.py` setdefault | development |
| `gunicorn config.wsgi` | `config/wsgi.py` setdefault | **production** |
| Docker | the image `ENV` | production |
| Docker + dev override | the override's `environment:` | development |

### INSTALLED_APPS

`django.contrib.auth`, `contenttypes`, `sessions`, `messages`, `staticfiles`, then
`apps.core`, `apps.ai`, `apps.auditing`, `apps.accounts`, `apps.leads`, `apps.outreach`.

**`django.contrib.admin` is NOT installed and there is no `admin.py` anywhere.** — status:
**NOT IMPLEMENTED**, deliberately. `createsuperuser` still works because `contrib.auth`
provides it, and `is_staff` is used as a permission flag for Settings → Database. If you
want the admin, you must add the app and a URL for it.

### Middleware

**Source:** `config/settings/base.py` → `MIDDLEWARE`

```
SecurityMiddleware
SessionMiddleware
CommonMiddleware
CsrfViewMiddleware
AuthenticationMiddleware
LoginRequiredMiddleware      <- deny-by-default; every view needs a session
MessageMiddleware
XFrameOptionsMiddleware
```

`LoginRequiredMiddleware` (Django 5.1+) is the important one: a new view added later is
protected without anybody remembering to protect it. The exceptions are marked with
`@login_not_required` — login, signup, logout.

### URLs

**Source:** `config/urls.py` → 69 routes. Namespaces: `accounts`, `leads`, `outreach`,
`ai`, `core`.

```python
path("", include("apps.accounts.urls")),
path("dashboard", outreach_views.dashboard, name="dashboard"),
path("outreach/ai/", include("apps.ai.urls")),      # credential pool
path("outreach/", include("apps.core.urls")),        # settings/database
path("outreach/", include("apps.outreach.urls")),
path("", include("apps.leads.urls")),
```

### Views

Split by subject, not one file. `apps/outreach/views/` is a package:
`dashboard.py`, `leads.py`, `campaigns.py`, `drafts.py`, `followups.py`,
`suppressions.py`, `settings.py`, `automation.py`, `websiteaudit.py`, plus `shared.py`
for the helpers (`_json`, `_my_campaign`, `_my_draft`, `_filters_from`,
`MAX_LEADS_PER_CAMPAIGN = 300`). `__init__.py` re-exports the public names so
`views.dashboard` still resolves.

Views are thin by rule. The longest decision in one is "which template".

### Forms

**Source:** `apps/outreach/forms.py`, `apps/accounts/forms.py`

| File | Class | Purpose |
| --- | --- | --- |
| `apps/outreach/forms.py` | `AutomationForm` | Validates an automation plan: window, timezone, targets, categories |
| `apps/outreach/forms.py` | `MultiTextField` | A field that accepts several free-text values (cities, categories) |
| `apps/accounts/forms.py` | `LoginForm` | Email-or-username sign-in |
| `apps/accounts/forms.py` | `SignUpForm` | Account creation |
| `apps/accounts/forms.py` | `_unique_username()` | Derives a unique username from an email |

`AutomationForm.plan_values()` returns `"followup_autosend": False` and the form has no
field for it — see chapter 16.

### Templates

25 files under `templates/`, extending `templates/shared/base.html`. `templates/shared/icons.html` is an SVG
sprite; every icon in the app is a `<use href="#i-name">` into it. No template engine
beyond Django's, no build step, no frontend framework.

### Services and management commands

Services: `apps/outreach/services/`. Commands: `apps/outreach/management/commands/` —
`run_automation`, `run_audits`, `process_followups`, `check_replies`, `ai_status`,
`smtp_check`, `claim_data`, `db_transfer`. `apps/outreach/tasks.py` gives the three
unattended jobs plain callables so a command and a thread can both reach them.

### Migrations

24 total: 23 in `apps/outreach/migrations/`, 1 in `apps/ai/migrations/`. The AI one is
`0001_move_ai_credentials.py`, which moved three credential models from `outreach` to
`ai` using `SeparateDatabaseAndState` with `db_table` pinned — so **no data moved and no
table was renamed**. `apps/accounts` has an empty migrations package (it uses
`django.contrib.auth.models.User` unchanged). `apps/core`, `apps/auditing` and
`apps/leads` have no models and no migrations.

### Request lifecycle, with real names

```
Browser: POST /outreach/<uuid>/run
   ↓
config/urls.py -> apps/outreach/urls.py -> name="run"
   ↓
MIDDLEWARE: session, CSRF, auth, LoginRequiredMiddleware
   ↓
apps/outreach/views/campaigns.py :: run(request, campaign_id)
   ↓  _my_campaign(request, campaign_id)   # ownership check, 404 otherwise
apps/outreach/services/pipeline.py :: start_pipeline(campaign)
   ↓  _claim(campaign.id)                  # one job per campaign, per process
   ↓  _spawn(...)                          # daemon thread; the request returns now
   │
   ├─> apps/auditing/crawler.py :: analyse(website)
   ├─> apps/auditing/measurements.py :: measure(), extract()
   ├─> apps/auditing/scoring.py :: merge_signals(), the six sub-scores
   ├─> apps/ai/generation.py :: audit(), generate()
   │      -> apps/ai/prompts.py :: build_audit_prompt(), build_prompt()
   │      -> apps/ai/client.py :: _complete()  -> apps/ai/backends/<provider>.py
   │      -> apps/ai/parsing.py :: parse_audit(), parse()
   │      -> apps/ai/validation.py :: draft_problem(), specificity_problem()
   └─> apps/outreach/models/campaigns.py :: EmailDraft.objects.update(...)
   ↓
JsonResponse -> the workspace polls GET /outreach/<uuid>/state
```

### In simple words

A URL points at a view. The view checks you own the thing, hands off to a service, and
returns. For long work the service starts a background thread and the page polls a
`/state` endpoint to watch progress. Settings live in three files so development and
production cannot be confused for each other.

---
# 5. Database and Models

### Where the code is

`apps/outreach/models/` is a package, one module per group of tables, with
`__init__.py` re-exporting the public API in foreign-key order:

| Module | Models |
| --- | --- |
| `accounts.py` | `EmailAccount` |
| `campaigns.py` | `Campaign`, `EmailDraft`, `CampaignEvent` |
| `history.py` | `SentLead`, `Suppression` |
| `followups.py` | `FollowUp` |
| `automation.py` | `AutomationPlan`, `AutomationDay`, `ProspectSearch` |
| `auditing.py` | `WebsiteAudit`, `AuditJob` |

`apps/ai/models.py` holds `ProviderCredential`, `CredentialEvent`, `AiSelection`.

**13 models in total.** `apps/accounts` has none — it uses
`django.contrib.auth.models.User` unchanged, with email as the login identifier via a
custom backend (`apps/accounts/backends.py`). `apps/core`, `apps/auditing` and
`apps/leads` have no models at all.

### Ownership

Almost every model carries `owner = ForeignKey(User, null=True)`. `null=True` is
historical: rows created before accounts existed have no owner, and
`manage.py claim_data <email>` assigns them. Views never trust an id in a URL — they
re-read the object scoped to `request.user` (`_my_campaign`, `_my_draft`, `_my_account`
in `apps/outreach/views/shared.py`).

### Campaign

**Source:** `apps/outreach/models/campaigns.py` → `Campaign`

The unit of work. Primary key is a `UUIDField`, not a sequence — campaign ids appear in
URLs, and a guessable integer would leak how many campaigns exist.

Two independent state fields, which is the thing to understand about this model:

| Field | Choices | Means |
| --- | --- | --- |
| `status` | `draft`, `scheduled`, `active`, `paused`, `completed`, `stopped`, `failed` | **What the operator wants.** Set by a person or by the automation runner. |
| `phase` | `setup`, `crawling`, `analysing`, `generating`, `paused_rate_limit`, `cancel_requested`, `cancelled`, `review`, `sending`, `done`, `failed` | **What the pipeline is doing right now.** |

They are separate because "paused because I said so" and "currently crawling" are
different facts, and a campaign can be `active`/`crawling` or `paused`/`review`.

Other notable fields: `sending_accounts` (M2M to `EmailAccount`), `current_draft` +
`current_step` (so the workspace can show which lead is in flight), `pause_reason` /
`pause_detail` / `retry_at` / `pause_count` (rate-limit machinery),
`scheduled_for`, `status_note`.

**Properties enforced elsewhere:** `may_send` and `may_follow_up`. A `completed`
campaign may not contact anybody new but still owes follow-ups to people it emailed —
that distinction is why there are two properties instead of one.

### EmailDraft

**Source:** `apps/outreach/models/campaigns.py` → `EmailDraft`

One lead inside a campaign, from raw business through to sent email. The widest model in
the project.

| Field | Choices | Means |
| --- | --- | --- |
| `status` | `no_email`, `excluded`, `duplicate`, `suppressed`, `pending`, `crawled`, `analysed`, `generated`, `approved`, `rejected`, `sending`, `sent`, `failed` | Where in the pipeline this lead is |
| `lifecycle` | `new`, `analyzing`, `analyzed`, `qualified`, `email_ready`, `contacted`, `follow_up`, `replied`, `interested`, `meeting`, `won`, `lost`, `do_not_contact` | A sales stage, set by hand or by the system |

Also carries the crawl and audit results: `analysis_status`, `analysis_context`,
`observation`, `findings` (JSON), `business_summary`, the six sub-scores, priority band,
`recommended_service`, `claimed_by` / `claimed_at`.

**Constraints and indexes:**

```
UniqueConstraint  one_sendable_draft_per_email_per_campaign
Index             draft_claimable_idx  (campaign, status, claimed_by)
Index             on status; Index on email
```

`draft_claimable_idx` exists for exactly one query — the automation runner asking "give
me one unclaimed, sendable draft in this campaign" — and it is the index that keeps that
query cheap as a campaign grows.

`finding_objects` is a property that turns the `findings` JSON back into `ai.Finding`
dataclasses, so the email builder and the templates never parse JSON by hand.

### SentLead

**Source:** `apps/outreach/models/history.py` → `SentLead`

The permanent record that an address was contacted. **This is the duplicate-prevention
table**, and its constraints are the mechanism:

```
UniqueConstraint  one_live_send_per_email             (owner, email) where status is live
UniqueConstraint  one_live_send_per_unowned_email     the same, for pre-accounts rows
UniqueConstraint  one_recontact_per_email_per_campaign
CheckConstraint   —
Index             (status), (business_name, city), (owner, status)
```

A row is inserted **before** SMTP is opened, with `status = sending` and
`reserved_at` set — see `apps/outreach/services/history.py :: reserve()`. That ordering
is the whole guarantee: two concurrent sends race on the unique constraint and exactly
one wins, so the second cannot send even if it wanted to. `status` then moves to `sent`
or `failed`.

`domain` is stored alongside `email` and normalised by `SentLead.domain_of()`, so a
domain-level suppression can be checked with an index rather than a `LIKE`.

Reply tracking lives here too: `reply_state` (`no_reply`, `replied`, `bounced`,
`unsubscribed`), `replied_at`, `reply_snippet`, `checked_at`, and `message_id` — the
`Message-ID` of the email that was sent, which is what makes reply matching reliable
rather than a guess based on the sender address.

### Suppression

**Source:** `apps/outreach/models/history.py` → `Suppression`

The do-not-contact list. Either an `email` or a `domain`, enforced by a
`CheckConstraint` named `suppression_needs_an_email_or_a_domain` — a row with neither
would silently match nothing, which is the worst possible failure for this table.

`reason` has four choices; `SuppressionIndex` in `apps/outreach/services/history.py` loads the whole
list once per run and answers membership in memory, because it is consulted for every
lead.

### FollowUp

**Source:** `apps/outreach/models/followups.py` → `FollowUp`

One scheduled follow-up for one `SentLead`. `number` is 1, 2, … and

```
UniqueConstraint  one_live_followup_per_number_per_lead
```

is what stops two workers drafting the same follow-up. 10 statuses: `waiting`, `due`,
`draft`, `processing`, `sending`, `sent`, `skipped`, `failed`, `cancelled`, `opted_out`.

`attempts` + `last_attempt_at` bound retries (`MAX_ATTEMPTS = 3` in
`apps/outreach/services/followups.py`). `skip_reason` records *why* nothing happened, because a
follow-up that silently did not happen is indistinguishable from a bug.

Threading: `in_reply_to`, `references`, `thread_id` — so the follow-up lands in the
conversation the first email started rather than as a new thread.

### EmailAccount

**Source:** `apps/outreach/models/accounts.py` → `EmailAccount`

A sending mailbox. `secret` holds the SMTP password **encrypted** (Fernet, via
`apps/core/secrets.py`); `hint` holds a mask. Per-account `daily_limit`,
`followup_max`, `followup_delays`, `signature`, optional custom SMTP/IMAP host and port.

```
UniqueConstraint  one_account_per_address_per_owner
UniqueConstraint  one_account_name_per_owner
Index             ea_owner_active_idx  (owner, is_active)
```

### AutomationPlan / AutomationDay / ProspectSearch

**Source:** `apps/outreach/models/automation.py`

`AutomationPlan` is `OneToOneField` to `Campaign` — a plan *is* a campaign's unattended
configuration, not a separate thing. It carries the window (`start_date`, `start_time`,
`end_date`, `end_time`, `timezone_name`), the targets (`daily_target`, `total_target`),
the discovery inputs (`countries`, `cities`, `categories` as JSON), `send_gap_seconds`,
the follow-up settings, and the **worker lease**: `locked_by` + `locked_until`.

A lease, not a lock: a worker killed mid-lead cannot release anything, so the next one
takes over when the lease expires (`LEASE_SECONDS = 600` in `apps/outreach/services/automation/runner.py`)
instead of the campaign being stuck forever.

`AutomationDay` is one row per plan per calendar day, with `reserved`, `sent`, `skipped`,
`failed`, and

```
UniqueConstraint  one_day_row_per_plan   (plan, day)
```

That constraint is how the daily target is enforced atomically: reserving a slot is a
conditional `UPDATE` on this row, so two workers cannot both take the last send of the
day.

`ProspectSearch` is one country/city/category combination to search, with
`UniqueConstraint one_search_per_plan_area` so the same area is not searched twice, and
`attempts` so a failing area is not retried forever.

### WebsiteAudit / AuditJob

**Source:** `apps/outreach/models/auditing.py`

`WebsiteAudit` caches an audit **per domain per owner**
(`UniqueConstraint one_audit_per_domain_per_owner`) so re-crawling the same site inside
`OUTREACH_AUDIT_MAX_AGE_DAYS` is unnecessary. `status` mirrors the crawler's:
`ok`, `blocked`, `failed`, `no_website`.

`AuditJob` is the submitted-URL queue. 9 states: `created`, `queued`, `crawling`,
`analyzing`, `contacts_found`, `draft_ready`, `ready_for_review`, `sent`, `failed`.
Note that `ready_for_review` is a terminal state as far as the worker is concerned —
nothing moves it to `sent` except a person pressing Send.

```
Index  audit_state_created_idx  (state, created_at)
Index  audit_owner_time_idx     (owner, -created_at)
```

### ProviderCredential / CredentialEvent / AiSelection

**Source:** `apps/ai/models.py`. Tables are still named `outreach_*` — see chapter 4.

`ProviderCredential` holds one AI key: `secret` encrypted, `hint` masked, plus health
counters (`request_count`, `error_count`, `last_error_category`, `last_success_at`).

```
UniqueConstraint  one_active_credential_per_provider_per_owner
UniqueConstraint  one_label_per_provider_per_owner
Index             pc_owner_prov_active_idx  (owner, provider, is_active)
```

The first constraint is the interesting one: it makes "exactly one active key per
provider" a database fact rather than application logic.

### Concurrency protection, summarised

Every concurrent path in this project is protected by the database, not by timing:

| What must not happen twice | Mechanism | Where |
| --- | --- | --- |
| The same address emailed twice | `UniqueConstraint` on insert-before-send | `services/history.py :: reserve()` |
| Two workers on one plan | Conditional `UPDATE` on the lease | `automation/runner.py :: claim()` |
| Two workers on one lead | Conditional `UPDATE` on `claimed_by` | `automation/runner.py :: claim_lead()` |
| Exceeding the daily target | Conditional `UPDATE` on `AutomationDay` | `apps/outreach/services/automation/runner.py` |
| Two drafts of one follow-up | Conditional `UPDATE`, else unique-constraint insert | `services/followups.py :: claim()` |
| Two jobs for one campaign (in-process) | `_running` set + `_claim()` | `apps/outreach/services/pipeline.py` |
| Two audits of one job | Conditional `UPDATE` on the job lease | `services/websiteaudit.py :: claim()` |

### In simple words

13 tables. `Campaign` is a job, `EmailDraft` is one business inside it, `SentLead` is the
permanent "we emailed them" record, and `Suppression` is the do-not-contact list.
Everything that must not happen twice is prevented by a database constraint, not by
careful code — because careful code loses races and databases do not.

---

# 6. Business Discovery

### What is it?

Finding real local businesses to contact, by country, city and category.

### Where is the code?

| File | Class / Function | Purpose |
| --- | --- | --- |
| `apps/leads/scraper.py` | `search()` | The whole search: geocode, query, parse, qualify |
| `apps/leads/scraper.py` | `Lead` | One business as a dataclass before it becomes a draft |
| `apps/leads/scraper.py` | `ScrapeError` | Anything that went wrong, with a readable message |
| `apps/leads/scraper.py` | `_throttle()`, `_headers()`, `_check_contact()` | Rate-limit and identify ourselves |
| `apps/leads/places.py` | `countries()`, `cities_for()`, `validate()` | Offline country/city data from `geonamescache` |
| `apps/leads/views.py` | `search`, `cities`, `export`, `index` | The screens and JSON endpoints |
| `apps/outreach/services/automation/leads.py` | `fill()`, `claim_search()`, `ensure_searches()` | The same search, driven by an automation plan |

### External sources — the actual two

**Source:** `apps/leads/scraper.py`

```python
NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"
OVERPASS_URLS = ("https://overpass-api.de/api/interpreter",
                 "https://overpass.kumi.systems/api/interpreter",
                 "https://overpass.osm.ch/api/interpreter")
```

Both are OpenStreetMap. **Nominatim** turns "Delft, Netherlands" into a bounding box.
**Overpass** returns businesses inside that box matching the category. Three Overpass
mirrors, tried in order, because the main one rate-limits.

No Google Places, no paid data provider, no scraping of a directory site.

### Politeness, which is not optional here

```python
MIN_INTERVAL = {"nominatim.openstreetmap.org": 1.1}
DEFAULT_INTERVAL = 0.5
QUERY_TIMEOUT = 90
MAX_LEADS = 300
USER_AGENT = "LeadMapper/1.0 (+{contact})"
```

`_check_contact()` refuses to run if `OSM_CONTACT_EMAIL` is still a placeholder.
Nominatim's usage policy requires a real contact address in the User-Agent and at most
one request per second — `MIN_INTERVAL` is 1.1s to stay on the right side of it. This is
enforced in code rather than trusted to the caller.

### How it works

```
User picks country + city + category
   ↓
apps/leads/places.py :: validate(country, city)      offline, no network
   ↓
apps/leads/scraper.py :: search()
   ↓  _throttle("nominatim.openstreetmap.org")        >= 1.1s since last
   ↓  GET Nominatim  -> bounding box
   ↓  _throttle()
   ↓  POST Overpass  (mirror 1, then 2, then 3)      -> raw OSM elements
   ↓  parse tags: _KIND_TAGS = shop, office, craft, amenity,
   ↓              healthcare, tourism, leisure
   ↓  build Lead objects; drop placeholder contacts
   ↓  cap at MAX_LEADS = 300
   ↓
Table + map in templates/leads/index.html
   ↓  user selects rows
POST /outreach/start -> apps/outreach/views/campaigns.py :: start()
   ↓  MAX_LEADS_PER_CAMPAIGN = 300  (views/shared.py)
Campaign + one EmailDraft per selected lead
```

### Qualification and duplicate prevention

Two different things happen at two different times:

1. **At search time** — `_PLACEHOLDER_CONTACTS = ("example.com", "example.org",
   "example.net", "test.com")`. A business whose published email is on one of those is
   not a lead.
2. **At campaign time** — `apps/outreach/services/history.py :: annotate_leads()` marks
   which of the selected leads have been contacted before, so the table shows it, and
   `mark_campaign_duplicates()` sets `EmailDraft.status = duplicate` for repeats inside
   one campaign.
3. **At send time** — `reserve()` and the unique constraint. This is the one that
   actually guarantees it; the earlier two are for the operator's benefit.

### Database involvement

`Campaign` and `EmailDraft` are created here. `SentLead` and `Suppression` are read (to
annotate). Search results themselves are **not** stored as their own table — a `Lead` is
a dataclass that becomes an `EmailDraft` or is discarded. In an automation plan, the
search *attempt* is recorded as a `ProspectSearch` row so it is not repeated.

### Error handling

`ScrapeError` carries a sentence for the operator. Overpass mirrors are tried in turn; if
all three fail the search fails with a message rather than returning an empty list, so
"no businesses here" and "the data source is down" are never confused. `QUERY_TIMEOUT`
is 90 seconds because Overpass is genuinely slow for a large box.

### Security

The category and city reach Overpass as part of a query, and are validated against the
offline `geonamescache` data first (`places.validate()`) rather than passed through. The
User-Agent carries a real contact address so OSM can identify and, if necessary, block
this client — that is the polite half of a permitted-data-only posture.

### How to debug

```bash
# Is the contact address configured? A placeholder makes search refuse.
grep OSM_CONTACT_EMAIL .env

# Try a search from a shell with the real code path
python manage.py shell -c "
from apps.leads import scraper
leads = scraper.search(country='Netherlands', city='Delft', category='Restaurants')
print(len(leads)); print(leads[0] if leads else 'none')"

# Country/city validation only, no network
python manage.py shell -c "
from apps.leads import places
print(places.validate('Netherlands', 'Delft'))
print(len(places.cities_for('Netherlands')))"
```

If a search returns nothing: check the category spelling against `_KIND_TAGS`, and try a
bigger city — Overpass returns what OSM has, and small towns genuinely have few tagged
businesses.

### How to safely modify it

- **New category mapping** → `_KIND_TAGS` and the tag-parsing block in
  `apps/leads/scraper.py`. Tests: `apps/leads/tests.py :: BuildQueryTests`,
  `CustomFilterTests`.
- **A new qualification rule** → `apps/leads/scraper.py`, in the `Lead` construction, and
  `ToLeadTests` / `ContactGuardTests`.
- **A different data source** → replace `search()`. Everything downstream takes `Lead`
  objects, so the blast radius is one function, but you own the licensing question.

### In simple words

It asks OpenStreetMap "what shops of this kind are in this town", politely and slowly
enough not to get blocked, throws away obvious junk, and turns each result into a row you
can select. It does not buy data and it does not scrape Google.

---
# 7. Website Crawler

### What is it?

The part that reads a lead's website: fetches the homepage, works out which other pages
are worth reading, fetches a few of them, and hands back structured pages.

### Why does it exist?

Every claim in every email has to trace to something on that specific site. That means
actually reading the site — and doing it in a way that a website owner would not object
to if they looked at their logs.

### Where is the code?

`apps/auditing/crawler.py` (~700 lines). Entry point: `analyse()`.

| Function | Purpose |
| --- | --- |
| `analyse(website, ...)` | The whole crawl. **Never raises** — returns a `SiteAnalysis` |
| `normalise(url)` | Adds a scheme, strips fragments, lowercases the host |
| `_canonical(url)` | The de-duplication key for "same page" |
| `_fetch(url, guard)` | One request with retries, size cap and redirect limit |
| `_get(url)` | The raw `requests` call |
| `_guard(guard, url)` | Calls the caller's guard before every request, redirects included |
| `_robots_for(base)` | Fetches and caches `robots.txt` |
| `_allowed(url, robots)` | Whether `robots.txt` permits this URL |
| `_throttle(host)` | Per-host delay |
| `_headers()` | The User-Agent with a contact address |
| `classify(url, anchor)` | What kind of page a link looks like, and how valuable |
| `discover_links(html, base)` | Internal links worth considering, from nav/footer/body |
| `discover_sitemap(base, robots)` | Reads `sitemap.xml` when `robots.txt` names one |
| `choose_pages(candidates, ...)` | Picks which of the candidates to actually fetch |
| `forget_robots()` | Clears the robots cache (used by tests) |

### The limits, all in one place

**Source:** `apps/auditing/crawler.py`, lines ~82–127. Every one is overridable by an
environment variable through `_tunable()`.

| Constant | Default | Env var | What it bounds |
| --- | --- | --- | --- |
| `TARGET_INTERNAL` | 5 | `OUTREACH_CRAWL_TARGET_PAGES` | Internal pages we aim to read |
| `MAX_PAGES` | 8 | `OUTREACH_CRAWL_MAX_PAGES` | Hard ceiling on pages fetched |
| `MAX_DEPTH` | 3 | `OUTREACH_CRAWL_MAX_DEPTH` | Link depth from the homepage |
| `MAX_CANDIDATES` | 400 | — | Links considered before scoring |
| `MAX_SITEMAP_URLS` | 300 | — | URLs read from a sitemap |
| `MAX_BYTES` | 2,000,000 | `OUTREACH_CRAWL_MAX_BYTES` | Per-response size cap |
| `TIMEOUT` | 15 | `OUTREACH_CRAWL_TIMEOUT` | Seconds per request |
| `HOST_DELAY` | 1.0 | `OUTREACH_CRAWL_DELAY` | Seconds between requests to one host |
| `MAX_ATTEMPTS` | 2 | `OUTREACH_CRAWL_RETRIES` | Attempts per URL |
| `MAX_REDIRECTS` | 5 | `OUTREACH_CRAWL_MAX_REDIRECTS` | Redirect hops followed |
| `ROBOTS_TTL` | 3600.0 | `OUTREACH_CRAWL_ROBOTS_TTL` | Seconds a `robots.txt` is cached |
| `CONTEXT_BUDGET` | 9000 | `OUTREACH_AI_CONTEXT_CHARS` | Characters of site text sent to the AI |

### robots.txt — obeyed, with a cache

`_robots_for()` fetches `robots.txt` and parses it with Python's `RobotFileParser`,
caching per host for `ROBOTS_TTL`. `_allowed()` is consulted for the homepage *and* every
discovered link. A disallowed homepage ends the crawl with status `BLOCKED` — it does not
try anyway and it does not raise.

`_robots_for` failing is treated as "no robots file" rather than as an error, because a
missing or malformed `robots.txt` is common and is not a refusal.

### Bot walls — recognised, never worked around

```python
BOT_WALL_MARKERS = (...)      # crawler.py line ~155
```

If a fetched page's content matches one of these markers, the crawl stops with `BLOCKED`.
This is the deliberate line: the system detects that it has hit a challenge page and
gives up. There is no CAPTCHA solving, no header spoofing to look like a browser, no
retry-with-different-fingerprint. The User-Agent identifies the crawler honestly.

### Page selection — why not just crawl everything

`classify(url, anchor_text)` returns a `(kind, value)` pair: a link that looks like
`/contact`, `/about`, `/services`, `/pricing` scores high; a link to `/wp-login.php`,
`?add-to-cart=`, a `.pdf`, or a paginated archive scores zero. `discover_links()` gathers
candidates separately from `nav`/`header` and `footer` containers and the body, because a
link in the main navigation is more likely to be a real page than one in a sidebar.
`choose_pages()` then takes the best `TARGET_INTERNAL` within `MAX_DEPTH`.

`discover_sitemap()` is tried when `robots.txt` names a sitemap — a sitemap is the site
telling you what its pages are, which is better than guessing.

### SSRF protection — the `guard` parameter

**Source:** `apps/auditing/safeurl.py`, wired in through `analyse(guard=...)`

`analyse()` takes a `guard` callable. `_guard()` calls it before **every** request,
including every redirect hop. `safeurl.guard()` is what the submitted-URL workflow
passes. A refusal ends the crawl with `BLOCKED` rather than raising, because to the
caller "refused" and "robots says no" are the same kind of answer.

Redirect hops matter more than the initial URL: a public site is allowed to answer
`302 Location: http://169.254.169.254/`, and following it would read cloud metadata. The
guard sees that hop. Full detail in chapter 20.

For campaign crawls of OSM-published websites, `guard` is not passed — those URLs come
from OpenStreetMap, not from a form.

### How it works

```
analyse(website, guard=..., should_stop=..., progress=...)
   ↓ should_stop()?  -> SiteAnalysis(FAILED, stopped=True)
   ↓ normalise(website)
   ↓ empty?          -> SiteAnalysis(NO_WEBSITE, ...)
   ↓ _robots_for(url)                       (cached, best-effort)
   ↓ _allowed(url, robots)?  no             -> SiteAnalysis(BLOCKED, ...)
   ↓ _throttle(host); _guard(guard, url); _fetch(url)
   ↓   retries up to MAX_ATTEMPTS, MAX_BYTES cap, MAX_REDIRECTS hops
   ↓ bot wall marker in the HTML?           -> SiteAnalysis(BLOCKED, ...)
   ↓ measurements.extract(fetched, url, "home")   -> Page
   ↓ progress({"stage": "home", ...})
   ↓ discover_links(html, base) + discover_sitemap(base, robots)
   ↓ choose_pages(candidates, ...)          -> up to TARGET_INTERNAL
   ↓ for each: throttle, guard, fetch, extract, progress({"stage": "page"})
   ↓
SiteAnalysis(status, detail, pages=[Page, ...], emails_found=[...],
             discovered=N, sitemap_used=bool, stopped=bool)
```

`SiteAnalysis.usable` is `status == OK and bool(pages)` — the single check every caller
uses before trusting the result.

### Cancellation

`should_stop` is checked before every network request. The request in flight cannot be
aborted, but the next one need never start, so pressing Cancel stops a crawl within one
page. The result carries `stopped=True`, and the caller throws the partial read away
rather than storing it as the whole truth — `stopped` is deliberately separate from
`status`, because "half-read because somebody cancelled" is not "could not be read".

### The progress callback, and why the crawler stores no HTML

`progress` receives `{"stage": "home"|"discovered"|"page", ...}` as the crawl happens. It
serves two purposes: a status screen can report what has actually been read, and a caller
can look at each page's HTML **while it is still in memory**. Contact extraction uses
that (chapter 10), which is why the crawler does not keep every page's markup for a caller
that may not want it.

An exception from `progress` is caught and logged, never allowed to end the crawl — the
crawl is the expensive part and a caller's bookkeeping is not worth losing it for.

### Database involvement

**None directly.** `apps/auditing/crawler.py` touches no model. Callers persist the
result: `services/intelligence.py :: remember()` writes a `WebsiteAudit`, and
`apps/outreach/services/pipeline.py` writes `analysis_status` / `analysis_context` onto the
`EmailDraft`. This is what makes the crawler testable with a fake `requests` session and
no database.

### Error handling

`analyse()` never raises. Every failure becomes a status:

| Status | Means |
| --- | --- |
| `OK` | Read at least one page |
| `BLOCKED` | `robots.txt` refused, a bot wall, or the `guard` refused |
| `FAILED` | Network error, timeout, non-HTML, all retries used |
| `NO_WEBSITE` | The lead has no website to read |

`detail` carries a sentence for the operator. The card in the UI shows it, and an email
generated for a lead with a non-`OK` status makes no claim about the site.

### How to debug

```bash
# Crawl one site and see exactly what came back
python manage.py shell -c "
from apps.auditing import crawler
r = crawler.analyse('https://example.com')
print(r.status, '|', r.detail)
print('pages:', len(r.pages), 'discovered:', r.discovered, 'sitemap:', r.sitemap_used)
for p in r.pages: print('  ', p.kind, p.url)"

# Is robots.txt the reason?
python manage.py shell -c "
from apps.auditing import crawler
crawler.forget_robots()
robots = crawler._robots_for('https://example.com')
print('allowed:', crawler._allowed('https://example.com/', robots))"

# Loosen the limits for one investigation
OUTREACH_CRAWL_MAX_PAGES=15 OUTREACH_CRAWL_TIMEOUT=40 python manage.py shell -c "..."
```

The tests to read: `apps/auditing/tests/test_crawler.py` (31 tests) — `DiscoveryTests`
covers page choice, `AnalyserPolicyTests` covers the refusals.

### How to safely modify it

- **A new page-worth-reading rule** → `classify()`. Tests: `DiscoveryTests`.
- **A new refusal** → `BOT_WALL_MARKERS`, or `_allowed()`. Tests: `AnalyserPolicyTests`.
- **Different limits** → set the env var; do not edit the constant.
- **A new measurement** → this is the wrong file. Go to `measurements.py` (chapter 8).

### In simple words

It reads the homepage, decides which handful of other pages are worth a look, reads
those, and stops. It obeys `robots.txt`, waits a second between requests, gives up if it
hits a "prove you are human" wall instead of trying to get past it, and never follows a
redirect into a private network. It never crashes — every failure comes back as a status
with a sentence.

---

# 8. Website Audit / Analyzer

### What is it?

Turning crawled pages into **facts**, then into **scores**, then giving those facts to the
AI so it can write findings that cite them.

### Why does it exist?

This is the chapter that makes the product honest. Without it the AI would be asked "what
is wrong with this website?" and would produce plausible, confident, unverifiable claims.
Instead it is asked "here are 40 measured facts about this site — which of them matter,
and why?"

### Where is the code?

| File | Class / Function | Purpose |
| --- | --- | --- |
| `apps/auditing/measurements.py` | `measure(soup, html, fetched)` | The signal dictionary for one page |
| `apps/auditing/measurements.py` | `extract(fetched, url, kind)` | `Fetched` → `Page` |
| `apps/auditing/measurements.py` | `detect_stack(html, generator)` | Which platform built the site |
| `apps/auditing/measurements.py` | `Page`, `Fetched` | The interface types between crawler and analysis |
| `apps/auditing/scoring.py` | `merge_signals(pages)` | Per-page signals → one site-wide dict |
| `apps/auditing/scoring.py` | `performance_score()` … `technical_score()` | Six sub-scores |
| `apps/auditing/scoring.py` | `WebsiteAssessment` | The combined result |
| `apps/auditing/scoring.py` | `classify(website, analysis_status, pages_read)` | `website_found` / `no_website_opportunity` / `website_unverified` |
| `apps/auditing/scoring.py` | `platform_advice(signals)` | `keep` / `optimise` / `modernise` / `unknown` |
| `apps/auditing/scoring.py` | `unsupported_replatform(finding, advice)` | Catches a "rebuild it" claim the measurements do not support |
| `apps/ai/prompts.py` | `build_audit_prompt()`, `AUDIT_SCHEMA` | What the model is asked |
| `apps/ai/reports.py` | `audit_report(findings)` | Groups findings by priority for display |
| `apps/outreach/services/intelligence.py` | `audit_website()`, `remember()`, `apply()` | Persists and applies the result |

### The signals — what is actually measured

**Source:** `apps/auditing/measurements.py`

`measure()` returns a dictionary of facts about one page. The tables that drive it:

| Table | What it detects |
| --- | --- |
| `CTA_PATTERN` | Call-to-action text: "book", "call", "get a quote", "contact us" |
| `TRUST_PATTERN` | Trust signals: reviews, testimonials, accreditations, guarantees |
| `PLACEHOLDER_PATTERN` | Lorem ipsum, "your text here", unedited theme copy |
| `VAGUE_LINK_PATTERN` | "click here", "read more" — links with no destination in the text |
| `BUSINESS_PATTERNS` / `BUSINESS_SIGNALS` | Opening hours, prices, address, booking, menu, gallery |
| `SKIP_PATTERN` | Content to exclude from text extraction |
| `NAV_CONTAINERS` / `FOOTER_CONTAINERS` | Where a link was found, which changes what it means |

Plus the mechanical ones: page load time (`load_ms` on `Fetched`), transferred bytes,
title and meta-description presence and length, heading structure, image count and
`alt`-text coverage, viewport meta tag, HTTPS, form presence, `mailto:`/`tel:` links,
text length against `MIN_PAGE_TEXT = 350`.

`TEXT_BUDGET = 4_000` characters of page text stored per page.

Every one of these is something a person could check by opening the page. That is the
test for whether a signal belongs here.

### The six sub-scores

**Source:** `apps/auditing/scoring.py`

```python
SUB_SCORES = (performance, mobile, seo, ux, conversion, technical)
SUB_WEIGHTS = {...}
SEVERITY_WEIGHT = {"critical": 14, "high": 10, "medium": 5, "low": 2}
```

Each is a function `signals -> Score`, where `Score` carries a number and a list of
`Factor` deductions — so the score can always be explained as "100, minus 10 for no
viewport tag, minus 5 for a 4-second homepage".

`_quality(deductions, measured=True)` is the shared shape. The `measured` flag matters: a
score derived from nothing measured is not 100, it is *unknown*, and the code keeps that
distinction rather than flattering a site it could not read.

### Platform advice — and the guard on it

```python
KEEP      = "keep"        # the platform is fine; the opportunity is elsewhere
OPTIMISE  = "optimise"    # a measured problem, fixable where it stands
MODERNISE = "modernise"   # measured problems that a rebuild would address
UNKNOWN   = "unknown"     # nothing detected; say nothing
ESTABLISHED_PLATFORMS = (...)
SLOW_MS  = 4000           # homepage response, not a lab score
HEAVY_KB = 4000           # transferred weight of one page
```

`platform_advice(signals)` decides which of the four applies.
`unsupported_replatform(finding, advice)` then checks the AI's output: if a finding says
"you should rebuild on a modern platform" but the advice is `keep` or `unknown`, the
finding is rejected. `REPLATFORM_PHRASES` is the list of wordings it looks for.

This exists because "you should rebuild your website" is the most commercially convenient
thing an AI could say and the least likely to be supported by evidence.

### The pipeline

```
crawler.analyse(website)
   ↓  SiteAnalysis(pages=[Page, ...])
measurements.measure()  per page, inside extract()
   ↓  Page.signals = {"cta_count": 0, "load_ms": 4200, "has_viewport": False, ...}
scoring.merge_signals(pages)
   ↓  one site-wide signal dict
scoring.performance_score() / mobile_ / seo_ / ux_ / conversion_ / technical_
   ↓  six Score objects with Factor deductions
scoring.platform_advice(signals)   -> keep | optimise | modernise | unknown
   ↓
ai/prompts.build_audit_prompt(signals=..., pages=...)
   ↓  the facts, as text, with AUDIT_SCHEMA demanding structured JSON back
ai/client._complete()  ->  the provider
   ↓
ai/parsing.parse_audit(text)   -> SiteAudit(findings=[Finding, ...])
   ↓
ai/prompts.attribute_pages(findings, pages)     which page each finding is about
ai/validation.assign_ids(findings)              AUD-001, AUD-002, ...
ai/validation.hedge_findings(findings)          soften anything unverifiable
scoring.unsupported_replatform(finding, advice) reject unsupported rebuild claims
   ↓
ai/reports.audit_report(findings)   -> grouped by PRIORITY_ORDER ("high","medium","low")
   ↓
services/intelligence.remember()    -> WebsiteAudit row
services/intelligence.apply()       -> scores and priority onto the EmailDraft
```

### Evidence-only rules — where they are enforced

Four separate places, deliberately:

1. **The prompt** — `AUDIT_SYSTEM` in `apps/ai/prompts.py` tells the model that every
   finding needs an `evidence` field naming the measured signal, and `AUDIT_SCHEMA` makes
   it a required property so a finding without one is invalid JSON.
2. **`build_audit_prompt()`** — only sends measured signals. The model cannot cite what
   it was not given.
3. **`apps/ai/validation.py`** — `specificity_problem()` rejects a draft whose claims are
   vague (`VAGUE_PATTERNS`) or contain invented numbers (`METRIC_PATTERNS`,
   `_METRIC_NUMBER`). `is_unverified()` / `UNVERIFIED_PHRASE = "could not be verified"`
   marks findings that must be hedged rather than stated.
4. **`scoring.unsupported_replatform()`** — the domain-specific check above.

`MAX_FINDINGS = 10` caps how many come back.

### Database involvement

| Model | Role |
| --- | --- |
| `WebsiteAudit` | The cached audit, one per domain per owner. Written by `remember()` |
| `EmailDraft` | `analysis_status`, `analysis_context`, `findings` JSON, the six sub-scores, priority band, `recommended_service`, `business_summary` |

`OUTREACH_AUDIT_MAX_AGE_DAYS` controls how long a cached `WebsiteAudit` is reused before
a re-crawl. `cached_audit()` in `apps/outreach/services/intelligence.py` is the lookup.

### Error handling

A crawl that returns non-`OK` never reaches the AI as if it had succeeded.
`scoring.classify()` produces `website_unverified` and the downstream email says nothing
about the site. A malformed AI response raises from `parsing.parse_audit()` and is
retried once by `pipeline._call_ai()` — see chapter 9.

### How to debug

```bash
# The full audit path for one site, printed
python manage.py shell -c "
from apps.auditing import crawler, measurements, scoring
r = crawler.analyse('https://example.com')
print('crawl:', r.status, len(r.pages), 'pages')
signals = scoring.merge_signals([p.signals for p in r.pages])
for name, value in sorted(signals.items()): print(f'  {name} = {value}')
for fn in (scoring.performance_score, scoring.mobile_score, scoring.seo_score,
           scoring.ux_score, scoring.conversion_score, scoring.technical_score):
    s = fn(signals)
    print(f'{fn.__name__:22} {s.value:3}  ' + '; '.join(f.reason for f in s.deductions))
print('platform:', scoring.platform_advice(signals))"

# What stack was detected
python manage.py shell -c "
from apps.auditing import measurements
import requests
html = requests.get('https://example.com', timeout=15).text
print(measurements.detect_stack(html))"
```

Tests: `apps/auditing/tests/test_measurements.py` (26), `apps/ai/tests/test_audit.py`
(46), `apps/ai/tests/test_evidence.py` (48), `apps/outreach/tests/test_platform.py` (35).

### How to safely modify it

**Adding a signal** touches four places, in order:

1. `apps/auditing/measurements.py` — detect it in `measure()`, add any pattern constant.
2. `apps/auditing/scoring.py` — use it in whichever sub-score it belongs to.
3. `apps/ai/prompts.py` — `_signals_block()` includes it in the prompt text.
4. Tests — `apps/auditing/tests/test_measurements.py`, and
   `apps/ai/tests/test_evidence.py` if the AI is meant to be able to cite it.

Do **not** add a signal that cannot be pointed at on the page. That is the one rule.

### In simple words

It counts things on the pages it read — how fast, how heavy, is there a phone number, is
there a "book now" button, does it work on a phone — and turns them into six scores it
can explain. Then it gives the AI *only those facts* and asks which matter. If the AI
says something the facts do not support, the code throws it away.

---
# 9. AI System

### What is it?

Every call to a language model in this project, and the machinery that keeps its answers
honest.

### Where is the code?

`apps/ai/` — 16 modules plus 6 backends. Nothing outside this app calls a provider.

| File | Class / Function | Purpose |
| --- | --- | --- |
| `apps/ai/client.py` | `_complete()` | **The one place a provider is called** |
| `apps/ai/client.py` | `provider()`, `model()`, `backend()`, `load()` | Which provider and model are active |
| `apps/ai/client.py` | `_fallback_for()`, `FALLBACK_CATEGORIES` | Opt-in spare-key retry |
| `apps/ai/generation.py` | `audit()`, `generate()`, `no_website_email()`, `follow_up()` | The four AI features |
| `apps/ai/prompts.py` | `AUDIT_SYSTEM`, `SYSTEM_TEMPLATE`, `FOLLOWUP_SYSTEM`, `NO_WEBSITE_SYSTEM` | The system prompts |
| `apps/ai/prompts.py` | `AUDIT_SCHEMA`, `schema_for()`, `NO_WEBSITE_SCHEMA` | The JSON schemas |
| `apps/ai/prompts.py` | `build_audit_prompt()`, `build_prompt()`, `build_no_website_prompt()` | The user prompts |
| `apps/ai/prompts.py` | `attribute_pages()` | Which page each finding is about |
| `apps/ai/parsing.py` | `parse()`, `parse_audit()`, `parse_followup()`, `parse_no_website()` | Text → typed objects |
| `apps/ai/validation.py` | `draft_problem()`, `specificity_problem()`, `style_problem()` | Rejecting a bad answer |
| `apps/ai/validation.py` | `hedge_findings()`, `unhedged_benefit()`, `assign_ids()` | Softening and labelling |
| `apps/ai/base.py` | `AiError`, `classify_rate_limit()`, `retry_after_of()` | Provider-neutral errors |
| `apps/ai/base.py` | `GeneratedEmail`, `Finding`, `SiteAudit` | The output dataclasses |
| `apps/ai/credentials.py` | `resolve()`, `require()`, `SPECS` | Which key to use |
| `apps/ai/styles.py` | `Style`, `DEFAULT_STYLE` | Email length and tone presets |
| `apps/ai/context.py` | `get_owner()`, `using_credential()` | Per-request AI context |
| `apps/ai/backends/` | `claude`, `gemini`, `groq`, `openai`, `openrouter`, `openai_compatible` | One `complete()` per provider |

### Providers — the actual five

**Source:** `apps/ai/credentials.py → SPECS`

| Provider | Default model | SDK | Env vars | Key prefix |
| --- | --- | --- | --- | --- |
| `claude` | `claude-opus-5` | `anthropic` | `ANTHROPIC_API_KEY`, `ANTHROPIC_AUTH_TOKEN` | `sk-ant-` |
| `gemini` | `gemini-3.7-flash` | `google-genai` | `GEMINI_API_KEY`, `GOOGLE_API_KEY` | — |
| `openai` | `gpt-4.1-mini` | `openai` | `OPENAI_API_KEY` | `sk-` |
| `openrouter` | `openai/gpt-4.1-mini` | `openai` | `OPENROUTER_API_KEY` | `sk-or-` |
| `groq` | `openai/gpt-oss-120b` | `groq` | `GROQ_API_KEY` | `gsk_` |

`DEFAULT_PROVIDER = "claude"`. `OUTREACH_AI_PROVIDER` overrides it;
`OUTREACH_AI_MODEL` overrides the model. Backends are imported lazily
(`client.load()`), so only the SDK for the provider you actually use needs to be
installed — all four are in `requirements/base.txt` for convenience.

`openrouter` and `openai` share `apps/ai/backends/openai_compatible.py`; the two thin modules
differ only in base URL and default model.

### Token budgets

```python
AUDIT_MAX_TOKENS = int(os.environ.get("OUTREACH_AI_AUDIT_TOKENS", "2600"))
EMAIL_MAX_TOKENS = int(os.environ.get("OUTREACH_AI_EMAIL_TOKENS", "1200"))
# and OUTREACH_AI_FOLLOWUP_TOKENS, OUTREACH_AI_CONTEXT_CHARS (9000)
```

### DETERMINISTIC CODE vs AI-DRIVEN LOGIC

This split is the design, not an accident. **Anything that can be wrong in a way a
customer would notice is deterministic.**

| Deterministic (Python decides) | AI-driven (the model decides) |
| --- | --- |
| What is measured on a page — `measurements.measure()` | Which measured facts matter most |
| The six sub-scores — `scoring.py` | How to phrase a finding |
| Priority bands — `OUTREACH_PRIORITY_HOT/WARM/LOW` | The subject line and the email body |
| Whether a finding may claim a rebuild — `unsupported_replatform()` | The business summary |
| Whether an email is too long, too short, or salesy — `validation.py` | Which finding to lead the email with |
| Whether a benefit is hedged — `unhedged_benefit()` | The follow-up's wording |
| Whether an address may be contacted — `history.py`, `Suppression` | — |
| Whether a send is allowed — `reserve()`, the unique constraints | — |
| Which page a finding is about — `attribute_pages()` | — |
| Finding ids — `assign_ids()`, `FINDING_PREFIX = "AUD"` | — |

**Why:** the model is good at judgement and phrasing and bad at arithmetic, consistency
and restraint. So it is given facts and asked for prose, and every number, threshold and
permission stays in code where it can be tested. Nothing the AI returns is trusted enough
to reach a recipient without passing deterministic checks first.

### The prompt structure

**System prompt** (`AUDIT_SYSTEM`, or `system_for(style)` for emails) carries the rules:
evidence or silence, no invention, no flattery, length limits, tone. `SYSTEM_TEMPLATE`
has a `LENGTH_SLOT = "{length_rule}"` substituted by `system_for()` using
`str.replace`, **not** `str.format` — the prompt contains literal braces from the JSON
examples, and `format` raised `KeyError` on them.

**User prompt** (`build_audit_prompt()` / `build_prompt()`) carries the data: business
name, category, city, country, the measured signals (`_signals_block()`), and the page
extracts (`_pages_block()`) up to `CONTEXT_BUDGET` characters.

**Schema** (`AUDIT_SCHEMA`, `schema_for(style)`) is a JSON Schema passed to the provider's
structured-output mode. `evidence` is a required property on every finding, so a finding
with no cited signal is invalid at the protocol level rather than caught later.

### Output and validation

```
provider text
   ↓ parsing._load_json(text)          tolerant of fenced code blocks
   ↓ parsing.parse_audit() / parse()   -> SiteAudit / GeneratedEmail
   ↓ validation.assign_ids()           AUD-001, AUD-002 ...
   ↓ prompts.attribute_pages()         each finding gets its page_url
   ↓ validation.hedge_findings()       unverifiable claims are softened
   ↓ validation.draft_problem()        banned phrases, flattery, shouting
   ↓ validation.style_problem()        word count against the Style
   ↓ validation.specificity_problem()  vague claims, invented metrics
   ↓ scoring.unsupported_replatform()  unsupported "rebuild it" claims
   ↓ validation.unhedged_benefit()     a promise with no hedge
   ↓
accepted, or the caller retries / rejects
```

The rejection tables, all in `apps/ai/validation.py`:

| Constant | Catches |
| --- | --- |
| `BANNED_PHRASES`, `BANNED_STEMS`, `_BANNED_PATTERN` | Spam and cliché wording |
| `_FLATTERY` | "I love your website", "your beautiful business" |
| `_SHOUTING` + `_SHOUTING_ALLOWED` | ALL-CAPS words, minus a whitelist (`VAT`, `SEO`, `GDPR`, …) |
| `VAGUE_PATTERNS` | "could be improved", "may not be optimal" |
| `METRIC_PATTERNS`, `_METRIC_NUMBER` | Invented numbers — "40% more conversions" |
| `GUARANTEE_PATTERNS` | An unhedged promise |
| `HEDGES`, `BENEFIT_WITHHELD` | The acceptable hedged forms |
| `UNVERIFIED_PHRASE = "could not be verified"` | Marks a finding as unverifiable |

`EMAIL_MIN_WORDS` / `EMAIL_MAX_WORDS` come from `styles.DEFAULT_STYLE`.

### Error handling, retry and fallback

**Provider-neutral errors** — `apps/ai/base.py`:

```python
RATE_LIMIT = "rate_limit"
QUOTA      = "quota"
class AiError(RuntimeError): ...
classify_rate_limit(message)   # which of the two a message is
retry_after_of(error)          # seconds, from the body or a Retry-After header
_WAIT_PATTERNS, _UNIT_SECONDS  # parses "try again in 2m30s"
```

Each backend raises its SDK's own exception; `credentials.categorise()` maps it to a
category and a written phrase. **The provider's own error text is never stored or
shown** — it can quote the request, and the request carried the key.

**Two independent retry mechanisms:**

1. **Spare-credential fallback** — `client._complete()`. If the active credential fails
   with a category in `FALLBACK_CATEGORIES = ("rate_limited", "unavailable")` *and* the
   user has explicitly marked a spare key as usable (`allow_fallback`), the spare is
   tried **for that one request**. The active credential is never silently rotated:
   that would leave the Settings page saying something different from what the
   application is doing. Both attempts are recorded as `CredentialEvent` rows.
2. **Transient retry and rate-limit pause** — `services/pipeline.py :: _call_ai()`. One
   retry for a transient failure (`AI_RETRY_DELAY = 20.0`), none for a permanent one. A
   rate limit raises `RateLimited`, which parks the whole campaign:
   `_park()` / `_hold()` / `_backoff()` with `BACKOFF_BASE = 30.0`,
   `BACKOFF_CAP = 900.0`, `MAX_PAUSES = 5`, `MAX_INLINE_WAIT = 300.0`. The campaign's
   `phase` becomes `paused_rate_limit` with a `retry_at`, and the workspace offers
   **Resume now**.

### Hallucination prevention, in one list

1. The model is only given measured signals — it cannot cite what it never saw.
2. `evidence` is a required schema property.
3. `specificity_problem()` rejects vague claims and invented numbers.
4. `hedge_findings()` softens anything marked unverifiable.
5. `unsupported_replatform()` rejects commercially convenient rebuild claims.
6. `attribute_pages()` ties each finding to a real crawled URL — a finding about a page
   that was not read cannot be attributed.
7. A crawl that failed produces `website_unverified`, and the email makes no site claim.

### Database involvement

`ProviderCredential` (which key), `CredentialEvent` (what happened to it),
`AiSelection` (which provider the account chose). The AI's *output* is stored by callers
onto `EmailDraft.findings` / `WebsiteAudit`, not by this app.

### Security

Keys are encrypted at rest (`apps/core/secrets.py`), masked for display
(`credentials.mask()`), never returned by an endpoint, never logged, and never in an
error message. `apps/ai/views.py` catches `CredentialError` specifically because that
class is documented not to carry a key.

### How to debug

```bash
# Which provider and credential are live, and where they came from
python manage.py ai_status
python manage.py ai_status --user you@example.com

# Actually generate one throwaway email — proves the key works end to end
python manage.py ai_status --live

# See a prompt without sending it
python manage.py shell -c "
from apps.ai import prompts
print(prompts.build_prompt(
    business_name='Bella Cucina', category='Restaurant', city='Delft',
    country='Netherlands', website='https://bella.example',
    observation='wood-fired pizza since 1998', findings=[], signals={},
    pages=None, sender_name='Sam', sender_company='Northline',
    sender_email='sam@agency.test', service_pitch='fast websites')[:1500])"
```

**Patching in tests:** patch `apps.ai.client.backend`, **not** `apps.ai.backend`.
`_complete()` resolves the name in `client`, so patching the package attribute leaves the
real provider in place — that mistake once made a test hit the live Groq API.

### How to safely modify it

- **A new validation rule** → `apps/ai/validation.py`, add the pattern and a check, then
  call it from the caller that should reject. Tests: `apps/ai/tests/test_email_style.py`,
  `test_evidence.py`.
- **Prompt wording** → `apps/ai/prompts.py`. Tests in `apps/ai/tests/test_prompts.py`
  assert specific phrases are present, and that is intentional — the prompt carries the
  product's promise, so changing it should fail a test until you have thought about it.
- **A new provider** → add a `Spec` to `credentials.SPECS`, add
  `apps/ai/backends/<name>.py` with a `complete()`, add the SDK to
  `requirements/base.txt`. Tests: `apps/ai/tests/test_backends.py`.
- **A new AI feature** → a function in `apps/ai/generation.py` that builds a prompt,
  calls `client._complete()`, parses and validates. Do not call a provider directly.

### In simple words

There is exactly one function that talks to an AI. It is given facts the crawler measured
and a strict JSON shape to answer in. Whatever comes back is checked by ordinary Python
code — too long, too vague, made-up numbers, salesy phrases, claims the facts do not
support — and thrown away if it fails. Anything a customer would notice being wrong is
decided in code, not by the model.

---

# 10. Contact / Email Discovery

### What is it?

Finding a real, published email address for a business — and refusing to invent one.

### Why does it exist?

The obvious shortcut is `info@` + the domain. It is also wrong often enough to matter:
it bounces, it damages the sending domain's reputation, and a bounce is worse than not
sending. So the rule is absolute — **an address is used only if it was published
somewhere the crawler actually read.**

### Where is the code?

| File | Class / Function | Purpose |
| --- | --- | --- |
| `apps/auditing/contacts.py` | `harvest_page(harvest, html, url, kind)` | Pull contact details out of one page |
| `apps/auditing/contacts.py` | `Harvest`, `Detail` | The accumulated result, and one detail with its source |
| `apps/auditing/contacts.py` | `_links()` | `mailto:` and `tel:` links |
| `apps/auditing/contacts.py` | `_schema()`, `_schema_node()`, `_nodes()` | JSON-LD / schema.org markup |
| `apps/auditing/contacts.py` | `_text()` | Plain-text addresses and phone numbers |
| `apps/auditing/contacts.py` | `_better()`, `_CONFIDENCE_ORDER` | Keeping the best of two candidates |
| `apps/auditing/measurements.py` | `scrape_emails(html)` | Simpler address extraction, used by the crawler |
| `apps/outreach/services/websiteaudit.py` | `SpecificWebsiteAuditService` | Drives harvesting for a submitted URL |
| `apps/outreach/services/automation/process.py` | `_discovered_email()`, `ROLE_ADDRESSES` | Picks which harvested address to use |

### The sources it reads, in order of trust

```
STRONG_PAGES = ("contact", "about", "home", "team")
```

1. **`mailto:` links** — the strongest signal. Somebody typed that address deliberately.
2. **schema.org / JSON-LD markup** — structured, machine-readable, intended to be read.
3. **Plain text on a strong page** — an address written out on the contact page.
4. **Plain text elsewhere** — accepted with lower confidence.

Each `Detail` carries its `kind` (`EMAIL`, `PHONE`, `ADDRESS`, `SOCIAL`, `BUSINESS`,
`PERSON`, `HOURS`), its `confidence` (`HIGH`, `MEDIUM`, `LOW`), and the URL it came
from. `_better()` uses `_CONFIDENCE_ORDER` to keep the stronger of two candidates —
so a `mailto:` on the contact page beats the same-looking string in a footer.

### The refusals

```python
NEVER_WORDS = ("noreply", "no-reply", "donotreply", "do-not-reply", "bounce", ...)
PLATFORM_DOMAINS = ("example.com", "example.org", "example.net", "domain.com", ...)
```

`NEVER_WORDS` addresses are never usable — mailing to `noreply@` reaches nobody and looks
automated. `PLATFORM_DOMAINS` catches unedited theme placeholders, which are extremely
common on small-business sites.

Classification tables that inform, but do not exclude:

```python
OWNER_WORDS      = ("owner", "founder", "director", "principal", "ceo", "md", ...)
BUSINESS_WORDS   = ("info", "contact", "hello", "hi", "enquiries", "enquiry", ...)
DEPARTMENT_WORDS = ("sales", "support", "help", "service", "bookings", ...)
```

`ROLE_ADDRESSES` in `apps/outreach/services/automation/process.py` uses the same idea when choosing between
several harvested addresses — a named person is preferred over `info@`, but `info@` that
was *published* is fine; `info@` that was *guessed* is not.

Obfuscation is handled: `_OBFUSCATED` matches `name [at] domain [dot] com` forms, because
that is a published address written to defeat naive scrapers, not a hidden one.

Social links are recognised via `SOCIAL_HOSTS`, which includes `wa.me` and
`api.whatsapp.com` → `"WhatsApp"`. See the WhatsApp note in chapter 32.

### How it works

```
crawler.analyse(website, progress=callback)
   ↓  for each page, while its HTML is still in memory:
callback({"stage": "page", "html": ..., "url": ..., "kind": ...})
   ↓
contacts.harvest_page(harvest, html, url, kind)
   ↓  _links()    mailto: / tel:
   ↓  _schema()   JSON-LD blocks -> _schema_node()
   ↓  _text()     plain text, including _OBFUSCATED forms
   ↓  _better()   keep the higher-confidence candidate per address
   ↓
Harvest.emails / .phones / .people / .address / .social / .hours
   ↓
process._discovered_email(draft)  or  SpecificWebsiteAuditService
   ↓  drop NEVER_WORDS and PLATFORM_DOMAINS
   ↓  prefer a named person, then a business address
   ↓
EmailDraft.email      — or status = no_email, and nothing is sent
```

The `progress` callback is why this works without the crawler storing every page's HTML:
harvesting happens while the page is in memory, and only the extracted details are kept.

### The no-email case

`EmailDraft.status = no_email` (a real choice on the model). The lead stays visible with
that status so the operator can see the business was found and could not be contacted.
Nothing is sent, and no address is constructed.

For a submitted-URL audit with no email found: the job reaches `ready_for_review` with
the report and the draft, and the send button reports that there is no address. Tested by
`apps/outreach/tests/test_websiteaudit.py :: NoEmailFoundTests`.

### Database involvement

`EmailDraft.email`, `EmailDraft.phone`, `EmailDraft.status = no_email`.
`AuditJob` carries the harvested contact details for the submitted-URL workflow, and
reaches state `contacts_found`. `SentLead.email` is the permanent record of what was
actually used.

### Error handling

`harvest_page()` is defensive — malformed JSON-LD, broken HTML and missing attributes are
skipped rather than raised, because one bad page must not lose the crawl. A page that
yields nothing simply adds nothing to the `Harvest`.

### Security

Addresses are read from HTML the crawler fetched under `robots.txt` and the SSRF guard —
this is published data on a public page, not a scraped private directory or a
login-protected page. Nothing here bypasses a restriction to reach an address.

### How to debug

```bash
python manage.py shell -c "
import requests
from apps.auditing import contacts
h = contacts.Harvest()
html = requests.get('https://example.com/contact', timeout=15).text
contacts.harvest_page(h, html, 'https://example.com/contact', 'contact')
for d in h.emails:  print('EMAIL', d.value, d.confidence, d.source)
for d in h.phones:  print('PHONE', d.value, d.confidence, d.source)
for d in h.people:  print('PERSON', d.value, d.confidence, d.source)"
```

If a lead is `no_email` and you can see an address on the site: check whether it is inside
an image (nothing can read that), whether the contact page was among the pages chosen
(`choose_pages()`, chapter 7), and whether the address matches `NEVER_WORDS` or
`PLATFORM_DOMAINS`.

### How to safely modify it

- **A new source of addresses** → a `_...()` helper in `apps/auditing/contacts.py`,
  called from `harvest_page()`, feeding `_better()`. Tests:
  `apps/outreach/tests/test_websiteaudit.py :: ContactTests`.
- **A new refusal** → `NEVER_WORDS` or `PLATFORM_DOMAINS`.
- **Never** add a function that constructs an address from a domain. There are tests
  asserting the no-email path stays a no-send.

### In simple words

It reads the pages it already fetched and picks out email addresses and phone numbers
that someone actually published — preferring a `mailto:` link or structured markup over
text it found lying around. It throws away `noreply@` and obvious theme placeholders. If
it finds nothing, the lead is marked "no email" and nothing is sent. It never makes an
address up.

---
# 11. Email Generation

### What is it?

Turning a lead plus its audit findings into a subject line and a body that a person would
plausibly reply to.

### Where is the code?

| File | Class / Function | Purpose |
| --- | --- | --- |
| `apps/ai/prompts.py` | `SYSTEM_TEMPLATE`, `system_for(style)` | The system prompt, with the length rule substituted |
| `apps/ai/prompts.py` | `build_prompt(...)` | The user prompt: business, findings, signals, pages |
| `apps/ai/prompts.py` | `SCHEMA_TEMPLATE`, `schema_for(style)` | The JSON shape demanded back |
| `apps/ai/prompts.py` | `NO_WEBSITE_SYSTEM`, `build_no_website_prompt()`, `NO_WEBSITE_SCHEMA` | The no-website variant |
| `apps/ai/prompts.py` | `DEFAULT_OFFER` | The fallback pitch when a campaign set none |
| `apps/ai/generation.py` | `generate(...)` | The call: prompt → provider → parse |
| `apps/ai/generation.py` | `no_website_email(...)` | For a lead with no site to audit |
| `apps/ai/parsing.py` | `parse(text)` | → `GeneratedEmail(subject, body, observation, finding_ids)` |
| `apps/ai/styles.py` | `CONSULTATIVE`, `BRIEF`, `STYLES`, `DEFAULT_STYLE` | The two approved templates |
| `apps/ai/validation.py` | `style_problem()`, `draft_problem()`, `specificity_problem()` | The rejections |
| `apps/outreach/mail/compose.py` | `with_reply_line()`, `with_signature()` | What is added after generation |

### The two email modes — IMPLEMENTED

**Source:** `apps/ai/styles.py`

| Key | Label | Enforced band |
| --- | --- | --- |
| `consultative` | Website audit — consultative | 210–560 words |
| `brief` | Website audit — brief | 80–175 words |

`DEFAULT_STYLE = CONSULTATIVE`. Selected per campaign via `template_key` on
`AutomationPlan`.

The word bands are wider than what the prompt asks for, deliberately: the `Style`
docstring says it plainly — "a 240-word email when 250 was requested is a good email, and
regenerating it costs a provider call to fix nothing a reader would notice. The prompt
aims; the check catches the drafts that missed by enough to matter."

`Style.length_rule` becomes rule 6 of the system prompt, substituted into
`LENGTH_SLOT` by `system_for()`.

### The flow

```
EmailDraft (has findings, signals, observation, business_summary)
   ↓
prompts.build_prompt(
      business_name, category, city, country, website,
      observation, findings, signals, pages,
      sender_name, sender_company, sender_email, service_pitch)
   ↓  _signals_block(signals)   the measured facts
   ↓  _pages_block(pages)       page extracts, capped at CONTEXT_BUDGET (9000 chars)
   ↓
client._complete(system=system_for(style), prompt=..., schema=schema_for(style),
                 max_tokens=EMAIL_MAX_TOKENS)     # default 1200
   ↓
parsing.parse(text) -> GeneratedEmail(subject, body, observation, finding_ids)
   ↓
validation.style_problem(email, style)          too long / too short?
validation.draft_problem(email, findings)       banned phrases, flattery, shouting?
validation.specificity_problem(email, findings) vague, or invented numbers?
   ↓  any problem -> rejected; pipeline._call_ai() may retry once
   ↓
EmailDraft.subject / .body / .observation / status = generated
   ↓  (only at send time)
compose.with_signature(body, account.signature)
compose.with_reply_line(body)      appends REPLY_LINE
compose.build_message(...)         headers
```

### Personalisation — what makes it specific

The prompt carries, per lead: the business name, its category, its city and country, the
**observation** (a short phrase drawn from the site — e.g. "wood-fired pizza since
1998"), the findings with their evidence, and page extracts. `finding_ids` comes back in
the response, so the email is traceable to exactly which findings it used.

`MAX_FINDINGS = 10` caps how many findings are offered; the model chooses which to lead
with, and `finding_ids` records the choice.

### The no-website variant — IMPLEMENTED

For a lead with no site (`analysis_status = no_website`), `build_no_website_prompt()` and
`NO_WEBSITE_SYSTEM` are used instead, with `NO_WEBSITE_SCHEMA`. It makes no claim about a
website, because there is none to claim anything about — it talks about the opportunity
instead. `scoring.classify()` produces `no_website_opportunity` for this case.

### Anti-spam rules — where each lives

| Rule | Where enforced |
| --- | --- |
| No banned phrases | `validation.BANNED_PHRASES`, `BANNED_STEMS`, `_BANNED_PATTERN` |
| No flattery | `validation._FLATTERY` |
| No ALL-CAPS shouting | `validation._SHOUTING` + `_SHOUTING_ALLOWED` |
| No invented statistics | `validation.METRIC_PATTERNS`, `_METRIC_NUMBER` |
| No unhedged promises | `validation.GUARANTEE_PATTERNS`, `unhedged_benefit()`, `HEDGES` |
| Length band | `validation.style_problem()` against the `Style` |
| A reply invitation, always | `compose.REPLY_LINE` via `with_reply_line()` |
| `List-Unsubscribe` header | `compose.build_message()` |
| **No** `Auto-Submitted` header | `compose.build_message()` — deliberately not set; see the comment there |

`List-Unsubscribe` is set to `<mailto:SENDER?subject=unsubscribe>` — a real, working
opt-out route, and `inbox.asks_to_unsubscribe()` acts on replies matching it.

### Database involvement

Reads `EmailDraft` (findings, signals, observation) and `Campaign`
(`sender_name`, `sender_email`, `sender_company`, `service_pitch`). Writes
`EmailDraft.subject`, `.body`, `.observation`, `.status = generated`.

Signature and reply line are **not** stored on the draft — they are added by
`compose` at send time, so editing a mailbox signature changes future sends without
rewriting stored drafts.

### Error handling

A malformed response raises from `parsing.parse()`. A response that parses but fails
validation is rejected with a reason. `pipeline._call_ai()` retries once for a transient
failure. A repeatedly failing draft ends at `status = failed` with the reason on the row,
visible on the card — it does not silently disappear.

### How to debug

```bash
# The exact prompt for one draft
python manage.py shell -c "
from apps.outreach.models import EmailDraft
from apps.ai import prompts
d = EmailDraft.objects.filter(status='generated').first()
print(prompts.build_prompt(
    business_name=d.business_name, category=d.category, city=d.city,
    country=d.country, website=d.website, observation=d.observation,
    findings=d.finding_objects, signals={}, pages=None,
    sender_name=d.campaign.sender_name, sender_company=d.campaign.sender_company,
    sender_email=d.campaign.sender_email, service_pitch=d.campaign.service_pitch))"

# Why was a generated body rejected?
python manage.py shell -c "
from apps.ai import validation, base
from apps.outreach.models import EmailDraft
d = EmailDraft.objects.filter(status='generated').first()
email = base.GeneratedEmail(d.subject, d.body, d.observation, [])
print('style      :', validation.style_problem(email) or 'ok')
print('draft      :', validation.draft_problem(email, d.finding_objects) or 'ok')
print('specificity:', validation.specificity_problem(email, d.finding_objects) or 'ok')"
```

### How to safely modify it

- **Change the length band** → `apps/ai/styles.py`, the `Style`'s `min_words`/`max_words`
  **and** its `length_rule` (which is what the prompt says). Changing only one makes the
  prompt and the check disagree. Tests: `apps/ai/tests/test_email_style.py`.
- **A new style** → add a `Style` to `apps/ai/styles.py`, it joins `STYLES` automatically.
- **A new banned phrase** → `apps/ai/validation.py :: BANNED_PHRASES`.
- **Change what the reply line says** → `apps/outreach/mail/compose.py :: REPLY_LINE`.

### In simple words

It hands the AI everything it measured about one business plus the pitch, and asks for a
subject and a body in a fixed JSON shape. Then ordinary code checks the result: right
length, no spam phrases, no flattery, no made-up statistics, no promises without a hedge.
The signature and the "just reply to this email" line are added at the last moment, not
baked into the draft.

---

# 12. Email Sending

### What is it?

The one place a message is handed to an SMTP server.

### Where is the code?

| File | Class / Function | Purpose |
| --- | --- | --- |
| `apps/outreach/mail/transport.py` | `Session` | An authenticated SMTP connection for one run |
| `apps/outreach/mail/transport.py` | **`Session.send()`** | **The actual sending function** |
| `apps/outreach/mail/compose.py` | `build_message()` | Every header, in one funnel |
| `apps/outreach/mail/providers.py` | `Provider`, `PROVIDERS`, `provider_for()`, `resolve_host()` | Hosts, ports, pacing, caps |
| `apps/outreach/mail/providers.py` | `normalise_password()` | Strips the spaces out of a Gmail app password |
| `apps/outreach/mail/errors.py` | `SendError` | The shared failure type (re-exported from `transport`) |
| `apps/outreach/mail/accounts.py` | `sending_accounts()`, `daily_cap()`, `remaining_today()` | Which mailbox may send, and how much |
| `apps/outreach/mail/inbox.py` | `check()`, `Inbox`, `Matcher`, `apply()` | Reading replies and bounces |
| `apps/outreach/mail/auditsend.py` | `send()` | Sending one submitted-URL audit, after approval |
| `apps/outreach/services/history.py` | `reserve()` | The insert-before-send that prevents duplicates |
| `apps/outreach/services/automation/courier.py` | `Courier` | Sending inside an automation pass |

### The five providers

**Source:** `apps/outreach/mail/providers.py`

| Key | Delay between messages | Daily cap |
| --- | --- | --- |
| `gmail` (default) | 2.5s | 400 |
| … | 3.5s | 250 |
| … | 3.0s | 200 |
| … | 2.5s | 300 |
| `custom` | 3.0s | 200 |

Both numbers are set **below** each provider's published limit, because the published
limit is where they start refusing and a campaign that reaches it has already been
noticed. `resolve_host()` lets an account override host and port; `custom` requires them.

`normalise_password()` exists for Gmail: an app password is displayed as four groups of
four and pasted with the spaces in, which SMTP rejects. The regex is
`^[a-z]{4}(?:\s[a-z]{4}){3}$`.

### Authentication and the anti-spoofing refusal

`Session.__init__` refuses to construct if the visible sender is not the authenticated
address:

> "…the SMTP login (`{username}`). Sending as an address you have not authenticated is
> spoofing…"

And `compose.build_message()` has **no parameter** that could put a different address in
`From` — it is built from the authenticated `sender_email`. Spoofing is prevented
structurally, not by a check that could be forgotten.

### The headers, every one

**Source:** `apps/outreach/mail/compose.py :: build_message()`

| Header | Value |
| --- | --- |
| `From` | `formataddr((sender_name or sender_email, sender_email))` — always the login |
| `To` | the recipient |
| `Subject` | the draft's subject |
| `Date` | `formatdate(localtime=True)` |
| `Message-ID` | `make_msgid(domain=sender_email.split("@")[-1])` |
| `Reply-To` | only when it differs from the sender — a redundant one reads as a filter signal |
| `In-Reply-To` | the parent, for follow-ups |
| `References` | the chain; falls back to `in_reply_to` when there is no chain yet |
| `List-Unsubscribe` | `<mailto:SENDER?subject=unsubscribe>` |
| *(no* `Auto-Submitted`*)* | Deliberately absent. RFC 3834's `auto-generated` is for a machine replying to a machine; these are first contacts a person replies to, and some receivers read the header as "do not reply". Nothing here reads it. |

### `OUTREACH_BLOCK_SEND` — the safety switch

Enforced in four places:

| File | What it blocks |
| --- | --- |
| `apps/outreach/mail/transport.py` (line ~65) | Opening the SMTP connection at all |
| `apps/outreach/mail/inbox.py` (line ~428) | Opening the IMAP connection |
| `apps/outreach/mail/accounts.py` (line ~317) | The mailbox "Test connection" button |
| `apps/ai/views.py` (line ~81) | The AI credential live test |

It is **forced on under `manage.py test`**, and `apps/outreach/tests/test_mail.py ::
SendBlockTests` asserts that. Real credentials live in `.env`, and the line between a
failing test and mail leaving the building should not be a mock somebody forgot.

### The send flow

```
Person presses Send  (POST /outreach/<uuid>/send)
   ↓
apps/outreach/views/drafts.py :: send()
   ↓  _my_campaign()                         ownership
apps/outreach/services/pipeline.py           the send loop
   ↓  for each approved draft:
   │
   ├─ history.reserve(draft, sender_account=...)
   │     ↓ INSERT SentLead(status="sending", reserved_at=now)
   │     ↓ unique constraint decides: AlreadyContacted / DoNotContact -> skip
   │
   ├─ mail.accounts.sending_accounts(campaign)  -> usable mailboxes
   │     ↓ active, has a password, under its daily cap
   ├─ mail.accounts.remaining_today(account)    -> is there room
   │
   ├─ transport.Session(provider, sender_email, password)
   │     ↓ OUTREACH_BLOCK_SEND?  -> SendError, nothing opened
   │     ↓ SMTP_SSL or SMTP+STARTTLS, login
   │     ↓ Session.send(to_email=..., subject=..., body=..., sender_name=...)
   │           ↓ compose.build_message(...)
   │           ↓ smtp.send_message(message)
   │           ↓ returns message["Message-ID"]
   │
   ├─ SentLead.status = "sent", sent_at, sent_date, sent_time, message_id
   │     (or status = "failed" with error_message)
   │
   └─ sleep provider.delay  (+ plan.send_gap_seconds in an automation pass)
```

The **`Message-ID` is returned and stored** — it is what a reply quotes in
`In-Reply-To`/`References`, and it is the only reliable way to tie an incoming email back
to the one that was sent. Reply tracking works on that, not on a guess based on the
sender address.

### Bounce and unsubscribe handling

**Source:** `apps/outreach/mail/inbox.py`, read-only against IMAP

| Function | Purpose |
| --- | --- |
| `check(password=..., owner=..., days=...)` | The whole scan; returns `CheckResult` |
| `Inbox` | The IMAP connection |
| `Matcher` | Ties a message back to a `SentLead` via `Message-ID` then address |
| `message_ids()`, `sender_address()`, `plain_text()`, `new_text()` | Parsing |
| `looks_like_bounce()`, `is_permanent_bounce()` | Bounce detection |
| `asks_to_unsubscribe()` | Opt-out detection |
| `apply(verdict)` | Writes the outcome |
| `resolve_imap()` | Host and port for the provider |

`apply()` sets `SentLead.reply_state` to `replied`, `bounced` or `unsubscribed`, and an
unsubscribe **automatically adds a `Suppression`** — that is the one automatic write in
the whole inbox path, and it exists because an opt-out must take effect without waiting
for somebody to notice it.

`OUTREACH_INBOX_DAYS` bounds how far back a scan looks.

### Retry and logging

There is **no automatic retry of a send**. A failure sets `SentLead.status = failed` with
`error_message`, and the operator decides. That is deliberate: a retry loop against SMTP
is how one bad address becomes a reputation problem.

Per-recipient failures do not stop the loop — one bad address must not abandon a campaign.
Tested by `apps/outreach/tests/test_pipeline.py :: BulkSendTests`.

`CampaignEvent` rows record what happened, with 17 `kind` choices. Nothing logs a password.

### Security

- `From` cannot be anything but the authenticated address (structural).
- Passwords are encrypted at rest (`EmailAccount.secret`, Fernet) and masked (`hint`).
- `SendError` messages are written for a person and carry no credential.
- `OUTREACH_BLOCK_SEND` forced on in tests.
- Recipient addresses are validated — `mail/followups.py :: _valid()`,
  `views/shared.py :: _valid_email()`.

### How to debug

```bash
# Prove SMTP works without emailing anybody
python manage.py smtp_check

# Are there usable mailboxes for this campaign, and how much room is left?
python manage.py shell -c "
from apps.outreach.models import Campaign
from apps.outreach.mail import accounts
c = Campaign.objects.first()
print(accounts.selection_report(c))
for a in accounts.sending_accounts(c):
    print(f'  {a.sender_email}: cap={accounts.daily_cap(a)} '
          f'sent_today={accounts.sent_today(a)} left={accounts.remaining_today(a)}')"

# Why did one lead not send?
python manage.py shell -c "
from apps.outreach.models import EmailDraft
from apps.outreach.services import history
d = EmailDraft.objects.get(pk=123)
print(d.status, '|', history.blocked_reason(d))"

# Read the inbox once
python manage.py check_replies --user you@example.com --dry-run
```

If nothing sends and there is no error: check `OUTREACH_BLOCK_SEND` first. It is the
single most common cause.

### How to safely modify it

- **A new provider** → add a `Provider` to `providers.PROVIDERS`. Tests:
  `apps/outreach/tests/test_mailaccounts.py`.
- **A new header** → `compose.build_message()` only. Tests:
  `apps/outreach/tests/test_mail.py :: MessageTests`.
- **Change pacing** → the provider's `delay`, or `AutomationPlan.send_gap_seconds`.
- **Do not** add a parameter to `build_message()` that sets `From`.

### In simple words

One class opens an authenticated SMTP connection and one method sends a message. Before
anything is sent, a row is written claiming that address so nothing else can send to it.
The `From` line is always the mailbox that logged in — it is impossible to fake here. The
message id is saved so replies can be matched later. If sending is blocked by the safety
switch, no connection is even opened.

---
# 13. Email Limits and Safety

### What is it?

Everything that stops this tool becoming a spam cannon, whether by accident or by an
operator setting a number too high.

### Two different limits, often confused

| | Campaign target | Mailbox sending limit |
| --- | --- | --- |
| **What it is** | How many emails you *want* sent | How many the mailbox *may* send |
| **Where** | `AutomationPlan.daily_target`, `.total_target` | `providers.Provider.daily_cap`, `EmailAccount.daily_limit` |
| **Set by** | The operator, per campaign | The provider's policy, and optionally lowered per account |
| **If they conflict** | The mailbox wins, always | |

`AutomationForm` refuses a plan whose daily target the selected mailbox cannot meet:

> "…cannot be met, and the cap is not ours to raise."

That refusal is at form-validation time, so an impossible plan cannot be created — rather
than being created and then quietly under-delivering.

`accounts.daily_cap(account)` implements the precedence:

```python
preset = provider_of(account).daily_cap
if account.daily_limit and account.daily_limit < preset:
    return account.daily_limit
return preset
```

An account may lower its own cap. It cannot raise it above the provider preset.

### The actual limits

| Limit | Value | Where |
| --- | --- | --- |
| Daily cap per mailbox | 200–400 by provider | `mail/providers.py :: Provider.daily_cap` |
| Minimum delay between sends | 2.5–3.5s by provider | `mail/providers.py :: Provider.delay` |
| Extra delay, per plan | `send_gap_seconds`, default 0 | `AutomationPlan` |
| Leads per campaign | 300 | `views/shared.py :: MAX_LEADS_PER_CAMPAIGN` |
| Leads per search | 300 | `apps/leads/scraper.py :: MAX_LEADS` |
| Leads per automation pass | 25 | `automation/runner.py :: PASS_LIMIT` |
| Follow-ups prepared per pass | 5 | `automation/runner.py :: FOLLOWUP_LIMIT` |
| Follow-ups per lead | 2 | `OUTREACH_FOLLOWUP_MAX` |
| Follow-up delays (days) | `2,7` | `OUTREACH_FOLLOWUP_DELAYS` |
| Follow-up attempts | 3 | `services/followups.py :: MAX_ATTEMPTS` |
| Consecutive account failures | 3 | `automation/courier.py :: MAX_CONSECUTIVE_FAILURES` |
| Rate-limit pauses per campaign | 5 | `services/pipeline.py :: MAX_PAUSES` |
| Inbox scan window (days) | 45 | `OUTREACH_INBOX_DAYS` |

**There is no hourly limit.** Pacing is per-message delay plus the daily cap — status:
**NOT IMPLEMENTED** as a distinct hourly counter. A daily cap plus a 2.5-second floor
bounds the hourly rate implicitly, which is why one was never added.

**There is no maximum delay.** `send_gap_seconds` is an operator-set minimum addition, not
a randomised range — status: **NOT IMPLEMENTED**.

### Duplicate protection

Three layers, and only the last one is a guarantee:

1. **Visible** — `history.annotate_leads()` marks already-contacted leads in the table.
2. **Marked** — `history.mark_campaign_duplicates()` sets `EmailDraft.status = duplicate`
   for repeats inside one campaign.
3. **Enforced** — `history.reserve()` inserts a `SentLead` row **before** SMTP opens, and
   `UniqueConstraint one_live_send_per_email` decides. Two concurrent sends race; exactly
   one wins; the loser raises `AlreadyContacted` and skips.

Layers 1 and 2 are for the operator. Layer 3 is what makes it true.

`recontact` + `recontact_reason` + `UniqueConstraint one_recontact_per_email_per_campaign`
allow a deliberate second contact — once per campaign, recorded, and explicit.

### Suppression

**Source:** `apps/outreach/services/history.py`

`Suppression` rows carry either an email or a domain. `SuppressionIndex` loads the whole
list once per run and answers membership in memory, because it is consulted for every
lead. `history.suppress()` adds a row; `DoNotContact` is raised by `reserve()` when a
suppressed address is reached.

Four `reason` choices. The UI adds them from a lead card or the Suppressions screen; the
inbox scanner adds them automatically for an unsubscribe.

### Bounce protection

`inbox.looks_like_bounce()` and `is_permanent_bounce()` classify an incoming message;
`apply()` sets `SentLead.reply_state = bounced`. A bounced address is then excluded from
follow-ups by `mail/followups.py :: eligibility()`, whose `REASONS` table names each
refusal. A **permanent** bounce is the one that matters — a mailbox-full bounce is not a
reason to stop contacting somebody forever.

### Unsubscribe protection

Three things together:

1. Every message carries `List-Unsubscribe: <mailto:SENDER?subject=unsubscribe>`.
2. `inbox.asks_to_unsubscribe(text)` detects an opt-out reply.
3. `apply()` sets `reply_state = unsubscribed` **and adds a `Suppression`
   automatically** — the one automatic write in the inbox path, because an opt-out must
   take effect without waiting for somebody to notice it.

### Provider failure handling and account pause

**Source:** `apps/outreach/services/automation/courier.py`

```python
MAX_CONSECUTIVE_FAILURES = 3
class AccountUnavailable(RuntimeError): ...
class Courier: ...
```

The `Courier` counts consecutive failures for the mailbox it is using. At 3 it raises
`AccountUnavailable`, which halts the pass with a recorded reason rather than continuing
to hammer a mailbox that is refusing. Consecutive, not cumulative: three failures in a row
is a broken mailbox; three failures across a thousand sends is three bad addresses.

A campaign whose mailbox becomes unusable is halted by
`automation/runner.py :: _halt()` with a `Halt` reason, recorded as a `CampaignEvent`.

### Rate-limit pause (AI, not email)

`apps/outreach/services/pipeline.py` — `RateLimited` → `_park()` → `Campaign.phase =
paused_rate_limit` with `retry_at`, `pause_reason`, `pause_detail`, `pause_count`.
`_backoff()` grows the wait from `BACKOFF_BASE = 30.0` to `BACKOFF_CAP = 900.0`.
After `MAX_PAUSES = 5` the campaign stops rather than pausing forever. The workspace
offers **Resume now**.

### `OUTREACH_BLOCK_SEND`

The master off switch. Blocks SMTP and IMAP at four call sites (chapter 12), forced on
under `manage.py test`, and warned about loudly by `docker/entrypoint.sh` if set on a real
deployment — because it silently disables both sending and reply reading, which looks like
a bug for days.

### Database involvement

`SentLead` (the reservation and the constraints), `Suppression`, `EmailAccount`
(`daily_limit`), `AutomationDay` (`reserved`/`sent` per day, atomic reservation),
`AutomationPlan` (targets), `CampaignEvent` (why something did not happen).

### How to debug

```bash
# Everything about one address
python manage.py shell -c "
from apps.outreach.models import SentLead, Suppression
addr = 'someone@example.com'
for r in SentLead.objects.filter(email__iexact=addr):
    print(r.status, r.reply_state, r.reserved_at, r.sent_at, r.campaign_label)
print('suppressed:', Suppression.objects.filter(email__iexact=addr).exists())"

# Today's room, per mailbox
python manage.py shell -c "
from apps.outreach.models import EmailAccount
from apps.outreach.mail import accounts
for a in EmailAccount.objects.all():
    print(f'{a.sender_email:34} cap={accounts.daily_cap(a):4} '
          f'sent={accounts.sent_today(a):4} left={accounts.remaining_today(a):4}')"

# Why is a plan not sending?
python manage.py run_automation --dry-run
```

### In simple words

Two separate ceilings: how many you asked for, and how many the mailbox is allowed to
send. The mailbox always wins, and a plan asking for more than the mailbox can do is
refused when you create it. A row is written claiming each address before any email goes
out, so the same person cannot be emailed twice even by two workers at once. Unsubscribes
add themselves to the do-not-contact list. A mailbox that fails three times in a row is
stopped rather than hammered.

---

# 14. Campaign Engine

### What is it?

The lifecycle of one campaign: created, configured, running, paused, finished.

### Where is the code?

| File | Class / Function | Purpose |
| --- | --- | --- |
| `apps/outreach/services/campaigns.py` | `ALLOWED` | The legal status transitions |
| `apps/outreach/services/campaigns.py` | `set_status()` | The only way status changes |
| `apps/outreach/services/campaigns.py` | `controls()`, `CONTROLS`, `CONTROL_LABELS`, `CONTROL_HINTS` | Which buttons to offer |
| `apps/outreach/services/campaigns.py` | `dashboard()` | The figures a dashboard shows |
| `apps/outreach/services/campaigns.py` | `TransitionError` | An illegal transition |
| `apps/outreach/services/pipeline.py` | `start_pipeline()` | The per-lead run, in a thread |
| `apps/outreach/services/pipeline.py` | `is_running()`, `stalled()`, `mark_cancelled()` | Run state |
| `apps/outreach/views/campaigns.py` | `start`, `setup`, `run`, `resume`, `cancel`, `state`, `campaign_status`, `workspace`, `report` | The screens |
| `apps/outreach/services/automation/runner.py` | `run_plan()`, `due_plans()`, `claim()`, `claim_lead()` | Unattended running |

### The two state fields, again

- **`status`** — what the operator wants: `draft`, `scheduled`, `active`, `paused`,
  `completed`, `stopped`, `failed`.
- **`phase`** — what the pipeline is doing: `setup`, `crawling`, `analysing`,
  `generating`, `paused_rate_limit`, `cancel_requested`, `cancelled`, `review`,
  `sending`, `done`, `failed`.

### The transition table — IMPLEMENTED

**Source:** `apps/outreach/services/campaigns.py :: ALLOWED`

```
draft      -> scheduled
scheduled  -> draft, active, paused, stopped
active     -> draft, scheduled, paused, stopped, completed, failed
paused     -> active, scheduled, completed, failed
stopped    -> active, paused, scheduled, draft, failed
completed  -> active, paused          (reachable only from a campaign that ran)
failed     -> active, paused, scheduled
```

Two rules encoded here:

1. **Nothing that has started sending goes back to unstarted.** The one exception is
   un-scheduling (`scheduled -> draft`), which is a cancelled intention rather than a
   rollback.
2. **`completed` and `failed` are outcomes, not controls.** They are reachable only from a
   campaign that was actually running, which is why they have narrow inbound edges.

`set_status()` raises `TransitionError` for anything not in the table. `WORDING` gives each
transition a sentence the UI shows, so "Paused" explains what pausing actually did:

> "Active. New sends and follow-up preparation are allowed again, continuing from where it
> stopped — nothing already sent is repeated."

### Creation

```
POST /outreach/start   (selected leads from the search)
   ↓ views/campaigns.py :: start()
   ↓ MAX_LEADS_PER_CAMPAIGN = 300
Campaign(status=draft, phase=setup) + one EmailDraft per lead
   ↓
GET /outreach/<uuid>/setup   sender identity, pitch, mailboxes
   ↓ Campaign.sending_accounts (M2M)
POST /outreach/<uuid>/run
   ↓ pipeline.start_pipeline(campaign)
```

For an unattended campaign, `AutomationForm` creates the `Campaign` **and** its
`AutomationPlan` together — a plan is a campaign's unattended configuration, not a
separate object (`OneToOneField`).

### Running — the attended path

`pipeline.start_pipeline()` claims the campaign (`_claim()`, backed by the per-process
`_running` set) and spawns a daemon thread (`_spawn()`). The request returns immediately;
the workspace polls `GET /outreach/<uuid>/state`.

Per lead: crawl → measure → score → audit → generate → validate → store. `phase` moves
`crawling` → `analysing` → `generating` and `current_draft` / `current_step` say which
lead is in flight, so the progress panel reports something real rather than a percentage
somebody invented.

**One lead at a time, not batched by stage.** Asserted by
`apps/outreach/tests/test_pipeline.py :: SequentialPipelineTests`. The reason: a batch
that fails halfway leaves an inconsistent set, and a per-lead loop can be resumed at the
exact lead it stopped on.

### Pause, resume, stop, cancel

| Action | What happens |
| --- | --- |
| **Pause** | `set_status(paused)`. New sends and follow-up preparation stop. Nothing in flight is killed. |
| **Resume** | `set_status(active)`, and `POST /outreach/<uuid>/resume` restarts the thread from where it stopped. Leads already finished are skipped. |
| **Stop** | `set_status(stopped)`. |
| **Cancel** (mid-run) | `phase = cancel_requested`. `pipeline._check_cancel()` is consulted between steps and `crawler.analyse(should_stop=...)` before every request, so it stops within one page. `mark_cancelled()` then sets `phase = cancelled`. |

**Resume after a restart** — `stalled(campaign)` detects a campaign in a working phase with
no thread behind it (the server was restarted mid-run). The workspace offers Resume.
Tested by `apps/outreach/tests/test_resume.py`.

### Completion and targets

For an automation plan: `AutomationPlan.target_reached` compares `sent_total` against
`total_target`; `AutomationDay.remaining()` bounds the day.
`automation/runner.py :: _complete(plan, reason)` sets the campaign `completed` with
`completion_reason`. Halt reasons come from `_halt()`, each with a written sentence:

- "Paused: …", "Stopped by hand.", "Total target of N reached.",
  "No eligible businesses remaining.", "Pass limit of N lead(s) reached.",
  the schedule window's own reason.

`Halt(reason, complete=True)` distinguishes "done" from "not now".

### Timezone

**Source:** `apps/outreach/services/automation/schedule.py`

```python
DEFAULT_ZONE = "UTC"
LAST_MOMENT = dt.time(23, 59, 59)
```

`AutomationPlan.timezone_name` is a real IANA name, validated by `valid_zone()` and
loaded with `zoneinfo.ZoneInfo` via `zone()`. `now_local(plan)` and `local_date(plan)`
convert; `window(plan, day)` gives the day's open/close as aware datetimes; `state(plan)`
returns a `Window` saying whether it is open and why not if not; `next_open()` and
`tomorrow_open()` say when it will be; `describe(plan)` renders it for the UI.

The daily target is counted **in the plan's timezone**, not the server's — which is the
whole reason `AutomationDay.day` is a `DateField` keyed on `local_date()`.

### Lead selection

Attended: every `EmailDraft` in the campaign, in order.

Unattended: `automation/runner.py :: claim_lead(plan)` — a conditional `UPDATE` on
`EmailDraft.claimed_by` over the `draft_claimable_idx` index, so exactly one worker gets
each lead. `unclaim()` releases it. `apps/outreach/services/automation/leads.py` keeps the pool topped up:
`ensure_searches()`, `claim_search()`, `fill()`, `top_up()`, `pool_size()`,
`searches_left()`, `exhausted()`, with `SEARCH_SIZE = 60` and `LOW_WATER = 5`.

### Database involvement

`Campaign`, `EmailDraft`, `CampaignEvent` (17 event kinds), `AutomationPlan`,
`AutomationDay`, `ProspectSearch`, `SentLead`.

### Error handling

A per-lead failure sets that draft `failed` with a reason and the loop continues. A
campaign-level failure sets `Campaign.status = failed` with `error`. A rate limit pauses
rather than fails. A worker that dies leaves a lease that expires (`LEASE_SECONDS = 600`)
and a claim that is released on the next pass — `test_automation.py ::
test_a_lead_is_never_left_claimed_by_a_dead_pass` covers exactly this.

### How to debug

```bash
# What state is it in, really?
python manage.py shell -c "
from apps.outreach.models import Campaign
from apps.outreach.services import campaigns, pipeline
c = Campaign.objects.first()
print('status:', c.status, '| phase:', c.phase, '| note:', c.status_note)
print('may_send:', c.may_send, '| may_follow_up:', c.may_follow_up)
print('running in this process:', pipeline.is_running(c.id))
print('stalled:', pipeline.stalled(c) or 'no')
print('controls offered:', [x['action'] for x in campaigns.controls(c)])
print('dashboard:', campaigns.dashboard(c))"

# The event log — why did it stop?
python manage.py shell -c "
from apps.outreach.models import Campaign
from apps.outreach.services.automation import events
c = Campaign.objects.first()
for e in events.recent(c, limit=20):
    print(f'{e.created_at:%m-%d %H:%M} {e.kind:18} {e.message[:70]}')"

# One pass, deciding nothing
python manage.py run_automation --dry-run
python manage.py run_automation --campaign <uuid> --limit 1
```

### How to safely modify it

- **A new status** → `Campaign.Status`, then `ALLOWED`, `WORDING`, `CONTROLS`. All four,
  or the UI will offer a button that raises. Tests:
  `apps/outreach/tests/test_campaign_ops.py :: CampaignStatusTests`.
- **A new halt reason** → `automation/runner.py :: _halt()`. Give it a sentence.
- **Change the pass size** → `PASS_LIMIT` in `apps/outreach/services/automation/runner.py`.

### In simple words

A campaign has two states: what you want (active, paused, stopped) and what it is doing
right now (crawling, generating, sending). Only certain moves between them are legal, and
a table says which. Running happens one lead at a time in a background thread, so a
restart loses at most one lead and the page offers Resume. For unattended campaigns a
schedule in your own timezone decides when it may run, and a daily counter in that
timezone decides when it has done enough for today.

---
# 15. Cron / Background Automation

### Why cron, and why not Celery

**This project has no Celery, no Redis, no broker and no result backend.** That is a
decision, not an omission — status: **IMPLEMENTED as cron + threads**.

The reasoning, which the code and docs both state:

| | Cron + threads (what this is) | Celery + Redis |
| --- | --- | --- |
| Things to run | 1 (the web process) | 3 (web, worker, broker) |
| Things to monitor | 1 | 3 |
| Things that can be down | 1 | 3 |
| Job latency | minutes | milliseconds |
| Latency actually needed | **minutes** | — |
| Restart semantics | a process exits; cron starts the next one | requeue, visibility timeout, acks-late |
| Debugging a failed job | read a log file | inspect a queue |

The jobs here are *minutes* apart, not milliseconds. A campaign that starts within five
minutes of its window opening is indistinguishable from one that starts instantly. A broker
would be a second thing to run, monitor, restart and secure for no benefit at this size —
and it is the second thing that breaks at 3am.

**What the choice costs**, stated honestly:

- No sub-minute latency. Nothing here needs it.
- No retry-with-backoff *framework*. The project implements its own where it matters
  (`_backoff()` in `pipeline.py`, `attempts` on `FollowUp` and `ProspectSearch`).
- No distributed fan-out. One box, one worker at a time per campaign — which the
  `_running` set and the plan lease already assume.
- **One worker per Gunicorn process, deliberately** — `pipeline._running` is a
  *per-process* set, so two Gunicorn workers could both start a job for the same campaign.
  `DEPLOY.md` says to run exactly one worker and scale with threads. This is the sharpest
  limitation of the design.

### The two background shapes

**1. Cron / a timer** — a process starts, does one pass, exits.

**2. A daemon thread in the web process** — for Run, Resume, and the `--loop` command
modes. `pipeline._spawn()` and `websiteaudit.start_in_background()`.

Both call the same services. There is no code that only runs in one shape.

### The commands

**Source:** `apps/outreach/management/commands/`

| Command | What it does | Sends email? |
| --- | --- | --- |
| `run_automation` | One pass over every plan inside its window | **Yes** — the only job that does |
| `run_audits` | Works the submitted-URL queue | No |
| `process_followups` | Drafts follow-ups that are due | No |
| `check_replies` | Reads IMAP for replies and bounces | No (read-only) |
| `ai_status` | Which provider and credential are active | No |
| `smtp_check` | Verifies SMTP without emailing anybody | No |
| `claim_data` | Assigns pre-accounts rows to an account | No |
| `db_transfer` | Copies SQLite → Postgres, verifies, resets sequences | No |

`apps/outreach/tasks.py` holds the three unattended jobs as plain callables —
`prepare_followups()`, `run_audits()`, `check_replies()` — so a command, a thread or a
test can reach them without instantiating a `BaseCommand`. That existed because the
automation runner used to do exactly that, which is what motivated extracting
`apps/outreach/services/followups.py`.

### The schedule — from DEPLOY.md §12

```cron
# Replies and bounces, every 30 minutes
*/30 * * * * /opt/leadmapper/bin/manage check_replies --user you@example.com >> /var/log/leadmapper-replies.log 2>&1

# Automation campaigns, every 5 minutes. Cheap when nothing is due.
*/5 * * * * /opt/leadmapper/bin/manage run_automation >> /var/log/leadmapper-automation.log 2>&1

# Submitted website audits, every 2 minutes
*/2 * * * * /opt/leadmapper/bin/manage run_audits >> /var/log/leadmapper-audits.log 2>&1

# Follow-ups that have come due, hourly. Drafts only; nothing is sent.
7 * * * * /opt/leadmapper/bin/manage process_followups --limit 50 >> /var/log/leadmapper-followups.log 2>&1
```

Under Docker every line becomes `docker compose exec -T web python manage.py <cmd>`.

`/opt/leadmapper/bin/manage` is a wrapper that sources `.env` **and exports
`DJANGO_SETTINGS_MODULE=config.settings.production`** — without that, `manage.py` defaults
to development settings on the server.

### Campaign selection

`automation/runner.py :: due_plans(owner=None)` returns the plans worth looking at. Each
pass then, per plan:

```
claim(plan, worker_id(), seconds=LEASE_SECONDS)     conditional UPDATE on the lease
   ↓ lost the race?  -> skip, silently, this is normal
_halt(plan, ...)                                    should it run at all?
   ↓ status paused/stopped? window closed? target reached? no mailbox?
   ↓ no eligible leads?                             -> Halt(reason, complete=?)
leads.top_up(plan)                                  keep the pool above LOW_WATER
_work(plan, report, limit=PASS_LIMIT)
   ↓ loop up to 25 leads:
   │   claim_lead(plan)                             conditional UPDATE on claimed_by
   │   AutomationDay.reserve()                      atomic daily-slot reservation
   │   process.eligibility(plan, draft)             suppression, reply, no-email, filters
   │   process.process(plan, draft, courier)        reserve -> send -> record
   │   sleep(provider.delay + plan.send_gap_seconds)
   ↓ process.prepare_followups(plan, FOLLOWUP_LIMIT) drafts only
release(plan)
```

### Concurrency protection — four independent claims

| What | Mechanism | Function |
| --- | --- | --- |
| One worker per plan | Lease: `locked_by` + `locked_until`, conditional `UPDATE` | `runner.claim()` |
| One worker per lead | Conditional `UPDATE` on `claimed_by` | `runner.claim_lead()` |
| The daily target | Conditional `UPDATE` on `AutomationDay` | `AutomationDay.reserve()` |
| One send per address | `UniqueConstraint`, insert-before-send | `history.reserve()` |

**Overlap is safe.** If a pass takes longer than the cron interval, the next one starts
alongside it, finds every plan leased, every claimable lead claimed and every day slot
accounted for, does nothing and exits. Asserted by tests, not assumed.

A **lease, not a lock**: a worker killed mid-lead cannot release anything, so the next one
takes over after `LEASE_SECONDS = 600` rather than the campaign being stuck forever.

### `worker_id()`

`runner.worker_id()` and `websiteaudit.worker_id()` produce an identifier for whoever holds
a lease, so a stuck plan can be traced to a host and a process.

### Error handling

Per lead: caught, recorded as a `CampaignEvent`, the pass continues. Per plan: the lease
is released in a `finally`, so a crash does not strand it beyond the lease. A process that
dies entirely leaves leases that expire and claims that the next pass releases. Cron logs
stdout and stderr to the files above; `Report` (a dataclass in `runner.py`) is what the
command prints.

### How to debug

```bash
# What would happen, without doing it
python manage.py run_automation --dry-run

# One campaign, one lead
python manage.py run_automation --campaign <uuid> --limit 1

# Continuously, watching (the supervised shape)
python manage.py run_automation --loop --interval 60

# Which plans are due, and is anything leased?
python manage.py shell -c "
from apps.outreach.services.automation import runner
from apps.outreach.models import AutomationPlan
for p in AutomationPlan.objects.all():
    print(f'{p.name:26} locked_by={p.locked_by or \"-\":20} until={p.locked_until} '
          f'next_run={p.next_run_at}')
print('due now:', [p.name for p in runner.due_plans()])"

# Is a stale lease the problem?
python manage.py shell -c "
from django.utils import timezone
from apps.outreach.models import AutomationPlan
for p in AutomationPlan.objects.exclude(locked_by=''):
    print(p.name, 'expired' if p.locked_until and p.locked_until < timezone.now() else 'held')"
```

Cron running but nothing happening: check the wrapper exports
`DJANGO_SETTINGS_MODULE`, check `OUTREACH_BLOCK_SEND`, check the plan's window with
`schedule.describe(plan)`, and read the campaign's event log.

### How to safely modify it

- **A new background job** → a function in `apps/outreach/tasks.py` calling a service, and
  a thin command in `apps/outreach/management/commands/`. Do not put logic in the command.
- **A different interval** → the crontab. Nothing in the code assumes one.
- **Do not** introduce a broker without also removing the `_running` per-process
  assumption in `pipeline.py`.

### In simple words

There is no job queue. A timer runs a management command every few minutes; the command
does one pass and exits. If two run at once nothing breaks, because the database decides
who owns each plan and each lead. Only one of these jobs sends email, and it only sends
inside the schedule and targets you configured. The trade is that jobs happen within
minutes rather than instantly, which is fine, and that you must run exactly one Gunicorn
worker, which matters.

---

# 16. Follow-up System

### What is it?

The second and third email to somebody who did not reply.

### The rule that shapes everything here

**A follow-up is prepared by machine and sent by a person.** There is no code path from
the follow-up worker to SMTP.

### Where is the code?

| File | Class / Function | Purpose |
| --- | --- | --- |
| `apps/outreach/mail/followups.py` | `eligibility(lead, blocklist)` | **May this lead get one?** |
| `apps/outreach/mail/followups.py` | `Eligibility`, `REASONS` | The verdict and every refusal wording |
| `apps/outreach/mail/followups.py` | `delay_days(number)`, `max_followups()` | The waiting period |
| `apps/outreach/mail/followups.py` | `next_due(lead, number)` | When it becomes due |
| `apps/outreach/mail/followups.py` | `schedule_next(lead)` | Writes the `waiting` row at send time |
| `apps/outreach/mail/followups.py` | `blocklist_for(owner)` | The suppression index for a run |
| `apps/outreach/mail/followups.py` | `conversation(lead)`, `days_since()`, `reference_chain()` | Context for the AI, and threading |
| `apps/outreach/mail/followups.py` | `check_before_send(followup)`, `Blocked` | The last gate, at the moment of sending |
| `apps/outreach/services/followups.py` | `prepare_one(owner, lead, dry_run)` | Draft one. Sends nothing |
| `apps/outreach/services/followups.py` | `due_leads()`, `halted()`, `claim()`, `next_number()` | The worker's decisions |
| `apps/outreach/services/followups.py` | `write()`, `record_skip()`, `record_failure()` | Outcomes |
| `apps/outreach/services/followups.py` | `MAX_ATTEMPTS = 3`, `UNSPENT` | Bounds |
| `apps/outreach/views/followups.py` | `followups`, `followup_action`, `followup_create`, `check_inbox` | The screen |
| `apps/outreach/management/commands/process_followups.py` | `Command` | The cron entry point |
| `apps/ai/prompts.py` | `FOLLOWUP_SYSTEM`, `build_followup_prompt` | What the AI is asked |

### Eligibility

**Source:** `apps/outreach/mail/followups.py :: eligibility()` — shared by the worker **and**
the screen, so the page and the cron job cannot disagree about what "due" means.

`REASONS` is the table of refusals. A lead is not eligible if it has replied, bounced,
unsubscribed, been suppressed, has no valid address (`_valid()`), has reached
`max_followups()`, or the waiting period has not elapsed.

`services/followups.py :: halted()` adds the checks that belong to the campaign rather
than the lead:

- `campaign.may_follow_up` is False — note **`may_follow_up`, not `may_send`**: a
  *completed* campaign may not contact anybody new but still owes follow-ups to people it
  already emailed;
- no active sending account is available;
- one is already waiting to be reviewed (`record=False` — no row, because a row already
  says it);
- the last one failed `MAX_ATTEMPTS` times (`record=False`).

### The waiting period

```python
OUTREACH_FOLLOWUP_MAX    = 2        # follow-ups per lead
OUTREACH_FOLLOWUP_DELAYS = [2, 7]   # days before #1, then before #2
```

`delay_days(number)` reads the list and reuses the final value for numbers beyond it, so
`[2, 7]` with `max = 4` gives 2, 7, 7, 7. A mailbox may override both
(`EmailAccount.followup_delays`, `.followup_max`), as may a plan
(`AutomationPlan.followup_delay_days`, `.followup_max`).

`next_due()` measures from **the last thing actually sent**, not from the first email —
so a lead that got follow-up #1 waits from that, not from the original.

### Numbering, and why it is careful

`next_number(lead)` returns the lowest **unspent** number where one exists:

```python
UNSPENT = (FollowUp.Status.WAITING, FollowUp.Status.SKIPPED, FollowUp.Status.FAILED)
```

Stepping over an unspent row would strand it, and
`UniqueConstraint one_live_followup_per_number_per_lead` would then read every later
attempt at that number as "another worker has it" — forever, with nothing on screen to say
why. Otherwise it is one past the highest on record; a `cancelled` row is not on the
record, because cancelling frees the number deliberately.

### The claim

`services/followups.py :: claim()` — two routes to the same guarantee:

1. An unspent row is claimed by a **conditional `UPDATE`** into `processing`, which only
   the worker that observes it in that state can win.
2. With no such row, creation races on `UniqueConstraint (lead, number)` and exactly one
   insert succeeds.

Either way the database decides, not the timing. A reused row has its `skip_reason` and
`error_message` cleared, because a stale reason beside a fresh attempt reads as the
current one.

### The lifecycle

```
Email sent
   ↓  followups.schedule_next(lead)      -> FollowUp(status=waiting, scheduled_for=...)
   │
   ↓  time passes; delay_days elapses
cron: process_followups   (or an automation pass, FOLLOWUP_LIMIT=5)
   ↓  services/followups.due_leads(owner, limit)
   ↓  eligibility(lead) + halted(lead)
   ↓     refused -> record_skip() with a reason, or no row if one already says it
   ↓  claim(owner, lead, number)          -> status=processing, attempts += 1
   ↓  write(followup, lead)
   │     ai.follow_up(... conversation=followups.conversation(lead) ...)
   │     FollowUp.subject/.body set, in_reply_to, references
   ↓  status = DUE                        <-- STOPS HERE
   │
   │  ############  NOTHING SENDS IT  ############
   │
   ↓  a person opens /outreach/followups, reads it, may edit it
POST /outreach/followup/<pk>/send
   ↓  views/followups.py :: followup_action()
   ↓  followups.check_before_send(followup)   -> may raise Blocked
   ↓  transport.Session.send(...)
   ↓  status = sent, message_id stored
```

### `followup_autosend` — DISABLED, and stronger than documented

**Source:** `apps/outreach/models/automation.py`, line 117

```python
#: Present, always False, and refused by `clean()`. Unattended follow-up
#: sending is not implemented, and the field exists so the answer to "can this
#: be switched on?" is a visible no rather than a missing option somebody
#: adds by hand later.
followup_autosend = models.BooleanField(default=False)
```

**What it means:** unattended follow-up sending does not exist. The field is a deliberate,
visible "no" rather than a missing option.

**Where it is actually enforced** — three places, and a correction:

1. `apps/outreach/models/automation.py` — `default=False`.
2. `apps/outreach/forms.py` — `AutomationForm` has **no field** for it, and
   `plan_values()` hardcodes `"followup_autosend": False`. The module docstring calls it
   "the one rule that is not the user's to change".
3. **Nothing reads it.** Verified: no module in `apps/outreach/services/`, `apps/outreach/mail/` or `apps/outreach/views/` consults
   `followup_autosend` at all. The only path from a `FollowUp` to SMTP is
   `views/followups.py :: followup_action()`, reached by a person pressing Send.

⚠️ **Contradiction found.** The comment says "refused by `clean()`", but
`AutomationPlan` defines no `clean()` method — its methods are `__str__`, `sent_total`,
`remaining_total`, `target_reached`, `day`. The comment is wrong about the mechanism.

The *effect* is correct and in fact stronger than claimed: because the flag is never
consulted, setting it `True` in a shell would still not cause any follow-up to send. The
protection is structural (there is no code path) rather than conditional (a flag that is
checked). The comment should be corrected to say so — see chapter 32.

Tests: `apps/outreach/tests/test_automation.py` lines 551–552 assert the form has no field
and `plan_values()` returns `False`.

### Threading

`in_reply_to` = the original's `Message-ID`; `references` = `reference_chain(lead)`. So the
follow-up lands in the conversation the first email started rather than as a new thread —
which is both better for the recipient and better for deliverability.

### Database involvement

`FollowUp` (the row and its 10 statuses), `SentLead` (the parent, and `reply_state`),
`Suppression` (via `blocklist_for`), `EmailAccount` (`sender_account`, per-account
overrides), `Campaign` (`may_follow_up`).

### Error handling

`record_failure()` sets `status = failed` with a truncated message and bumps `attempts`.
The row stays `failed` rather than being deleted, because the next run reads `attempts` and
stops at `MAX_ATTEMPTS = 3` — which is what stops a broken lead consuming an AI call every
fifteen minutes forever.

`record_skip()` writes the reason **once per reason**: a campaign paused for a month should
not produce a thousand identical rows.

### How to debug

```bash
# What is due, and why is the rest not?
python manage.py process_followups --dry-run

# One lead's verdict, in full
python manage.py shell -c "
from apps.outreach.models import SentLead
from apps.outreach.mail import followups
from apps.outreach.services import followups as svc
lead = SentLead.objects.filter(status='sent').first()
b = followups.blocklist_for(lead.owner)
v = followups.eligibility(lead, blocklist=b)
print('eligible:', v.eligible, '| reason:', getattr(v, 'reason', ''))
print('halted  :', svc.halted(lead))
print('next #  :', svc.next_number(lead))
print('due at  :', followups.next_due(lead))
print('rows    :', list(lead.followups.values_list('number','status','skip_reason')))"
```

### How to safely modify it

- **A new refusal** → `mail/followups.py :: eligibility()` and its `REASONS` entry (a
  lead-level rule), or `services/followups.py :: halted()` (a campaign-level one). Tests:
  `apps/outreach/tests/test_followups.py :: EligibilityTests`.
- **Change the delays** → `OUTREACH_FOLLOWUP_DELAYS`, or per account/plan.
- **Enabling autosend** would mean writing a send path in the worker, a validated way to
  turn it on, and tests for every refusal. It is deliberately absent; do not switch on a
  flag and assume it works.

### In simple words

When an email is sent, a row is written saying "check back in two days". A background job
later drafts the follow-up, using the whole conversation so far so it does not repeat
itself, and then **stops**. It sits on the Follow-ups screen until you read it and press
Send. There is a flag called `followup_autosend` — it is always False, nothing reads it,
and unattended follow-up sending simply does not exist in this codebase.

---
# 17. Specific URL Audit

### What is it?

A person pastes one website address; the system crawls it, audits it, finds contact
details, drafts an email — and stops. Separate from campaign discovery: no OpenStreetMap
search, no lead list, one site.

Status: **IMPLEMENTED**. Email sending from it is **manual only**, by design.

### Why does it exist?

Two reasons. First, an operator often already knows who they want to approach and does not
need discovery. Second, it is the natural demo: paste a URL, get a real audit.

It is a separate workflow because it has a different risk profile — **the URL comes from a
form**, so the crawler must be defended against being pointed at the server's own network.
Campaign URLs come from OpenStreetMap.

### Where is the code?

| File | Class / Function | Purpose |
| --- | --- | --- |
| `apps/outreach/services/websiteaudit.py` | `SpecificWebsiteAuditService` | The whole workflow |
| | `.run()` | The pass: crawl → analyse → contacts → draft |
| | `._crawl(target)` | Crawl with the SSRF guard attached |
| | `._analyse(draft, result)` | Scores and findings |
| | `._contacts(draft, target)` | Harvest published contact details |
| | `._draft_for()`, `._business_name()` | Build the draft |
| | `._write_email(draft, contact)` | Generate the email |
| | `._state(...)`, `._fail(kind, message)` | Progress and failure |
| `apps/outreach/services/websiteaudit.py` | `create(owner, submitted)` | Make the `AuditJob` |
| | `claim(job, who, seconds)` | The job lease |
| | `run_job()`, `run_pending()` | One job, or the queue |
| | `start_in_background(job)` | The daemon thread for an immediate start |
| | `regenerate(job, hint)` | Rewrite the email |
| | `holder(owner)`, `HOLDER_CITY` | The synthetic campaign these drafts belong to |
| | `blocked_reason(job)` | Why sending is refused |
| `apps/auditing/safeurl.py` | `check()`, `guard()`, `normalise()`, `same_site()` | The SSRF boundary |
| `apps/outreach/mail/auditsend.py` | `send(job, account, sender_name)`, `SendRefused` | Sending, after approval |
| `apps/outreach/views/websiteaudit.py` | `audit_new`, `audit_list`, `audit_view`, `audit_state`, `audit_save`, `audit_regenerate`, `audit_retry`, `audit_send` | The screens |
| `apps/outreach/management/commands/run_audits.py` | `Command` | The cron entry point |

### The flow

```
Person pastes a URL at /outreach/audit/new
   ↓
views/websiteaudit.py :: audit_new()
   ↓
safeurl.normalise(raw)  then  safeurl.check(raw)        <-- refuses here, before anything
   ↓  -> Target(url, host, ...)
websiteaudit.create(owner, submitted)                  -> AuditJob(state=created)
   ↓
websiteaudit.start_in_background(job)                  daemon thread; the page returns
   │  (or the cron job picks it up: run_audits -> run_pending -> claim -> run_job)
   ↓
SpecificWebsiteAuditService.run()
   ↓  _state(CRAWLING)
   ↓  _crawl(target)
   │     crawler.analyse(url, guard=safeurl.guard, progress=...)
   │        every request AND every redirect hop passes the guard
   │        contacts.harvest_page() runs on each page while its HTML is in memory
   ↓  _state(ANALYZING)
   ↓  _analyse(draft, result)      measurements -> scoring -> ai.audit() -> findings
   ↓  _state(CONTACTS_FOUND)
   ↓  _contacts(draft, target)     the shortlist of published addresses
   ↓  _state(DRAFT_READY, "Writing the email…")
   ↓  _write_email(draft, contact)  ai.generate() -> validation
   ↓
AuditJob.state = READY_FOR_REVIEW                       <-- STOPS HERE
   │
   │  ##########  NOTHING SENDS IT  ##########
   │
   ↓  person opens /outreach/audit/<pk>
   ↓  reads the report, may edit (audit_save) or regenerate (audit_regenerate)
POST /outreach/audit/<pk>/send
   ↓  auditsend.send(job, account, sender_name)
   ↓     eight separate refusals — see below
   ↓  transport.Session.send(...)
   ↓  AuditJob.state = SENT
```

The nine states: `created`, `queued`, `crawling`, `analyzing`, `contacts_found`,
`draft_ready`, `ready_for_review`, `sent`, `failed`. `ready_for_review` is terminal as far
as every automated path is concerned.

### Why the drafts need a campaign

`EmailDraft` requires a `Campaign`. So `holder(owner)` returns a synthetic campaign with
`city = HOLDER_CITY = "Website audits"` — one per owner — that these drafts belong to. It
keeps the model unchanged and keeps submitted-URL audits out of the real campaign lists.

### Sending is refused eight ways

**Source:** `apps/outreach/mail/auditsend.py :: send()`, each raising `SendRefused`

1. `blocked_reason(job)` returns something (wrong state, already sent, …).
2. The job is not in a sendable state.
3. The account is switched off.
4. No password is stored for the account.
5. The account is otherwise unusable.
6. There is no email draft to send.
7. No usable password after normalisation.
8. SMTP itself refused (wrapped).

Tested by `apps/outreach/tests/test_websiteaudit.py :: SendRefusalTests`, whose docstring
notes that `auditsend.send` "refuses on its own, not only through the view" — so calling
it from a shell is as safe as clicking.

### SSRF protection — the detail

**Source:** `apps/auditing/safeurl.py`

```python
ALLOWED_SCHEMES = ("http", "https")
ALLOWED_PORTS   = (80, 443)
BLOCKED_HOSTS    = ("localhost", "localhost.localdomain", "ip6-localhost", ...)
BLOCKED_SUFFIXES = (".local", ".internal", ".localdomain", ".home.arpa", ...)
```

`check(raw, resolve=True)` refuses, in order:

| Refusal | Why |
| --- | --- |
| Empty | "Enter a website address." |
| Scheme not `http`/`https` | `file://`, `gopher://`, `data:` |
| Credentials in the URL | Including `http://real.com@evil.com/`, which **a person reads as `real.com`** |
| No host | Malformed |
| Invalid port, or a port outside `ALLOWED_PORTS` | Non-web ports reach internal services |
| Host in `BLOCKED_HOSTS` or ending in `BLOCKED_SUFFIXES` | Loopback and internal names |
| An IP literal in a private/reserved range | `_as_ip()` → `_refuse_private()` |
| A hostname that **resolves** into one | `_resolved()` → `_refuse_private()` — DNS rebinding |
| No dot and not an IP literal | A bare word is not a public host |
| `_ODD_HOST` — `0x7f000001`, `2130706433` | Decimal and hex encodings of `127.0.0.1` |

`guard(url)` is the callable handed to `crawler.analyse(guard=...)`. It runs on the initial
URL **and every redirect hop** — because a public site is allowed to answer
`302 Location: http://169.254.169.254/`, and following that reads cloud metadata. That is
the attack this defends against, and checking only the submitted URL would miss it
entirely.

`same_site(url, site)` keeps the crawl on the submitted host.
`TRACKING_PARAMS` are stripped by `normalise()` so `?utm_source=…` does not create
distinct URLs for one page.

19 tests: `apps/auditing/tests/test_safeurl.py`. Redirect-time enforcement is tested
separately in `apps/outreach/tests/test_websiteaudit.py :: RedirectTests`, because it
needs a crawl to exercise.

### Database involvement

`AuditJob` (the queue and its states), `EmailDraft` (the audit result and the email),
`Campaign` (the synthetic holder), `WebsiteAudit` (the per-domain cache),
`EmailAccount` (which mailbox sends it), `SentLead` (only once actually sent).

### Error handling

`_fail(kind, message)` sets `state = FAILED` with a sentence and returns an `Outcome`.
`audit_retry` lets a person try again. A crawl that is `BLOCKED` (robots, bot wall, or the
guard) is not a crash — the job records why, and the report says the site could not be
read rather than inventing findings about it.

`_run_and_close()` wraps the background thread so a failure still releases the lease.

### Security

The whole SSRF section above, plus: the audit report and the draft are owned
(`AuditJob.owner`), the view re-reads by owner, and no submitted URL is ever echoed into a
page without escaping. Sending needs an explicit click and passes eight refusals.

### How to debug

```bash
# Would this URL even be accepted?
python manage.py shell -c "
from apps.auditing import safeurl
for raw in ('https://example.com', 'http://127.0.0.1', 'https://real.com@evil.com',
            'http://169.254.169.254', 'https://example.com:8080'):
    try: print('ok     ', raw, '->', safeurl.check(raw).url)
    except Exception as exc: print('refused', raw, '->', exc)"

# Run one job in the foreground and watch it
python manage.py run_audits --job 7

# The queue
python manage.py shell -c "
from apps.outreach.models import AuditJob
for j in AuditJob.objects.order_by('-created_at')[:10]:
    print(f'{j.pk:4} {j.state:18} {j.submitted[:44]:44} {j.detail[:40]}')"

# Why can't it be sent?
python manage.py shell -c "
from apps.outreach.models import AuditJob
from apps.outreach.services import websiteaudit
j = AuditJob.objects.get(pk=7)
print(j.state, '|', websiteaudit.blocked_reason(j) or 'sendable')"
```

### How to safely modify it

- **A new refusal on the URL** → `apps/auditing/safeurl.py :: check()`. Tests:
  `apps/auditing/tests/test_safeurl.py`.
- **A new stage** → `AuditJob.State`, then a `_state()` call in
  `SpecificWebsiteAuditService.run()`. Tests: `test_websiteaudit.py :: JobTests`.
- **A new send refusal** → `apps/outreach/mail/auditsend.py`. Tests: `SendRefusalTests`.
- **Do not** make this workflow send automatically. Multiple tests assert it does not.

### In simple words

You paste a website address. Before anything is fetched, the address is checked hard — no
private networks, no odd ports, no `user@host` tricks, and the check is repeated on every
redirect so a public site cannot bounce the crawler into your own network. Then it crawls,
audits, looks for a published email and writes a draft. Then it stops. You read it and
press Send, and even then eight separate checks have to pass.

---

# 18. Database Configuration

### What is it?

Which database this deployment stores everything in, and the Settings → Database page that
shows and changes it.

### The fact everything here follows from

**Django connects to Postgres directly.** `DATABASE_URL` carries the connection — host,
port, database, user and **the database password**. Supabase's URL, anon key and
service-role key are PostgREST API credentials; **they cannot open a Postgres connection.**

That is why the page stores those three *and* reports the database connection separately.
Presenting three API keys as if they were enough to switch database would fail at the first
request with an authentication error nobody could explain.

### Where is the code?

| File | Class / Function | Purpose |
| --- | --- | --- |
| `config/settings/base.py` | the `DATABASES` block, `_DB_SELECTION` | Assembles the connection |
| `apps/core/dburl.py` | `parse(url, conn_max_age)` | `DATABASE_URL` → a Django config dict |
| `apps/core/dburl.py` | `describe(config)` | A one-line summary **with no password in it** |
| `apps/core/dburl.py` | `is_postgres()`, `pooled()`, `DatabaseUrlError` | Classification |
| `apps/core/database.py` | `selection()`, `write_state()`, `read_state()`, `state_path()` | The stored choice |
| `apps/core/database.py` | `active()`, `active_description()`, `pending_restart()` | What is live right now |
| `apps/core/database.py` | `local_status()`, `supabase_status()`, `Status` | Is each usable |
| `apps/core/database.py` | `save_supabase()`, `validate_url()`, `supabase_config()` | The three fields |
| `apps/core/database.py` | `test_supabase()`, `test_local()`, `_test_postgres()`, `_test_rest()` | Connection tests |
| `apps/core/database.py` | `switch(target)`, `DatabaseSettingsError` | Recording a choice |
| `apps/core/secrets.py` | `encrypt()`, `decrypt()`, `mask()` | The keys at rest |
| `apps/core/views.py` | `database_view`, `database_state`, `supabase_save`, `connection_test`, `database_switch` | The five endpoints |
| `templates/core/database.html`, `static/js/database.js` | — | The page |
| `apps/outreach/management/commands/db_transfer.py` | `Command` | Copying data between databases |

### The local database — automatic, IMPLEMENTED

One SQLite file, `DATA_DIR / "outreach.sqlite3"`, with `OPTIONS = {"timeout": 20}` (the
worker thread writes while requests read). Django creates the file on first connection.

**There is nothing to configure and the page asks for nothing** — `local_status()` takes
no arguments. It reports:

- data directory missing → not ready;
- not writable → not ready;
- file absent → **ready**, "will be created automatically on first use";
- file present → ready, with how many migrations are applied.

It reads the migration count with `sqlite3` in `mode=ro` — because rendering a page must
not create or alter a database.

### Supabase — exactly three fields, IMPLEMENTED

| Field | Env var (wins if set) | Stored as |
| --- | --- | --- |
| Supabase URL | `SUPABASE_URL` | plain text |
| Anon / Public Key | `SUPABASE_PUBLISHABLE_KEY` | **encrypted** |
| Service Role / Secret Key | `SUPABASE_SECRET_KEY` | **encrypted** |

No host, port, database name, Postgres username, password or connection string is asked
for. Verified by a test that counts `<input>` elements in that section and asserts three.

`validate_url()` requires `https://` and a host ending `.supabase.co`, and refuses
credentials in the URL or a path. That is both a correctness check and an SSRF defence: the
server fetches this URL with a service-role key in the headers. Self-hosted Supabase
therefore cannot be configured through the UI — use the environment variables. Documented
limitation.

### Where the selection is stored, and why not in the database

`DATA_DIR / "database.json"`, mode 0600, written atomically (temp file + `os.replace`).

It **cannot** be a database row: the value being stored is *which database to open*, and
reading it from the database would need the answer first.

```json
{
  "selection": "local",
  "supabase": {
    "url": "https://abcdefgh.supabase.co",
    "anon_key": "gAAAAAB...",      <- Fernet ciphertext
    "service_key": "gAAAAAB..."   <- Fernet ciphertext
  }
}
```

### The three states, and why "no file" is its own state

```python
if os.environ.get("DATABASE_URL") and _DB_SELECTION != "local":
    DATABASES["default"] = _parse_database_url(os.environ["DATABASE_URL"], ...)
```

| Selection | `DATABASE_URL` set | Result |
| --- | --- | --- |
| *(no file)* | no | SQLite |
| *(no file)* | **yes** | **Postgres** — unchanged from before this page existed |
| `local` | yes | **SQLite** — the environment is deliberately ignored |
| `supabase` | yes | Postgres |
| `supabase` | no | SQLite, and the page refuses to record this |

**"No file" is not the same as "local selected".** That distinction is what makes deploying
this feature a no-op: a site already on Postgres has `DATABASE_URL` set and no selection
file, and it keeps using Postgres. Collapsing the two would have moved every Postgres
deployment onto SQLite.

The asymmetry is deliberate: choosing *local* overrides the environment (otherwise the
button does nothing on any deployment that would want it); choosing *Supabase* cannot
invent a connection.

A corrupt or unreadable state file reads as "no selection" rather than raising — it is read
while settings are being assembled, and it must not be the reason a deployment cannot
start.

### Switching — validate first, then record

`switch(target)`:

1. Target not in `("local", "supabase")` → refuse.
2. For Supabase: `supabase_status()` must be ready (needs `DATABASE_URL` **and** all three
   fields), then `test_supabase()` must pass.
3. For local: `local_status()` must be ready.
4. Only then is the file written.

**A failed check changes nothing** — the file is written after validation, not before. And
`switch()` is idempotent.

**Nothing is copied, moved or deleted.** A test strips comments and docstrings from
`apps/core/database.py` and asserts the code contains no `db_transfer`, `call_command`,
`TRUNCATE`, `DROP TABLE`, `.delete()` or `flush(`. Moving data is
`manage.py db_transfer`, a separate explicit command.

### A switch takes effect on restart — and why

`DATABASES` is read **once** when the process starts. Django's connection handling, the
session backend, the auth backend and the campaign worker *threads* all hold connections
derived from it. Swapping the default database under a running process — one that may have
a campaign mid-crawl in a daemon thread — would be a way to corrupt two databases at once.

So `switch()` records the choice and validates it; the process picks it up next start. The
page says so, `pending_restart()` drives a warning banner, and the returned message
includes "Nothing has been copied, moved or deleted".

After switching, run `manage.py migrate` if the target has no schema. The connection test
reports whether it does.

### The connection test — both halves

`test_supabase()` runs two independent checks and labels them:

**`_test_postgres()`** — parses `DATABASE_URL`, opens a real `psycopg` connection, runs
`SELECT 1`, then counts `django_migrations` to report whether the schema is there and up to
date. Driver errors are matched against `_POSTGRES_HINTS` and replaced with a sentence,
because a psycopg error can quote the whole DSN including the password. An unrecognised
error is replaced entirely rather than shown.

**`_test_rest()`** — `GET {url}/rest/v1/` with the anon key, then the service key.
`allow_redirects=False`, deliberately: the request carries a service-role key in a header
and must not hand it to another host.

### Cron behaviour

A cron job is a new process, so it reads the same `database.json` and the same
`DATABASE_URL`. There is no second place to configure and nothing to keep in step. The
selection is read from disk on every call — no module-level cache — so a long-running
`--loop` worker picks up a change on its next pass.

Proven by subprocess tests in `tests/integration/test_database_selection.py`, including
`CronTests`, which runs `manage.py` with a `DATABASE_URL` in its environment and `local`
selected, and asserts SQLite is what the command actually uses.

### Migrations

**This feature added no migrations and no models.** 24 migrations exist in total (23
outreach, 1 ai) and none of them relate to this page. `makemigrations --check --dry-run`
reports `No changes detected`.

The one migration worth knowing about is `apps/ai/migrations/0001_move_ai_credentials.py`:
it moved three credential models from `outreach` to `ai` using
`SeparateDatabaseAndState` with `db_table` pinned to `outreach_providercredential` etc.
**No data moved, no table was renamed**, and the Supabase row-level-security policies in
`sql/` that name those tables stay correct.

### Access control

**Staff only.** All five endpoints call `_require_staff()` first, raising
`PermissionDenied` (403) — not a redirect, because these are reached by `fetch()` as often
as by a person, and a redirect to a login page arrives at JavaScript as a 200 full of HTML.
The Settings-page card is wrapped in `{% if user.is_staff %}`, so no link is shown to
somebody who would get a 403.

**⚠️ Operational note:** an account created through the sign-up form does **not** have
`is_staff`, so on a fresh install the page is invisible to everybody. Grant it once:

```bash
python manage.py shell -c "from django.contrib.auth import get_user_model as m; \
  u = m().objects.get(email__iexact='you@example.com'); u.is_staff = True; \
  u.save(update_fields=['is_staff'])"
```

`is_staff` is the whole grant needed; `is_superuser` would additionally bypass every
permission check.

### Secret handling

Encrypted at rest with Fernet under a key derived from `DJANGO_SECRET_KEY`
(PBKDF2-HMAC-SHA256, 200,000 iterations, salt `outreach.credentials.v1` — **which must
never change**, or every stored secret becomes unreadable).

- **No endpoint returns a key.** The payload carries `anon_masked`, `service_masked`,
  `anon_set`, `service_set` — a mask and a boolean.
- An empty key field on save means "keep the stored one", so there is no round trip to
  preserve and therefore no reason to ever send one to a browser.
- **Nothing in `apps/core/database.py` or `apps/core/views.py` logs anything** — verified.
- The `.json` file is 0600.
- 42 UI tests assert this, including one that walks every response from all five endpoints
  on both success and failure paths, and one that checks the payload has no field *named*
  for a secret.

### Error handling

`DatabaseSettingsError` (a `UserFacingError`) carries a sentence written for the settings
page and documented to hold no key, password or connection string — which is why its
message goes straight into a JSON response. `connection_test` returns 200 whether or not
the test passed: the request succeeded and the answer is in the body.

### How to debug

```bash
# What is live, what is chosen, do they agree?
python manage.py shell -c "
from apps.core import database
print('active        :', database.active())
print('description   :', database.active_description())
print('selection     :', repr(database.selection()))
print('pending restart:', database.pending_restart())
print('state file    :', database.state_path(), database.state_path().exists())
print('local         :', database.local_status())
print('supabase      :', database.supabase_status())"

# Test the connection from the command line
python manage.py shell -c "
from apps.core import database
r = database.test_supabase()
print(r.ok, r.message)
for line in r.lines: print('  ', line)"

# Moving data — dry run first, always
python manage.py db_transfer --dry-run
python manage.py db_transfer --verify-only
```

If a server comes up on SQLite with `DATABASE_URL` set: look for `database.json` in the
data directory with `"selection": "local"`.

### How to safely modify it

- **A new database option** → `apps/core/database.py`: add to `CHOICES`, `label()`, a
  `..._status()`, a branch in `switch()`, and a branch in the `config/settings/base.py`
  block. Tests: `apps/core/tests/test_database.py`.
- **Do not** add a fourth Supabase field without checking whether it is genuinely needed —
  the three are the deliberate limit.
- **Never change** `apps/core/secrets.py :: SALT` or `ITERATIONS`.

### In simple words

Two choices: the local SQLite file, which needs no configuration at all, or Supabase. The
page stores your three Supabase keys encrypted and never shows them again. But the thing
that actually connects to Postgres is the `DATABASE_URL` environment variable, because that
is where the database password lives — the page says so and refuses to switch without it.
Choosing a database writes one small file and moves no data; it takes effect the next time
the app restarts.

---
# 19. Settings and Configuration

Every setting is read from the environment, in `config/settings/base.py`, via a private
`_load_env()` that reads `.env`. There is no `django-environ` dependency.

**Never put a real secret in a tracked file.** `.env` is git-ignored; `.env.example` is the
committed template with placeholders only.

### Django core

| Name | Location | Purpose | Default | Who changes it | Effect |
| --- | --- | --- | --- | --- | --- |
| `DJANGO_SECRET_KEY` | env → `base.py :: SECRET_KEY` | Signs sessions **and derives the encryption key for every stored secret** | none | operator, once | Changing it makes every saved AI key, mailbox password and Supabase key unreadable |
| `DJANGO_SETTINGS_MODULE` | env | Which settings module | `development` from `manage.py`, `production` from `wsgi.py`/`asgi.py` | operator / the image | Decides `DEBUG`, `ALLOWED_HOSTS`, cookie security |
| `DJANGO_ALLOWED_HOSTS` | env → `ALLOWED_HOSTS` | Host allowlist | `[]` in production, `["*"]` in development | operator | A missing host gives `400 Bad Request` |
| `DJANGO_DATA_DIR` | env → `DATA_DIR` | Where the database, media, exports and `database.json` live | `BASE_DIR` | operator / Docker (`/data`) | Moves all writable state |
| `DATABASE_URL` | env → `DATABASES` | The Postgres connection **including the password** | unset (SQLite) | operator | Moves the whole application onto Postgres |
| `DJANGO_CONN_MAX_AGE` | env | Postgres connection reuse, seconds | `600` | operator | `0` closes every connection |
| `SQLITE_SOURCE` | env → `DATABASES["sqlite_source"]` | The database `db_transfer` copies *from* | unset | operator, during a migration | Adds a second alias |
| `DJANGO_SSL_REDIRECT` | env → `production.py` | Force HTTPS | `0` | operator | `1` before a certificate exists breaks the site |
| `DJANGO_HSTS_SECONDS` | env → `production.py` | HSTS window | `0` | operator | Hard to undo — browsers remember |
| `DJANGO_TRUST_PROXY_TLS` | env → `production.py` | Trust `X-Forwarded-Proto` | unset | operator | Needed behind nginx/Caddy; without it, redirect loops |

### Email — sending

| Name | Purpose | Default | Read where |
| --- | --- | --- | --- |
| `OUTREACH_SENDER_EMAIL` | The default From address | — | `base.py`, the setup form |
| `OUTREACH_SENDER_NAME` | The default display name | — | `base.py` |
| `OUTREACH_SENDER_COMPANY` | Used in the prompt and the signature | — | `base.py` |
| `OUTREACH_PROVIDER` | Which mail provider preset | `gmail` | `apps/outreach/mail/providers.py` |
| `OUTREACH_SMTP_PASSWORD` | Mailbox password, for commands | — | `check_replies`, `smtp_check` |
| `OUTREACH_SMTP_HOST` / `_PORT` | Only for `provider=custom` | — | `mail/providers.py :: resolve_host()` |
| **`OUTREACH_BLOCK_SEND`** | **Blocks SMTP and IMAP entirely** | off; **forced on under `manage.py test`** | `transport.py`, `inbox.py`, `accounts.py`, `apps/ai/views.py` |

Per-provider `delay` and `daily_cap` are **not** environment variables — they are in
`apps/outreach/mail/providers.py` and a mailbox may only lower its cap via `EmailAccount.daily_limit`.

### Email — replies and follow-ups

| Name | Purpose | Default |
| --- | --- | --- |
| `OUTREACH_FOLLOWUP_MAX` | Follow-ups per lead | `2` |
| `OUTREACH_FOLLOWUP_DELAYS` | Days before each, comma-separated; the last value repeats | `2,7` |
| `OUTREACH_IMAP_HOST` / `_PORT` | Override the provider's IMAP | provider preset |
| `OUTREACH_INBOX_DAYS` | How far back a scan reads | `45` |

### AI

| Name | Purpose | Default |
| --- | --- | --- |
| `OUTREACH_AI_PROVIDER` | `claude`, `gemini`, `openai`, `openrouter`, `groq` | `claude` |
| `OUTREACH_AI_MODEL` | Override the provider's default model | the `Spec`'s `default_model` |
| `OUTREACH_AI_AUDIT_TOKENS` | Max tokens for a website review | `2600` |
| `OUTREACH_AI_EMAIL_TOKENS` | Max tokens for an email | `1200` |
| `OUTREACH_AI_FOLLOWUP_TOKENS` | Max tokens for a follow-up | see `prompts.py` |
| `OUTREACH_AI_CONTEXT_CHARS` | Characters of site text sent to the model | `9000` |
| `ANTHROPIC_API_KEY` / `ANTHROPIC_AUTH_TOKEN` | Claude key | — |
| `GEMINI_API_KEY` / `GOOGLE_API_KEY` | Gemini key | — |
| `OPENAI_API_KEY`, `OPENROUTER_API_KEY`, `GROQ_API_KEY` | the rest | — |
| `OUTREACH_CREDENTIALS_UI` | `0` disables editing AI keys in the browser | on |

An **active credential in the database takes priority** over the environment variable; with
none active it falls straight back to the env var.

### Crawler

All read through `crawler._tunable()`. Defaults in chapter 7's table.

`OUTREACH_CRAWL_TARGET_PAGES`, `_MAX_PAGES`, `_MAX_DEPTH`, `_MAX_BYTES`, `_TIMEOUT`,
`_DELAY`, `_RETRIES`, `_MAX_REDIRECTS`, `_ROBOTS_TTL`.

`OSM_CONTACT_EMAIL` — **required**, and search refuses to run with a placeholder. It goes
in the User-Agent so OpenStreetMap can identify this client, which their usage policy
requires.

### Scoring and audit

| Name | Purpose | Default |
| --- | --- | --- |
| `OUTREACH_PRIORITY_HOT` | Score at or above which a lead is "hot" | `80` |
| `OUTREACH_PRIORITY_WARM` | … "warm" | `60` |
| `OUTREACH_PRIORITY_LOW` | … "low" | `40` |
| `OUTREACH_READINESS_MIN` | Minimum readiness to be email-ready | `60` |
| `OUTREACH_AUDIT_MAX_AGE_DAYS` | How long a cached `WebsiteAudit` is reused | `30` |

### Supabase (API credentials, not the database connection)

| Name | Purpose | Also settable in the UI |
| --- | --- | --- |
| `SUPABASE_URL` | Project URL | yes |
| `SUPABASE_PUBLISHABLE_KEY` | Anon / public key | yes |
| `SUPABASE_SECRET_KEY` | Service role key — **bypasses row-level security** | yes |

Environment values **win** over UI-saved values, and the field goes read-only to say so.
None of the three is the database connection; see chapter 18.

### Docker only

`SITE_ADDRESS` (Caddy's hostname, or `:80`), `ACME_EMAIL` (Let's Encrypt notifications).

### Test-only

`LIVE_WEB_TESTS=1` enables `tests/e2e/`; `LIVE_OSM_TESTS` enables the live OSM tests.

### In simple words

Everything configurable is an environment variable in `.env`. Two matter more than the
rest: `DJANGO_SECRET_KEY`, because it encrypts every stored password and must never change,
and `OUTREACH_BLOCK_SEND`, because it silently stops all sending and reading — which is
what you want in tests and never what you want in production.

---

# 20. Security

Each threat, its protection, and the file that implements it.

### Authentication

```
Threat: an anonymous visitor reaching any page
   ↓
Protection: LoginRequiredMiddleware — deny by default
   ↓
config/settings/base.py :: MIDDLEWARE
apps/accounts/views.py  :: @login_not_required on login/signup/logout only
apps/accounts/backends.py :: the email-as-username backend
```

A view added later is protected without anybody remembering to protect it. Sessions:
`SESSION_COOKIE_HTTPONLY`, `SESSION_COOKIE_SAMESITE`, `SESSION_COOKIE_SECURE` (True in
base, relaxed in development because a Secure cookie is never sent over plain HTTP),
`SESSION_COOKIE_AGE`, `SESSION_SAVE_EVERY_REQUEST`. Password validators are Django's.
36 tests: `apps/outreach/tests/test_authorization.py`; 51 in `apps/accounts/tests.py`.

### Authorization

```
Threat: reading or changing another account's leads, drafts, mailboxes or keys
   ↓
Protection: every lookup is re-scoped to request.user; an id in a URL grants nothing
   ↓
apps/outreach/views/shared.py :: _my_campaign(), _my_draft(), _my_account()
apps/ai/views.py              :: every route re-reads the credential by owner
apps/core/views.py            :: _require_staff() on all five database endpoints
```

`_my_*` use `get_object_or_404(..., owner=request.user)`, so another account's object is
indistinguishable from one that does not exist.

Database settings are **staff-only** because they are global — they decide which database
everybody's data is in. That is the only privilege distinction in the project.

### CSRF

```
Threat: a third-party page making an authenticated state-changing request
   ↓
Protection: CsrfViewMiddleware + the token on every POST
   ↓
config/settings/base.py :: MIDDLEWARE, CSRF_COOKIE_SAMESITE, CSRF_COOKIE_SECURE
static/js/ui.js :: postJson() sends X-CSRFToken from the cookie
```

Every write endpoint is `@require_POST`; a GET to one returns 405. Asserted by
`apps/core/tests/test_database_ui.py :: test_the_write_endpoints_refuse_a_get`.

### SSRF and URL validation

```
Threat: a submitted URL pointing the server at its own network — cloud metadata,
        an internal admin panel, a database on localhost
   ↓
Protection: scheme, credential, port, hostname, IP-literal and resolved-IP checks,
            applied to the submitted URL AND every redirect hop
   ↓
apps/auditing/safeurl.py :: check(), guard(), _as_ip(), _refuse_private(), _resolved()
apps/auditing/crawler.py :: analyse(guard=...) -> _guard() before every request
apps/core/database.py    :: validate_url() for the Supabase URL
```

The redirect-hop check is the important half. A public site is allowed to answer
`302 Location: http://169.254.169.254/`, and validating only the initial URL would miss it.

`_ODD_HOST` catches `0x7f000001` and `2130706433`. Credentials in the URL are refused
including `http://real.com@evil.com/`, "which a person reads as real.com".

For the Supabase URL: `https://` and a `.supabase.co` host only, and the REST test uses
`allow_redirects=False` because the request carries a service-role key in a header.

19 tests in `apps/auditing/tests/test_safeurl.py`, plus `RedirectTests` in
`apps/outreach/tests/test_websiteaudit.py`.

### API keys, secrets and passwords

```
Threat: a stored credential read from the database, a log, a page or an error
   ↓
Protection: Fernet at rest; masks for display; no endpoint returns one; nothing logs one
   ↓
apps/core/secrets.py     :: encrypt(), decrypt(), mask(), SALT, ITERATIONS
apps/ai/credentials.py   :: the AI key pool; CredentialError carries no key
apps/outreach/mail/accounts.py :: EmailAccount.secret encrypted, .hint masked
apps/core/database.py    :: the Supabase keys, same treatment
```

- Fernet (AES-128-CBC + HMAC), key derived by PBKDF2-HMAC-SHA256, 200,000 iterations, salt
  `outreach.credentials.v1`.
- Derived rather than used directly, so learning `SECRET_KEY` is not the same as being able
  to read the stored keys.
- **Provider error text is never stored or shown** — it can quote the request, and the
  request carried the key. A category and a written phrase are kept instead.
- `_POSTGRES_HINTS` in `apps/core/database.py` does the same for psycopg errors, which can
  quote the DSN with the password in it. An unrecognised error is replaced entirely.
- `.env` is git-ignored (with `!.env.example` negated after `.env.*`); `database.json` is
  0600.

### SQL injection

```
Threat: user input reaching SQL
   ↓
Protection: the Django ORM everywhere; the one place raw SQL exists is parameterless
   ↓
apps/outreach/management/commands/db_transfer.py :: _reset_sequences()
```

No `.raw()`, no string-built `WHERE`. `db_transfer` uses `connection.cursor()` for sequence
resets, which take no user input. Filters, sorts and pagination all go through
`apps/outreach/selectors.py` with ORM lookups.

### XSS

```
Threat: business names, page titles and submitted URLs rendering as markup
   ↓
Protection: Django's autoescaping; JS escapes anything it injects
   ↓
templates/ — no |safe on user data
static/js/ui.js :: escapeHtml(), used by every innerHTML in the project
```

`static/js/database.js`, `credentials.js` and the others route every interpolated value
through `LMUI.escapeHtml()`. `XFrameOptionsMiddleware` sends `X-Frame-Options: DENY`
(clickjacking); `SECURE_CONTENT_TYPE_NOSNIFF` and `SECURE_REFERRER_POLICY` are set in
production.

### Email abuse

```
Threat: spoofing, spamming, contacting somebody who opted out, sending twice
   ↓
Protection: structural, not procedural
   ↓
mail/transport.py :: Session refuses if From != the authenticated login
mail/compose.py   :: build_message() has NO parameter that could change From
services/history.py :: reserve() — insert before send, unique constraint decides
models/history.py :: Suppression + the CheckConstraint that it must have a target
mail/inbox.py     :: asks_to_unsubscribe() -> apply() adds a Suppression automatically
mail/compose.py   :: List-Unsubscribe header on every message
mail/followups.py :: eligibility() — replied, bounced, unsubscribed, suppressed
services/followups.py :: a follow-up is never sent by any automated path
```

### Rate limits and provider limits

```
Threat: hammering OpenStreetMap, a website, or a mail provider until blocked
   ↓
Protection: enforced in code, below every published limit
   ↓
apps/leads/scraper.py    :: MIN_INTERVAL 1.1s for Nominatim, _throttle()
apps/auditing/crawler.py :: HOST_DELAY 1.0s, _throttle(host), MAX_ATTEMPTS 2
mail/providers.py        :: per-provider delay and daily_cap
automation/courier.py    :: MAX_CONSECUTIVE_FAILURES = 3 -> AccountUnavailable
services/pipeline.py     :: _backoff(), MAX_PAUSES = 5 on AI rate limits
```

**Nothing attempts to bypass a limit or an anti-bot control.** `BOT_WALL_MARKERS` in the
crawler *detects* a challenge page and abandons the crawl. There is no CAPTCHA solving, no
UA rotation, no fingerprint evasion. `robots.txt` is obeyed.

### Database access

```
Threat: credentials in a browser, privileged access from the frontend
   ↓
Protection: the connection string stays in the environment; RLS policies for Supabase
   ↓
config/settings/base.py :: DATABASE_URL read from env only
apps/core/dburl.py      :: describe() never includes the password
sql/                    :: row-level-security policies, applied by hand
apps/core/views.py      :: staff-only, and no endpoint returns a key
```

The Supabase service-role key bypasses RLS, which is exactly why it is encrypted, never
returned and never logged. There is **no client-side Supabase code in this project**, so
the publishable key has no browser consumer either.

### The test suite as a control

`OUTREACH_BLOCK_SEND` is forced on under `manage.py test`, and a test asserts it. Every AI
call and HTTP fetch in the suite is a double. The whole suite runs offline and costs
nothing — so a test cannot accidentally email a stranger or spend money.

### In simple words

Every page needs a login by default. Every object is re-read as yours before you can touch
it. Passwords and keys are encrypted with a key derived from the secret key, are shown only
as masks, and no endpoint hands one back. A submitted URL is checked hard before anything is
fetched, and re-checked on every redirect. The From line on an email cannot be faked
because there is no way to set it. And nothing here tries to get past a robots file, a rate
limit or a bot wall.

---
# 21. Error Handling

### The two philosophies, applied deliberately

| Approach | Where | Why |
| --- | --- | --- |
| **Never raise; return a status** | `crawler.analyse()` | A crawl failing is an ordinary outcome, not an exception |
| **Raise a user-facing error** | services, `apps/outreach/mail/`, `apps/core` | The caller must decide, and the message is shown |

`apps/core/exceptions.py :: UserFacingError` is the base for the second kind — inheriting
from it declares that the message is written for a person, names what to do, and contains
nothing secret.

### The exception types

| Exception | File | Raised when |
| --- | --- | --- |
| `UserFacingError` | `apps/core/exceptions.py` | Base for anything a person may read |
| `SecretError` | `apps/core/secrets.py` | A secret cannot be encrypted (no `SECRET_KEY`) |
| `DatabaseSettingsError` | `apps/core/database.py` | A database setting cannot be saved, tested or switched to |
| `DatabaseUrlError` | `apps/core/dburl.py` | `DATABASE_URL` is malformed |
| `AiError` | `apps/ai/base.py` | A provider failed, categorised |
| `CredentialError` | `apps/ai/credentials.py` | A credential is missing, unusable or undecryptable |
| `SendError` | `apps/outreach/mail/errors.py` | Anything wrong with sending |
| `AccountError`, `NoSendingAccount` | `apps/outreach/mail/accounts.py` | The mailbox is unusable |
| `InboxError` | `apps/outreach/mail/inbox.py` | IMAP could not be opened or read |
| `SendRefused` | `apps/outreach/mail/auditsend.py` | One of eight refusals on an audit send |
| `Blocked` | `apps/outreach/mail/followups.py` | A follow-up may not be sent now |
| `AlreadyContacted`, `DoNotContact` | `apps/outreach/services/history.py` | The reservation was refused |
| `Cancelled`, `RateLimited` | `apps/outreach/services/pipeline.py` | Control flow, not failure |
| `TransitionError` | `apps/outreach/services/campaigns.py` | An illegal status change |
| `ScheduleError` | `apps/outreach/services/automation/schedule.py` | An invalid window or timezone |
| `AccountUnavailable` | `apps/outreach/services/automation/courier.py` | 3 consecutive send failures |
| `ScrapeError` | `apps/leads/scraper.py` | OSM search failed |
| `UnsafeUrl`, `InvalidUrl` | `apps/auditing/safeurl.py` | A URL is refused |

### Website timeout / crawl failure

```
requests timeout, DNS failure, non-HTML, size cap exceeded
   ↓ crawler._fetch() retries up to MAX_ATTEMPTS = 2
   ↓ still failing
SiteAnalysis(status=FAILED, detail="…")          -- no exception raised
   ↓ SiteAnalysis.usable is False
   ↓ scoring.classify() -> "website_unverified"
   ↓ the email makes NO claim about the site
EmailDraft.analysis_status = failed; the card shows the detail
```

`robots.txt` refusal, a bot wall, or an SSRF guard refusal → `BLOCKED` instead of `FAILED`.
Both are statuses, never crashes. `crawler.analyse()` is documented "Never raises."

### AI failure

```
provider exception
   ↓ credentials.categorise(exc) -> (category, safe phrase)
   ↓ record_use(credential, success=False, category=..., detail=phrase)
   ↓
   ├─ category in FALLBACK_CATEGORIES and a spare is marked usable?
   │     -> retry once on the spare, for this request only
   │        (record_fallback either way; the active credential never changes)
   │
   └─ otherwise re-raise
        ↓ pipeline._call_ai()
        ├─ transient -> one retry after AI_RETRY_DELAY = 20.0s
        └─ RateLimited -> _park(campaign)
              Campaign.phase = paused_rate_limit, retry_at, pause_count += 1
              _backoff(): 30s growing to a 900s cap
              after MAX_PAUSES = 5 -> stop rather than pause forever
              the workspace offers "Resume now"
```

A response that parses but fails validation is not retried indefinitely — the draft ends
`failed` with the reason on the row.

### Email failure

```
Session.__enter__  -> SendError (blocked, auth refused, connection dropped)
Session.send       -> SendError
   ↓
SentLead.status = "failed", error_message set     -- the reservation row stays
   ↓
the loop CONTINUES to the next recipient
   ↓
CampaignEvent recorded
```

**No automatic retry of a send.** A retry loop against SMTP is how one bad address becomes a
reputation problem. Three consecutive failures on one mailbox → `AccountUnavailable` →
the pass halts with a recorded reason.

One bad address never abandons a campaign — `apps/outreach/tests/test_pipeline.py ::
BulkSendTests` asserts exactly this.

### Invalid email address

Caught at three points, each with a different consequence:

| Point | Function | Consequence |
| --- | --- | --- |
| Discovery | `contacts.py :: NEVER_WORDS`, `PLATFORM_DOMAINS` | Never becomes the draft's address |
| Draft | `EmailDraft.status = no_email` | Nothing is sent; the lead stays visible |
| Follow-up | `mail/followups.py :: _valid()` | Not eligible, with a reason |
| Form | `views/shared.py :: _valid_email()` | Rejected with a message |

### Database failure

`DatabaseUrlError` for a malformed `DATABASE_URL` is a **hard failure at startup**, not a
quiet fall back to SQLite — falling back would mean a production deployment writing to a
file nobody intended and discovering it later from the missing data.

A corrupt `database.json` is the opposite: read as "no selection" rather than raising,
because it is read while settings are being assembled and must not stop a deployment
starting.

SQLite locking under concurrent writes is handled by WAL mode (set by
`docker/entrypoint.sh`, and documented for manual installs) plus `OPTIONS = {"timeout": 20}`.

### Cron failure

A pass that dies leaves:

- a **plan lease** that expires after `LEASE_SECONDS = 600` — the next pass takes over;
- a **lead claim** that the next pass releases (`unclaim()`), tested by
  `test_a_lead_is_never_left_claimed_by_a_dead_pass`;
- a **`FollowUp` in `processing`** which is in `UNSPENT`, so the next run reclaims that
  number rather than stranding it.

Nothing needs manual repair. Cron's own stdout/stderr goes to the log files in DEPLOY.md
§12.

### Provider failure (the mail provider)

`SendError` with the provider's refusal turned into a sentence.
`accounts.test_connection()` is the diagnostic: it authenticates and reads the mailbox
without sending. `smtp_check` is the command version.

### What is deliberately caught broadly

Several `except Exception:  # noqa: BLE001` sites, each with a comment saying why:

| Where | Why |
| --- | --- |
| `crawler.analyse()` progress callback | "bookkeeping must not lose a crawl" |
| `crawler._robots_for()` | robots is best-effort |
| `apps/outreach/services/automation/process.py` per lead | "one lead, not the campaign" |
| `services/followups.py :: prepare_one()` | one lead's failure is recorded, not fatal |
| `config/settings/base.py` reading the selection | a file problem must not stop startup |
| `apps/core/database.py :: _migrations_on_disk()` | "a broken graph is not this page's problem" |

`BLE001` is not in the selected ruff rules, so those comments are documentation for the next
reader rather than suppression.

### In simple words

The crawler never crashes — it returns a status and a sentence. Everything else raises an
error whose message is safe to show, because it never contains a key or a password. A
failure on one lead is recorded and the loop moves on. A failed send is never retried
automatically. A dead background worker leaves nothing stuck, because every claim it held
expires on its own.

---

# 22. Testing

### The suite

```
python manage.py test
Ran 1642 tests in ~115s — OK (skipped=6)
```

**Nothing leaves the machine.** `OUTREACH_BLOCK_SEND` is forced on under `manage.py test`
(blocking SMTP *and* IMAP), and every AI call and HTTP fetch is a double. A test asserts
that the block is on. The 6 skips are the opt-in live tests.

### Where the tests are

Beside what they test, so the path to a test is the path to its subject.

| Location | Tests | Subject |
| --- | --- | --- |
| `apps/accounts/tests.py` | 51 | Sign-up, sign-in, sessions, protected routes |
| `apps/leads/tests.py` | 41 | The OSM query, CSV, contact guards |
| `apps/leads/test_places.py` | 39 | Countries, cities, validation |
| `apps/auditing/tests/test_crawler.py` | 31 | Discovery, sitemaps, the refusals |
| `apps/auditing/tests/test_measurements.py` | 26 | The signals an audit may cite |
| `apps/auditing/tests/test_safeurl.py` | 19 | SSRF refusals |
| `apps/ai/tests/test_credentials.py` | 143 | The credential store: encryption, masking, pool, ownership |
| `apps/ai/tests/test_evidence.py` | 48 | Evidence behind each claim |
| `apps/ai/tests/test_audit.py` | 46 | The audit and its rules |
| `apps/ai/tests/test_email_style.py` | 37 | Length, tone, banned wording |
| `apps/ai/tests/test_backends.py` | 32 | Each provider's transport and error mapping |
| `apps/ai/tests/test_prompts.py` | 25 | The prompts as text |
| `apps/ai/tests/test_provider_credentials.py` | 20 | Resolution order per provider |
| `apps/ai/tests/test_credential_ui.py` | 13 | The credential cards |
| `apps/ai/tests/test_parsing.py` | 12 | `ai.parse()` |
| `apps/outreach/tests/test_automation.py` | 157 | Unattended campaigns end to end |
| `apps/outreach/tests/test_websiteaudit.py` | 96 | The submitted-URL workflow |
| `apps/outreach/tests/test_intelligence.py` | 88 | Scoring, classification, lifecycle |
| `apps/outreach/tests/test_followups.py` | 82 | Eligibility, replies, bounces, threading |
| `apps/outreach/tests/test_campaign_ops.py` | 66 | Status transitions, the follow-up worker |
| `apps/outreach/tests/test_runcontrol.py` | 65 | Rate-limit pause, resume, cancel |
| `apps/outreach/tests/test_mailaccounts.py` | 63 | Mailboxes, limits, connection tests |
| `apps/outreach/tests/test_views.py` | 43 | The screens |
| `apps/outreach/tests/test_history.py` | 41 | Reservation, duplicates, export |
| `apps/outreach/tests/test_campaign_ui.py` | 38 | Sending-address and control UI |
| `apps/outreach/tests/test_authorization.py` | 36 | Cross-account isolation |
| `apps/outreach/tests/test_pipeline.py` | 35 | Crawl → review → generate → send |
| `apps/outreach/tests/test_platform.py` | 35 | Stack detection, replatform guards |
| `apps/outreach/tests/test_suppression.py` | 35 | Do-not-contact |
| `apps/outreach/tests/test_mail.py` | 23 | Compose, providers, the send block |
| `apps/outreach/tests/test_resume.py` | 19 | Picking up a dead run |
| `apps/core/tests/test_database.py` | 55 | The database selection module |
| `apps/core/tests/test_database_ui.py` | 42 | The page, the staff gate, secret leaks |
| `tests/integration/test_database_url.py` | 22 | `DATABASE_URL` parsing |
| `tests/integration/test_settings.py` | 9 | The `.env` loader |
| `tests/integration/test_database_selection.py` | 7 | Real subprocesses; cron behaviour |
| `tests/e2e/test_live_website.py` | 2 | One real website — opt-in, skipped |

### The categories, by kind rather than location

| Kind | Where |
| --- | --- |
| **Unit** | `test_measurements`, `test_safeurl`, `test_parsing`, `test_prompts`, most of `test_database` |
| **Model / constraint** | `test_history` (the reservation constraints), `test_campaign_ops` (transitions) |
| **Service** | `test_pipeline`, `test_automation`, `test_followups`, `test_intelligence` |
| **Crawler** | `apps/auditing/tests/` |
| **AI** | `apps/ai/tests/` — including that every backend maps its own errors |
| **Email** | `test_mail`, `test_mailaccounts`, `test_followups` |
| **Campaign** | `test_automation`, `test_campaign_ops`, `test_runcontrol`, `test_resume` |
| **Security** | `test_authorization` (36), `test_safeurl` (19), `test_database_ui` secret-leak group, `test_credentials` ownership group, `test_mail :: SendBlockTests` |
| **Integration** | `tests/integration/` — real files, real subprocesses, real environment |
| **E2E** | `tests/e2e/` — one real website, opt-in |

### Shared fixtures

| File | Provides |
| --- | --- |
| `apps/core/testing.py` | `SignedIn` (a `TestCase` with a session), `OtherUser`, `make_user()`, `default_user()`, `PASSWORD`, `EMAIL_BODY` |
| `apps/outreach/tests/factories.py` | `make_campaign()`, `make_draft()`, `FakeSession` |
| `apps/ai/tests/factories.py` | `make_findings()` |
| `apps/auditing/tests/factories.py` | `HTML_HOME`, `HTML_ABOUT`, `FakeResponse`, `fetched()` |

`SignedIn` hooks `_pre_setup`, which Django calls before `setUp` on every test regardless of
whether a subclass overrides `setUp` — doing it in `setUp` would silently skip any class
that defines its own without calling `super()`.

`make_campaign()` uses `default_user()` as the owner, so a fixture belongs to the account
driving `self.client` and ownership filtering behaves as it does in the application. A
fixture owned by somebody else would be filtered out of every page it appears on, and the
test would pass for the wrong reason.

### Commands

```bash
python manage.py test                    # everything, including tests/
python manage.py test apps.auditing      # the crawler and the measurements
python manage.py test apps.ai            # prompts, parsing, backends, credentials
python manage.py test apps.outreach      # campaigns, mail, follow-ups, the screens
python manage.py test apps.core          # the database selection
python manage.py test tests.integration  # settings, DATABASE_URL, cron behaviour

python manage.py test apps.auditing.tests.test_safeurl        # the SSRF refusals
python manage.py test apps.ai.tests.test_evidence             # evidence behind each email
python manage.py test apps.outreach.tests.test_runcontrol     # rate-limit pauses
python manage.py test apps.core.tests.test_database_ui        # secret-leak assertions

LIVE_WEB_TESTS=1 python manage.py test tests.e2e         # opt-in, needs a network
python manage.py test --parallel                              # faster; MD5 hashing is already on
python manage.py test -v 2                                    # per-test names
python manage.py test --failfast                              # stop at the first failure
```

### The full gate

```bash
ruff check .                                        # lint and import order
ruff check --fix .                                  # fix what is fixable
python manage.py check                              # Django system checks
python manage.py check --deploy                     # production settings
python manage.py makemigrations --check --dry-run   # no model drifted from a migration
python manage.py test
```

Verified at the time of writing: ruff clean, check clean, no migration drift, 1642 OK.
`check --deploy` reports 2 warnings — `SECURE_HSTS_SECONDS` and `SECURE_SSL_REDIRECT` — both
of which are documented opt-ins (chapter 19), not defects.

### Tests worth reading as documentation

| Test | What it pins down |
| --- | --- |
| `test_mail.py :: SendBlockTests` | The suite cannot open a real SMTP connection |
| `test_pipeline.py :: DoubleSendGuardTests` | The same lead is never emailed twice |
| `test_pipeline.py :: SequentialPipelineTests` | One lead at a time, never batched by stage |
| `test_pipeline.py :: BulkSendTests` | One bad address does not stop the loop |
| `test_automation.py :: FollowUpTests` | A follow-up is prepared and left for approval |
| `test_campaign_ops.py :: UnspentNumberTests` | A stranded follow-up number cannot happen |
| `test_websiteaudit.py :: SendRefusalTests` | `auditsend.send` refuses on its own |
| `test_websiteaudit.py :: NoEmailFoundTests` | Nothing is guessed, and the audit survives |
| `test_database.py :: NoAutomaticChangeTests` | Deploying the DB page changes no database |
| `test_database_ui.py :: SecretLeakTests` | No key in any response, page or log |
| `test_authorization.py` | Another account's data is indistinguishable from absent |

### How to debug a failing test

```bash
python manage.py test apps.outreach.tests.test_pipeline.PipelineTests -v 2
python manage.py test apps.outreach.tests.test_pipeline.PipelineTests.test_one_thing --failfast
python manage.py test --pdb apps.outreach.tests.test_pipeline   # drop into the debugger
```

**If a test unexpectedly reaches a real provider:** you patched `apps.ai.backend` instead
of `apps.ai.client.backend`. `_complete()` resolves the name in `client`, so patching the
package attribute leaves the real provider in place. That mistake once cost a live 401 from
Groq.

### In simple words

1,642 tests, about two minutes, and none of them can send an email, read a mailbox or spend
money — that is enforced, not hoped for. Tests live next to the code they test. The ones
worth reading are the negative ones: they are how the project records what must never
happen.

---
# 23. Debugging

Each guide is ordered cheapest check first.

### Email not sending

```
1. THE SAFETY SWITCH — this is the most common cause by a wide margin
   grep OUTREACH_BLOCK_SEND .env
   -> set? remove it. It blocks SMTP and IMAP at
      mail/transport.py, mail/inbox.py, mail/accounts.py, ai/views.py

2. THE CAMPAIGN
   python manage.py shell -c "
   from apps.outreach.models import Campaign
   c = Campaign.objects.get(pk='<uuid>')
   print(c.status, c.phase, '| may_send:', c.may_send, '|', c.status_note)"
   -> paused / stopped / completed? may_send is False and nothing new goes out

3. THE MAILBOX
   python manage.py shell -c "
   from apps.outreach.models import Campaign
   from apps.outreach.mail import accounts
   c = Campaign.objects.get(pk='<uuid>')
   print(accounts.selection_report(c))
   print('usable:', [a.sender_email for a in accounts.sending_accounts(c)])"
   -> empty? the mailbox is inactive, has no password, or is at its cap

4. THE LIMITS
   python manage.py shell -c "
   from apps.outreach.models import EmailAccount
   from apps.outreach.mail import accounts
   for a in EmailAccount.objects.all():
       print(a.sender_email, accounts.sent_today(a), '/', accounts.daily_cap(a),
             'left', accounts.remaining_today(a))"

5. THE DELAY
   provider.delay (2.5-3.5s) + AutomationPlan.send_gap_seconds
   -> slow is not broken. 400 emails at 2.5s is ~17 minutes of pure waiting

6. DUPLICATE PROTECTION
   python manage.py shell -c "
   from apps.outreach.models import EmailDraft
   from apps.outreach.services import history
   d = EmailDraft.objects.get(pk=<id>)
   print(d.status, '|', history.blocked_reason(d))"
   -> AlreadyContacted / DoNotContact means it is working as designed

7. THE RECIPIENT
   -> EmailDraft.status == 'no_email'? nothing was published and nothing is guessed
   -> status 'suppressed'? check Suppression for the address AND the domain

8. THE PROVIDER
   python manage.py smtp_check
   -> authenticates without emailing anybody

9. THE LOGS
   sudo journalctl -u leadmapper --since '1 hour ago' | grep -i error
   tail -f /var/log/leadmapper-automation.log
   python manage.py shell -c "
   from apps.outreach.models import Campaign
   from apps.outreach.services.automation import events
   for e in events.recent(Campaign.objects.get(pk='<uuid>'), limit=30):
       print(f'{e.created_at:%m-%d %H:%M} {e.kind:18} {e.message[:70]}')"
```

### Campaign not running

```
1. STATUS
   -> not 'active'? nothing runs. Press Start, or set_status(active)

2. THE SCHEDULE AND THE WINDOW
   python manage.py shell -c "
   from apps.outreach.models import AutomationPlan
   from apps.outreach.services.automation import schedule
   p = AutomationPlan.objects.get(pk=<id>)
   print(schedule.describe(p))
   print('window state:', schedule.state(p))
   print('next open   :', schedule.next_open(p))"

3. TIMEZONE
   -> plan.timezone_name is IANA ('Europe/Amsterdam'), not an offset.
      The window and the daily count are evaluated in THAT zone, not the server's

4. TARGETS
   python manage.py shell -c "
   from apps.outreach.models import AutomationPlan
   p = AutomationPlan.objects.get(pk=<id>)
   print('sent', p.sent_total, 'of', p.total_target, '| reached:', p.target_reached)
   d = p.day()
   print('today reserved', d.reserved, 'sent', d.sent, 'remaining', d.remaining())"

5. THE LEAD POOL
   python manage.py shell -c "
   from apps.outreach.models import AutomationPlan
   from apps.outreach.services.automation import leads
   p = AutomationPlan.objects.get(pk=<id>)
   print('pool:', leads.pool_size(p), '| searches left:', leads.searches_left(p),
         '| exhausted:', leads.exhausted(p))"

6. A STALE LEASE
   python manage.py shell -c "
   from django.utils import timezone
   from apps.outreach.models import AutomationPlan
   for p in AutomationPlan.objects.exclude(locked_by=''):
       stale = p.locked_until and p.locked_until < timezone.now()
       print(p.name, p.locked_by, 'EXPIRED' if stale else 'held until', p.locked_until)"
   -> expired leases are taken over automatically after LEASE_SECONDS = 600

7. CRON
   crontab -l | grep run_automation
   -> and check the wrapper exports DJANGO_SETTINGS_MODULE=config.settings.production
   python manage.py run_automation --dry-run     # what WOULD happen

8. THE DATABASE
   python manage.py shell -c "
   from apps.core import database
   print(database.active(), '|', database.active_description())
   print('pending restart:', database.pending_restart())"
   -> a switch that has not been restarted into means cron and the web process
      could be on different databases
```

### Audit failed

```
1. THE URL
   python manage.py shell -c "
   from apps.auditing import safeurl
   try: print('accepted:', safeurl.check('<url>').url)
   except Exception as exc: print('refused:', exc)"
   -> refused for a private range, an odd port, credentials in the URL,
      or a non-.supabase.co host (that last one is only for the DB page)

2. THE CRAWL
   python manage.py shell -c "
   from apps.auditing import crawler
   r = crawler.analyse('<url>')
   print(r.status, '|', r.detail)
   print('pages', len(r.pages), 'discovered', r.discovered, 'sitemap', r.sitemap_used)"
   -> BLOCKED = robots.txt, a bot wall, or the guard
      FAILED  = network, timeout, non-HTML
      NO_WEBSITE = nothing to read

3. TIMEOUT
   OUTREACH_CRAWL_TIMEOUT=40 OUTREACH_CRAWL_MAX_PAGES=15 python manage.py run_audits --job <id>

4. THE NETWORK
   curl -sS -o /dev/null -w '%{http_code} %{time_total}s\n' '<url>'
   -> outbound 443 blocked? a security group or firewall problem, not this code

5. CRAWL RESTRICTIONS
   python manage.py shell -c "
   from apps.auditing import crawler
   crawler.forget_robots()
   robots = crawler._robots_for('<url>')
   print('robots allows:', crawler._allowed('<url>', robots))"

6. THE STORED STATE
   python manage.py shell -c "
   from apps.outreach.models import AuditJob
   j = AuditJob.objects.get(pk=<id>)
   print(j.state, '|', j.detail)
   print('sendable:', not __import__('apps.outreach.services.websiteaudit',
        fromlist=['x']).blocked_reason(j))"
   -> then press Retry, or: python manage.py run_audits --job <id>
```

### AI not working

```
1. python manage.py ai_status
   python manage.py ai_status --user you@example.com
2. python manage.py ai_status --live        # generates one throwaway email
3. Is the campaign parked?
   python manage.py shell -c "
   from apps.outreach.models import Campaign
   c = Campaign.objects.get(pk='<uuid>')
   print(c.phase, c.pause_reason, c.pause_detail, 'retry at', c.retry_at,
         'pauses', c.pause_count)"
   -> phase 'paused_rate_limit' -> wait for retry_at, or press Resume now
   -> pause_count at MAX_PAUSES (5) -> it stopped rather than pausing forever
4. "cannot be decrypted" on a saved key -> DJANGO_SECRET_KEY changed. Re-add the key
   and keep the secret key stable
```

### Follow-up not appearing

```
python manage.py process_followups --dry-run

python manage.py shell -c "
from apps.outreach.models import SentLead
from apps.outreach.mail import followups
from apps.outreach.services import followups as svc
lead = SentLead.objects.get(pk=<id>)
b = followups.blocklist_for(lead.owner)
print('eligibility:', followups.eligibility(lead, blocklist=b))
print('halted     :', svc.halted(lead))
print('next number:', svc.next_number(lead))
print('due at     :', followups.next_due(lead))
print('existing   :', list(lead.followups.values_list('number','status','skip_reason')))"
```

Common causes: the delay has not elapsed (`OUTREACH_FOLLOWUP_DELAYS` default `2,7`); the
lead replied, bounced or unsubscribed; `followup_max` reached; the campaign cannot follow
up; three attempts already failed. Remember: a prepared follow-up **never sends itself** —
it waits at `DUE` for a click.

### Database page not visible

```
python manage.py shell -c "
from django.contrib.auth import get_user_model
for u in get_user_model().objects.all():
    print(u.email or u.username, 'staff=', u.is_staff)"
```

Not staff → the page is invisible and returns 403. Grant it:

```bash
python manage.py shell -c "from django.contrib.auth import get_user_model as m; \
  u = m().objects.get(email__iexact='you@example.com'); u.is_staff = True; \
  u.save(update_fields=['is_staff'])"
```

### Everything is slow

```
Crawling      5 pages x (1s throttle + up to 15s timeout) — this is the expensive part
AI            one audit call + one email call per lead
Sending       2.5-3.5s per message, by design
=> ~30-60s per lead is normal. 25 leads per pass (PASS_LIMIT) is ~15-25 minutes.
```

Not a bug. Lower `OUTREACH_CRAWL_TARGET_PAGES` to trade evidence for speed.

### In simple words

Nine times out of ten: `OUTREACH_BLOCK_SEND` is set, the campaign is not `active`, the
window is closed in the plan's timezone, or the mailbox has hit its daily cap. Check those
four first. The campaign event log usually says which.

---

# 24. Common Development Tasks

Each: the file, the function, the change, what else it touches, and the tests.

### Add an audit signal

1. **File** `apps/auditing/measurements.py` — detect it inside `measure()`; add any pattern
   constant beside `CTA_PATTERN` and friends.
2. **File** `apps/auditing/scoring.py` — use it in whichever sub-score owns it, as a
   `Factor` deduction so it can be explained.
3. **File** `apps/ai/prompts.py` — `_signals_block()` so the model can cite it.
4. **Dependencies** none. Do not touch the crawler.
5. **Tests** `apps/auditing/tests/test_measurements.py`;
   `apps/ai/tests/test_evidence.py` if the AI may cite it.

**The one rule:** the signal must be something a person could verify by opening the page.

### Add a field to an email

1. **File** `apps/ai/prompts.py` — add it to `SCHEMA_TEMPLATE`/`schema_for()` and mention
   it in `SYSTEM_TEMPLATE`.
2. **File** `apps/ai/base.py` — add it to `GeneratedEmail`.
3. **File** `apps/ai/parsing.py` — read it in `parse()`.
4. **File** `apps/outreach/models/campaigns.py` — a field on `EmailDraft`, then
   `makemigrations`.
5. **Tests** `apps/ai/tests/test_parsing.py`, `apps/ai/tests/test_prompts.py`.

### Change email length

1. **File** `apps/ai/styles.py` — the `Style`'s `min_words`, `max_words` **and**
   `length_rule`.
2. **Both**, or the prompt and the check disagree: the prompt aims, the check catches.
3. **Tests** `apps/ai/tests/test_email_style.py`.

### Add a campaign setting

1. **File** `apps/outreach/models/automation.py` — the field on `AutomationPlan`.
2. `python manage.py makemigrations outreach && python manage.py migrate`
3. **File** `apps/outreach/forms.py` — the field on `AutomationForm`, validation in
   `clean_*`, and an entry in `plan_values()` and `summary()`.
4. **File** `templates/outreach/automation_form.html`.
5. **File** wherever it is read — usually `apps/outreach/services/automation/runner.py` or `process.py`.
6. **Tests** `apps/outreach/tests/test_automation.py :: FormValidationTests`,
   `CreationTests`.

### Add a crawler rule

1. **File** `apps/auditing/crawler.py` — `classify()` for what is worth reading;
   `BOT_WALL_MARKERS` or `_allowed()` for a refusal.
2. **Limits** add a `_tunable()` rather than a bare constant, so it is overridable.
3. **Tests** `apps/auditing/tests/test_crawler.py :: DiscoveryTests`,
   `AnalyserPolicyTests`.

### Add an AI validation rule

1. **File** `apps/ai/validation.py` — the pattern constant, then a check function
   returning `""` or a reason.
2. **Call it** from `draft_problem()` or the caller that should reject.
3. **Tests** `apps/ai/tests/test_email_style.py`, `test_evidence.py`.

Prefer a validation rule over a prompt instruction. The prompt asks; the validator
guarantees.

### Change email limits

| Change | Where |
| --- | --- |
| Provider daily cap or delay | `apps/outreach/mail/providers.py :: PROVIDERS` |
| A mailbox's own lower cap | `EmailAccount.daily_limit` in the UI |
| Extra gap between sends | `AutomationPlan.send_gap_seconds` |
| Leads per pass | `automation/runner.py :: PASS_LIMIT` |
| Follow-up count and delays | `OUTREACH_FOLLOWUP_MAX`, `OUTREACH_FOLLOWUP_DELAYS` |

Tests: `apps/outreach/tests/test_mailaccounts.py :: DailyLimitTests`.

### Add a model

1. **File** the right module in `apps/outreach/models/` — not a new giant `models.py`.
2. **File** `apps/outreach/models/__init__.py` — export it, **in foreign-key order** (the
   comment there explains why).
3. Add `owner = ForeignKey(User, null=True, on_delete=...)` unless it is genuinely global.
4. Add constraints for anything that must not happen twice. A `UniqueConstraint` beats
   application logic.
5. `python manage.py makemigrations outreach && python manage.py migrate`
6. **Tests** a new file in `apps/outreach/tests/`, and an entry in
   `apps/outreach/tests/test_authorization.py` if it is owned.

### Create a migration

```bash
python manage.py makemigrations outreach
python manage.py makemigrations --check --dry-run    # must say "No changes detected"
python manage.py migrate
python manage.py migrate --plan                     # what it will do, before it does it
```

**Moving a model between apps** — the pattern already used once, in
`apps/ai/migrations/0001_move_ai_credentials.py`: pin `db_table` on the model, then wrap
the operations in `migrations.SeparateDatabaseAndState(database_operations=[],
state_operations=[...])`. No table is renamed and no data moves. Verify with
`migrate --plan`, which should report only "Custom state/database change combination".

### Add a management command

1. **File** `apps/outreach/management/commands/<name>.py`.
2. Put the **logic in a service**; the command is `add_arguments` + `handle` + printing.
   `process_followups.py` is the worked example — 95 lines of terminal, with the work in
   `apps/outreach/services/followups.py`.
3. If it is a background job, add a callable to `apps/outreach/tasks.py` too.
4. **Verify it imports** — `manage.py check` does *not* load commands:
   ```bash
   python -c "
   import os, django; os.environ['DJANGO_SETTINGS_MODULE']='config.settings.development'
   django.setup()
   from django.core.management import load_command_class
   load_command_class('apps.outreach','<name>'); print('ok')"
   ```
   A broken command import once went unnoticed for exactly this reason.
5. **Docs** the Commands table in `README.md`, and DEPLOY.md §12 if it wants a cron line.

### Add a view

1. **File** the right module in `apps/outreach/views/` — and `__init__.py` if it should be
   re-exported.
2. Use `_my_campaign()` / `_my_draft()` — never trust an id.
3. `@require_GET` or `@require_POST`.
4. Keep it thin: parse, call a service, render.
5. **File** `apps/outreach/urls.py`.
6. **Tests** `apps/outreach/tests/test_views.py`, plus `test_authorization.py`.

### Add a settings tunable

1. **File** `config/settings/base.py` — `os.environ.get(...)` with a default and a `#:`
   comment saying what it does.
2. **File** `.env.example` — a commented placeholder.
3. **File** `README.md` §7.
4. Read it via `getattr(settings, "NAME", default)` so a missing one cannot crash.

### In simple words

Most changes touch three or four files, and the pattern is always the same: the data in a
model, the decision in a service, the display in a view and template, and a test next to
whichever of those you changed. If you are about to put logic in a view or a management
command, it belongs in a service instead.

---
# 25. End-to-End Workflows

### A. Automated campaign (the only path that sends unattended)

```
PERSON, once:
  /outreach/automation/new  -> AutomationForm
     countries, cities, categories, quality
     daily_target, total_target
     start_date/time, end_date/time, timezone_name
     email_account, template_key, send_gap_seconds
     followups_enabled, followup_delay_days, followup_max
     (followup_autosend is NOT a field — always False)
  -> Campaign(status=draft) + AutomationPlan (OneToOne)
  POST /outreach/automation/<pk>/start -> set_status(active)

THEN, EVERY 5 MINUTES, cron:
  manage.py run_automation
     ↓ tasks / runner.due_plans()
     ↓ for each plan:
        claim(plan, worker_id(), 600s)          conditional UPDATE — lose = skip
           ↓
        _halt(plan, courier)                    should it run at all?
           status paused/stopped?               -> Halt("Paused: …")
           schedule.state(plan) closed?         -> Halt(window.reason)
           plan.target_reached?                 -> Halt("Total target reached", complete=True)
           no usable mailbox?                   -> Halt(unusable)
           leads.exhausted(plan)?               -> Halt("No eligible businesses", complete=True)
           ↓ clear
        leads.top_up(plan)                      keep the pool above LOW_WATER = 5
           ↓ claim_search() -> scraper.search() -> _absorb() -> EmailDrafts
        _work(plan, report, limit=PASS_LIMIT=25)
           ↓ for each of up to 25 leads:
              claim_lead(plan)                  conditional UPDATE on claimed_by
              AutomationDay.reserve()           atomic daily-slot reservation
              process.eligibility(plan, draft)  suppressed? replied? no email? filters?
                 ↓ refused -> process.refuse() -> CampaignEvent, next lead
              crawler.analyse(website)          <- the expensive part
              measurements + scoring
              ai.audit()   -> findings
              ai.generate() -> subject + body
              validation                        reject -> record and move on
              process.validate(draft, plan)     last check before sending
              history.reserve(draft)            INSERT SentLead(sending) — the guarantee
                 ↓ AlreadyContacted/DoNotContact -> skip
              courier -> transport.Session.send()
              SentLead.status=sent, message_id stored
              followups.schedule_next(lead)     -> FollowUp(waiting)
              sleep(provider.delay + send_gap_seconds)
           ↓
        process.prepare_followups(plan, FOLLOWUP_LIMIT=5)    DRAFTS ONLY
        release(plan)
```

### B. Specific URL audit

```
PERSON: pastes a URL at /outreach/audit/new
   ↓ safeurl.normalise() then safeurl.check()      <- refuses here, before any fetch
   ↓ websiteaudit.create(owner, submitted)          AuditJob(created)
   ↓ start_in_background(job)  (or cron: run_audits -> run_pending -> claim -> run_job)
SpecificWebsiteAuditService.run()
   CRAWLING         crawler.analyse(url, guard=safeurl.guard, progress=harvest)
                       guard runs on the URL AND EVERY REDIRECT HOP
   ANALYZING        measurements -> scoring -> ai.audit()
   CONTACTS_FOUND   contacts.harvest_page() results shortlisted
   DRAFT_READY      ai.generate() -> validation
   READY_FOR_REVIEW  <-- TERMINAL for every automated path
   ↓
PERSON: reads /outreach/audit/<pk>, may audit_save (edit) or audit_regenerate
POST /outreach/audit/<pk>/send
   ↓ auditsend.send() — eight refusals, each raising SendRefused
   ↓ transport.Session.send()
   AuditJob.state = SENT
```

### C. First email (attended)

```
/  -> search -> select leads -> POST /outreach/start
   Campaign(draft, setup) + EmailDraft per lead   (max 300)
GET /outreach/<uuid>/setup   sender identity, pitch, mailboxes (M2M)
POST /outreach/<uuid>/run
   ↓ pipeline.start_pipeline(campaign)
   ↓ _claim(campaign.id)  -> _spawn(thread)  -> the request returns NOW
   │  per lead, phase moves crawling -> analysing -> generating,
   │  current_draft / current_step updated so /state can report the truth
   │  crawl -> measure -> score -> ai.audit -> ai.generate -> validate -> store
   ↓ phase = review
BROWSER polls GET /outreach/<uuid>/state
PERSON approves or rejects each draft  (/outreach/draft/<pk>/<action>, approve_all)
POST /outreach/<uuid>/send
   ↓ per approved draft: history.reserve() -> Session.send() -> SentLead(sent)
   ↓ followups.schedule_next(lead)
   ↓ phase = done
```

### D. Follow-up

```
Email sent -> followups.schedule_next(lead) -> FollowUp(waiting, scheduled_for=+2 days)
   ↓ (2 days, from OUTREACH_FOLLOWUP_DELAYS)
cron: process_followups   (hourly)  or an automation pass (5 per pass)
   ↓ services.followups.due_leads(owner, limit)
   ↓ mail.followups.eligibility(lead, blocklist)     replied? bounced? unsubscribed?
   ↓ services.followups.halted(lead)                 campaign? mailbox? already waiting?
   ↓     refused -> record_skip(reason), once per reason
   ↓ claim(owner, lead, number)                      conditional UPDATE / unique insert
   ↓ write(followup, lead)
   │     ai.follow_up(conversation=followups.conversation(lead), days_since=...)
   │     in_reply_to + references set — it lands in the original thread
   ↓ status = DUE
   │
   │   ##############  NOTHING SENDS IT  ##############
   │
PERSON: /outreach/followups -> reads -> may edit
POST /outreach/followup/<pk>/send
   ↓ followups.check_before_send(followup)  -> may raise Blocked
   ↓ transport.Session.send() -> status = sent
```

### E. Website crawling

```
analyse(website, guard=?, should_stop=?, progress=?)
   normalise(website)                       "" -> NO_WEBSITE
   _robots_for(url)                         cached ROBOTS_TTL=3600s, best-effort
   _allowed(url, robots)                    no -> BLOCKED
   _throttle(host)                          HOST_DELAY = 1.0s
   _guard(guard, url)                       refuse -> BLOCKED
   _fetch(url)                              MAX_ATTEMPTS=2, MAX_BYTES=2MB,
                                            TIMEOUT=15s, MAX_REDIRECTS=5
                                            (guard runs on every hop)
   BOT_WALL_MARKERS in html?                -> BLOCKED, no attempt to get past it
   measurements.extract() -> Page
   progress({"stage":"home", ...})           <- contacts harvested here, in memory
   discover_links() + discover_sitemap()
   choose_pages()                            TARGET_INTERNAL=5, MAX_DEPTH=3, MAX_PAGES=8
   repeat for each chosen page
   -> SiteAnalysis(status, detail, pages, emails_found, discovered,
                   sitemap_used, stopped)
```

### F. AI audit

```
SiteAnalysis.pages
   ↓ scoring.merge_signals([p.signals for p in pages])
   ↓ six sub-scores, each with explainable Factor deductions
   ↓ scoring.platform_advice(signals) -> keep | optimise | modernise | unknown
   ↓ prompts.build_audit_prompt(signals=..., pages=...)   only measured facts
   ↓ client._complete(system=AUDIT_SYSTEM, schema=AUDIT_SCHEMA,
                      max_tokens=AUDIT_MAX_TOKENS)
   │     -> credentials.require(provider) -> backends/<provider>.complete()
   │     -> on rate_limit/unavailable + an opt-in spare: ONE retry on the spare
   ↓ parsing.parse_audit(text) -> SiteAudit(findings)
   ↓ validation.assign_ids()             AUD-001 …
   ↓ prompts.attribute_pages()           each finding -> a real crawled URL
   ↓ validation.hedge_findings()          unverifiable claims softened
   ↓ scoring.unsupported_replatform()     unsupported "rebuild it" claims rejected
   ↓ reports.audit_report(findings)       grouped high / medium / low
   ↓ intelligence.remember() -> WebsiteAudit;  intelligence.apply() -> EmailDraft
```

### G. Database switching

```
PERSON (staff): /outreach/settings/database
   ↓ POST .../supabase   {url, anon_key, service_key}
   ↓ database.validate_url()   https + *.supabase.co, no credentials, no path
   ↓ database.save_supabase()  encrypt both keys -> database.json (0600)
   ↓ POST .../switch {"target": "supabase"}
   ↓ database.switch("supabase")
      supabase_status()  DATABASE_URL set? all three fields present?
         ↓ no -> DatabaseSettingsError, NOTHING WRITTEN
      test_supabase()
         _test_postgres()  psycopg connect, SELECT 1, count django_migrations
         _test_rest()      GET {url}/rest/v1/ with each key, allow_redirects=False
         ↓ fail -> DatabaseSettingsError, NOTHING WRITTEN
      ↓ pass
      write_state({"selection": "supabase"})
   ↓ response: needs_restart=True, "Nothing has been copied, moved or deleted"

RESTART: systemctl restart leadmapper  /  docker compose restart web
   ↓ config/settings/base.py reads database.json + DATABASE_URL
   ↓ DATABASES["default"] = dburl.parse(DATABASE_URL)
   ↓ python manage.py migrate      (if the target has no schema)

To move the DATA — separate, explicit, never automatic:
   SQLITE_SOURCE=outreach.sqlite3 python manage.py db_transfer --dry-run
   SQLITE_SOURCE=outreach.sqlite3 python manage.py db_transfer
   python manage.py db_transfer --verify-only
```

### H. Email failure

```
Session.__enter__ or Session.send raises SendError
   ↓ SentLead.status = "failed", error_message set    (the reservation row STAYS,
   │                                                   so the address is not retried)
   ↓ CampaignEvent recorded
   ↓ THE LOOP CONTINUES to the next recipient
   ↓ courier counts a consecutive failure
   ↓ 3 in a row (MAX_CONSECUTIVE_FAILURES) -> AccountUnavailable
        -> _halt(plan) with a recorded reason; the pass ends
   ↓ NO AUTOMATIC RETRY of the send — a person decides
```

### I. Campaign pause / resume

```
PAUSE   POST /outreach/<uuid>/status/pause
   ↓ campaigns.set_status(campaign, "paused")     checked against ALLOWED
   ↓ may_send -> False. New sends and follow-up preparation stop.
   ↓ nothing in flight is killed; the lead being processed finishes

CANCEL (mid-run)  POST /outreach/<uuid>/cancel
   ↓ phase = cancel_requested
   ↓ pipeline._check_cancel() between steps
   ↓ crawler.analyse(should_stop=...) before EVERY request -> stops within one page
   ↓ SiteAnalysis.stopped = True -> the partial read is DISCARDED, not stored
   ↓ mark_cancelled() -> phase = cancelled

RESTART KILLED IT
   ↓ campaign left in a working phase with no thread
   ↓ pipeline.stalled(campaign) detects exactly that
   ↓ the workspace offers Resume

RESUME  POST /outreach/<uuid>/resume
   ↓ set_status(active) + start_pipeline(campaign, resume=True)
   ↓ leads already finished are SKIPPED
   ↓ within the interrupted lead, completed steps are skipped
   ↓ nothing is paid for twice
```

---

### In simple words

Nine numbered flows, each one traced through the real function names. If you are trying to
follow what happens when somebody presses a button, find the flow here first and then open
the files it names in order — that is faster than reading any single module.

---

# 26. Code Map

| Feature | File | Class | Function | Purpose |
| --- | --- | --- | --- | --- |
| Business search | `apps/leads/scraper.py` | `Lead`, `ScrapeError` | `search()` | Nominatim + Overpass → leads |
| Country/city data | `apps/leads/places.py` | — | `countries()`, `cities_for()`, `validate()` | Offline geo data |
| Search screens | `apps/leads/views.py` | — | `index`, `search`, `cities`, `export` | The search UI and CSV |
| Crawling | `apps/auditing/crawler.py` | `SiteAnalysis`, `Page` | `analyse()`, `_fetch()`, `_robots_for()`, `choose_pages()` | Reading a website |
| Measuring | `apps/auditing/measurements.py` | `Fetched`, `Page` | `measure()`, `extract()`, `detect_stack()`, `scrape_emails()` | HTML → facts |
| Scoring | `apps/auditing/scoring.py` | `Score`, `Factor`, `WebsiteAssessment` | six `*_score()`, `merge_signals()`, `platform_advice()`, `classify()` | Facts → scores |
| Contact discovery | `apps/auditing/contacts.py` | `Harvest`, `Detail` | `harvest_page()` | Published emails and phones |
| SSRF defence | `apps/auditing/safeurl.py` | `Target`, `UnsafeUrl`, `InvalidUrl` | `check()`, `guard()`, `same_site()` | Refusing a dangerous URL |
| AI dispatch | `apps/ai/client.py` | — | `_complete()`, `provider()`, `model()`, `backend()` | The one provider call |
| AI features | `apps/ai/generation.py` | — | `audit()`, `generate()`, `no_website_email()`, `follow_up()` | The four features |
| Prompts | `apps/ai/prompts.py` | — | `build_audit_prompt()`, `build_prompt()`, `system_for()`, `schema_for()`, `attribute_pages()` | What is asked |
| Parsing | `apps/ai/parsing.py` | — | `parse()`, `parse_audit()`, `parse_followup()` | Text → objects |
| Validation | `apps/ai/validation.py` | — | `draft_problem()`, `specificity_problem()`, `style_problem()`, `hedge_findings()`, `assign_ids()` | Rejecting bad output |
| AI errors | `apps/ai/base.py` | `AiError`, `GeneratedEmail`, `Finding`, `SiteAudit` | `classify_rate_limit()`, `retry_after_of()` | Provider-neutral errors |
| AI credentials | `apps/ai/credentials.py` | `Spec`, `Credential`, `CredentialError` | `resolve()`, `require()`, `status()`, `all_statuses()` | The key pool |
| Email styles | `apps/ai/styles.py` | `Style` | `STYLES`, `DEFAULT_STYLE` | Length and tone presets |
| Encryption | `apps/core/secrets.py` | `SecretError` | `encrypt()`, `decrypt()`, `mask()` | Secrets at rest |
| DB selection | `apps/core/database.py` | `Status`, `TestResult`, `DatabaseSettingsError` | `selection()`, `active()`, `switch()`, `test_supabase()`, `save_supabase()` | Which database |
| DB URL parsing | `apps/core/dburl.py` | `DatabaseUrlError` | `parse()`, `describe()`, `is_postgres()`, `pooled()` | `DATABASE_URL` |
| Pagination | `apps/core/paging.py` | — | `page_context()` | Server-side paging |
| Test support | `apps/core/testing.py` | `SignedIn`, `OtherUser` | `make_user()`, `default_user()` | The signed-in TestCase |
| DB settings UI | `apps/core/views.py` | — | `database_view`, `database_state`, `supabase_save`, `connection_test`, `database_switch` | The page |
| Mail providers | `apps/outreach/mail/providers.py` | `Provider` | `PROVIDERS`, `provider_for()`, `resolve_host()`, `normalise_password()` | Hosts, pacing, caps |
| Composing | `apps/outreach/mail/compose.py` | — | `build_message()`, `with_reply_line()`, `with_signature()` | Every header |
| **Sending** | `apps/outreach/mail/transport.py` | **`Session`** | **`Session.send()`** | **The only SMTP handover** |
| Mailboxes | `apps/outreach/mail/accounts.py` | `AccountError`, `NoSendingAccount` | `sending_accounts()`, `daily_cap()`, `remaining_today()`, `save_account()` | Which mailbox may send |
| Follow-up rules | `apps/outreach/mail/followups.py` | `Eligibility`, `Blocked` | `eligibility()`, `delay_days()`, `schedule_next()`, `conversation()`, `check_before_send()` | May this get one |
| Inbox | `apps/outreach/mail/inbox.py` | `Inbox`, `Matcher`, `Verdict`, `CheckResult`, `InboxError` | `check()`, `apply()`, `looks_like_bounce()`, `asks_to_unsubscribe()` | Replies and bounces |
| Audit send | `apps/outreach/mail/auditsend.py` | `SendRefused` | `send()` | Sending one audit |
| Pipeline | `apps/outreach/services/pipeline.py` | `Cancelled`, `RateLimited` | `start_pipeline()`, `is_running()`, `stalled()`, `_call_ai()`, `_park()` | One lead end to end |
| Campaign status | `apps/outreach/services/campaigns.py` | `TransitionError` | `ALLOWED`, `set_status()`, `controls()`, `dashboard()` | The lifecycle |
| Send history | `apps/outreach/services/history.py` | `Index`, `SuppressionIndex`, `AlreadyContacted`, `DoNotContact` | `reserve()`, `suppress()`, `annotate_leads()`, `export_excel()` | Duplicate prevention |
| Follow-up worker | `apps/outreach/services/followups.py` | `Outcome`, `Halt` | `prepare_one()`, `due_leads()`, `claim()`, `next_number()`, `write()` | Drafting, never sending |
| Lead intelligence | `apps/outreach/services/intelligence.py` | — | `audit_website()`, `remember()`, `apply()`, `set_lifecycle()` | Scores onto a lead |
| Submitted-URL audit | `apps/outreach/services/websiteaudit.py` | `SpecificWebsiteAuditService`, `Outcome` | `create()`, `run_job()`, `run_pending()`, `regenerate()`, `blocked_reason()` | The URL workflow |
| Automation runner | `apps/outreach/services/automation/runner.py` | `Report`, `Halt` | `run_plan()`, `due_plans()`, `claim()`, `claim_lead()`, `_halt()` | The unattended pass |
| Scheduling | `apps/outreach/services/automation/schedule.py` | `Window`, `ScheduleError` | `state()`, `window()`, `next_open()`, `describe()` | Timezone windows |
| Prospect pool | `apps/outreach/services/automation/leads.py` | — | `fill()`, `top_up()`, `claim_search()`, `exhausted()` | Keeping leads available |
| Sending courier | `apps/outreach/services/automation/courier.py` | `Courier`, `Result`, `AccountUnavailable` | — | The mailbox during a pass |
| Per-lead decisions | `apps/outreach/services/automation/process.py` | `Verdict`, `Outcome` | `eligibility()`, `process()`, `refuse()`, `validate()`, `prepare_followups()` | One lead in a pass |
| Event log | `apps/outreach/services/automation/events.py` | — | `record()`, `recent()`, `last_activity()` | Why something happened |
| Lead queries | `apps/outreach/selectors.py` | — | `filtered()`, `summary()`, `queues()`, `choices()` | Filtering and paging |
| Background jobs | `apps/outreach/tasks.py` | — | `prepare_followups()`, `run_audits()`, `check_replies()` | The three unattended jobs |
| Forms | `apps/outreach/forms.py` | `AutomationForm`, `MultiTextField` | `plan_values()`, `summary()` | Plan validation |

---
### In simple words

One row per thing the project does, with the file and function that does it. This is the
table to search when you know *what* you want to change but not *where* — Ctrl-F the
feature name and the path is in the same row.

---

# 27. Data Flow Map

### The main flow, with the real model names

```
 OpenStreetMap (Nominatim + Overpass)
        │  apps/leads/scraper.py :: search()
        ▼
 Lead  (a dataclass — NOT a database table)
        │  views/campaigns.py :: start()   max 300
        ▼
 ┌─────────────┐        ┌──────────────────────────────────────┐
 │  Campaign   │───1:N──▶│           EmailDraft                │
 │  (UUID pk)  │         │  status: no_email … sent … failed    │
 │  status     │         │  lifecycle: new … won / lost         │
 │  phase      │         └──────────────┬───────────────────────┘
 └──────┬──────┘                        │
        │ 1:1                           │  website
        ▼                               ▼
 ┌──────────────┐         apps/auditing/crawler.py :: analyse()
 │AutomationPlan│                       │
 │ window, tz   │                       ▼
 │ targets      │            SiteAnalysis (in memory only)
 │ lease        │                       │
 └───┬──────┬───┘                       ▼
     │1:N   │1:N          measurements.measure() -> signals per Page
     ▼      ▼                           │
 AutomationDay  ProspectSearch          ▼
 (day counter)  (one area)   scoring.merge_signals() + six sub-scores
     │                                  │
     │ atomic                           ▼
     │ reservation           scoring.platform_advice()
     │                                  │
     │                                  ▼
     │                    apps/ai/prompts.build_audit_prompt()
     │                                  │
     │                                  ▼
     │                     apps/ai/client._complete()  ──▶ AI provider
     │                                  │                  (external)
     │                                  ▼
     │                    parsing.parse_audit() -> Finding objects
     │                                  │
     │                    validation + scoring guards
     │                                  │
     │                 ┌────────────────┴──────────────────┐
     │                 ▼                                   ▼
     │        ┌─────────────────┐              EmailDraft.findings (JSON)
     │        │  WebsiteAudit   │              EmailDraft.<six sub-scores>
     │        │ cache per       │              EmailDraft.priority
     │        │ domain+owner    │              EmailDraft.business_summary
     │        └─────────────────┘                          │
     │                                                     ▼
     │                              apps/ai/prompts.build_prompt()
     │                                                     │
     │                                     ai.generate() ──▶ AI provider
     │                                                     │
     │                                                     ▼
     │                          EmailDraft.subject / .body / .observation
     │                                     status = generated
     │                                                     │
     │                                        person approves, or a pass validates
     │                                                     ▼
     │              ┌──────────────────────────────────────────────────┐
     └─────────────▶│ services/history.py :: reserve()                 │
                    │   INSERT SentLead(status="sending")              │
                    │   UniqueConstraint one_live_send_per_email       │
                    │   ── THE DUPLICATE GUARANTEE ──                  │
                    └──────────────────┬───────────────────────────────┘
                                       │ checked against
                                       ▼
                               ┌───────────────┐
                               │  Suppression  │  email or domain
                               └───────────────┘
                                       │ clear
                                       ▼
                    mail/compose.build_message()  ──▶ headers, List-Unsubscribe
                    mail/transport.Session.send()  ──▶ SMTP (external)
                                       │
                                       ▼
                    ┌──────────────────────────────────┐
                    │           SentLead               │
                    │  status = sent                   │
                    │  message_id  <- ties replies back│
                    │  sent_at, sent_date, sent_time   │
                    │  reply_state = no_reply           │
                    └────────┬────────────────┬────────┘
                             │ 1:N            │
                             ▼                │
                    ┌─────────────────┐       │  IMAP (external)
                    │    FollowUp     │       │  mail/inbox.py :: check()
                    │  number 1, 2 …  │       ▼
                    │  waiting -> due │   Matcher (by message_id, then address)
                    │  -> sent        │       │
                    │  in_reply_to    │       ▼
                    │  references     │   apply(verdict)
                    └─────────────────┘       │
                             ▲                ├─▶ reply_state = replied
                             │                ├─▶ reply_state = bounced
                             │                └─▶ reply_state = unsubscribed
                             │                        │
                             │                        ▼
                             │                  Suppression (AUTOMATIC —
                             │                  the one automatic write here)
                             │                        │
                             └────────────────────────┘
                                blocks future follow-ups

 ── Throughout ─────────────────────────────────────────────────────────
 CampaignEvent   17 kinds — every decision, refusal and failure, per campaign
 EmailAccount    the sending mailbox; secret encrypted, daily_limit
 ProviderCredential / CredentialEvent / AiSelection   which AI key, and its health

 ── The submitted-URL branch ───────────────────────────────────────────
 a pasted URL -> safeurl.check() -> AuditJob -> (crawl/analyse/contacts/draft)
   -> state READY_FOR_REVIEW -> a person clicks -> auditsend.send() -> SentLead
   drafts hang off a synthetic Campaign, city = "Website audits"
```

### What is deliberately *not* stored

| Not stored | Why |
| --- | --- |
| Raw search results (`Lead`) | A dataclass that becomes an `EmailDraft` or is discarded |
| Full page HTML | Harvested in memory via the `progress` callback, then dropped |
| The prompt sent to the AI | Reconstructible from the draft; storing it would duplicate every signal |
| A partial crawl (`stopped=True`) | A cancelled read is not the whole truth |
| Any key or password in plaintext | Encrypted, or in `.env` only |
| The signature and reply line | Added by `compose` at send time, so editing them affects future sends |
| Which database to use | A JSON file — it cannot live in the database it selects |

---

### In simple words

Follow the arrows: a business becomes a lead, a lead's website becomes pages, pages become
measured facts, facts become findings, findings become an email, and the email becomes a
permanent `SentLead` record that blocks a second one. The boxes are real tables; anything
in the "not stored" list is deliberately kept only in memory.

---

# 28. External Services

Five, and no others. Anything not listed here is not called.

### 1. Nominatim (OpenStreetMap geocoding)

| | |
| --- | --- |
| **Purpose** | Turn "Delft, Netherlands" into a bounding box |
| **API** | `GET https://nominatim.openstreetmap.org/search` |
| **Authentication** | None. A real contact address in the User-Agent is **required** by their policy |
| **Configuration** | `OSM_CONTACT_EMAIL` — search refuses to run with a placeholder |
| **Code** | `apps/leads/scraper.py :: NOMINATIM_URL`, `_headers()`, `_check_contact()`, `_throttle()` |
| **Data sent** | The country and city name |
| **Data returned** | A bounding box |
| **Rate limit** | Theirs: 1 req/s. Ours: `MIN_INTERVAL = 1.1s`, enforced in code |
| **Failure** | `ScrapeError` with a readable message. The search fails rather than returning an empty list |
| **Licence** | ODbL. Attribution required if you publish the data onward |

### 2. Overpass API (OpenStreetMap business data)

| | |
| --- | --- |
| **Purpose** | Businesses inside a bounding box, matching a category |
| **API** | `POST` to `overpass-api.de`, `overpass.kumi.systems`, `overpass.osm.ch` |
| **Authentication** | None |
| **Configuration** | `OVERPASS_URLS`, `QUERY_TIMEOUT = 90`, `MAX_LEADS = 300` |
| **Code** | `apps/leads/scraper.py :: OVERPASS_URLS`, `search()` |
| **Data sent** | An Overpass QL query — the bounding box and the tags from `_KIND_TAGS` |
| **Data returned** | OSM elements with tags: name, website, phone, email, address |
| **Rate limit** | `DEFAULT_INTERVAL = 0.5s`; three mirrors tried in order because the main one throttles |
| **Failure** | All three failing → `ScrapeError` |

### 3. AI providers (one of five)

| | |
| --- | --- |
| **Purpose** | Review a website's measurements; write an email; write a follow-up |
| **API** | Each vendor's SDK — `anthropic`, `google-genai`, `openai`, `groq` |
| **Authentication** | An API key: an active `ProviderCredential`, else the env var |
| **Configuration** | `OUTREACH_AI_PROVIDER`, `OUTREACH_AI_MODEL`, the token budgets |
| **Code** | `apps/ai/client.py :: _complete()` — **the only call site**; `apps/ai/backends/` |
| **Data sent** | Business name, category, city, country, the **measured signals**, page text extracts (≤ `OUTREACH_AI_CONTEXT_CHARS` = 9000), the sender identity, the service pitch, and for a follow-up the conversation so far |
| **Data returned** | JSON matching `AUDIT_SCHEMA` or `schema_for(style)` |
| **Failure** | Categorised by `credentials.categorise()`; **the provider's error text is never stored or shown**. Optional one-shot retry on an opt-in spare key; a rate limit parks the campaign |
| **Cost** | The only paid service here. `OUTREACH_BLOCK_SEND` does not block it, but the test suite doubles every call |

### 4. SMTP (the mail provider)

| | |
| --- | --- |
| **Purpose** | Sending |
| **API** | `smtplib` — `SMTP_SSL` or `SMTP` + STARTTLS |
| **Authentication** | The mailbox address and its password (an app password for Gmail) |
| **Configuration** | `OUTREACH_PROVIDER`, `OUTREACH_SMTP_PASSWORD`, or per-`EmailAccount` |
| **Code** | `apps/outreach/mail/transport.py :: Session`; hosts in `providers.py` |
| **Data sent** | One `EmailMessage` — headers in chapter 12 |
| **Data returned** | Success, or an `smtplib` exception. The `Message-ID` is generated locally and stored |
| **Rate limit** | `Provider.delay` (2.5–3.5s) and `Provider.daily_cap` (200–400), both below the published limits |
| **Failure** | `SendError`; `SentLead.status = failed`; **no automatic retry**; 3 consecutive failures halt the pass |
| **Blocked by** | `OUTREACH_BLOCK_SEND` — no connection is even opened |

### 5. IMAP (reading replies)

| | |
| --- | --- |
| **Purpose** | Detect replies, bounces and unsubscribe requests |
| **API** | `imaplib`, read-only in intent |
| **Authentication** | The same mailbox credentials |
| **Configuration** | `OUTREACH_IMAP_HOST`, `OUTREACH_IMAP_PORT`, `OUTREACH_INBOX_DAYS = 45` |
| **Code** | `apps/outreach/mail/inbox.py :: Inbox`, `check()`, `resolve_imap()` |
| **Data sent** | A search over recent messages |
| **Data returned** | Headers and plain text; `Message-ID` matching ties a reply to a `SentLead` |
| **Writes** | `reply_state`, `replied_at`, `reply_snippet` — and a `Suppression` for an unsubscribe |
| **Failure** | `InboxError`; `check_replies` reports it and exits |
| **Blocked by** | `OUTREACH_BLOCK_SEND` |

### Not used

Supabase's **REST/PostgREST API** is not used to store or read application data — Django
connects to Postgres directly. The only PostgREST request in the codebase is the connection
test on the database settings page. There is no client-side Supabase code, which is why the
publishable key has no browser consumer.

No Google Places, no paid lead provider, no email-verification service, no analytics, no
error-reporting service, no CDN, no object storage, no Celery broker.

---

### In simple words

Five outside services and no more: two OpenStreetMap endpoints for finding businesses, one
AI provider for judgement, SMTP for sending and IMAP for reading replies. Only the AI costs
money. There is no analytics, no tracking, no error-reporting service and no CDN.

---

# 29. Technology Decisions

### Django 6.1

- **Problem** — server-rendered screens, an ORM, sessions, auth, migrations and a
  management-command runner, without assembling five libraries.
- **Benefit** — `LoginRequiredMiddleware` gives deny-by-default auth; migrations give a
  reviewable schema history; management commands give a background-job runner for free.
- **Trade-off** — server-rendered means a full page load for navigation. Fine here: this is
  a tool for one operator, not a consumer app.
- **Alternative** — FastAPI plus a frontend framework. Would have meant building auth,
  sessions, an admin path and migrations, and running a build step.

### SQLite by default

- **Problem** — a fresh checkout must run with no configuration.
- **Benefit** — one file. A backup is a file copy. No service to run.
- **Trade-off** — one writer at a time. Handled with WAL mode plus `timeout: 20`, and by
  running exactly one Gunicorn worker.
- **Alternative** — Postgres from the start, which would have made "clone and run" a
  three-step setup.

### PostgreSQL / Supabase as the option

- **Problem** — SQLite on one box is a single point of failure and does not survive an
  ephemeral container filesystem.
- **Benefit** — a real concurrent database, managed backups, and Supabase adds row-level
  security policies (`sql/`).
- **Trade-off** — a connection string with a password to manage; the pooler (port 6543)
  does not keep session state, so migrations want the direct port (5432) —
  `dburl.pooled()` exists to warn about exactly that.
- **Alternative** — RDS. More setup, no RLS, and nothing here needs it.
- **How** — `DATABASE_URL` only. One switch, no second settings module.

### cron instead of Celery

- **Problem** — work that must happen when nobody is looking.
- **Benefit** — no broker, no worker process, no result backend. Three fewer things to run,
  monitor and restart. A failed job is a log line.
- **Trade-off** — minutes of latency, no distributed fan-out, and **exactly one Gunicorn
  worker** because `pipeline._running` is per-process.
- **Alternative** — Celery + Redis. The jobs here are minutes apart; a broker would be the
  second thing that breaks at 3am for no gain at this size.

### `requests` as the HTTP client

- **Problem** — fetching pages with timeouts, redirect control and streaming size caps.
- **Benefit** — `stream=True` plus reading `MAX_BYTES` is how a 2MB cap is enforced without
  downloading a 200MB file; `allow_redirects=False` is what makes per-hop SSRF checks
  possible.
- **Trade-off** — synchronous. Irrelevant: the crawler is deliberately throttled to 1
  request/second per host anyway.
- **Alternative** — `httpx` with async. Async would buy nothing against a self-imposed
  1s delay.

### BeautifulSoup4 as the parser

- **Problem** — extracting facts from real-world small-business HTML.
- **Benefit** — tolerant of broken markup, which is the normal case. `nav`/`footer`
  container queries are what let `discover_links()` weight a nav link above a sidebar one.
- **Trade-off** — slower than `lxml` or `selectolax`. Irrelevant at 5 pages per lead.
- **Alternative** — `lxml` (brittle on bad HTML), regex (wrong).

### Five AI providers, none required

- **Problem** — one provider means one rate limit, one price and one outage.
- **Benefit** — `OUTREACH_AI_PROVIDER` switches, backends are imported lazily, and the
  credential pool supports several keys per provider with an opt-in fallback.
- **Trade-off** — five SDKs in `base.txt`, and each backend has to map its own errors —
  which is why `apps/ai/tests/test_backends.py` tests them one at a time.
- **Alternative** — one provider, or LiteLLM. LiteLLM would add a dependency to hide five
  thin modules that each do one thing.

### `cryptography` / Fernet for secrets

- **Problem** — AI keys, mailbox passwords and Supabase keys must survive at rest without
  being readable from the database alone.
- **Benefit** — authenticated encryption; the key is *derived* from `SECRET_KEY` by
  PBKDF2, so learning the signing key is not the same as being able to read the secrets.
- **Trade-off** — rotating `DJANGO_SECRET_KEY` makes every stored secret unreadable. Handled
  by returning `""` and falling back to the environment, and documented loudly.
- **Alternative** — a secrets manager (another service, another credential) or plaintext
  (unacceptable).

### SMTP directly, no transactional email API

- **Problem** — sending from the operator's own mailbox.
- **Benefit** — the recipient sees a real person's address; replies land in a real inbox
  that IMAP can read; no third party sees the content.
- **Trade-off** — no delivery webhooks, so bounces are detected by reading the mailbox
  rather than by a callback. Lower volume ceiling.
- **Alternative** — SendGrid or Postmark. Better analytics, but a bulk-sender reputation
  and a "via sendgrid.net" footer, which is the opposite of what a personal cold email
  needs.

### `geonamescache` for country/city data

- **Problem** — validating a city against a country without a network call.
- **Benefit** — offline, so `places.validate()` costs nothing and works with no network.
- **Trade-off** — a fixed snapshot; small towns may be missing.
- **Alternative** — a geocoding API call per validation. Slower, rate-limited, and
  needless.

### `openpyxl` for the export

- **Problem** — sent-lead history that opens in Excel.
- **Benefit** — a real `.xlsx` with formatting, not a CSV that mangles dates.
- **Trade-off** — a dependency used by exactly one feature.
- **Alternative** — CSV. Worse for dates and for anyone who opens it in Excel.

### ruff for linting

- **Problem** — consistent imports and no dead names across ~30k lines.
- **Benefit** — one tool, configured in `pyproject.toml`; the rule set is narrow on purpose
  (`E`, `F`, `W`, `I`) so it catches real defects rather than arguing about style.
- **Trade-off** — none worth mentioning.
- **Alternative** — flake8 + isort + black: three tools, three configs.

### Vanilla JavaScript, no build step

- **Problem** — interactive screens: polling progress, editing drafts, saving credentials.
- **Benefit** — no `node_modules`, no build, no bundle to invalidate. `git pull` +
  `collectstatic` is a deploy. 15 files, each matching one screen.
- **Trade-off** — no components; `credentials.js` has to mirror the markup Django writes,
  and that duplication is acknowledged in its own header comment.
- **Alternative** — React. A build step and a second dependency tree for a handful of
  screens.

---
### In simple words

Boring choices on purpose. Django because it comes with the ORM, auth and migrations;
SQLite because a fresh checkout should just run; cron because the jobs are minutes apart and
a broker would be a second thing to break; SMTP because a real mailbox gets real replies.
Each row says what it costs as well as what it buys.

---

# 30. Glossary

### General terms

| Term | In this project |
| --- | --- |
| **Lead** | A business that might be contacted. Before a campaign it is a `Lead` dataclass; inside one it is an `EmailDraft` row. |
| **Business** | The real-world shop or firm. Comes from OpenStreetMap. |
| **Campaign** | One job: a set of leads, a sender identity, a pitch, a mailbox. The `Campaign` model, primary key a UUID. |
| **Draft** | `EmailDraft` — one lead inside a campaign, carrying the crawl, the audit and the written email. |
| **Audit** | Reading and measuring one website. Cached as `WebsiteAudit`, one per domain per owner. |
| **Finding** | One thing wrong with a website, with the evidence for it. `apps/ai/base.py :: Finding`, id `AUD-001`. |
| **Evidence** | The measured signal a finding cites. A required schema property — a finding without one is invalid JSON. |
| **Signal** | One measured fact about a page: `cta_count`, `load_ms`, `has_viewport`. From `measurements.measure()`. |
| **Crawler** | `apps/auditing/crawler.py`. Fetches pages, obeys `robots.txt`, never raises. |
| **Suppression** | A do-not-contact entry: an email or a domain. The `Suppression` model. |
| **Bounce** | An email that could not be delivered. Detected by reading the mailbox, not by a webhook. |
| **Follow-up** | The second or third email to somebody who did not reply. `FollowUp`. **Always sent by a person.** |
| **Cron** | The scheduler. There is no job queue here — cron runs a management command. |
| **Migration** | A versioned schema change in `apps/*/migrations/`. 24 of them. |
| **ORM** | Django's object-relational mapper. Used for everything; there is no raw user-input SQL. |
| **Service** | A module in `apps/outreach/services/` where decisions live. Knows nothing about `HttpRequest`. |
| **Selector** | `apps/outreach/selectors.py` — the complex reads: filtering, sorting, pagination. |
| **Model** | A database table as a Python class. 13 of them. |
| **View** | A function that handles one request. Deliberately thin here. |
| **Worker** | Not a separate process. Either a cron-run command or a daemon thread in the web process. |

### Project-specific terms

| Term | Means |
| --- | --- |
| **Status vs phase** | On `Campaign`: `status` is what the operator wants (`active`, `paused`); `phase` is what the pipeline is doing right now (`crawling`, `generating`). Two fields, deliberately. |
| **Lifecycle** | `EmailDraft.lifecycle` — a sales stage (`new` … `won`/`lost`), separate from the pipeline `status`. |
| **Reservation** | `history.reserve()` — inserting a `SentLead` row **before** SMTP opens. The unique constraint on it is the duplicate guarantee. |
| **Claim** | A conditional `UPDATE` that exactly one worker can win. Used for plans, leads, follow-up numbers and audit jobs. |
| **Lease** | `AutomationPlan.locked_by` + `locked_until`, 600s. A lease rather than a lock, because a killed worker cannot release a lock. |
| **Plan** | `AutomationPlan` — a campaign's unattended configuration. `OneToOne` with `Campaign`; a plan *is* a campaign's schedule. |
| **Pass** | One run of `run_automation` over one plan. Up to `PASS_LIMIT = 25` leads. |
| **Day row** | `AutomationDay` — one row per plan per calendar day **in the plan's timezone**, and the atomic daily-target counter. |
| **Prospect search** | `ProspectSearch` — one country/city/category to search, recorded so it is not searched twice. |
| **Halt** | A reason a pass will not run, with a sentence. `Halt(reason, complete=True)` distinguishes "finished" from "not now". |
| **Courier** | `automation/courier.py :: Courier` — the sending mailbox during a pass, counting consecutive failures. |
| **Holder campaign** | The synthetic `Campaign` with `city = "Website audits"` that submitted-URL drafts belong to, because `EmailDraft` requires a campaign. |
| **Unspent** | A `FollowUp` in `waiting`, `skipped` or `failed` — a number the next run takes over rather than stepping past. |
| **Observation** | A short phrase drawn from the site ("wood-fired pizza since 1998") that makes an email specific. |
| **Style** | `apps/ai/styles.py` — an approved email template: `consultative` (210–560 words) or `brief` (80–175). |
| **Hedge** | Softening a claim that cannot be verified. `validation.hedge_findings()`, `HEDGES`. |
| **Replatform guard** | `scoring.unsupported_replatform()` — rejects a "you should rebuild" claim the measurements do not support. |
| **Bot wall** | A "prove you are human" page. `BOT_WALL_MARKERS` **detects** it and abandons the crawl. Nothing tries to get past it. |
| **Guard** | The callable `crawler.analyse(guard=...)` runs before every request **and every redirect hop**. `safeurl.guard`. |
| **Selection** | Which database was chosen, in `database.json`. Distinct from `active()`, which is what the running process has. |
| **Pending restart** | The selection and the live connection disagree — a switch has been recorded but not applied. |
| **Block send** | `OUTREACH_BLOCK_SEND` — blocks SMTP and IMAP outright. Forced on under `manage.py test`. |
| **Park / hold** | `pipeline._park()` / `_hold()` — pausing a campaign on an AI rate limit, with growing backoff. |
| **Stalled** | A campaign in a working phase with no thread behind it, because the server restarted. `pipeline.stalled()`. |

---

### In simple words

Two vocabularies to learn. The general terms mean roughly what you would expect. The
project-specific ones are worth reading twice — especially *status vs phase*, *reservation*,
*claim* and *lease*, because those four explain most of the code you will be surprised by.

---

# 31. Architecture Decisions

Each: the decision, the reason, the problem solved, the benefit, the trade-off, the
alternative.

### ADR-1 — cron and threads instead of Celery

- **Decision** Background work is a management command on a timer, plus daemon threads in
  the web process for supervised shapes.
- **Reason** The jobs are minutes apart, not milliseconds.
- **Problem solved** Work that must happen unattended, without a broker to run and monitor.
- **Benefit** One process to deploy, monitor and restart. A failed job is a log line.
- **Trade-off** Minutes of latency; no distributed fan-out; **exactly one Gunicorn worker**,
  because `pipeline._running` is per-process. This is the sharpest constraint in the design.
- **Alternative** Celery + Redis — three processes for latency nothing here needs.

### ADR-2 — evidence-only AI findings

- **Decision** The model is given only measured signals, `evidence` is a required schema
  property, and four separate code paths reject unsupported claims.
- **Reason** A confident, plausible, invented claim is worse than no claim. It is the
  failure mode that destroys trust in one email.
- **Problem solved** Making cold email specific at volume without inventing anything.
- **Benefit** Every sentence traces to something a recipient could verify by opening their
  own page.
- **Trade-off** Fewer findings per site, sometimes none. A site the crawler could not read
  produces an email that says nothing about the site.
- **Alternative** Asking the model "what's wrong with this website?" — cheaper, faster, and
  the thing that makes cold email spam.

### ADR-3 — manual follow-up approval

- **Decision** Follow-ups are drafted by machine and sent by a person. There is **no code
  path** from the follow-up worker to SMTP.
- **Reason** The worker exists so nobody has to keep a browser open for a 48-hour timer —
  not so nobody has to read the email before it goes to a stranger.
- **Problem solved** Follow-ups happening on time without unsupervised repeat contact.
- **Benefit** A second email is always seen by a person. Cannot be switched on by accident:
  `followup_autosend` is `False`, has no form field, and **is never read** (chapter 16).
- **Trade-off** Follow-ups stall if nobody visits the Follow-ups screen.
- **Alternative** Autosend after N days — one bug away from a stranger getting four emails.

### ADR-4 — the reservation, not a pre-flight check

- **Decision** A `SentLead` row is inserted **before** SMTP opens, and a `UniqueConstraint`
  decides.
- **Reason** "Check then send" loses the race between two workers. The database does not.
- **Problem solved** Never emailing the same address twice, under concurrency.
- **Benefit** Two workers race; exactly one wins; the loser raises `AlreadyContacted` and
  skips. No coordination needed.
- **Trade-off** A crash between the insert and the send leaves a `sending` row, so the
  address is not retried — which is the right side to fail on.
- **Alternative** A pre-flight `SELECT`, which is a race, or a distributed lock, which needs
  a broker.

### ADR-5 — two state fields on a campaign

- **Decision** `status` (what the operator wants) and `phase` (what the pipeline is doing)
  are separate.
- **Reason** "Paused because I said so" and "currently crawling" are different facts.
- **Benefit** A campaign can be `paused`/`review` or `active`/`crawling`; the UI can show
  both; `set_status()` validates against `ALLOWED` without touching the pipeline.
- **Trade-off** Two fields to reason about, and a table of legal transitions to maintain.
- **Alternative** One state machine with the cross-product of both — combinatorially worse.

### ADR-6 — the selection file, not a settings row

- **Decision** Which database to use lives in `database.json` in `DATA_DIR`.
- **Reason** The value being stored is *which database to open*. Reading it from the
  database would need the answer first.
- **Benefit** Readable while settings are being assembled; survives a container rebuild in
  the data volume; a missing file means "unchanged", so deploying the feature is a no-op.
- **Trade-off** A file to back up alongside the database; 0600 to manage.
- **Alternative** A settings row (impossible), or an env var only (no UI possible).

### ADR-7 — a switch requires a restart

- **Decision** Switching database records a choice; the process applies it on next start.
- **Reason** `DATABASES` is read once, and campaign work runs in threads holding connections
  from it. Swapping it under a running process with a campaign mid-crawl could corrupt two
  databases at once.
- **Benefit** No partially-migrated state, no in-flight request on the wrong database.
- **Trade-off** A restart. The page says so; `pending_restart()` drives a banner.
- **Alternative** Runtime swapping — fragile, and dangerous with worker threads.

### ADR-8 — three Supabase fields, and `DATABASE_URL` separately

- **Decision** The UI takes the project URL, anon key and service-role key. The **database
  connection** stays in `DATABASE_URL`.
- **Reason** Django connects to Postgres directly. Those three are PostgREST API
  credentials and cannot open a Postgres connection.
- **Benefit** No second copy of the database password; the page explains the requirement
  before a switch is attempted rather than failing later with an authentication error.
- **Trade-off** Two places to configure, and the page has to explain why.
- **Alternative** A fourth field for the connection string — a second copy of the password,
  in a browser form.

### ADR-9 — staff-only database settings

- **Decision** All five endpoints require `is_staff`.
- **Reason** Every other setting is per-account. This one decides which database
  *everybody's* data is in.
- **Trade-off** A fresh install has no staff account, so the page is invisible until
  somebody grants it. Documented, and the cause of one real support round trip.
- **Alternative** Any signed-in user — meaning any account could point the deployment
  elsewhere.

### ADR-10 — the crawler never raises

- **Decision** `analyse()` returns a status (`OK`, `BLOCKED`, `FAILED`, `NO_WEBSITE`).
- **Reason** A crawl failing is an ordinary outcome, not an exception. Most sites in a batch
  of 300 have something wrong with them.
- **Benefit** No caller needs a `try` around it; the failure is data with a sentence
  attached; `stopped` is kept separate from `status` so a cancelled read is not mistaken for
  an unreadable site.
- **Trade-off** Callers must check `SiteAnalysis.usable` — an ignored return value is a
  silent bug.
- **Alternative** Exceptions, which would put a `try/except` around every crawl.

### ADR-11 — the SSRF guard runs on every redirect hop

- **Decision** `guard` is called before the initial request **and every redirect**.
- **Reason** A public site is allowed to answer `302 Location: http://169.254.169.254/`.
  Validating only the submitted URL misses the actual attack.
- **Benefit** The interesting case is covered, not just the obvious one.
- **Trade-off** `allow_redirects=False` and a manual hop loop, bounded by `MAX_REDIRECTS`.
- **Alternative** Validating the submitted URL only — which is the common, broken pattern.

### ADR-12 — one function calls the AI

- **Decision** Every AI request goes through `apps/ai/client.py :: _complete()`.
- **Reason** Usage recording, safe failures and opt-in fallback belong together, and a
  second call site would need all three duplicated.
- **Benefit** "Activate the backup credential" takes effect everywhere at once with no other
  change. A new AI feature inherits every protection.
- **Trade-off** One function with three responsibilities. Its docstring says why they belong
  together.
- **Alternative** Per-feature provider calls — three copies of the retry and recording
  logic, drifting apart.

### ADR-13 — encryption derived from `SECRET_KEY`

- **Decision** Fernet under a PBKDF2-derived key, salt `outreach.credentials.v1`.
- **Reason** Secrets must survive at rest without being readable from a database dump alone.
- **Benefit** No extra credential to manage; deriving means the signing key alone is not
  enough to read the secrets.
- **Trade-off** Rotating `DJANGO_SECRET_KEY` makes every stored secret unreadable. Handled
  by returning `""` and falling back to the environment. **The salt can never change.**
- **Alternative** A secrets manager (another service and credential) or plaintext.

### ADR-14 — views decide nothing

- **Decision** Views parse, call a service, render. Decisions live in `apps/outreach/services/`, complex
  reads in `selectors.py`.
- **Reason** A decision inside a view can only be tested through an HTTP request, and cannot
  be reached by a cron job.
- **Benefit** The same code serves a click and a cron pass. `apps/outreach/services/followups.py` exists
  precisely because the automation runner needed logic that had been written inside a
  management command.
- **Trade-off** More files, and one more hop to read when tracing a request.
- **Alternative** Logic in views — which is how `process_followups` ended up being
  instantiated by a service, the wart that motivated the split.

### ADR-15 — tests cannot reach the outside world

- **Decision** `OUTREACH_BLOCK_SEND` is forced on under `manage.py test`, and a test asserts
  it. Every AI call and HTTP fetch is a double.
- **Reason** Real credentials live in `.env`. The line between a failing test and mail
  leaving the building should not be a mock somebody forgot.
- **Benefit** The suite runs offline and costs nothing; 1,642 tests in ~2 minutes.
- **Trade-off** Live behaviour needs the opt-in `tests/e2e/` and the `--live` commands.
- **Alternative** Trusting mocks — and one test did once hit the live Groq API, which is why
  this is a rule.

---

### In simple words

Fifteen decisions and why each one was made, including what it cost. If you are about to
change something structural — how background work runs, how the AI is constrained, how
duplicates are prevented — read the matching decision first. Each one names the alternative
that was rejected and why, which is usually the thing you are about to propose.

---

# 32. Known Limitations

### 1. Exactly one Gunicorn worker

- **Why** `pipeline._running` is a per-process set enforcing one job per campaign.
- **Now** With two workers, two Send clicks can start two jobs for the same campaign.
- **Workaround** `--workers 1 --threads 8`, as DEPLOY.md §1 and §10 specify.
- **Future** Move the run claim into the database (the automation runner already does this
  with `claim()`), then workers become safe.

### 2. WhatsApp detection — **NOT IMPLEMENTED**

- **Where** `apps/outreach/selectors.py :: apply_whatsapp_filter()`, whose docstring says
  "Placeholder until Task 3 adds detection."
- **Now** `unknown` matches everything; `available` and `unavailable` match nothing
  (`rows.none()`). There is **no `whatsapp` field** on `EmailDraft` — only `phone`.
  `contacts.py :: SOCIAL_HOSTS` does recognise `wa.me` and `api.whatsapp.com` as social
  links, but nothing acts on it.
- **Why deliberate** Answering "available" for a lead nobody checked would be exactly the
  guess the project forbids. Tested: `test_intelligence.py :: test_whatsapp_is_never_guessed`.
- **Future** Detect from harvested `wa.me` links, add a field, then make the filter real.

### 3. `followup_autosend` — **DISABLED**, and its comment is wrong

- **Where** `apps/outreach/models/automation.py`, line 117.
- **Now** Always `False`; no form field; **and nothing reads it**. Unattended follow-up
  sending does not exist.
- ⚠️ **The comment says "refused by `clean()`" — `AutomationPlan` has no `clean()` method.**
  Its methods are `__str__`, `sent_total`, `remaining_total`, `target_reached`, `day`. The
  protection is real but structural (no code path) rather than conditional (a checked flag),
  so the comment overstates one mechanism and understates the actual one.
- **Fix** Correct the comment to say the flag is never consulted and no send path exists.
- **Future** Implementing it means a send path, a validated way to enable it, and tests for
  every refusal.

### 4. No hourly send limit, no randomised delay

- **Now** Pacing is a per-message delay (2.5–3.5s) plus a daily cap. There is no separate
  hourly counter and no maximum-delay jitter — both **NOT IMPLEMENTED**.
- **Why** A daily cap plus a per-message floor bounds the hourly rate implicitly.
- **Workaround** `AutomationPlan.send_gap_seconds` adds a fixed extra gap.
- **Future** A randomised gap between a min and max would look less mechanical.

### 5. Django admin — **NOT IMPLEMENTED**

- **Now** `django.contrib.admin` is not in `INSTALLED_APPS` and no `admin.py` exists.
  `createsuperuser` works (it is `contrib.auth`), and `is_staff` is used only to gate
  Settings → Database.
- **Why** Every screen this project needs is purpose-built; a generic CRUD interface over
  13 models with encrypted fields invites editing something that should go through a service.
- **Workaround** `manage.py shell`.

### 6. Self-hosted Supabase cannot be configured in the UI

- **Where** `apps/core/database.py :: validate_url()` requires a `*.supabase.co` host.
- **Why** The server fetches that URL with a service-role key in the headers; an
  unrestricted host would be an SSRF hole.
- **Workaround** Set `SUPABASE_URL` in the environment; the page marks the field read-only.

### 7. A database switch needs a restart

- **Why** ADR-7 — `DATABASES` is read once and worker threads hold connections from it.
- **Now** The choice is recorded and applied on the next start; the page says so.
- **Workaround** Restart the service.

### 8. Bounce detection needs a mailbox scan

- **Now** `check_replies` reads IMAP on a schedule. A bounce is noticed within 30 minutes,
  not instantly. No delivery webhooks — a consequence of sending over SMTP rather than
  through a transactional API (ADR: "SMTP directly").
- **Workaround** Run `check_replies` more often.

### 9. A soft bounce leaves no trace — IMPLEMENTED correctly, but silently

- **Now** `mail/inbox.py` line ~310 checks `is_permanent_bounce()` and returns an empty
  `Verdict()` for a 4.x.x deferral, with the reason in a comment: "Recording it as bounced
  would close a live lead." So a temporary failure correctly does **not** suppress the
  contact.
- **The gap** it also records nothing at all — no counter, no event. A mailbox that
  deferred five times looks identical to one that never bounced, so a slow-failing address
  is invisible until it becomes a hard bounce.
- **Workaround** none needed for correctness; this is an observability gap, not a defect.
- **Future** count deferrals on `SentLead` (or a `CampaignEvent`) so a repeatedly deferring
  address can be seen before it turns permanent.

### 10. `geonamescache` is a fixed snapshot

- **Now** Small towns may be missing from `cities_for()`, so `validate()` rejects them.
- **Workaround** Use the nearest larger city; the bounding box usually covers it.

### 11. Overpass is slow and rate-limited

- **Now** `QUERY_TIMEOUT = 90`; three mirrors tried in order. A large city can take a
  minute.
- **Workaround** Smaller areas, or narrower categories.

### 12. Text in images cannot be read

- **Now** A contact address or a phone number that exists only inside an image is invisible.
  The lead becomes `no_email`.
- **Why** No OCR, deliberately.

### 13. No delivery, open or click tracking

- **Now** Only replies, bounces and unsubscribes, from reading the mailbox.
- **Why** Tracking pixels and rewritten links are exactly the markers that make a personal
  email look like bulk mail.

### 14. Cancel is not instant

- **Now** `should_stop` is checked before every request; the request in flight cannot be
  aborted. Cancel takes effect within one page — up to `TIMEOUT = 15s`.
- **Why** Aborting mid-request risks a partially-read response.

### 15. The `.env` loader is minimal

- **Now** `config/settings/base.py :: _load_env()` is a small parser. `EnvFileTests` in
  `tests/integration/test_settings.py` covers it, but it is not a full dotenv
  implementation — no multi-line values, no variable interpolation.
- **Why** No dependency for something that reads `KEY=value`.

### 16. `docs/make_workflow.py` needs pillow

- **Now** Only in `requirements/development.txt`. Running it from a production install
  fails.
- **Why** A diagram generator has no business in a served image.

### 17. Two accounts exist, one is unowned data

- **Now** 12 campaigns in the live database have no owner (`owner=None`), from before
  accounts existed. They are invisible on every owned page.
- **Workaround** `python manage.py claim_data you@example.com`.

### In simple words

The big three: run only one Gunicorn worker, a database switch needs a restart, and
follow-ups never send themselves. WhatsApp filtering and the Django admin do not exist — the
first is an honest placeholder, the second was left out on purpose. And one code comment
about `followup_autosend` names a `clean()` method that is not there.

---

# 33. Future Roadmap

Only what the current code makes reachable.

### Now — small, and the code is already shaped for it

| Item | Why it is easy | Where |
| --- | --- | --- |
| **Fix the `followup_autosend` comment** | A comment naming a `clean()` that does not exist | `apps/outreach/models/automation.py:113-116` |
| **Claim the 12 unowned campaigns** | The command exists | `manage.py claim_data you@example.com` |
| **Rotate the exposed credentials** | Carried over from earlier work | Gmail app password, Groq key, Supabase keys |
| **Separate soft and hard bounces** | `is_permanent_bounce()` already distinguishes them | `apps/outreach/mail/inbox.py`, plus a `reply_state` value |
| **A randomised send gap** | One number becomes a range | `apps/outreach/services/automation/courier.py`, `AutomationPlan` |
| **Verify the Dockerfile builds** | Changed but never built — no daemon available here | `Dockerfile` |

### Next — a few days each

| Item | What it needs |
| --- | --- |
| **WhatsApp detection** | Harvest `wa.me` links (`SOCIAL_HOSTS` already recognises them), add a field to `EmailDraft` and a migration, then make `apply_whatsapp_filter()` real. Keep `test_whatsapp_is_never_guessed` passing. |
| **Move the run claim into the database** | Replace `pipeline._running` with a conditional `UPDATE`, the way `automation/runner.py :: claim()` already does. **This is what unblocks more than one Gunicorn worker** — the single sharpest limitation. |
| **A CampaignEvent timeline screen** | The rows and 17 event kinds exist; only a page is missing. |
| **Per-campaign email style choice in the UI** | `template_key` and `STYLES` exist; the form does not offer it. |
| **A `manage.py grant_staff` command** | Turns a documented shell one-liner into a command, so Settings → Database is reachable without copy-pasting Python. |
| **Soft-bounce retry** | Once soft and hard bounces are separated, a temporary failure can be retried rather than suppressing the contact. |

### Later — real design work first

| Item | Why it is not "next" |
| --- | --- |
| **More than one worker process** | Needs the run claim moved (above) *and* an audit of every in-process assumption: `pipeline._running`, the daemon threads, `_FERNETS`, the robots cache. |
| **A reply classifier** | "Interested" vs "not now" vs "remove me" is a judgement call, and getting it wrong means mailing somebody who declined. Needs the same evidence discipline as the audit. |
| **Delivery webhooks** | Means a transactional email API, which means losing "sent from a real mailbox that a human replies to" — the trade-off in ADR "SMTP directly". |
| **Multi-user teams** | Every model is `owner`-scoped to one user. Shared workspaces means a team model, roles, and revisiting every `_my_*` lookup. |
| **The Django admin** | Adding it means deciding which of 13 models are safe to edit outside a service, given encrypted fields and status machines. |
| **A second language for emails** | Prompts, `BANNED_PHRASES`, `HEDGES` and the validators are all English-specific. |
| **OCR for images** | Would find addresses in image-only contact pages. New dependency, new failure modes, modest gain. |

### Deliberately not planned

| Not planned | Why |
| --- | --- |
| Celery / Redis | ADR-1. Nothing here needs sub-minute latency. |
| Open and click tracking | The markers that make a personal email look like bulk mail. |
| Automatic follow-up sending | ADR-3. The whole point is that a person reads it. |
| Bypassing bot walls or CAPTCHAs | `BOT_WALL_MARKERS` detects and abandons, on purpose. |
| Guessing email addresses | ADR-2's sibling rule. Multiple tests assert the no-email path stays a no-send. |
| A frontend framework | 15 vanilla JS files, no build step. |

---

### In simple words

Three things to do soon: fix one wrong code comment, claim the twelve unowned campaigns, and
rotate the exposed keys. One thing worth real effort: move the run claim into the database,
because that single change is what would let this run on more than one worker process.
Everything in "deliberately not planned" is a decision, not a backlog.

---

## Appendix — verification of this document

Every path, class and function named here was checked to exist. The figures were produced by
running the code, not estimated:

```
python manage.py test                       Ran 1642 tests — OK (skipped=6)
ruff check .                                All checks passed!
python manage.py check                      System check identified no issues (0 silenced)
python manage.py check --deploy             2 warnings — both documented opt-ins (ch. 19)
python manage.py makemigrations --check      No changes detected
python manage.py migrate --plan              No planned migration operations

69 URL routes           config/urls.py, resolved
13 models               django.apps.get_models(), introspected
24 migrations           23 outreach + 1 ai
25 templates            templates/**/*.html
15 JavaScript files     static/js/
167 Python modules      apps/ + config/ + tests/, excluding migrations
```

**Marked as not implemented:** WhatsApp detection (ch. 32.2), the Django admin (32.5),
unattended follow-up sending (16, 32.3), an hourly send limit and randomised delay (13,
32.4).

**Contradiction found between a code comment and the code** — one, recorded in chapters 16
and 32.3: `followup_autosend`'s comment says "refused by `clean()`", but `AutomationPlan`
defines no `clean()`. The effect (follow-ups never auto-send) is correct and in fact
stronger than the comment claims, because the flag is never read at all.
