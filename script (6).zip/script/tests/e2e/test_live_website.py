"""
One test that reads a real public website.

Opt-in, and skipped without `LIVE_WEB_TESTS=1` and a network. It exists because
every other crawler test uses HTML this repository wrote, and HTML this repository
wrote is HTML that behaves. Nothing here sends an email or calls a paid API.
"""

from __future__ import annotations

from apps.auditing import crawler
from apps.core.testing import SignedIn


@__import__("unittest").skipUnless(
    __import__("os").environ.get("LIVE_WEB_TESTS") == "1",
    "set LIVE_WEB_TESTS=1 to fetch a real website",
)
class LiveWebsiteTests(SignedIn):
    """Reads one real public website. Opt-in, and needs a network."""

    def setUp(self):
        crawler._robots.clear()
        crawler._last_hit.clear()

    def test_reads_a_real_site_and_obeys_its_robots_txt(self):
        result = crawler.analyse("https://www.python.org")

        self.assertEqual(result.status, crawler.OK)
        self.assertTrue(result.usable)
        self.assertTrue(result.pages[0].title)
        self.assertGreater(len(result.pages[0].text), 200)
        self.assertIn("python", result.as_context().lower())

    def test_a_domain_that_does_not_resolve_fails_cleanly(self):
        result = crawler.analyse("https://this-domain-does-not-exist-zzqq.example")

        self.assertEqual(result.status, crawler.FAILED)
        self.assertIn("Could not read", result.detail)
