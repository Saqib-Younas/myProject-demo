"""The tests that touch the outside world.

Opt-in, and skipped by default: they need a network, and a suite that silently depends
on somebody else's uptime is a suite that fails for reasons unrelated to this code.

    LIVE_WEB_TESTS=1 python manage.py test tests.e2e

Even here, nothing sends an email and nothing calls a paid API. The only external thing
touched is one public website, read the same way the crawler reads any other.
"""
