"""Tests that are about more than one app.

Everything that belongs to a single app lives in that app's `tests/` package, next to
what it tests. What is left over is here:

    integration/   settings and the database URL, exercised the way a deployment reads
                   them -- against a real file and a real environment
    e2e/           the one test that reads a real public website, opt-in and skipped
                   without a network

Nothing in here sends an email or calls a paid API.
"""
