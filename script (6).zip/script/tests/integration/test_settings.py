"""
Settings, read the way a deployment reads them.

Not a unit test of a function: these exercise the loader against a real file on disk
and the environment it produces, because the failure they exist to prevent is a
deployment reading the wrong value and nobody noticing.

The thing being protected is narrow and important: the live mailbox password lives in
`.env` and must never end up in a settings module, a traceback or a log line.
"""

from __future__ import annotations

from unittest import mock

from django.conf import settings

from apps.core.testing import SignedIn


class EnvFileTests(SignedIn):
    """The .env loader keeps the live password out of settings.py."""

    def _load(self, text: str, existing: dict | None = None) -> dict:
        import os
        import tempfile
        from pathlib import Path

        from config.settings import base as project_settings

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / ".env"
            path.write_text(text, encoding="utf-8")
            base = {k: v for k, v in os.environ.items()
                    if not k.startswith("ZZ_TEST_")}
            base.update(existing or {})
            with mock.patch.dict(os.environ, base, clear=True):
                project_settings._load_env(path)
                return {k: v for k, v in os.environ.items()
                        if k.startswith("ZZ_TEST_")}

    def test_key_values_are_loaded(self):
        loaded = self._load("ZZ_TEST_A=hello\nZZ_TEST_B=world\n")

        self.assertEqual(loaded, {"ZZ_TEST_A": "hello", "ZZ_TEST_B": "world"})

    def test_comments_and_blank_lines_are_ignored(self):
        loaded = self._load("# a comment\n\nZZ_TEST_A=hello\n")

        self.assertEqual(loaded, {"ZZ_TEST_A": "hello"})

    def test_values_containing_spaces_survive(self):
        loaded = self._load("ZZ_TEST_A=abcd efgh ijkl mnop\n")

        self.assertEqual(loaded["ZZ_TEST_A"], "abcd efgh ijkl mnop")

    def test_quotes_are_stripped(self):
        loaded = self._load('ZZ_TEST_A="quoted"\n')

        self.assertEqual(loaded["ZZ_TEST_A"], "quoted")

    def test_a_real_environment_variable_wins(self):
        # CI and one-off shell overrides must beat the file.
        loaded = self._load("ZZ_TEST_A=from-file\n",
                            existing={"ZZ_TEST_A": "from-env"})

        self.assertEqual(loaded["ZZ_TEST_A"], "from-env")

    def test_a_missing_file_is_not_an_error(self):
        from pathlib import Path

        from config.settings import base as project_settings

        project_settings._load_env(Path("no-such-file-here.env"))  # must not raise
class ConfiguredIdentityTests(SignedIn):
    """The one address the app is set up to use."""

    def test_both_addresses_are_configured_and_look_like_addresses(self):
        """They serve different purposes and may legitimately differ.

        OSM_CONTACT_EMAIL is advertised in the User-Agent when fetching data;
        OUTREACH_SENDER_EMAIL is the From header and the SMTP login. Using a
        role address for crawling and a personal one for sending is a reasonable
        setup, so this checks both are usable rather than that they match.
        """
        for name in ("OUTREACH_SENDER_EMAIL", "OSM_CONTACT_EMAIL"):
            with self.subTest(setting=name):
                value = getattr(settings, name)
                self.assertTrue(value, f"{name} must be set")
                self.assertRegex(value, r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
                self.assertNotIn("example.com", value)

    def test_the_provider_matches_the_address_domain(self):
        domain = settings.OUTREACH_SENDER_EMAIL.rsplit("@", 1)[-1].lower()
        if domain in ("gmail.com", "googlemail.com"):
            self.assertEqual(settings.OUTREACH_PROVIDER, "gmail")

    def test_no_password_is_hardcoded_in_settings(self):
        """The live password must live in .env, never in tracked source."""
        from pathlib import Path

        source = (Path(settings.BASE_DIR) / "config" / "settings" / "base.py").read_text(
            encoding="utf-8")

        self.assertNotIn("OUTREACH_SMTP_PASSWORD =", source)
        self.assertIn("_load_env", source)
