"""
The selection, read the way a process actually reads it.

Everything else about this feature can be tested in-process. This cannot: the claim is
about what `config/settings/base.py` does when a *new* interpreter starts, which is the
only thing that decides which database a deployment opens and the only thing a cron job
does. So these tests start real subprocesses.

They are slow -- a few seconds each -- and there are four of them, which is the right
number. Each one asserts something that would be a serious bug and that no in-process test
can reach:

  * a deployment with `DATABASE_URL` set and no selection recorded still uses Postgres,
    which is what makes deploying this feature a no-op;
  * a recorded choice of "local" makes the same deployment ignore `DATABASE_URL`, which
    is what makes the button work;
  * a cron job sees the selection, because it is a file and not process state;
  * a corrupt selection file does not stop a process from starting.

`DJANGO_DATA_DIR` points each subprocess at its own temporary directory, so none of them
can see or write the real one.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

from django.test import SimpleTestCase

#: A Supabase-shaped connection string. Never opened -- these tests read
#: `settings.DATABASES`, they do not connect.
DSN = ("postgresql://postgres.abcdefgh:pw@aws-0-eu-west-2.pooler.supabase.com"
       ":6543/postgres")

#: Printed by the subprocess: the engine, and what `apps.core.database` makes of it.
PROBE = (
    "import django; django.setup();"
    "from django.conf import settings;"
    "from apps.core import database;"
    "print(settings.DATABASES['default']['ENGINE'], database.active(),"
    "      repr(database.selection()))"
)


class SubprocessSelection(SimpleTestCase):
    """Run the probe in a fresh interpreter with a chosen environment."""

    def probe(self, *, selection=None, database_url=None, raw_state=None):
        with tempfile.TemporaryDirectory() as tmp:
            if raw_state is not None:
                (Path(tmp) / "database.json").write_text(raw_state, encoding="utf-8")
            elif selection is not None:
                (Path(tmp) / "database.json").write_text(
                    json.dumps({"selection": selection}), encoding="utf-8")

            environment = {
                **os.environ,
                "DJANGO_SETTINGS_MODULE": "config.settings.development",
                "DJANGO_DATA_DIR": tmp,
            }
            environment.pop("DATABASE_URL", None)
            if database_url:
                environment["DATABASE_URL"] = database_url

            finished = subprocess.run(
                [sys.executable, "-c", PROBE],
                capture_output=True, text=True, env=environment,
                cwd=str(Path(__file__).resolve().parents[2]), timeout=120,
            )
        self.assertEqual(finished.returncode, 0,
                         f"the probe failed:\n{finished.stderr[-2000:]}")
        engine, active, chosen = finished.stdout.strip().splitlines()[-1].split(None, 2)
        return engine, active, chosen


class NoSelectionTests(SubprocessSelection):
    """The state every existing deployment is in."""

    def test_without_a_selection_sqlite_is_the_default(self):
        engine, active, chosen = self.probe()
        self.assertEqual(engine, "django.db.backends.sqlite3")
        self.assertEqual(active, "local")
        self.assertEqual(chosen, "''")

    def test_without_a_selection_database_url_is_still_honoured(self):
        """The one that makes this feature safe to deploy.

        A site already running on Supabase has `DATABASE_URL` set and no selection
        file. If shipping this page moved it onto SQLite, every campaign, draft and
        sent-lead record would appear to have vanished.
        """
        engine, active, chosen = self.probe(database_url=DSN)
        self.assertEqual(engine, "django.db.backends.postgresql")
        self.assertEqual(active, "supabase")
        self.assertEqual(chosen, "''")


class RecordedSelectionTests(SubprocessSelection):
    def test_choosing_local_makes_database_url_be_ignored(self):
        """The asymmetry, deliberately.

        Choosing "local" has to override the environment or the button does nothing on
        any deployment that would want it. Choosing "supabase" cannot invent a
        connection, which is why the page refuses that switch instead of recording it.
        """
        engine, active, chosen = self.probe(selection="local", database_url=DSN)
        self.assertEqual(engine, "django.db.backends.sqlite3")
        self.assertEqual(active, "local")
        self.assertEqual(chosen, "'local'")

    def test_choosing_supabase_uses_database_url(self):
        engine, active, chosen = self.probe(selection="supabase", database_url=DSN)
        self.assertEqual(engine, "django.db.backends.postgresql")
        self.assertEqual(active, "supabase")
        self.assertEqual(chosen, "'supabase'")

    def test_choosing_supabase_without_database_url_stays_on_sqlite(self):
        """Belt and braces.

        The page will not record this state -- it refuses the switch when
        `DATABASE_URL` is missing. If it somehow arose, the process still starts and
        serves from the local database rather than failing to boot.
        """
        engine, active, _ = self.probe(selection="supabase")
        self.assertEqual(engine, "django.db.backends.sqlite3")
        self.assertEqual(active, "local")

    def test_a_corrupt_selection_file_does_not_stop_a_process_starting(self):
        engine, _, chosen = self.probe(raw_state="{ truncated", database_url=DSN)
        self.assertEqual(engine, "django.db.backends.postgresql")
        self.assertEqual(chosen, "''")


class CronTests(SubprocessSelection):
    """A scheduled job is a new process, so it reads the selection like any other.

    This is the whole mechanism behind "cron uses the active database". There is no
    second place to configure and nothing to keep in step: `manage.py` in a cron line
    loads the same settings module, which reads the same file.
    """

    def test_a_management_command_uses_the_selected_database(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / "database.json").write_text(
                json.dumps({"selection": "local"}), encoding="utf-8")
            environment = {
                **os.environ,
                "DJANGO_SETTINGS_MODULE": "config.settings.development",
                "DJANGO_DATA_DIR": tmp,
                "DATABASE_URL": DSN,
                # The suite's own guard, kept on: a command run here must not be able
                # to open SMTP or IMAP.
                "OUTREACH_BLOCK_SEND": "1",
            }
            finished = subprocess.run(
                [sys.executable, "manage.py", "diffsettings", "--output", "unified"],
                capture_output=True, text=True, env=environment,
                cwd=str(Path(__file__).resolve().parents[2]), timeout=120,
            )
        self.assertEqual(finished.returncode, 0, finished.stderr[-2000:])
        # `diffsettings` prints what differs from Django's defaults. The selection said
        # local, so the engine in effect for this command is SQLite despite the
        # DATABASE_URL in its environment.
        self.assertIn("sqlite3", finished.stdout)
        self.assertNotIn("pooler.supabase.com", finished.stdout)
