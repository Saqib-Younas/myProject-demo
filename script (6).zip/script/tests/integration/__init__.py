"""Configuration, read the way a deployment reads it.

These are not unit tests of a parsing function. They write a real `.env` to a real
temporary directory and check what the loader puts in the environment, because the
failure they exist to prevent is a deployment quietly reading the wrong value -- a
`DATABASE_URL` that falls back to SQLite, or a password that ends up somewhere it can
be read.
"""
