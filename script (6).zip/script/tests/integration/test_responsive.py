"""
The responsive rules, checked structurally.

**What this suite is and is not.** It cannot see pixels. There is no browser here, so
nothing below proves that a page *looks* right at 320px — only that the structures which
cause horizontal overflow are absent and the ones that prevent it are present. Visual
confirmation at the widths in the brief is a manual step, and saying otherwise would be
the kind of claim this project's tests exist to prevent.

What it does catch, which is most of what actually breaks:

  * a table that is not inside a scroll container, so the *page* scrolls instead of the
    table;
  * a grid whose minimum track is wider than a phone;
  * a hard-coded pixel width on a layout element;
  * the drawer markup or its script missing from a page;
  * `viewport` meta missing, which makes every other rule irrelevant.

These are the regressions a later edit introduces without noticing, which is exactly what
a test is for.
"""

from __future__ import annotations

import pathlib
import re

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

REPO = pathlib.Path(__file__).resolve().parents[2]
TEMPLATES = REPO / "templates"
CSS = REPO / "static" / "css"

#: The narrowest viewport the brief names. Everything below is measured against it.
NARROWEST = 320

#: Page padding at phone width: `.page-wrap { padding: ... var(--sp-3) }`, both sides.
PAGE_PADDING = 12 * 2


def stylesheets() -> str:
    return "\n".join(p.read_text(encoding="utf-8") for p in sorted(CSS.glob("*.css")))


def declarations() -> str:
    """Every stylesheet with its comments removed.

    Needed because this project comments its CSS heavily, and an `assertIn` for a
    property name will happily match the comment that explains it — which is how a test
    here once passed with the very declaration it was guarding deleted. Assert on this
    when the subject is a declaration rather than prose.
    """
    return re.sub(r"/\*.*?\*/", "", stylesheets(), flags=re.S)


def templates() -> list[pathlib.Path]:
    return sorted(TEMPLATES.rglob("*.html"))


class ViewportTests(TestCase):
    """Without this meta tag, a phone renders at 980px and lies about it."""

    def test_the_viewport_meta_is_present(self):
        base = (TEMPLATES / "shared" / "base.html").read_text(encoding="utf-8")

        self.assertIn('name="viewport"', base)
        self.assertIn("width=device-width", base)

    def test_the_auth_pages_have_it_too(self):
        """They extend a different base, so they are a separate risk."""
        auth = (TEMPLATES / "accounts" / "auth_base.html").read_text(encoding="utf-8")

        self.assertIn("width=device-width", auth)


class OverflowGuardTests(TestCase):
    def test_the_page_cannot_scroll_sideways(self):
        css = stylesheets()

        self.assertIn("overflow-x: clip", css)

    def test_both_overflow_axes_are_named_on_the_root(self):
        """Naming only one axis is a bug, and it was one here.

        Per CSS Overflow 3, when one of `overflow-x`/`overflow-y` is `clip` and the
        other is `visible`, the `visible` one computes to `hidden`. So `overflow-x: clip`
        on its own gave `overflow-y: hidden` too — a scroll container, which breaks
        `position: sticky` on the topbar and stops the document scrolling. The leads page,
        the only one with a full-height flex layout, was where it showed.
        """
        css = declarations()
        rule = re.search(r"^html\s*\{([^}]*)\}", css, re.M)

        self.assertIsNotNone(rule, "no `html` rule setting overflow")
        body = rule.group(1)
        self.assertIn("overflow-x: clip", body)
        self.assertIn("overflow-y:", body,
                      "name overflow-y too, or it computes to hidden")
        self.assertNotIn("overflow-y: hidden", body)

    def test_the_body_is_left_without_an_overflow_value(self):
        """`body` is a flex column at `height: 100%` and the leads page fills it with a
        map. Any overflow value there re-creates the problem one level down."""
        css = declarations()
        for rule in re.finditer(r"^body\s*\{([^}]*)\}", css, re.M):
            self.assertNotIn("overflow", rule.group(1))


    def test_no_grid_minimum_is_wider_than_the_narrowest_phone(self):
        """A `minmax(340px, 1fr)` track overflows a 320px screen.

        `min(340px, 100%)` is the fix and reads as an exception here, so a bare pixel
        minimum above the content width fails.
        """
        usable = NARROWEST - PAGE_PADDING
        offenders = []
        for match in re.finditer(r"minmax\(\s*(\d+)px", stylesheets()):
            width = int(match.group(1))
            if width > usable:
                context = stylesheets()[max(0, match.start() - 90):match.start()]
                selector = (context.strip().splitlines() or [""])[-1]
                offenders.append(f"minmax({width}px …) near {selector.strip()[:60]!r}")

        self.assertEqual(
            offenders, [],
            f"grid tracks with a minimum wider than {usable}px of usable width. "
            "Wrap the minimum in min(Npx, 100%) so the track can collapse:\n  "
            + "\n  ".join(offenders))

    def test_no_flex_child_has_a_minimum_wider_than_a_phone(self):
        """The same hazard as an over-wide grid track, in its other shape.

        A flex item with `min-width: 240px` cannot shrink below it, so in a container
        narrower than that -- a card on a 320px screen has about 264px of inner width --
        it pushes past the edge. `min(240px, 100%)` keeps the intent and drops it when
        there is no room, which is why that form reads as the exception here.

        The 150px floor is deliberate: below it these are icons, badges and short
        labels, not layout minimums, and flagging them would be noise.
        """
        offenders = []
        for path in sorted(CSS.glob("*.css")):
            text = path.read_text(encoding="utf-8")
            selector = ""
            for number, line in enumerate(text.splitlines(), 1):
                stripped = line.strip()
                if stripped and not stripped.startswith(("/*", "*", "@")) and "{" in stripped:
                    selector = stripped.split("{")[0].strip()
                found = re.search(r"min-width:\s*(\d+)px", stripped)
                if found and int(found.group(1)) >= 150:
                    offenders.append(
                        f"{path.name}:{number} {selector[:40]} "
                        f"min-width:{found.group(1)}px")

        self.assertEqual(
            offenders, [],
            "flex/grid children with a fixed minimum wide enough to overflow a phone. "
            "Wrap it in min(Npx, 100%):\n  " + "\n  ".join(offenders))

    def test_long_unbreakable_strings_are_allowed_to_wrap(self):
        """Email addresses, domains and ids have no spaces to wrap at."""
        css = stylesheets()

        self.assertIn("overflow-wrap: anywhere", css)
        # The classes that actually carry those values.
        for selector in (".mono", ".kv dd", ".mailbox-name"):
            self.assertIn(selector, css)


class MapStackingTests(TestCase):
    """The map may not paint over the header.

    Leaflet stacks its own layers up to `z-index: 1000` (the control corners), and
    `.pin.is-active` is 1000. The topbar is 900. `#map` is `position: absolute` with
    `z-index: auto`, so it creates no stacking context — every one of those layers was
    competing in the root context, above the header, and the navigation stopped taking
    clicks whenever a map was on screen.
    """

    def test_the_map_wrapper_is_a_stacking_context(self):
        css = declarations()
        rule = re.search(r"^\.map-wrap\s*\{([^}]*)\}", css, re.M)

        self.assertIsNotNone(rule, "no `.map-wrap` rule")
        self.assertIn("isolation: isolate", rule.group(1),
                      "without a stacking context, Leaflet's z-index 1000 layers paint "
                      "above the z-index 900 topbar")

    def test_the_topbar_is_above_everything_that_is_not_a_dialog(self):
        """The ladder: map (contained) < topbar < drawer < modal < toasts."""
        css = declarations()

        def z(selector):
            rule = re.search(rf"^{re.escape(selector)}\s*\{{([^}}]*)\}}", css, re.M)
            found = re.search(r"z-index:\s*(\d+)", rule.group(1)) if rule else None
            return int(found.group(1)) if found else None

        topbar = z(".topbar")
        scrim = z(".nav-scrim")

        self.assertIsNotNone(topbar)
        self.assertLess(topbar, scrim, "the drawer scrim must cover the header")
        # And the modal covers the drawer.
        self.assertIn("z-index: 1100", css)


class TableTests(TestCase):
    """A table is the one thing allowed to scroll horizontally — inside its own box."""

    def test_every_table_sits_inside_a_scroll_container(self):
        loose = []
        for path in templates():
            text = path.read_text(encoding="utf-8")
            if "<table" not in text:
                continue
            # Each `<table>` must be preceded, somewhere above it, by a scroll wrapper
            # that has not yet closed. Checked by counting rather than parsing, which
            # is enough to catch a table added without one.
            for match in re.finditer(r"<table", text):
                before = text[:match.start()]
                opened = before.count("table-scroll")
                if opened == 0:
                    loose.append(f"{path.relative_to(REPO).as_posix()}")
                    break

        self.assertEqual(
            loose, [],
            "these templates have a <table> with no .table-scroll container, so the "
            "page will scroll sideways instead of the table:\n  " + "\n  ".join(loose))

    def test_the_scroll_container_actually_scrolls(self):
        self.assertIn("overflow-x: auto", stylesheets())


class FixedWidthTests(TestCase):
    """A hard pixel width on a layout element is how a phone ends up scrolling."""

    #: Inline widths that are fine: icons, avatars, small square controls. The number
    #: is the ceiling — anything wider than this is a layout decision, not an icon.
    DECORATIVE_MAX = 120

    def test_no_template_sets_a_wide_fixed_width_inline(self):
        offenders = []
        for path in templates():
            text = path.read_text(encoding="utf-8")
            # `(?<![-a-z])` so `max-width` and `min-width` do not match: both are the
            # responsive patterns, and a bare `width` is the one that pins a
            # layout to a pixel count.
            for match in re.finditer(
                    r"style=\"[^\"]*?(?<![-a-z])width:\s*(\d+)px", text):
                if int(match.group(1)) > self.DECORATIVE_MAX:
                    offenders.append(
                        f"{path.relative_to(REPO).as_posix()}: width:{match.group(1)}px")

        self.assertEqual(
            offenders, [],
            "inline pixel widths wider than an icon. Use a max-width, a percentage or "
            "a grid track instead:\n  " + "\n  ".join(offenders))


class DrawerTests(TestCase):
    """The mobile navigation. Present on every page, and driven by real markup."""

    PAGES = ("dashboard", "leads:index", "outreach:settings", "outreach:followups",
             "outreach:history", "outreach:suppressions", "outreach:audits",
             "outreach:automation", "outreach:audit_new")

    def setUp(self):
        self.user = get_user_model().objects.create_user(
            "sam", "sam@agency.test", "responsive-test-password-42")
        self.client.force_login(self.user)

    def test_every_page_carries_the_drawer_and_its_script(self):
        for name in self.PAGES:
            with self.subTest(page=name):
                body = self.client.get(reverse(name)).content.decode()

                self.assertIn('id="nav-toggle"', body)
                self.assertIn('id="site-nav"', body)
                self.assertIn('id="nav-scrim"', body)
                self.assertIn("js/nav.js", body)

    def test_the_toggle_is_a_real_button_with_the_right_state(self):
        body = self.client.get(reverse("dashboard")).content.decode()

        self.assertIn('aria-expanded="false"', body)
        self.assertIn('aria-controls="site-nav"', body)
        self.assertIn('aria-label="Open menu"', body)

    def test_the_scrim_is_inert_until_the_drawer_opens(self):
        """A full-screen invisible div left in the page swallows every tap."""
        body = self.client.get(reverse("dashboard")).content.decode()
        scrim = body.split('id="nav-scrim"', 1)[1].split(">", 1)[0]

        self.assertIn("hidden", scrim)

    def test_the_drawer_reuses_the_one_navigation_list(self):
        """One list, not two. A second copy is a second thing to keep in step."""
        body = self.client.get(reverse("dashboard")).content.decode()

        # The same `.topnav` serves both layouts, so it appears exactly once.
        self.assertEqual(body.count('class="topnav"'), 1)
        self.assertEqual(body.count('id="site-nav"'), 1)
        # And it still holds every link.
        self.assertIn(reverse("outreach:settings"), body)
        self.assertIn(reverse("outreach:followups"), body)

    def test_the_drawer_has_a_close_button(self):
        body = self.client.get(reverse("dashboard")).content.decode()

        self.assertIn('id="nav-close"', body)
        self.assertIn('aria-label="Close menu"', body)


class BreakpointTests(TestCase):
    """The three the brief names."""

    def test_the_stylesheet_covers_phone_tablet_and_desktop(self):
        css = stylesheets()

        # The drawer takes over below 1024, so a tablet gets it too.
        self.assertIn("max-width: 1023px", css)
        # Phone-specific stacking.
        self.assertIn("max-width: 767px", css)

    def test_the_drawer_never_fills_the_screen(self):
        """`width: min(300px, 86vw)` — the page behind stays visible, which is what
        makes tapping outside an obvious way to dismiss it."""
        self.assertIn("min(300px, 86vw)", stylesheets())

    def test_touch_targets_are_large_enough(self):
        """44px is the smallest comfortable thumb target, and the menu button is the
        worst one to miss because there is no other way to navigate."""
        css = declarations()
        toggle = css.split(".nav-toggle {", 1)[1].split("}", 1)[0]

        self.assertIn("44px", toggle)

    def test_the_header_does_not_contain_the_fixed_drawer(self):
        """The bug that made the drawer open as a 60px sliver.

        `.topbar` has `backdrop-filter` for its frosted-glass look. A `filter` or
        `backdrop-filter` on an ancestor makes that ancestor the containing block for
        `position: fixed` descendants -- so the drawer's `top: 0; bottom: 0` resolved
        against the 60px header instead of the viewport, and `overflow-y: auto` hid the
        links below the fold. Opening the menu showed almost nothing.

        The filter is therefore dropped at drawer widths. The topbar is `sticky`, not
        `fixed`, so nothing structural depended on it.
        """
        css = declarations()
        drawer_widths = css.split("@media (max-width: 1023px)", 1)[1]                             .split("@media (max-width: 767px)", 1)[0]

        self.assertIn("backdrop-filter: none", drawer_widths)
        # And the drawer really is viewport-fixed, which is what the above enables.
        self.assertIn("position: fixed", drawer_widths)
        self.assertIn("z-index: 950", drawer_widths)

    def test_the_drawer_links_show_their_labels(self):
        """The old treatment hid them: `.navlink span { display: none }` at 860px left
        eight unlabelled icons. In a drawer the labels are the whole point."""
        css = declarations()
        drawer_widths = css.split("@media (max-width: 1023px)", 1)[1]                             .split("@media (max-width: 767px)", 1)[0]

        self.assertIn(".navlink span { display: inline; }", drawer_widths)

    def test_nothing_depends_on_hover_alone(self):
        self.assertIn("@media (hover: none)", stylesheets())

    def test_inputs_are_16px_on_a_phone(self):
        """Below 16px, iOS Safari zooms the page when a field takes focus — and a
        zoomed page is a horizontally scrolling page."""
        css = declarations()
        phone = css.split("@media (max-width: 767px)", 1)[1]

        self.assertIn("font-size: 16px", phone)


class TemplateCommentTests(TestCase):
    """A comment that renders is a comment written in the wrong syntax.

    Django's `{# ... #}` is **single-line only** — the documentation says so, and a
    multi-line one is not a comment at all: the template engine never recognises it, so
    the text is emitted as content. Seven of them were written across lines in this
    project and every one rendered on screen, two of them on every page because they were
    in `base.html`.

    `{% comment %} ... {% endcomment %}` is the multi-line form. These tests catch the
    mistake in the templates rather than in a screenshot.
    """

    PAGES = ("dashboard", "leads:index", "outreach:settings", "outreach:followups",
             "outreach:history", "outreach:suppressions", "outreach:audits",
             "outreach:automation", "outreach:audit_new")

    def setUp(self):
        self.user = get_user_model().objects.create_user(
            "sam", "sam@agency.test", "comment-test-password-42", is_staff=True)
        self.client.force_login(self.user)

    def test_no_template_uses_a_multi_line_hash_comment(self):
        """The source-level check: it fails on the template, naming file and line.

        Cheaper and more useful than the rendered check below, because it points at the
        line to fix rather than at a page that looks wrong.
        """
        offenders = []
        for path in templates():
            text = path.read_text(encoding="utf-8")
            for match in re.finditer(r"\{#(.*?)#\}", text, re.S):
                if "\n" in match.group(1):
                    line = text[:match.start()].count("\n") + 1
                    first = match.group(1).strip().splitlines()[0][:48]
                    offenders.append(
                        f"{path.relative_to(REPO).as_posix()}:{line}  {first}")

        self.assertEqual(
            offenders, [],
            "multi-line {# #} blocks. Django's {# #} is single-line only, so these "
            "render as visible text. Use {% comment %} ... {% endcomment %}:\n  "
            + "\n  ".join(offenders))

    def test_no_template_leaves_an_unclosed_hash_comment(self):
        """An opener with no `#}` on the same line is the same failure."""
        offenders = []
        for path in templates():
            for number, line in enumerate(
                    path.read_text(encoding="utf-8").splitlines(), 1):
                if "{#" in line and "#}" not in line:
                    offenders.append(
                        f"{path.relative_to(REPO).as_posix()}:{number}  "
                        f"{line.strip()[:48]}")

        self.assertEqual(offenders, [],
                         "unclosed {# on a line:\n  " + "\n  ".join(offenders))

    def test_no_page_renders_comment_syntax(self):
        """The end-to-end check: whatever the cause, nothing comment-shaped reaches the
        browser."""
        for name in self.PAGES:
            with self.subTest(page=name):
                body = self.client.get(reverse(name)).content.decode()

                self.assertNotIn("{#", body)
                self.assertNotIn("#}", body)
                self.assertNotIn("{% comment", body)
                self.assertNotIn("endcomment", body)

    def test_no_page_renders_the_prose_that_used_to_leak(self):
        """Named explicitly, so a reversion fails here rather than being seen.

        These are the exact phrases that were on screen. A test for the syntax would
        catch the syntax; this catches the symptom, which is what somebody reported.
        """
        leaked = ("Opens the drawer", "tap-outside target",
                  "The prerequisite, stated", "Staff only, matching",
                  "The account being edited", "The one thing this page cannot do")
        for name in self.PAGES:
            body = self.client.get(reverse(name)).content.decode()
            for phrase in leaked:
                with self.subTest(page=name, phrase=phrase):
                    self.assertNotIn(phrase, body)

    def test_no_page_renders_an_unrendered_template_tag(self):
        """A stray `{%` or `{{` in the output means a tag was mistyped."""
        for name in self.PAGES:
            with self.subTest(page=name):
                body = self.client.get(reverse(name)).content.decode()

                self.assertNotIn("{%", body)
                # `{{` appears legitimately in no template here; a leaked one means an
                # unbalanced variable tag.
                self.assertNotIn("{{", body)
