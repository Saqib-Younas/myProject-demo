"""
Moving the database: parsing DATABASE_URL, and copying the data safely.

Two failure modes worth testing, because both are silent:

  * a **connection string** that is subtly wrong -- the pooled port where the
    direct one was needed, or TLS quietly not required. Nothing complains; the
    migration just behaves oddly, or the data crosses the internet in the clear.
  * a **copy that reports success** while losing something. Row counts are the
    check everybody writes and they would not have caught the real bug found here:
    `auto_now_add` rewriting every timestamp to the moment of the migration.

The transfer command itself is exercised against a second SQLite database, which
covers the ordering, the foreign-key cycle, the timestamp preservation and the
verification. The Postgres-only part -- resetting sequences -- is checked by
inspection rather than execution, since there is no Postgres in the test
environment.
"""

from __future__ import annotations

from django.test import TestCase

from apps.core import dburl


class DatabaseUrlTests(TestCase):
    """The connection string is the one input nobody validates until it is wrong."""

    SUPABASE_POOLED = (
        "postgresql://leadmapper_app:pa%2Fss@aws-0-eu-west-2.pooler."
        "supabase.com:6543/postgres")
    SUPABASE_DIRECT = (
        "postgresql://postgres:secret@db.abcdefghijkl.supabase.co:5432/postgres")

    def test_a_supabase_uri_becomes_a_django_configuration(self):
        config = dburl.parse(self.SUPABASE_DIRECT)

        self.assertEqual(config["ENGINE"], "django.db.backends.postgresql")
        self.assertEqual(config["NAME"], "postgres")
        self.assertEqual(config["USER"], "postgres")
        self.assertEqual(config["HOST"], "db.abcdefghijkl.supabase.co")
        self.assertEqual(config["PORT"], "5432")

    def test_a_percent_encoded_password_is_decoded(self):
        """Supabase passwords contain characters that have to be encoded in a URI.

        A `/` in a password becomes `%2F`, and passing it through undecoded means
        authentication fails with a message that says nothing about encoding.
        """
        self.assertEqual(dburl.parse(self.SUPABASE_POOLED)["PASSWORD"], "pa/ss")

    def test_tls_is_required_unless_the_url_says_otherwise(self):
        """The connection carries every lead this application has contacted."""
        self.assertEqual(
            dburl.parse(self.SUPABASE_DIRECT)["OPTIONS"]["sslmode"], "require")

    def test_an_explicit_sslmode_is_respected(self):
        config = dburl.parse(self.SUPABASE_DIRECT + "?sslmode=verify-full")

        self.assertEqual(config["OPTIONS"]["sslmode"], "verify-full")

    def test_connections_are_kept_open_between_requests(self):
        """A TLS handshake per request would be most of the response time."""
        self.assertEqual(dburl.parse(self.SUPABASE_DIRECT)["CONN_MAX_AGE"], 600)

    def test_the_pooled_connection_is_recognised(self):
        """Right for the application, wrong for migrations. Worth saying out loud."""
        self.assertTrue(dburl.pooled(dburl.parse(self.SUPABASE_POOLED)))
        self.assertFalse(dburl.pooled(dburl.parse(self.SUPABASE_DIRECT)))

    def test_describe_says_which_connection_it_is(self):
        pooled = dburl.describe(dburl.parse(self.SUPABASE_POOLED))
        direct = dburl.describe(dburl.parse(self.SUPABASE_DIRECT))

        self.assertIn("pooled", pooled)
        self.assertIn("wrong for migrations", pooled)
        self.assertIn("direct", direct)
        self.assertIn("right for migrations", direct)

    def test_describe_never_contains_the_password(self):
        """It is printed before every destructive step, so it must be safe to print."""
        for url in (self.SUPABASE_POOLED, self.SUPABASE_DIRECT):
            with self.subTest(url=url[:40]):
                description = dburl.describe(dburl.parse(url))
                self.assertNotIn("secret", description)
                self.assertNotIn("pa/ss", description)
                self.assertNotIn("pa%2Fss", description)

    def test_sqlite_urls_resolve_to_a_file(self):
        cases = [
            ("sqlite:///relative/app.sqlite3", "relative/app.sqlite3"),
            ("sqlite:////var/data/app.sqlite3", "/var/data/app.sqlite3"),
            # urlparse keeps a leading slash, and Windows cannot open "/C:/...".
            ("sqlite:///C:/data/app.sqlite3", "C:/data/app.sqlite3"),
        ]
        for url, expected in cases:
            with self.subTest(url=url):
                self.assertEqual(dburl.parse(url)["NAME"], expected)

    def test_an_empty_url_is_refused(self):
        with self.assertRaises(dburl.DatabaseUrlError):
            dburl.parse("")

    def test_a_url_with_no_database_name_is_refused(self):
        """A Supabase URI ends in /postgres; a truncated copy-paste loses it."""
        with self.assertRaises(dburl.DatabaseUrlError) as caught:
            dburl.parse("postgresql://user:pw@db.abc.supabase.co:5432")

        self.assertIn("no database name", str(caught.exception))

    def test_an_unsupported_scheme_names_the_alternative(self):
        with self.assertRaises(dburl.DatabaseUrlError) as caught:
            dburl.parse("mysql://user:pw@localhost/app")

        self.assertIn("postgresql://", str(caught.exception))

    def test_the_error_never_contains_the_password(self):
        with self.assertRaises(dburl.DatabaseUrlError) as caught:
            dburl.parse("mysql://user:hunter2@localhost/app")

        self.assertNotIn("hunter2", str(caught.exception))


class SettingsFallbackTests(TestCase):
    """With no DATABASE_URL the project runs on SQLite, exactly as before."""

    def test_the_default_is_sqlite_when_nothing_is_configured(self):
        import os
        from unittest import mock

        from django.conf import settings

        if os.environ.get("DATABASE_URL"):
            self.skipTest("DATABASE_URL is set in this environment")

        with mock.patch.dict(os.environ, {}, clear=False):
            self.assertEqual(settings.DATABASES["default"]["ENGINE"],
                             "django.db.backends.sqlite3")

    def test_a_malformed_url_is_a_hard_failure_not_a_silent_fallback(self):
        """Falling back would mean production writing to a file nobody intended."""
        with self.assertRaises(dburl.DatabaseUrlError):
            dburl.parse("not-a-url-at-all")


class TransferSafetyTests(TestCase):
    """The rules the copy has to follow, checked without a second database."""

    def _command(self):
        from apps.outreach.management.commands.db_transfer import Command

        return Command()

    def test_the_tables_rebuilt_by_migrate_are_never_copied(self):
        """Their ids differ between databases, and nothing here references them."""
        from apps.outreach.management.commands import db_transfer

        self.assertIn("contenttypes.ContentType", db_transfer.SKIP_MODELS)
        self.assertIn("auth.Permission", db_transfer.SKIP_MODELS)
        self.assertIn("sessions.Session", db_transfer.SKIP_MODELS)

    def test_parents_are_ordered_before_children(self):
        order = [m._meta.label for m in self._command()._ordered_models("default")]

        self.assertLess(order.index("outreach.Campaign"),
                        order.index("outreach.EmailDraft"))
        self.assertLess(order.index("auth.User"),
                        order.index("outreach.Campaign"))

    def test_the_foreign_key_cycle_is_broken_by_deferring_the_nullable_side(self):
        """Campaign and EmailDraft point at each other.

        No insert order satisfies both, and Postgres -- unlike SQLite -- will not
        let a non-superuser turn foreign keys off. So the nullable reference is
        written as NULL and restored afterwards, and this is the test that would
        fail if somebody "simplified" that away.
        """
        from apps.outreach.models import Campaign

        command = self._command()
        order = command._ordered_models("default")
        deferred = command._deferred_fields(Campaign, order)

        self.assertEqual([f.name for f in deferred], ["current_draft"])
        self.assertTrue(all(f.null for f in deferred))

    def test_timestamps_are_preserved_while_copying(self):
        """The bug row counts would never have caught.

        `bulk_create` lets `auto_now_add` rewrite the value, so every `created_at`
        would say "the day of the migration" and the real history would be gone.
        """
        from apps.outreach.models import Campaign

        command = self._command()
        created_at = Campaign._meta.get_field("created_at")
        self.assertTrue(created_at.auto_now_add)      # the risk exists

        with command._preserve_timestamps([Campaign]) as frozen:
            self.assertIn(created_at, frozen)
            self.assertFalse(created_at.auto_now_add)

        # And restored, or everything stamped afterwards in this process breaks.
        self.assertTrue(created_at.auto_now_add)

    def test_the_flags_are_restored_even_if_the_copy_fails(self):
        from apps.outreach.models import Campaign

        command = self._command()
        created_at = Campaign._meta.get_field("created_at")

        with self.assertRaises(RuntimeError):
            with command._preserve_timestamps([Campaign]):
                raise RuntimeError("the copy failed")

        self.assertTrue(created_at.auto_now_add)

    def test_a_sample_of_rows_is_compared_field_by_field(self):
        """Counts alone would have missed the timestamp bug."""
        from apps.outreach.management.commands import db_transfer

        self.assertGreaterEqual(db_transfer.SAMPLE_SIZE, 1)

    def test_long_values_are_trimmed_before_being_printed(self):
        """A mismatch report must not dump an email body or a credential."""
        short = self._command()._short("x" * 500)

        self.assertLessEqual(len(short), 61)
        self.assertTrue(short.endswith("..."))
