"""
Three views: the page, the search, and the CSV download.

Finished searches are kept in a small in-memory dict so the download button has
something to serve. That is on purpose -- the brief rules out a database, and a
capped dict plus a file on disk covers everything the export needs. Restarting
the server clears the dict; the CSVs already written to exports/ survive.
"""

from __future__ import annotations

import json
import re
import uuid
from collections import OrderedDict
from threading import Lock
from typing import Any

from django.conf import settings
from django.http import (
    FileResponse,
    HttpRequest,
    HttpResponse,
    JsonResponse,
)
from django.shortcuts import render
from django.utils import timezone
from django.views.decorators.csrf import ensure_csrf_cookie
from django.views.decorators.http import require_GET, require_POST

from . import places, scraper
from .scraper import CATEGORIES, ScrapeError

#: job id -> {"leads": [...], "path": Path, "filename": str}
_JOBS: "OrderedDict[str, dict[str, Any]]" = OrderedDict()
_JOBS_LOCK = Lock()
MAX_JOBS = 20


def _remember(job: dict[str, Any]) -> str:
    job_id = uuid.uuid4().hex[:12]
    with _JOBS_LOCK:
        _JOBS[job_id] = job
        while len(_JOBS) > MAX_JOBS:
            _JOBS.popitem(last=False)
    return job_id


def _slug(text: str, fallback: str = "search") -> str:
    slug = re.sub(r"[^A-Za-z0-9]+", "-", text).strip("-").lower()
    return slug[:40] or fallback


@ensure_csrf_cookie
@require_GET
def index(request: HttpRequest) -> HttpResponse:
    """The single page: search form on the left, map on the right."""
    # Restoring from the query string is what makes "search again" work from a
    # campaign: the stored country and city come back as the form's values.
    country = request.GET.get("country", "").strip()
    return render(request, "leads/index.html", {
        "categories": list(CATEGORIES),
        "max_leads": scraper.MAX_LEADS,
        "nav": "search",
        # Lists reach the page as JSON via json_script, not as hundreds of DOM
        # nodes -- the combobox filters an array far faster than the browser
        # filters 282 <option> elements.
        "countries": list(places.country_choices()),
        "initial_country": country,
        "initial_city": request.GET.get("city", "").strip(),
        "initial_category": request.GET.get("category", "").strip(),
        # Pre-loaded so a restored country shows its cities immediately rather
        # than after a round trip.
        "initial_cities": [
            {"name": row["name"], "population": row["population"]}
            for row in (places.cities_for(country) if country else ())
        ],
    })


@require_GET
def cities(request: HttpRequest) -> JsonResponse:
    """Cities for one country, for the dependent dropdown.

    Ordered by population so the most likely choices are at the top of an
    unfiltered list. Served from an in-process dataset, so this is a local
    lookup rather than a call out to anybody's API.
    """
    country = request.GET.get("country", "").strip()
    if not country:
        return JsonResponse({"error": "Select a country first."}, status=400)

    code = places.code_for(country)
    if not code:
        return JsonResponse({
            "country": country, "code": "", "cities": [], "count": 0,
            "note": (f"{country} is not in the reference data — type the city "
                     "name and the geocoder will still try it."),
        })

    rows = places.cities_for(code)
    return JsonResponse({
        "country": places.country_name(code),
        "code": code,
        "count": len(rows),
        "cities": [{"name": r["name"], "population": r["population"]} for r in rows],
        "note": "" if rows else (
            f"The reference data lists no cities of 15,000+ people in "
            f"{places.country_name(code)}. Type the place name instead."
        ),
    })


@require_POST
def search(request: HttpRequest) -> JsonResponse:
    """Run one collection: geocode, query Overpass, write the CSV."""
    try:
        payload = json.loads(request.body or b"{}")
    except json.JSONDecodeError:
        return JsonResponse({"error": "Malformed request."}, status=400)

    country = str(payload.get("country", "")).strip()
    city = str(payload.get("city", "")).strip()
    category = str(payload.get("category", "")).strip()

    if not city:
        return JsonResponse({"error": "Enter a city or location."}, status=400)
    if not category:
        return JsonResponse({"error": "Choose or type a business category."}, status=400)

    try:
        limit = int(payload.get("limit", 50))
    except (TypeError, ValueError):
        return JsonResponse({"error": "Number of leads must be a number."}, status=400)

    # A city that belongs to a different country is a mistake worth catching
    # here, before a geocoding request is spent on it.
    coherent, why = places.validate(country, city)
    if not coherent:
        return JsonResponse({"error": why}, status=400)

    try:
        area, leads = scraper.search(country, city, category, limit)
    except ScrapeError as exc:
        # Expected, explainable failures: bad place name, every mirror busy.
        return JsonResponse({"error": str(exc)}, status=502)

    if not leads:
        return JsonResponse({
            "error": (
                f"No {category.lower()} with a business name are mapped in "
                f"{area.city}. OpenStreetMap coverage varies by area -- try a "
                "broader category, or a larger city."
            ),
        }, status=404)

    # The CSV is generated as soon as the search finishes, so the download
    # button is only ever revealing a file that already exists.
    settings.EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    stamp = timezone.now().strftime("%Y%m%d-%H%M%S")
    filename = f"leads_{_slug(area.city)}_{_slug(category)}_{stamp}.csv"
    path = settings.EXPORT_DIR / filename
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        scraper.write_csv(leads, handle)

    job_id = _remember({"leads": leads, "path": path, "filename": filename})

    # Check every result against the sending history before the user sees it, so
    # an already-contacted business is obvious at the point of selection rather
    # than at the point of sending.
    payload_leads = [lead.as_dict() for lead in leads]
    from outreach import history as sending_history

    # Annotated against this user's own history: another account having
    # emailed a business is not a reason to hide it from this one.
    history_counts = sending_history.annotate_leads(payload_leads,
                                                   request.user)

    return JsonResponse({
        "job_id": job_id,
        "count": len(leads),
        "history": history_counts,
        "requested": max(1, min(limit, scraper.MAX_LEADS)),
        "area": {
            "city": area.city,
            "country": area.country,
            "label": area.label,
            "lat": area.lat,
            "lon": area.lon,
            "bbox": area.bbox,
        },
        "csv_filename": filename,
        "download_url": f"/api/export/{job_id}",
        "leads": payload_leads,
    })


@require_GET
def export(request: HttpRequest, job_id: str) -> HttpResponse:
    """Serve the CSV written when the search finished."""
    with _JOBS_LOCK:
        job = _JOBS.get(job_id)

    if job is None:
        return HttpResponse(
            "That export has expired. Run the search again to rebuild it.",
            status=404,
            content_type="text/plain",
        )

    path, filename = job["path"], job["filename"]
    if path.exists():
        return FileResponse(
            path.open("rb"),
            as_attachment=True,
            filename=filename,
            content_type="text/csv",
        )

    # File was moved or deleted since the search -- rebuild it from memory.
    response = HttpResponse(
        scraper.csv_text(job["leads"]).encode("utf-8-sig"),
        content_type="text/csv",
    )
    response["Content-Disposition"] = f'attachment; filename="{filename}"'
    return response
