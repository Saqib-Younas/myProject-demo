from django.apps import AppConfig


class LeadsConfig(AppConfig):
    name = "leads"
    verbose_name = "Lead Mapper"

    def ready(self) -> None:
        """Hand the configured contact address to the scraper.

        Nominatim wants a way to reach whoever is running the app, so the
        User-Agent is built from this rather than hard-coded in the module.
        """
        from django.conf import settings

        from . import scraper

        scraper.CONTACT = settings.OSM_CONTACT_EMAIL
