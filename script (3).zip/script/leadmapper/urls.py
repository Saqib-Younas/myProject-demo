"""
Root URL configuration.

`/login`, `/signup` and `/logout` live at the top level because they are not
part of either feature app, and `/dashboard` does too because it is the
authenticated home rather than a page inside the outreach workflow.

Everything except the three auth routes requires a signed-in user, enforced by
LoginRequiredMiddleware rather than per-view decorators.
"""

from django.urls import include, path

from outreach import views as outreach_views

urlpatterns = [
    path("", include("accounts.urls")),
    path("dashboard", outreach_views.dashboard, name="dashboard"),
    path("outreach/", include("outreach.urls")),
    path("", include("leads.urls")),
]
