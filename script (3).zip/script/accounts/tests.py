"""
Authentication, sessions and protected routes.

The tests that matter here are the negative ones. "Login works" is table stakes;
what has to be proved is that a signed-out visitor cannot reach anything, that a
signed-in visitor cannot reach *another account's* data by editing a URL, and
that a failed login does not reveal whether the email exists.

Route protection is asserted against the real URL list rather than a hand-written
one, so a view added later without protection fails a test instead of shipping.
"""

from __future__ import annotations

from django.contrib.auth import get_user_model
from django.test import Client, TestCase, override_settings
from django.urls import reverse

from outreach.testsupport import PASSWORD, make_user

User = get_user_model()

GOOD_PASSWORD = "a-long-enough-passphrase-42"


class SignUpTests(TestCase):
    def _post(self, **overrides):
        data = {
            "name": "Sam Rivers",
            "email": "sam@agency.test",
            "password": GOOD_PASSWORD,
            "confirm_password": GOOD_PASSWORD,
        }
        data.update(overrides)
        return self.client.post(reverse("signup"), data=data)

    def test_a_valid_signup_creates_an_account_and_signs_in(self):
        response = self._post()

        self.assertRedirects(response, reverse("dashboard"))
        user = User.objects.get(email="sam@agency.test")
        self.assertEqual(user.first_name, "Sam Rivers")
        # Signed straight in, no second step.
        self.assertEqual(int(self.client.session["_auth_user_id"]), user.pk)

    def test_the_password_is_hashed_not_stored(self):
        self._post()
        user = User.objects.get(email="sam@agency.test")

        self.assertNotEqual(user.password, GOOD_PASSWORD)
        self.assertNotIn(GOOD_PASSWORD, user.password)
        self.assertTrue(user.check_password(GOOD_PASSWORD))
        # Hashed with an algorithm, not stored raw or encoded.
        self.assertIn("$", user.password)

    def test_the_hash_is_never_sent_to_the_browser(self):
        self._post()
        user = User.objects.get(email="sam@agency.test")

        page = self.client.get(reverse("dashboard"))
        self.assertNotIn(user.password, page.content.decode())

    def test_mismatched_passwords_are_refused(self):
        response = self._post(confirm_password="something-else-entirely")

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "do not match")
        self.assertEqual(User.objects.count(), 0)

    def test_a_short_password_is_refused(self):
        response = self._post(password="short", confirm_password="short")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(User.objects.count(), 0)

    def test_a_common_password_is_refused(self):
        response = self._post(password="password123", confirm_password="password123")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(User.objects.count(), 0)

    def test_an_entirely_numeric_password_is_refused(self):
        response = self._post(password="8471926350", confirm_password="8471926350")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(User.objects.count(), 0)

    def test_a_malformed_email_is_refused(self):
        response = self._post(email="not-an-address")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(User.objects.count(), 0)

    def test_a_duplicate_email_is_refused(self):
        make_user("sam@agency.test")

        response = self._post()

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "already exists")
        self.assertEqual(User.objects.filter(email__iexact="sam@agency.test").count(), 1)

    def test_a_duplicate_email_in_another_case_is_also_refused(self):
        """Login is case-insensitive, so signup has to be too or it breaks."""
        make_user("sam@agency.test")

        response = self._post(email="SAM@Agency.Test")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(User.objects.count(), 1)

    def test_the_email_is_stored_lowercase(self):
        self._post(email="Sam@Agency.TEST")

        self.assertTrue(User.objects.filter(email="sam@agency.test").exists())

    def test_a_signed_in_visitor_is_sent_to_the_dashboard(self):
        self.client.force_login(make_user())

        response = self.client.get(reverse("signup"))

        self.assertRedirects(response, reverse("dashboard"))

    def test_the_page_renders_for_a_visitor(self):
        response = self.client.get(reverse("signup"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Create an account")
        self.assertContains(response, "csrfmiddlewaretoken")


class LoginTests(TestCase):
    def setUp(self):
        self.user = make_user("sam@agency.test")

    def _post(self, email="sam@agency.test", password=PASSWORD, **extra):
        return self.client.post(
            reverse("login"), data={"email": email, "password": password, **extra})

    def test_valid_credentials_sign_in_and_redirect_to_the_dashboard(self):
        response = self._post()

        self.assertRedirects(response, reverse("dashboard"))
        self.assertEqual(int(self.client.session["_auth_user_id"]), self.user.pk)

    def test_the_email_is_case_insensitive(self):
        response = self._post(email="SAM@Agency.Test")

        self.assertRedirects(response, reverse("dashboard"))

    def test_a_wrong_password_is_refused(self):
        response = self._post(password="not-the-password")

        self.assertEqual(response.status_code, 200)
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_an_unknown_email_is_refused(self):
        response = self._post(email="nobody@elsewhere.test")

        self.assertEqual(response.status_code, 200)
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_the_error_does_not_reveal_whether_the_account_exists(self):
        """Identical wording either way, or the form becomes an account oracle."""
        import re

        def banner(response) -> str:
            """The form-level error text, found by id rather than by role.

            Several elements on the page carry role="alert" now, and attribute
            order is not something a test should depend on.
            """
            html = response.content.decode()
            found = re.search(r'id="form-error".*?<span>(.*?)</span>', html, re.S)
            return " ".join(found.group(1).split()) if found else ""

        wrong_password = banner(self._post(password="not-the-password"))
        unknown_email = banner(self._post(email="nobody@elsewhere.test"))

        self.assertTrue(wrong_password)
        # Byte-for-byte the same message, so the response cannot be used to test
        # whether an address has an account.
        self.assertEqual(wrong_password, unknown_email)
        self.assertNotIn("no account with", wrong_password.lower())
        self.assertNotIn("incorrect password", wrong_password.lower())

    def test_a_disabled_account_cannot_sign_in(self):
        User.objects.filter(pk=self.user.pk).update(is_active=False)

        response = self._post()

        self.assertEqual(response.status_code, 200)
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_the_session_key_changes_on_login(self):
        """Session fixation: a key set before login must not survive it."""
        self.client.get(reverse("login"))
        self.client.session.save()
        before = self.client.session.session_key

        self._post()

        self.assertNotEqual(self.client.session.session_key, before)

    def test_a_signed_in_visitor_is_sent_to_the_dashboard(self):
        self.client.force_login(self.user)

        response = self.client.get(reverse("login"))

        self.assertRedirects(response, reverse("dashboard"))

    def test_a_next_parameter_on_this_site_is_honoured(self):
        response = self.client.post(
            reverse("login"),
            data={"email": "sam@agency.test", "password": PASSWORD,
                  "next": "/outreach/settings"})

        self.assertRedirects(response, "/outreach/settings",
                             fetch_redirect_response=False)

    def test_a_next_parameter_pointing_off_site_is_ignored(self):
        """An open redirect after login is a ready-made phishing step."""
        response = self.client.post(
            reverse("login"),
            data={"email": "sam@agency.test", "password": PASSWORD,
                  "next": "https://evil.example/harvest"})

        self.assertRedirects(response, reverse("dashboard"))

    def test_the_password_is_not_echoed_back_into_the_form(self):
        response = self._post(password="wrong-but-memorable")

        self.assertNotIn("wrong-but-memorable", response.content.decode())

    def test_the_page_renders_for_a_visitor(self):
        response = self.client.get(reverse("login"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Sign in")
        self.assertContains(response, "csrfmiddlewaretoken")


class LogoutTests(TestCase):
    def setUp(self):
        self.user = make_user()
        self.client.force_login(self.user)

    def test_logout_clears_the_session_and_redirects_to_login(self):
        response = self.client.post(reverse("logout"))

        self.assertRedirects(response, reverse("login"))
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_protected_pages_are_closed_again_after_logout(self):
        self.client.post(reverse("logout"))

        response = self.client.get(reverse("dashboard"))

        self.assertEqual(response.status_code, 302)
        self.assertIn(reverse("login"), response["Location"])

    def test_protected_apis_are_closed_again_after_logout(self):
        self.client.post(reverse("logout"))

        response = self.client.post(reverse("outreach:start"), data={},
                                    content_type="application/json")

        self.assertEqual(response.status_code, 302)

    def test_logout_refuses_get(self):
        """A GET logout can be fired by any image tag on any page."""
        response = self.client.get(reverse("logout"))

        self.assertEqual(response.status_code, 405)
        self.assertIn("_auth_user_id", self.client.session)


class SessionTests(TestCase):
    def setUp(self):
        self.user = make_user()

    def test_a_session_survives_a_second_request(self):
        self.client.force_login(self.user)

        first = self.client.get(reverse("dashboard"))
        second = self.client.get(reverse("dashboard"))

        self.assertEqual(first.status_code, 200)
        self.assertEqual(second.status_code, 200)

    def test_a_deleted_session_row_signs_the_visitor_out(self):
        """An expired or purged session must not keep working."""
        from django.contrib.sessions.models import Session

        self.client.force_login(self.user)
        Session.objects.all().delete()

        response = self.client.get(reverse("dashboard"))

        self.assertEqual(response.status_code, 302)
        self.assertIn(reverse("login"), response["Location"])

    def test_a_forged_session_cookie_is_rejected(self):
        self.client.cookies["sessionid"] = "not-a-real-session-key"

        response = self.client.get(reverse("dashboard"))

        self.assertEqual(response.status_code, 302)

    def test_a_deleted_account_cannot_keep_using_its_session(self):
        self.client.force_login(self.user)
        self.user.delete()

        response = self.client.get(reverse("dashboard"))

        self.assertEqual(response.status_code, 302)

    def test_the_session_state_endpoint_reports_signed_out(self):
        data = self.client.get(reverse("session_state")).json()

        self.assertFalse(data["authenticated"])
        self.assertEqual(data["name"], "")

    def test_the_session_state_endpoint_reports_signed_in(self):
        self.client.force_login(self.user)

        data = self.client.get(reverse("session_state")).json()

        self.assertTrue(data["authenticated"])
        self.assertTrue(data["name"])

    @override_settings(DEBUG=False)
    def test_the_session_cookie_is_http_only(self):
        """Set in settings; asserted here so a later change cannot drop it."""
        from django.conf import settings

        self.assertTrue(settings.SESSION_COOKIE_HTTPONLY)
        self.assertEqual(settings.SESSION_COOKIE_SAMESITE, "Lax")


class ProtectedRouteTests(TestCase):
    """Every route except the three auth ones requires a session."""

    #: The only URLs an anonymous visitor may reach. Anything else appearing
    #: here in future is a deliberate decision, not an oversight.
    PUBLIC = {"/login", "/signup", "/logout", "/api/session"}

    #: Stand-ins for URL parameters, so a pattern can be turned into a real path.
    SAMPLES = {
        "campaign_id": "0f5b8c2e-1a2b-4c3d-8e9f-000000000001",
        "job_id": "no-such-job",
        "pk": "1",
        "provider": "groq",
        "action": "approve",
    }

    def _all_get_routes(self) -> list[str]:
        """Concrete paths from the real URL configuration.

        Walked from the resolver tree rather than listed by hand, so a view added
        later is covered without anybody remembering to add it here.
        """
        import re

        from django.urls import get_resolver
        from django.urls.resolvers import URLPattern, URLResolver

        def walk(resolver, prefix=""):
            for entry in resolver.url_patterns:
                fragment = str(entry.pattern)
                if isinstance(entry, URLResolver):
                    yield from walk(entry, prefix + fragment)
                elif isinstance(entry, URLPattern):
                    yield prefix + fragment

        paths = []
        for raw in walk(get_resolver()):
            # "<uuid:campaign_id>" and "<int:pk>" become sample values.
            path = re.sub(
                r"<(?:[a-z]+:)?([a-z_]+)>",
                lambda m: self.SAMPLES.get(m.group(1), "1"), raw)
            if "<" in path or "(" in path:
                continue        # a regex route this helper cannot fill in
            paths.append("/" + path.lstrip("/"))
        return sorted(set(paths))

    def test_every_route_is_either_public_or_protected(self):
        routes = self._all_get_routes()
        self.assertIn("/dashboard", routes)
        self.assertGreater(len(routes), 15, "route discovery found too little")

        unprotected = []
        for path in routes:
            if path.rstrip("/") in self.PUBLIC or path in self.PUBLIC:
                continue
            response = Client().get(path)
            # 302 to login is the protected answer. 405 means the route exists
            # but refuses GET, which is also not an information leak.
            if response.status_code == 302:
                if reverse("login") in response["Location"]:
                    continue
            if response.status_code == 405:
                continue
            unprotected.append((path, response.status_code))

        self.assertEqual(unprotected, [],
                         f"these routes answered an anonymous GET: {unprotected}")

    def test_the_public_routes_really_are_public(self):
        for path in ("/login", "/signup"):
            with self.subTest(path=path):
                self.assertEqual(Client().get(path).status_code, 200)

    def test_an_anonymous_visitor_is_redirected_with_a_next_parameter(self):
        response = Client().get("/outreach/settings")

        self.assertEqual(response.status_code, 302)
        self.assertIn("next=/outreach/settings", response["Location"])

    def test_the_lead_search_page_is_protected(self):
        response = Client().get(reverse("leads:index"))

        self.assertEqual(response.status_code, 302)
        self.assertIn(reverse("login"), response["Location"])

    def test_the_search_api_is_protected(self):
        response = Client().post(reverse("leads:search"), data={},
                                 content_type="application/json")

        self.assertEqual(response.status_code, 302)

class FormMarkupTests(TestCase):
    """The markup the CSS and the validation JavaScript depend on.

    Asserted because all three have to agree: a renamed wrapper class breaks the
    layout, and a missing error slot means a message with nowhere to go. The
    monospace check exists because the password box originally borrowed the
    credential-card styling, which sets a monospace face for API keys.
    """

    PAGES = ("login", "signup")

    def test_the_auth_forms_do_not_borrow_credential_card_styling(self):
        for page in self.PAGES:
            with self.subTest(page=page):
                response = self.client.get(reverse(page))
                self.assertNotContains(response, "cred-input")
                self.assertContains(response, 'class="auth-input')

    def test_every_field_has_an_error_slot_and_a_state_icon(self):
        expected = {"login": ["email", "password"],
                    "signup": ["name", "email", "password", "confirm_password"]}
        for page, names in expected.items():
            html = self.client.get(reverse(page)).content.decode()
            for name in names:
                with self.subTest(page=page, field=name):
                    self.assertIn(f'data-field="{name}"', html)
            self.assertEqual(html.count('class="field-error"'), len(names))
            self.assertEqual(html.count('class="auth-state"'), len(names))

    def test_the_reveal_button_is_inside_the_field(self):
        """Beside the field it cost ~90px of a 320px screen."""
        import re

        for page in self.PAGES:
            html = self.client.get(reverse(page)).content.decode()
            groups = re.findall(r'<div class="auth-input has-reveal">(.*?)</div>',
                                html, re.S)
            with self.subTest(page=page):
                self.assertTrue(groups)
                for group in groups:
                    self.assertIn("auth-reveal", group)

    def test_the_reveal_button_has_an_accessible_name_and_state(self):
        response = self.client.get(reverse("login"))

        self.assertContains(response, 'aria-label="Show password"')
        self.assertContains(response, 'aria-pressed="false"')

    def test_the_forms_carry_live_regions(self):
        for page in self.PAGES:
            with self.subTest(page=page):
                response = self.client.get(reverse(page))
                self.assertContains(response, 'id="form-error"')
                self.assertContains(response, 'aria-live="assertive"')
                self.assertContains(response, 'aria-live="polite"')

    def test_the_email_field_asks_for_the_right_mobile_keyboard(self):
        for page in self.PAGES:
            with self.subTest(page=page):
                response = self.client.get(reverse(page))
                self.assertContains(response, 'inputmode="email"')
                self.assertContains(response, 'autocapitalize="none"')

    def test_signup_shows_a_password_strength_meter(self):
        html = self.client.get(reverse("signup")).content.decode()

        self.assertIn('id="pw-meter"', html)
        self.assertIn('data-score="0"', html)
        self.assertEqual(html.count('class="pw-bar"'), 4)

    def test_a_caps_lock_hint_exists_on_both_forms(self):
        for page in self.PAGES:
            with self.subTest(page=page):
                self.assertContains(self.client.get(reverse(page)),
                                    'id="caps-warning"')

    def test_no_password_value_is_ever_rendered(self):
        import re

        response = self.client.post(reverse("signup"), data={
            "name": "Sam", "email": "sam@agency.test",
            "password": "a-long-enough-passphrase-42",
            "confirm_password": "something-else-entirely"})

        self.assertIsNone(re.search(r'type="password"[^>]*value="[^"]+"',
                                    response.content.decode()))

    def test_a_server_error_lands_in_the_field_slot(self):
        """The same slot the JavaScript writes into, so they cannot disagree."""
        import re

        response = self.client.post(reverse("signup"), data={
            "name": "Sam", "email": "sam@agency.test",
            "password": "a-long-enough-passphrase-42",
            "confirm_password": "something-else-entirely"})
        html = response.content.decode()
        # From this field's wrapper to the next one, or to the end of the form.
        block = re.search(
            r'data-field="confirm_password".*?(?=data-field="|</form>)',
            html, re.S)

        self.assertIsNotNone(block)
        segment = block.group(0)
        self.assertIn("do not match", segment)
        # In the error slot specifically, not merely somewhere on the page.
        slot = re.search(r'class="field-error"[^>]*>(.*?)</p>', segment, re.S)
        self.assertIsNotNone(slot)
        self.assertIn("do not match", slot.group(1))
