"""
Sending history and duplicate prevention.

Kept in its own module because it is a distinct concern from the campaign
workflow, and because the important cases here are the adversarial ones: the
same search run twice, a second campaign carrying the same lead, a double send,
two threads racing for one address.
"""

from __future__ import annotations

from unittest import mock

from django.db import IntegrityError, transaction
from django.test import TestCase
from django.utils import timezone

from . import history, runner, sender
from .models import Campaign, EmailDraft, SentLead
from .tests import FakeSession, make_campaign, make_draft
from .testsupport import SignedIn, default_user


def make_sent(email="ciao@bella.example", **overrides) -> SentLead:
    """A completed history row, as the send loop would leave it."""
    now = timezone.localtime()
    values = dict(
        owner=default_user(),
        business_name="Bella Cucina",
        email=email,
        website="https://bella.example",
        domain="bella.example",
        country="Netherlands",
        city="Delft",
        campaign_label="Restaurants · Delft",
        subject="Booking for Bella Cucina",
        status=SentLead.Status.SENT,
        sent_at=now,
        sent_date=now.date(),
        sent_time=now.time().replace(microsecond=0),
    )
    values.update(overrides)
    return SentLead.objects.create(**values)


class DomainNormalisationTests(SignedIn):
    def test_scheme_www_port_and_case_are_stripped(self):
        for raw in ("https://www.bella.example/menu", "http://bella.example",
                    "www.bella.example", "bella.example/",
                    "https://BELLA.example:443/x?y=1"):
            with self.subTest(raw=raw):
                self.assertEqual(SentLead.domain_of(raw), "bella.example")

    def test_no_website_gives_no_domain(self):
        self.assertEqual(SentLead.domain_of(""), "")
        self.assertEqual(SentLead.domain_of(None), "")

    def test_different_sites_do_not_collapse(self):
        self.assertNotEqual(SentLead.domain_of("https://a.example"),
                            SentLead.domain_of("https://b.example"))


class HistoryMatchTests(SignedIn):
    """The three tiers, and the things that must NOT match."""

    def setUp(self):
        make_sent()

    def _match(self, **kwargs):
        return history.Index(default_user()).match(**kwargs)

    def test_tier_one_exact_email(self):
        match = self._match(email="ciao@bella.example")

        self.assertIsNotNone(match)
        self.assertEqual(match.matched_by, "email")

    def test_email_matching_ignores_case(self):
        self.assertIsNotNone(self._match(email="CIAO@Bella.Example"))

    def test_tier_two_same_website_different_address(self):
        match = self._match(email="info@bella.example",
                            website="https://www.bella.example/contact")

        self.assertIsNotNone(match)
        self.assertEqual(match.matched_by, "domain")

    def test_tier_three_same_name_and_city(self):
        match = self._match(email="hello@other.example",
                            business_name="bella cucina", city="DELFT")

        self.assertIsNotNone(match)
        self.assertEqual(match.matched_by, "name_city")

    def test_the_same_name_in_another_city_is_not_a_match(self):
        # Chains share names across cities; blocking those would be wrong.
        self.assertIsNone(self._match(email="new@x.example",
                                      business_name="Bella Cucina",
                                      city="Rotterdam"))

    def test_a_name_with_no_city_cannot_match_on_tier_three(self):
        self.assertIsNone(self._match(email="new@x.example",
                                      business_name="Bella Cucina", city=""))

    def test_an_unrelated_lead_is_free_to_contact(self):
        self.assertIsNone(self._match(email="new@elsewhere.example",
                                      website="https://elsewhere.example",
                                      business_name="Elsewhere", city="Delft"))

    def test_a_failed_record_does_not_block(self):
        SentLead.objects.all().update(status=SentLead.Status.FAILED)

        self.assertIsNone(self._match(email="ciao@bella.example"))

    def test_an_in_flight_record_does_block(self):
        SentLead.objects.all().update(status=SentLead.Status.SENDING)

        self.assertIsNotNone(self._match(email="ciao@bella.example"))

    def test_the_matched_tier_is_reported_for_the_user_to_judge(self):
        detail = self._match(email="info@bella.example",
                             website="https://bella.example").as_dict()

        self.assertIn("domain", detail["matched_by_label"])
        self.assertEqual(detail["campaign"], "Restaurants · Delft")
        self.assertTrue(detail["sent_date"])


class AnnotateLeadsTests(SignedIn):
    def test_leads_split_into_available_contacted_and_invalid(self):
        make_sent()
        leads = [
            {"business_name": "Bella Cucina", "email": "ciao@bella.example",
             "website": "https://bella.example", "city": "Delft"},
            {"business_name": "New Place", "email": "hi@new.example",
             "website": "https://new.example", "city": "Delft"},
            {"business_name": "No Email", "email": "", "city": "Delft"},
        ]

        counts = history.annotate_leads(leads, default_user())

        self.assertEqual(counts, {"total": 3, "available": 1, "contacted": 1,
                                  "invalid": 1, "suppressed": 0})
        self.assertEqual([l["contact_state"] for l in leads],
                         ["contacted", "new", "invalid"])

    def test_a_contacted_lead_carries_the_history_detail(self):
        make_sent()
        leads = [{"business_name": "Bella Cucina", "email": "ciao@bella.example",
                  "city": "Delft"}]

        history.annotate_leads(leads, default_user())

        self.assertEqual(leads[0]["history"]["matched_by"], "email")
        self.assertEqual(leads[0]["state_label"], "Already contacted")

    def test_an_empty_history_leaves_everything_available(self):
        leads = [{"business_name": "A", "email": "a@x.example", "city": "Delft"}]

        counts = history.annotate_leads(leads, default_user())

        self.assertEqual(counts["available"], 1)
        self.assertNotIn("history", leads[0])


class ReserveTests(SignedIn):
    """The pre-send lock. This is what makes a duplicate impossible."""

    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(self.campaign, status=EmailDraft.Status.APPROVED)

    def test_a_fresh_address_can_be_reserved(self):
        record = history.reserve(self.draft)

        self.assertEqual(record.status, SentLead.Status.SENDING)
        self.assertEqual(record.email, self.draft.email)
        self.assertEqual(record.domain, "bella.example")
        self.assertEqual(record.campaign_label, self.campaign.label)

    def test_the_same_address_cannot_be_reserved_twice(self):
        history.reserve(self.draft)

        with self.assertRaises(history.AlreadyContacted):
            history.reserve(self.draft)

    def test_an_already_sent_address_cannot_be_reserved(self):
        make_sent(email=self.draft.email)

        with self.assertRaises(history.AlreadyContacted) as caught:
            history.reserve(self.draft)

        self.assertIn(self.draft.email, str(caught.exception))

    def test_a_failed_address_can_be_reserved_again(self):
        history.reserve(self.draft).mark_failed("mailbox full")

        self.assertEqual(history.reserve(self.draft).status,
                         SentLead.Status.SENDING)

    def test_a_draft_with_no_email_is_refused(self):
        self.draft.email = ""

        with self.assertRaises(history.AlreadyContacted):
            history.reserve(self.draft)

    def test_marking_sent_records_date_and_time_separately(self):
        record = history.reserve(self.draft)
        record.mark_sent()
        record.refresh_from_db()

        self.assertEqual(record.status, SentLead.Status.SENT)
        self.assertIsNotNone(record.sent_at)
        self.assertIsNotNone(record.sent_date)
        self.assertIsNotNone(record.sent_time)

    def test_the_database_constraint_is_the_real_guard(self):
        """Not the application check -- the constraint itself.

        Everything else is advisory. This is the line that holds if a future
        change forgets to call reserve().
        """
        make_sent(email="taken@x.example")

        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                SentLead.objects.create(
                    owner=default_user(),
                    business_name="Sneaky", email="taken@x.example",
                    status=SentLead.Status.SENDING)

    def test_two_failed_rows_for_one_address_are_allowed(self):
        make_sent(email="a@x.example", status=SentLead.Status.FAILED,
                  sent_at=None, sent_date=None, sent_time=None)
        make_sent(email="a@x.example", status=SentLead.Status.FAILED,
                  sent_at=None, sent_date=None, sent_time=None)

        self.assertEqual(SentLead.objects.filter(email="a@x.example").count(), 2)


class CampaignDuplicateSweepTests(SignedIn):
    def test_already_contacted_drafts_leave_the_workflow(self):
        make_sent(email="ciao@bella.example")
        campaign = make_campaign()
        blocked = make_draft(campaign, status=EmailDraft.Status.APPROVED)
        clear = make_draft(campaign, business_name="New Place",
                           email="hi@new.example", website="https://new.example",
                           status=EmailDraft.Status.APPROVED)

        moved = history.mark_campaign_duplicates(campaign)

        blocked.refresh_from_db()
        clear.refresh_from_db()
        self.assertEqual(moved, 1)
        self.assertEqual(blocked.status, EmailDraft.Status.DUPLICATE)
        self.assertIn("already contacted", blocked.error_message)
        self.assertEqual(clear.status, EmailDraft.Status.APPROVED)


class SendHistoryTests(SignedIn):
    """The send loop must write history and obey it."""

    def setUp(self):
        self.campaign = make_campaign()
        self.drafts = [
            make_draft(self.campaign, business_name=f"Shop {i}",
                       email=f"shop{i}@example.test",
                       website=f"https://shop{i}.example",
                       status=EmailDraft.Status.APPROVED)
            for i in range(3)
        ]

    def _run(self, session, campaign=None):
        with mock.patch.object(sender, "Session", return_value=session), \
             mock.patch.object(runner.time, "sleep"), \
             mock.patch.object(history, "export_excel",
                               return_value={"path": "x", "added": 0, "total": 0}):
            runner._send_all(campaign or self.campaign, "pw", "", 0)
        (campaign or self.campaign).refresh_from_db()

    def test_every_send_writes_a_history_row(self):
        self._run(FakeSession())

        rows = SentLead.objects.filter(status=SentLead.Status.SENT)
        self.assertEqual(rows.count(), 3)
        row = rows.get(email="shop0@example.test")
        self.assertEqual(row.business_name, "Shop 0")
        self.assertEqual(row.campaign_id, self.campaign.id)
        self.assertEqual(row.subject, self.drafts[0].subject)
        self.assertIsNotNone(row.sent_date)
        self.assertIsNotNone(row.sent_time)

    def test_a_failed_send_records_a_failed_row_and_frees_the_address(self):
        self._run(FakeSession(fail_for={"shop1@example.test"}))

        row = SentLead.objects.get(email="shop1@example.test")
        self.assertEqual(row.status, SentLead.Status.FAILED)
        self.assertIn("SMTPRecipientsRefused", row.error_message)
        # Freed, so a deliberate retry is still possible.
        self.assertIsNone(history.Index(default_user()).match(email="shop1@example.test"))

    def test_a_previously_contacted_lead_never_reaches_the_transport(self):
        make_sent(email="shop1@example.test", business_name="Shop 1")
        session = FakeSession()

        self._run(session)

        self.assertNotIn("shop1@example.test", session.sent)
        self.assertEqual(len(session.sent), 2)
        self.drafts[1].refresh_from_db()
        self.assertEqual(self.drafts[1].status, EmailDraft.Status.DUPLICATE)
        self.assertIn("skipped", self.campaign.error.lower())

    def test_running_the_same_campaign_twice_sends_nothing_again(self):
        first, second = FakeSession(), FakeSession()

        self._run(first)
        # As if the user re-approved everything and pressed Send again.
        self.campaign.drafts.update(status=EmailDraft.Status.APPROVED)
        self._run(second)

        self.assertEqual(len(first.sent), 3)
        self.assertEqual(len(second.sent), 0,
                         "the history must block a second send")
        self.assertEqual(
            SentLead.objects.filter(status=SentLead.Status.SENT).count(), 3)

    def test_a_second_campaign_cannot_reach_the_same_addresses(self):
        self._run(FakeSession())

        other = make_campaign()
        for i in range(3):
            make_draft(other, business_name=f"Shop {i}",
                       email=f"shop{i}@example.test",
                       status=EmailDraft.Status.APPROVED)

        session = FakeSession()
        self._run(session, campaign=other)

        self.assertEqual(len(session.sent), 0)
        self.assertEqual(
            other.drafts.filter(status=EmailDraft.Status.DUPLICATE).count(), 3)

    def test_an_aborted_run_leaves_no_stuck_reservation(self):
        self._run(FakeSession(raise_on_enter=sender.SendError("login rejected")))

        # Nothing was reserved, so every address is still contactable.
        self.assertEqual(SentLead.objects.count(), 0)

    def test_a_concurrent_reservation_is_skipped_not_double_sent(self):
        """Simulates the other thread having already claimed one address.

        Same owner as the campaign: two sending threads for one account is the
        race this protects against. Two *different* accounts each reserving the
        same address is allowed, and is the point of a per-user history.
        """
        SentLead.objects.create(
            owner=default_user(),
            business_name="Shop 1", email="shop1@example.test",
            status=SentLead.Status.SENDING)
        session = FakeSession()

        self._run(session)

        self.assertNotIn("shop1@example.test", session.sent)
        self.assertEqual(len(session.sent), 2)


class ExcelExportTests(SignedIn):
    """The spreadsheet is an export of the database, appended to."""

    def setUp(self):
        import tempfile
        from pathlib import Path

        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)
        patcher = mock.patch("django.conf.settings.EXPORT_DIR", self.dir)
        patcher.start()
        self.addCleanup(patcher.stop)

    def _read(self):
        from openpyxl import load_workbook

        sheet = load_workbook(history.excel_path(default_user())).active
        return [list(r) for r in sheet.iter_rows(values_only=True)]

    def test_the_file_is_created_with_the_expected_columns(self):
        make_sent()

        result = history.export_excel(default_user())

        self.assertTrue(history.excel_path(default_user()).exists())
        self.assertEqual(result["added"], 1)
        rows = self._read()
        self.assertEqual(rows[0], list(history.HEADERS))
        self.assertIn("Bella Cucina", rows[1])
        self.assertIn("ciao@bella.example", rows[1])

    def test_a_second_run_appends_only_new_records(self):
        make_sent(email="a@x.example")
        history.export_excel(default_user())
        make_sent(email="b@x.example", business_name="Second Shop")

        result = history.export_excel(default_user())

        self.assertEqual(result["added"], 1)
        self.assertEqual(result["total"], 2)
        emails = [row[2] for row in self._read()[1:]]
        self.assertEqual(sorted(emails), ["a@x.example", "b@x.example"])

    def test_running_twice_with_no_new_records_changes_nothing(self):
        make_sent()
        history.export_excel(default_user())

        result = history.export_excel(default_user())

        self.assertEqual(result["added"], 0)
        self.assertEqual(result["total"], 1)

    def test_earlier_rows_are_never_overwritten(self):
        make_sent(email="first@x.example", business_name="First")
        history.export_excel(default_user())
        for i in range(3):
            make_sent(email=f"later{i}@x.example", business_name=f"Later {i}")
        history.export_excel(default_user())

        names = [row[1] for row in self._read()[1:]]
        self.assertEqual(names[0], "First")
        self.assertEqual(len(names), 4)

    def test_failed_rows_appear_with_their_status(self):
        make_sent(email="bad@x.example", status=SentLead.Status.FAILED,
                  sent_at=None, sent_date=None, sent_time=None,
                  error_message="SMTPRecipientsRefused")

        history.export_excel(default_user())

        row = self._read()[1]
        self.assertIn("Failed", row)
        self.assertIn("SMTPRecipientsRefused", row)

    def test_in_flight_reservations_are_not_exported(self):
        SentLead.objects.create(business_name="Mid flight", email="m@x.example",
                                status=SentLead.Status.SENDING)

        result = history.export_excel(default_user())

        self.assertEqual(result["added"], 0)

    def test_a_damaged_file_is_replaced_rather_than_failing_the_send(self):
        history.excel_path(default_user()).write_bytes(b"this is not a spreadsheet")
        make_sent()

        result = history.export_excel(default_user())

        self.assertEqual(result["added"], 1)
        self.assertEqual(self._read()[0], list(history.HEADERS))

    def test_exported_rows_are_stamped(self):
        row = make_sent()

        history.export_excel(default_user())

        row.refresh_from_db()
        self.assertIsNotNone(row.exported_at)

    def test_stats_report_the_history(self):
        make_sent(email="a@x.example")
        make_sent(email="b@x.example", status=SentLead.Status.FAILED,
                  sent_at=None, sent_date=None, sent_time=None)

        stats = history.stats(default_user())

        self.assertEqual(stats["sent"], 1)
        self.assertEqual(stats["failed"], 1)
        self.assertEqual(stats["domains"], 1)
