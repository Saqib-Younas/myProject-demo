"""
Lead scoring, website classification and service recommendation.

Deterministic on purpose. Every number below is computed from something the
crawler actually measured or the reviewer actually found -- a response time, a
missing viewport tag, a count of calls to action -- and every number carries the
list of reasons that produced it. Two consequences:

  * **Scores are explainable.** `Score.factors` is what the UI shows, so "72"
    always comes with the four or five facts that made it 72. A score nobody can
    account for is a score nobody should act on.
  * **Scores cost nothing.** The expensive part of assessing a lead is the crawl
    and the AI review; the arithmetic is free and repeatable, so re-scoring a
    stored audit does not re-spend anything.

The AI is not asked for numbers. It interprets -- what the findings mean for this
business, how to phrase an approach -- and that division is deliberate: a model
asked to produce a score produces a different one each time, from nothing.

THE RULE THAT OVERRIDES THE REST: never invent a fact. There is no revenue
figure, traffic estimate, employee count or search ranking anywhere in this
module, because the application has no way to know any of them. Where a signal is
absent the score says so ("not measured") rather than assuming a value.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from django.conf import settings

# --------------------------------------------------------------------------- #
# Website classification
# --------------------------------------------------------------------------- #

WEBSITE_FOUND = "website_found"
NO_WEBSITE_OPPORTUNITY = "no_website_opportunity"
WEBSITE_UNVERIFIED = "website_unverified"

CLASSIFICATION_LABELS = {
    WEBSITE_FOUND: "Website found",
    NO_WEBSITE_OPPORTUNITY: "No website",
    WEBSITE_UNVERIFIED: "Website unverified",
    "": "Not classified",
}


def classify(*, website: str, analysis_status: str, pages_read: int) -> tuple[str, str]:
    """(classification, reason) for one lead.

    The distinction that matters is the third one. A site that could not be read
    -- blocked by robots.txt, behind a bot check, timing out -- is **unverified**,
    not absent. Calling it "no website" would invent a fact about the business and
    then sell against it, which is both wrong and embarrassing in an email.
    """
    from . import analyzer

    has_url = bool((website or "").strip())

    if analysis_status == analyzer.OK and pages_read > 0:
        return WEBSITE_FOUND, f"{pages_read} page(s) read successfully."

    if not has_url:
        if analysis_status in ("", analyzer.NO_WEBSITE):
            return (NO_WEBSITE_OPPORTUNITY,
                    "No website address published in the source listing.")
        return WEBSITE_UNVERIFIED, "No website address, and verification failed."

    if analysis_status == analyzer.NO_WEBSITE:
        # A URL was listed but resolved to nothing usable. That is closer to
        # "unverified" than to "no website": the listing says one exists.
        return (WEBSITE_UNVERIFIED,
                "A website address was listed but could not be reached.")

    if analysis_status == analyzer.BLOCKED:
        return (WEBSITE_UNVERIFIED,
                "The site refused automated access (robots.txt, a bot check or a "
                "403/429). Whether it is a working site is unknown.")

    if analysis_status == analyzer.FAILED:
        return (WEBSITE_UNVERIFIED,
                "The site could not be read -- a timeout, DNS failure or server "
                "error. Unknown rather than absent.")

    if analysis_status == analyzer.OK:
        return (WEBSITE_UNVERIFIED,
                "The site responded but no page content could be analysed.")

    return WEBSITE_UNVERIFIED, "Not analysed yet."


# --------------------------------------------------------------------------- #
# Scores
# --------------------------------------------------------------------------- #

@dataclass(frozen=True)
class Factor:
    """One thing that moved a score, and the evidence for it."""

    label: str
    points: int              # signed: negative lowers the site's quality score
    evidence: str = ""

    def as_dict(self) -> dict:
        return {"label": self.label, "points": self.points,
                "evidence": self.evidence}


@dataclass
class Score:
    """A 0-100 value and the reasons for it."""

    value: int
    factors: list[Factor] = field(default_factory=list)
    #: Set when there was nothing to measure. A score of 0 and "not measured" are
    #: different answers and must not look the same.
    measured: bool = True

    def as_dict(self) -> dict:
        return {
            "value": self.value,
            "measured": self.measured,
            "factors": [f.as_dict() for f in self.factors],
        }

    @property
    def display(self) -> str:
        return str(self.value) if self.measured else "Unknown"


def _clamp(value: float) -> int:
    return max(0, min(100, int(round(value))))


def _quality(deductions: list[Factor], *, measured: bool = True) -> Score:
    """A quality score: 100 minus what the evidence takes off."""
    if not measured:
        return Score(value=0, factors=[], measured=False)
    total = sum(f.points for f in deductions)
    return Score(value=_clamp(100 + total), factors=deductions)


# --- the six website sub-scores -------------------------------------------- #
#
# Each reads only signals `analyzer.measure()` actually produces. A signal that
# is absent from the dict was not measured on that page, and is skipped rather
# than assumed -- which is why every check below tests for presence first.

def performance_score(signals: dict) -> Score:
    """Response time and page weight, as measured on the pages that were read."""
    if "load_ms" not in signals:
        return _quality([], measured=False)

    out: list[Factor] = []
    load = signals.get("load_ms") or 0
    if load >= 4000:
        out.append(Factor("Very slow to respond", -45, f"{load} ms measured"))
    elif load >= 2500:
        out.append(Factor("Slow to respond", -30, f"{load} ms measured"))
    elif load >= 1200:
        out.append(Factor("Sluggish response", -15, f"{load} ms measured"))

    weight = signals.get("page_kb") or 0
    if weight >= 3000:
        out.append(Factor("Very heavy page", -25, f"{weight} KB"))
    elif weight >= 1500:
        out.append(Factor("Heavy page", -12, f"{weight} KB"))

    scripts = signals.get("external_scripts") or 0
    if scripts >= 25:
        out.append(Factor("Many external scripts", -12, f"{scripts} scripts"))
    elif scripts >= 15:
        out.append(Factor("Several external scripts", -6, f"{scripts} scripts"))

    images = signals.get("images") or 0
    legacy = signals.get("images_legacy_format") or 0
    modern = signals.get("images_modern_format") or 0
    if images >= 5 and legacy and not modern:
        out.append(Factor("No modern image formats", -8,
                          f"{legacy} JPEG/PNG references, none WebP or AVIF"))
    if images >= 10 and not signals.get("images_lazy_loaded"):
        out.append(Factor("No lazy loading", -6, f"{images} images, none deferred"))
    return _quality(out)


def mobile_score(signals: dict) -> Score:
    """Whether the markup is set up for a phone at all.

    A missing viewport tag is the one mobile problem that can be established from
    markup with certainty, so it carries the most weight. Nothing here claims to
    know how the site *looks* on a phone -- no screenshot was taken.
    """
    if "viewport_meta" not in signals:
        return _quality([], measured=False)

    out: list[Factor] = []
    if not signals.get("viewport_meta"):
        out.append(Factor("No viewport meta tag", -55,
                          "Absent, so mobile browsers render at desktop width"))
    else:
        content = (signals.get("viewport_content") or "").lower()
        if "width=device-width" not in content:
            out.append(Factor("Viewport does not use device width", -25,
                              f"content=\"{content[:60]}\""))
        if "user-scalable=no" in content or "maximum-scale=1" in content:
            out.append(Factor("Zoom disabled", -12,
                              "Blocks pinch-to-zoom, which some readers rely on"))

    fixed = signals.get("fixed_width_attrs") or 0
    if fixed >= 5:
        out.append(Factor("Fixed-width elements", -18,
                          f"{fixed} elements with a hard-coded width"))
    elif fixed:
        out.append(Factor("Some fixed-width elements", -8,
                          f"{fixed} element(s) with a hard-coded width"))
    return _quality(out)


def seo_score(signals: dict) -> Score:
    """The basics that are visible in the markup. Nothing about rankings."""
    if "title_length" not in signals:
        return _quality([], measured=False)

    out: list[Factor] = []
    title = signals.get("title_length") or 0
    if title == 0:
        out.append(Factor("No page title", -30, "The <title> element is empty"))
    elif title < 15:
        out.append(Factor("Very short page title", -15, f"{title} characters"))
    elif title > 70:
        out.append(Factor("Overlong page title", -8,
                          f"{title} characters; search results truncate near 60"))

    desc = signals.get("meta_description_length") or 0
    if desc == 0:
        out.append(Factor("No meta description", -20,
                          "Search engines will invent the snippet instead"))
    elif desc < 50:
        out.append(Factor("Very short meta description", -8, f"{desc} characters"))

    h1 = signals.get("h1_count")
    if h1 == 0:
        out.append(Factor("No H1 heading", -12, "No top-level heading found"))
    elif h1 and h1 > 3:
        out.append(Factor("Several H1 headings", -6, f"{h1} H1 elements"))

    if not signals.get("canonical"):
        out.append(Factor("No canonical link", -6, "Absent"))
    if not signals.get("og_tags"):
        out.append(Factor("No Open Graph tags", -8,
                          "Shared links will not show a title or image"))
    if not signals.get("structured_data_blocks"):
        out.append(Factor("No structured data", -8,
                          "No JSON-LD block, so no rich result is possible"))
    if signals.get("html_lang") in ("MISSING", None, ""):
        out.append(Factor("No language attribute", -4, "<html> has no lang"))
    return _quality(out)


def ux_score(signals: dict) -> Score:
    """Content and navigation quality, from counts rather than impressions."""
    if "word_count" not in signals:
        return _quality([], measured=False)

    out: list[Factor] = []
    words = signals.get("word_count") or 0
    if words < 120:
        out.append(Factor("Very little page content", -30, f"{words} words"))
    elif words < 300:
        out.append(Factor("Thin page content", -15, f"{words} words"))

    placeholders = signals.get("placeholder_text_found")
    if placeholders:
        out.append(Factor("Placeholder text still published", -25,
                          ", ".join(placeholders[:3])))

    year = signals.get("copyright_year")
    if year:
        try:
            from django.utils import timezone
            behind = timezone.now().year - int(year)
            if behind >= 3:
                out.append(Factor("Stale copyright year", -12,
                                  f"Footer says {year}"))
        except (TypeError, ValueError):
            pass

    images = signals.get("images") or 0
    missing_alt = signals.get("images_missing_alt") or 0
    if images and missing_alt:
        share = missing_alt / images
        if share >= 0.6:
            out.append(Factor("Most images have no alt text", -20,
                              f"{missing_alt} of {images}"))
        elif share >= 0.25:
            out.append(Factor("Many images have no alt text", -10,
                              f"{missing_alt} of {images}"))

    vague = signals.get("vague_link_text") or 0
    if vague >= 5:
        out.append(Factor("Vague link text", -10,
                          f'{vague} links reading "click here" or similar'))
    elif vague:
        out.append(Factor("Some vague link text", -5, f"{vague} link(s)"))

    new_tabs = signals.get("links_new_tab_no_warning") or 0
    if new_tabs >= 8:
        out.append(Factor("Many links open new tabs unannounced", -6,
                          f"{new_tabs} links"))
    return _quality(out)


def conversion_score(signals: dict) -> Score:
    """Whether an interested visitor can act. The commercially useful one."""
    if "cta_count" not in signals:
        return _quality([], measured=False)

    out: list[Factor] = []
    ctas = signals.get("cta_count") or 0
    if ctas == 0:
        out.append(Factor("No call to action found", -40,
                          "No link or button matching a booking, quote, call or "
                          "contact phrase"))
    elif ctas == 1:
        out.append(Factor("Only one call to action", -18,
                          f'A single prompt: "{(signals.get("cta_examples") or [""])[0]}"'))

    forms = signals.get("forms") or 0
    mailto = signals.get("mailto_links") or 0
    tel = signals.get("tel_links") or 0
    if not forms and not mailto and not tel:
        out.append(Factor("No way to make contact from the page", -30,
                          "No form, no mailto: link, no tel: link"))
    else:
        if not forms:
            out.append(Factor("No contact form", -10,
                              "Contact depends on the visitor typing an address"))
        if not tel:
            out.append(Factor("Phone number not tappable", -8,
                              "No tel: link, so a phone visitor cannot dial it"))

    unlabelled = signals.get("form_fields_unlabelled") or 0
    if unlabelled >= 3:
        out.append(Factor("Form fields without labels", -12,
                          f"{unlabelled} fields with no label, aria-label or "
                          "placeholder"))
    elif unlabelled:
        out.append(Factor("Some form fields unlabelled", -6,
                          f"{unlabelled} field(s)"))

    if not signals.get("trust_signal_mentions"):
        out.append(Factor("No trust signals", -10,
                          "No testimonial, review, certification or guarantee "
                          "wording found"))
    if not signals.get("social_links"):
        out.append(Factor("No social links", -6, "None found"))
    if not signals.get("map_embed"):
        out.append(Factor("No map", -4,
                          "No embedded map, which a local visitor often wants"))
    return _quality(out)


def technical_score(signals: dict) -> Score:
    """Transport security and configuration. Deliberately narrow.

    This is not a security audit: nothing here inspects headers, certificates or
    software versions. It reports what a page fetch can establish.
    """
    if "https" not in signals:
        return _quality([], measured=False)

    out: list[Factor] = []
    if not signals.get("https"):
        out.append(Factor("Served over plain HTTP", -60,
                          "No HTTPS, so browsers mark it 'Not secure'"))
    if signals.get("inline_style_blocks", 0) >= 8:
        out.append(Factor("Many inline style blocks", -8,
                          f"{signals['inline_style_blocks']} <style> blocks"))
    if (signals.get("stylesheets") or 0) >= 12:
        out.append(Factor("Many stylesheets", -6,
                          f"{signals['stylesheets']} stylesheet links"))
    return _quality(out)


#: The sub-scores, in the order the lead page shows them.
SUB_SCORES = (
    ("performance", "Performance", performance_score),
    ("mobile", "Mobile", mobile_score),
    ("seo", "SEO", seo_score),
    ("ux", "UX & content", ux_score),
    ("conversion", "Conversion", conversion_score),
    ("technical", "Security & technical", technical_score),
)

#: Weights for the overall website quality score. Conversion and mobile lead
#: because they are what a small business loses enquiries to; SEO basics matter
#: but a missing canonical tag does not cost a booking today.
SUB_WEIGHTS = {
    "conversion": 0.28,
    "mobile": 0.22,
    "performance": 0.18,
    "ux": 0.14,
    "seo": 0.10,
    "technical": 0.08,
}


def merge_signals(pages: list[dict]) -> dict:
    """One signal set from several pages.

    Worst-case for quality signals, total for counts. A site with one fast page
    and one four-second page has a four-second problem, and averaging would hide
    exactly the finding worth raising.
    """
    merged: dict = {}
    for facts in pages:
        for key, value in (facts or {}).items():
            if key not in merged:
                merged[key] = value
                continue
            current = merged[key]
            if isinstance(value, bool) and isinstance(current, bool):
                merged[key] = current and value        # any page missing it counts
            elif key in ("load_ms", "page_kb", "external_scripts", "stylesheets",
                         "inline_style_blocks", "fixed_width_attrs",
                         "vague_link_text", "links_new_tab_no_warning",
                         "form_fields_unlabelled"):
                merged[key] = max(current, value)      # worst page wins
            elif key in ("word_count", "cta_count", "title_length",
                         "meta_description_length", "trust_signal_mentions",
                         "social_links", "forms", "mailto_links", "tel_links",
                         "og_tags", "structured_data_blocks", "h1_count"):
                merged[key] = max(current, value)      # best page wins
            elif isinstance(value, int) and isinstance(current, int):
                merged[key] = current + value
            elif isinstance(value, list) and isinstance(current, list):
                merged[key] = list(dict.fromkeys(current + value))
    return merged


@dataclass
class WebsiteAssessment:
    """Everything computed about one website."""

    sub_scores: dict[str, Score] = field(default_factory=dict)
    quality: Score = field(default_factory=lambda: Score(0, measured=False))
    opportunity: Score = field(default_factory=lambda: Score(0, measured=False))

    def as_dict(self) -> dict:
        return {
            "sub_scores": {k: v.as_dict() for k, v in self.sub_scores.items()},
            "quality": self.quality.as_dict(),
            "opportunity": self.opportunity.as_dict(),
        }


#: How much each severity of finding adds to the opportunity score. A confirmed
#: critical problem is worth more than five cosmetic ones.
SEVERITY_WEIGHT = {"critical": 14, "high": 10, "medium": 5, "low": 2}


# --------------------------------------------------------------------------- #
# Which findings go in the email
#
# An audit produces eight to ten findings. An email may carry one to three, and
# *which* three decides whether it reads like a consultant or like a linter.
# The order below is the brief's, and it is commercial rather than technical: a
# booking form that does not work outranks a missing canonical tag however much
# easier the second is to measure.
#
# Deterministic, and in code rather than in the prompt, for two reasons. A model
# asked to "pick the most commercially relevant" will reliably favour whatever it
# can describe most fluently, and the ordering is a business decision that should
# be readable, testable and changeable without touching a prompt.
# --------------------------------------------------------------------------- #

#: Tier 1 is the most commercially relevant. Matched against a finding's
#: dimension and its issue text, so a reviewer that writes "checkout" instead of
#: "conversion" still lands in the right tier.
COMMERCIAL_TIERS: tuple[tuple[int, str, tuple[str, ...]], ...] = (
    (1, "Broken or missing functionality", (
        "broken", "does not work", "doesn't work", "404", "error page",
        "dead link", "form fails", "not submitting", "unavailable",
        "missing page", "no booking", "booking form", "checkout", "payment",
    )),
    (2, "Customer journey and conversion", (
        "conversion", "call to action", "call-to-action", "cta", "enquiry",
        "enquire", "contact form", "no contact", "phone number", "get in touch",
        "lead capture", "next step", "booking", "quote", "sign up", "signup",
    )),
    (3, "Mobile usability", (
        "mobile", "responsive", "viewport", "small screen", "tap", "thumb",
        "pinch", "zoom", "fixed width",
    )),
    (4, "Speed and performance", (
        "performance", "speed", "slow", "load", "loading", "page weight",
        "heavy", "render", "lcp", "time to",
    )),
    (5, "Missing or thin content", (
        "content", "thin", "sparse", "missing information", "no pricing",
        "no services", "unclear", "services page", "about", "opening hours",
        "hours", "location", "trust", "review", "testimonial", "photo",
    )),
    (6, "Search visibility", (
        "seo", "search", "google", "title tag", "page title", "meta",
        "description", "heading", "h1", "canonical", "sitemap", "schema",
        "structured data", "alt text", "alt attribute", "indexing",
    )),
    (7, "Technical detail", (
        "technical", "https", "ssl", "certificate", "accessibility",
        "aria", "markup", "validation", "script", "stylesheet", "cache",
        "compression", "favicon",
    )),
)

#: A finding that matches nothing lands here -- between "missing content" and
#: "search visibility". Not last: an unmatched finding is usually a real issue
#: described in words this table has not seen, and burying it under a favicon
#: would be the wrong guess.
DEFAULT_TIER = 5

#: Ordering weight within a tier. The audit's own severity, which is evidence-
#: backed, breaks ties inside a commercial band rather than across bands.
_SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}

#: The most findings an email may be built on. One is often better; three is the
#: point at which a first-contact email starts reading like an audit report.
EMAIL_FINDING_LIMIT = 3


def commercial_tier(finding) -> int:
    """Which tier of COMMERCIAL_TIERS this finding belongs to.

    The dimension is checked first and on its own, because it is the field the
    reviewer chose deliberately. The issue text is a fallback, and is checked
    against the same keywords so a well-described finding in an unhelpfully named
    dimension still ranks correctly.
    """
    dimension = (getattr(finding, "dimension", "") or "").lower()
    issue = (getattr(finding, "issue", "") or "").lower()

    for tier, _label, keywords in COMMERCIAL_TIERS:
        if any(word in dimension for word in keywords):
            return tier
    for tier, _label, keywords in COMMERCIAL_TIERS:
        if any(word in issue for word in keywords):
            return tier
    return DEFAULT_TIER


def tier_label(tier: int) -> str:
    for value, label, _keywords in COMMERCIAL_TIERS:
        if value == tier:
            return label
    return "Other"


def rank_for_email(findings: list, limit: int = EMAIL_FINDING_LIMIT) -> list:
    """The one to three findings an email should be built on.

    Sorted by commercial tier, then by the audit's severity, then by the order
    the reviewer produced them -- which is itself strongest-first, so an
    otherwise-tied pair keeps the reviewer's judgement.

    Findings with no evidence are dropped rather than ranked. An unevidenced
    finding is exactly the invented website problem this application must never
    put in an email, and the cheapest place to stop it is before the prompt.
    """
    usable = [
        f for f in (findings or [])
        if (getattr(f, "issue", "") or "").strip()
        and (getattr(f, "evidence", "") or "").strip()
    ]
    ordered = sorted(
        enumerate(usable),
        key=lambda pair: (
            commercial_tier(pair[1]),
            _SEVERITY_ORDER.get(
                (getattr(pair[1], "severity", "") or "").lower(), 2),
            pair[0],
        ),
    )
    return [finding for _index, finding in ordered[:max(1, limit)]]


def assess_website(signals: dict, findings: list | None = None) -> WebsiteAssessment:
    """Sub-scores, overall quality, and the opportunity that follows from it.

    Opportunity is the inverse of quality, adjusted by the findings the reviewer
    actually evidenced. A poor site is a large opportunity; a good site is a small
    one, however much anybody would like to sell to it.
    """
    subs = {key: fn(signals) for key, _label, fn in SUB_SCORES}
    measured = [key for key, score in subs.items() if score.measured]

    if not measured:
        return WebsiteAssessment(sub_scores=subs)

    # Re-weighted across the sub-scores that were actually measured, so an
    # unmeasured area neither helps nor hurts.
    total_weight = sum(SUB_WEIGHTS[key] for key in measured)
    quality_value = sum(
        subs[key].value * SUB_WEIGHTS[key] for key in measured) / total_weight
    quality_factors = [
        Factor(f"{label}: {subs[key].value}", 0,
               f"weight {int(SUB_WEIGHTS[key] * 100)}%")
        for key, label, _fn in SUB_SCORES if subs[key].measured
    ]
    quality = Score(_clamp(quality_value), quality_factors)

    # Opportunity: the room to improve, plus credit for evidenced findings.
    room = 100 - quality.value
    evidenced = [f for f in (findings or []) if getattr(f, "evidence", "")]
    bonus = sum(SEVERITY_WEIGHT.get(
        (getattr(f, "severity", "") or "medium").lower(), 5) for f in evidenced)

    opportunity_factors = [
        Factor("Room to improve", room, f"Website quality scored {quality.value}/100"),
    ]
    if evidenced:
        counts: dict[str, int] = {}
        for finding in evidenced:
            level = (getattr(finding, "severity", "") or "medium").lower()
            counts[level] = counts.get(level, 0) + 1
        opportunity_factors.append(Factor(
            "Evidenced findings", min(bonus, 30),
            ", ".join(f"{n} {level}" for level, n in sorted(counts.items()))))
    else:
        opportunity_factors.append(Factor(
            "No evidenced findings yet", 0,
            "The review has not run, or found nothing it could evidence"))

    opportunity = Score(_clamp(room + min(bonus, 30)), opportunity_factors)
    return WebsiteAssessment(sub_scores=subs, quality=quality,
                             opportunity=opportunity)


# --------------------------------------------------------------------------- #
# Business value
# --------------------------------------------------------------------------- #

#: How much a website plausibly matters to each kind of business, on the evidence
#: available: whether customers choose it online, whether enquiries arrive by
#: search, whether presentation affects the decision.
#:
#: This is a judgement about the *category*, not about the business -- the
#: application knows nothing about any individual company's size or revenue and
#: does not pretend to. Categories the scraper does not recognise get the neutral
#: baseline rather than a guess.
CATEGORY_VALUE = {
    "Hotels & Guest Houses": 92,
    "Real Estate Agents": 90,
    "Restaurants": 84,
    "Dentists": 84,
    "Lawyers": 82,
    "Travel Agencies": 82,
    "Doctors & Clinics": 80,
    "Gyms & Fitness": 80,
    "Car Repair & Dealers": 78,
    "Construction & Trades": 78,
    "Clothing & Fashion": 76,
    "Accountants": 76,
    "Schools & Education": 76,
    "Furniture & Interiors": 74,
    "Hairdressers & Beauty": 74,
    "Insurance": 72,
    "Bars & Pubs": 70,
    "Veterinarians": 70,
    "Cafes": 68,
    "IT & Software Offices": 68,
    "Electronics & Phones": 68,
    "Bakeries": 64,
    "Fast Food & Takeaway": 64,
    "Florists": 64,
    "Hardware & DIY": 60,
    "Pharmacies": 58,
    "Supermarkets & Grocery": 56,
    "Laundry & Dry Cleaning": 54,
    "Banks": 40,          # already have national marketing departments
    "Any business": 60,
}

NEUTRAL_CATEGORY_VALUE = 60


def business_value(*, category: str = "", phone: str = "", email: str = "",
                   website: str = "", social_links: int = 0,
                   city: str = "", country: str = "") -> Score:
    """How much better web presence could plausibly be worth to this business.

    Built only from what the listing and the crawl provide. There is no revenue
    estimate, no employee count and no traffic figure here, because the
    application has no way to obtain any of them.
    """
    factors: list[Factor] = []
    base = CATEGORY_VALUE.get((category or "").strip())
    if base is None:
        base = NEUTRAL_CATEGORY_VALUE
        factors.append(Factor(
            "Category not recognised", base,
            f"{category or 'No category'} -- neutral baseline used rather than "
            "a guess"))
    else:
        factors.append(Factor("Customer-facing category", base,
                              f"{category}"))

    total = float(base)

    # Contactability is evidence that the business wants enquiries.
    if phone:
        total += 5
        factors.append(Factor("Publishes a phone number", 5, phone[:24]))
    if email:
        total += 5
        factors.append(Factor("Publishes an email address", 5, email[:40]))
    if not phone and not email:
        total -= 10
        factors.append(Factor("No published contact details", -10,
                              "Harder to reach, and a weaker signal of intent"))

    if social_links:
        total += 4
        factors.append(Factor("Active on social platforms", 4,
                              f"{social_links} profile link(s) found"))

    if city or country:
        total += 3
        factors.append(Factor("Location known", 3,
                              ", ".join(p for p in (city, country) if p)))

    return Score(_clamp(total), factors)


# --------------------------------------------------------------------------- #
# The no-website opportunity
# --------------------------------------------------------------------------- #

#: Benefits a website could plausibly bring, per category. Only shown for the
#: category in hand, and phrased as possibility rather than promise -- "could
#: make it easier", never "will increase sales".
CATEGORY_BENEFITS = {
    "Restaurants": ["showing the menu", "taking table bookings",
                    "opening hours customers can check"],
    "Cafes": ["showing the menu", "opening hours customers can check"],
    "Bakeries": ["showing what is made fresh", "taking order enquiries"],
    "Fast Food & Takeaway": ["showing the menu", "taking order enquiries"],
    "Bars & Pubs": ["what is on", "opening hours customers can check"],
    "Hotels & Guest Houses": ["showing rooms", "taking booking enquiries",
                              "answering questions before arrival"],
    "Dentists": ["taking appointment enquiries", "explaining treatments",
                 "answering common questions before a call"],
    "Doctors & Clinics": ["taking appointment enquiries", "listing services"],
    "Veterinarians": ["taking appointment enquiries", "listing services"],
    "Lawyers": ["explaining areas of practice", "taking enquiries in writing"],
    "Accountants": ["explaining services", "taking enquiries in writing"],
    "Insurance": ["explaining cover", "taking enquiries in writing"],
    "Real Estate Agents": ["showing listings", "taking viewing enquiries"],
    "Gyms & Fitness": ["showing classes and timetables", "taking trial enquiries"],
    "Hairdressers & Beauty": ["showing work", "taking appointment enquiries"],
    "Clothing & Fashion": ["showing the range", "answering sizing questions"],
    "Furniture & Interiors": ["showing the range", "taking quote enquiries"],
    "Construction & Trades": ["showing completed work", "taking quote enquiries"],
    "Car Repair & Dealers": ["listing services", "taking booking enquiries"],
    "Travel Agencies": ["showing what is on offer", "taking enquiries"],
    "Schools & Education": ["explaining courses", "taking enrolment enquiries"],
    "Electronics & Phones": ["listing what is stocked", "taking repair enquiries"],
    "Florists": ["showing arrangements", "taking order enquiries"],
    "Pharmacies": ["opening hours customers can check", "listing services"],
    "Hardware & DIY": ["listing what is stocked", "opening hours"],
    "Supermarkets & Grocery": ["opening hours customers can check"],
    "Laundry & Dry Cleaning": ["listing services and prices", "opening hours"],
    "IT & Software Offices": ["explaining services", "taking enquiries"],
    "Banks": ["listing services", "opening hours"],
}

#: Benefits that apply whatever the business does.
UNIVERSAL_BENEFITS = [
    "being findable when somebody searches for this kind of business locally",
    "somewhere to send people who ask what the business does",
    "a presence that works outside opening hours",
]


def missing_website_opportunity(*, category: str = "", phone: str = "",
                               email: str = "", social_links: int = 0
                               ) -> tuple[Score, list[str]]:
    """(score, benefits) for a lead with no verified website.

    A business with no website is not a failed lead -- it is the clearest kind of
    opportunity this application can find. The score says how much a site could
    plausibly help *this category*, and the benefits list is what to talk about.
    """
    factors: list[Factor] = []
    base = CATEGORY_VALUE.get((category or "").strip(), NEUTRAL_CATEGORY_VALUE)
    factors.append(Factor("No website at all", 55,
                          "Nothing to improve on -- the whole thing is missing"))
    factors.append(Factor("Category benefit", int(base * 0.35),
                          category or "Category unknown"))

    total = 55 + base * 0.35

    if phone or email:
        total += 8
        factors.append(Factor("Already takes enquiries", 8,
                              "Publishes contact details, so enquiries matter to "
                              "them"))
    if social_links:
        total += 6
        factors.append(Factor("Already present on social platforms", 6,
                              f"{social_links} profile link(s) -- a site gives "
                              "those somewhere to point"))

    benefits = list(CATEGORY_BENEFITS.get((category or "").strip(), []))
    benefits += UNIVERSAL_BENEFITS
    return Score(_clamp(total), factors), benefits[:5]


# --------------------------------------------------------------------------- #
# Overall opportunity and priority
# --------------------------------------------------------------------------- #

def default_thresholds() -> dict[str, int]:
    """HOT / WARM / LOW boundaries, configurable per deployment."""
    return {
        "hot": int(getattr(settings, "OUTREACH_PRIORITY_HOT", 80)),
        "warm": int(getattr(settings, "OUTREACH_PRIORITY_WARM", 60)),
        "low": int(getattr(settings, "OUTREACH_PRIORITY_LOW", 40)),
    }


HOT, WARM, LOW, SKIP = "hot", "warm", "low", "skip"

PRIORITY_LABELS = {HOT: "Hot", WARM: "Warm", LOW: "Low priority",
                   SKIP: "Skip", "": "Not scored"}


def priority_band(score: int, thresholds: dict | None = None) -> str:
    limits = thresholds or default_thresholds()
    if score >= limits["hot"]:
        return HOT
    if score >= limits["warm"]:
        return WARM
    if score >= limits["low"]:
        return LOW
    return SKIP


def overall_opportunity(*, classification: str, website_opportunity: Score,
                        missing_opportunity: Score,
                        value: Score) -> Score:
    """The single number the queues sort on.

    Business value and opportunity are combined rather than averaged blindly: a
    huge opportunity at a business a website cannot help is not a good prospect,
    and neither is a perfect prospect with a flawless site.
    """
    factors: list[Factor] = []

    if classification == NO_WEBSITE_OPPORTUNITY:
        opportunity = missing_opportunity
        factors.append(Factor("No verified website", opportunity.value,
                              "Scored as a missing-website opportunity"))
    elif classification == WEBSITE_FOUND and website_opportunity.measured:
        opportunity = website_opportunity
        factors.append(Factor("Website opportunity", opportunity.value,
                              "From the measured audit"))
    else:
        # Unverified: there is a business here, but no evidence about its site.
        # Scored on business value alone and capped, so an unknown never
        # outranks a lead that was actually assessed.
        capped = _clamp(min(value.value * 0.6, 55))
        return Score(capped, [
            Factor("Website unverified", capped,
                   "Scored on business value alone and capped -- an unknown "
                   "should not outrank an assessed lead"),
            Factor("Business value", value.value, "Category and contactability"),
        ])

    combined = opportunity.value * 0.6 + value.value * 0.4
    factors.append(Factor("Business value", value.value,
                          "Category and contactability"))
    factors.append(Factor("Weighting", 0, "60% opportunity, 40% business value"))
    return Score(_clamp(combined), factors)


# --------------------------------------------------------------------------- #
# Recommended service
# --------------------------------------------------------------------------- #

NEW_WEBSITE = "New Professional Website"
REDESIGN = "Website Redesign"
MOBILE = "Mobile Optimization"
PERFORMANCE = "Performance Optimization"
SEO = "SEO Improvements"
CONVERSION = "Conversion Optimization"
LANDING = "Landing Page"
ECOMMERCE = "E-commerce Website"
MAINTENANCE = "Maintenance"

SERVICES = (NEW_WEBSITE, REDESIGN, MOBILE, PERFORMANCE, SEO, CONVERSION,
            LANDING, ECOMMERCE, MAINTENANCE)


def recommend_service(*, classification: str, assessment: WebsiteAssessment,
                      category: str = "") -> tuple[str, str]:
    """(service, why). Recommends the largest real problem, or nothing much.

    Deliberately conservative: a site that measures well is offered maintenance
    rather than a redesign it does not need. Recommending work nobody needs is
    how an outreach email earns a reputation.
    """
    if classification == NO_WEBSITE_OPPORTUNITY:
        if (category or "").strip() in ("Clothing & Fashion", "Electronics & Phones",
                                        "Furniture & Interiors", "Florists",
                                        "Bakeries"):
            return (NEW_WEBSITE,
                    "No website at all, and this category usually sells products "
                    "-- a site with a catalogue is the starting point.")
        return (NEW_WEBSITE,
                "No verified website, so the first step is having one.")

    if classification == WEBSITE_UNVERIFIED:
        return ("", "The website could not be verified, so no service is "
                    "recommended yet.")

    subs = assessment.sub_scores
    if not any(score.measured for score in subs.values()):
        return "", "Nothing was measured, so no service is recommended."

    # The weakest measured area decides, with a floor: an area scoring 70 is not
    # a problem worth an email.
    measured = {key: score.value for key, score in subs.items() if score.measured}
    worst_key = min(measured, key=lambda key: measured[key])
    worst = measured[worst_key]

    quality = assessment.quality.value
    if quality < 40 and len([v for v in measured.values() if v < 50]) >= 3:
        return (REDESIGN,
                f"Website quality scored {quality}/100 with weakness across "
                f"{len([v for v in measured.values() if v < 50])} areas.")

    if worst >= 70:
        return (MAINTENANCE,
                f"The site measures well (weakest area {worst_key} at {worst}/100). "
                "Upkeep rather than rebuilding.")

    mapping = {
        "mobile": (MOBILE, "the site is not set up for phones"),
        "performance": (PERFORMANCE, "the site is slow to respond"),
        "seo": (SEO, "the SEO basics are missing"),
        "conversion": (CONVERSION, "visitors have no clear way to act"),
        "ux": (REDESIGN, "the content and navigation need work"),
        "technical": (MAINTENANCE, "there are configuration issues"),
    }
    service, reason = mapping[worst_key]
    return service, f"Weakest measured area is {worst_key} at {worst}/100 -- {reason}."


# --------------------------------------------------------------------------- #
# Email readiness
# --------------------------------------------------------------------------- #

def email_readiness(*, classification: str, email: str = "",
                    business_name: str = "", findings: list | None = None,
                    observation: str = "", pages_read: int = 0,
                    opportunity: int = 0, benefits: list | None = None) -> Score:
    """Is there enough reliable material to send this lead anything?

    Low is not a verdict on the business -- it means the application does not know
    enough to write something worth reading. Sending anyway is how a personalised
    campaign turns into a mail merge.
    """
    factors: list[Factor] = []
    total = 0

    if email:
        total += 30
        factors.append(Factor("Valid email address", 30, email[:40]))
    else:
        factors.append(Factor("No email address", 0,
                              "Nothing can be sent without one"))
        return Score(0, factors)

    if business_name and business_name.lower() != "unnamed":
        total += 10
        factors.append(Factor("Business name known", 10, business_name[:40]))

    if classification == WEBSITE_FOUND:
        evidenced = [f for f in (findings or []) if getattr(f, "evidence", "")]
        if pages_read >= 3:
            total += 15
            factors.append(Factor("Website read properly", 15,
                                  f"{pages_read} pages"))
        elif pages_read:
            total += 8
            factors.append(Factor("Website partly read", 8,
                                  f"{pages_read} page(s)"))
        if len(evidenced) >= 5:
            total += 25
            factors.append(Factor("Plenty of evidenced findings", 25,
                                  f"{len(evidenced)} findings"))
        elif evidenced:
            total += 14
            factors.append(Factor("Some evidenced findings", 14,
                                  f"{len(evidenced)} finding(s)"))
        else:
            factors.append(Factor("No evidenced findings", 0,
                                  "There is nothing specific to write about"))
    elif classification == NO_WEBSITE_OPPORTUNITY:
        total += 25
        factors.append(Factor("Clear no-website angle", 25,
                              "The approach does not depend on an audit"))
        if benefits:
            total += 10
            factors.append(Factor("Category-specific benefits available", 10,
                                  f"{len(benefits)} to draw on"))
    else:
        factors.append(Factor("Website unverified", 0,
                              "Writing about a site nobody could read risks "
                              "claiming something untrue"))

    if observation and observation.lower() != "none":
        total += 10
        factors.append(Factor("A specific observation to open with", 10,
                              observation[:60]))

    if opportunity >= 70:
        total += 10
        factors.append(Factor("High opportunity score", 10, f"{opportunity}/100"))

    return Score(_clamp(total), factors)


READY_TO_SEND = 60


def is_ready(readiness: int) -> bool:
    """Whether to recommend sending. Advisory: the user still decides."""
    return readiness >= int(getattr(settings, "OUTREACH_READINESS_MIN",
                                    READY_TO_SEND))


# --------------------------------------------------------------------------- #
# Why this is a good prospect
# --------------------------------------------------------------------------- #

def explain(*, classification: str, category: str = "",
            assessment: WebsiteAssessment | None = None,
            findings: list | None = None, value: Score | None = None,
            overall: int = 0) -> str:
    """One short, factual sentence. Only ever restates evidence already held."""
    if classification == NO_WEBSITE_OPPORTUNITY:
        base = "no verified website"
        if category and category != "Any business":
            base += f" and a customer-facing category ({category.lower()})"
        return (f"{_band_word(overall)} opportunity because the business has "
                f"{base}.")

    if classification == WEBSITE_UNVERIFIED:
        return ("Opportunity unknown: the website could not be verified, so "
                "there is no evidence to judge it on.")

    if assessment is None or not assessment.quality.measured:
        return "Not yet assessed."

    evidenced = [f for f in (findings or []) if getattr(f, "evidence", "")]
    weakest = [
        (label, assessment.sub_scores[key].value)
        for key, label, _fn in SUB_SCORES
        if assessment.sub_scores[key].measured
        and assessment.sub_scores[key].value < 55
    ]
    weakest.sort(key=lambda pair: pair[1])

    parts = []
    if weakest:
        named = ", ".join(f"{label.lower()} ({value}/100)"
                          for label, value in weakest[:2])
        parts.append(f"the website scores poorly on {named}")
    if evidenced:
        parts.append(f"{len(evidenced)} evidenced finding(s)")
    if category and category != "Any business":
        parts.append(f"the business is customer-facing ({category.lower()})")

    if not parts:
        return (f"{_band_word(overall)} opportunity: the website measures well "
                f"({assessment.quality.value}/100), so there is little to fix.")
    return f"{_band_word(overall)} opportunity because " + ", and ".join(parts) + "."


def _band_word(score: int) -> str:
    band = priority_band(score)
    return {HOT: "High", WARM: "Moderate", LOW: "Low", SKIP: "Minimal"}[band]
