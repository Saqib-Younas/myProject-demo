"""
Stopping a run: AI rate limits, and one-click cancel.

Two ways a run ends early, and the same three promises apply to both:

  * **nothing keeps firing.** A provider that has just refused a request is not
    sent twenty-four more, and a cancelled job does not start the next lead.
  * **the position is kept.** Every lead that finished keeps its completion
    stamp, so resuming pays for nothing twice.
  * **the state is honest.** The phase says what actually happened, survives a
    reload, and cannot claim work is happening when it is not.

Cancellation wins over a rate-limit retry: a job waiting out a window and then
cancelled must stay cancelled.

Nothing here reaches a provider or a website -- every AI call and every crawl is a
double, and OUTREACH_BLOCK_SEND is on under `manage.py test`.
"""

from __future__ import annotations

from datetime import timedelta
from unittest import mock

from django.test import Client, TestCase
from django.urls import reverse
from django.utils import timezone

from . import ai, analyzer, runner
from .ai_base import QUOTA, RATE_LIMIT, AiError, classify_rate_limit, retry_after_of
from .models import Campaign, EmailDraft
from .tests import make_campaign, make_draft, make_findings
from .testsupport import OtherUser, SignedIn


def rate_limit_error(message="Rate limit reached, try again in 3s",
                     retry_after=None, category=RATE_LIMIT) -> AiError:
    """The error a backend raises when a provider refuses on allowance."""
    return AiError(message, retryable=True, category=category,
                   retry_after=retry_after)


class FakeHeaders(dict):
    """A requests-style headers mapping, case-insensitive enough for the test."""

    def get(self, key, default=None):
        for name, value in self.items():
            if name.lower() == key.lower():
                return value
        return default


class HeaderError(Exception):
    """An SDK error that kept the response headers, as most of them do."""

    def __init__(self, message, headers):
        super().__init__(message)
        self.response = mock.Mock(headers=FakeHeaders(headers))


# --------------------------------------------------------------------------- #
# What the provider said
# --------------------------------------------------------------------------- #

class RateLimitDetectionTests(TestCase):
    """A 429 is not one thing. Which one decides what happens next."""

    def test_a_per_minute_limit_is_waitable(self):
        self.assertEqual(
            classify_rate_limit("Rate limit reached, try again in 8.5s"),
            RATE_LIMIT)

    def test_a_daily_limit_is_a_quota(self):
        for message in ("Rate limit reached for requests per day",
                        "Limit 14400 requests per day exceeded",
                        "You exceeded your current quota",
                        "insufficient_quota: check your plan and billing"):
            with self.subTest(message=message[:30]):
                self.assertEqual(classify_rate_limit(message), QUOTA)

    def test_an_unrecognisable_message_is_treated_as_waitable(self):
        """The cheaper mistake of the two.

        Calling a per-minute limit a spent quota stops a run that thirty seconds
        would have fixed. The other way round costs one more refused request.
        """
        self.assertEqual(classify_rate_limit("429 Too Many Requests"),
                         RATE_LIMIT)

    def test_the_retry_after_header_is_respected(self):
        error = HeaderError("429", {"Retry-After": "45"})

        self.assertEqual(retry_after_of(error), 45.0)

    def test_the_millisecond_header_is_respected(self):
        error = HeaderError("429", {"retry-after-ms": "2500"})

        self.assertEqual(retry_after_of(error), 2.5)

    def test_a_delay_in_the_message_is_used_when_there_is_no_header(self):
        for message, expected in (
            ("Rate limit reached. Please try again in 8.532s", 8.532),
            ("Too many requests; retry after 20 seconds", 20.0),
            ("Slow down: try again in 500ms", 0.5),
            ("Try again in 2m", 120.0),
        ):
            with self.subTest(message=message[:30]):
                self.assertAlmostEqual(retry_after_of(Exception(message)),
                                       expected, places=3)

    def test_nothing_parseable_gives_no_answer(self):
        """None, not a guess: the caller has a backoff for exactly this."""
        self.assertIsNone(retry_after_of(Exception("429 Too Many Requests")))

    def test_a_malformed_header_does_not_raise(self):
        error = HeaderError("429", {"Retry-After": "soon"})

        self.assertIsNone(retry_after_of(error))

    def test_an_absurd_delay_is_ignored(self):
        """A provider asking for a fortnight is not answering the question."""
        self.assertIsNone(retry_after_of(Exception("try again in 999999s")))

    def test_the_error_carries_the_distinction(self):
        limit = rate_limit_error()
        quota = rate_limit_error(category=QUOTA)

        self.assertTrue(limit.rate_limited)
        self.assertFalse(limit.quota_exhausted)
        self.assertTrue(quota.rate_limited)
        self.assertTrue(quota.quota_exhausted)

    def test_an_ordinary_failure_is_neither(self):
        self.assertFalse(AiError("The model returned malformed JSON.").rate_limited)


class BackoffTests(TestCase):
    """The fallback when the provider does not say how long to wait."""

    def test_the_delay_doubles(self):
        self.assertEqual(
            [runner._backoff(n) for n in range(4)],
            [runner.BACKOFF_BASE * 1, runner.BACKOFF_BASE * 2,
             runner.BACKOFF_BASE * 4, runner.BACKOFF_BASE * 8])

    def test_the_delay_is_capped(self):
        self.assertEqual(runner._backoff(50), runner.BACKOFF_CAP)

    def test_the_providers_own_answer_wins(self):
        campaign = make_campaign()
        limit = runner.RateLimited(rate_limit_error(retry_after=12))

        # 13, not 12: a wait that ends a moment early buys another refusal.
        self.assertEqual(runner._pause_delay(campaign, limit), 13.0)

    def test_the_backoff_is_used_when_the_provider_says_nothing(self):
        campaign = make_campaign()
        campaign.pause_count = 1
        limit = runner.RateLimited(rate_limit_error(retry_after=None))

        self.assertEqual(runner._pause_delay(campaign, limit),
                         runner._backoff(1))


# --------------------------------------------------------------------------- #
# A run that hits a rate limit
# --------------------------------------------------------------------------- #

class PausingRunTests(SignedIn):
    """The pipeline parks on a rate limit instead of burning through the queue."""

    def setUp(self):
        self.campaign = make_campaign(phase=Campaign.Phase.CRAWLING)
        self.names = ["Alpha", "Beta", "Gamma"]
        self.drafts = {}
        for index, name in enumerate(self.names, 1):
            self.drafts[name] = make_draft(
                self.campaign, business_name=name,
                email=f"{name.lower()}@example.test",
                website=f"https://{name.lower()}.example",
                subject="", body="", sequence=index,
                status=EmailDraft.Status.PENDING)
        self.calls = []

        # Waits are real but tiny, so the wait path is exercised rather than
        # mocked out -- with the tick shorter still, so cancellation during a
        # wait is genuinely tested.
        patches = [
            mock.patch.object(runner, "BACKOFF_BASE", 0.02),
            mock.patch.object(runner, "BACKOFF_CAP", 0.05),
            mock.patch.object(runner, "WAIT_TICK", 0.005),
            mock.patch.object(runner, "AI_RETRY_DELAY", 0),
        ]
        for patch in patches:
            patch.start()
            self.addCleanup(patch.stop)

    def _analysis(self, url):
        return analyzer.SiteAnalysis(
            analyzer.OK, "Read 1 page(s).",
            [analyzer.Page(url, "home", "T", "", ["H"], "prose",
                           {"cta_count": 0, "load_ms": 900})],
            discovered=3)

    def _run(self, audit=None, generate=None, resume=False):
        def analyse(url, **kwargs):
            self.calls.append(("analyse", url))
            return self._analysis(url)

        def default_audit(**kwargs):
            self.calls.append(("audit", kwargs["website"]))
            return ai.SiteAudit("A cafe.", make_findings(4))

        def default_generate(**kwargs):
            self.calls.append(("generate", kwargs["website"]))
            return ai.GeneratedEmail("Subject", "Body of the email.",
                                     "no obvious way to get in touch",
                                     ["Issue 0"])

        with mock.patch.object(analyzer, "analyse", side_effect=analyse), \
             mock.patch.object(ai, "audit", side_effect=audit or default_audit), \
             mock.patch.object(ai, "generate",
                               side_effect=generate or default_generate):
            runner._pipeline(self.campaign, resume=resume)
        self.campaign.refresh_from_db()

    def _audit_limited_from(self, website, **kwargs):
        """An audit double that rate-limits from one lead onwards."""
        def audit(**call):
            self.calls.append(("audit", call["website"]))
            if call["website"] >= website:
                raise rate_limit_error(**kwargs)
            return ai.SiteAudit("A cafe.", make_findings(4))
        return audit

    # --- the pause itself ------------------------------------------------- #

    def test_a_quota_pauses_the_run(self):
        self._run(audit=self._audit_limited_from(
            "https://beta.example", category=QUOTA))

        self.assertEqual(self.campaign.phase, Campaign.Phase.PAUSED_RATE_LIMIT)
        self.assertEqual(self.campaign.pause_reason, Campaign.Pause.QUOTA)

    def test_the_remaining_leads_are_not_requested(self):
        """The core of the requirement: no more requests after a refusal."""
        self._run(audit=self._audit_limited_from(
            "https://beta.example", category=QUOTA))

        audited = [url for kind, url in self.calls if kind == "audit"]
        self.assertEqual(audited, ["https://alpha.example", "https://beta.example"])
        # Gamma was never touched at all -- not crawled, not audited, not written.
        self.assertNotIn(("analyse", "https://gamma.example"), self.calls)

    def test_the_same_request_is_not_retried(self):
        """One refusal, one entry. Retrying it is what the brief rules out."""
        self._run(audit=self._audit_limited_from(
            "https://alpha.example", category=QUOTA))

        self.assertEqual(
            [url for kind, url in self.calls if kind == "audit"],
            ["https://alpha.example"])

    def test_a_completed_lead_keeps_its_completion(self):
        self._run(audit=self._audit_limited_from(
            "https://beta.example", category=QUOTA))

        self.assertIsNotNone(
            EmailDraft.objects.get(pk=self.drafts["Alpha"].pk).processed_at)
        for name in ("Beta", "Gamma"):
            with self.subTest(name=name):
                self.assertIsNone(
                    EmailDraft.objects.get(pk=self.drafts[name].pk).processed_at)

    def test_a_quota_offers_no_countdown(self):
        """Nothing resumes it: there is no wait that clears a spent allowance."""
        self._run(audit=self._audit_limited_from(
            "https://alpha.example", category=QUOTA))

        self.assertIsNone(self.campaign.retry_at)
        self.assertEqual(self.campaign.retry_seconds, 0)
        self.assertFalse(self.campaign.control_state()["waitable"])

    def test_the_pause_message_comes_from_the_backend_not_the_provider(self):
        self._run(audit=self._audit_limited_from(
            "https://alpha.example", category=QUOTA,
            message="Groq daily quota exhausted for this key."))

        self.assertIn("quota", self.campaign.pause_detail.lower())

    def test_a_rate_limit_is_waited_out_and_the_run_continues(self):
        """RUNNING -> PAUSED_RATE_LIMIT -> RUNNING, on the same lead."""
        state = {"refused": False}

        def audit(**call):
            self.calls.append(("audit", call["website"]))
            if call["website"] == "https://beta.example" and not state["refused"]:
                state["refused"] = True
                raise rate_limit_error(retry_after=0.01)
            return ai.SiteAudit("A cafe.", make_findings(4))

        self._run(audit=audit)

        # It came back to Beta rather than skipping it, and finished the queue.
        self.assertEqual(
            [url for kind, url in self.calls if kind == "audit"],
            ["https://alpha.example", "https://beta.example",
             "https://beta.example", "https://gamma.example"])
        self.assertEqual(self.campaign.phase, Campaign.Phase.REVIEW)
        self.assertEqual(self.campaign.drafts.filter(
            processed_at__isnull=False).count(), 3)

    def test_the_pause_is_recorded_even_when_it_is_waited_out(self):
        """The page must be able to say why nothing is moving."""
        seen = []

        def audit(**call):
            if call["website"] == "https://alpha.example" and not seen:
                seen.append(1)
                raise rate_limit_error(retry_after=0.01)
            # By now the pause has been written and cleared again; the counter is
            # what survives to prove it happened.
            return ai.SiteAudit("A cafe.", make_findings(4))

        self._run(audit=audit)

        self.assertEqual(self.campaign.pause_count, 1)

    def test_a_long_window_is_recorded_rather_than_slept_through(self):
        """A thread asleep for ten minutes survives no restart."""
        # BACKOFF_CAP is raised back up for this one: setUp squashes it so the
        # wait path runs fast, and a 60-second window is the point here.
        with mock.patch.object(runner, "MAX_INLINE_WAIT", 0.001),              mock.patch.object(runner, "BACKOFF_CAP", 900.0):
            self._run(audit=self._audit_limited_from(
                "https://beta.example", retry_after=60))

        self.assertEqual(self.campaign.phase, Campaign.Phase.PAUSED_RATE_LIMIT)
        self.assertEqual(self.campaign.pause_reason, Campaign.Pause.RATE_LIMIT)
        self.assertGreater(self.campaign.retry_seconds, 0)
        self.assertNotIn(("analyse", "https://gamma.example"), self.calls)

    def test_a_run_stops_parking_after_a_few_refusals(self):
        """Park, wait, retry, refuse, forever is the same mistake as retrying.

        A provider that refuses every attempt would otherwise keep the run
        re-crawling the same website on an escalating backoff with no end. After
        MAX_PAUSES the run stays parked and waits for a person.
        """
        def audit(**call):
            self.calls.append(("audit", call["website"]))
            raise rate_limit_error(retry_after=0.001)

        with mock.patch.object(runner, "MAX_PAUSES", 3):
            self._run(audit=audit)

        self.assertEqual(self.campaign.phase, Campaign.Phase.PAUSED_RATE_LIMIT)
        self.assertEqual(self.campaign.pause_count, 3)
        # Three attempts at the first lead, and the queue never moved past it.
        self.assertEqual(len(self.calls), 6)          # crawl + audit, three times
        self.assertEqual(
            {url for _kind, url in self.calls}, {"https://alpha.example"})
        self.assertIn("try a different credential",
                      self.campaign.pause_detail.lower())

    def test_a_capped_run_can_still_be_resumed_by_hand(self):
        def audit(**call):
            raise rate_limit_error(retry_after=0.001)

        with mock.patch.object(runner, "MAX_PAUSES", 2):
            self._run(audit=audit)

        with mock.patch.object(runner, "start_pipeline", return_value=True) as start:
            response = self.client.post(
                reverse("outreach:resume", args=[self.campaign.id]),
                data={"force": True}, content_type="application/json")

        self.assertEqual(response.status_code, 200)
        start.assert_called_once()

    def test_a_rate_limit_during_generation_pauses_too(self):
        """Both AI stages, not just the review."""
        def generate(**call):
            self.calls.append(("generate", call["website"]))
            raise rate_limit_error(category=QUOTA)

        self._run(generate=generate)

        self.assertEqual(self.campaign.phase, Campaign.Phase.PAUSED_RATE_LIMIT)
        self.assertEqual(
            [url for kind, url in self.calls if kind == "generate"],
            ["https://alpha.example"])

    def test_an_ordinary_ai_failure_does_not_pause_the_run(self):
        """One bad website must still cost only itself."""
        def audit(**call):
            self.calls.append(("audit", call["website"]))
            if call["website"] == "https://beta.example":
                raise AiError("The model returned malformed JSON.")
            return ai.SiteAudit("A cafe.", make_findings(4))

        self._run(audit=audit)

        self.assertEqual(self.campaign.phase, Campaign.Phase.REVIEW)
        self.assertEqual(self.campaign.drafts.filter(
            processed_at__isnull=False).count(), 3)


# --------------------------------------------------------------------------- #
# Resuming a paused run
# --------------------------------------------------------------------------- #

class ResumeAfterPauseTests(SignedIn):
    def setUp(self):
        self.campaign = make_campaign(
            phase=Campaign.Phase.PAUSED_RATE_LIMIT,
            pause_reason=Campaign.Pause.RATE_LIMIT,
            pause_detail="Groq rate limit reached.",
            retry_at=timezone.now() + timedelta(seconds=45))
        self.done = make_draft(self.campaign, business_name="Alpha",
                               email="a@example.test", sequence=1,
                               processed_at=timezone.now())
        self.todo = make_draft(self.campaign, business_name="Beta",
                               email="b@example.test", sequence=2,
                               subject="", body="",
                               status=EmailDraft.Status.PENDING)

    def _resume(self, **payload):
        return self.client.post(
            reverse("outreach:resume", args=[self.campaign.id]),
            data=payload, content_type="application/json")

    def test_resuming_inside_the_window_is_refused(self):
        response = self._resume()

        self.assertEqual(response.status_code, 409)
        self.assertIn("wait", response.json()["error"].lower())
        self.assertGreater(response.json()["retry_seconds"], 0)

    def test_the_user_can_override_the_window(self):
        """They may have just switched provider; the wait was never for them."""
        with mock.patch.object(runner, "start_pipeline",
                               return_value=True) as start:
            response = self._resume(force=True)

        self.assertEqual(response.status_code, 200)
        start.assert_called_once()
        self.assertTrue(start.call_args.kwargs["resume"])

    def test_resuming_after_the_window_needs_no_override(self):
        Campaign.objects.filter(pk=self.campaign.pk).update(
            retry_at=timezone.now() - timedelta(seconds=1))

        with mock.patch.object(runner, "start_pipeline",
                               return_value=True) as start:
            response = self._resume()

        self.assertEqual(response.status_code, 200)
        start.assert_called_once()

    def test_the_resume_reports_only_the_unfinished_leads(self):
        Campaign.objects.filter(pk=self.campaign.pk).update(retry_at=None)

        with mock.patch.object(runner, "start_pipeline", return_value=True):
            response = self._resume()

        self.assertEqual(response.json()["remaining"], 1)

    def test_a_finished_lead_is_not_processed_again(self):
        """The point of keeping the position at all."""
        queue = runner._queue_for(self.campaign, resume=True)

        self.assertEqual([d.pk for d in queue], [self.todo.pk])

    def test_the_state_endpoint_explains_the_pause(self):
        response = self.client.get(
            reverse("outreach:state", args=[self.campaign.id]))
        control = response.json()["campaign"]["control"]

        self.assertEqual(control["state"], "paused")
        self.assertTrue(control["waitable"])
        self.assertGreater(control["retry_seconds"], 0)
        self.assertIn("rate limit", control["pause_detail"].lower())

    def test_a_quota_pause_is_not_offered_a_countdown(self):
        Campaign.objects.filter(pk=self.campaign.pk).update(
            pause_reason=Campaign.Pause.QUOTA, retry_at=None)

        response = self.client.get(
            reverse("outreach:state", args=[self.campaign.id]))
        control = response.json()["campaign"]["control"]

        self.assertFalse(control["waitable"])
        self.assertEqual(control["retry_seconds"], 0)


# --------------------------------------------------------------------------- #
# Cancelling
# --------------------------------------------------------------------------- #

class CancelEndpointTests(SignedIn):
    def setUp(self):
        self.campaign = make_campaign(phase=Campaign.Phase.CRAWLING)
        self.done = make_draft(self.campaign, business_name="Alpha",
                               email="a@example.test", sequence=1,
                               processed_at=timezone.now())
        self.todo = make_draft(self.campaign, business_name="Beta",
                               email="b@example.test", sequence=2,
                               subject="", body="",
                               status=EmailDraft.Status.PENDING)

    def _cancel(self):
        return self.client.post(reverse("outreach:cancel", args=[self.campaign.id]))

    def test_cancelling_with_a_worker_running_records_the_request(self):
        """The worker settles it -- it is the only thing that knows where it is."""
        with mock.patch.object(runner, "is_running", return_value=True):
            response = self._cancel()

        self.campaign.refresh_from_db()
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.json()["cancelled"])
        self.assertEqual(self.campaign.phase, Campaign.Phase.CANCEL_REQUESTED)

    def test_cancelling_with_no_worker_settles_it_immediately(self):
        response = self._cancel()

        self.campaign.refresh_from_db()
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["cancelled"])
        self.assertEqual(self.campaign.phase, Campaign.Phase.CANCELLED)
        self.assertIsNotNone(self.campaign.cancelled_at)

    def test_the_message_says_how_much_was_left(self):
        self.assertIn("1 lead(s) were not processed", self._cancel().json()["message"])

    def test_cancelling_twice_changes_nothing(self):
        first = self._cancel()
        self.campaign.refresh_from_db()
        stamp = self.campaign.cancelled_at

        second = self._cancel()
        self.campaign.refresh_from_db()

        self.assertEqual(first.status_code, 200)
        self.assertEqual(second.status_code, 200)
        self.assertTrue(second.json()["already"])
        self.assertEqual(self.campaign.phase, Campaign.Phase.CANCELLED)
        self.assertEqual(self.campaign.cancelled_at, stamp)

    def test_a_second_press_while_cancelling_is_not_an_error(self):
        with mock.patch.object(runner, "is_running", return_value=True):
            self._cancel()
            second = self._cancel()

        self.campaign.refresh_from_db()
        self.assertEqual(second.status_code, 200)
        self.assertTrue(second.json()["already"])
        self.assertEqual(self.campaign.phase, Campaign.Phase.CANCEL_REQUESTED)

    def test_a_cancel_request_whose_worker_vanished_is_settled(self):
        """Otherwise "Cancelling…" would be the final state, forever."""
        Campaign.objects.filter(pk=self.campaign.pk).update(
            phase=Campaign.Phase.CANCEL_REQUESTED)

        response = self._cancel()

        self.campaign.refresh_from_db()
        self.assertTrue(response.json()["cancelled"])
        self.assertEqual(self.campaign.phase, Campaign.Phase.CANCELLED)

    def test_a_paused_run_can_be_cancelled(self):
        Campaign.objects.filter(pk=self.campaign.pk).update(
            phase=Campaign.Phase.PAUSED_RATE_LIMIT,
            pause_reason=Campaign.Pause.RATE_LIMIT,
            retry_at=timezone.now() + timedelta(seconds=60))

        self._cancel()
        self.campaign.refresh_from_db()

        self.assertEqual(self.campaign.phase, Campaign.Phase.CANCELLED)
        # The countdown goes with it: a cancelled run has no retry.
        self.assertIsNone(self.campaign.retry_at)
        self.assertEqual(self.campaign.pause_reason, "")

    def test_cancelling_never_touches_a_completed_lead(self):
        self._cancel()

        self.assertIsNotNone(EmailDraft.objects.get(pk=self.done.pk).processed_at)
        self.assertIsNone(EmailDraft.objects.get(pk=self.todo.pk).processed_at)

    def test_a_send_in_progress_is_not_cancellable_here(self):
        Campaign.objects.filter(pk=self.campaign.pk).update(
            phase=Campaign.Phase.SENDING)

        response = self._cancel()

        self.campaign.refresh_from_db()
        self.assertEqual(response.status_code, 409)
        self.assertIn("send", response.json()["error"].lower())
        self.assertEqual(self.campaign.phase, Campaign.Phase.SENDING)

    def test_a_campaign_with_nothing_running_is_not_cancellable(self):
        Campaign.objects.filter(pk=self.campaign.pk).update(
            phase=Campaign.Phase.REVIEW)

        response = self._cancel()

        self.assertEqual(response.status_code, 409)

    def test_the_endpoint_refuses_get(self):
        response = self.client.get(
            reverse("outreach:cancel", args=[self.campaign.id]))

        self.assertEqual(response.status_code, 405)

    def test_another_account_cannot_cancel_this_run(self):
        other = OtherUser()

        response = other.client.post(
            reverse("outreach:cancel", args=[self.campaign.id]))

        self.campaign.refresh_from_db()
        self.assertEqual(response.status_code, 404)
        self.assertEqual(self.campaign.phase, Campaign.Phase.CRAWLING)

    def test_a_signed_out_visitor_cannot_cancel(self):
        response = Client().post(
            reverse("outreach:cancel", args=[self.campaign.id]))

        self.assertEqual(response.status_code, 302)
        self.assertIn(reverse("login"), response["Location"])


class CancelDuringRunTests(SignedIn):
    """Cancelling a job that is actually working."""

    def setUp(self):
        self.campaign = make_campaign(phase=Campaign.Phase.CRAWLING)
        self.drafts = {}
        for index, name in enumerate(["Alpha", "Beta", "Gamma"], 1):
            self.drafts[name] = make_draft(
                self.campaign, business_name=name,
                email=f"{name.lower()}@example.test",
                website=f"https://{name.lower()}.example",
                subject="", body="", sequence=index,
                status=EmailDraft.Status.PENDING)
        self.calls = []

    def _press_cancel(self):
        """What the HTTP endpoint does while a worker is running."""
        Campaign.objects.filter(pk=self.campaign.pk).update(
            phase=Campaign.Phase.CANCEL_REQUESTED)

    def _analysis(self, url):
        return analyzer.SiteAnalysis(
            analyzer.OK, "Read 1 page(s).",
            [analyzer.Page(url, "home", "T", "", ["H"], "prose",
                           {"cta_count": 0})],
            discovered=3)

    def _run(self, analyse=None, audit=None, generate=None):
        def default_analyse(url, **kwargs):
            self.calls.append(("analyse", url))
            return self._analysis(url)

        def default_audit(**kwargs):
            self.calls.append(("audit", kwargs["website"]))
            return ai.SiteAudit("A cafe.", make_findings(4))

        def default_generate(**kwargs):
            self.calls.append(("generate", kwargs["website"]))
            return ai.GeneratedEmail("Subject", "Body.", "no obvious CTA",
                                     ["Issue 0"])

        with mock.patch.object(analyzer, "analyse",
                               side_effect=analyse or default_analyse), \
             mock.patch.object(ai, "audit", side_effect=audit or default_audit), \
             mock.patch.object(ai, "generate",
                               side_effect=generate or default_generate):
            runner._pipeline(self.campaign)
        self.campaign.refresh_from_db()

    def test_a_cancel_between_leads_stops_the_run(self):
        def generate(**call):
            self.calls.append(("generate", call["website"]))
            if call["website"] == "https://alpha.example":
                self._press_cancel()
            return ai.GeneratedEmail("Subject", "Body.", "no obvious CTA",
                                     ["Issue 0"])

        self._run(generate=generate)

        self.assertEqual(self.campaign.phase, Campaign.Phase.CANCELLED)
        self.assertEqual([url for kind, url in self.calls if kind == "analyse"],
                         ["https://alpha.example"])

    def test_the_lead_in_flight_when_cancel_arrives_is_completed_not_abandoned(self):
        """Cancel is checked *before* each lead, so the one being written finishes.

        Abandoning a lead whose crawl and review have already been paid for, to
        save one AI call, would be the more wasteful choice.
        """
        def generate(**call):
            self.calls.append(("generate", call["website"]))
            if call["website"] == "https://alpha.example":
                self._press_cancel()
            return ai.GeneratedEmail("Subject", "Body.", "no obvious CTA",
                                     ["Issue 0"])

        self._run(generate=generate)

        self.assertIsNotNone(
            EmailDraft.objects.get(pk=self.drafts["Alpha"].pk).processed_at)

    def test_a_cancel_before_the_review_stops_the_ai_call(self):
        """An AI call that has not started need never start."""
        def analyse(url, **kwargs):
            self.calls.append(("analyse", url))
            self._press_cancel()
            return self._analysis(url)

        self._run(analyse=analyse)

        self.assertEqual(self.campaign.phase, Campaign.Phase.CANCELLED)
        self.assertEqual([kind for kind, _url in self.calls], ["analyse"])

    def test_a_lead_cancelled_mid_way_keeps_no_completion_stamp(self):
        def analyse(url, **kwargs):
            self.calls.append(("analyse", url))
            self._press_cancel()
            return self._analysis(url)

        self._run(analyse=analyse)

        for name in ("Alpha", "Beta", "Gamma"):
            with self.subTest(name=name):
                self.assertIsNone(
                    EmailDraft.objects.get(pk=self.drafts[name].pk).processed_at)

    def test_cancelling_is_idempotent_against_the_worker(self):
        """Two presses, one settled state, and no restart."""
        def generate(**call):
            self.calls.append(("generate", call["website"]))
            self._press_cancel()
            self._press_cancel()
            return ai.GeneratedEmail("Subject", "Body.", "no obvious CTA",
                                     ["Issue 0"])

        self._run(generate=generate)

        self.assertEqual(self.campaign.phase, Campaign.Phase.CANCELLED)
        self.assertEqual(Campaign.objects.filter(
            phase=Campaign.Phase.CANCELLED).count(), 1)

    def test_a_cancelled_run_can_be_resumed_by_the_user(self):
        """Explicitly. Nothing resumes it on its own -- that is the point."""
        def generate(**call):
            self.calls.append(("generate", call["website"]))
            self._press_cancel()
            return ai.GeneratedEmail("S", "B", "no obvious CTA", ["Issue 0"])

        self._run(generate=generate)

        with mock.patch.object(runner, "start_pipeline",
                               return_value=True) as start:
            response = self.client.post(
                reverse("outreach:resume", args=[self.campaign.id]))

        self.assertEqual(response.status_code, 200)
        start.assert_called_once()
        self.assertTrue(start.call_args.kwargs["resume"])

    def test_the_progress_panel_reports_the_cancellation(self):
        def generate(**call):
            self._press_cancel()
            return ai.GeneratedEmail("Subject", "Body.", "no obvious CTA",
                                     ["Issue 0"])

        self._run(generate=generate)
        progress = self.campaign.progress()

        self.assertEqual(progress["control"]["state"], "cancelled")
        self.assertEqual(progress["unfinished"], 2)
        # Not "failed": nothing went wrong with them, and a resume takes them on.
        self.assertEqual(
            [lead["state"] for lead in progress["leads"]],
            ["completed", "stopped", "stopped"])
        # No step is left spinning on a run that has stopped.
        self.assertNotIn("current",
                         [step["state"] for step in progress["steps"]])


class CancelBeatsRetryTests(SignedIn):
    """A cancelled job stays cancelled, even one asleep on a retry window."""

    def setUp(self):
        self.campaign = make_campaign(phase=Campaign.Phase.CRAWLING)
        for index, name in enumerate(["Alpha", "Beta"], 1):
            make_draft(self.campaign, business_name=name,
                       email=f"{name.lower()}@example.test",
                       website=f"https://{name.lower()}.example",
                       subject="", body="", sequence=index,
                       status=EmailDraft.Status.PENDING)
        self.calls = []

    def test_a_cancel_during_a_rate_limit_wait_wins(self):
        def analyse(url, **kwargs):
            return analyzer.SiteAnalysis(
                analyzer.OK, "Read 1 page(s).",
                [analyzer.Page(url, "home", "T", "", ["H"], "prose",
                               {"cta_count": 0})], discovered=3)

        def audit(**call):
            self.calls.append(("audit", call["website"]))
            # Refuse the first lead, then press Cancel while the run waits.
            Campaign.objects.filter(pk=self.campaign.pk).update(
                phase=Campaign.Phase.CANCEL_REQUESTED)
            raise rate_limit_error(retry_after=0.05)

        with mock.patch.object(runner, "WAIT_TICK", 0.005), \
             mock.patch.object(runner, "MAX_INLINE_WAIT", 10), \
             mock.patch.object(analyzer, "analyse", side_effect=analyse), \
             mock.patch.object(ai, "audit", side_effect=audit), \
             mock.patch.object(ai, "generate") as generate:
            runner._pipeline(self.campaign)

        self.campaign.refresh_from_db()
        self.assertEqual(self.campaign.phase, Campaign.Phase.CANCELLED)
        # It did not come back to the lead it was waiting on.
        self.assertEqual(len(self.calls), 1)
        generate.assert_not_called()

    def test_a_cancelled_run_is_not_auto_resumed(self):
        """`stalled()` must not offer to pick a cancelled run back up."""
        Campaign.objects.filter(pk=self.campaign.pk).update(
            phase=Campaign.Phase.CANCELLED, cancelled_at=timezone.now())
        self.campaign.refresh_from_db()

        self.assertEqual(runner.stalled(self.campaign), "")
        self.assertFalse(self.campaign.control_state()["retry_ready"])


class CancelDuringCrawlTests(TestCase):
    """The crawler stops between fetches, and a partial read is discarded."""

    def test_the_crawl_stops_before_the_next_fetch(self):
        fetched = []

        def fake_fetch(url):
            fetched.append(url)
            return analyzer.Fetched(
                html=("<html><head><title>T</title></head><body>"
                      "<a href='/a'>A</a><a href='/b'>B</a><p>text</p>"
                      "</body></html>"),
                load_ms=120, size=900, final_url=url)

        with mock.patch.object(analyzer, "_fetch", side_effect=fake_fetch), \
             mock.patch.object(analyzer, "_robots_for", return_value=None), \
             mock.patch.object(analyzer, "discover_sitemap", return_value=[]):
            result = analyzer.analyse("https://bella.example",
                                      should_stop=lambda: len(fetched) >= 1)

        self.assertTrue(result.stopped)
        self.assertEqual(len(fetched), 1)

    def test_a_cancelled_crawl_saves_nothing(self):
        """A half-read site stored as the whole site would be analysed as one."""
        campaign = make_campaign()
        draft = make_draft(campaign, analysis_status="", analysis_context="",
                           status=EmailDraft.Status.PENDING)

        stopped = analyzer.SiteAnalysis(
            analyzer.OK, "Cancelled after 1 page(s).",
            [analyzer.Page("https://bella.example", "home", "T", "", [], "x", {})],
            stopped=True)

        with mock.patch.object(analyzer, "analyse", return_value=stopped):
            saved = runner.crawl_draft(draft, should_stop=lambda: True)

        draft.refresh_from_db()
        self.assertFalse(saved)
        self.assertEqual(draft.status, EmailDraft.Status.PENDING)
        self.assertEqual(draft.analysis_context, "")
        self.assertEqual(draft.pages_read, [])

    def test_a_completed_crawl_is_saved_as_before(self):
        campaign = make_campaign()
        draft = make_draft(campaign, analysis_status="", analysis_context="",
                           status=EmailDraft.Status.PENDING)

        done = analyzer.SiteAnalysis(
            analyzer.OK, "Read 1 page(s).",
            [analyzer.Page("https://bella.example", "home", "T", "", [], "x",
                           {"cta_count": 2})],
            discovered=4)

        with mock.patch.object(analyzer, "analyse", return_value=done):
            saved = runner.crawl_draft(draft)

        draft.refresh_from_db()
        self.assertTrue(saved)
        self.assertEqual(draft.status, EmailDraft.Status.CRAWLED)
        # The measurements travel with the page, for the scoring and email steps.
        self.assertEqual(draft.pages_read[0]["facts"], {"cta_count": 2})
        self.assertEqual(draft.measured_signals["cta_count"], 2)

class WorkspaceControlsTests(SignedIn):
    """The controls exist on the page, and the script is given their routes.

    Cheap, and it catches the failure that is otherwise invisible until somebody
    tries to cancel a real run: a renamed id or a missing data attribute leaves
    the button inert with no error anywhere.
    """

    def setUp(self):
        self.campaign = make_campaign(phase=Campaign.Phase.CRAWLING)
        make_draft(self.campaign, sequence=1, subject="", body="",
                   status=EmailDraft.Status.PENDING)

    def _page(self):
        return self.client.get(
            reverse("outreach:workspace", args=[self.campaign.id]))

    def test_the_cancel_button_is_on_the_page(self):
        response = self._page()

        self.assertContains(response, 'id="run-cancel"')
        self.assertContains(response, "Cancel")

    def test_there_is_exactly_one_cancel_button_for_the_job(self):
        """"One clearly visible Cancel button", per the brief -- not one per lead."""
        self.assertContains(self._page(), 'id="run-cancel"', count=1)

    def test_the_stopped_run_banner_is_on_the_page(self):
        response = self._page()

        for element in ('id="run-control"', 'id="run-control-title"',
                        'id="run-control-text"', 'id="run-control-resume"',
                        'id="run-control-settings"'):
            with self.subTest(element=element):
                self.assertContains(response, element)

    def test_the_script_is_given_both_routes(self):
        response = self._page()

        self.assertContains(response, "data-cancel-url")
        self.assertContains(response, "data-resume-url")
        self.assertContains(
            response, reverse("outreach:cancel", args=[self.campaign.id]))

    def test_the_banner_announces_itself_to_a_screen_reader(self):
        """A run that stops while nobody is looking at that corner of the page."""
        response = self._page()

        self.assertContains(response, 'role="status"')
        self.assertContains(response, 'aria-live="polite"')
