"""
Gemini backend, via Google's `google-genai` SDK.

Same contract as the Claude backend: take a system prompt, a user prompt and a
JSON schema, return the model's raw JSON text, raise AiError with something
readable on failure.

Shapes here were checked against the installed SDK (google-genai 2.18.x) rather
than recalled: the call is `client.interactions.create(...)` and the structured
output goes in `response_format={"text": {"mime_type": ..., "schema": ...}}`.
Note the published docs write that field as `schema` while the SDK model calls it
`jsonSchema` -- `schema` is its alias, so a plain dict works either way.
"""

from __future__ import annotations

from google import genai
from google.genai import errors as genai_errors

from .ai_base import (
    RATE_LIMIT,
    AiError,
    classify_rate_limit,
    retry_after_of,
)

NAME = "gemini"
LABEL = "Gemini (Google)"

#: Flash is the sensible default for this job: writing one short email from
#: supplied material is not a reasoning-heavy task, and cost scales with list
#: size. Set OUTREACH_AI_MODEL to a pro model for a small, high-value list.
DEFAULT_MODEL = "gemini-3.7-flash"

#: The SDK itself reads these, in this order.
KEY_VARS = ("GEMINI_API_KEY", "GOOGLE_API_KEY")

_client: "genai.Client | None" = None
_client_fingerprint = ""


def describe_credentials() -> tuple[bool, str, str]:
    """(usable, source, advice), from the central resolver."""
    from . import credentials

    resolved = credentials.resolve(NAME)
    if resolved.usable:
        return True, resolved.detail, ""
    return False, resolved.detail, resolved.advice


def reset_client() -> None:
    """Drop the cached client, so a newly saved key takes effect at once."""
    global _client, _client_fingerprint
    _client = None
    _client_fingerprint = ""


def client() -> "genai.Client":
    """One shared client, rebuilt when the resolved credential changes.

    The key is passed explicitly rather than left to the SDK's own environment
    lookup: a key saved in Settings is not in the environment, and the SDK cannot
    find what is not there.
    """
    global _client, _client_fingerprint
    from . import credentials

    resolved = credentials.require(NAME)
    if _client is None or _client_fingerprint != resolved.fingerprint:
        try:
            _client = genai.Client(api_key=resolved.key)
        except Exception as exc:  # noqa: BLE001 - surface as a readable message
            raise AiError(f"Could not build the Gemini client: {exc}") from exc
        _client_fingerprint = resolved.fingerprint
    return _client


def verify(model: str = "") -> tuple[str, str]:
    """Test Connection: (category, message). Never raises for a bad key.

    Lists models rather than generating: it is the cheapest call the API offers
    and it still requires a valid key.
    """
    try:
        handle = client()
    except AiError as exc:
        return "error", str(exc)

    try:
        next(iter(handle.models.list()), None)
    except genai_errors.ClientError as exc:
        status = getattr(exc, "status", None) or ""
        message = str(getattr(exc, "message", exc)).upper()
        if status == "UNAUTHENTICATED" or "API_KEY" in message:
            return "invalid", f"{LABEL} rejected the API key."
        if status == "RESOURCE_EXHAUSTED" or "QUOTA" in message:
            return "rate_limited", (f"{LABEL} accepted the key but its quota is "
                                    "exhausted right now.")
        return "error", f"{LABEL} rejected the request."
    except genai_errors.ServerError:
        return "unavailable", f"{LABEL} is unavailable right now."
    except Exception:  # noqa: BLE001 - never leak an unexpected provider string
        return "unavailable", f"Could not reach {LABEL}."
    return "ok", f"Connected to {LABEL} successfully."


def complete(*, system: str, prompt: str, schema: dict, model: str,
             max_tokens: int = 0) -> str:
    """Return the model's JSON text, or raise AiError.

    `max_tokens` is accepted for interface parity but not applied: it would live
    in `generation_config`, and rather than guess that field's name on the
    interactions API it is left unset. Gemini's output ceiling is generous and is
    not the binding constraint here -- unlike Groq, where the reservation counts
    against a per-minute allowance.
    """
    try:
        interaction = client().interactions.create(
            model=model,
            input=prompt,
            system_instruction=system,
            response_format={
                "text": {"mime_type": "application/json", "schema": schema},
            },
        )
    except genai_errors.ClientError as exc:
        status = getattr(exc, "status", None) or ""
        message = getattr(exc, "message", str(exc))
        if "API_KEY" in str(message).upper() or status == "UNAUTHENTICATED":
            raise AiError(
                "Gemini rejected the API key. Check GEMINI_API_KEY in .env -- "
                "keys are created at https://aistudio.google.com/apikey."
            ) from exc
        if status == "RESOURCE_EXHAUSTED" or "quota" in str(message).lower():
            # Gemini reports both the per-minute cap and an exhausted free-tier
            # day as RESOURCE_EXHAUSTED; only the message separates them.
            category = classify_rate_limit(str(message))
            raise AiError(
                "Gemini rate limit reached. Free-tier keys have a low "
                "per-minute cap -- wait a moment and retry, or reduce the list."
                if category == RATE_LIMIT else
                "Gemini quota exhausted for this key -- this is the daily or "
                "per-project allowance, not a short pause. Wait for the reset, "
                "or switch provider or credential in Settings.",
                retryable=True, category=category,
                retry_after=retry_after_of(exc),
            ) from exc
        raise AiError(f"Gemini rejected the request: {message}") from exc
    except genai_errors.ServerError as exc:
        raise AiError(
            f"Gemini had a server error ({getattr(exc, 'message', exc)}) -- retry.",
            retryable=True,
        ) from exc
    except genai_errors.APIError as exc:
        raise AiError(f"Gemini API error: {getattr(exc, 'message', exc)}") from exc
    except Exception as exc:  # noqa: BLE001 - network stack, DNS, TLS
        raise AiError(f"Could not reach the Gemini API: {exc}",
                      retryable=True) from exc

    # Safety filtering and truncation both show up as a completed call with no
    # usable text, so check before handing anything to the parser.
    text = (getattr(interaction, "output_text", None) or "").strip()
    if not text:
        reported = getattr(interaction, "errors", None)
        status = getattr(interaction, "status", None)
        detail = f" (status {status})" if status else ""
        if reported:
            detail += f" {reported}"
        raise AiError(
            "Gemini returned no text for this lead -- most often a safety filter "
            f"or a blocked prompt.{detail} Review the lead and the service "
            "description, then retry."
        )
    return text
