"""
Groq backend, via the official `groq` SDK.

Same contract as the other backends: take a system prompt, a user prompt and a
JSON schema, return the model's raw JSON text, raise AiError with something
readable on failure.

Shapes checked against the installed SDK (groq 1.6.x) and Groq's docs rather
than recalled: the call is `client.chat.completions.create(...)`, structured
output goes in
`response_format={"type": "json_schema", "json_schema": {"name", "strict", "schema"}}`,
and the text is at `choices[0].message.content`.

Model note: `strict: true` schema enforcement is only supported on the GPT-OSS
models, which is why the default is `openai/gpt-oss-120b` rather than a Llama
model. Point OUTREACH_AI_MODEL at something else and the backend drops to
Groq's looser `json_object` mode automatically -- the prompt already demands
JSON, and ai.parse() validates whatever comes back.
"""

from __future__ import annotations

import os

import groq

from .ai_base import (
    RATE_LIMIT,
    AiError,
    classify_rate_limit,
    retry_after_of,
)

NAME = "groq"
LABEL = "Groq"

#: Production model with strict structured-output support. 131k context,
#: ~500 tok/s, $0.15/$0.60 per 1M tokens at the time of writing.
DEFAULT_MODEL = "openai/gpt-oss-120b"

#: Models that accept `strict: true`. Anything else falls back to json_object.
STRICT_SCHEMA_MODELS = ("openai/gpt-oss-120b", "openai/gpt-oss-20b")

KEY_VARS = ("GROQ_API_KEY",)

MAX_TOKENS = 4000

_client: "groq.Groq | None" = None
_client_fingerprint = ""


def describe_credentials() -> tuple[bool, str, str]:
    """(usable, source, advice), from the central resolver."""
    from . import credentials

    resolved = credentials.resolve(NAME)
    if resolved.usable:
        return True, resolved.detail, ""
    return False, resolved.detail, resolved.advice


def reset_client() -> None:
    """Drop the cached client, so a newly saved key takes effect at once."""
    global _client, _client_fingerprint
    _client = None
    _client_fingerprint = ""


def client() -> "groq.Groq":
    """One shared client, rebuilt when the resolved credential changes.

    The key is passed explicitly rather than left to the SDK's own environment
    lookup: a key saved in Settings is not in the environment.
    """
    global _client, _client_fingerprint
    from . import credentials

    resolved = credentials.require(NAME)
    if _client is None or _client_fingerprint != resolved.fingerprint:
        try:
            _client = groq.Groq(api_key=resolved.key, max_retries=3)
        except Exception as exc:  # noqa: BLE001 - surface as a readable message
            raise AiError(f"Could not build the Groq client: {exc}") from exc
        _client_fingerprint = resolved.fingerprint
    return _client


def verify(model: str = "") -> tuple[str, str]:
    """Test Connection: (category, message). Never raises for a bad key."""
    try:
        handle = client()
    except AiError as exc:
        return "error", str(exc)

    try:
        handle.chat.completions.create(
            model=model or DEFAULT_MODEL, max_tokens=1,
            messages=[{"role": "user", "content": "ping"}],
        )
    except groq.AuthenticationError:
        return "invalid", f"{LABEL} rejected the API key."
    except groq.PermissionDeniedError:
        return "invalid", (f"{LABEL} accepted the key but refused access to "
                           f"{model or DEFAULT_MODEL!r}.")
    except groq.NotFoundError:
        return "invalid", (f"{LABEL} does not recognise the model "
                           f"{model or DEFAULT_MODEL!r}. The key may still be fine.")
    except groq.RateLimitError:
        return "rate_limited", (f"{LABEL} accepted the key but is rate limited "
                                "right now.")
    except groq.APIConnectionError:
        return "unavailable", f"Could not reach {LABEL}."
    except groq.APIStatusError as exc:
        if exc.status_code >= 500:
            return "unavailable", f"{LABEL} is unavailable ({exc.status_code})."
        return "error", f"{LABEL} returned status {exc.status_code}."
    except Exception:  # noqa: BLE001 - never leak an unexpected provider string
        return "error", f"{LABEL} could not be reached."
    return "ok", f"Connected to {LABEL} successfully."


def _response_format(schema: dict, model: str) -> dict:
    """Strict schema where the model supports it, JSON mode otherwise."""
    if model in STRICT_SCHEMA_MODELS:
        return {
            "type": "json_schema",
            "json_schema": {
                "name": "outreach_email",
                "strict": True,
                "schema": schema,
            },
        }
    return {"type": "json_object"}


def complete(*, system: str, prompt: str, schema: dict, model: str,
             max_tokens: int = MAX_TOKENS) -> str:
    """Return the model's JSON text, or raise AiError.

    `max_tokens` counts against Groq's tokens-per-minute allowance, not just the
    response size, so an over-generous reservation can fail a request that would
    otherwise fit. Callers pass what the task actually needs.
    """
    messages = [
        {"role": "system", "content": system},
        {"role": "user", "content": prompt},
    ]

    try:
        try:
            response = client().chat.completions.create(
                model=model, max_tokens=max_tokens, messages=messages,
                response_format=_response_format(schema, model),
            )
        except groq.BadRequestError as exc:
            # Strict mode rejects the whole reply if one required field is
            # missing, even when the rest is correct and complete. Retry once in
            # looser JSON mode rather than throw away usable output -- ai.parse
            # and ai.parse_audit validate it either way.
            if "json_validate_failed" not in str(exc):
                raise
            response = client().chat.completions.create(
                model=model, max_tokens=max_tokens, messages=messages,
                response_format={"type": "json_object"},
            )
    except groq.AuthenticationError as exc:
        raise AiError(
            "Groq rejected the API key. Check GROQ_API_KEY in .env -- keys are "
            "created at https://console.groq.com/keys."
        ) from exc
    except groq.RateLimitError as exc:
        # Groq caps per minute *and* per day, and both arrive as one 429. The
        # message says which, and the two need opposite handling: a per-minute
        # cap is waited out, a spent daily allowance is not.
        category = classify_rate_limit(str(exc))
        raise AiError(
            "Groq rate limit reached. The free tier caps requests per minute "
            "and per day -- wait a moment and retry, or reduce the list size."
            if category == RATE_LIMIT else
            "Groq daily quota exhausted for this key -- this is the per-day "
            "allowance, not a short pause. It resets on Groq's own schedule; "
            "wait for it, or switch provider or credential in Settings.",
            retryable=True, category=category,
            retry_after=retry_after_of(exc),
        ) from exc
    except groq.NotFoundError as exc:
        raise AiError(
            f"Groq does not recognise the model {model!r}. Check "
            "OUTREACH_AI_MODEL against https://console.groq.com/docs/models."
        ) from exc
    except groq.BadRequestError as exc:
        # The usual cause is a model that cannot do strict schemas.
        raise AiError(
            f"Groq rejected the request for {model!r}: {exc}. If this mentions "
            "response_format, that model does not support structured output -- "
            f"use one of {', '.join(STRICT_SCHEMA_MODELS)}."
        ) from exc
    except groq.APIStatusError as exc:
        # 413 on Groq is a tokens-per-minute ceiling, not an oversized document,
        # so the fix is to send less context rather than to crawl fewer pages.
        if exc.status_code == 413 or "too large" in str(exc).lower():
            raise AiError(
                "Groq refused the request as too large for its per-minute token "
                "limit. Lower OUTREACH_AI_CONTEXT_CHARS (currently "
                f"{os.environ.get('OUTREACH_AI_CONTEXT_CHARS', '12000')}) to "
                "send shorter page excerpts, or raise the limit on your Groq "
                "plan. The crawl itself is unaffected."
            ) from exc
        raise AiError(
            f"Groq API error ({exc.status_code}): {exc}",
            retryable=exc.status_code >= 500,
        ) from exc
    except groq.APIConnectionError as exc:
        raise AiError(f"Could not reach the Groq API: {exc}",
                      retryable=True) from exc

    choices = getattr(response, "choices", None) or []
    if not choices:
        raise AiError("Groq returned no choices for this lead.")

    choice = choices[0]
    finish = getattr(choice, "finish_reason", None)
    text = (getattr(choice.message, "content", None) or "").strip()

    if finish == "length":
        raise AiError("The reply was cut off by the token limit -- retry.",
                      retryable=True)
    if not text:
        raise AiError(
            "Groq returned no text for this lead"
            + (f" (finish_reason {finish})" if finish else "")
            + ". Review the lead and the service description, then retry.",
            retryable=True,
        )
    return text
