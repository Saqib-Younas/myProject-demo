"""
Assign existing campaigns, history, suppressions and AI credentials to an
account.

    python manage.py claim_data you@example.com
    python manage.py claim_data you@example.com --dry-run

Needed once, when upgrading a database that predates accounts. Rows created
before ownership existed have no owner, and a row with no owner is visible to
nobody -- which is the safe default, but not a useful one for the person whose
data it is.

Only unowned rows are touched. Running it twice is harmless, and it can never
move one account's data to another.
"""

from __future__ import annotations

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from ...models import (
    Campaign,
    FollowUp,
    ProviderCredential,
    SentLead,
    Suppression,
)


class Command(BaseCommand):
    help = ("Assign pre-accounts campaigns, history, suppressions and AI "
            "credentials to a user.")

    def add_arguments(self, parser) -> None:
        parser.add_argument("email", help="Email of the account to assign to.")
        parser.add_argument(
            "--dry-run", action="store_true",
            help="Report what would be claimed without changing anything.",
        )

    def handle(self, *args, **options) -> None:
        User = get_user_model()
        email = options["email"].strip()
        user = User.objects.filter(email__iexact=email).first()
        if user is None:
            raise CommandError(
                f"No account with the email {email!r}. Sign up first, or create "
                "one with `python manage.py createsuperuser`."
            )

        # Only rows with no owner at all. An owned row is somebody's, and this
        # command must never be able to take it.
        unowned = {
            "campaigns": Campaign.objects.filter(owner__isnull=True),
            "sent leads": SentLead.objects.filter(owner__isnull=True),
            "follow-ups": FollowUp.objects.filter(owner__isnull=True),
            "suppressions": Suppression.objects.filter(owner__isnull=True),
            # Keys saved in Settings before credentials belonged to an account.
            # Unclaimed, they resolve for nobody: the resolver ignores rows with
            # no owner rather than handing them to whoever asks.
            "AI credentials": ProviderCredential.objects.filter(
                owner__isnull=True),
        }
        counts = {label: query.count() for label, query in unowned.items()}

        self.stdout.write(f"Account: {user.email or user.username}")
        for label, count in counts.items():
            self.stdout.write(f"  unowned {label:<15} {count}")

        if not any(counts.values()):
            self.stdout.write(self.style.SUCCESS(
                "\nNothing to claim -- every row already has an owner."))
            return

        if options["dry_run"]:
            self.stdout.write(self.style.WARNING(
                "\nDry run: nothing was changed."))
            return

        with transaction.atomic():
            for query in unowned.values():
                query.update(owner=user)

            # Follow-ups whose lead is now owned but which were created before
            # the column existed: take the owner from the lead rather than the
            # argument, so a mixed database cannot cross-assign.
            for followup in FollowUp.objects.filter(
                owner__isnull=True,
            ).select_related("lead"):
                FollowUp.objects.filter(pk=followup.pk).update(
                    owner=followup.lead.owner)

        total = sum(counts.values())
        self.stdout.write(self.style.SUCCESS(
            f"\nClaimed {total} row(s) for {user.email or user.username}."))
        self.stdout.write(
            "The Excel history export is per-account, so download it again from "
            "Settings to get a workbook for this user."
        )
        if counts["AI credentials"]:
            self.stdout.write(
                "Claimed credentials keep whichever one was active. Check "
                f"`python manage.py ai_status --user {user.email or user.username}`."
            )
