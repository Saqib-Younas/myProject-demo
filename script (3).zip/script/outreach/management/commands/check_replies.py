"""
Read the sending account's inbox once and record what came back.

    python manage.py check_replies
    python manage.py check_replies --days 7
    python manage.py check_replies --dry-run

Meant to be run on a schedule (cron, Task Scheduler) or by hand. It never sends
anything: it updates reply states, which is what makes follow-ups *available*.
Deciding to send a follow-up is always a person clicking a button.

Only emails that match something sent from this application are examined. A
message that matches nothing is dropped without being stored.
"""

from __future__ import annotations

import os

from django.core.management.base import BaseCommand, CommandError

from ... import inbox
from ...models import FollowUp, SentLead


class Command(BaseCommand):
    help = "Check the inbox for replies to emails this application sent."

    def _owner(self, email: str):
        """Which account's history to match against.

        A reply can only answer something a particular account sent, so this is
        required rather than defaulted -- guessing would attribute one user's
        reply to another user's lead.
        """
        from django.contrib.auth import get_user_model

        User = get_user_model()
        if email:
            user = User.objects.filter(email__iexact=email.strip()).first()
            if user is None:
                raise CommandError(f"No account with the email {email!r}.")
            return user

        users = list(User.objects.order_by("pk")[:2])
        if not users:
            raise CommandError(
                "No accounts exist yet. Sign up first, or create one with "
                "`python manage.py createsuperuser`."
            )
        if len(users) > 1:
            raise CommandError(
                "More than one account exists. Pass --user <email> to say whose "
                "inbox is being checked."
            )
        return users[0]

    def add_arguments(self, parser) -> None:
        parser.add_argument(
            "--user", default="",
            help="Email of the account whose history to match replies against. "
                 "Required once more than one account exists.",
        )
        parser.add_argument(
            "--days", type=int, default=0,
            help="How far back to look. Defaults to OUTREACH_INBOX_DAYS.",
        )
        parser.add_argument(
            "--password", default="",
            help="Mailbox password. Defaults to OUTREACH_SMTP_PASSWORD.",
        )
        parser.add_argument(
            "--dry-run", action="store_true",
            help="Report what would be checked without connecting.",
        )

    def handle(self, *args, **options) -> None:
        owner = self._owner(options["user"])

        mine = SentLead.objects.filter(owner=owner, status=SentLead.Status.SENT)
        sent = mine.count()
        threaded = mine.exclude(message_id="").count()
        followups = FollowUp.objects.filter(
            owner=owner, status=FollowUp.Status.SENT).count()

        self.stdout.write(f"Account:             {owner.email or owner.username}")

        self.stdout.write(f"Sent leads:          {sent}")
        self.stdout.write(f"  with a Message-ID: {threaded}")
        self.stdout.write(f"Follow-ups sent:     {followups}")

        if sent and not threaded:
            self.stdout.write(self.style.WARNING(
                "\nNone of these sends recorded a Message-ID, so replies can "
                "only be matched by sender address. Emails sent before reply "
                "tracking was added are in that position; new sends record it."
            ))

        if options["dry_run"]:
            self.stdout.write(self.style.SUCCESS(
                "\nDry run: no connection was opened."))
            return

        if not sent:
            self.stdout.write(
                "\nNothing has been sent, so nothing can be a reply.")
            return

        password = options["password"] or os.environ.get(
            "OUTREACH_SMTP_PASSWORD", "")
        if not password:
            raise CommandError(
                "No mailbox password. Set OUTREACH_SMTP_PASSWORD in .env, or "
                "pass --password."
            )

        self.stdout.write("\nReading the inbox...")
        try:
            result = inbox.check(password=password, owner=owner,
                                 days=options["days"])
        except inbox.InboxError as exc:
            raise CommandError(str(exc)) from exc

        self.stdout.write("")
        self.stdout.write(f"Examined:      {result.examined}")
        self.stdout.write(f"Matched:       {result.matched}")
        self.stdout.write(f"  replied:     {result.replied}")
        self.stdout.write(f"  bounced:     {result.bounced}")
        self.stdout.write(f"  unsubscribed:{result.unsubscribed}")
        self.stdout.write(f"Ignored:       {result.ignored} (not ours)")

        for name in result.changed[:25]:
            self.stdout.write(f"  - {name}")

        self.stdout.write(self.style.SUCCESS("\n" + result.summary()))
        if result.unsubscribed:
            self.stdout.write(
                "Addresses that asked to be removed were added to the "
                "do-not-contact list automatically."
            )
