"""
Report which Claude credential the app will use, and optionally prove it works.

    python manage.py ai_status           # inspect only, makes no API call
    python manage.py ai_status --live    # also generate one throwaway email

Use this after `ant auth login` to confirm the browser sign-in is what the app
picked up. No ANTHROPIC_API_KEY is required -- the SDK reads the CLI's stored
profile on its own.

Credentials saved in Settings belong to an account, and a management command has
no signed-in user, so by default this reports the environment only. Pass
`--user you@example.com` to see what that account's campaigns would actually use.
"""

from __future__ import annotations

import os
import shutil
import subprocess

from django.core.management.base import BaseCommand

from outreach import ai, aicontext, credentials


class Command(BaseCommand):
    help = "Show which Claude API credential is active, and optionally test it."

    def add_arguments(self, parser) -> None:
        parser.add_argument(
            "--live", action="store_true",
            help="Make one real API call to generate a throwaway email.",
        )
        parser.add_argument(
            "--user", default="",
            help="Report the credentials saved by this account (email or "
                 "username). Without it, only the environment is read.",
        )

    def handle(self, *args, **options) -> None:
        ok = self.style.SUCCESS
        warn = self.style.WARNING
        bad = self.style.ERROR

        owner = self._owner(options["user"])
        if owner is None:
            # No account in context means environment-only resolution, which is
            # the safe default: a command must not reach into somebody's keys
            # just because it can read the database.
            with aicontext.acting_as(None):
                self._report(options, None, ok, warn, bad)
            return
        with aicontext.acting_as(owner):
            self._report(options, owner, ok, warn, bad)

    def _owner(self, identifier: str):
        """The account to act as, or None for environment-only."""
        if not identifier:
            return None

        from django.contrib.auth import get_user_model
        from django.core.management.base import CommandError

        model = get_user_model()
        found = (model.objects.filter(email__iexact=identifier).first()
                 or model.objects.filter(username__iexact=identifier).first())
        if found is None:
            raise CommandError(f"No account matches {identifier!r}.")
        return found

    def _report(self, options, owner, ok, warn, bad) -> None:
        self.stdout.write(self.style.MIGRATE_HEADING("AI provider"))
        self.stdout.write(
            f"  account  : {owner} (credentials saved in Settings)" if owner
            else warn("  account  : none -- reading the environment only. "
                      "Pass --user to include saved credentials."))

        usable, source, advice = ai.describe_credentials()
        self.stdout.write(f"  provider : {ai.provider()}"
                          f"  (options: {', '.join(sorted(ai.PROVIDERS))})")
        self.stdout.write(f"  model    : {ai.describe_provider()}")
        self.stdout.write(f"  source   : {source}")
        self.stdout.write(f"  status   : {ok('ready') if usable else bad('not usable')}")
        if advice:
            self.stdout.write(warn(f"  fix      : {advice}"))

        # Every provider, and where each one's credential comes from. Shows at
        # a glance which are usable and which source won -- the question that
        # "database or .env?" makes worth asking.
        self.stdout.write(self.style.MIGRATE_HEADING(chr(10) + "Providers"))
        for status in credentials.all_statuses(owner):
            mark = ok("configured") if status["configured"] else bad("not configured")
            line = f"  {status['name']:<11} {mark}  source: {status['source_label']}"
            if status["masked"]:
                line += f"  key: {status['masked']}"
            if not status["sdk_installed"]:
                line += warn(f"  (needs `pip install {status['package']}`)")
            self.stdout.write(line)

            # The children, so "which of my three keys is live" has an answer
            # outside the browser.
            for child in status["credentials"]:
                state = ok("ACTIVE") if child["is_active"] else "inactive"
                used = (child["last_used_at"] or "")[:10] or "never used"
                fallback = ", fallback" if child["allow_fallback"] else ""
                self.stdout.write(
                    f"              {state:<9} {child['label']}  "
                    f"{child['masked']}  {child['request_count']} requests, "
                    f"{child['error_count']} failed, last {used}{fallback}")
                if child["last_error_detail"]:
                    self.stdout.write(warn(
                        f"                        last error: "
                        f"{child['last_error_category']} -- "
                        f"{child['last_error_detail']}"))

            if status["credentials"] and not status["has_active"]:
                self.stdout.write(warn(
                    "              no active credential -- activate one in "
                    "Settings"))
            if status["env_present"] and status["source"] == "database":
                self.stdout.write(
                    f"              {status['env_vars'][0]} is also set, and is "
                    "used only when no credential is active")

        # Show the raw inputs, so a shadowed credential is obvious at a glance.
        self.stdout.write(self.style.MIGRATE_HEADING("\nEnvironment"))
        for name in ("OUTREACH_AI_PROVIDER", "OUTREACH_AI_MODEL",
                     "GROQ_API_KEY", "GEMINI_API_KEY", "GOOGLE_API_KEY",
                     "ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN",
                     "ANTHROPIC_PROFILE", "ANTHROPIC_CONFIG_DIR"):
            if name in os.environ:
                value = os.environ[name]
                plain = ("ANTHROPIC_PROFILE", "ANTHROPIC_CONFIG_DIR",
                         "OUTREACH_AI_PROVIDER", "OUTREACH_AI_MODEL")
                shown = "(empty!)" if not value.strip() else (
                    value if name in plain else f"set, {len(value)} chars"
                )
                self.stdout.write(f"  {name} = {shown}")
            else:
                self.stdout.write(f"  {name} = not set")

        # The ant CLI only matters for Claude; skip the noise on Gemini.
        if ai.provider() == "claude":
            self.stdout.write(self.style.MIGRATE_HEADING("\nant CLI"))
            binary = shutil.which("ant")
            if binary:
                self.stdout.write(f"  binary : {binary}")
                self._run_ant_status()
            else:
                self.stdout.write(warn("  binary : not on PATH"))
                self.stdout.write(
                    "           Install it, then run `ant auth login` to sign "
                    "in through the browser."
                )
            from outreach import ai_claude
            self.stdout.write(
                f"  profiles dir : {ai_claude._profile_dir() / 'credentials'}")

        if not options["live"]:
            self.stdout.write(
                "\nPass --live to generate one throwaway email and confirm the "
                "credential really works."
            )
            return

        self.stdout.write(self.style.MIGRATE_HEADING("\nLive test"))
        if not usable:
            self.stdout.write(bad("  skipped -- no usable credential."))
            return

        try:
            email = ai.generate(
                business_name="Bella Cucina",
                category="Restaurant",
                city="Delft",
                country="Netherlands",
                website="https://example.com",
                sender_name="Test Sender",
                sender_company="Test Co",
                service_pitch="We build booking websites for restaurants.",
                site_context="--- HOME PAGE\nWood-fired pizza, hand-made sourdough bases.",
                site_note="Read 1 page.",
            )
        except ai.AiError as exc:
            self.stdout.write(bad(f"  failed : {exc}"))
            return

        self.stdout.write(ok("  call succeeded"))
        self.stdout.write(f"  subject     : {email.subject}")
        self.stdout.write(f"  observation : {email.observation}")
        body = email.body.replace("\n", "\n                ")
        self.stdout.write(f"  body        : {body}")

    def _run_ant_status(self) -> None:
        try:
            result = subprocess.run(
                ["ant", "auth", "status"], capture_output=True, text=True,
                timeout=30, check=False,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            self.stdout.write(self.style.WARNING(f"  `ant auth status` failed: {exc}"))
            return

        for line in (result.stdout or result.stderr or "").splitlines():
            if line.strip():
                self.stdout.write(f"  | {line.rstrip()}")
