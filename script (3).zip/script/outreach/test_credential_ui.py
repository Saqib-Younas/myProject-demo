"""
The credential pool's rendered page.

Separate from `test_credentials.py` because these assert on *markup* -- the
controls a user actually has, and the two states the page must never confuse:
"active" and "saved but not active". They are the tests that fail if the template
and the JS renderer drift apart on what a credential row contains.
"""

from __future__ import annotations

from django.urls import reverse

from . import credentials
from .test_credentials import clean_env
from .testsupport import SignedIn


class CredentialCardTests(SignedIn):
    def setUp(self):
        with clean_env():
            self.live = credentials.add(self.user, "openai", "sk-live-1111",
                                        label="Production",
                                        description="Main billing account")
            self.spare = credentials.add(self.user, "openai", "sk-spare-2222",
                                         label="Backup")

    def _page(self):
        with clean_env():
            return self.client.get(reverse("outreach:settings"))

    def test_each_credential_is_a_row_the_browser_can_act_on(self):
        response = self._page()

        for row in (self.live, self.spare):
            with self.subTest(label=row.label):
                self.assertContains(response, f'data-id="{row.pk}"')

    def test_the_active_credential_offers_deactivate_and_not_activate(self):
        """A control that would do nothing must not be on screen."""
        page = self._page().content.decode()
        active_row = page.split(f'data-id="{self.live.pk}"')[1].split("</li>")[0]

        self.assertIn("cred-deactivate", active_row)
        self.assertNotIn("cred-activate", active_row)
        self.assertIn("ACTIVE", active_row)

    def test_a_spare_offers_activate_and_the_fallback_switch(self):
        page = self._page().content.decode()
        spare_row = page.split(f'data-id="{self.spare.pk}"')[1].split("</li>")[0]

        self.assertIn("cred-activate", spare_row)
        self.assertIn("cred-fallback", spare_row)
        self.assertNotIn("ACTIVE", spare_row)

    def test_every_credential_can_be_tested_and_deleted(self):
        page = self._page().content.decode()

        for row in (self.live, self.spare):
            with self.subTest(label=row.label):
                markup = page.split(f'data-id="{row.pk}"')[1].split("</li>")[0]
                self.assertIn("cred-test", markup)
                self.assertIn("cred-delete", markup)

    def test_the_description_is_shown(self):
        self.assertContains(self._page(), "Main billing account")

    def test_the_add_form_is_present_for_every_provider(self):
        page = self._page()

        self.assertContains(page, "Add credential", count=len(credentials.SPECS))
        for name in credentials.SPECS:
            with self.subTest(provider=name):
                self.assertContains(page, f'id="key-{name}"')
                self.assertContains(page, f'id="lbl-{name}"')

    def test_the_key_field_is_a_password_field(self):
        """A credential must not sit on screen in plain text."""
        page = self._page().content.decode()
        field = page.split('id="key-openai"')[0].split("<input")[-1]

        self.assertIn('type="password"', field)

    def _card(self, page: str, provider: str) -> str:
        """One provider card.

        Anchored on the card's own class, not on `data-provider` alone: the
        provider selector at the top of the page carries that attribute too, and
        splitting on it lands in the wrong element.
        """
        marker = f'class="cred-card" data-provider="{provider}"'
        return page.split(marker)[1].split("</article>")[0]

    def test_the_activate_box_is_off_when_a_provider_already_has_one(self):
        """Adding a spare must not default to taking over."""
        card = self._card(self._page().content.decode(), "openai")
        box = card.split('class="check cred-activate-new"')[1].split(">")[0]

        self.assertNotIn("checked", box)

    def test_the_activate_box_is_on_when_a_provider_has_nothing(self):
        card = self._card(self._page().content.decode(), "groq")
        box = card.split('class="check cred-activate-new"')[1].split(">")[0]

        self.assertIn("checked", box)

    def test_the_write_controls_disappear_when_the_ui_is_switched_off(self):
        with clean_env(OUTREACH_CREDENTIALS_UI="0"):
            page = self.client.get(reverse("outreach:settings")).content.decode()

        active_row = page.split(f'data-id="{self.live.pk}"')[1].split("</li>")[0]
        self.assertIn("cred-deactivate", active_row)
        self.assertIn("disabled", active_row)
        self.assertIn("OUTREACH_CREDENTIALS_UI=0", page)

    def test_the_page_carries_every_endpoint_the_script_needs(self):
        """The URLs are reversed in the template, never built in JS."""
        page = self._page().content.decode()

        for attribute in ("data-add-url", "data-activate-url",
                          "data-deactivate-url", "data-test-url",
                          "data-fallback-url", "data-delete-url",
                          "data-select-url"):
            with self.subTest(attribute=attribute):
                self.assertIn(attribute, page)

    def test_the_history_panel_appears_once_there_is_history(self):
        page = self._page()

        self.assertContains(page, "Recent credential activity")
        self.assertContains(page, "Production")

    def test_a_failure_is_shown_on_the_credential_that_failed(self):
        credentials.record_use(self.spare.pk, success=False,
                               category="rate_limited",
                               detail="The provider is rate limiting this key.")
        page = self._page().content.decode()
        spare_row = page.split(f'data-id="{self.spare.pk}"')[1].split("</li>")[0]
        live_row = page.split(f'data-id="{self.live.pk}"')[1].split("</li>")[0]

        self.assertIn("rate limiting", spare_row)
        self.assertNotIn("rate limiting", live_row)
