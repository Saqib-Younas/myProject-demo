"""
Writes one email per lead, using whichever AI provider is configured.

Every lead gets its own request built from its own website material, so no two
emails share a template. Two constraints hold regardless of provider:

  * structured output -- the response is validated against a JSON schema, so
    there is nothing to parse defensively,
  * an `observation` field -- the model must quote the specific website fact its
    personalisation rests on. If the website could not be read, the prompt says
    so and the observation must be "none", which the review UI surfaces. That
    turns "do not make up information" into something the user can check.

The prompt, the schema and the parsing live here and are shared. Each backend
(`ai_claude`, `ai_gemini`) only does transport and provider-specific errors, so
switching providers cannot quietly change the email contract.

Pick one with OUTREACH_AI_PROVIDER=claude|gemini.
"""

from __future__ import annotations

import importlib
import json
import os
import re
from types import ModuleType

from . import credentials
from .ai_base import AiError, Finding, GeneratedEmail, SiteAudit

__all__ = [
    "AiError", "Finding", "GeneratedEmail", "SiteAudit", "SYSTEM", "SCHEMA",
    "AUDIT_SYSTEM", "AUDIT_SCHEMA", "REVIEW_DIMENSIONS", "DEFAULT_OFFER",
    "MAX_FINDINGS", "PROVIDERS", "audit", "build_audit_prompt", "build_prompt",
    "generate", "parse", "parse_audit", "provider", "backend", "load", "model",
    "describe_credentials", "describe_provider", "FOLLOWUP_SYSTEM",
    "FOLLOWUP_SCHEMA", "FOLLOWUP_MAX_TOKENS", "follow_up",
    "build_followup_prompt", "parse_followup", "reply_subject",
    "NO_WEBSITE_SYSTEM", "NO_WEBSITE_SCHEMA", "no_website_email",
    "build_no_website_prompt", "parse_no_website",
]

#: The brief asks for 8-10 findings. This is the hard ceiling; the prompt is
#: what asks for a realistic number, and fewer is an acceptable answer.
MAX_FINDINGS = 10

#: Output reservations, sized to the task. These are not free on every provider
#: -- Groq counts the reservation against its tokens-per-minute allowance, so
#: asking for 4k on a short email can fail a request that would otherwise fit.
#: Ten findings of four fields each need real room; one email does not.
AUDIT_MAX_TOKENS = int(os.environ.get("OUTREACH_AI_AUDIT_TOKENS", "2600"))
EMAIL_MAX_TOKENS = int(os.environ.get("OUTREACH_AI_EMAIL_TOKENS", "1200"))

#: Backend name -> (module path, the pip package it needs).
#:
#: Imported lazily so only the provider actually in use needs its SDK
#: installed -- running on Gemini should not require `anthropic`, or vice versa.
#: Each module exposes NAME, LABEL, DEFAULT_MODEL, describe_credentials() and
#: complete().
#: Derived from credentials.SPECS so there is one list of providers in the
#: project, not two that can drift apart. The shape is unchanged, so callers and
#: tests that read PROVIDERS keep working.
PROVIDERS: dict[str, tuple[str, str]] = {
    name: (provider_spec.module, provider_spec.package)
    for name, provider_spec in credentials.SPECS.items()
}

DEFAULT_PROVIDER = credentials.DEFAULT_PROVIDER

#: Dimensions the reviewer is asked to consider. Named explicitly so coverage is
#: broad rather than whatever the model thinks of first.
REVIEW_DIMENSIONS = (
    "UI/UX", "visual design", "layout", "navigation", "mobile responsiveness",
    "images", "image optimisation", "content quality", "grammar and readability",
    "services/products clarity", "calls to action and conversion flow",
    "contact experience", "trust signals", "SEO basics",
    "performance indicators", "accessibility", "overall customer experience",
)

AUDIT_SYSTEM = """\
You are a senior web consultant reviewing a small business website before a \
sales conversation. You have been given the text and MEASURED SIGNALS from \
several pages that were actually crawled.

Your job is to report genuine, defensible issues and improvement \
opportunities -- the kind a competent consultant would raise in a first \
meeting.

THE EVIDENCE RULE, which overrides everything else:

Every finding must rest on something present in the supplied material -- a \
measured signal, a quoted phrase, a missing element the data shows is missing. \
The "evidence" field must state that specific fact, including the number or the \
quote. If you cannot point to evidence, do not report the finding.

Specifically, you must NOT claim:
- slow load times unless load_ms says so,
- missing mobile support unless viewport_meta is false,
- missing alt text unless images_missing_alt is above zero,
- a weak CTA unless cta_count is low or zero for that page,
- thin content unless word_count is low,
- anything at all about colours, fonts, spacing, animation, hover states, \
video, or how the site *looks* -- you were given text and measurements, not \
screenshots. You cannot see the site.
- anything about pages that were not supplied.

Report 8 to 10 findings when the evidence supports that many. Report fewer if \
it does not. Padding the list with speculation is a failure; a short, solid \
list is a success.

Judge severity honestly: "high" means it plausibly costs the business enquiries, \
"medium" is a real weakness, "low" is a refinement. Order findings strongest \
first.

Write for the business owner, not for a developer. No jargon in "why_it_matters" \
-- say what it costs them in plain commercial terms.

Reply with JSON only, matching the schema you were given. Every field of every \
finding must be present.\
"""

AUDIT_SCHEMA = {
    "type": "object",
    "properties": {
        "business_summary": {
            "type": "string",
            "description": (
                "One or two sentences on what this business does and who it "
                "serves, drawn only from the supplied pages."
            ),
        },
        "findings": {
            "type": "array",
            "minItems": 1,
            "maxItems": 10,
            "items": {
                "type": "object",
                "properties": {
                    "issue": {
                        "type": "string",
                        "description": "The problem or opportunity, one short sentence.",
                    },
                    "evidence": {
                        "type": "string",
                        "description": (
                            "The specific measured signal or quoted text this "
                            "rests on. Include the number or the quote."
                        ),
                    },
                    "why_it_matters": {
                        "type": "string",
                        "description": (
                            "The commercial cost to the business, in plain "
                            "language, no jargon."
                        ),
                    },
                    "suggested_improvement": {
                        "type": "string",
                        "description": "A concrete, actionable fix.",
                    },
                    "dimension": {
                        "type": "string",
                        "description": (
                            "Which area this belongs to, e.g. navigation, SEO "
                            "basics, calls to action, accessibility."
                        ),
                    },
                    "severity": {
                        "type": "string",
                        "enum": ["high", "medium", "low"],
                    },
                },
                # Strict schema mode requires every declared property to appear
                # in "required" -- there is no such thing as an optional field.
                # A `page_url` field was tried here and cost a whole run: the
                # model reported eight well-evidenced findings, omitted that one
                # field, and the entire response was rejected. Models cite the
                # page inside "evidence" of their own accord, so the field was
                # redundant as well as fragile.
                "required": ["issue", "evidence", "why_it_matters",
                             "suggested_improvement", "dimension", "severity"],
                "additionalProperties": False,
            },
        },
    },
    "required": ["business_summary", "findings"],
    "additionalProperties": False,
}

#: What we sell. Prefills "What do you offer?" on the setup screen, and stands in
#: wherever a campaign has not set its own `service_pitch`.
#:
#: Every email connects a verified website finding to this text, and the prompts
#: forbid describing the offer in any terms other than these -- so a capability
#: that is not written here cannot appear in an email. That makes this paragraph
#: worth being specific in: naming speed, mobile and SEO work explicitly is what
#: lets an email about a slow homepage say honestly that the sender fixes exactly
#: that.
DEFAULT_OFFER = (
    "We help businesses build fast, responsive, SEO-friendly, and "
    "conversion-focused websites that look professional on every device. Our "
    "services include website development, speed and performance optimization, "
    "mobile responsiveness, technical SEO improvements, modern UI/UX, landing "
    "pages, website redesigns, and conversion optimization. We combine modern "
    "web development with AI-powered lead and sales automation to help "
    "businesses strengthen their online presence, attract more potential "
    "customers, make it easier for visitors to take action, and build a more "
    "efficient path from website visitor to qualified lead."
)

SYSTEM = """\
You write first-contact B2B emails for an agency reaching out to local \
businesses found on a public map. A website review has already been done for \
you; its findings are supplied.

Rules, in order of importance:

1. Never state anything you were not given. No invented client names, metrics, \
awards, locations, staff, prices or history, and no problems beyond the \
supplied findings.
2. Build the email on ONE to THREE of the supplied findings, starting with the \
first: they have already been ranked by commercial importance, so the first is \
the one worth leading on. Refer to each specifically enough that the sentence \
could only have been written about this business.

2a. NEVER write a vague version of a finding. "I noticed some issues with your \
website", "there are a few areas that could be improved", "your site could be \
better optimised" -- these are wrong answers even when findings were supplied, \
because they say nothing that required looking. Name the actual thing: "the main \
contact button is hard to find on a phone", "the homepage has no page title", \
"most of your images have no alt text".

2b. Say it in the owner's language, not the auditor's. You are given measured \
numbers as evidence that a finding is real -- you must NOT put them in the \
email. Never write a metric name or a raw figure: no "LCP", "load_ms", \
"cta_count", "4.8s", "viewport meta tag", "12 of 14 images". Translate: a slow \
measurement becomes "the homepage takes a noticeable moment to load on mobile"; \
a missing viewport tag becomes "the site does not adapt to phone screens"; a \
zero CTA count becomes "there is no obvious way for a visitor to get in touch".
3. Make it clear the site was actually looked at, WITHOUT narrating the review. \
Never list the pages visited. Do not write "I visited your Home, About, \
Services and Contact pages" or "I reviewed 6 pages of your site". Write like a \
person who happened to look: "I noticed your website currently has no...", \
"Your services page describes X, but...".
4. Raise the issue as an opportunity, not a scolding. One to three findings, \
mentioned plainly in prose. Do not paste the whole list, do not use bullet \
points, and do not include the evidence numbers -- those are for internal use.
5. Connect that opportunity to what the sender offers, in one sentence. The \
link must be honest: if the finding and the offer only relate loosely, keep the \
claim modest. Describe the offer ONLY in the terms you were given -- do not add \
capabilities, technologies, mechanisms or results that were not stated. \
Inventing how the service works is the same error as inventing a website \
problem.
6. Be brief. 90-150 words in the body. Short paragraphs.
7. Plain professional English. No exclamation marks, no "I hope this email \
finds you well", no hard-sell superlatives, no emoji, no jargon.
8. One clear call to action -- a short, low-friction ask such as a 15-minute \
call or a reply.
9. Subject line: 4-9 words, specific to this business, sentence case, not \
clickbait, no "Re:" and no fake familiarity.
10. Close with the sender's name, company and email on their own lines, exactly \
as supplied. Never write a placeholder like [Your Name].
11. "findings_used" and "observation" are the audit trail. List the exact \
issue text of each finding you drew on, and state in "observation" the specific \
thing your email refers to. If no findings were supplied, set both to reflect \
that: "observation" becomes "none" and "findings_used" an empty list. An email \
that references the site while reporting "none" is a wrong answer, and so is one \
that lists a finding it never actually mentioned.

Reply with JSON only, matching the schema you were given. The body must be \
plain text with \\n\\n between paragraphs, and must not repeat the subject \
line.\
"""

SCHEMA = {
    "type": "object",
    "properties": {
        "subject": {
            "type": "string",
            "description": "Natural subject line, 4-9 words, specific to this business.",
        },
        "body": {
            "type": "string",
            "description": (
                "The email body as plain text, 90-150 words, paragraphs "
                "separated by blank lines, closing with the sender's name, "
                "company and email."
            ),
        },
        "observation": {
            "type": "string",
            "description": (
                "The specific website fact the email refers to, quoted or "
                "closely paraphrased. Exactly 'none' if no findings were supplied."
            ),
        },
        "findings_used": {
            "type": "array",
            "items": {"type": "string"},
            "description": (
                "The exact 'issue' text of each supplied finding the email "
                "draws on. Empty if none were supplied."
            ),
        },
    },
    "required": ["subject", "body", "observation", "findings_used"],
    "additionalProperties": False,
}


# --------------------------------------------------------------------------- #
# Provider selection
# --------------------------------------------------------------------------- #

def provider() -> str:
    """The selected provider name.

    Read live, and through the resolver, so a change made in Settings takes
    effect on the next request without a restart. The priority is the same as it
    is for credentials: a choice saved in Settings, then OUTREACH_AI_PROVIDER,
    then the built-in default.
    """
    return credentials.selection()[0]


def load(name: str) -> ModuleType:
    """Import one backend by name, with a readable error if it is unavailable."""
    try:
        path, package = PROVIDERS[(name or "").strip().lower()]
    except KeyError:
        raise AiError(
            f"Unknown AI provider {name!r}. Choose one of: "
            f"{', '.join(sorted(PROVIDERS))} in Settings, or set "
            "OUTREACH_AI_PROVIDER."
        ) from None

    try:
        return importlib.import_module(path)
    except ImportError as exc:
        raise AiError(
            f"The {name} backend needs the {package!r} package, which is not "
            f"installed. Run `pip install {package}`, or switch provider with "
            f"OUTREACH_AI_PROVIDER."
        ) from exc


def backend() -> ModuleType:
    return load(provider())


def model() -> str:
    """The model to use, for the selected provider.

    Priority: a model saved against that provider's credential, then the model
    chosen in Settings, then OUTREACH_AI_MODEL, then the backend default. Each
    provider keeps its own model, so switching provider cannot leave a model name
    belonging to a different one behind.
    """
    name = provider()
    resolved = credentials.resolve(name)
    if resolved.model:
        # Carried with the active credential, so a testing key can point at a
        # cheaper model than the production one without any other change.
        return resolved.model

    chosen = credentials.selection()[1]
    if chosen:
        return chosen
    return backend().DEFAULT_MODEL


def describe_credentials() -> tuple[bool, str, str]:
    """(usable, source, advice) for the configured provider."""
    try:
        return backend().describe_credentials()
    except AiError as exc:
        return False, str(exc), ""


def describe_provider() -> str:
    """One line for status output and error messages."""
    try:
        return f"{backend().LABEL} / {model()}"
    except AiError:
        return f"{provider()} (unknown)"


# --------------------------------------------------------------------------- #
# The one path every AI request takes
# --------------------------------------------------------------------------- #

def _complete(*, system: str, prompt: str, schema: dict,
              max_tokens: int) -> str:
    """Send one request through the active credential, and record what happened.

    Every AI feature in the application goes through here -- the website review,
    the email, the follow-up, the no-website email, and anything added later.
    That is what makes "activate the backup credential" take effect everywhere at
    once with no other change: this function asks the resolver which credential is
    active, and the resolver is the only thing that knows.

    Three responsibilities, in one place because they belong together:

      * **usage** -- which credential served the request, and did it work. Written
        against the child row, so the Settings page can show a real "last used"
        rather than an invented one.
      * **safe failures** -- the provider's own error text is never stored or
        shown. It can quote the request, and the request carried the key; a
        category and a written phrase are enough to act on.
      * **opt-in fallback** -- if the active credential is rate limited and the
        user has explicitly marked a spare as usable, the spare is tried *for this
        request only*. The active credential never changes: silently rotating it
        would leave the user looking at a Settings page that no longer says what
        the application is doing.
    """
    from . import aicontext, credentials

    name = provider()
    resolved = credentials.require(name)
    handle = backend()

    def send() -> str:
        return handle.complete(system=system, prompt=prompt, schema=schema,
                               model=model(), max_tokens=max_tokens)

    try:
        text = send()
    except Exception as first_error:      # noqa: BLE001 - categorised below
        category, phrase = credentials.categorise(first_error)
        credentials.record_use(resolved.credential_id, success=False,
                               category=category, detail=phrase)

        spare = _fallback_for(name, category, resolved)
        if spare is None:
            raise

        # One retry, on one spare, for this request only.
        owner = aicontext.get_owner()
        try:
            with aicontext.using_credential(spare):
                credentials.invalidate(name)
                text = handle.complete(system=system, prompt=prompt,
                                       schema=schema, model=model(),
                                       max_tokens=max_tokens)
        except Exception as second_error:  # noqa: BLE001
            spare_category, spare_phrase = credentials.categorise(second_error)
            credentials.record_use(spare.pk, success=False,
                                   category=spare_category, detail=spare_phrase)
            credentials.record_fallback(
                owner=owner, provider=name, from_label=resolved.label or "active",
                to_row=spare, reason=category, result=spare_phrase)
            credentials.invalidate(name)
            raise first_error from None     # report the active key's failure
        finally:
            credentials.invalidate(name)

        credentials.record_use(spare.pk, success=True)
        credentials.record_fallback(
            owner=owner, provider=name, from_label=resolved.label or "active",
            to_row=spare, reason=category, result="succeeded")
        return text

    credentials.record_use(resolved.credential_id, success=True)
    return text


#: Failures a different key might genuinely survive. An invalid key is not one of
#: them for the *same* provider account, but a rate limit or a quota is exactly
#: what a spare key exists for.
FALLBACK_CATEGORIES = ("rate_limited", "unavailable")


def _fallback_for(name: str, category: str, resolved):
    """A spare credential to try, or None.

    None whenever anything is unclear: the failure is not one a different key
    would survive, the user has not marked a spare as usable, or the request was
    not using a database credential in the first place.
    """
    from . import credentials

    if category not in FALLBACK_CATEGORIES:
        return None
    if not resolved.credential_id:
        # An environment or CLI credential. There is no pool to fall back within.
        return None

    for spare in credentials.fallbacks(name):
        if spare.pk != resolved.credential_id:
            return spare
    return None


# --------------------------------------------------------------------------- #
# Prompt
# --------------------------------------------------------------------------- #

def build_audit_prompt(*, business_name: str, category: str, city: str,
                       country: str, website: str, site_context: str,
                       pages_read: int, discovered: int) -> str:
    """Assemble the review request for one lead's crawled site."""
    return f"""\
Review this business's website and report the strongest genuine issues and \
improvement opportunities.

BUSINESS (from a public map listing):
Name: {business_name}
Category: {category or 'unknown'}
Location: {', '.join(p for p in (city, country) if p) or 'unknown'}
Website: {website}

CRAWL: {pages_read} page(s) were read automatically out of {discovered} \
discovered internal links. Only what appears below was seen -- say nothing \
about anything else.

AREAS TO CONSIDER (only where the evidence supports a finding):
{', '.join(REVIEW_DIMENSIONS)}

CRAWLED PAGES, TEXT AND MEASURED SIGNALS:
{site_context}

Report the 8-10 strongest findings the evidence supports, strongest first. \
Every "evidence" field must cite a specific measured signal or quote from \
above."""


#: Measured signals worth restating in the email request, and what each one
#: actually means to a business owner. The email must not quote the numbers -- the
#: prompt says so -- but the model writes a better sentence when it knows the
#: measurement behind the finding it is describing, and a wrong-way-round claim
#: ("your fast site is slow") becomes impossible rather than merely forbidden.
#:
#: Kept short on purpose. Every extra signal is another thing the model can be
#: tempted to mention, and these are the ones that carry commercial meaning.
EMAIL_SIGNALS: tuple[tuple[str, str], ...] = (
    ("load_ms", "homepage response time, milliseconds"),
    ("page_kb", "homepage weight, KB"),
    ("viewport_meta", "adapts to phone screens (false means it does not)"),
    ("cta_count", "obvious ways to get in touch, counted on the page"),
    ("forms", "contact or enquiry forms found"),
    ("tel_links", "tappable phone links"),
    ("word_count", "words of visible copy"),
    ("title_length", "page title length, 0 means missing"),
    ("meta_description_length", "search description length, 0 means missing"),
    ("images", "images on the page"),
    ("images_missing_alt", "images with no alt text"),
    ("h1_count", "main headings (0 or several is a problem)"),
    ("https", "served over HTTPS"),
)


def attribute_pages(findings: list, pages: list | None) -> list:
    """Fill in each finding's `page_url` from the pages that were crawled.

    §5 asks for the page a finding was found on. It is derived here rather than
    asked of the model: a required `page_url` field in the audit schema was tried
    and cost a whole run when the model omitted it, and a URL invented to satisfy
    a schema is worse than no URL at all.

    So the evidence text is matched against the pages actually read -- by URL
    first, then by the page's kind ("the contact page has no form"). Nothing
    matches, nothing is filled in. Every URL this produces is one the crawler
    fetched.
    """
    crawled = [
        (str(p.get("url") or ""), str(p.get("kind") or "").lower())
        for p in (pages or []) if isinstance(p, dict) and p.get("url")
    ]
    if not crawled:
        return findings

    home = crawled[0][0]
    for finding in findings:
        if getattr(finding, "page_url", ""):
            continue
        haystack = f"{finding.evidence} {finding.issue}".lower()

        # Longest first: the site root is a prefix of every other page, so a
        # shortest-match search would attribute every finding to the homepage.
        match = next(
            (url for url in sorted((u for u, _k in crawled), key=len, reverse=True)
             if url.lower() in haystack), "")
        if not match:
            match = next(
                (url for url, kind in crawled
                 if kind and kind != "home" and f"{kind} page" in haystack), "")
        if not match and ("home" in haystack or "homepage" in haystack):
            match = home
        finding.page_url = match
    return findings


def build_prompt(*, business_name: str, category: str, city: str, country: str,
                 website: str, sender_name: str, sender_company: str,
                 sender_email: str = "", service_pitch: str = "",
                 findings: list | None = None, business_summary: str = "",
                 site_note: str = "", retry_hint: str = "",
                 pages: list | None = None, signals: dict | None = None) -> str:
    """Assemble the per-lead email request from the review findings.

    The findings arrive here already ranked by commercial importance and already
    trimmed to the two or three the email may use -- see
    `scoring.rank_for_email`. This function's job is to present them as
    *structured evidence* rather than as a sentence: issue, severity, dimension,
    the measured fact behind it, what it costs the business, the fix, and the page
    it was found on.

    That structure is the whole defence against a generic email. A model given
    "review the site at example.com" will write "I noticed some issues with your
    website" because that is all it knows. A model given "the homepage has no
    page title (title_length=0), found at example.com/, which means search
    results show a bare URL" can only write something specific.
    """
    facts = [
        f"Business name: {business_name}",
        f"Category: {category or 'unknown'}",
        f"Location: {', '.join(p for p in (city, country) if p) or 'unknown'}",
        f"Website: {website or 'none published'}",
    ]
    if business_summary:
        facts.append(f"What they do (from their site): {business_summary}")

    findings = list(findings or [])
    if findings:
        findings = attribute_pages(findings, pages)
        blocks = []
        for index, finding in enumerate(findings, 1):
            lines = [
                f"{index}. {finding.issue}",
                f"   Severity: {finding.severity or 'medium'}"
                + (f"   Area: {finding.dimension}" if finding.dimension else ""),
                f"   Evidence (measured -- do NOT quote in the email): "
                f"{finding.evidence}",
                f"   What it costs them: {finding.why_it_matters}",
            ]
            if finding.suggested_improvement:
                lines.append(f"   Fix: {finding.suggested_improvement}")
            if getattr(finding, "page_url", ""):
                lines.append(f"   Found on: {finding.page_url}")
            blocks.append("\n".join(lines))

        findings_block = (
            "VERIFIED WEBSITE FINDINGS. These come from a crawl of the pages "
            "listed above and are the ONLY website problems that exist as far as "
            "this email is concerned. They are ordered by commercial importance, "
            "most important first. Build the email on the first one, and at most "
            "three in total:\n\n" + "\n\n".join(blocks)
        )
    else:
        findings_block = (
            f"VERIFIED WEBSITE FINDINGS: none available ({site_note or 'the site could not be reviewed'}). "
            "Do not imply you looked at their website. Write a short, honest "
            "note based only on the business facts above, and set "
            '"observation" to "none" with an empty "findings_used".'
        )

    sections = [f"BUSINESS FACTS:\n{chr(10).join(facts)}"]

    pages_block = _pages_block(pages)
    if pages_block and findings:
        sections.append(pages_block)

    signals_block = _signals_block(signals)
    if signals_block and findings:
        sections.append(signals_block)

    sections.append(findings_block)
    sections.append(
        "ABOUT THE SENDER (close the email with these, on their own lines):\n"
        f"Name: {sender_name}\n"
        f"Company: {sender_company or sender_name}\n"
        f"Email: {sender_email or 'omit if blank'}\n"
        f"What they offer: {service_pitch or DEFAULT_OFFER}"
    )

    prompt = ("Write one first-contact email to this business.\n\n"
              + "\n\n".join(sections))
    if retry_hint:
        prompt += f"\n\nREVISION NOTE: {retry_hint}"
    return prompt


def _pages_block(pages: list | None) -> str:
    """Which pages were actually read. §5's "pages analyzed"."""
    rows = [
        f"- {p.get('kind') or 'page'}: {p['url']}"
        for p in (pages or [])
        if isinstance(p, dict) and p.get("url")
    ]
    if not rows:
        return ""
    return (f"PAGES ANALYSED ({len(rows)} crawled -- nothing outside this list "
            "was seen, and the email must never claim otherwise):\n"
            + "\n".join(rows[:12]))


def _signals_block(signals: dict | None) -> str:
    """The measured numbers behind the findings, with what each one means.

    Present so the model describes a real measurement in plain words rather than
    guessing at the shape of the problem. Explicitly labelled as not for
    quoting -- the prompt forbids putting a figure in the email, and a labelled
    number is easier to obey than an unexplained one.
    """
    if not signals:
        return ""
    rows = []
    for key, meaning in EMAIL_SIGNALS:
        if key not in signals:
            continue
        value = signals[key]
        if value in (None, "", []):
            continue
        rows.append(f"- {key} = {value}   ({meaning})")
    if not rows:
        return ""
    return ("MEASURED SIGNALS behind those findings. Context for your wording "
            "only -- translate them into plain business language and NEVER put a "
            "number or a metric name in the email:\n" + "\n".join(rows))


# --------------------------------------------------------------------------- #
# Generation
# --------------------------------------------------------------------------- #

def audit(*, business_name: str, category: str, city: str, country: str,
          website: str, site_context: str, pages_read: int,
          discovered: int) -> SiteAudit:
    """Review one crawled website. Raises AiError on failure."""
    if not site_context.strip():
        raise AiError("There is no crawled website material to review.")

    prompt = build_audit_prompt(
        business_name=business_name, category=category, city=city,
        country=country, website=website, site_context=site_context,
        pages_read=pages_read, discovered=discovered,
    )
    text = _complete(system=AUDIT_SYSTEM, prompt=prompt, schema=AUDIT_SCHEMA,
                     max_tokens=AUDIT_MAX_TOKENS)
    return parse_audit(text)


def generate(*, business_name: str, category: str, city: str, country: str,
             website: str, sender_name: str, sender_company: str,
             sender_email: str = "", service_pitch: str = "",
             findings: list | None = None, business_summary: str = "",
             site_note: str = "", retry_hint: str = "",
             pages: list | None = None,
             signals: dict | None = None) -> GeneratedEmail:
    """Generate one email from the review findings. Raises AiError on failure.

    `findings` is expected to be the ranked shortlist, not the whole audit --
    the caller applies `scoring.rank_for_email` so that the commercial ordering
    is one decision made in one place. `pages` and `signals` are the rest of the
    structured evidence: which pages were read, and what was measured on them.
    """
    prompt = build_prompt(
        business_name=business_name, category=category, city=city,
        country=country, website=website, sender_name=sender_name,
        sender_company=sender_company, sender_email=sender_email,
        service_pitch=service_pitch, findings=findings,
        business_summary=business_summary, site_note=site_note,
        retry_hint=retry_hint, pages=pages, signals=signals,
    )

    text = _complete(system=SYSTEM, prompt=prompt, schema=SCHEMA,
                     max_tokens=EMAIL_MAX_TOKENS)
    return parse(text)


def _load_json(text: str) -> dict:
    """Parse a model reply into a JSON object, tolerating a code fence."""
    if not (text or "").strip():
        raise AiError("The model returned an empty response.")

    # Some models wrap JSON in a ```json fence even when asked not to.
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.split("\n", 1)[-1].rsplit("```", 1)[0].strip()

    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as exc:
        raise AiError("The model returned malformed JSON.") from exc

    if not isinstance(data, dict):
        raise AiError("The model returned JSON that is not an object.")
    return data


def parse(text: str) -> GeneratedEmail:
    """Validate the model's JSON into a GeneratedEmail."""
    data = _load_json(text)
    subject = str(data.get("subject") or "").strip()
    body = str(data.get("body") or "").strip()
    if not subject or not body:
        raise AiError("The model returned an email with no subject or no body.")

    used = data.get("findings_used") or []
    if not isinstance(used, list):
        used = []

    return GeneratedEmail(
        subject=subject,
        body=body,
        observation=str(data.get("observation") or "").strip() or "none",
        findings_used=[str(u).strip() for u in used if str(u).strip()],
    )


# --------------------------------------------------------------------------- #
# Was the email actually built on the findings?
#
# The prompt says to name the specific thing that was measured. This checks it,
# because "I noticed some issues with your website" is the exact output the brief
# rules out, and a prompt instruction is a request rather than a guarantee.
#
# Two separate failures, both caught here:
#
#   * a **vague claim** -- the email gestures at problems without naming one;
#   * a **quoted metric** -- the email puts "LCP 4.8s" or "cta_count 0" in front
#     of a business owner, which is the audit's language, not theirs.
#
# Neither is fatal. `generate_draft` regenerates once with the failure as the
# revision note, which is cheaper than a human noticing it in review, and far
# cheaper than sending it.
# --------------------------------------------------------------------------- #

#: Phrases that claim a problem without naming one. Matched on the flattened
#: body, so line breaks and double spaces cannot slip one past.
VAGUE_PATTERNS = (
    "some issues with your website", "some issues with your site",
    "a few issues with your", "several issues with your",
    "a number of issues", "some areas for improvement",
    "a few areas for improvement", "areas that could be improved",
    "could be improved in a few", "room for improvement on your",
    "some opportunities to improve", "your website could be better",
    "your site could be better", "could be better optimised",
    "could be better optimized", "not fully optimised",
    "not fully optimized", "a few things that could be", "some things that could be",
    "noticed a few things", "noticed some things", "noticed a couple of things",
)

#: Metric names and shapes that belong in the audit trail, not in an email. The
#: numeric patterns are deliberately narrow -- "15-minute call" and "20 years"
#: are fine, "4.8s" and "load_ms=920" are not.
METRIC_PATTERNS = (
    "load_ms", "page_kb", "cta_count", "word_count", "title_length",
    "images_missing_alt", "meta_description_length", "viewport_meta",
    "h1_count", "tel_links", "lcp", "fcp", "cls", "ttfb",
    "viewport meta", "alt attribute", "pagespeed score", "lighthouse score",
)

_METRIC_NUMBER = re.compile(
    r"\b\d+(?:\.\d+)?\s*(?:ms|kb|mb)\b"          # 920ms, 1.4MB
    r"|\b\d+\.\d+\s*(?:s|sec|seconds)\b"          # 4.8 seconds
    r"|\b\d+\s*(?:of|out of)\s*\d+\s+images\b",  # 12 of 14 images
    re.I,
)


def specificity_problem(email: GeneratedEmail, findings: list | None) -> str:
    """"" if the email is specific enough to send, otherwise what is wrong.

    The return value is written as a revision note, so it is phrased as an
    instruction to the model rather than as a diagnosis for a log.
    """
    findings = list(findings or [])
    flat = " ".join((email.body or "").lower().split())

    if not findings:
        # Nothing was measured. The email must not imply otherwise -- but that is
        # already enforced by the no-findings branch of the prompt and by
        # `observation` being "none", so there is nothing to check for vagueness.
        return ""

    for phrase in VAGUE_PATTERNS:
        if phrase in flat:
            leading = findings[0].issue
            return (f"The email says {phrase!r}, which tells the reader nothing. "
                    f"Name the actual finding instead -- lead with: {leading!r} -- "
                    "described in plain business language.")

    for phrase in METRIC_PATTERNS:
        if phrase in flat:
            return (f"The email contains the technical term {phrase!r}. Measured "
                    "values are internal evidence only. Say what it means for "
                    "their customers instead, with no metric names and no "
                    "figures.")

    found = _METRIC_NUMBER.search(email.body or "")
    if found:
        return (f"The email quotes a measurement ({found.group(0).strip()!r}). "
                "Describe the effect in words -- \"takes a noticeable moment to "
                "load on mobile\" -- rather than giving the number.")

    if not email.findings_used and email.observation.lower() in ("", "none"):
        # Both fields empty means the model is reporting that it referenced
        # nothing -- while holding a list of measured findings. That is rule 11's
        # wrong answer, and worth one more attempt. A missing list on its own is
        # untidy bookkeeping and not worth a second AI call per lead.
        return ("The email reported no findings and no observation even though "
                "findings were supplied. Build it on the first finding, and "
                "record the exact issue text in findings_used.")

    return ""


# --------------------------------------------------------------------------- #
# Workflow B: no verified website
# --------------------------------------------------------------------------- #

NO_WEBSITE_SYSTEM = """\
You are writing a first email to a small business that has no website.

There is nothing to critique here, so do not try. You have never seen a website \
for this business because there is not one to see, and the whole email is about \
what having one could make easier.

WHAT YOU HAVE: the business name, what kind of business it is, where it is, and a \
short list of things a website could plausibly help with for that kind of \
business. That is all. Work from it and nothing else.

THE RULE THAT OVERRIDES EVERYTHING: never state a fact you were not given.

You do not know their revenue, their customer numbers, how busy they are, how \
many staff they have, whether they are losing business, what their competitors \
do, or how people currently find them. Do not imply that you do. "I noticed \
you're missing out on customers" is an invented fact and a bad email.

NEVER GUARANTEE AN OUTCOME. Not revenue, not sales, not more customers, not \
search rankings, not return on investment. Write in the conditional:
- "could make it easier for people to ..."
- "may help when somebody is looking for ..."
- "would give customers somewhere to ..."
- "can be a straightforward way to ..."

NEVER:
- mention SEO rankings, traffic figures or percentages of any kind,
- claim they are invisible online, or that customers cannot find them,
- say a website is essential, or that they are behind their competitors,
- open with "I noticed you don't have a website" as an accusation. It is a fact, \
not a failing, and plenty of good businesses run without one.

STRUCTURE:
1. One line that shows you know what this business actually is and where.
2. One or two of the supplied benefits, in your own words, as possibilities.
3. A single, small, easy next step -- a question they can answer in one line.

LENGTH: 70-110 words of body text. Plain British English, contractions welcome, \
no marketing register, no exclamation marks, no bullet points.

Return only JSON."""

NO_WEBSITE_SCHEMA = {
    "type": "object",
    "properties": {
        "subject": {
            "type": "string",
            "description": (
                "Natural subject line, 4-9 words, naming the business or its "
                "trade. Not a question, and no 'Re:'."
            ),
        },
        "body": {
            "type": "string",
            "description": (
                "The email body as plain text, 70-110 words, paragraphs "
                "separated by blank lines, closing with the sender's name and "
                "company."
            ),
        },
        "observation": {
            "type": "string",
            "description": (
                "The specific thing about this business the email opens on -- "
                "its trade and location. Never a claim about a website."
            ),
        },
        "benefits_used": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Which of the supplied benefits the email drew on.",
        },
    },
    "required": ["subject", "body", "observation", "benefits_used"],
    "additionalProperties": False,
}


def build_no_website_prompt(*, business_name: str, category: str = "",
                            city: str = "", country: str = "",
                            phone: str = "", benefits: list | None = None,
                            sender_name: str = "", sender_company: str = "",
                            sender_email: str = "", service_pitch: str = "",
                            retry_hint: str = "") -> str:
    """Assemble the no-website prompt from listing data only."""
    lines = [
        f"BUSINESS: {business_name}",
        f"WHAT THEY DO: {category or 'not recorded'}",
        f"WHERE: {', '.join(p for p in (city, country) if p) or 'not recorded'}",
    ]
    if phone:
        lines.append("THEY PUBLISH A PHONE NUMBER, so enquiries by phone already "
                     "matter to them.")

    lines += ["",
              "THIS BUSINESS HAS NO VERIFIED WEBSITE. Do not refer to one, and "
              "do not speculate about what it might be like."]

    chosen = [b for b in (benefits or []) if b]
    if chosen:
        lines += ["",
                  "THINGS A WEBSITE COULD PLAUSIBLY HELP WITH FOR THIS KIND OF "
                  "BUSINESS (use one or two, in your own words, as "
                  "possibilities):"]
        for benefit in chosen[:5]:
            lines.append(f"- {benefit}")
    else:
        lines += ["",
                  "NO CATEGORY-SPECIFIC BENEFITS WERE SUPPLIED. Keep to the "
                  "general case: somewhere to send enquiries, and a presence "
                  "that works outside opening hours."]

    lines += [
        "",
        f"WHAT THE SENDER OFFERS: {service_pitch or DEFAULT_OFFER}",
        "",
        "SIGN OFF AS:",
        f"  {sender_name}",
    ]
    if sender_company:
        lines.append(f"  {sender_company}")
    if sender_email:
        lines.append(f"  {sender_email}")
    if retry_hint:
        lines += ["", f"REVISION REQUESTED: {retry_hint}"]

    lines += ["",
              "Write the email. 70-110 words. Nothing about website problems, "
              "and no promises about results."]
    return "\n".join(lines)


def no_website_email(*, business_name: str, category: str = "", city: str = "",
                     country: str = "", phone: str = "",
                     benefits: list | None = None, sender_name: str = "",
                     sender_company: str = "", sender_email: str = "",
                     service_pitch: str = "",
                     retry_hint: str = "") -> GeneratedEmail:
    """Write one email to a business with no website. Raises AiError on failure."""
    prompt = build_no_website_prompt(
        business_name=business_name, category=category, city=city,
        country=country, phone=phone, benefits=benefits,
        sender_name=sender_name, sender_company=sender_company,
        sender_email=sender_email, service_pitch=service_pitch,
        retry_hint=retry_hint,
    )
    text = _complete(system=NO_WEBSITE_SYSTEM, prompt=prompt,
                     schema=NO_WEBSITE_SCHEMA, max_tokens=EMAIL_MAX_TOKENS)
    return parse_no_website(text)


#: Phrases that would be a guarantee rather than a possibility. Checked in code
#: as well as forbidden in the prompt, because a promise about revenue is the one
#: thing in this email that could actually mislead somebody.
GUARANTEE_PATTERNS = (
    "will increase", "will boost", "will grow", "will double", "will bring you",
    "guaranteed", "guarantee you", "we guarantee", "rank #1", "rank first",
    "top of google", "first page of google", "more customers guaranteed",
    "increase your revenue", "increase your sales", "roi of",
)


def parse_no_website(text: str) -> GeneratedEmail:
    """Validate the no-website JSON, and refuse a promise it should not make."""
    data = _load_json(text)
    subject = str(data.get("subject") or "").strip()
    body = str(data.get("body") or "").strip()
    if not subject or not body:
        raise AiError("The model returned an email with no subject or no body.")

    flat = " ".join(body.lower().split())
    for phrase in GUARANTEE_PATTERNS:
        if phrase in flat:
            raise AiError(
                f"The draft promised an outcome ({phrase!r}), which this "
                "application does not do. Regenerate it.",
                retryable=True,
            )

    used = data.get("benefits_used") or []
    if not isinstance(used, list):
        used = []

    return GeneratedEmail(
        subject=subject[:400],
        body=body,
        observation=str(data.get("observation") or "").strip() or "none",
        findings_used=[str(u).strip() for u in used if str(u).strip()],
    )


# --------------------------------------------------------------------------- #
# Follow-ups
# --------------------------------------------------------------------------- #

FOLLOWUP_SYSTEM = """\
You are writing a short follow-up email to a small business that did not reply \
to an earlier email.

You will be shown the email that was already sent, what was noticed on the \
company's website, and how long ago the first email went out.

THE RULE THAT MATTERS MOST: do not rewrite or restate the first email. The \
recipient may well read the two next to each other. A follow-up that repeats \
the original in new words is worse than no follow-up at all -- it reads as \
automated, and it spends the small amount of goodwill a second email has.

So:
- Reference the earlier message briefly and move on. One clause, not a \
paragraph.
- Add something the first email did not say: a different angle on the same \
opportunity, a sharper version of the offer, or a smaller and easier next step.
- Do NOT re-list the website issues. At most allude to the one thing the first \
email was built on, in a handful of words.
- Assume the silence is busyness, not rejection. No guilt, no "I noticed you \
have not responded", no invented deadline, no false urgency.
- Make replying trivial: one small question, or a yes/no ask.

LENGTH: 45-90 words of body text, and always shorter than the original. A \
follow-up that runs long has misunderstood what it is.

TONE: a competent person sending a brief nudge to a peer. Plain British \
English, contractions welcome, no marketing register, no exclamation marks.

NEVER:
- claim anything about the website that is not in the supplied material,
- invent a phone call, a meeting, an earlier conversation or a mutual contact,
- mention how many emails have been sent, or that this is attempt number two,
- write a new subject line: reuse the original, prefixed with "Re: ".

Return only JSON."""

FOLLOWUP_SCHEMA = {
    "type": "object",
    "properties": {
        "subject": {
            "type": "string",
            "description": (
                "The original subject prefixed with 'Re: ', otherwise "
                "unchanged. Do not add 'Re: ' twice."
            ),
        },
        "body": {
            "type": "string",
            "description": (
                "The follow-up body as plain text, 45-90 words, paragraphs "
                "separated by blank lines, closing with the sender name and "
                "company."
            ),
        },
        "angle": {
            "type": "string",
            "description": (
                "In one short phrase, what this follow-up adds that the first "
                "email did not say. Shown to the user to check it is not a "
                "repeat."
            ),
        },
    },
    "required": ["subject", "body", "angle"],
    "additionalProperties": False,
}

#: A follow-up is short by design, so it needs far less room than a first email.
FOLLOWUP_MAX_TOKENS = int(os.environ.get("OUTREACH_AI_FOLLOWUP_TOKENS", "800"))


def reply_subject(subject: str) -> str:
    """A subject with exactly one "Re: " on the front."""
    text = (subject or "").strip()
    while text[:3].casefold() == "re:":
        text = text[3:].strip()
    return f"Re: {text}" if text else "Re: following up"


def build_followup_prompt(*, business_name: str, category: str = "",
                          city: str = "", country: str = "", website: str = "",
                          sender_name: str = "", sender_company: str = "",
                          sender_email: str = "", service_pitch: str = "",
                          original_subject: str = "", original_body: str = "",
                          observation: str = "", findings: list | None = None,
                          business_summary: str = "", days_since: int = 0,
                          number: int = 1, campaign_label: str = "",
                          retry_hint: str = "") -> str:
    """Assemble the follow-up prompt from what the first email already knew."""
    lines = [
        f"BUSINESS: {business_name}",
        f"CATEGORY: {category or 'unknown'}",
        f"LOCATION: {', '.join(p for p in (city, country) if p) or 'unknown'}",
        f"WEBSITE: {website or 'none'}",
    ]
    if campaign_label:
        lines.append(f"CAMPAIGN: {campaign_label}")
    if business_summary:
        lines.append(f"WHAT THEY DO: {business_summary}")

    lines += [
        "",
        f"THIS IS FOLLOW-UP NUMBER {number}.",
        f"THE LAST EMAIL WENT OUT {days_since} DAY(S) AGO AND HAD NO REPLY.",
        "",
        "--- THE EMAIL ALREADY SENT (do not restate it) ---",
        f"Subject: {original_subject}",
        "",
        (original_body or "").strip(),
        "--- END OF THE EMAIL ALREADY SENT ---",
    ]

    if observation and observation.casefold() != "none":
        lines += ["", f"WHAT THE FIRST EMAIL WAS BUILT ON: {observation}"]

    spare = [f for f in (findings or []) if getattr(f, "issue", "")]
    if spare:
        lines += ["",
                  "OTHER VERIFIED FINDINGS, IF A DIFFERENT ANGLE HELPS "
                  "(use at most one, in a few words):"]
        for finding in spare[:4]:
            lines.append(f"- {finding.issue} -- {finding.evidence}")
    else:
        lines += ["",
                  "NO WEBSITE FINDINGS ARE AVAILABLE. Do not imply the website "
                  "was examined; follow up on the offer alone."]

    lines += [
        "",
        f"WHAT THE SENDER OFFERS: {service_pitch or DEFAULT_OFFER}",
        "",
        "SIGN OFF AS:",
        f"  {sender_name}",
    ]
    if sender_company:
        lines.append(f"  {sender_company}")
    if sender_email:
        lines.append(f"  {sender_email}")
    if retry_hint:
        lines += ["", f"REVISION REQUESTED: {retry_hint}"]

    lines += ["",
              "Write the follow-up. Under 90 words. Do not repeat the first "
              "email."]
    return "\n".join(lines)


def follow_up(*, business_name: str, category: str = "", city: str = "",
              country: str = "", website: str = "", sender_name: str = "",
              sender_company: str = "", sender_email: str = "",
              service_pitch: str = "", original_subject: str = "",
              original_body: str = "", observation: str = "",
              findings: list | None = None, business_summary: str = "",
              days_since: int = 0, number: int = 1, campaign_label: str = "",
              retry_hint: str = "") -> GeneratedEmail:
    """Write one follow-up email. Raises AiError on failure."""
    prompt = build_followup_prompt(
        business_name=business_name, category=category, city=city,
        country=country, website=website, sender_name=sender_name,
        sender_company=sender_company, sender_email=sender_email,
        service_pitch=service_pitch, original_subject=original_subject,
        original_body=original_body, observation=observation,
        findings=findings, business_summary=business_summary,
        days_since=days_since, number=number, campaign_label=campaign_label,
        retry_hint=retry_hint,
    )
    text = _complete(system=FOLLOWUP_SYSTEM, prompt=prompt,
                     schema=FOLLOWUP_SCHEMA, max_tokens=FOLLOWUP_MAX_TOKENS)
    return parse_followup(text, original_subject=original_subject)


def parse_followup(text: str, *, original_subject: str = "") -> GeneratedEmail:
    """Validate the follow-up JSON.

    The subject is rebuilt here rather than trusted. Models add "Re:" twice, drop
    it, or quietly rewrite the line -- and a follow-up that does not thread under
    the original defeats the point of sending one.
    """
    data = _load_json(text)
    body = str(data.get("body") or "").strip()
    if not body:
        raise AiError("The model returned a follow-up with no body.")

    # The original wins over a model that decided to write its own subject.
    base = original_subject or str(data.get("subject") or "").strip()

    return GeneratedEmail(
        subject=reply_subject(base)[:400],
        body=body,
        observation=str(data.get("angle") or "").strip() or "follow-up",
        findings_used=[],
    )


def parse_audit(text: str) -> SiteAudit:
    """Validate the review JSON, then drop findings with no evidence.

    The evidence rule is enforced here as well as in the prompt: a finding with
    an empty evidence field is exactly the speculation the prompt forbids, so it
    is discarded rather than shown to the user as if it were verified.
    """
    data = _load_json(text)
    audit_result = SiteAudit.from_dict(data)

    kept = [
        f for f in audit_result.findings
        if f.issue and f.evidence and f.why_it_matters
    ]
    kept.sort(key=lambda f: f.rank)
    audit_result.findings = kept[:MAX_FINDINGS]

    if not audit_result.findings:
        raise AiError(
            "The review produced no findings backed by evidence. The crawled "
            "pages may have been too thin to assess."
        )
    return audit_result
