/* Setup page: lead selection + sender settings, then start the pipeline. */
(function () {
  "use strict";

  var script = document.currentScript;
  var RUN_URL = script.dataset.runUrl;

  var form = document.getElementById("setup-form");
  var submitBtn = document.getElementById("setup-submit");
  var statusEl = document.getElementById("setup-status");
  var countEl = document.getElementById("selected-count");
  var checkAll = document.getElementById("check-all");
  var providerSelect = document.getElementById("provider");
  var providerNote = document.getElementById("provider-note");

  var notes = JSON.parse(document.getElementById("provider-notes").textContent);

  function checks() {
    return Array.prototype.slice.call(document.querySelectorAll(".lead-check"));
  }

  function selected() {
    return checks().filter(function (c) { return c.checked; });
  }

  function refresh() {
    var n = selected().length;
    countEl.textContent = n;
    submitBtn.disabled = n === 0;
    if (checkAll) {
      checkAll.checked = n === checks().length && n > 0;
      checkAll.indeterminate = n > 0 && n < checks().length;
    }
  }

  function setStatus(message, kind) {
    kind = kind || "info";
    var iconName = { info: "i-info", ok: "i-check-circle", warn: "i-alert",
                     err: "i-x-circle" }[kind];
    statusEl.className = "banner banner-" + kind;
    statusEl.style.flex = "1";
    statusEl.style.minWidth = "260px";
    statusEl.innerHTML = LMUI.iconMarkup(iconName) + "<span>" + message + "</span>";
  }

  function showProviderNote() {
    providerNote.textContent = notes[providerSelect.value] || "";
  }

  /* --- wiring ---------------------------------------------------------- */

  checks().forEach(function (box) {
    box.addEventListener("change", refresh);
  });

  if (checkAll) {
    checkAll.addEventListener("change", function () {
      checks().forEach(function (box) { box.checked = checkAll.checked; });
      refresh();
    });
  }

  providerSelect.addEventListener("change", showProviderNote);

  // Row filters over the selection table.
  var rowFilters = document.getElementById("row-filters");
  if (rowFilters) {
    rowFilters.addEventListener("click", function (event) {
      var chip = event.target.closest(".chip");
      if (!chip) return;
      var want = chip.dataset.rf;
      Array.prototype.forEach.call(this.children, function (other) {
        other.classList.toggle("is-active", other === chip);
      });
      var rows = document.querySelectorAll(".table tbody tr[data-state]");
      Array.prototype.forEach.call(rows, function (row) {
        row.classList.toggle("is-hidden",
                             want !== "all" && row.dataset.state !== want);
      });
    });
  }

  form.addEventListener("submit", function (event) {
    event.preventDefault();

    var payload = {
      sender_name: document.getElementById("sender_name").value.trim(),
      sender_email: document.getElementById("sender_email").value.trim(),
      sender_company: document.getElementById("sender_company").value.trim(),
      provider: providerSelect.value,
      service_pitch: document.getElementById("service_pitch").value.trim(),
      selected: selected().map(function (c) { return c.value; }),
    };

    if (!payload.sender_name) {
      setStatus("Enter the sender name.", "err");
      LMUI.warn("Sender name required");
      document.getElementById("sender_name").focus();
      return;
    }
    if (!payload.sender_email) {
      setStatus("Enter the sender email address.", "err");
      LMUI.warn("Sender email required");
      document.getElementById("sender_email").focus();
      return;
    }
    if (payload.service_pitch.length < 20) {
      setStatus(
        "Describe what you offer in a sentence or two — the AI needs it to " +
        "explain how you can help each business.", "err"
      );
      LMUI.warn("Describe your offer",
                "The AI needs it to connect a finding to what you sell.");
      document.getElementById("service_pitch").focus();
      return;
    }

    LMUI.loading(submitBtn, true, "Starting…");
    setStatus("Discovering pages and starting the crawl…", "info");

    LMUI.postJson(RUN_URL, payload)
      .then(function (data) {
        LMUI.ok("Campaign started", data.queued + " site(s) queued for review");
        window.location.href = data.workspace_url;
      })
      .catch(function (error) {
        setStatus(error.message, "err");
        LMUI.error("Could not start", error.message);
        LMUI.loading(submitBtn, false);
      });
  });

  showProviderNote();
  refresh();
})();
