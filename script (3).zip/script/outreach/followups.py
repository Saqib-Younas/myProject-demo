"""
Follow-up eligibility, timing, limits, and the check that runs before SMTP.

Nothing in here sends anything, and nothing schedules a send. A follow-up exists
only because somebody clicked Create Follow-Up, and it goes out only because
somebody then clicked Send Follow-Up. The waiting period makes a follow-up
*available*; it never makes one happen.

Eligibility is computed rather than stored. A lead's state changes underneath it
-- a reply arrives, an address is suppressed, another follow-up is sent -- and a
stored flag would be stale exactly when it matters. `eligibility()` is therefore
the single answer to "may this lead be followed up, and if not, why not", used by
the list view, the create endpoint and the pre-send check alike.

The pre-send check is the one that counts. It re-asks every question immediately
before the connection opens, because the reason a follow-up must be blocked --
a reply that arrived while the draft sat in review -- is precisely the kind of
thing that changes between generating and sending.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta

from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from django.db.models import Count, Max
from django.utils import timezone

from . import history
from .models import NO_FOLLOW_UP_STATES, Campaign, FollowUp, ReplyState, SentLead

#: Reasons a follow-up is unavailable, in the order they are checked. The order
#: is the point: the strongest, most permanent reason is the one reported.
REASONS = {
    "replied": "The lead replied — a follow-up is not required.",
    "bounced": "The address bounced, so a follow-up would not arrive.",
    "unsubscribed": "The lead asked not to be contacted again.",
    "suppressed": "This address is on the do-not-contact list.",
    "invalid": "This address is not a valid email address.",
    "not_sent": "The initial email has not been delivered yet.",
    "limit": "Follow-up limit reached.",
    "waiting": "Waiting for the follow-up period to pass.",
    "drafted": "A follow-up is already drafted and waiting for review.",
    "sending": "A follow-up to this lead is being sent right now.",
}


def max_followups() -> int:
    return max(0, int(getattr(settings, "OUTREACH_FOLLOWUP_MAX", 2)))


def delay_days(number: int) -> int:
    """Days to wait before follow-up `number` becomes available.

    A shorter configured list than the maximum reuses its final value, so
    OUTREACH_FOLLOWUP_DELAYS=3 with a maximum of 2 means "3 days, then 3 days".
    """
    delays = list(getattr(settings, "OUTREACH_FOLLOWUP_DELAYS", [3, 7])) or [3]
    index = max(1, number) - 1
    return int(delays[index] if index < len(delays) else delays[-1])


@dataclass(frozen=True)
class Eligibility:
    """Whether a lead may be followed up, and the whole story either way."""

    lead_id: int
    eligible: bool
    reason: str = ""                 # key into REASONS, "" when eligible
    next_number: int = 0             # the follow-up that would be created
    sent_count: int = 0              # follow-ups already sent
    last_contact_at: object = None   # most recent message to this lead
    eligible_at: object = None       # when the wait ends
    reply_state: str = ReplyState.NO_REPLY

    @property
    def label(self) -> str:
        return REASONS.get(self.reason, "") if not self.eligible else ""

    @property
    def waiting(self) -> bool:
        return self.reason == "waiting"

    @property
    def days_until(self) -> int:
        """Whole days until eligibility, rounded up. 0 once available."""
        if self.eligible or not self.eligible_at:
            return 0
        remaining = self.eligible_at - timezone.now()
        if remaining.total_seconds() <= 0:
            return 0
        return max(1, -(-remaining.days if remaining.seconds == 0
                        else remaining.days + 1))

    def as_dict(self) -> dict:
        return {
            "lead_id": self.lead_id,
            "eligible": self.eligible,
            "reason": self.reason,
            "label": self.label,
            "next_number": self.next_number,
            "sent_count": self.sent_count,
            "reply_state": self.reply_state,
            "last_contact_at": (self.last_contact_at.isoformat()
                                if self.last_contact_at else None),
            "eligible_at": (self.eligible_at.isoformat()
                            if self.eligible_at else None),
            "days_until": self.days_until,
            "waiting": self.waiting,
        }


def _valid(email: str) -> bool:
    try:
        validate_email(email)
    except ValidationError:
        return False
    return True


def eligibility(lead: SentLead, *, blocklist=None,
                followups: list[FollowUp] | None = None) -> Eligibility:
    """May this lead be followed up? Pass `blocklist`/`followups` for a batch.

    Both arguments exist so a list of 200 leads is not 400 extra queries; the
    answer is identical either way.
    """
    if followups is None:
        followups = list(lead.followups.all())
    live = [f for f in followups if f.is_live]
    sent = [f for f in live if f.status == FollowUp.Status.SENT]
    drafted = [f for f in live if f.status == FollowUp.Status.DRAFT]
    sending = [f for f in live if f.status == FollowUp.Status.SENDING]

    last_contact = lead.sent_at or lead.reserved_at
    for followup in sent:
        if followup.sent_at and (last_contact is None
                                 or followup.sent_at > last_contact):
            last_contact = followup.sent_at

    next_number = len(sent) + 1
    wait = timedelta(days=delay_days(next_number))
    eligible_at = (last_contact + wait) if last_contact else None

    common = {
        "lead_id": lead.pk,
        "next_number": next_number,
        "sent_count": len(sent),
        "last_contact_at": last_contact,
        "eligible_at": eligible_at,
        "reply_state": lead.reply_state,
    }

    def no(reason: str) -> Eligibility:
        return Eligibility(eligible=False, reason=reason, **common)

    # Strongest reasons first: these are about the lead, not about timing.
    if lead.reply_state in NO_FOLLOW_UP_STATES:
        return no(str(lead.reply_state))
    if lead.status != SentLead.Status.SENT:
        return no("not_sent")
    if not lead.email or not _valid(lead.email):
        return no("invalid")

    if blocklist is None:
        blocklist = history.SuppressionIndex(lead.owner)
    if blocklist.match(email=lead.email, website=lead.website):
        return no("suppressed")

    if sending:
        return no("sending")
    if drafted:
        return no("drafted")
    if len(sent) >= max_followups():
        return no("limit")
    if eligible_at and timezone.now() < eligible_at:
        return no("waiting")

    return Eligibility(eligible=True, **common)


# --------------------------------------------------------------------------- #
# The pre-send check
# --------------------------------------------------------------------------- #

class Blocked(Exception):
    """This follow-up must not be sent. Carries the reason to show the user."""


def check_before_send(followup: FollowUp) -> SentLead:
    """Re-ask every question immediately before SMTP. Raises Blocked.

    Deliberately re-reads the lead rather than trusting the object in hand: the
    whole point is to catch what changed while the draft sat in review.

    The numbered checks are the ones the brief asks for:
      1. did the recipient reply since the draft was generated?
      2. is the recipient suppressed or unsubscribed?
      3. has this follow-up already been sent?
      4. has the limit been reached?
      5. is the address still valid?
      6. is another process already sending to this lead?
    """
    lead = SentLead.objects.get(pk=followup.lead_id)

    # 3, first: a row that has already gone out must never go out twice, whatever
    # else is true. Checked before the rest so the message is the accurate one.
    if followup.status == FollowUp.Status.SENT:
        raise Blocked("This follow-up has already been sent.")
    if followup.status == FollowUp.Status.CANCELLED:
        raise Blocked("This follow-up was cancelled.")

    # 1, 2, 4, 5, 6 -- and the address check, all from one fresh answer.
    verdict = eligibility(
        lead,
        followups=[f for f in lead.followups.all() if f.pk != followup.pk],
    )
    if not verdict.eligible and verdict.reason not in ("waiting", "drafted"):
        # `waiting` cannot block a send: the user already waited long enough to
        # create the draft, and re-imposing the delay would strand it. `drafted`
        # is this row itself, filtered out above.
        raise Blocked(REASONS[verdict.reason])

    if followup.email.strip().casefold() != lead.email.strip().casefold():
        raise Blocked(
            "The recipient address has changed since this follow-up was written."
        )
    return lead


def claim(followup: FollowUp) -> bool:
    """Move one follow-up draft -> sending, atomically.

    The conditional UPDATE is what stops a double-clicked Send Follow-Up: only
    one caller can observe the row as `draft` and change it.
    """
    return FollowUp.objects.filter(
        pk=followup.pk, status=FollowUp.Status.DRAFT,
    ).update(status=FollowUp.Status.SENDING) == 1


def release(followup: FollowUp) -> None:
    FollowUp.objects.filter(
        pk=followup.pk, status=FollowUp.Status.SENDING,
    ).update(status=FollowUp.Status.DRAFT)


# --------------------------------------------------------------------------- #
# Listing and statistics
# --------------------------------------------------------------------------- #

#: The filters the follow-up screen offers, and what each one keeps.
FILTER_LABELS = (
    ("all", "All"),
    ("replied", "Replied"),
    ("no_reply", "No reply"),
    ("ready", "Follow-up ready"),
    ("waiting", "Waiting"),
    ("followed_up", "Follow-up sent"),
    ("bounced", "Bounced"),
    ("unsubscribed", "Unsubscribed"),
)
FILTERS = tuple(key for key, _label in FILTER_LABELS)


def rows(owner, *, campaign: Campaign | None = None,
         only: str = "all") -> list[dict]:
    """One user's sent leads, with reply state and follow-up eligibility."""
    if owner is None or not getattr(owner, "pk", None):
        return []

    query = (
        SentLead.objects.filter(owner=owner, status=SentLead.Status.SENT)
        .prefetch_related("followups").select_related("campaign")
        .order_by("-sent_at", "-reserved_at")
    )
    if campaign is not None:
        query = query.filter(campaign=campaign)

    blocklist = history.SuppressionIndex(owner)
    out = []
    for lead in query:
        followups = list(lead.followups.all())
        verdict = eligibility(lead, blocklist=blocklist, followups=followups)
        live = [f for f in followups if f.is_live]
        draft = next((f for f in live if f.status == FollowUp.Status.DRAFT), None)

        if not _keep(only, lead, verdict, live):
            continue

        out.append({
            "lead": lead,
            "eligibility": verdict,
            "followups": sorted(live, key=lambda f: f.number),
            "draft": draft,
            "sent_followups": [f for f in live
                               if f.status == FollowUp.Status.SENT],
        })
    return out


def _keep(only: str, lead: SentLead, verdict: Eligibility,
          live: list[FollowUp]) -> bool:
    if only in ("", "all"):
        return True
    if only == "replied":
        return lead.reply_state == ReplyState.REPLIED
    if only == "bounced":
        return lead.reply_state == ReplyState.BOUNCED
    if only == "unsubscribed":
        return lead.reply_state == ReplyState.UNSUBSCRIBED
    if only == "no_reply":
        return lead.reply_state == ReplyState.NO_REPLY
    if only == "ready":
        return verdict.eligible
    if only == "waiting":
        return verdict.waiting
    if only == "followed_up":
        return any(f.status == FollowUp.Status.SENT for f in live)
    return True


def stats(owner, campaign: Campaign | None = None) -> dict:
    """One user's dashboard figures, in as few queries as the answer allows."""
    if owner is None or not getattr(owner, "pk", None):
        leads = SentLead.objects.none()
    else:
        leads = SentLead.objects.filter(owner=owner, status=SentLead.Status.SENT)
    if campaign is not None:
        leads = leads.filter(campaign=campaign)

    by_state = {
        row["reply_state"]: row["n"]
        for row in leads.values("reply_state").annotate(n=Count("id"))
    }
    sent = sum(by_state.values())

    followups = FollowUp.objects.filter(lead__in=leads)
    followup_sent = followups.filter(status=FollowUp.Status.SENT).count()
    drafted = followups.filter(status=FollowUp.Status.DRAFT).count()

    # "Ready" is the one figure that cannot be a single query: it depends on the
    # suppression list, the per-number delay and the limit. Counted from the same
    # rule the buttons use, so the number and the buttons can never disagree.
    ready = sum(1 for row in rows(owner, campaign=campaign, only="ready"))
    waiting = sum(1 for row in rows(owner, campaign=campaign, only="waiting"))

    return {
        "sent": sent,
        "replied": by_state.get(ReplyState.REPLIED, 0),
        "no_reply": by_state.get(ReplyState.NO_REPLY, 0),
        "bounced": by_state.get(ReplyState.BOUNCED, 0),
        "unsubscribed": by_state.get(ReplyState.UNSUBSCRIBED, 0),
        "ready": ready,
        "waiting": waiting,
        "followup_sent": followup_sent,
        "followup_drafted": drafted,
        "max_followups": max_followups(),
        "delays": list(getattr(settings, "OUTREACH_FOLLOWUP_DELAYS", [3, 7])),
        "last_checked": leads.aggregate(when=Max("checked_at"))["when"],
    }
