"""
Sends approved emails over the user's own authenticated SMTP account.

Three rules the brief sets, and how they are kept:

  * "Use the user's own authenticated account" -- the campaign's sender email is
    the SMTP login. Nothing is relayed through a third party.
  * "Do not spoof sender addresses" -- the From header is built from the
    authenticated address and cannot be set to anything else. A mismatch is a
    hard error, not a warning.
  * "Rate limits/delays according to the provider" -- each provider carries a
    per-message delay and a daily cap, and the cap counts what this sender has
    already sent today across every campaign.

The password is never stored. It is passed in when a send starts and lives only
in the sending thread's memory.
"""

from __future__ import annotations

import re
import smtplib
import ssl
from dataclasses import dataclass
from email.message import EmailMessage
from email.utils import formataddr, formatdate, make_msgid


@dataclass(frozen=True)
class Provider:
    key: str
    label: str
    host: str
    port: int
    delay: float          # seconds to wait between messages
    daily_cap: int        # conservative per-day ceiling for one account
    note: str
    #: Where to read replies for this provider. Same account, same password --
    #: reply tracking never needs a second credential.
    imap_host: str = ""
    imap_port: int = 993


#: Delays and caps are deliberately below each provider's published ceiling.
PROVIDERS: dict[str, Provider] = {
    "gmail": Provider(
        "gmail", "Gmail / Google Workspace", "smtp.gmail.com", 587,
        delay=2.5, daily_cap=400,
        note="Needs an App Password (Google blocks plain passwords on SMTP). "
             "Free Gmail allows ~500/day, Workspace ~2000; capped at 400 here.",
        imap_host="imap.gmail.com",
    ),
    "outlook": Provider(
        "outlook", "Outlook / Microsoft 365", "smtp.office365.com", 587,
        delay=3.5, daily_cap=250,
        note="Microsoft 365 throttles at ~30 recipients/minute and 10,000/day; "
             "capped at 250 here. Basic auth may need an app password.",
        imap_host="outlook.office365.com",
    ),
    "zoho": Provider(
        "zoho", "Zoho Mail", "smtp.zoho.com", 587,
        delay=3.0, daily_cap=200,
        note="Zoho's per-day limit depends on plan; capped at 200 here.",
        imap_host="imap.zoho.com",
    ),
    "fastmail": Provider(
        "fastmail", "Fastmail", "smtp.fastmail.com", 587,
        delay=2.5, daily_cap=300,
        note="Requires an app password.",
        imap_host="imap.fastmail.com",
    ),
    "custom": Provider(
        "custom", "Other SMTP server", "", 587,
        delay=3.0, daily_cap=200,
        note="Set OUTREACH_SMTP_HOST and OUTREACH_SMTP_PORT for your server.",
        imap_host="",
    ),
}

DEFAULT_PROVIDER = "gmail"


class SendError(RuntimeError):
    """A failure that stops the whole run (auth, connection, configuration)."""


#: A Gmail App Password as Google displays it: four groups of four letters.
_APP_PASSWORD = re.compile(r"^[a-z]{4}(?:\s[a-z]{4}){3}$", re.IGNORECASE)


def normalise_password(password: str) -> str:
    """Trim a pasted password, and de-space a Gmail App Password.

    Google shows app passwords as `abcd efgh ijkl mnop` but expects the 16
    characters with no spaces, so a straight copy-paste would otherwise fail to
    authenticate. Only that exact shape is de-spaced -- a real password that
    happens to contain a space is left alone.
    """
    password = (password or "").strip()
    if _APP_PASSWORD.match(password):
        return password.replace(" ", "")
    return password


def provider_for(key: str) -> Provider:
    try:
        return PROVIDERS[key]
    except KeyError:
        raise SendError(f"Unknown email provider {key!r}.") from None


def resolve_host(provider: Provider, host: str = "", port: int = 0) -> tuple[str, int]:
    """Custom providers need an explicit host; presets carry their own."""
    host = (host or provider.host).strip()
    port = int(port or provider.port)
    if not host:
        raise SendError(
            "This provider needs an SMTP host. Set OUTREACH_SMTP_HOST (and "
            "OUTREACH_SMTP_PORT) or pick a preset provider."
        )
    return host, port


#: Appended to every outgoing email. Kept here rather than in the AI prompt so
#: it cannot be dropped by a model, an edit or a regeneration -- and so there is
#: one place to change the wording.
REPLY_LINE = ("If you're interested, simply reply to this email and our team "
              "will get back to you within 24 hours.")


def _flat(value: str) -> str:
    """Whitespace-insensitive, case-insensitive form, for containment checks."""
    return " ".join((value or "").split()).casefold()


def with_reply_line(body: str) -> str:
    """Append the standing reply invitation, exactly once.

    Idempotent on purpose: a user who moves the line into the middle of the body
    while editing keeps it where they put it instead of getting a second copy at
    the end. The comparison ignores wrapping and case, so a re-flowed copy still
    counts as present.
    """
    text = (body or "").rstrip()
    if _flat(REPLY_LINE) in _flat(text):
        return text + "\n"
    if not text:
        return REPLY_LINE + "\n"
    return f"{text}\n\n{REPLY_LINE}\n"


def build_message(*, sender_name: str, sender_email: str, to_email: str,
                  subject: str, body: str) -> EmailMessage:
    """Build one plain-text message from the authenticated identity.

    From is always the authenticated address -- there is no parameter that
    would let a caller put someone else's address in it.

    This is the single funnel every outgoing email passes through, which is why
    the reply invitation is added here.
    """
    message = EmailMessage()
    message["From"] = formataddr((sender_name or sender_email, sender_email))
    message["To"] = to_email
    message["Subject"] = subject
    message["Date"] = formatdate(localtime=True)
    message["Message-ID"] = make_msgid(domain=sender_email.split("@")[-1])
    # Cold outreach should always offer a way out.
    message["List-Unsubscribe"] = f"<mailto:{sender_email}?subject=unsubscribe>"
    message["Auto-Submitted"] = "auto-generated"
    message.set_content(with_reply_line(body))
    return message


class Session:
    """An authenticated SMTP connection for one send run."""

    def __init__(self, provider: Provider, sender_email: str, password: str,
                 host: str = "", port: int = 0, username: str = ""):
        self.provider = provider
        self.sender_email = sender_email.strip()
        self.username = (username or self.sender_email).strip()
        self.password = normalise_password(password)
        self.host, self.port = resolve_host(provider, host, port)
        self.smtp: smtplib.SMTP | None = None

        if not self.sender_email:
            raise SendError("A sender email address is required.")
        if not self.password:
            raise SendError(
                "No SMTP password supplied. Enter it when starting the send, or "
                "set OUTREACH_SMTP_PASSWORD in the environment."
            )
        # The anti-spoofing rule: the visible sender is the logged-in account.
        if self.username.casefold() != self.sender_email.casefold():
            raise SendError(
                f"The sender address ({self.sender_email}) must be the same as "
                f"the SMTP login ({self.username}). Sending as an address you "
                "have not authenticated is spoofing and is not supported."
            )

    def __enter__(self) -> "Session":
        # Refuse to reach the network when sending is blocked (default under
        # `manage.py test`). Real credentials are on disk, so this is the line
        # between a failing test and mail leaving the building.
        from django.conf import settings as django_settings

        if getattr(django_settings, "OUTREACH_BLOCK_SEND", False):
            raise SendError(
                "Sending is blocked in this environment (OUTREACH_BLOCK_SEND). "
                "No SMTP connection was opened."
            )

        try:
            if self.port == 465:
                self.smtp = smtplib.SMTP_SSL(
                    self.host, self.port, timeout=30,
                    context=ssl.create_default_context(),
                )
            else:
                self.smtp = smtplib.SMTP(self.host, self.port, timeout=30)
                self.smtp.ehlo()
                self.smtp.starttls(context=ssl.create_default_context())
                self.smtp.ehlo()
            self.smtp.login(self.username, self.password)
        except smtplib.SMTPAuthenticationError as exc:
            raise SendError(
                f"{self.provider.label} rejected the login for "
                f"{self.username}. {self.provider.note}"
            ) from exc
        except (smtplib.SMTPException, OSError) as exc:
            raise SendError(
                f"Could not connect to {self.host}:{self.port} -- {exc}"
            ) from exc
        return self

    def __exit__(self, *exc_info) -> None:
        if self.smtp is not None:
            try:
                self.smtp.quit()
            except smtplib.SMTPException:
                pass
            self.smtp = None

    def send(self, *, to_email: str, subject: str, body: str,
             sender_name: str) -> str:
        """Send one message and return its Message-ID.

        The Message-ID is what a reply quotes in In-Reply-To/References, so it is
        the only reliable way to tie an incoming email back to the one we sent.
        Storing it is what makes reply tracking work on more than a guess.
        """
        if self.smtp is None:
            raise SendError("SMTP session is not open.")
        message = build_message(
            sender_name=sender_name, sender_email=self.sender_email,
            to_email=to_email, subject=subject, body=body,
        )
        self.smtp.send_message(message)
        return message["Message-ID"] or ""
