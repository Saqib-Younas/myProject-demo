"""
The AI credential pool: resolution, ownership, switching and secrecy.

The cases that matter are the ones where a credential must NOT be used or must
NOT be visible:

  * the ACTIVE child must beat `.env`, and deactivating it must fall back rather
    than break;
  * exactly one child per provider per account may be active, enforced by the
    database and not only by the code that writes it;
  * one account must never see, use or delete another's key -- and a caller with
    no account at all must reach the environment only, never "whichever row it
    can find";
  * a rotated SECRET_KEY must degrade instead of crash;
  * no response, page, log line or audit row may ever contain a key.

Every test runs with the real environment cleared, so a developer's `.env` cannot
make a test pass or fail by accident, and OUTREACH_BLOCK_SEND is on under
`manage.py test`, so nothing here reaches a provider.
"""

from __future__ import annotations

import os
from unittest import mock

from django.db import IntegrityError, transaction
from django.test import TestCase, override_settings
from django.urls import reverse

from . import ai, aicontext, credentials
from .models import AiSelection, CredentialEvent, ProviderCredential
from .testsupport import OtherUser, SignedIn, make_user

#: Every variable the resolver reads, blanked for the duration of a test. A real
#: key in the developer's environment would otherwise silently satisfy tests that
#: are supposed to be checking the "not configured" path.
ENV_KEYS = tuple(
    name for provider_spec in credentials.SPECS.values()
    for name in provider_spec.env_vars
) + ("OUTREACH_AI_PROVIDER", "OUTREACH_AI_MODEL", "ANTHROPIC_PROFILE",
     "ANTHROPIC_CONFIG_DIR", "OUTREACH_CREDENTIALS_UI")


def clean_env(**overrides):
    """Patch os.environ down to just what a test asks for."""
    values = {name: "" for name in ENV_KEYS}
    values.update(overrides)
    keep = {k: v for k, v in os.environ.items() if k not in ENV_KEYS}
    keep.update({k: v for k, v in values.items() if v})
    return mock.patch.dict(os.environ, keep, clear=True)


class MaskTests(SignedIn):
    """The masked hint is the only form of a key the UI ever sees."""

    def test_the_prefix_and_last_four_survive(self):
        self.assertEqual(credentials.mask("sk-ant-api03-abcdefghXYZW"),
                         "sk-ant-" + "•" * 8 + "XYZW")

    def test_the_middle_is_never_included(self):
        masked = credentials.mask("gsk_abcdefghijklmnop1234")

        self.assertNotIn("abcdefgh", masked)
        self.assertNotIn("ijklmnop", masked)
        self.assertTrue(masked.endswith("1234"))

    def test_a_short_value_is_masked_completely(self):
        self.assertEqual(credentials.mask("secret"), "••••••")

    def test_nothing_masks_to_nothing(self):
        self.assertEqual(credentials.mask(""), "")
        self.assertEqual(credentials.mask(None), "")


class EncryptionTests(SignedIn):
    def test_a_credential_round_trips(self):
        token = credentials.encrypt("sk-test-abcdefghijkl")

        self.assertEqual(credentials.decrypt(token), "sk-test-abcdefghijkl")

    def test_the_ciphertext_does_not_contain_the_key(self):
        token = credentials.encrypt("sk-test-abcdefghijkl")

        self.assertNotIn("sk-test", token)
        self.assertNotIn("abcdefghijkl", token)

    def test_the_same_key_encrypts_differently_each_time(self):
        """Fernet includes a nonce, so identical keys are not identical rows."""
        self.assertNotEqual(credentials.encrypt("same-key"),
                            credentials.encrypt("same-key"))

    def test_an_empty_value_is_refused(self):
        with self.assertRaises(credentials.CredentialError):
            credentials.encrypt("   ")

    def test_a_value_from_another_secret_key_does_not_decrypt(self):
        token = credentials.encrypt("sk-test-abcdefghijkl")

        with override_settings(SECRET_KEY="a-totally-different-secret"):
            self.assertEqual(credentials.decrypt(token), "")

    def test_garbage_decrypts_to_nothing_rather_than_raising(self):
        self.assertEqual(credentials.decrypt("not-a-fernet-token"), "")


class PoolShapeTests(SignedIn):
    """Providers are parents; credentials are children of an account."""

    def test_a_credential_belongs_to_an_account(self):
        """The field this whole feature turns on.

        This test replaces the one that asserted `ProviderCredential` had *no*
        owner, whose comment said it should be the first to fail when
        credentials became per-user. It did.
        """
        field = ProviderCredential._meta.get_field("owner")

        self.assertTrue(field.is_relation)
        self.assertEqual(field.related_model, type(self.user))

    def test_several_credentials_can_share_one_provider(self):
        with clean_env():
            credentials.add(self.user, "openai", "sk-one-1111", label="Production")
            credentials.add(self.user, "openai", "sk-two-2222", label="Backup")

        self.assertEqual(credentials.children("openai", self.user).count(), 2)

    def test_the_first_credential_is_activated_automatically(self):
        with clean_env():
            row = credentials.add(self.user, "openai", "sk-one-1111")

        self.assertTrue(row.is_active)

    def test_a_second_credential_does_not_take_over_by_itself(self):
        """Adding a spare must not silently redirect every request onto it."""
        with clean_env():
            first = credentials.add(self.user, "openai", "sk-one-1111",
                                    label="Production")
            second = credentials.add(self.user, "openai", "sk-two-2222",
                                     label="Backup")

        self.assertTrue(ProviderCredential.objects.get(pk=first.pk).is_active)
        self.assertFalse(ProviderCredential.objects.get(pk=second.pk).is_active)

    def test_a_second_credential_can_be_activated_on_the_way_in(self):
        with clean_env():
            credentials.add(self.user, "openai", "sk-one-1111", label="Production")
            second = credentials.add(self.user, "openai", "sk-two-2222",
                                     label="Backup", activate=True)

        self.assertTrue(ProviderCredential.objects.get(pk=second.pk).is_active)
        self.assertEqual(
            credentials.children("openai", self.user).filter(
                is_active=True).count(), 1)

    def test_an_unnamed_credential_gets_the_next_number(self):
        with clean_env():
            first = credentials.add(self.user, "groq", "gsk_one_1111")
            second = credentials.add(self.user, "groq", "gsk_two_2222")

        self.assertEqual(first.label, "Credential 1")
        self.assertEqual(second.label, "Credential 2")

    def test_a_duplicate_label_is_refused(self):
        with clean_env():
            credentials.add(self.user, "groq", "gsk_one_1111", label="Production")
            with self.assertRaises(credentials.CredentialConflict):
                credentials.add(self.user, "groq", "gsk_two_2222",
                                label="production")

        self.assertEqual(credentials.children("groq", self.user).count(), 1)

    def test_the_same_label_under_two_providers_is_fine(self):
        with clean_env():
            credentials.add(self.user, "groq", "gsk_one_1111", label="Production")
            credentials.add(self.user, "openai", "sk-one-1111", label="Production")

        self.assertEqual(
            ProviderCredential.objects.filter(owner=self.user,
                                              label="Production").count(), 2)

    def test_a_credential_stores_ciphertext_and_a_masked_hint(self):
        with clean_env():
            row = credentials.add(self.user, "groq", "gsk_abcdefghijkl1234")

        row.refresh_from_db()
        self.assertNotIn("gsk_abcdefghijkl1234", row.secret)
        self.assertNotIn("abcdefghijkl", row.hint)
        self.assertTrue(row.hint.endswith("1234"))

    def test_the_string_form_does_not_contain_the_key(self):
        """A stray repr in a log or traceback must not leak a credential."""
        with clean_env():
            row = credentials.add(self.user, "groq", "gsk_abcdefghijkl1234")

        self.assertNotIn("gsk_abcdefghijkl1234", str(row))

    def test_only_declared_extras_are_stored(self):
        with clean_env():
            row = credentials.add(self.user, "openai", "sk-key-1234", extras={
                "organization": "org-9", "api_key": "sneaky", "nonsense": "x"})

        self.assertEqual(row.extras, {"organization": "org-9"})

    def test_an_empty_key_is_refused_before_anything_is_written(self):
        with clean_env():
            with self.assertRaises(credentials.CredentialError):
                credentials.add(self.user, "groq", "   ")

        self.assertEqual(ProviderCredential.objects.count(), 0)

    def test_a_credential_without_an_account_is_refused(self):
        with clean_env():
            with self.assertRaises(credentials.CredentialError):
                credentials.add(None, "groq", "gsk_key_1234")

        self.assertEqual(ProviderCredential.objects.count(), 0)

    def test_two_active_credentials_cannot_exist_in_the_database(self):
        """The only hard guarantee: a constraint, not a code path.

        Two tabs both pressing Activate would otherwise leave a provider with
        two active keys and no way to say which one requests use.
        """
        with clean_env():
            credentials.add(self.user, "groq", "gsk_one_1111", label="A")
            spare = credentials.add(self.user, "groq", "gsk_two_2222", label="B")

        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                ProviderCredential.objects.filter(pk=spare.pk).update(
                    is_active=True)


class ActivationTests(SignedIn):
    """Switching the active credential, and what that does and does not change."""

    def setUp(self):
        with clean_env():
            self.live = credentials.add(self.user, "groq", "gsk_live_1111",
                                        label="Production")
            self.spare = credentials.add(self.user, "groq", "gsk_spare_2222",
                                         label="Backup")

    def test_activating_a_spare_stands_the_previous_one_down(self):
        with clean_env():
            credentials.activate(self.user, self.spare)

        self.assertFalse(ProviderCredential.objects.get(pk=self.live.pk).is_active)
        self.assertTrue(ProviderCredential.objects.get(pk=self.spare.pk).is_active)

    def test_every_ai_request_follows_the_active_credential(self):
        """The promise of the feature: one switch, no other change anywhere."""
        with clean_env():
            self.assertEqual(credentials.resolve("groq", self.user).key,
                             "gsk_live_1111")
            credentials.activate(self.user, self.spare)
            self.assertEqual(credentials.resolve("groq", self.user).key,
                             "gsk_spare_2222")

    def test_deactivating_promotes_nothing_in_its_place(self):
        with clean_env():
            credentials.deactivate(self.user, self.live)

        self.assertFalse(
            credentials.children("groq", self.user).filter(is_active=True).exists())

    def test_with_nothing_active_the_environment_is_used(self):
        with clean_env(GROQ_API_KEY="gsk_env_key_EEEE"):
            credentials.deactivate(self.user, self.live)
            resolved = credentials.resolve("groq", self.user)

        self.assertEqual(resolved.source, credentials.ENVIRONMENT)
        self.assertEqual(resolved.key, "gsk_env_key_EEEE")

    def test_with_nothing_active_and_no_environment_it_is_not_configured(self):
        with clean_env():
            credentials.deactivate(self.user, self.live)
            resolved = credentials.resolve("groq", self.user)

        self.assertFalse(resolved.usable)

    def test_deleting_the_active_credential_promotes_no_sibling(self):
        """A key nobody chose must never start serving requests."""
        with clean_env():
            status = credentials.remove(self.user, self.live)

        self.assertFalse(status["has_active"])
        self.assertTrue(ProviderCredential.objects.filter(pk=self.spare.pk).exists())

    def test_deleting_an_inactive_credential_leaves_the_active_one_alone(self):
        with clean_env():
            credentials.remove(self.user, self.spare)
            resolved = credentials.resolve("groq", self.user)

        self.assertEqual(resolved.key, "gsk_live_1111")

    def test_a_deleted_credential_cannot_be_resolved_again(self):
        with clean_env():
            credentials.remove(self.user, self.live)
            credentials.activate(self.user, self.spare)
            credentials.remove(self.user, self.spare)
            resolved = credentials.resolve("groq", self.user)

        self.assertFalse(resolved.usable)
        self.assertEqual(ProviderCredential.objects.count(), 0)

    def test_acting_on_another_accounts_credential_is_refused(self):
        stranger = make_user("stranger@elsewhere.test")

        for action in (credentials.activate, credentials.deactivate,
                       credentials.remove):
            with self.subTest(action=action.__name__):
                with self.assertRaises(credentials.CredentialError):
                    action(stranger, self.live)

        self.assertTrue(ProviderCredential.objects.filter(pk=self.live.pk).exists())


class OwnershipTests(SignedIn):
    """A key belongs to one account, and to no context at all by default."""

    def setUp(self):
        with clean_env():
            self.mine = credentials.add(self.user, "groq", "gsk_mine_1111",
                                        label="Mine")
        self.other = OtherUser()
        with clean_env():
            self.theirs = credentials.add(self.other.user, "groq",
                                          "gsk_theirs_2222", label="Theirs")

    def test_each_account_resolves_its_own_key(self):
        with clean_env():
            self.assertEqual(credentials.resolve("groq", self.user).key,
                             "gsk_mine_1111")
            self.assertEqual(credentials.resolve("groq", self.other.user).key,
                             "gsk_theirs_2222")

    def test_both_accounts_can_have_an_active_credential_for_one_provider(self):
        """The constraint is per account, not global."""
        self.assertTrue(ProviderCredential.objects.get(pk=self.mine.pk).is_active)
        self.assertTrue(ProviderCredential.objects.get(pk=self.theirs.pk).is_active)

    def test_an_account_sees_only_its_own_children(self):
        labels = set(credentials.children("groq", self.user)
                     .values_list("label", flat=True))

        self.assertEqual(labels, {"Mine"})

    def test_with_no_account_in_context_the_database_is_not_read(self):
        """A management command must not reach into somebody's keys."""
        with clean_env():
            with aicontext.acting_as(None):
                resolved = credentials.resolve("groq")

        self.assertFalse(resolved.usable)
        self.assertNotEqual(resolved.source, credentials.DATABASE)

    def test_with_no_account_in_context_the_environment_still_works(self):
        with clean_env(GROQ_API_KEY="gsk_env_key_EEEE"):
            with aicontext.acting_as(None):
                resolved = credentials.resolve("groq")

        self.assertEqual(resolved.source, credentials.ENVIRONMENT)

    def test_the_context_owner_is_used_when_none_is_passed(self):
        with clean_env():
            with aicontext.acting_as(self.other.user):
                resolved = credentials.resolve("groq")

        self.assertEqual(resolved.key, "gsk_theirs_2222")

    def test_the_context_is_restored_after_the_block(self):
        with aicontext.acting_as(self.user):
            with aicontext.acting_as(self.other.user):
                pass
            self.assertEqual(aicontext.get_owner(), self.user)


class ResolutionPriorityTests(SignedIn):
    """Active child > environment > CLI profile > not configured."""

    def test_setup_a_environment_only(self):
        with clean_env(OPENAI_API_KEY="sk-env-key-EEEE"):
            resolved = credentials.resolve("openai", self.user)

        self.assertEqual(resolved.source, credentials.ENVIRONMENT)
        self.assertEqual(resolved.key, "sk-env-key-EEEE")
        self.assertTrue(resolved.usable)

    def test_setup_b_database_only(self):
        with clean_env():
            credentials.add(self.user, "openai", "sk-db-key-DDDD")
            resolved = credentials.resolve("openai", self.user)

        self.assertEqual(resolved.source, credentials.DATABASE)
        self.assertEqual(resolved.key, "sk-db-key-DDDD")

    def test_setup_c_the_active_child_beats_the_environment(self):
        with clean_env(OPENAI_API_KEY="sk-env-key-EEEE"):
            credentials.add(self.user, "openai", "sk-db-key-DDDD")
            resolved = credentials.resolve("openai", self.user)

        self.assertEqual(resolved.source, credentials.DATABASE)
        self.assertEqual(resolved.key, "sk-db-key-DDDD")

    def test_an_inactive_child_is_never_used_on_its_own(self):
        with clean_env(OPENAI_API_KEY="sk-env-key-EEEE"):
            live = credentials.add(self.user, "openai", "sk-db-key-DDDD",
                                   label="Live")
            credentials.add(self.user, "openai", "sk-spare-SSSS", label="Spare")
            credentials.deactivate(self.user, live)
            resolved = credentials.resolve("openai", self.user)

        # Two children exist, neither active: the environment wins, not a
        # credential the user did not choose.
        self.assertEqual(resolved.source, credentials.ENVIRONMENT)

    def test_neither_source_means_not_configured(self):
        with clean_env():
            resolved = credentials.resolve("openai", self.user)

        self.assertFalse(resolved.usable)
        self.assertEqual(resolved.source, credentials.NONE)
        self.assertEqual(resolved.source_label, "Not configured")

    def test_the_first_listed_environment_variable_wins(self):
        with clean_env(GEMINI_API_KEY="first-GGGG", GOOGLE_API_KEY="second-HHHH"):
            resolved = credentials.resolve("gemini", self.user)

        self.assertEqual(resolved.key, "first-GGGG")

    def test_the_second_variable_is_honoured_when_the_first_is_absent(self):
        with clean_env(GOOGLE_API_KEY="second-HHHH"):
            self.assertEqual(credentials.resolve("gemini", self.user).key,
                             "second-HHHH")

    def test_a_rotated_secret_key_falls_back_instead_of_failing(self):
        with clean_env(OPENAI_API_KEY="sk-env-key-EEEE"):
            credentials.add(self.user, "openai", "sk-db-key-DDDD")
            with override_settings(SECRET_KEY="a-totally-different-secret"):
                resolved = credentials.resolve("openai", self.user)

        self.assertEqual(resolved.source, credentials.ENVIRONMENT)
        self.assertIn("DJANGO_SECRET_KEY", resolved.advice)

    def test_a_rotated_secret_key_with_no_fallback_is_not_configured(self):
        with clean_env():
            credentials.add(self.user, "openai", "sk-db-key-DDDD")
            with override_settings(SECRET_KEY="a-totally-different-secret"):
                resolved = credentials.resolve("openai", self.user)

        self.assertFalse(resolved.usable)
        self.assertIn("DJANGO_SECRET_KEY", resolved.advice)

    def test_an_unknown_provider_resolves_to_not_configured(self):
        resolved = credentials.resolve("pretendai", self.user)

        self.assertFalse(resolved.usable)
        self.assertIn("unknown provider", resolved.detail)

    def test_one_provider_never_borrows_anothers_key(self):
        with clean_env(GROQ_API_KEY="gsk_groq_only"):
            credentials.add(self.user, "claude", "sk-ant-claude-only")

            self.assertEqual(credentials.resolve("claude", self.user).key,
                             "sk-ant-claude-only")
            self.assertEqual(credentials.resolve("groq", self.user).key,
                             "gsk_groq_only")
            self.assertFalse(credentials.resolve("openai", self.user).usable)
            self.assertFalse(credentials.resolve("openrouter", self.user).usable)

    def test_the_resolved_credential_names_the_child_it_came_from(self):
        with clean_env():
            row = credentials.add(self.user, "groq", "gsk_key_1234",
                                  label="Production")
            resolved = credentials.resolve("groq", self.user)

        self.assertEqual(resolved.credential_id, row.pk)
        self.assertEqual(resolved.label, "Production")

    def test_a_forced_credential_overrides_the_active_one(self):
        """How a spare is tested, and how one retry borrows it."""
        with clean_env():
            credentials.add(self.user, "groq", "gsk_live_1111", label="Live")
            spare = credentials.add(self.user, "groq", "gsk_spare_2222",
                                    label="Spare")
            with aicontext.using_credential(spare):
                resolved = credentials.resolve("groq", self.user)

        self.assertEqual(resolved.key, "gsk_spare_2222")

    def test_a_forced_credential_does_not_outlive_the_block(self):
        with clean_env():
            credentials.add(self.user, "groq", "gsk_live_1111", label="Live")
            spare = credentials.add(self.user, "groq", "gsk_spare_2222",
                                    label="Spare")
            with aicontext.using_credential(spare):
                pass
            resolved = credentials.resolve("groq", self.user)

        self.assertEqual(resolved.key, "gsk_live_1111")

    def test_require_raises_the_specified_message(self):
        with clean_env():
            with self.assertRaises(ai.AiError) as caught:
                credentials.require("openai", self.user)

        self.assertTrue(str(caught.exception).startswith(
            "OpenAI is not configured. Please add OpenAI credentials in Settings."
        ))

    def test_require_returns_the_credential_when_there_is_one(self):
        with clean_env(OPENAI_API_KEY="sk-env-key-EEEE"):
            self.assertEqual(credentials.require("openai", self.user).key,
                             "sk-env-key-EEEE")


class StatusTests(SignedIn):
    """`status()` and `child_status()` are the only shapes the UI receives."""

    def test_status_never_contains_the_key(self):
        with clean_env(GROQ_API_KEY="gsk_env_secret_9999"):
            status = credentials.status("groq", self.user)

        self.assertNotIn("gsk_env_secret_9999", repr(status))
        self.assertNotIn("env_secret", repr(status))
        self.assertTrue(status["masked"].endswith("9999"))

    def test_child_status_never_contains_the_key(self):
        with clean_env():
            row = credentials.add(self.user, "groq", "gsk_child_secret_8888")
            child = credentials.child_status(row)

        self.assertNotIn("gsk_child_secret_8888", repr(child))
        self.assertNotIn("child_secret", repr(child))
        self.assertTrue(child["masked"].endswith("8888"))

    def test_status_names_the_active_credential(self):
        with clean_env():
            credentials.add(self.user, "groq", "gsk_key_1234", label="Production")
            status = credentials.status("groq", self.user)

        self.assertTrue(status["has_active"])
        self.assertEqual(status["active_label"], "Production")

    def test_status_says_when_no_credential_is_active(self):
        """The exact state §10 says must never be left ambiguous."""
        with clean_env():
            row = credentials.add(self.user, "groq", "gsk_key_1234")
            credentials.deactivate(self.user, row)
            status = credentials.status("groq", self.user)

        self.assertFalse(status["has_active"])
        self.assertEqual(status["active_label"], "")
        self.assertEqual(status["credential_count"], 1)

    def test_status_lists_every_child(self):
        with clean_env():
            credentials.add(self.user, "groq", "gsk_one_1111", label="A")
            credentials.add(self.user, "groq", "gsk_two_2222", label="B")
            status = credentials.status("groq", self.user)

        self.assertEqual([c["label"] for c in status["credentials"]], ["A", "B"])
        self.assertEqual(status["credential_count"], 2)

    def test_the_active_child_is_listed_first(self):
        with clean_env():
            credentials.add(self.user, "groq", "gsk_one_1111", label="Zebra")
            second = credentials.add(self.user, "groq", "gsk_two_2222",
                                     label="Alpha")
            credentials.activate(self.user, second)
            status = credentials.status("groq", self.user)

        self.assertEqual(status["credentials"][0]["label"], "Alpha")

    def test_status_reports_a_still_present_environment_fallback(self):
        with clean_env(GROQ_API_KEY="gsk_env_key_1234"):
            credentials.add(self.user, "groq", "gsk_db_key_5678")
            status = credentials.status("groq", self.user)

        self.assertTrue(status["has_database_row"])
        self.assertTrue(status["env_present"])

    def test_an_unused_credential_reports_no_timestamps_rather_than_zeroes(self):
        """"Unknown" is the specified answer; an invented date is worse."""
        with clean_env():
            row = credentials.add(self.user, "groq", "gsk_key_1234")
            child = credentials.child_status(row)

        self.assertIsNone(child["last_used_at"])
        self.assertIsNone(child["last_success_at"])
        self.assertEqual(child["request_count"], 0)

    def test_every_provider_has_a_status(self):
        statuses = credentials.all_statuses(self.user)

        self.assertEqual({s["name"] for s in statuses}, set(credentials.SPECS))
        for status in statuses:
            with self.subTest(provider=status["name"]):
                self.assertTrue(status["label"])
                self.assertTrue(status["env_vars"])
                self.assertTrue(status["default_model"])
                self.assertTrue(status["console_url"])
                self.assertEqual(status["credentials"], [])


class UsageRecordTests(SignedIn):
    """Usage is recorded against the child that served the request."""

    def setUp(self):
        with clean_env():
            self.row = credentials.add(self.user, "groq", "gsk_key_1234",
                                       label="Production")

    def test_a_successful_request_is_counted(self):
        credentials.record_use(self.row.pk, success=True)

        self.row.refresh_from_db()
        self.assertEqual(self.row.request_count, 1)
        self.assertEqual(self.row.error_count, 0)
        self.assertIsNotNone(self.row.last_used_at)
        self.assertIsNotNone(self.row.last_success_at)

    def test_a_failure_is_counted_and_categorised(self):
        credentials.record_use(self.row.pk, success=False, category="rate_limited",
                               detail="The provider is rate limiting this key.")

        self.row.refresh_from_db()
        self.assertEqual(self.row.error_count, 1)
        self.assertEqual(self.row.last_error_category, "rate_limited")
        self.assertEqual(self.row.status, "failing")

    def test_a_success_clears_the_previous_failure(self):
        credentials.record_use(self.row.pk, success=False, category="unavailable",
                               detail="The provider could not be reached.")
        credentials.record_use(self.row.pk, success=True)

        self.row.refresh_from_db()
        self.assertEqual(self.row.last_error_category, "")
        self.assertEqual(self.row.status, "active")
        self.assertEqual(self.row.error_count, 1)     # the history stays

    def test_an_environment_credential_has_nothing_to_record_against(self):
        credentials.record_use(None, success=True)      # must not raise

        self.assertFalse(CredentialEvent.objects.filter(
            kind=CredentialEvent.Kind.USED).exists())

    def test_a_detail_that_might_quote_a_key_is_withheld(self):
        """Belt and braces: a provider body must never reach the database."""
        credentials.record_use(
            self.row.pk, success=False, category="invalid",
            detail='request failed: {"api_key": "sk-live-abcdefgh"}')

        self.row.refresh_from_db()
        self.assertNotIn("sk-live-abcdefgh", self.row.last_error_detail)
        self.assertIn("withheld", self.row.last_error_detail)

    def test_no_audit_row_ever_contains_a_key(self):
        credentials.record_use(self.row.pk, success=False, category="invalid",
                               detail="Bearer gsk_key_1234 was rejected")

        text = " ".join(CredentialEvent.objects.values_list("detail", flat=True))
        self.assertNotIn("gsk_key_1234", text)

    def test_the_audit_trail_records_the_lifecycle(self):
        with clean_env():
            spare = credentials.add(self.user, "groq", "gsk_spare_2222",
                                    label="Backup")
            credentials.activate(self.user, spare)
            credentials.remove(self.user, spare)

        kinds = [e.kind for e in credentials.events(self.user, "groq")]
        self.assertIn(CredentialEvent.Kind.CREATED, kinds)
        self.assertIn(CredentialEvent.Kind.ACTIVATED, kinds)
        self.assertIn(CredentialEvent.Kind.DEACTIVATED, kinds)
        self.assertIn(CredentialEvent.Kind.DELETED, kinds)

    def test_the_trail_outlives_the_credential(self):
        with clean_env():
            spare = credentials.add(self.user, "groq", "gsk_spare_2222",
                                    label="Backup")
            credentials.remove(self.user, spare)

        deleted = CredentialEvent.objects.get(kind=CredentialEvent.Kind.DELETED)
        self.assertEqual(deleted.label, "Backup")
        self.assertEqual(deleted.provider, "groq")

    def test_events_are_per_account(self):
        other = OtherUser()

        self.assertEqual(credentials.events(other.user), [])
        self.assertTrue(credentials.events(self.user))

    def test_events_with_no_account_are_empty(self):
        self.assertEqual(credentials.events(None), [])


class CategoriseTests(TestCase):
    """A failure becomes a category and a phrase written here, never the SDK's."""

    def test_an_authentication_error_is_invalid(self):
        class AuthenticationError(Exception):
            pass

        category, phrase = credentials.categorise(
            AuthenticationError("401 {'key': 'sk-live-abcdefgh'}"))

        self.assertEqual(category, "invalid")
        self.assertNotIn("sk-live", phrase)

    def test_a_rate_limit_is_retryable_in_category(self):
        class RateLimitError(Exception):
            pass

        self.assertEqual(credentials.categorise(RateLimitError("429"))[0],
                         "rate_limited")

    def test_a_connection_failure_is_unavailable(self):
        class APIConnectionError(Exception):
            pass

        self.assertEqual(credentials.categorise(APIConnectionError("no route"))[0],
                         "unavailable")

    def test_anything_else_is_a_plain_error(self):
        category, phrase = credentials.categorise(ValueError("something odd"))

        self.assertEqual(category, "error")
        self.assertNotIn("something odd", phrase)

    def test_the_phrase_never_quotes_the_provider(self):
        for error in (Exception('body: {"authorization": "Bearer sk-x"}'),
                      Exception("api_key=gsk_abcdefgh invalid")):
            with self.subTest(error=str(error)[:20]):
                _category, phrase = credentials.categorise(error)
                self.assertNotIn("sk-x", phrase)
                self.assertNotIn("gsk_abcdefgh", phrase)


class FallbackTests(SignedIn):
    """Rotation is opt-in, single-use, and never changes what is ACTIVE."""

    def setUp(self):
        with clean_env():
            self.live = credentials.add(self.user, "groq", "gsk_live_1111",
                                        label="Production")
            self.spare = credentials.add(self.user, "groq", "gsk_spare_2222",
                                         label="Backup")
            credentials.set_selection("groq", owner=self.user)

    def _rate_limited_then_ok(self):
        """A backend that fails once with a rate limit, then succeeds."""
        class RateLimitError(Exception):
            pass

        calls = []

        def complete(**kwargs):
            calls.append(credentials.resolve("groq", self.user).key)
            if len(calls) == 1:
                raise RateLimitError("429 too many requests")
            return '{"subject": "s", "body": "b"}'

        return calls, mock.Mock(complete=complete), RateLimitError

    def test_without_opt_in_nothing_is_retried(self):
        calls, handle, _ = self._rate_limited_then_ok()

        with clean_env():
            with aicontext.acting_as(self.user):
                with mock.patch.object(ai, "backend", return_value=handle):
                    with self.assertRaises(Exception):
                        ai._complete(system="s", prompt="p", schema={},
                                     max_tokens=10)

        self.assertEqual(len(calls), 1)

    def test_an_opted_in_spare_is_tried_once(self):
        credentials.set_fallback(self.user, self.spare, True)
        calls, handle, _ = self._rate_limited_then_ok()

        with clean_env():
            with aicontext.acting_as(self.user):
                with mock.patch.object(ai, "backend", return_value=handle):
                    ai._complete(system="s", prompt="p", schema={}, max_tokens=10)

        self.assertEqual(calls, ["gsk_live_1111", "gsk_spare_2222"])

    def test_a_fallback_does_not_change_which_credential_is_active(self):
        """§11: the permanent choice is the user's, not a retry's."""
        credentials.set_fallback(self.user, self.spare, True)
        _calls, handle, _ = self._rate_limited_then_ok()

        with clean_env():
            with aicontext.acting_as(self.user):
                with mock.patch.object(ai, "backend", return_value=handle):
                    ai._complete(system="s", prompt="p", schema={}, max_tokens=10)

        self.assertTrue(ProviderCredential.objects.get(pk=self.live.pk).is_active)
        self.assertFalse(ProviderCredential.objects.get(pk=self.spare.pk).is_active)

    def test_a_fallback_is_recorded_with_why_and_what_happened(self):
        credentials.set_fallback(self.user, self.spare, True)
        _calls, handle, _ = self._rate_limited_then_ok()

        with clean_env():
            with aicontext.acting_as(self.user):
                with mock.patch.object(ai, "backend", return_value=handle):
                    ai._complete(system="s", prompt="p", schema={}, max_tokens=10)

        event = CredentialEvent.objects.get(kind=CredentialEvent.Kind.FALLBACK)
        self.assertEqual(event.label, "Backup")
        self.assertIn("rate_limited", event.category)
        self.assertIn("Production", event.detail)
        self.assertIn("succeeded", event.detail)

    def test_an_invalid_key_is_not_a_reason_to_try_another(self):
        """A rejected key is a configuration problem, not a transient one."""
        credentials.set_fallback(self.user, self.spare, True)

        class AuthenticationError(Exception):
            pass

        calls = []

        def complete(**kwargs):
            calls.append(1)
            raise AuthenticationError("401 unauthorized")

        with clean_env():
            with aicontext.acting_as(self.user):
                with mock.patch.object(ai, "backend",
                                       return_value=mock.Mock(complete=complete)):
                    with self.assertRaises(AuthenticationError):
                        ai._complete(system="s", prompt="p", schema={},
                                     max_tokens=10)

        self.assertEqual(len(calls), 1)

    def test_the_active_credentials_failure_is_what_gets_reported(self):
        """A spare failing too must not hide why the real one failed."""
        credentials.set_fallback(self.user, self.spare, True)

        class RateLimitError(Exception):
            pass

        def complete(**kwargs):
            raise RateLimitError("429 too many requests")

        with clean_env():
            with aicontext.acting_as(self.user):
                with mock.patch.object(ai, "backend",
                                       return_value=mock.Mock(complete=complete)):
                    with self.assertRaises(RateLimitError):
                        ai._complete(system="s", prompt="p", schema={},
                                     max_tokens=10)

        self.assertEqual(
            ProviderCredential.objects.get(pk=self.spare.pk).error_count, 1)

    def test_usage_is_recorded_against_the_credential_that_served_it(self):
        with clean_env():
            with aicontext.acting_as(self.user):
                with mock.patch.object(
                    ai, "backend",
                    return_value=mock.Mock(complete=lambda **kw: "{}"),
                ):
                    ai._complete(system="s", prompt="p", schema={}, max_tokens=10)

        self.assertEqual(
            ProviderCredential.objects.get(pk=self.live.pk).request_count, 1)
        self.assertEqual(
            ProviderCredential.objects.get(pk=self.spare.pk).request_count, 0)

    def test_the_active_credential_is_never_offered_as_its_own_fallback(self):
        credentials.set_fallback(self.user, self.spare, True)

        with clean_env():
            spares = credentials.fallbacks("groq", self.user)

        self.assertEqual([s.pk for s in spares], [self.spare.pk])


class SelectionTests(SignedIn):
    """The provider chosen in the UI decides which service is called."""

    def test_the_default_applies_with_nothing_configured(self):
        with clean_env():
            self.assertEqual(credentials.selection(self.user)[0],
                             credentials.DEFAULT_PROVIDER)

    def test_the_environment_variable_is_honoured(self):
        with clean_env(OUTREACH_AI_PROVIDER="groq"):
            self.assertEqual(credentials.selection(self.user)[0], "groq")

    def test_a_saved_selection_beats_the_environment(self):
        with clean_env(OUTREACH_AI_PROVIDER="groq"):
            credentials.set_selection("gemini", owner=self.user)
            self.assertEqual(credentials.selection(self.user)[0], "gemini")

    def test_the_choice_is_per_account(self):
        other = OtherUser()

        with clean_env():
            credentials.set_selection("gemini", owner=self.user)
            credentials.set_selection("groq", owner=other.user)

            self.assertEqual(credentials.selection(self.user)[0], "gemini")
            self.assertEqual(credentials.selection(other.user)[0], "groq")

    def test_an_unrecognised_environment_provider_is_not_silently_corrected(self):
        """It must reach ai.load() so the error names the wrong value."""
        with clean_env(OUTREACH_AI_PROVIDER="skynet"):
            with aicontext.acting_as(self.user):
                self.assertEqual(credentials.selection(self.user)[0], "skynet")
                with self.assertRaises(ai.AiError) as caught:
                    ai.backend()

        self.assertIn("skynet", str(caught.exception))

    def test_selecting_an_unknown_provider_is_refused(self):
        with self.assertRaises(KeyError):
            credentials.set_selection("skynet", owner=self.user)

    def test_one_selection_row_per_account(self):
        credentials.set_selection("groq", owner=self.user)
        credentials.set_selection("gemini", owner=self.user)

        self.assertEqual(AiSelection.objects.filter(owner=self.user).count(), 1)

    def test_the_model_follows_the_provider(self):
        with clean_env():
            with aicontext.acting_as(self.user):
                credentials.add(self.user, "groq", "gsk_key_1234",
                                model="openai/gpt-oss-20b")
                credentials.add(self.user, "gemini", "AIza-key-1234")
                credentials.set_selection("groq", owner=self.user)

                self.assertEqual(ai.provider(), "groq")
                self.assertEqual(ai.model(), "openai/gpt-oss-20b")

                credentials.set_selection("gemini", owner=self.user)
                self.assertEqual(ai.provider(), "gemini")
                # Gemini's own default, not Groq's saved model.
                self.assertEqual(ai.model(), "gemini-3.7-flash")

    def test_the_environment_model_is_the_fallback(self):
        with clean_env(GROQ_API_KEY="gsk_key", OUTREACH_AI_MODEL="llama-3.3-70b"):
            with aicontext.acting_as(self.user):
                credentials.set_selection("groq", owner=self.user)
                self.assertEqual(ai.model(), "llama-3.3-70b")

    def test_the_active_credentials_model_beats_the_environment(self):
        with clean_env(GROQ_API_KEY="gsk_key", OUTREACH_AI_MODEL="llama-3.3-70b"):
            with aicontext.acting_as(self.user):
                credentials.add(self.user, "groq", "gsk_key_1234",
                                model="openai/gpt-oss-20b")
                credentials.set_selection("groq", owner=self.user)
                self.assertEqual(ai.model(), "openai/gpt-oss-20b")

    def test_activating_a_different_credential_can_change_the_model(self):
        """Model metadata belongs to the credential, per §3."""
        with clean_env():
            with aicontext.acting_as(self.user):
                credentials.add(self.user, "groq", "gsk_one_1111", label="Fast",
                                model="openai/gpt-oss-20b")
                slow = credentials.add(self.user, "groq", "gsk_two_2222",
                                       label="Big", model="openai/gpt-oss-120b")
                credentials.set_selection("groq", owner=self.user)
                self.assertEqual(ai.model(), "openai/gpt-oss-20b")

                credentials.activate(self.user, slow)
                self.assertEqual(ai.model(), "openai/gpt-oss-120b")


class EndpointTests(SignedIn):
    """The HTTP surface. No response may ever carry a key."""

    def _add(self, provider="openai", **payload):
        payload.setdefault("api_key", "sk-payload-key-PPPP")
        return self.client.post(
            reverse("outreach:credential_add", args=[provider]),
            data=payload, content_type="application/json")

    def _post(self, name, pk, **payload):
        return self.client.post(
            reverse(f"outreach:{name}", args=[pk]),
            data=payload, content_type="application/json")

    def test_adding_a_credential_reports_what_happened(self):
        with clean_env():
            response = self._add(label="Production")

        self.assertEqual(response.status_code, 200)
        message = response.json()["message"]
        self.assertIn("Production", message)
        self.assertIn("active credential", message)

    def test_the_add_response_contains_no_key(self):
        with clean_env():
            response = self._add(api_key="sk-super-secret-value-PPPP")

        self.assertNotIn("sk-super-secret-value-PPPP", response.content.decode())
        self.assertNotIn("super-secret", response.content.decode())

    def test_the_add_response_carries_a_masked_hint(self):
        with clean_env():
            data = self._add(api_key="sk-abcdefghijkl-PPPP").json()

        self.assertTrue(data["credential"]["masked"].endswith("PPPP"))
        self.assertNotIn("abcdefghijkl", data["credential"]["masked"])

    def test_an_empty_key_is_refused(self):
        with clean_env():
            response = self._add(api_key="   ")

        self.assertEqual(response.status_code, 400)
        self.assertEqual(ProviderCredential.objects.count(), 0)

    def test_an_unknown_provider_is_refused(self):
        with clean_env():
            response = self._add(provider="pretendai")

        self.assertEqual(response.status_code, 400)
        self.assertEqual(ProviderCredential.objects.count(), 0)

    def test_a_duplicate_label_is_reported_as_a_conflict(self):
        with clean_env():
            self._add(label="Production")
            response = self._add(label="Production")

        self.assertEqual(response.status_code, 409)
        self.assertEqual(ProviderCredential.objects.count(), 1)

    def test_a_credential_is_owned_by_the_account_that_added_it(self):
        with clean_env():
            self._add()

        self.assertEqual(ProviderCredential.objects.get().owner, self.user)

    def test_activating_switches_the_active_credential(self):
        with clean_env():
            self._add(label="Production")
            self._add(label="Backup", api_key="sk-backup-BBBB")
            spare = ProviderCredential.objects.get(label="Backup")
            response = self._post("credential_activate", spare.pk)

        self.assertEqual(response.status_code, 200)
        self.assertTrue(ProviderCredential.objects.get(pk=spare.pk).is_active)
        self.assertIn("Backup", response.json()["message"])

    def test_activating_the_active_credential_is_harmless(self):
        with clean_env():
            self._add(label="Production")
            row = ProviderCredential.objects.get()
            response = self._post("credential_activate", row.pk)

        self.assertEqual(response.status_code, 200)
        self.assertIn("already", response.json()["message"])

    def test_deactivating_reports_the_environment_fallback(self):
        with clean_env(OPENAI_API_KEY="sk-env-key-EEEE"):
            self._add()
            row = ProviderCredential.objects.get()
            response = self._post("credential_deactivate", row.pk)

        self.assertEqual(response.status_code, 200)
        self.assertIn("environment", response.json()["message"].lower())
        self.assertEqual(response.json()["status"]["source"],
                         credentials.ENVIRONMENT)

    def test_deactivating_with_no_fallback_says_so_plainly(self):
        with clean_env():
            self._add()
            row = ProviderCredential.objects.get()
            response = self._post("credential_deactivate", row.pk)

        self.assertIn("no active credential",
                      response.json()["message"].lower())

    def test_deleting_removes_the_credential(self):
        with clean_env():
            self._add()
            row = ProviderCredential.objects.get()
            response = self._post("credential_delete", row.pk)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(ProviderCredential.objects.count(), 0)

    def test_deleting_the_active_credential_warns_and_promotes_nothing(self):
        with clean_env():
            self._add(label="Production")
            self._add(label="Backup", api_key="sk-backup-BBBB")
            live = ProviderCredential.objects.get(label="Production")
            response = self._post("credential_delete", live.pk)

        self.assertIn("no active credential", response.json()["message"].lower())
        self.assertFalse(ProviderCredential.objects.filter(is_active=True).exists())

    def test_marking_a_spare_as_a_fallback(self):
        with clean_env():
            self._add(label="Production")
            self._add(label="Backup", api_key="sk-backup-BBBB")
            spare = ProviderCredential.objects.get(label="Backup")
            response = self._post("credential_fallback", spare.pk, enabled=True)

        self.assertEqual(response.status_code, 200)
        self.assertTrue(ProviderCredential.objects.get(pk=spare.pk).allow_fallback)

    def test_the_active_credential_cannot_be_its_own_fallback(self):
        with clean_env():
            self._add(label="Production")
            row = ProviderCredential.objects.get()
            response = self._post("credential_fallback", row.pk, enabled=True)

        self.assertEqual(response.status_code, 400)
        self.assertFalse(ProviderCredential.objects.get(pk=row.pk).allow_fallback)

    def test_another_accounts_credential_is_not_found(self):
        """404, not 403: 403 would confirm the credential exists."""
        with clean_env():
            self._add()
            row = ProviderCredential.objects.get()

        other = OtherUser()
        for name in ("credential_activate", "credential_deactivate",
                     "credential_test", "credential_fallback",
                     "credential_delete"):
            with self.subTest(endpoint=name):
                response = other.client.post(
                    reverse(f"outreach:{name}", args=[row.pk]),
                    data={}, content_type="application/json")
                self.assertEqual(response.status_code, 404)

        self.assertTrue(ProviderCredential.objects.filter(pk=row.pk).exists())

    def test_the_endpoints_require_a_session(self):
        from django.test import Client

        with clean_env():
            self._add()
            row = ProviderCredential.objects.get()

        anonymous = Client()
        response = anonymous.post(
            reverse("outreach:credential_activate", args=[row.pk]))

        self.assertEqual(response.status_code, 302)
        self.assertIn("/login", response["Location"])

    def test_the_write_endpoints_refuse_get(self):
        with clean_env():
            self._add()
            row = ProviderCredential.objects.get()

        for name, arg in (("credential_add", "openai"),
                          ("credential_activate", row.pk),
                          ("credential_deactivate", row.pk),
                          ("credential_test", row.pk),
                          ("credential_fallback", row.pk),
                          ("credential_delete", row.pk)):
            with self.subTest(endpoint=name):
                response = self.client.get(
                    reverse(f"outreach:{name}", args=[arg]))
                self.assertEqual(response.status_code, 405)

    def test_the_kill_switch_blocks_writing(self):
        with clean_env(OUTREACH_CREDENTIALS_UI="0"):
            response = self._add()

        self.assertEqual(response.status_code, 403)
        self.assertEqual(ProviderCredential.objects.count(), 0)

    def test_the_kill_switch_blocks_switching(self):
        with clean_env():
            self._add(label="Production")
            self._add(label="Backup", api_key="sk-backup-BBBB")
            spare = ProviderCredential.objects.get(label="Backup")

        with clean_env(OUTREACH_CREDENTIALS_UI="0"):
            activate = self._post("credential_activate", spare.pk)
            delete = self._post("credential_delete", spare.pk)

        self.assertEqual(activate.status_code, 403)
        self.assertEqual(delete.status_code, 403)
        self.assertEqual(ProviderCredential.objects.count(), 2)

    def test_the_audit_trail_endpoint_is_per_account(self):
        with clean_env():
            self._add(label="Production")

        response = self.client.get(reverse("outreach:credential_events"))
        other = OtherUser().client.get(reverse("outreach:credential_events"))

        self.assertTrue(response.json()["events"])
        self.assertEqual(other.json()["events"], [])

    def test_the_audit_trail_contains_no_key(self):
        with clean_env():
            self._add(api_key="sk-trail-secret-TTTT")

        response = self.client.get(reverse("outreach:credential_events"))

        self.assertNotIn("sk-trail-secret-TTTT", response.content.decode())
        self.assertNotIn("trail-secret", response.content.decode())


class ConnectionTestTests(SignedIn):
    """Testing one credential proves that credential, and changes nothing."""

    def setUp(self):
        with clean_env():
            self.live = credentials.add(self.user, "groq", "gsk_live_1111",
                                        label="Production")
            self.spare = credentials.add(self.user, "groq", "gsk_spare_2222",
                                         label="Backup")

    def _test(self, row):
        return self.client.post(reverse("outreach:credential_test", args=[row.pk]))

    def test_a_test_is_refused_where_outbound_requests_are_blocked(self):
        """OUTREACH_BLOCK_SEND covers this as well as SMTP and IMAP."""
        response = self._test(self.live)

        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.json()["result"], "blocked")

    @override_settings(OUTREACH_BLOCK_SEND=False)
    def test_a_successful_test_is_recorded_against_that_credential(self):
        with clean_env():
            with mock.patch("outreach.ai_groq.verify",
                            return_value=("ok", "Connected to Groq successfully.")):
                response = self._test(self.spare)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["result"], "ok")
        self.spare.refresh_from_db()
        self.assertIn("ok", self.spare.last_test_result)
        self.assertIsNotNone(self.spare.last_tested_at)
        self.assertEqual(self.live.last_test_result, "")

    @override_settings(OUTREACH_BLOCK_SEND=False)
    def test_testing_a_spare_does_not_activate_it(self):
        with clean_env():
            with mock.patch("outreach.ai_groq.verify",
                            return_value=("ok", "Connected.")):
                self._test(self.spare)

        self.assertTrue(ProviderCredential.objects.get(pk=self.live.pk).is_active)
        self.assertFalse(ProviderCredential.objects.get(pk=self.spare.pk).is_active)

    @override_settings(OUTREACH_BLOCK_SEND=False)
    def test_a_spare_is_tested_with_its_own_key(self):
        """Otherwise the button would report on the active credential instead."""
        seen = {}

        def verify(model=""):
            seen["key"] = credentials.resolve("groq", self.user).key
            return "ok", "Connected."

        with clean_env():
            with mock.patch("outreach.ai_groq.verify", side_effect=verify):
                self._test(self.spare)

        self.assertEqual(seen["key"], "gsk_spare_2222")

    @override_settings(OUTREACH_BLOCK_SEND=False)
    def test_a_rejected_key_is_reported_without_provider_detail(self):
        with clean_env():
            with mock.patch("outreach.ai_groq.verify",
                            return_value=("invalid", "Groq rejected the API key.")):
                response = self._test(self.live)

        self.assertEqual(response.status_code, 502)
        self.assertEqual(response.json()["result"], "invalid")
        self.assertNotIn("gsk_live_1111", response.content.decode())

    @override_settings(OUTREACH_BLOCK_SEND=False)
    def test_a_rate_limited_provider_still_counts_as_reachable(self):
        with clean_env():
            with mock.patch("outreach.ai_groq.verify",
                            return_value=("rate_limited", "Rate limited.")):
                response = self._test(self.live)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["result"], "rate_limited")

    @override_settings(OUTREACH_BLOCK_SEND=False)
    def test_a_raising_backend_becomes_a_category_not_a_traceback(self):
        class AuthenticationError(Exception):
            pass

        with clean_env():
            with mock.patch("outreach.ai_groq.verify",
                            side_effect=AuthenticationError("401 sk-leak-1234")):
                response = self._test(self.live)

        self.assertEqual(response.json()["result"], "invalid")
        self.assertNotIn("sk-leak-1234", response.content.decode())


class SettingsPageTests(SignedIn):
    def test_the_page_shows_a_card_per_provider(self):
        with clean_env():
            response = self.client.get(reverse("outreach:settings"))

        self.assertEqual(response.status_code, 200)
        for provider_spec in credentials.SPECS.values():
            with self.subTest(provider=provider_spec.name):
                self.assertContains(response, provider_spec.label)

    def test_the_page_never_contains_a_key(self):
        with clean_env(GROQ_API_KEY="gsk_env_secret_1111"):
            credentials.add(self.user, "openai", "sk-db-secret-2222")
            response = self.client.get(reverse("outreach:settings"))

        text = response.content.decode()
        self.assertNotIn("gsk_env_secret_1111", text)
        self.assertNotIn("sk-db-secret-2222", text)
        self.assertNotIn("env_secret", text)
        self.assertNotIn("db-secret", text)

    def test_the_page_lists_each_credential_by_name(self):
        with clean_env():
            credentials.add(self.user, "openai", "sk-one-1111", label="Production")
            credentials.add(self.user, "openai", "sk-two-2222", label="Backup")
            response = self.client.get(reverse("outreach:settings"))

        self.assertContains(response, "Production")
        self.assertContains(response, "Backup")
        self.assertContains(response, "ACTIVE")

    def test_the_page_shows_another_accounts_credentials_to_nobody(self):
        other = OtherUser()
        with clean_env():
            credentials.add(other.user, "openai", "sk-theirs-9999",
                            label="Their Production Key")
            response = self.client.get(reverse("outreach:settings"))

        self.assertNotContains(response, "Their Production Key")

    def test_the_page_states_the_resolution_order(self):
        with clean_env():
            response = self.client.get(reverse("outreach:settings"))

        # Whitespace-normalised: the sentence wraps in the template and carries
        # markup, so a literal match would be testing the line breaks.
        text = " ".join(response.content.decode().split())
        self.assertIn("active credential", text)
        self.assertIn("environment variable", text)

    def test_the_page_says_when_a_provider_has_no_active_credential(self):
        with clean_env():
            row = credentials.add(self.user, "openai", "sk-one-1111")
            credentials.deactivate(self.user, row)
            response = self.client.get(reverse("outreach:settings"))

        self.assertContains(response, "No active credential")


class CampaignGateTests(SignedIn):
    """An unconfigured provider stops the run before it costs anything."""

    def setUp(self):
        from .models import Campaign, EmailDraft
        from .tests import make_campaign, make_draft

        self.campaign = make_campaign(phase=Campaign.Phase.SETUP)
        self.draft = make_draft(self.campaign, status=EmailDraft.Status.PENDING)
        self.payload = {
            "sender_name": "Sam Rivers",
            "sender_email": "sam@agency.test",
            "provider": "gmail",
            "service_pitch": "We build fast websites with online booking.",
            "selected": [self.draft.pk],
        }

    def _run(self):
        return self.client.post(
            reverse("outreach:run", args=[self.campaign.id]),
            data=self.payload, content_type="application/json")

    def test_starting_a_run_is_refused_with_no_credential(self):
        from . import runner

        with clean_env():
            with mock.patch.object(runner, "start_pipeline") as start:
                response = self._run()

        self.assertEqual(response.status_code, 400)
        self.assertIn("not configured", response.json()["error"])
        start.assert_not_called()

    def test_starting_a_run_works_once_a_credential_is_active(self):
        from . import runner

        with clean_env():
            credentials.add(self.user, "groq", "gsk_saved_key_1234")
            credentials.set_selection("groq", owner=self.user)
            with mock.patch.object(runner, "start_pipeline",
                                   return_value=True) as start:
                response = self._run()

        self.assertEqual(response.status_code, 200)
        start.assert_called_once()

    def test_a_run_is_refused_when_the_only_credential_is_deactivated(self):
        from . import runner

        with clean_env():
            row = credentials.add(self.user, "groq", "gsk_saved_key_1234")
            credentials.set_selection("groq", owner=self.user)
            credentials.deactivate(self.user, row)
            with mock.patch.object(runner, "start_pipeline") as start:
                response = self._run()

        self.assertEqual(response.status_code, 400)
        start.assert_not_called()

    def test_the_setup_screen_warns_before_anything_is_spent(self):
        with clean_env():
            response = self.client.get(
                reverse("outreach:setup", args=[self.campaign.id]))

        self.assertContains(response, "is not configured")


class ProviderTableTests(SignedIn):
    """One provider table, not two that can drift."""

    def test_ai_providers_mirrors_the_credential_specs(self):
        self.assertEqual(set(ai.PROVIDERS), set(credentials.SPECS))

    def test_every_provider_has_a_loadable_backend(self):
        for name in credentials.SPECS:
            with self.subTest(provider=name):
                module = ai.load(name)
                self.assertEqual(module.NAME, name)
                self.assertTrue(module.LABEL)
                self.assertTrue(module.DEFAULT_MODEL)
                self.assertTrue(callable(module.complete))
                self.assertTrue(callable(module.describe_credentials))
                self.assertTrue(callable(module.reset_client))
                self.assertTrue(callable(module.verify))

    def test_the_spec_default_model_matches_the_backend(self):
        for name, provider_spec in credentials.SPECS.items():
            with self.subTest(provider=name):
                self.assertEqual(provider_spec.default_model,
                                 ai.load(name).DEFAULT_MODEL)

    def test_no_backend_reads_a_provider_key_from_the_environment(self):
        """The whole point of the resolver: one place reads the variables."""
        import pathlib
        import re

        pattern = re.compile(
            r"os\.environ(?:\.get)?[\[(]\s*[\"'](?:ANTHROPIC_API_KEY|"
            r"ANTHROPIC_AUTH_TOKEN|GEMINI_API_KEY|GOOGLE_API_KEY|"
            r"OPENAI_API_KEY|OPENROUTER_API_KEY|GROQ_API_KEY)[\"']")
        for name, provider_spec in credentials.SPECS.items():
            path = pathlib.Path(provider_spec.module.replace(".", "/") + ".py")
            with self.subTest(provider=name):
                self.assertIsNone(pattern.search(path.read_text(encoding="utf-8")))

    def test_every_ai_entry_point_goes_through_the_credential_path(self):
        """A new AI feature that calls a backend directly would bypass usage
        recording, the safe error categories and the fallback rules."""
        import pathlib
        import re

        source = pathlib.Path("outreach/ai.py").read_text(encoding="utf-8")
        calls = re.findall(r"backend\(\)\.complete", source)

        self.assertEqual(calls, [], "ai.py must route every request through "
                                    "_complete()")
