from django.urls import path

from . import views

app_name = "outreach"

urlpatterns = [
    path("start", views.start, name="start"),
    path("history", views.campaign_history, name="history"),
    path("settings", views.settings_view, name="settings"),
    path("history.xlsx", views.history_excel, name="history_excel"),
    path("leads", views.leads, name="leads"),
    path("lead/<int:pk>/intel", views.lead_detail, name="lead_detail"),
    path("lead/<int:pk>/reanalyse", views.lead_reanalyse, name="lead_reanalyse"),
    path("lead/<int:pk>/lifecycle", views.lead_lifecycle, name="lead_lifecycle"),
    path("rescore", views.rescore, name="rescore"),
    path("ai/select", views.ai_select, name="ai_select"),
    # The pool: one route to add a child under a provider, then routes that act
    # on one child by id. Every one of them re-reads the credential scoped to the
    # signed-in account, so an id in a URL grants nothing on its own.
    path("ai/credentials/<str:provider>/add", views.credential_add,
         name="credential_add"),
    path("ai/credentials/<int:pk>/activate", views.credential_activate,
         name="credential_activate"),
    path("ai/credentials/<int:pk>/deactivate", views.credential_deactivate,
         name="credential_deactivate"),
    path("ai/credentials/<int:pk>/test", views.credential_test,
         name="credential_test"),
    path("ai/credentials/<int:pk>/fallback", views.credential_fallback,
         name="credential_fallback"),
    path("ai/credentials/<int:pk>/delete", views.credential_delete,
         name="credential_delete"),
    path("ai/credentials/events", views.credential_events,
         name="credential_events"),
    path("followups", views.followups, name="followups"),
    path("followups/check-inbox", views.check_inbox, name="check_inbox"),
    path("lead/<int:pk>/followup", views.followup_create,
         name="followup_create"),
    path("followup/<int:pk>/<str:action>", views.followup_action,
         name="followup_action"),
    path("suppressions", views.suppressions, name="suppressions"),
    path("suppressions/add", views.suppress_add, name="suppress_add"),
    path("suppressions/<int:pk>/remove", views.suppress_remove,
         name="suppress_remove"),
    path("draft/<int:pk>/<str:action>", views.draft_action, name="draft_action"),
    path("<uuid:campaign_id>/setup", views.setup, name="setup"),
    path("<uuid:campaign_id>/run", views.run, name="run"),
    path("<uuid:campaign_id>/state", views.state, name="state"),
    path("<uuid:campaign_id>/resume", views.resume, name="resume"),
    path("<uuid:campaign_id>/cancel", views.cancel, name="cancel"),
    path("<uuid:campaign_id>/approve-all", views.approve_all, name="approve_all"),
    path("<uuid:campaign_id>/send", views.send, name="send"),
    path("<uuid:campaign_id>/report", views.report, name="report"),
    path("<uuid:campaign_id>/", views.workspace, name="workspace"),
]
