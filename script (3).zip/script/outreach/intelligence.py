"""
The lead intelligence pipeline: audit, cache, score, classify, recommend.

Sits between the crawler and everything that displays a lead. Two rules shape it:

  * **Opening a lead page never spends money.** `apply()` reads the cached audit
    and recomputes the arithmetic; only `audit_website(refresh=True)` crawls, and
    only a person asking for it does that. An application that re-audited on every
    page view would cost its owner a fortune to browse.
  * **Programmatic first, AI second.** Classification, every score, the
    recommended service and the "why this is a prospect" sentence are computed
    from measured signals here. The AI is asked only for interpretation -- what
    the findings mean, how to phrase an approach -- because a model asked for a
    number invents a different one each time.

The audit cache is keyed on (owner, domain), so two campaigns containing the same
business share one crawl, and one user's audit is never read by another.
"""

from __future__ import annotations

import logging

from django.utils import timezone

from . import ai, analyzer, scoring
from .models import EmailDraft, Lifecycle, SentLead, WebsiteAudit

log = logging.getLogger(__name__)

#: Bumped when the scoring rules change, so a stored score can be recognised as
#: having been produced by older rules.
SCORING_VERSION = 1


# --------------------------------------------------------------------------- #
# The audit cache
# --------------------------------------------------------------------------- #

def cached_audit(owner, website: str) -> WebsiteAudit | None:
    """The stored audit for this website, or None. Never crawls."""
    domain = SentLead.domain_of(website)
    if not domain or owner is None or not getattr(owner, "pk", None):
        return None
    return WebsiteAudit.objects.filter(owner=owner, domain=domain).first()


def audit_website(owner, website: str, *, refresh: bool = False,
                  review: bool = True, business_name: str = "",
                  category: str = "", city: str = "",
                  country: str = "") -> WebsiteAudit | None:
    """Crawl and score one website, or return the cached result.

    `refresh=False` is the default everywhere except the Re-analyse button: a
    usable, fresh audit is reused rather than repeated. A *stale* audit is still
    returned rather than silently refreshed -- the page offers the refresh, and the
    user decides whether it is worth the crawl.

    `review=False` skips the AI call, which is what the initial classification
    pass wants: the measured signals alone are enough to classify and score a
    site, and the findings can be added later.
    """
    domain = SentLead.domain_of(website)
    if not domain:
        return None

    existing = cached_audit(owner, website)
    if existing is not None and not refresh and existing.usable:
        return existing

    result = analyzer.analyse(website)
    signals = scoring.merge_signals([page.facts for page in result.pages])

    findings: list = []
    summary = ""
    ai_version = ""
    if review and result.usable:
        # The one AI call in this module, and only when there is material for it.
        try:
            reviewed = ai.audit(
                business_name=business_name or domain, category=category,
                city=city, country=country, website=website,
                site_context=_context(result),
                pages_read=len(result.pages),
                discovered=result.discovered,
            )
            findings = [f.as_dict() for f in reviewed.findings]
            summary = reviewed.business_summary
            ai_version = ai.describe_provider()
        except Exception as exc:  # noqa: BLE001 - see below
            # A failed review must not lose the crawl. The crawl is the expensive
            # part and it has already happened; the measured signals classify and
            # score the site perfectly well without any findings.
            #
            # Deliberately broader than AiError: a provider SDK can raise
            # something the backend did not wrap, and letting that through would
            # throw away a page fetch to save nothing.
            log.info("website review failed for %s: %s", domain, exc)

    # What the fresh crawl replaces, and what it must not.
    #
    # A usable crawl replaces everything, findings included. Carrying yesterday's
    # findings forward onto today's measurements would show evidence that the
    # fresh measurement contradicts -- a site that has just been re-measured as
    # fast and mobile-ready must not still be accused of being slow. Stale
    # evidence is worse than no evidence.
    #
    # A crawl that *failed* replaces nothing but the status. "We could not reach
    # it today" is not a reason to erase what was learned last week, so the
    # previous signals and findings are kept and the failure is recorded in
    # `detail` for the page to show.
    if result.usable or existing is None:
        fields = {
            "url": (result.pages[0].url if result.pages else website)[:500],
            "signals": signals,
            "pages": [{"url": p.url, "kind": p.kind} for p in result.pages],
            "pages_discovered": result.discovered,
            "findings": findings,
            "business_summary": summary,
            "ai_version": ai_version,
        }
    else:
        fields = {
            "url": existing.url,
            "signals": existing.signals,
            "pages": existing.pages,
            "pages_discovered": existing.pages_discovered,
            "findings": existing.findings,
            "business_summary": existing.business_summary,
            "ai_version": existing.ai_version,
        }
        signals = existing.signals or {}
        findings = existing.findings or []

    assessment = scoring.assess_website(signals, _finding_objects(findings))

    audit, _created = WebsiteAudit.objects.update_or_create(
        owner=owner, domain=domain,
        defaults={
            **fields,
            "status": result.status,
            "detail": result.summary()[:400],
            "quality_score": assessment.quality.value,
            "opportunity_score": assessment.opportunity.value,
            "sub_scores": {k: v.as_dict()
                           for k, v in assessment.sub_scores.items()},
            "scoring_version": SCORING_VERSION,
            "refreshes": (existing.refreshes + 1) if existing else 0,
        },
    )
    return audit


def _finding_objects(findings: list[dict]) -> list:
    from .ai_base import Finding

    return [Finding.from_dict(f) for f in findings]


def _context(result: analyzer.SiteAnalysis) -> str:
    """The crawled material, in the shape ai.audit() expects."""
    return result.as_context()


# --------------------------------------------------------------------------- #
# Scoring one lead
# --------------------------------------------------------------------------- #

def apply(draft: EmailDraft, *, audit: WebsiteAudit | None = None,
          save: bool = True) -> EmailDraft:
    """Classify and score one lead from what is already known. Never crawls.

    Safe to call as often as you like: it reads the draft's own crawl fields and
    the cached audit, does arithmetic, and writes the result. That is what makes
    the table sortable in SQL without the numbers going stale.
    """
    audit = audit or draft.audit or cached_audit(
        draft.campaign.owner if draft.campaign_id else None, draft.website)

    # The draft's own crawl wins where it has one -- it is this lead's own
    # evidence. The shared audit fills in for a lead that has not been crawled.
    if draft.analysis_status:
        status = draft.analysis_status
        pages_read = len(draft.pages_read or [])
    elif audit is not None:
        status = audit.status
        pages_read = len(audit.pages or [])
    else:
        status = ""
        pages_read = 0

    classification, reason = scoring.classify(
        website=draft.website, analysis_status=status, pages_read=pages_read)

    # Same precedence as the status above: this lead's own crawl is its own
    # evidence, and the shared audit fills in when it has none.
    signals = draft.measured_signals or ((audit.signals if audit else {}) or {})
    findings = draft.finding_objects or (audit.finding_objects if audit else [])
    assessment = scoring.assess_website(signals, findings)

    value = scoring.business_value(
        category=draft.category, phone=draft.phone, email=draft.email,
        website=draft.website, social_links=signals.get("social_links", 0) or 0,
        city=draft.city, country=draft.country,
    )

    missing, benefits = scoring.missing_website_opportunity(
        category=draft.category, phone=draft.phone, email=draft.email,
        social_links=signals.get("social_links", 0) or 0,
    )
    if classification != scoring.NO_WEBSITE_OPPORTUNITY:
        benefits = []

    overall = scoring.overall_opportunity(
        classification=classification, website_opportunity=assessment.opportunity,
        missing_opportunity=missing, value=value,
    )

    service, service_reason = scoring.recommend_service(
        classification=classification, assessment=assessment,
        category=draft.category)

    readiness = scoring.email_readiness(
        classification=classification, email=draft.email,
        business_name=draft.business_name, findings=findings,
        observation=draft.observation, pages_read=pages_read,
        opportunity=overall.value, benefits=benefits,
    )

    why = scoring.explain(
        classification=classification, category=draft.category,
        assessment=assessment, findings=findings, value=value,
        overall=overall.value,
    )

    draft.classification = classification
    draft.classification_reason = reason[:400]
    draft.audit = audit
    draft.score_overall = overall.value
    draft.score_website = (assessment.opportunity.value
                           if assessment.opportunity.measured else 0)
    draft.score_value = value.value
    draft.score_missing = (missing.value
                           if classification == scoring.NO_WEBSITE_OPPORTUNITY
                           else 0)
    draft.score_readiness = readiness.value
    draft.priority = scoring.priority_band(overall.value)
    draft.score_detail = {
        "overall": overall.as_dict(),
        "website": assessment.opportunity.as_dict(),
        "quality": assessment.quality.as_dict(),
        "value": value.as_dict(),
        "missing": missing.as_dict(),
        "readiness": readiness.as_dict(),
        "thresholds": scoring.default_thresholds(),
        "scoring_version": SCORING_VERSION,
    }
    draft.recommended_service = service[:64]
    draft.service_reason = service_reason[:400]
    draft.why_prospect = why[:400]
    draft.benefits = benefits
    draft.scored_at = timezone.now()

    derived = draft.derive_lifecycle()
    if derived != draft.lifecycle:
        draft.lifecycle = derived
        draft.lifecycle_changed_at = timezone.now()

    if save:
        draft.save(update_fields=[
            "classification", "classification_reason", "audit", "score_overall",
            "score_website", "score_value", "score_missing", "score_readiness",
            "priority", "score_detail", "recommended_service", "service_reason",
            "why_prospect", "benefits", "scored_at", "lifecycle",
            "lifecycle_changed_at",
        ])
    return draft


def apply_to_campaign(campaign) -> int:
    """Re-score every lead in one campaign. Arithmetic only, no crawling."""
    count = 0
    for draft in campaign.drafts.select_related("audit").all():
        apply(draft)
        count += 1
    return count


def set_lifecycle(draft: EmailDraft, stage: str, note: str = "") -> EmailDraft:
    """Move a lead to a stage a person has judged.

    Only the manual stages are settable this way; the derived ones are computed
    from the machinery and would be overwritten on the next scoring pass.
    """
    valid = [c.value for c in Lifecycle]
    if stage not in valid:
        raise ValueError(f"Unknown lifecycle stage {stage!r}.")

    draft.lifecycle = stage
    draft.lifecycle_note = (note or "")[:300]
    draft.lifecycle_changed_at = timezone.now()
    draft.save(update_fields=["lifecycle", "lifecycle_note",
                             "lifecycle_changed_at"])
    return draft
