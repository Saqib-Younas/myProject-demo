"""
Whose credentials the current AI call should use.

The problem this solves: credentials are per-account, but the code that reaches
for one is buried three layers down -- `ai.generate()` calls `backend().complete()`
calls `client()` calls `credentials.require()` -- and none of those layers has a
request. Threading an `owner` argument through all of them would touch every AI
function, every backend and every call site, and the first one anybody forgot
would silently fall back to the wrong account's key.

So the owner is carried in a context variable instead, set at the two places work
actually starts:

  * **a request** -- `AiOwnerMiddleware` sets it from `request.user`;
  * **a background job** -- `runner._spawn` sets it from `campaign.owner`, because
    a thread does not inherit the request's context.

The safety property that makes this acceptable: when no owner is set, the
resolver uses **environment credentials only**. It never falls back to "whichever
database credential it can find", so a call from a context nobody set cannot
reach into an account's keys. A management command therefore works from `.env`
unless it is told whose account to act as.
"""

from __future__ import annotations

import contextvars
from contextlib import contextmanager

#: The account whose credentials apply to work happening right now. None means
#: "no account", which the resolver treats as environment-only.
_owner: contextvars.ContextVar = contextvars.ContextVar("ai_owner", default=None)


def get_owner():
    """The account for the current context, or None."""
    return _owner.get()


def set_owner(owner):
    """Set the account for this context. Returns the token to reset with."""
    return _owner.set(owner if getattr(owner, "pk", None) else None)


def reset_owner(token) -> None:
    _owner.reset(token)


@contextmanager
def acting_as(owner):
    """Run a block against one account's credentials.

    Used by the background runner and by management commands. A context manager
    rather than a bare setter so an exception cannot leave the wrong owner in
    place for whatever the thread does next.
    """
    token = set_owner(owner)
    try:
        yield owner
    finally:
        reset_owner(token)


class AiOwnerMiddleware:
    """Bind the signed-in account to the request's context.

    Cheap: one context variable set and reset per request. Placed after
    AuthenticationMiddleware so `request.user` exists.
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        token = set_owner(getattr(request, "user", None))
        try:
            return self.get_response(request)
        finally:
            reset_owner(token)


# --------------------------------------------------------------------------- #
# Forcing one specific credential
# --------------------------------------------------------------------------- #

#: When set, the resolver uses this child credential rather than the active one.
#: Two callers need that: the per-credential connection test, and the fallback
#: path, which tries a spare key without changing which one is active.
_forced: contextvars.ContextVar = contextvars.ContextVar(
    "ai_credential", default=None)


def get_forced_credential():
    return _forced.get()


@contextmanager
def using_credential(row):
    """Run a block against one specific child credential.

    A context manager so an exception cannot leave a spare key selected for
    whatever the thread does next -- which would be the silent rotation the whole
    design is meant to avoid.
    """
    token = _forced.set(row)
    try:
        yield row
    finally:
        _forced.reset(token)
