"""
Tests for the email workflow.

The Claude API and SMTP are both mocked -- these run offline and cost nothing.
Coverage is aimed at the parts that would quietly do the wrong thing: robots.txt
and bot-wall handling in the analyser, the prompt's no-invention framing, the
anti-spoofing check, per-recipient failure isolation, the daily cap, and the
double-send guard.
"""

from __future__ import annotations

import os
import smtplib
from unittest import mock

import groq as groq_errors
from django.conf import settings
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone
from google.genai import errors as genai_errors

from . import (
    ai,
    ai_claude,
    ai_gemini,
    ai_groq,
    analyzer,  # noqa: F811
    credentials,
    runner,
    scoring,
    sender,
)
from .models import Campaign, EmailDraft
from .testsupport import OtherUser, SignedIn, default_user, make_user

HTML_HOME = """
<html><head><title>Bella Cucina</title>
<meta name="description" content="Family-run Italian kitchen in Delft.">
</head><body>
<h1>Bella Cucina</h1><h2>Wood-fired pizza since 1998</h2>
<p>We make everything by hand, including our sourdough bases.</p>
<a href="/about">About us</a>
<a href="/services">Our services</a>
<a href="/contact">Contact</a>
<a href="https://facebook.com/x">Facebook</a>
<a href="mailto:ciao@bella.example">Email us</a>
</body></html>
"""

HTML_ABOUT = """
<html><head><title>About - Bella Cucina</title></head><body>
<h1>Our story</h1><p>Three generations of the Rossi family.</p>
<script>var tracking = 1;</script>
</body></html>
"""


def make_campaign(**overrides) -> Campaign:
    values = dict(
        # Owned by the account driving the test client, so ownership filtering
        # behaves as it does in the application rather than hiding the fixture.
        owner=default_user(),
        city="Delft", country="Netherlands", category="Restaurants",
        sender_name="Sam Rivers", sender_email="sam@agency.test",
        sender_company="Northline", provider="gmail",
        service_pitch="We build fast websites with online booking for restaurants.",
        phase=Campaign.Phase.REVIEW,
    )
    values.update(overrides)
    return Campaign.objects.create(**values)


def make_draft(campaign: Campaign, **overrides) -> EmailDraft:
    values = dict(
        business_name="Bella Cucina",
        email="ciao@bella.example",
        website="https://bella.example",
        category="Restaurant",
        city="Delft",
        country="Netherlands",
        subject="Online booking for Bella Cucina",
        body="Hello,\n\nI saw your wood-fired pizza page.\n\nSam",
        observation="wood-fired pizza since 1998",
        analysis_status=analyzer.OK,
        analysis_context="--- HOME PAGE\nWood-fired pizza since 1998",
        status=EmailDraft.Status.GENERATED,
    )
    values.update(overrides)
    return EmailDraft.objects.create(campaign=campaign, **values)


class FakeResponse:
    """Stands in for a requests.Response in analyser tests."""

    def __init__(self, text="", status_code=200, content_type="text/html",
                 url="https://bella.example/"):
        self.text = text
        self.status_code = status_code
        self.headers = {"Content-Type": content_type}
        self.encoding = "utf-8"
        self.url = url
        self.raw = mock.Mock()
        self.raw.read.return_value = text.encode()

    def raise_for_status(self):
        if self.status_code >= 400:
            raise __import__("requests").HTTPError(f"HTTP {self.status_code}")


def fetched(html, load_ms=120, url="https://bella.example/"):
    """Wrap raw HTML the way analyzer._fetch would return it."""
    return analyzer.Fetched(html, load_ms, len(html.encode()), url)


# --------------------------------------------------------------------------- #
# Website analysis
# --------------------------------------------------------------------------- #

class AnalyserExtractionTests(SignedIn):
    def test_extracts_title_description_and_headings(self):
        page = analyzer.extract(fetched(HTML_HOME), "https://bella.example", "home")

        self.assertEqual(page.title, "Bella Cucina")
        self.assertEqual(page.description, "Family-run Italian kitchen in Delft.")
        self.assertIn("Wood-fired pizza since 1998", page.headings)
        self.assertIn("sourdough bases", page.text)

    def test_scripts_are_not_part_of_the_text(self):
        page = analyzer.extract(
            fetched(HTML_ABOUT), "https://bella.example/about", "about")

        self.assertNotIn("var tracking", page.text)
        self.assertIn("Three generations", page.text)

    def test_collects_published_mailto_addresses(self):
        self.assertEqual(analyzer.scrape_emails(HTML_HOME), ["ciao@bella.example"])

    def test_normalise_adds_a_scheme(self):
        self.assertEqual(analyzer.normalise("bella.example"), "https://bella.example")
        self.assertEqual(analyzer.normalise(""), "")


class DiscoveryTests(SignedIn):
    """The crawler must decide for itself which pages are worth reading."""

    def test_internal_links_are_classified_and_scored(self):
        rows = analyzer.discover_links(HTML_HOME, "https://bella.example")
        by_kind = {kind: url for url, kind, _score in rows}

        self.assertEqual(by_kind["about"], "https://bella.example/about")
        self.assertEqual(by_kind["services"], "https://bella.example/services")
        self.assertEqual(by_kind["contact"], "https://bella.example/contact")

    def test_external_links_are_not_followed(self):
        rows = analyzer.discover_links(HTML_HOME, "https://bella.example")

        self.assertFalse(any("facebook" in url for url, _k, _s in rows))

    def test_the_home_page_is_not_offered_as_a_candidate(self):
        html = '<a href="/">Home</a><a href="/services">Services</a>'
        rows = analyzer.discover_links(html, "https://bella.example")

        self.assertEqual([url for url, _k, _s in rows],
                         ["https://bella.example/services"])

    def test_boilerplate_and_account_pages_are_skipped(self):
        html = """
        <a href="/privacy-policy">Privacy</a><a href="/terms">Terms</a>
        <a href="/cart">Cart</a><a href="/my-account">Account</a>
        <a href="/wp-login.php">Login</a><a href="/feed">RSS</a>
        <a href="/tag/pizza">Tag</a><a href="/brochure.pdf">PDF</a>
        <a href="/services">Services</a>
        """
        rows = analyzer.discover_links(html, "https://bella.example")

        self.assertEqual([url for url, _k, _s in rows],
                         ["https://bella.example/services"])

    def test_navigation_links_outrank_body_links(self):
        html = """
        <nav><a href="/our-services">Services</a></nav>
        <div><a href="/blog/a-post">A post</a></div>
        """
        rows = analyzer.discover_links(html, "https://bella.example")

        self.assertEqual(rows[0][1], "services")
        self.assertGreater(rows[0][2], rows[-1][2])

    def test_shallow_pages_outrank_deep_ones(self):
        html = """
        <a href="/services">Services</a>
        <a href="/a/b/c/d/services-detail">Deep services</a>
        """
        rows = analyzer.discover_links(html, "https://bella.example")

        self.assertEqual(rows[0][0], "https://bella.example/services")

    def test_duplicate_urls_collapse(self):
        html = """
        <a href="/services">Services</a>
        <a href="/services/">Services again</a>
        <a href="/services#top">Services anchor</a>
        """
        rows = analyzer.discover_links(html, "https://bella.example")

        self.assertEqual(len(rows), 1)

    def test_classify_recognises_the_business_page_kinds(self):
        for path, expected in (
            ("/our-services", "services"),
            ("/shop/menu", "products"),
            ("/pricing", "pricing"),
            ("/contact-us", "contact"),
            ("/about-us", "about"),
            ("/testimonials", "testimonials"),
            ("/blog/hello", "blog"),
        ):
            with self.subTest(path=path):
                self.assertEqual(analyzer.classify(path)[0], expected)

    def test_an_unrecognised_page_scores_zero(self):
        self.assertEqual(analyzer.classify("/random-thing"), ("other", 0))

    def test_substrings_do_not_cause_false_classifications(self):
        """Both of these were mislabelled on a real site before word boundaries.

        "workshops" contains "shop", so it was filed as a products page, and
        "quotes" (testimonials) matched the pricing pattern for "quote". A wrong
        page kind reaches the AI as a wrong claim about the business.
        """
        self.assertNotEqual(analyzer.classify("/community/workshops")[0], "products")
        # /about/quotes lands on "about", which is right -- it is under /about.
        # What matters is that it is no longer read as a pricing page.
        self.assertNotEqual(analyzer.classify("/about/quotes")[0], "pricing")
        self.assertEqual(analyzer.classify("/client-quotes")[0], "testimonials")
        self.assertNotEqual(analyzer.classify("/restore-data")[0], "products")
        self.assertNotEqual(analyzer.classify("/arrangements")[0], "products")

    def test_the_genuine_forms_still_classify(self):
        self.assertEqual(analyzer.classify("/shop")[0], "products")
        self.assertEqual(analyzer.classify("/get-a-quote")[0], "pricing")
        self.assertEqual(analyzer.classify("/our-services")[0], "services")

    def test_choose_pages_prefers_a_spread_of_kinds(self):
        # Five service pages tell us less than services + pricing + contact.
        candidates = [
            ("https://x/services-1", "services", 100),
            ("https://x/services-2", "services", 99),
            ("https://x/services-3", "services", 98),
            ("https://x/pricing", "pricing", 90),
            ("https://x/contact", "contact", 85),
        ]

        chosen = analyzer.choose_pages(candidates, 3)
        kinds = [kind for _url, kind, _score in chosen]

        self.assertEqual(kinds, ["services", "pricing", "contact"])

    def test_choose_pages_backfills_when_kinds_run_out(self):
        candidates = [
            ("https://x/services-1", "services", 100),
            ("https://x/services-2", "services", 99),
        ]

        chosen = analyzer.choose_pages(candidates, 2)

        self.assertEqual(len(chosen), 2)


class SitemapTests(SignedIn):
    def test_sitemap_urls_are_discovered_and_classified(self):
        xml = """<?xml version="1.0"?>
        <urlset><url><loc>https://bella.example/services</loc></url>
        <url><loc>https://bella.example/pricing</loc></url>
        <url><loc>https://bella.example/privacy</loc></url>
        <url><loc>https://elsewhere.test/services</loc></url></urlset>"""

        with mock.patch.object(analyzer.requests, "get",
                               return_value=FakeResponse(xml)):
            rows = analyzer.discover_sitemap("https://bella.example", None)

        urls = [url for url, _k, _s in rows]
        self.assertIn("https://bella.example/services", urls)
        self.assertIn("https://bella.example/pricing", urls)
        self.assertNotIn("https://bella.example/privacy", urls)   # boilerplate
        self.assertFalse(any("elsewhere.test" in u for u in urls))  # off-site

    def test_a_missing_sitemap_is_not_an_error(self):
        with mock.patch.object(analyzer.requests, "get",
                               return_value=FakeResponse("", 404)):
            self.assertEqual(analyzer.discover_sitemap("https://bella.example", None), [])

    def test_robots_declared_sitemaps_are_tried_first(self):
        robots = analyzer.RobotFileParser()
        robots.parse(["Sitemap: https://bella.example/custom-sitemap.xml",
                      "User-agent: *", "Allow: /"])
        xml = ("<urlset><url><loc>https://bella.example/services</loc></url>"
               "</urlset>")

        with mock.patch.object(analyzer.requests, "get",
                               return_value=FakeResponse(xml)) as get:
            analyzer.discover_sitemap("https://bella.example", robots)

        self.assertIn("custom-sitemap.xml", get.call_args_list[0][0][0])


class MeasurementTests(SignedIn):
    """The signals the AI is allowed to cite as evidence.

    These are the whole basis of "no invented issues": if a number here is
    wrong, the model will report a problem that does not exist.
    """

    def _facts(self, body_html, head_html="", load_ms=120, url="https://x.test/"):
        html = f"<html lang='en'><head>{head_html}</head><body>{body_html}</body></html>"
        return analyzer.extract(fetched(html, load_ms, url), url, "home").facts

    def test_missing_alt_text_is_counted_exactly(self):
        facts = self._facts(
            '<img src="a.jpg" alt="A pizza"><img src="b.jpg"><img src="c.jpg" alt="">')

        self.assertEqual(facts["images"], 3)
        self.assertEqual(facts["images_missing_alt"], 2)

    def test_a_fully_captioned_page_reports_zero_missing(self):
        facts = self._facts('<img src="a.jpg" alt="One"><img src="b.jpg" alt="Two">')

        self.assertEqual(facts["images_missing_alt"], 0)

    def test_image_formats_are_counted(self):
        facts = self._facts(
            '<img src="a.webp" alt="x"><img src="b.jpg" alt="y"><img src="c.png" alt="z">')

        self.assertEqual(facts["images_modern_format"], 1)
        self.assertEqual(facts["images_legacy_format"], 2)

    def test_viewport_meta_presence_is_recorded(self):
        with_vp = self._facts("", '<meta name="viewport" content="width=device-width">')
        without = self._facts("", "")

        self.assertTrue(with_vp["viewport_meta"])
        self.assertIn("device-width", with_vp["viewport_content"])
        self.assertFalse(without["viewport_meta"])

    def test_load_time_and_page_weight_are_recorded(self):
        facts = self._facts("<p>hello</p>" * 200, load_ms=3400)

        self.assertEqual(facts["load_ms"], 3400)
        self.assertGreater(facts["page_kb"], 0)

    def test_a_small_page_is_not_rounded_to_a_misleading_zero(self):
        """"page_kb=0" would read as evidence of an empty response."""
        facts = self._facts("<p>hi</p>")

        self.assertGreater(facts["page_kb"], 0)

    def test_https_is_detected_from_the_final_url(self):
        self.assertTrue(self._facts("", url="https://x.test/")["https"])
        self.assertFalse(self._facts("", url="http://x.test/")["https"])

    def test_cta_phrases_are_found_and_quoted(self):
        facts = self._facts(
            '<a href="/c">Contact us</a><button>Book now</button><a href="/x">Pizza</a>')

        self.assertEqual(facts["cta_count"], 2)
        self.assertIn("Contact us", facts["cta_examples"])

    def test_a_page_with_no_cta_reports_zero(self):
        facts = self._facts('<a href="/x">Pizza</a><a href="/y">Pasta</a>')

        self.assertEqual(facts["cta_count"], 0)

    def test_heading_structure_is_counted(self):
        facts = self._facts("<h1>A</h1><h1>B</h1><h2>C</h2><h3>D</h3><h3>E</h3>")

        self.assertEqual(facts["h1_count"], 2)
        self.assertEqual(facts["h2_count"], 1)
        self.assertEqual(facts["h3_count"], 2)

    def test_seo_basics_are_recorded(self):
        facts = self._facts("", """
            <title>Bella Cucina - Italian in Delft</title>
            <meta name="description" content="Wood-fired pizza in Delft.">
            <link rel="canonical" href="https://x.test/">
            <meta property="og:title" content="Bella">
            <script type="application/ld+json">{}</script>
        """)

        self.assertGreater(facts["title_length"], 0)
        self.assertGreater(facts["meta_description_length"], 0)
        self.assertTrue(facts["canonical"])
        self.assertEqual(facts["og_tags"], 1)
        self.assertEqual(facts["structured_data_blocks"], 1)

    def test_a_missing_meta_description_reads_as_zero_length(self):
        self.assertEqual(self._facts("", "<title>x</title>")["meta_description_length"], 0)

    def test_placeholder_text_is_flagged(self):
        facts = self._facts("<p>Lorem ipsum dolor sit amet, our site is Coming Soon</p>")

        self.assertIn("placeholder_text_found", facts)
        self.assertTrue(any("lorem ipsum" in p for p in facts["placeholder_text_found"]))

    def test_clean_copy_is_not_flagged_as_placeholder(self):
        facts = self._facts("<p>We make wood-fired pizza by hand every morning.</p>")

        self.assertNotIn("placeholder_text_found", facts)

    def test_copyright_year_is_captured(self):
        self.assertEqual(self._facts("<p>© 2019 Bella Cucina</p>")["copyright_year"],
                         "2019")

    def test_contact_affordances_are_counted(self):
        facts = self._facts(
            '<a href="mailto:a@b.test">Email</a><a href="tel:+3115">Call</a>')

        self.assertEqual(facts["mailto_links"], 1)
        self.assertEqual(facts["tel_links"], 1)

    def test_form_fields_without_labels_are_counted(self):
        facts = self._facts("""
            <form>
              <label for="n">Name</label><input id="n">
              <input id="e">
              <textarea id="m"></textarea>
              <input type="hidden" id="h">
              <input type="submit" value="Send">
            </form>
        """)

        self.assertEqual(facts["forms"], 1)
        # The labelled input, the hidden field and the submit are all excluded.
        self.assertEqual(facts["form_fields_unlabelled"], 2)

    def test_trust_signals_are_counted(self):
        facts = self._facts(
            "<p>Read our reviews. Rated 5 stars. Certified and insured since 1998.</p>")

        self.assertGreater(facts["trust_signal_mentions"], 2)

    def test_vague_link_text_is_counted(self):
        facts = self._facts(
            '<a href="/a">Click here</a><a href="/b">Read more</a>'
            '<a href="/c">Our wood-fired pizza menu</a>')

        self.assertEqual(facts["vague_link_text"], 2)

    def test_social_links_are_counted(self):
        facts = self._facts(
            '<a href="https://facebook.com/x">FB</a>'
            '<a href="https://instagram.com/x">IG</a>')

        self.assertEqual(facts["social_links"], 2)

    def test_html_lang_is_recorded_or_flagged(self):
        url = "https://x.test/"
        with_lang = analyzer.extract(
            fetched("<html lang='nl'><body>x</body></html>", url=url), url, "home")
        without = analyzer.extract(
            fetched("<html><body>x</body></html>", url=url), url, "home")

        self.assertEqual(with_lang.facts["html_lang"], "nl")
        self.assertEqual(without.facts["html_lang"], "MISSING")

    def test_word_count_reflects_visible_text(self):
        facts = self._facts("<p>one two three four five</p>")

        self.assertEqual(facts["word_count"], 5)

    def test_context_stays_within_its_character_budget(self):
        """Breadth must not blow the provider's token limit.

        A 6-page crawl at the full per-page allowance came to ~10.5k tokens,
        over Groq's free-tier 8k/minute cap, so the review could never run.
        """
        pages = [
            analyzer.Page(f"https://x.test/{i}", "services", f"T{i}", "d",
                          ["H"], "word " * 3000, {"cta_count": 0})
            for i in range(6)
        ]
        result = analyzer.SiteAnalysis(analyzer.OK, "ok", pages, discovered=9)

        context = result.as_context(char_budget=9000)

        self.assertLess(len(context), 11000)
        # Every page still contributes something.
        for i in range(6):
            self.assertIn(f"https://x.test/{i}", context)

    def test_measured_signals_are_never_trimmed_away(self):
        """Signals are the evidence, and they are cheap. Prose is what gives."""
        pages = [
            analyzer.Page(f"https://x.test/{i}", "services", "T", "", [],
                          "word " * 5000,
                          {"images_missing_alt": 7, "cta_count": 0})
            for i in range(5)
        ]
        context = analyzer.SiteAnalysis(
            analyzer.OK, "ok", pages).as_context(char_budget=4000)

        self.assertEqual(context.count("images_missing_alt=7"), 5)

    def test_a_small_crawl_is_not_padded(self):
        page = analyzer.Page("https://x.test/", "home", "T", "", [], "short text",
                             {"cta_count": 1})
        context = analyzer.SiteAnalysis(
            analyzer.OK, "ok", [page]).as_context(char_budget=9000)

        self.assertIn("short text", context)
        self.assertLess(len(context), 500)

    def test_signals_reach_the_ai_context(self):
        page = analyzer.Page(
            url="https://x.test/", kind="home", title="T", description="",
            headings=["H"], text="Body text",
            facts={"images_missing_alt": 4, "cta_count": 0, "load_ms": 3200},
        )
        context = analyzer.SiteAnalysis(analyzer.OK, "ok", [page]).as_context()

        self.assertIn("images_missing_alt=4", context)
        self.assertIn("load_ms=3200", context)
        self.assertIn("Meta description: MISSING", context)


class AnalyserPolicyTests(SignedIn):
    """The rules that keep this a permitted-data-only crawler."""

    def setUp(self):
        analyzer._robots.clear()
        analyzer._last_hit.clear()

    def test_no_website_is_reported_not_guessed(self):
        result = analyzer.analyse("")

        self.assertEqual(result.status, analyzer.NO_WEBSITE)
        self.assertFalse(result.usable)
        self.assertEqual(result.as_context(), "")

    def test_robots_disallow_stops_the_crawl(self):
        robots = FakeResponse("User-agent: *\nDisallow: /", 200, "text/plain")

        with mock.patch.object(analyzer.requests, "get", return_value=robots) as get:
            result = analyzer.analyse("https://bella.example")

        self.assertEqual(result.status, analyzer.BLOCKED)
        self.assertIn("robots.txt", result.detail)
        # robots.txt only -- the page itself was never requested.
        self.assertEqual(get.call_count, 1)

    def test_unauthorised_robots_is_treated_as_disallow_all(self):
        with mock.patch.object(analyzer.requests, "get",
                               return_value=FakeResponse("", 403)):
            result = analyzer.analyse("https://bella.example")

        self.assertEqual(result.status, analyzer.BLOCKED)

    def test_http_403_on_the_page_is_recorded_not_retried(self):
        responses = [FakeResponse("", 404), FakeResponse("", 403)]

        with mock.patch.object(analyzer.requests, "get", side_effect=responses):
            result = analyzer.analyse("https://bella.example")

        self.assertEqual(result.status, analyzer.BLOCKED)
        self.assertIn("403", result.detail)

    def test_bot_wall_is_not_worked_around(self):
        wall = FakeResponse(
            "<html><head><title>Attention Required! | Cloudflare</title></head>"
            "<body>Checking your browser before accessing</body></html>"
        )

        with mock.patch.object(analyzer.requests, "get",
                               side_effect=[FakeResponse("", 404), wall]):
            result = analyzer.analyse("https://bella.example")

        self.assertEqual(result.status, analyzer.BLOCKED)
        self.assertIn("bot check", result.detail)

    def test_rate_limited_site_is_left_alone(self):
        with mock.patch.object(analyzer.requests, "get",
                               side_effect=[FakeResponse("", 404),
                                            FakeResponse("", 429)]):
            result = analyzer.analyse("https://bella.example")

        self.assertEqual(result.status, analyzer.BLOCKED)

    def test_successful_crawl_reads_home_plus_interior_pages(self):
        # Request order is robots.txt, home, sitemap, then the chosen pages.
        pages = [FakeResponse("", 404), FakeResponse(HTML_HOME),
                 FakeResponse("", 404)] + [FakeResponse(HTML_ABOUT)] * 6

        with mock.patch.object(analyzer.requests, "get", side_effect=pages):
            result = analyzer.analyse("https://bella.example")

        self.assertEqual(result.status, analyzer.OK)
        self.assertTrue(result.usable)
        self.assertLessEqual(len(result.pages), analyzer.MAX_PAGES)
        self.assertEqual(result.pages[0].kind, "home")
        self.assertIn("wood-fired pizza", result.as_context().lower())
        self.assertIn("ciao@bella.example", result.emails_found)

    def test_the_crawler_visits_several_internal_pages_by_itself(self):
        """The user supplies one URL; the crawler finds the rest."""
        nav = """
        <html><head><title>Bella</title></head><body>
        <nav>
          <a href="/services">Services</a><a href="/pricing">Pricing</a>
          <a href="/about">About</a><a href="/contact">Contact</a>
          <a href="/testimonials">Reviews</a><a href="/team">Team</a>
        </nav><h1>Bella</h1><p>Pizza.</p></body></html>
        """
        responses = [FakeResponse("", 404), FakeResponse(nav),
                     FakeResponse("", 404)] + [FakeResponse(HTML_ABOUT)] * 10

        with mock.patch.object(analyzer.requests, "get", side_effect=responses):
            result = analyzer.analyse("https://bella.example")

        internal = [p for p in result.pages if p.kind != "home"]
        self.assertGreaterEqual(len(internal), analyzer.TARGET_INTERNAL)
        self.assertGreater(result.discovered, 0)
        # A spread of page kinds, not five copies of one.
        self.assertGreaterEqual(len({p.kind for p in internal}), 4)

    def test_a_thin_site_reports_what_it_could_reach(self):
        thin = ("<html><head><title>Bella</title></head><body><h1>Bella</h1>"
                '<a href="/contact">Contact</a></body></html>')
        responses = [FakeResponse("", 404), FakeResponse(thin),
                     FakeResponse("", 404), FakeResponse(thin)]

        with mock.patch.object(analyzer.requests, "get", side_effect=responses):
            result = analyzer.analyse("https://bella.example")

        self.assertEqual(result.status, analyzer.OK)
        self.assertEqual(len(result.pages), 2)   # home + contact, all there was
        self.assertIn("Only 1 useful internal page", result.detail)

    def test_the_page_budget_is_respected(self):
        many = "<html><body>" + "".join(
            f'<a href="/services-{i}">Service {i}</a>' for i in range(40)
        ) + "</body></html>"
        responses = [FakeResponse("", 404), FakeResponse(many),
                     FakeResponse("", 404)] + [FakeResponse(many)] * 30

        with mock.patch.object(analyzer.requests, "get", side_effect=responses):
            result = analyzer.analyse("https://bella.example")

        self.assertLessEqual(len(result.pages), analyzer.MAX_PAGES)

    def test_user_agent_carries_a_contact_address(self):
        agent = analyzer._headers()["User-Agent"]

        self.assertIn("LeadMapperBot", agent)
        self.assertIn("robots.txt", agent)


# --------------------------------------------------------------------------- #
# AI prompt construction
# --------------------------------------------------------------------------- #

def make_findings(count=3):
    severities = ["high", "medium", "low"]
    return [
        ai.Finding(
            issue=f"Issue {i}",
            evidence=f"cta_count=0 on page {i}",
            why_it_matters=f"Costs enquiries {i}",
            suggested_improvement=f"Add a CTA {i}",
            dimension="calls to action",
            severity=severities[i % 3],
            page_url=f"https://bella.example/p{i}",
        )
        for i in range(count)
    ]


class AuditPromptTests(SignedIn):
    """The review stage: broad coverage, but evidence or nothing."""

    def _prompt(self, **overrides):
        kwargs = dict(
            business_name="Bella Cucina", category="Restaurant", city="Delft",
            country="Netherlands", website="https://bella.example",
            site_context="### PAGE 1 -- HOME\nMeasured signals: cta_count=0",
            pages_read=6, discovered=14,
        )
        kwargs.update(overrides)
        return ai.build_audit_prompt(**kwargs)

    def test_the_crawled_material_and_counts_are_supplied(self):
        prompt = self._prompt()

        self.assertIn("cta_count=0", prompt)
        self.assertIn("6 page(s) were read automatically", prompt)
        self.assertIn("14 discovered", prompt)

    def test_every_review_dimension_is_named(self):
        prompt = self._prompt()

        for dimension in ai.REVIEW_DIMENSIONS:
            with self.subTest(dimension=dimension):
                self.assertIn(dimension, prompt)

    def test_the_target_count_is_stated(self):
        self.assertIn("8-10", self._prompt())

    def test_the_system_prompt_forbids_unevidenced_claims(self):
        self.assertIn("THE EVIDENCE RULE", ai.AUDIT_SYSTEM)
        self.assertIn("do not report the finding", ai.AUDIT_SYSTEM)

    def test_the_system_prompt_forbids_padding_to_reach_the_target(self):
        self.assertIn("Report fewer if", ai.AUDIT_SYSTEM)
        self.assertIn("Padding the list with speculation is a failure",
                      ai.AUDIT_SYSTEM)

    def test_the_system_prompt_forbids_claims_it_cannot_verify(self):
        """The model has text and numbers, not screenshots.

        Without this, a model asked about "design" and "layout" will happily
        invent judgements about colours and spacing it has no way to see.
        """
        for forbidden in ("colours", "fonts", "spacing", "You cannot see the site"):
            with self.subTest(forbidden=forbidden):
                self.assertIn(forbidden, ai.AUDIT_SYSTEM)

    def test_specific_signals_are_tied_to_specific_claims(self):
        for pair in ("load_ms", "viewport_meta", "images_missing_alt",
                     "cta_count", "word_count"):
            with self.subTest(signal=pair):
                self.assertIn(pair, ai.AUDIT_SYSTEM)

    def test_audit_schema_requires_the_four_reporting_fields(self):
        item = ai.AUDIT_SCHEMA["properties"]["findings"]["items"]

        for field_name in ("issue", "evidence", "why_it_matters",
                           "suggested_improvement"):
            self.assertIn(field_name, item["required"])
        self.assertFalse(item["additionalProperties"])
        self.assertEqual(ai.AUDIT_SCHEMA["properties"]["findings"]["maxItems"], 10)

    def test_an_empty_context_is_refused_before_calling_the_model(self):
        with mock.patch.object(ai, "backend") as backend:
            with self.assertRaises(ai.AiError):
                ai.audit(business_name="B", category="c", city="", country="",
                         website="https://x", site_context="   ",
                         pages_read=0, discovered=0)

        backend.assert_not_called()


class AuditParseTests(SignedIn):
    def _payload(self, findings):
        import json as _json

        return _json.dumps({"business_summary": "A pizzeria.", "findings": findings})

    def test_findings_are_parsed_and_ordered_strongest_first(self):
        result = ai.parse_audit(self._payload([
            {"issue": "B", "evidence": "e", "why_it_matters": "w",
             "suggested_improvement": "s", "dimension": "seo", "severity": "low",
             "page_url": "u"},
            {"issue": "A", "evidence": "e", "why_it_matters": "w",
             "suggested_improvement": "s", "dimension": "cta", "severity": "high",
             "page_url": "u"},
        ]))

        self.assertEqual(result.business_summary, "A pizzeria.")
        self.assertEqual([f.issue for f in result.findings], ["A", "B"])

    def test_a_finding_with_no_evidence_is_discarded(self):
        """The evidence rule is enforced in code, not just asked for.

        A finding with an empty evidence field is exactly the speculation the
        prompt forbids, so it must never reach the user looking verified.
        """
        result = ai.parse_audit(self._payload([
            {"issue": "Real", "evidence": "cta_count=0", "why_it_matters": "w",
             "suggested_improvement": "s", "severity": "high"},
            {"issue": "Made up", "evidence": "", "why_it_matters": "w",
             "suggested_improvement": "s", "severity": "high"},
        ]))

        self.assertEqual([f.issue for f in result.findings], ["Real"])

    def test_more_than_ten_findings_are_capped(self):
        rows = [
            {"issue": f"I{i}", "evidence": "e", "why_it_matters": "w",
             "suggested_improvement": "s", "severity": "medium"}
            for i in range(18)
        ]

        self.assertEqual(len(ai.parse_audit(self._payload(rows)).findings),
                         ai.MAX_FINDINGS)

    def test_no_evidenced_findings_at_all_is_an_error(self):
        with self.assertRaises(ai.AiError) as caught:
            ai.parse_audit(self._payload([
                {"issue": "x", "evidence": "", "why_it_matters": "",
                 "suggested_improvement": ""}]))

        self.assertIn("no findings backed by evidence", str(caught.exception))

    def test_a_finding_round_trips_through_storage(self):
        original = make_findings(1)[0]
        restored = ai.Finding.from_dict(original.as_dict())

        self.assertEqual(restored, original)


class PromptTests(SignedIn):
    def _prompt(self, **overrides):
        kwargs = dict(
            business_name="Bella Cucina", category="Restaurant", city="Delft",
            country="Netherlands", website="https://bella.example",
            sender_name="Sam Rivers", sender_company="Northline",
            sender_email="sam@northline.test",
            service_pitch="We build booking sites.",
            findings=make_findings(3),
            business_summary="A family pizzeria in Delft.",
            site_note="Read 6 pages.",
        )
        kwargs.update(overrides)
        return ai.build_prompt(**kwargs)

    def test_prompt_carries_the_findings_with_their_evidence(self):
        prompt = self._prompt()

        self.assertIn("VERIFIED WEBSITE FINDINGS", prompt)
        self.assertIn("Issue 0", prompt)
        self.assertIn("cta_count=0 on page 0", prompt)
        self.assertIn("Fix: Add a CTA 0", prompt)

    def test_prompt_carries_the_business_facts_and_the_offer(self):
        prompt = self._prompt()

        self.assertIn("Bella Cucina", prompt)
        self.assertIn("A family pizzeria in Delft.", prompt)
        self.assertIn("We build booking sites.", prompt)
        self.assertIn("sam@northline.test", prompt)

    def test_the_offer_falls_back_to_the_configured_default(self):
        prompt = self._prompt(service_pitch="")

        self.assertIn(ai.DEFAULT_OFFER, prompt)

    def test_no_findings_forbids_implying_the_site_was_seen(self):
        prompt = self._prompt(findings=[], site_note="robots.txt disallows")

        self.assertIn("none available", prompt)
        self.assertIn("Do not imply you looked at their website", prompt)
        self.assertIn("robots.txt disallows", prompt)

    def test_regeneration_hint_is_passed_through(self):
        prompt = self._prompt(retry_hint="make it shorter")

        self.assertIn("REVISION NOTE: make it shorter", prompt)

    def test_system_prompt_forbids_invention(self):
        self.assertIn("Never state anything you were not given", ai.SYSTEM)
        self.assertIn("no problems beyond the supplied findings", ai.SYSTEM)

    def test_system_prompt_forbids_narrating_the_crawl(self):
        """The brief is explicit: do not list the pages visited."""
        self.assertIn("Never list the pages visited", ai.SYSTEM)
        self.assertIn("I visited your Home, About", ai.SYSTEM)
        self.assertIn("I noticed your website currently has", ai.SYSTEM)

    def test_system_prompt_limits_the_email_to_one_or_two_findings(self):
        self.assertIn("ONE to THREE of the supplied findings", ai.SYSTEM)
        self.assertIn("Do not paste the whole list", ai.SYSTEM)

    def test_system_prompt_requires_the_offer_to_be_connected(self):
        self.assertIn("Connect that opportunity to what the sender offers",
                      ai.SYSTEM)

    def test_system_prompt_forbids_embellishing_the_offer(self):
        """A live run added "machine learning to prioritize visitors".

        That capability was never in the supplied offer. Inventing how the
        service works is the same failure mode as inventing a website problem,
        so it is now forbidden in the same explicit terms.
        """
        self.assertIn("ONLY in the terms you were given", ai.SYSTEM)
        self.assertIn("Inventing how the service works", ai.SYSTEM)

    def test_audit_system_asks_for_json_explicitly(self):
        """Groq's json_object fallback requires the word in the messages.

        Without it the retry path fails with "'messages' must contain the word
        'json'", turning a recoverable strict-schema miss into a lost lead.
        """
        self.assertIn("JSON", ai.AUDIT_SYSTEM)
        self.assertIn("JSON", ai.SYSTEM)

    def test_schema_requires_the_audit_trail_fields(self):
        self.assertEqual(
            set(ai.SCHEMA["required"]),
            {"subject", "body", "observation", "findings_used"})
        self.assertFalse(ai.SCHEMA["additionalProperties"])

    def test_the_observation_rule_is_stated_in_both_directions(self):
        """A provider swap exposed that "use the site" did not imply "record it".

        Gemini personalised from the website material while reporting
        observation="none", which would have made the review page claim the
        email used no website content. The rule is now explicit both ways.
        """
        self.assertIn('"findings_used" and "observation" are the audit trail',
                      ai.SYSTEM)
        self.assertIn("reporting \"none\" is a wrong answer", ai.SYSTEM)

    def test_findings_used_is_parsed_back(self):
        email = ai.parse(
            '{"subject": "s", "body": "b", "observation": "o",'
            ' "findings_used": ["Issue 0", "Issue 1"]}')

        self.assertEqual(email.findings_used, ["Issue 0", "Issue 1"])

    def test_a_missing_findings_used_defaults_to_empty(self):
        email = ai.parse('{"subject": "s", "body": "b", "observation": "none"}')

        self.assertEqual(email.findings_used, [])

    def test_each_backend_declares_a_sensible_default_model(self):
        self.assertEqual(ai_claude.DEFAULT_MODEL, "claude-opus-5")
        self.assertTrue(ai_gemini.DEFAULT_MODEL.startswith("gemini-"))
        # Groq's default must be one that accepts a strict JSON schema.
        self.assertIn(ai_groq.DEFAULT_MODEL, ai_groq.STRICT_SCHEMA_MODELS)


class ProviderSelectionTests(SignedIn):
    """OUTREACH_AI_PROVIDER picks the backend; everything else is shared."""

    def _with(self, provider=None, model=None):
        import os

        env = {k: v for k, v in os.environ.items()
               if k not in ("OUTREACH_AI_PROVIDER", "OUTREACH_AI_MODEL")}
        if provider is not None:
            env["OUTREACH_AI_PROVIDER"] = provider
        if model is not None:
            env["OUTREACH_AI_MODEL"] = model
        return mock.patch.dict(os.environ, env, clear=True)

    def test_claude_is_the_built_in_default(self):
        with self._with():
            self.assertEqual(ai.provider(), "claude")
            self.assertIs(ai.backend(), ai_claude)
            self.assertEqual(ai.model(), "claude-opus-5")

    def test_gemini_can_be_selected(self):
        with self._with(provider="gemini"):
            self.assertIs(ai.backend(), ai_gemini)
            self.assertEqual(ai.model(), "gemini-3.7-flash")

    def test_groq_can_be_selected(self):
        with self._with(provider="groq"):
            self.assertIs(ai.backend(), ai_groq)
            self.assertEqual(ai.model(), "openai/gpt-oss-120b")

    def test_provider_name_is_case_and_space_insensitive(self):
        with self._with(provider="  GEMINI  "):
            self.assertIs(ai.backend(), ai_gemini)

    def test_an_explicit_model_overrides_the_backend_default(self):
        with self._with(provider="gemini", model="gemini-3.1-pro-preview"):
            self.assertEqual(ai.model(), "gemini-3.1-pro-preview")

    def test_an_unknown_provider_is_a_readable_error(self):
        with self._with(provider="skynet"):
            with self.assertRaises(ai.AiError) as caught:
                ai.backend()

        message = str(caught.exception)
        self.assertIn("skynet", message)
        self.assertIn("claude", message)
        self.assertIn("gemini", message)

    def test_both_backends_satisfy_the_same_interface(self):
        for name in ai.PROVIDERS:
            with self.subTest(provider=name):
                module = ai.load(name)
                self.assertEqual(module.NAME, name)
                self.assertTrue(module.LABEL)
                self.assertTrue(module.DEFAULT_MODEL)
                self.assertTrue(callable(module.describe_credentials))
                self.assertTrue(callable(module.complete))

    def test_backends_are_imported_lazily(self):
        """Running on one provider must not require the other's SDK."""
        import ast
        import inspect

        tree = ast.parse(inspect.getsource(ai))
        top_level = [
            alias.name
            for node in tree.body
            if isinstance(node, (ast.Import, ast.ImportFrom))
            for alias in getattr(node, "names", [])
        ]

        self.assertNotIn("ai_claude", top_level)
        self.assertNotIn("ai_gemini", top_level)

    def test_a_missing_sdk_names_the_package_to_install(self):
        with mock.patch.dict(ai.PROVIDERS,
                             {"ghost": ("outreach.no_such_backend", "ghost-sdk")}):
            with self.assertRaises(ai.AiError) as caught:
                ai.load("ghost")

        message = str(caught.exception)
        self.assertIn("ghost-sdk", message)
        self.assertIn("pip install", message)

    def test_generate_routes_through_the_selected_backend(self):
        payload = ('{"subject": "s", "body": "b", "observation": "o",'
                   ' "findings_used": []}')

        with self._with(provider="gemini"), \
             mock.patch.object(ai_gemini, "complete", return_value=payload) as gem, \
             mock.patch.object(ai_claude, "complete") as claude:
            email = ai.generate(
                business_name="B", category="c", city="Delft", country="NL",
                website="", sender_name="S", sender_company="Co",
                service_pitch="p", findings=[], site_note="n",
            )

        self.assertEqual(email.subject, "s")
        gem.assert_called_once()
        claude.assert_not_called()
        # The shared contract is what reaches the backend, not a per-provider copy.
        self.assertEqual(gem.call_args.kwargs["schema"], ai.SCHEMA)
        self.assertEqual(gem.call_args.kwargs["system"], ai.SYSTEM)


class GeminiCredentialTests(SignedIn):
    def _describe(self, env):
        import os

        clean = {k: v for k, v in os.environ.items()
                 if k not in ai_gemini.KEY_VARS}
        clean.update(env)
        with mock.patch.dict(os.environ, clean, clear=True):
            return ai_gemini.describe_credentials()

    def test_gemini_api_key_is_used(self):
        usable, source, _ = self._describe({"GEMINI_API_KEY": "AQ.xyz"})

        self.assertTrue(usable)
        self.assertIn("GEMINI_API_KEY", source)

    def test_google_api_key_also_works(self):
        usable, source, _ = self._describe({"GOOGLE_API_KEY": "AIza-xyz"})

        self.assertTrue(usable)
        self.assertIn("GOOGLE_API_KEY", source)

    def test_no_key_points_at_ai_studio(self):
        usable, _, advice = self._describe({})

        self.assertFalse(usable)
        self.assertIn("aistudio.google.com", advice)

    def test_an_empty_key_is_caught(self):
        usable, source, _ = self._describe({"GEMINI_API_KEY": "  "})

        self.assertFalse(usable)
        self.assertIn("empty", source)

    def test_the_resolved_key_is_passed_to_the_client(self):
        """The key may have come from Settings, which the SDK cannot discover."""
        resolved = credentials.Credential(
            provider="gemini", source=credentials.DATABASE, key="AIza-resolved")

        with mock.patch.object(credentials, "require", return_value=resolved), \
             mock.patch.object(ai_gemini, "_client", None), \
             mock.patch.object(ai_gemini, "_client_fingerprint", ""), \
             mock.patch.object(ai_gemini.genai, "Client") as build:
            ai_gemini.client()

        self.assertEqual(build.call_args.kwargs["api_key"], "AIza-resolved")


class CredentialTests(SignedIn):
    """Claude credential resolution -- an `ant auth login` profile is enough."""

    ENV_KEYS = ("ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN",
                "ANTHROPIC_PROFILE", "ANTHROPIC_CONFIG_DIR")

    def _describe(self, env=None, profiles=()):
        """Run the Claude backend's describe_credentials() in isolation.

        Targets the backend directly rather than ai.describe_credentials(), which
        dispatches on the configured provider -- otherwise these assertions would
        silently test Gemini whenever .env selects it.
        """
        import os
        import tempfile
        from pathlib import Path

        with tempfile.TemporaryDirectory() as tmp:
            creds = Path(tmp) / "credentials"
            creds.mkdir()
            for name in profiles:
                (creds / f"{name}.json").write_text("{}", encoding="utf-8")

            clean = {k: v for k, v in os.environ.items() if k not in self.ENV_KEYS}
            clean["ANTHROPIC_CONFIG_DIR"] = tmp
            clean.update(env or {})
            with mock.patch.dict(os.environ, clean, clear=True):
                return ai_claude.describe_credentials()

    def test_api_key_is_used_when_present(self):
        usable, source, _ = self._describe({"ANTHROPIC_API_KEY": "sk-ant-xyz"})

        self.assertTrue(usable)
        self.assertIn("ANTHROPIC_API_KEY", source)

    def test_a_stored_cli_profile_is_enough_on_its_own(self):
        usable, source, advice = self._describe(profiles=["default"])

        self.assertTrue(usable)
        self.assertIn("ant CLI profile", source)
        self.assertEqual(advice, "")

    def test_no_credentials_points_at_the_cli_login(self):
        usable, source, advice = self._describe()

        self.assertFalse(usable)
        self.assertIn("no credentials", source)
        self.assertIn("ant auth login", advice)

    def test_an_empty_api_key_shadowing_a_profile_is_caught(self):
        # The trap: an empty key still wins its slot and authenticates with
        # nothing, so a working profile is silently ignored.
        usable, source, advice = self._describe(
            {"ANTHROPIC_API_KEY": ""}, profiles=["default"])

        self.assertFalse(usable)
        self.assertIn("empty", source)
        self.assertIn("takes priority", advice)
        self.assertIn("Remove-Item", advice)

    def test_a_named_profile_that_does_not_exist_is_reported(self):
        usable, source, advice = self._describe(
            {"ANTHROPIC_PROFILE": "work"}, profiles=["default"])

        self.assertFalse(usable)
        self.assertIn("does not exist", source)
        self.assertIn("default", advice)

    def test_a_named_profile_that_exists_is_used(self):
        usable, source, _ = self._describe(
            {"ANTHROPIC_PROFILE": "work"}, profiles=["default", "work"])

        self.assertTrue(usable)
        self.assertIn("work", source)

    def test_auth_token_is_accepted(self):
        usable, source, _ = self._describe({"ANTHROPIC_AUTH_TOKEN": "oauth-token"})

        self.assertTrue(usable)
        self.assertIn("ANTHROPIC_AUTH_TOKEN", source)

    def test_a_cli_profile_is_used_without_passing_a_key(self):
        """The reason this matters: passing api_key= would defeat the profile.

        Asserted behaviourally rather than by reading the source, because the
        answer now depends on which credential the resolver found -- an explicit
        key IS passed when there is one to pass, and must not be when there
        isn't.
        """
        resolved = credentials.Credential(
            provider="claude", source=credentials.CLI_PROFILE, key="",
            detail="ant CLI profile ('default')")

        with mock.patch.object(credentials, "require", return_value=resolved), \
             mock.patch.object(ai_claude, "_client", None), \
             mock.patch.object(ai_claude, "_client_fingerprint", ""), \
             mock.patch.object(ai_claude.anthropic, "Anthropic") as build:
            ai_claude.client()

        self.assertNotIn("api_key", build.call_args.kwargs)
        self.assertNotIn("auth_token", build.call_args.kwargs)
        self.assertIn("max_retries", build.call_args.kwargs)

    def test_a_resolved_key_is_passed_explicitly(self):
        """A key saved in Settings is not in the environment, so the SDK cannot
        find it on its own -- it has to be handed over."""
        resolved = credentials.Credential(
            provider="claude", source=credentials.DATABASE,
            key="sk-ant-from-settings", detail="saved in Settings")

        with mock.patch.object(credentials, "require", return_value=resolved), \
             mock.patch.object(ai_claude, "_client", None), \
             mock.patch.object(ai_claude, "_client_fingerprint", ""), \
             mock.patch.object(ai_claude.anthropic, "Anthropic") as build:
            ai_claude.client()

        self.assertEqual(build.call_args.kwargs["api_key"], "sk-ant-from-settings")

    def test_the_cached_client_is_rebuilt_when_the_key_changes(self):
        """Otherwise a newly saved key would not take effect until a restart."""
        first = credentials.Credential(provider="claude",
                                       source=credentials.DATABASE, key="key-one")
        second = credentials.Credential(provider="claude",
                                        source=credentials.DATABASE, key="key-two")

        with mock.patch.object(ai_claude, "_client", None), \
             mock.patch.object(ai_claude, "_client_fingerprint", ""), \
             mock.patch.object(ai_claude.anthropic, "Anthropic") as build:
            with mock.patch.object(credentials, "require", return_value=first):
                ai_claude.client()
                ai_claude.client()          # same key: no rebuild
            self.assertEqual(build.call_count, 1)

            with mock.patch.object(credentials, "require", return_value=second):
                ai_claude.client()
            self.assertEqual(build.call_count, 2)

    def test_client_refuses_to_build_with_no_credentials(self):
        with mock.patch.dict(os.environ, {}, clear=True):
            with mock.patch.object(ai_claude, "_client", None), \
                 mock.patch.object(ai_claude, "_client_fingerprint", ""), \
                 mock.patch.object(ai_claude, "find_cli_profile",
                                   return_value=(False, "no CLI profile")):
                with self.assertRaises(ai.AiError) as caught:
                    ai_claude.client()

        message = str(caught.exception)
        self.assertIn("no credentials found", message)
        self.assertIn("not configured", message)


class ParseTests(SignedIn):
    """ai.parse() is shared by every provider, so it is tested on its own."""

    def test_valid_json_becomes_a_generated_email(self):
        email = ai.parse(
            '{"subject": "Booking for Bella Cucina", "body": "Hi there.\\n\\nSam",'
            ' "observation": "wood-fired pizza since 1998"}'
        )

        self.assertEqual(email.subject, "Booking for Bella Cucina")
        self.assertIn("Sam", email.body)
        self.assertEqual(email.observation, "wood-fired pizza since 1998")

    def test_a_fenced_code_block_is_unwrapped(self):
        # Some models wrap JSON in ```json despite being told not to.
        email = ai.parse(
            '```json\n{"subject": "s", "body": "b", "observation": "o"}\n```')

        self.assertEqual(email.subject, "s")

    def test_malformed_json_is_an_error(self):
        with self.assertRaises(ai.AiError):
            ai.parse("not json at all")

    def test_empty_text_is_an_error(self):
        with self.assertRaises(ai.AiError):
            ai.parse("   ")

    def test_a_json_array_is_an_error(self):
        with self.assertRaises(ai.AiError):
            ai.parse('["not", "an", "object"]')

    def test_empty_subject_is_an_error(self):
        with self.assertRaises(ai.AiError):
            ai.parse('{"subject": "", "body": "x", "observation": "y"}')

    def test_missing_observation_defaults_to_none(self):
        self.assertEqual(
            ai.parse('{"subject": "s", "body": "b", "observation": ""}').observation,
            "none",
        )


class ClaudeBackendTests(SignedIn):
    """Claude-specific transport: refusals and truncation."""

    def _response(self, text, stop_reason="end_turn", details=None):
        block = mock.Mock(type="text", text=text)
        return mock.Mock(content=[block], stop_reason=stop_reason,
                         stop_details=details)

    def _complete(self, response):
        with mock.patch.object(ai_claude, "_create", return_value=response):
            return ai_claude.complete(
                system="sys", prompt="prompt", schema=ai.SCHEMA,
                model="claude-opus-5",
            )

    def test_text_is_returned_for_the_shared_parser(self):
        payload = '{"subject": "s", "body": "b", "observation": "o"}'

        self.assertEqual(self._complete(self._response(payload)), payload)

    def test_refusal_is_reported_not_read_as_content(self):
        response = self._response("", stop_reason="refusal",
                                  details=mock.Mock(category="cyber"))

        with self.assertRaises(ai.AiError) as caught:
            self._complete(response)

        self.assertIn("declined", str(caught.exception))
        self.assertIn("cyber", str(caught.exception))

    def test_truncated_reply_is_an_error(self):
        with self.assertRaises(ai.AiError) as caught:
            self._complete(self._response('{"subject": "x"',
                                          stop_reason="max_tokens"))

        self.assertIn("cut off", str(caught.exception))

    def test_the_schema_and_effort_reach_the_request(self):
        captured = {}

        def fake_create(request):
            captured.update(request)
            return self._response('{"subject": "s", "body": "b", "observation": "o"}')

        with mock.patch.object(ai_claude, "_create", side_effect=fake_create):
            ai_claude.complete(system="sys", prompt="p", schema=ai.SCHEMA,
                               model="claude-opus-5")

        fmt = captured["output_config"]["format"]
        self.assertEqual(fmt["type"], "json_schema")
        self.assertEqual(fmt["schema"], ai.SCHEMA)
        self.assertEqual(captured["output_config"]["effort"], ai_claude.EFFORT)
        self.assertEqual(captured["system"], "sys")


class GroqCredentialTests(SignedIn):
    def _describe(self, env):
        import os

        clean = {k: v for k, v in os.environ.items() if k not in ai_groq.KEY_VARS}
        clean.update(env)
        with mock.patch.dict(os.environ, clean, clear=True):
            return ai_groq.describe_credentials()

    def test_groq_api_key_is_used(self):
        usable, source, _ = self._describe({"GROQ_API_KEY": "gsk_xyz"})

        self.assertTrue(usable)
        self.assertIn("GROQ_API_KEY", source)

    def test_no_key_points_at_the_console(self):
        usable, _, advice = self._describe({})

        self.assertFalse(usable)
        self.assertIn("console.groq.com", advice)

    def test_an_empty_key_is_caught(self):
        usable, source, _ = self._describe({"GROQ_API_KEY": "  "})

        self.assertFalse(usable)
        self.assertIn("empty", source)

    def test_the_resolved_key_is_passed_to_the_client(self):
        """The key may have come from Settings, which the SDK cannot discover."""
        resolved = credentials.Credential(
            provider="groq", source=credentials.DATABASE, key="gsk_resolved")

        with mock.patch.object(credentials, "require", return_value=resolved), \
             mock.patch.object(ai_groq, "_client", None), \
             mock.patch.object(ai_groq, "_client_fingerprint", ""), \
             mock.patch.object(ai_groq.groq, "Groq") as build:
            ai_groq.client()

        self.assertEqual(build.call_args.kwargs["api_key"], "gsk_resolved")


class GroqBackendTests(SignedIn):
    """Groq-specific transport: response_format selection and error mapping."""

    def _reply(self, content, finish_reason="stop"):
        message = mock.Mock(content=content)
        choice = mock.Mock(message=message, finish_reason=finish_reason)
        return mock.Mock(choices=[choice])

    def _complete(self, reply=None, error=None, model="openai/gpt-oss-120b"):
        client = mock.Mock()
        if error is not None:
            client.chat.completions.create.side_effect = error
        else:
            client.chat.completions.create.return_value = reply
        with mock.patch.object(ai_groq, "client", return_value=client):
            return ai_groq.complete(
                system="sys", prompt="prompt", schema=ai.SCHEMA, model=model,
            ), client

    PAYLOAD = '{"subject": "s", "body": "b", "observation": "o"}'

    def test_message_content_is_returned(self):
        text, _ = self._complete(self._reply(self.PAYLOAD))

        self.assertEqual(text, self.PAYLOAD)

    def test_a_gpt_oss_model_gets_a_strict_json_schema(self):
        _, client = self._complete(self._reply(self.PAYLOAD))

        kwargs = client.chat.completions.create.call_args.kwargs
        fmt = kwargs["response_format"]
        self.assertEqual(fmt["type"], "json_schema")
        self.assertTrue(fmt["json_schema"]["strict"])
        self.assertEqual(fmt["json_schema"]["schema"], ai.SCHEMA)
        # System and user prompts go in as separate messages.
        self.assertEqual([m["role"] for m in kwargs["messages"]],
                         ["system", "user"])
        self.assertEqual(kwargs["messages"][0]["content"], "sys")

    def test_another_model_falls_back_to_json_object_mode(self):
        # strict schemas are GPT-OSS-only, so a Llama model must not request one
        # -- that would be a hard 400 instead of a slightly looser guarantee.
        _, client = self._complete(self._reply(self.PAYLOAD),
                                   model="llama-3.3-70b-versatile")

        fmt = client.chat.completions.create.call_args.kwargs["response_format"]
        self.assertEqual(fmt, {"type": "json_object"})

    def test_response_format_helper_matches_the_model_list(self):
        for model in ai_groq.STRICT_SCHEMA_MODELS:
            with self.subTest(model=model):
                self.assertEqual(
                    ai_groq._response_format(ai.SCHEMA, model)["type"],
                    "json_schema",
                )
        self.assertEqual(
            ai_groq._response_format(ai.SCHEMA, "something-else")["type"],
            "json_object",
        )

    def test_truncation_is_reported(self):
        with self.assertRaises(ai.AiError) as caught:
            self._complete(self._reply('{"subject"', finish_reason="length"))

        self.assertIn("cut off", str(caught.exception))

    def test_empty_content_is_reported(self):
        with self.assertRaises(ai.AiError) as caught:
            self._complete(self._reply(""))

        self.assertIn("no text", str(caught.exception))

    def test_no_choices_is_reported(self):
        with self.assertRaises(ai.AiError) as caught:
            self._complete(mock.Mock(choices=[]))

        self.assertIn("no choices", str(caught.exception))

    def test_a_bad_key_is_reported_clearly(self):
        error = groq_errors.AuthenticationError.__new__(
            groq_errors.AuthenticationError)

        with self.assertRaises(ai.AiError) as caught:
            self._complete(error=error)

        self.assertIn("rejected the API key", str(caught.exception))
        self.assertIn("console.groq.com", str(caught.exception))

    def test_rate_limiting_is_reported_clearly(self):
        error = groq_errors.RateLimitError.__new__(groq_errors.RateLimitError)

        with self.assertRaises(ai.AiError) as caught:
            self._complete(error=error)

        self.assertIn("rate limit", str(caught.exception).lower())

    def test_an_unknown_model_names_the_setting_to_fix(self):
        error = groq_errors.NotFoundError.__new__(groq_errors.NotFoundError)

        with self.assertRaises(ai.AiError) as caught:
            self._complete(error=error, model="no-such-model")

        self.assertIn("OUTREACH_AI_MODEL", str(caught.exception))

    def test_a_network_failure_is_wrapped(self):
        error = groq_errors.APIConnectionError.__new__(
            groq_errors.APIConnectionError)

        with self.assertRaises(ai.AiError) as caught:
            self._complete(error=error)

        self.assertIn("Could not reach", str(caught.exception))


class GeminiBackendTests(SignedIn):
    """Gemini-specific transport: response shape and error mapping."""

    def _complete(self, interaction=None, error=None):
        client = mock.Mock()
        if error is not None:
            client.interactions.create.side_effect = error
        else:
            client.interactions.create.return_value = interaction
        with mock.patch.object(ai_gemini, "client", return_value=client):
            return ai_gemini.complete(
                system="sys", prompt="prompt", schema=ai.SCHEMA,
                model="gemini-3.7-flash",
            ), client

    def test_output_text_is_returned(self):
        payload = '{"subject": "s", "body": "b", "observation": "o"}'
        interaction = mock.Mock(output_text=payload, status="completed", errors=None)

        text, _ = self._complete(interaction)

        self.assertEqual(text, payload)

    def test_the_request_uses_the_documented_response_format(self):
        interaction = mock.Mock(output_text='{"subject":"s","body":"b","observation":"o"}',
                                status="completed", errors=None)

        _, client = self._complete(interaction)

        kwargs = client.interactions.create.call_args.kwargs
        self.assertEqual(kwargs["model"], "gemini-3.7-flash")
        self.assertEqual(kwargs["system_instruction"], "sys")
        self.assertEqual(kwargs["input"], "prompt")
        text_format = kwargs["response_format"]["text"]
        self.assertEqual(text_format["mime_type"], "application/json")
        self.assertEqual(text_format["schema"], ai.SCHEMA)

    def test_empty_output_is_reported_as_a_block_not_parsed(self):
        interaction = mock.Mock(output_text="", status="blocked", errors=None)

        with self.assertRaises(ai.AiError) as caught:
            self._complete(interaction)

        self.assertIn("no text", str(caught.exception))
        self.assertIn("safety", str(caught.exception))

    def test_a_bad_key_is_reported_clearly(self):
        error = genai_errors.ClientError.__new__(genai_errors.ClientError)
        error.message = "API_KEY_INVALID"
        error.status = "INVALID_ARGUMENT"

        with self.assertRaises(ai.AiError) as caught:
            self._complete(error=error)

        self.assertIn("rejected the API key", str(caught.exception))
        self.assertIn("aistudio.google.com", str(caught.exception))

    def test_quota_exhaustion_is_reported_clearly(self):
        error = genai_errors.ClientError.__new__(genai_errors.ClientError)
        error.message = "Quota exceeded for requests"
        error.status = "RESOURCE_EXHAUSTED"

        with self.assertRaises(ai.AiError) as caught:
            self._complete(error=error)

        self.assertIn("quota", str(caught.exception).lower())

    def test_a_server_error_asks_for_a_retry(self):
        error = genai_errors.ServerError.__new__(genai_errors.ServerError)
        error.message = "internal"
        error.status = "INTERNAL"

        with self.assertRaises(ai.AiError) as caught:
            self._complete(error=error)

        self.assertIn("retry", str(caught.exception).lower())

    def test_a_network_failure_is_wrapped(self):
        with self.assertRaises(ai.AiError) as caught:
            self._complete(error=OSError("dns failure"))

        self.assertIn("Could not reach", str(caught.exception))


# --------------------------------------------------------------------------- #
# Sending
# --------------------------------------------------------------------------- #

class MessageTests(SignedIn):
    def test_from_header_is_the_authenticated_address(self):
        message = sender.build_message(
            sender_name="Sam Rivers", sender_email="sam@agency.test",
            to_email="ciao@bella.example", subject="Hello", body="Body text",
        )

        self.assertEqual(message["From"], "Sam Rivers <sam@agency.test>")
        self.assertEqual(message["To"], "ciao@bella.example")
        self.assertEqual(message["Subject"], "Hello")
        self.assertIn("mailto:sam@agency.test", message["List-Unsubscribe"])
        self.assertTrue(message.get_content().startswith("Body text"))


class ReplyLineTests(SignedIn):
    """The standing reply invitation, added to every outgoing email."""

    def _build(self, body):
        return sender.build_message(
            sender_name="Sam Rivers", sender_email="sam@agency.test",
            to_email="ciao@bella.example", subject="Hello", body=body,
        ).get_content()

    def test_every_message_carries_it(self):
        content = self._build("Hi there,\n\nShort note.\n\nSam")

        self.assertIn(sender.REPLY_LINE, content)
        # Its own paragraph at the end, not glued to the sign-off.
        self.assertTrue(content.rstrip().endswith(sender.REPLY_LINE))
        self.assertIn("Sam\n\n" + sender.REPLY_LINE, content)

    def test_it_is_not_added_twice_when_the_body_already_has_it(self):
        body = f"Hi there,\n\n{sender.REPLY_LINE}\n\nSam"
        content = self._build(body)

        self.assertEqual(content.count(sender.REPLY_LINE), 1)
        # And it stays where the user put it.
        self.assertTrue(content.rstrip().endswith("Sam"))

    def test_a_re_wrapped_copy_still_counts_as_present(self):
        wrapped = sender.REPLY_LINE.replace(" and ", " and\n", 1)
        content = self._build(f"Hi there,\n\n{wrapped}\n\nSam")

        self.assertNotIn(f"\n\n{sender.REPLY_LINE}\n", content)

    def test_an_empty_body_still_gets_the_line(self):
        self.assertEqual(sender.with_reply_line(""), sender.REPLY_LINE + "\n")

    def test_it_survives_an_edited_draft(self):
        """Added at send time, so no edit or regeneration can drop it."""
        content = self._build("A hand-written replacement with no CTA at all.")

        self.assertIn(sender.REPLY_LINE, content)


class PasswordNormalisationTests(SignedIn):
    """Gmail shows app passwords spaced but expects them bare."""

    def test_a_spaced_gmail_app_password_is_de_spaced(self):
        self.assertEqual(
            sender.normalise_password("abcd efgh ijkl mnop"), "abcdefghijklmnop")

    def test_an_already_bare_app_password_is_unchanged(self):
        self.assertEqual(
            sender.normalise_password("abcdefghijklmnop"), "abcdefghijklmnop")

    def test_surrounding_whitespace_is_trimmed(self):
        self.assertEqual(sender.normalise_password("  secret  "), "secret")

    def test_a_normal_password_containing_a_space_is_left_alone(self):
        # Only the exact 4x4 app-password shape is de-spaced, so a real
        # passphrase keeps its spaces.
        self.assertEqual(
            sender.normalise_password("correct horse battery staple"),
            "correct horse battery staple",
        )

    def test_case_is_preserved(self):
        self.assertEqual(
            sender.normalise_password("ABCD efgh IJKL mnop"), "ABCDefghIJKLmnop")

    def test_the_session_normalises_what_it_is_given(self):
        session = sender.Session(
            sender.PROVIDERS["gmail"], "sam@agency.test", "abcd efgh ijkl mnop")

        self.assertEqual(session.password, "abcdefghijklmnop")

    def test_empty_stays_empty_and_is_refused(self):
        self.assertEqual(sender.normalise_password("   "), "")
        with self.assertRaises(sender.SendError):
            sender.Session(sender.PROVIDERS["gmail"], "sam@agency.test", "  ")


class EnvFileTests(SignedIn):
    """The .env loader keeps the live password out of settings.py."""

    def _load(self, text: str, existing: dict | None = None) -> dict:
        import os
        import tempfile
        from pathlib import Path

        from leadmapper import settings as project_settings

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / ".env"
            path.write_text(text, encoding="utf-8")
            base = {k: v for k, v in os.environ.items()
                    if not k.startswith("ZZ_TEST_")}
            base.update(existing or {})
            with mock.patch.dict(os.environ, base, clear=True):
                project_settings._load_env(path)
                return {k: v for k, v in os.environ.items()
                        if k.startswith("ZZ_TEST_")}

    def test_key_values_are_loaded(self):
        loaded = self._load("ZZ_TEST_A=hello\nZZ_TEST_B=world\n")

        self.assertEqual(loaded, {"ZZ_TEST_A": "hello", "ZZ_TEST_B": "world"})

    def test_comments_and_blank_lines_are_ignored(self):
        loaded = self._load("# a comment\n\nZZ_TEST_A=hello\n")

        self.assertEqual(loaded, {"ZZ_TEST_A": "hello"})

    def test_values_containing_spaces_survive(self):
        loaded = self._load("ZZ_TEST_A=abcd efgh ijkl mnop\n")

        self.assertEqual(loaded["ZZ_TEST_A"], "abcd efgh ijkl mnop")

    def test_quotes_are_stripped(self):
        loaded = self._load('ZZ_TEST_A="quoted"\n')

        self.assertEqual(loaded["ZZ_TEST_A"], "quoted")

    def test_a_real_environment_variable_wins(self):
        # CI and one-off shell overrides must beat the file.
        loaded = self._load("ZZ_TEST_A=from-file\n",
                            existing={"ZZ_TEST_A": "from-env"})

        self.assertEqual(loaded["ZZ_TEST_A"], "from-env")

    def test_a_missing_file_is_not_an_error(self):
        from pathlib import Path

        from leadmapper import settings as project_settings

        project_settings._load_env(Path("no-such-file-here.env"))  # must not raise


class ConfiguredIdentityTests(SignedIn):
    """The one address the app is set up to use."""

    def test_both_addresses_are_configured_and_look_like_addresses(self):
        """They serve different purposes and may legitimately differ.

        OSM_CONTACT_EMAIL is advertised in the User-Agent when fetching data;
        OUTREACH_SENDER_EMAIL is the From header and the SMTP login. Using a
        role address for crawling and a personal one for sending is a reasonable
        setup, so this checks both are usable rather than that they match.
        """
        for name in ("OUTREACH_SENDER_EMAIL", "OSM_CONTACT_EMAIL"):
            with self.subTest(setting=name):
                value = getattr(settings, name)
                self.assertTrue(value, f"{name} must be set")
                self.assertRegex(value, r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
                self.assertNotIn("example.com", value)

    def test_the_provider_matches_the_address_domain(self):
        domain = settings.OUTREACH_SENDER_EMAIL.rsplit("@", 1)[-1].lower()
        if domain in ("gmail.com", "googlemail.com"):
            self.assertEqual(settings.OUTREACH_PROVIDER, "gmail")

    def test_no_password_is_hardcoded_in_settings(self):
        """The live password must live in .env, never in tracked source."""
        from pathlib import Path

        source = (Path(settings.BASE_DIR) / "leadmapper" / "settings.py").read_text(
            encoding="utf-8")

        self.assertNotIn("OUTREACH_SMTP_PASSWORD =", source)
        self.assertIn("_load_env", source)


class SessionTests(SignedIn):
    def test_sender_address_must_match_the_login(self):
        with self.assertRaises(sender.SendError) as caught:
            sender.Session(
                sender.PROVIDERS["gmail"], "boss@bigcorp.test", "pw",
                username="sam@agency.test",
            )

        self.assertIn("spoofing", str(caught.exception))

    def test_matching_address_and_login_is_accepted(self):
        session = sender.Session(
            sender.PROVIDERS["gmail"], "Sam@Agency.test", "pw",
            username="sam@agency.test",
        )

        self.assertEqual(session.host, "smtp.gmail.com")
        self.assertEqual(session.port, 587)

    def test_missing_password_is_refused(self):
        with self.assertRaises(sender.SendError):
            sender.Session(sender.PROVIDERS["gmail"], "sam@agency.test", "")

    def test_custom_provider_needs_a_host(self):
        with self.assertRaises(sender.SendError):
            sender.Session(sender.PROVIDERS["custom"], "sam@agency.test", "pw")

    def test_custom_provider_accepts_an_explicit_host(self):
        session = sender.Session(
            sender.PROVIDERS["custom"], "sam@agency.test", "pw",
            host="mail.agency.test", port=465,
        )

        self.assertEqual((session.host, session.port), ("mail.agency.test", 465))

    def test_every_provider_has_a_delay_and_a_cap(self):
        for key, provider in sender.PROVIDERS.items():
            with self.subTest(provider=key):
                self.assertGreater(provider.delay, 0)
                self.assertGreater(provider.daily_cap, 0)


class FakeSession:
    """Records sends; can be told to fail for specific recipients."""

    def __init__(self, fail_for=(), raise_on_enter=None):
        self.fail_for = set(fail_for)
        self.raise_on_enter = raise_on_enter
        self.sent: list[str] = []

    def __enter__(self):
        if self.raise_on_enter:
            raise self.raise_on_enter
        return self

    def __exit__(self, *exc_info):
        return False

    def send(self, *, to_email, subject, body, sender_name):
        if to_email in self.fail_for:
            raise smtplib.SMTPRecipientsRefused({to_email: (550, b"No such user")})
        self.sent.append(to_email)


class BulkSendTests(SignedIn):
    """runner._send_all -- the loop that must not stop on one bad address."""

    def setUp(self):
        self.campaign = make_campaign()
        self.drafts = [
            make_draft(self.campaign, business_name=f"Shop {i}",
                       email=f"shop{i}@example.test",
                       status=EmailDraft.Status.APPROVED)
            for i in range(4)
        ]

    def _run(self, session):
        with mock.patch.object(sender, "Session", return_value=session), \
             mock.patch.object(runner.time, "sleep"):
            runner._send_all(self.campaign, "pw", "", 0)
        self.campaign.refresh_from_db()

    def test_all_approved_emails_are_sent(self):
        session = FakeSession()
        self._run(session)

        self.assertEqual(len(session.sent), 4)
        self.assertEqual(self.campaign.counts()["sent"], 4)
        self.assertEqual(self.campaign.phase, Campaign.Phase.DONE)

    def test_one_rejected_recipient_does_not_stop_the_rest(self):
        session = FakeSession(fail_for={"shop1@example.test"})
        self._run(session)

        counts = self.campaign.counts()
        self.assertEqual(counts["sent"], 3)
        self.assertEqual(counts["failed"], 1)
        self.assertEqual(len(session.sent), 3)

        failed = self.campaign.drafts.get(email="shop1@example.test")
        self.assertEqual(failed.status, EmailDraft.Status.FAILED)
        self.assertIn("SMTPRecipientsRefused", failed.error_message)

    def test_sent_drafts_record_a_timestamp_and_no_error(self):
        self._run(FakeSession())
        draft = self.campaign.drafts.filter(status=EmailDraft.Status.SENT).first()

        self.assertIsNotNone(draft.sent_at)
        self.assertEqual(draft.error_message, "")

    def test_auth_failure_stops_the_run_and_explains_itself(self):
        session = FakeSession(raise_on_enter=sender.SendError("login rejected"))
        self._run(session)

        self.assertEqual(self.campaign.counts()["sent"], 0)
        self.assertIn("login rejected", self.campaign.error)
        self.assertEqual(self.campaign.phase, Campaign.Phase.DONE)
        # Nothing was consumed -- the drafts are still approved and sendable.
        self.assertEqual(self.campaign.counts()["approved"], 4)

    def test_daily_cap_stops_sending_and_says_what_is_left(self):
        capped = sender.Provider(
            "gmail", "Gmail", "smtp.gmail.com", 587, delay=0, daily_cap=2,
            note="test cap",
        )
        session = FakeSession()

        with mock.patch.dict(sender.PROVIDERS, {"gmail": capped}), \
             mock.patch.object(sender, "Session", return_value=session), \
             mock.patch.object(runner.time, "sleep"):
            runner._send_all(self.campaign, "pw", "", 0)

        self.campaign.refresh_from_db()
        self.assertEqual(len(session.sent), 2)
        self.assertEqual(self.campaign.counts()["sent"], 2)
        self.assertEqual(self.campaign.counts()["approved"], 2)
        self.assertIn("daily cap", self.campaign.error.lower())

    def test_sent_today_counts_only_todays_sends(self):
        draft = self.drafts[0]
        draft.status = EmailDraft.Status.SENT
        draft.sent_at = timezone.now()
        draft.save()

        self.assertEqual(runner.sent_today("sam@agency.test"), 1)
        self.assertEqual(runner.sent_today("someone@else.test"), 0)


class DoubleSendGuardTests(SignedIn):
    """The brief's "do not send the same campaign to the same lead twice"."""

    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(self.campaign, status=EmailDraft.Status.APPROVED)

    def test_a_draft_can_only_be_claimed_once(self):
        self.assertTrue(runner._claim_draft(self.draft.pk))
        # A second claim -- a double-click, or a second thread -- finds nothing.
        self.assertFalse(runner._claim_draft(self.draft.pk))

    def test_an_already_sent_draft_cannot_be_claimed(self):
        EmailDraft.objects.filter(pk=self.draft.pk).update(
            status=EmailDraft.Status.SENT)

        self.assertFalse(runner._claim_draft(self.draft.pk))

    def test_a_second_send_run_sends_nothing_new(self):
        session_one, session_two = FakeSession(), FakeSession()

        for session in (session_one, session_two):
            with mock.patch.object(sender, "Session", return_value=session), \
                 mock.patch.object(runner.time, "sleep"):
                runner._send_all(self.campaign, "pw", "", 0)

        self.assertEqual(len(session_one.sent), 1)
        self.assertEqual(len(session_two.sent), 0)
        self.campaign.refresh_from_db()
        self.assertEqual(self.campaign.counts()["sent"], 1)

    def test_one_email_cannot_enter_the_same_campaign_twice(self):
        from django.db import IntegrityError, transaction

        with self.assertRaises(IntegrityError):
            with transaction.atomic():
                make_draft(self.campaign, business_name="Copycat")

    def test_leads_without_an_email_do_not_collide(self):
        make_draft(self.campaign, business_name="A", email="",
                   status=EmailDraft.Status.NO_EMAIL)
        make_draft(self.campaign, business_name="B", email="",
                   status=EmailDraft.Status.NO_EMAIL)

        self.assertEqual(self.campaign.drafts.filter(email="").count(), 2)


# --------------------------------------------------------------------------- #
# Views
# --------------------------------------------------------------------------- #

@override_settings(ALLOWED_HOSTS=["*"])
class StartTests(SignedIn):
    def _post(self, leads, **extra):
        body = {"leads": leads, "area": {"city": "Delft", "country": "NL"},
                "category": "Restaurants"}
        body.update(extra)
        return self.client.post(reverse("outreach:start"), data=body,
                                content_type="application/json")

    def test_leads_become_drafts_and_return_a_setup_url(self):
        response = self._post([
            {"business_name": "A", "email": "a@x.test", "website": "https://a.test"},
            {"business_name": "B", "email": "b@x.test"},
        ])

        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["eligible"], 2)
        self.assertIn("/setup", data["setup_url"])

        campaign = Campaign.objects.get(pk=data["campaign_id"])
        self.assertEqual(campaign.city, "Delft")
        self.assertEqual(campaign.drafts.count(), 2)

    def test_leads_without_an_email_are_marked_not_dropped(self):
        response = self._post([
            {"business_name": "A", "email": "a@x.test"},
            {"business_name": "No Email", "email": ""},
            {"business_name": "Bad Email", "email": "not-an-address"},
        ])

        campaign = Campaign.objects.get(pk=response.json()["campaign_id"])
        self.assertEqual(response.json()["eligible"], 1)
        self.assertEqual(campaign.drafts.count(), 3)
        self.assertEqual(
            campaign.drafts.filter(status=EmailDraft.Status.NO_EMAIL).count(), 2)

    def test_two_leads_sharing_an_address_keep_only_the_first(self):
        response = self._post([
            {"business_name": "Branch A", "email": "same@x.test"},
            {"business_name": "Branch B", "email": "same@x.test"},
        ])

        campaign = Campaign.objects.get(pk=response.json()["campaign_id"])
        self.assertEqual(response.json()["eligible"], 1)
        self.assertEqual(
            campaign.drafts.filter(status=EmailDraft.Status.DUPLICATE).count(), 1)

    def test_empty_selection_is_a_400(self):
        self.assertEqual(self._post([]).status_code, 400)

    def test_oversized_selection_is_a_400(self):
        leads = [{"business_name": f"B{i}", "email": f"b{i}@x.test"}
                 for i in range(400)]

        self.assertEqual(self._post(leads).status_code, 400)


@override_settings(ALLOWED_HOSTS=["*"])
class RunTests(SignedIn):
    def setUp(self):
        self.campaign = make_campaign(phase=Campaign.Phase.SETUP,
                                      sender_name="", sender_email="",
                                      provider="", service_pitch="")
        self.a = make_draft(self.campaign, business_name="A", email="a@x.test",
                            status=EmailDraft.Status.PENDING)
        self.b = make_draft(self.campaign, business_name="B", email="b@x.test",
                            status=EmailDraft.Status.PENDING)

    def _post(self, **overrides):
        body = {
            "sender_name": "Sam Rivers",
            "sender_email": "sam@agency.test",
            "sender_company": "Northline",
            "provider": "gmail",
            "service_pitch": "We build booking websites for restaurants.",
            "selected": [self.a.pk, self.b.pk],
        }
        body.update(overrides)
        return self.client.post(
            reverse("outreach:run", args=[self.campaign.id]),
            data=body, content_type="application/json",
        )

    def test_valid_settings_save_and_start_the_pipeline(self):
        with mock.patch.object(runner, "start_pipeline", return_value=True) as start:
            response = self._post()

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["queued"], 2)
        start.assert_called_once()

        self.campaign.refresh_from_db()
        self.assertEqual(self.campaign.sender_email, "sam@agency.test")
        self.assertEqual(self.campaign.provider, "gmail")

    def test_deselected_leads_are_excluded_not_deleted(self):
        with mock.patch.object(runner, "start_pipeline", return_value=True):
            self._post(selected=[self.a.pk])

        self.b.refresh_from_db()
        self.assertEqual(self.b.status, EmailDraft.Status.EXCLUDED)
        self.assertEqual(self.campaign.drafts.count(), 2)

    def test_missing_sender_name_is_a_400(self):
        self.assertEqual(self._post(sender_name="").status_code, 400)

    def test_invalid_sender_email_is_a_400(self):
        self.assertEqual(self._post(sender_email="nope").status_code, 400)

    def test_unknown_provider_is_a_400(self):
        self.assertEqual(self._post(provider="carrier-pigeon").status_code, 400)

    def test_thin_service_description_is_a_400(self):
        response = self._post(service_pitch="stuff")

        self.assertEqual(response.status_code, 400)
        self.assertIn("what you offer", response.json()["error"])

    def test_empty_selection_is_a_400(self):
        self.assertEqual(self._post(selected=[]).status_code, 400)

    def test_a_started_campaign_cannot_be_restarted(self):
        Campaign.objects.filter(pk=self.campaign.pk).update(
            phase=Campaign.Phase.REVIEW)

        self.assertEqual(self._post().status_code, 409)


@override_settings(ALLOWED_HOSTS=["*"])
class SenderDefaultsTests(SignedIn):
    """The configured identity pre-fills the form; a campaign keeps its own."""

    def setUp(self):
        self.campaign = make_campaign(phase=Campaign.Phase.SETUP,
                                      sender_name="", sender_email="",
                                      sender_company="", provider="")
        make_draft(self.campaign, status=EmailDraft.Status.PENDING)

    def _setup_page(self):
        return self.client.get(reverse("outreach:setup", args=[self.campaign.id]))

    def test_configured_sender_is_prefilled(self):
        response = self._setup_page()

        self.assertEqual(response.status_code, 200)
        body = response.content.decode()
        self.assertIn(f'value="{settings.OUTREACH_SENDER_EMAIL}"', body)
        self.assertIn(f'value="{settings.OUTREACH_SENDER_NAME}"', body)

    def test_configured_provider_is_preselected(self):
        body = self._setup_page().content.decode()

        self.assertIn(f'value="{settings.OUTREACH_PROVIDER}" selected', body)

    @override_settings(OUTREACH_SENDER_EMAIL="other@example.test",
                       OUTREACH_SENDER_NAME="Other Person")
    def test_settings_drive_the_prefill(self):
        body = self._setup_page().content.decode()

        self.assertIn('value="other@example.test"', body)
        self.assertIn('value="Other Person"', body)

    def test_a_campaign_with_its_own_sender_keeps_it(self):
        Campaign.objects.filter(pk=self.campaign.pk).update(
            sender_email="oneoff@agency.test", sender_name="One Off")

        body = self._setup_page().content.decode()

        self.assertIn('value="oneoff@agency.test"', body)
        self.assertNotIn(settings.OUTREACH_SENDER_EMAIL, body)

    def test_the_default_provider_matches_the_default_address(self):
        # A gmail.com address configured against an Outlook host would fail
        # authentication on the first send, so keep the two in step.
        domain = settings.OUTREACH_SENDER_EMAIL.rsplit("@", 1)[-1].lower()
        if domain in ("gmail.com", "googlemail.com"):
            self.assertEqual(settings.OUTREACH_PROVIDER, "gmail")
        self.assertIn(settings.OUTREACH_PROVIDER, sender.PROVIDERS)

    def test_the_submitted_sender_is_what_gets_stored(self):
        draft = self.campaign.drafts.first()
        with mock.patch.object(runner, "start_pipeline", return_value=True):
            self.client.post(
                reverse("outreach:run", args=[self.campaign.id]),
                data={
                    "sender_name": settings.OUTREACH_SENDER_NAME,
                    "sender_email": settings.OUTREACH_SENDER_EMAIL,
                    "sender_company": "Northline",
                    "provider": settings.OUTREACH_PROVIDER,
                    "service_pitch": "We build booking websites for restaurants.",
                    "selected": [draft.pk],
                },
                content_type="application/json",
            )

        self.campaign.refresh_from_db()
        self.assertEqual(self.campaign.sender_email, settings.OUTREACH_SENDER_EMAIL)
        self.assertEqual(self.campaign.provider, settings.OUTREACH_PROVIDER)

    def test_sending_from_the_configured_address_is_not_spoofing(self):
        session = sender.Session(
            sender.PROVIDERS[settings.OUTREACH_PROVIDER],
            settings.OUTREACH_SENDER_EMAIL, "app-password",
        )
        message = sender.build_message(
            sender_name=settings.OUTREACH_SENDER_NAME,
            sender_email=settings.OUTREACH_SENDER_EMAIL,
            to_email="lead@example.test", subject="Hi", body="Body",
        )

        self.assertEqual(session.username, settings.OUTREACH_SENDER_EMAIL)
        self.assertIn(settings.OUTREACH_SENDER_EMAIL, message["From"])


@override_settings(ALLOWED_HOSTS=["*"])
class DraftActionTests(SignedIn):
    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(self.campaign)

    def _act(self, action, **body):
        return self.client.post(
            reverse("outreach:draft_action", args=[self.draft.pk, action]),
            data=body, content_type="application/json",
        )

    def test_save_records_an_edit(self):
        response = self._act("save", subject="New subject", body="New body")

        self.assertEqual(response.status_code, 200)
        self.draft.refresh_from_db()
        self.assertEqual(self.draft.subject, "New subject")
        self.assertTrue(self.draft.edited)

    def test_save_rejects_empty_content(self):
        self.assertEqual(self._act("save", subject="", body="x").status_code, 400)

    def test_approve_moves_the_draft_to_approved(self):
        self._act("approve")
        self.draft.refresh_from_db()

        self.assertEqual(self.draft.status, EmailDraft.Status.APPROVED)

    def test_reject_moves_the_draft_to_rejected(self):
        self._act("reject")
        self.draft.refresh_from_db()

        self.assertEqual(self.draft.status, EmailDraft.Status.REJECTED)

    def test_regenerate_replaces_the_email_and_counts_the_attempt(self):
        new = ai.GeneratedEmail("Fresh subject", "Fresh body", "their menu page")

        with mock.patch.object(ai, "generate", return_value=new) as generate:
            response = self._act("regenerate", hint="shorter")

        self.assertEqual(response.status_code, 200)
        self.draft.refresh_from_db()
        self.assertEqual(self.draft.subject, "Fresh subject")
        self.assertEqual(self.draft.regenerations, 1)
        self.assertEqual(generate.call_args.kwargs["retry_hint"], "shorter")

    def test_regenerate_failure_returns_the_reason(self):
        with mock.patch.object(ai, "generate",
                               side_effect=ai.AiError("no API key")):
            response = self._act("regenerate")

        self.assertEqual(response.status_code, 502)
        self.assertIn("no API key", response.json()["error"])

    def test_a_sent_draft_cannot_be_edited(self):
        EmailDraft.objects.filter(pk=self.draft.pk).update(
            status=EmailDraft.Status.SENT)

        self.assertEqual(self._act("save", subject="x", body="y").status_code, 409)

    def test_unknown_action_is_a_400(self):
        self.assertEqual(self._act("detonate").status_code, 400)


@override_settings(ALLOWED_HOSTS=["*"])
class WorkspaceViewTests(SignedIn):
    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(self.campaign)

    def test_state_reports_counts_and_drafts(self):
        response = self.client.get(
            reverse("outreach:state", args=[self.campaign.id]))

        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["campaign"]["phase"], "review")
        self.assertEqual(len(data["drafts"]), 1)
        self.assertEqual(data["drafts"][0]["business_name"], "Bella Cucina")
        self.assertEqual(data["counts"]["total"], 1)

    def test_state_separates_leads_that_cannot_be_emailed(self):
        make_draft(self.campaign, business_name="No Email", email="",
                   status=EmailDraft.Status.NO_EMAIL)

        data = self.client.get(
            reverse("outreach:state", args=[self.campaign.id])).json()

        self.assertEqual(len(data["drafts"]), 1)
        self.assertEqual(len(data["skipped"]), 1)

    def test_state_flags_an_address_contacted_in_an_earlier_campaign(self):
        older = make_campaign()
        make_draft(older, email="ciao@bella.example",
                   status=EmailDraft.Status.SENT, sent_at=timezone.now())

        data = self.client.get(
            reverse("outreach:state", args=[self.campaign.id])).json()

        self.assertTrue(data["drafts"][0]["previously_contacted"])

    def test_approve_all_approves_every_drafted_email(self):
        make_draft(self.campaign, business_name="Second", email="two@x.test")
        make_draft(self.campaign, business_name="Rejected", email="three@x.test",
                   status=EmailDraft.Status.REJECTED)

        response = self.client.post(
            reverse("outreach:approve_all", args=[self.campaign.id]))

        self.assertEqual(response.json()["approved"], 2)
        self.assertEqual(response.json()["counts"]["approved"], 2)

    def test_workspace_page_renders(self):
        response = self.client.get(
            reverse("outreach:workspace", args=[self.campaign.id]))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Review &amp; send")

    def test_workspace_carries_the_hooks_the_progress_panel_needs(self):
        response = self.client.get(
            reverse("outreach:workspace", args=[self.campaign.id]))

        # workspace.js looks these up by id; a rename here breaks the panel
        # silently, which is exactly the kind of thing a test should catch.
        for element_id in ("run", "run-position", "run-total", "run-current",
                           "run-pct", "run-bar", "run-seg", "run-steps",
                           "run-next", "run-queue", "run-leads"):
            self.assertContains(response, f'id="{element_id}"')

    def test_setup_redirects_once_the_campaign_has_started(self):
        response = self.client.get(
            reverse("outreach:setup", args=[self.campaign.id]))

        self.assertEqual(response.status_code, 302)

    def test_report_page_lists_outcomes(self):
        EmailDraft.objects.filter(pk=self.draft.pk).update(
            status=EmailDraft.Status.SENT, sent_at=timezone.now())

        response = self.client.get(
            reverse("outreach:report", args=[self.campaign.id]))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Bella Cucina")
        self.assertContains(response, "ciao@bella.example")

    def test_history_page_lists_campaigns(self):
        response = self.client.get(reverse("outreach:history"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Restaurants")


@override_settings(ALLOWED_HOSTS=["*"])
class SendViewTests(SignedIn):
    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(self.campaign, status=EmailDraft.Status.APPROVED)

    def _post(self, **body):
        return self.client.post(
            reverse("outreach:send", args=[self.campaign.id]),
            data=body, content_type="application/json",
        )

    def test_send_starts_the_background_run(self):
        with mock.patch.object(runner, "start_send", return_value=True) as start:
            response = self._post(password="app-password")

        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["started"])
        self.assertEqual(start.call_args[0][1], "app-password")

    def test_missing_password_is_a_400(self):
        # OUTREACH_SMTP_PASSWORD is set for real use, and the view falls back to
        # it -- so clear it to test the genuinely-unconfigured case.
        import os

        env = {k: v for k, v in os.environ.items() if k != "OUTREACH_SMTP_PASSWORD"}
        with mock.patch.dict(os.environ, env, clear=True):
            response = self._post(password="")

        self.assertEqual(response.status_code, 400)
        self.assertIn("password", response.json()["error"].lower())

    def test_the_env_password_is_used_when_the_form_leaves_it_blank(self):
        import os

        with mock.patch.dict(os.environ, {"OUTREACH_SMTP_PASSWORD": "from-env"}), \
             mock.patch.object(runner, "start_send", return_value=True) as start:
            response = self._post(password="")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(start.call_args[0][1], "from-env")

    def test_password_is_never_written_to_the_database(self):
        with mock.patch.object(runner, "start_send", return_value=True):
            self._post(password="super-secret")

        self.campaign.refresh_from_db()
        blob = " ".join(
            str(v) for v in Campaign.objects.filter(pk=self.campaign.pk).values()[0].values()
        )
        self.assertNotIn("super-secret", blob)

    def test_nothing_approved_is_a_400(self):
        EmailDraft.objects.filter(pk=self.draft.pk).update(
            status=EmailDraft.Status.GENERATED)

        response = self._post(password="pw")

        self.assertEqual(response.status_code, 400)
        self.assertIn("Approve at least one", response.json()["error"])

    def test_a_running_campaign_is_a_409(self):
        with mock.patch.object(runner, "is_running", return_value=True):
            response = self._post(password="pw")

        self.assertEqual(response.status_code, 409)


class SendBlockTests(SignedIn):
    """The suite must not be able to open a real SMTP connection."""

    def test_sending_is_blocked_while_running_tests(self):
        self.assertTrue(
            settings.OUTREACH_BLOCK_SEND,
            "OUTREACH_BLOCK_SEND must be on under `manage.py test` -- real "
            "credentials live in .env and a stray send would mail live people.",
        )

    def test_entering_a_session_refuses_to_connect(self):
        session = sender.Session(
            sender.PROVIDERS["gmail"], "sam@agency.test", "app-password")

        with self.assertRaises(sender.SendError) as caught:
            with session:
                pass

        self.assertIn("blocked", str(caught.exception).lower())

    def test_a_real_send_run_reports_the_block_instead_of_sending(self):
        campaign = make_campaign()
        make_draft(campaign, status=EmailDraft.Status.APPROVED)

        with mock.patch.object(runner.time, "sleep"):
            runner._send_all(campaign, "app-password", "", 0)

        campaign.refresh_from_db()
        self.assertEqual(campaign.counts()["sent"], 0)
        self.assertIn("blocked", campaign.error.lower())
        # The draft is untouched and still sendable for real later.
        self.assertEqual(campaign.counts()["approved"], 1)

    @override_settings(OUTREACH_BLOCK_SEND=False)
    def test_the_block_can_be_lifted_for_real_use(self):
        session = sender.Session(
            sender.PROVIDERS["custom"], "sam@agency.test", "pw",
            host="127.0.0.1", port=1,
        )

        # Not blocked any more, so it gets as far as a connection attempt --
        # which fails, because nothing is listening on that port.
        with self.assertRaises(sender.SendError) as caught:
            with session:
                pass

        self.assertIn("Could not connect", str(caught.exception))


class PipelineTests(SignedIn):
    """crawl -> review -> generate, with all three externals stubbed."""

    def setUp(self):
        self.campaign = make_campaign(phase=Campaign.Phase.SETUP)
        self.draft = make_draft(self.campaign, subject="", body="",
                                observation="", analysis_context="",
                                analysis_status="",
                                status=EmailDraft.Status.PENDING)

    def _analysis(self, status=analyzer.OK, pages=2):
        return analyzer.SiteAnalysis(
            status, f"Read {pages} page(s).",
            [analyzer.Page(f"https://bella.example/{i}", "home" if not i else "services",
                           "Bella Cucina", "", ["Wood-fired pizza"],
                           "Hand-made sourdough.", {"cta_count": 0})
             for i in range(pages)],
            discovered=11,
        ) if status == analyzer.OK else analyzer.SiteAnalysis(status, "blocked.")

    def _audit(self):
        return ai.SiteAudit("A family pizzeria.", make_findings(9))

    def _email(self):
        return ai.GeneratedEmail(
            "Booking for Bella Cucina", "Hi.\n\nSam", "no call to action",
            ["Issue 0"])

    def test_all_three_stages_run_and_land_in_review(self):
        with mock.patch.object(analyzer, "analyse", return_value=self._analysis()), \
             mock.patch.object(ai, "audit", return_value=self._audit()), \
             mock.patch.object(ai, "generate", return_value=self._email()):
            runner._pipeline(self.campaign)

        self.campaign.refresh_from_db()
        self.draft.refresh_from_db()
        self.assertEqual(self.campaign.phase, Campaign.Phase.REVIEW)
        self.assertEqual(self.draft.status, EmailDraft.Status.GENERATED)
        self.assertEqual(self.draft.subject, "Booking for Bella Cucina")
        self.assertEqual(len(self.draft.findings), 9)
        self.assertEqual(self.draft.business_summary, "A family pizzeria.")
        self.assertEqual(self.draft.findings_used, ["Issue 0"])
        self.assertEqual(self.draft.pages_discovered, 11)
        self.assertEqual(len(self.draft.pages_read), 2)

    def test_the_review_receives_the_crawled_context_not_the_raw_url(self):
        with mock.patch.object(analyzer, "analyse", return_value=self._analysis()), \
             mock.patch.object(ai, "audit", return_value=self._audit()) as audit, \
             mock.patch.object(ai, "generate", return_value=self._email()):
            runner._pipeline(self.campaign)

        kwargs = audit.call_args.kwargs
        self.assertIn("cta_count=0", kwargs["site_context"])
        self.assertEqual(kwargs["pages_read"], 2)
        self.assertEqual(kwargs["discovered"], 11)

    def test_the_email_stage_receives_the_ranked_shortlist(self):
        """Not all nine findings -- the two or three worth an email.

        Ten findings in a prompt produce an email that mentions three of them
        badly. The commercial ranking happens in `scoring`, and the email stage
        receives only its shortlist, so the prompt is built on the findings that
        matter to the business rather than on everything that was measurable.
        """
        with mock.patch.object(analyzer, "analyse", return_value=self._analysis()), \
             mock.patch.object(ai, "audit", return_value=self._audit()), \
             mock.patch.object(ai, "generate", return_value=self._email()) as generate:
            runner._pipeline(self.campaign)

        kwargs = generate.call_args.kwargs
        findings = kwargs["findings"]
        self.assertEqual(len(findings), scoring.EMAIL_FINDING_LIMIT)
        self.assertIsInstance(findings[0], ai.Finding)
        self.assertEqual(kwargs["business_summary"], "A family pizzeria.")

    def test_the_email_stage_receives_the_structured_evidence(self):
        """Section 5: not just a URL -- the pages read, and what was measured."""
        with mock.patch.object(analyzer, "analyse", return_value=self._analysis()), \
             mock.patch.object(ai, "audit", return_value=self._audit()), \
             mock.patch.object(ai, "generate", return_value=self._email()) as generate:
            runner._pipeline(self.campaign)

        kwargs = generate.call_args.kwargs
        self.assertTrue(kwargs["pages"])
        self.assertTrue(all("url" in page for page in kwargs["pages"]))
        self.assertIn("cta_count", kwargs["signals"])

    def test_a_blocked_website_skips_the_review_and_still_emails(self):
        with mock.patch.object(analyzer, "analyse",
                               return_value=self._analysis(analyzer.BLOCKED)), \
             mock.patch.object(ai, "audit") as audit, \
             mock.patch.object(ai, "generate",
                               return_value=ai.GeneratedEmail("Q", "Hi", "none", [])) as generate:
            runner._pipeline(self.campaign)

        self.draft.refresh_from_db()
        self.assertEqual(self.draft.analysis_status, analyzer.BLOCKED)
        self.assertEqual(self.draft.status, EmailDraft.Status.GENERATED)
        # No material means no review call at all, and no findings to email from.
        audit.assert_not_called()
        self.assertEqual(generate.call_args.kwargs["findings"], [])
        self.assertEqual(self.draft.findings, [])
        self.assertEqual(self.draft.observation, "none")

    def test_a_failed_review_still_lets_the_email_stage_run(self):
        with mock.patch.object(analyzer, "analyse", return_value=self._analysis()), \
             mock.patch.object(ai, "audit", side_effect=ai.AiError("quota")), \
             mock.patch.object(ai, "generate",
                               return_value=ai.GeneratedEmail("Q", "Hi", "none", [])):
            runner._pipeline(self.campaign)

        self.draft.refresh_from_db()
        self.assertEqual(self.draft.status, EmailDraft.Status.GENERATED)
        self.assertEqual(self.draft.findings, [])

    def test_generation_failure_surfaces_on_the_campaign(self):
        with mock.patch.object(analyzer, "analyse",
                               return_value=self._analysis(analyzer.NO_WEBSITE)), \
             mock.patch.object(ai, "generate",
                               side_effect=ai.AiError("Set GROQ_API_KEY")):
            runner._pipeline(self.campaign)

        self.campaign.refresh_from_db()
        self.draft.refresh_from_db()
        self.assertEqual(self.campaign.phase, Campaign.Phase.REVIEW)
        self.assertIn("GROQ_API_KEY", self.campaign.error)
        self.assertIn("GROQ_API_KEY", self.draft.error_message)


class SequentialPipelineTests(SignedIn):
    """One lead all the way through, then the next. Never batched by stage."""

    NAMES = (("Alpha Cafe", "alpha"), ("Beta Bakery", "beta"),
             ("Gamma Grill", "gamma"))

    def setUp(self):
        self.campaign = make_campaign(phase=Campaign.Phase.SETUP)
        for name, slug in self.NAMES:
            make_draft(
                self.campaign, business_name=name,
                email=f"hi@{slug}.example", website=f"https://{slug}.example",
                subject="", body="", observation="", analysis_context="",
                analysis_status="", status=EmailDraft.Status.PENDING,
            )
        self.calls = []

    def _analysis(self, url, status=analyzer.OK):
        if status != analyzer.OK:
            return analyzer.SiteAnalysis(status, "Website unavailable.")
        return analyzer.SiteAnalysis(
            status, "Read 2 page(s).",
            [analyzer.Page(f"{url}/{kind}", kind, "Title", "", ["Heading"],
                           "Some prose.", {"cta_count": 0})
             for kind in ("home", "services")],
            discovered=7,
        )

    def _run(self, analyse=None, audit=None, generate=None):
        """Run the pipeline with the three externals recording their order."""
        def default_analyse(url, **kwargs):
            # **kwargs swallows `should_stop`, which the pipeline now passes so
            # a cancel can interrupt a crawl between page fetches.
            self.calls.append(("analyse", url))
            return self._analysis(url)

        def default_audit(**kwargs):
            self.calls.append(("audit", kwargs["website"]))
            return ai.SiteAudit("A local eatery.", make_findings(9))

        def default_generate(**kwargs):
            self.calls.append(("generate", kwargs["website"]))
            return ai.GeneratedEmail(
                f"A quick idea for {kwargs['business_name']}",
                "Hi there,\n\nSam", "no call to action", ["Issue 0"])

        with mock.patch.object(analyzer, "analyse",
                               side_effect=analyse or default_analyse), \
             mock.patch.object(ai, "audit", side_effect=audit or default_audit), \
             mock.patch.object(ai, "generate",
                               side_effect=generate or default_generate):
            runner._pipeline(self.campaign)

    def test_each_lead_is_finished_before_the_next_one_is_started(self):
        self._run()

        # The whole point: no lead's crawl happens before the previous lead's
        # email has been written.
        self.assertEqual(self.calls, [
            ("analyse", "https://alpha.example"),
            ("audit", "https://alpha.example"),
            ("generate", "https://alpha.example"),
            ("analyse", "https://beta.example"),
            ("audit", "https://beta.example"),
            ("generate", "https://beta.example"),
            ("analyse", "https://gamma.example"),
            ("audit", "https://gamma.example"),
            ("generate", "https://gamma.example"),
        ])

    def test_the_running_order_is_stamped_and_every_lead_is_marked_saved(self):
        self._run()

        rows = list(self.campaign.drafts.order_by("sequence")
                    .values_list("sequence", "business_name"))
        self.assertEqual(rows, [(1, "Alpha Cafe"), (2, "Beta Bakery"),
                                (3, "Gamma Grill")])
        for draft in self.campaign.drafts.all():
            self.assertIsNotNone(draft.processed_at, draft.business_name)
            self.assertEqual(draft.status, EmailDraft.Status.GENERATED)
            self.assertTrue(draft.subject)
            self.assertEqual(len(draft.findings), 9)

        # Nothing is left claiming to be in flight.
        self.campaign.refresh_from_db()
        self.assertEqual(self.campaign.phase, Campaign.Phase.REVIEW)
        self.assertIsNone(self.campaign.current_draft_id)
        self.assertEqual(self.campaign.current_step, "")

    def test_progress_names_the_lead_and_the_step_in_flight(self):
        seen = {}

        def generate(**kwargs):
            if kwargs["business_name"] == "Beta Bakery":
                # Snapshot what the progress panel would be told, mid-run.
                seen.update(Campaign.objects.get(pk=self.campaign.pk).progress())
            return ai.GeneratedEmail("Subject", "Body", "none", [])

        self._run(generate=generate)

        self.assertEqual(seen["total"], 3)
        self.assertEqual(seen["done"], 1)
        self.assertEqual(seen["position"], 2)
        self.assertEqual(seen["percent"], 67)
        self.assertEqual(seen["step"], "generate")
        self.assertEqual(seen["current"]["business_name"], "Beta Bakery")
        self.assertEqual(seen["current"]["website"], "https://beta.example")
        self.assertEqual(seen["next"]["business_name"], "Gamma Grill")
        self.assertFalse(seen["finished"])
        self.assertEqual([step["state"] for step in seen["steps"]],
                         ["done", "done", "current", "waiting", "waiting"])
        self.assertEqual([lead["state"] for lead in seen["leads"]],
                         ["completed", "current", "waiting"])

    def test_progress_reads_as_complete_once_the_run_finishes(self):
        self._run()

        progress = Campaign.objects.get(pk=self.campaign.pk).progress()
        self.assertEqual(progress["position"], 3)
        self.assertEqual(progress["percent"], 100)
        self.assertTrue(progress["finished"])
        self.assertIsNone(progress["current"])
        self.assertIsNone(progress["next"])
        self.assertEqual({lead["state"] for lead in progress["leads"]},
                         {"completed"})
        self.assertEqual([step["state"] for step in progress["steps"]],
                         ["done"] * len(progress["steps"]))

    def test_an_unreachable_website_does_not_stop_the_campaign(self):
        def analyse(url, **kwargs):
            self.calls.append(("analyse", url))
            status = analyzer.BLOCKED if "beta" in url else analyzer.OK
            return self._analysis(url, status)

        self._run(analyse=analyse)

        # Nothing was reviewed for Beta -- there was no material to review --
        # but the other two leads were processed normally either side of it.
        self.assertEqual([url for kind, url in self.calls if kind == "audit"],
                         ["https://alpha.example", "https://gamma.example"])
        self.assertEqual(
            [url for kind, url in self.calls if kind == "generate"],
            ["https://alpha.example", "https://beta.example",
             "https://gamma.example"])

        beta = self.campaign.drafts.get(business_name="Beta Bakery")
        self.assertEqual(beta.analysis_status, analyzer.BLOCKED)
        self.assertEqual(beta.findings, [])
        self.assertTrue(beta.subject)            # still got an email
        self.assertIsNotNone(beta.processed_at)  # and was saved and moved past
        self.assertEqual(beta.status, EmailDraft.Status.GENERATED)

        self.campaign.refresh_from_db()
        self.assertEqual(self.campaign.phase, Campaign.Phase.REVIEW)
        self.assertEqual(self.campaign.error, "")

    def test_one_failed_email_leaves_the_other_leads_drafted(self):
        def generate(**kwargs):
            if kwargs["business_name"] == "Beta Bakery":
                raise ai.AiError("rate limited")
            return ai.GeneratedEmail("Subject", "Body", "none", [])

        self._run(generate=generate)

        beta = self.campaign.drafts.get(business_name="Beta Bakery")
        self.assertEqual(beta.subject, "")
        self.assertIn("rate limited", beta.error_message)
        self.assertIsNotNone(beta.processed_at)

        others = self.campaign.drafts.exclude(business_name="Beta Bakery")
        for draft in others:
            self.assertEqual(draft.status, EmailDraft.Status.GENERATED)
            self.assertTrue(draft.subject)

        # One failure out of three is not a campaign-level error.
        self.campaign.refresh_from_db()
        self.assertEqual(self.campaign.error, "")

        progress = Campaign.objects.get(pk=self.campaign.pk).progress()
        states = {lead["business_name"]: lead["state"]
                  for lead in progress["leads"]}
        self.assertEqual(states["Beta Bakery"], "failed")
        self.assertEqual(states["Alpha Cafe"], "completed")


class ResumeTests(SignedIn):
    """Picking up a run whose background thread died with the server."""

    NAMES = (("Alpha Cafe", "alpha"), ("Beta Bakery", "beta"),
             ("Gamma Grill", "gamma"))

    def setUp(self):
        self.campaign = make_campaign(phase=Campaign.Phase.CRAWLING)
        self.drafts = {}
        for position, (name, slug) in enumerate(self.NAMES, start=1):
            self.drafts[name] = make_draft(
                self.campaign, business_name=name,
                email=f"hi@{slug}.example", website=f"https://{slug}.example",
                subject="", body="", observation="", analysis_context="",
                analysis_status="", status=EmailDraft.Status.PENDING,
                sequence=position,
            )
        self.calls = []

    def _finish(self, name, **fields):
        """Mark a lead as already completed by an earlier, interrupted run."""
        fields.setdefault("processed_at", timezone.now())
        EmailDraft.objects.filter(pk=self.drafts[name].pk).update(**fields)

    def _run(self):
        def analyse(url, **kwargs):
            self.calls.append(("analyse", url))
            return analyzer.SiteAnalysis(
                analyzer.OK, "Read 1 page(s).",
                [analyzer.Page(url, "home", "T", "", ["H"], "prose",
                               {"cta_count": 0})],
                discovered=4)

        def audit(**kwargs):
            self.calls.append(("audit", kwargs["website"]))
            return ai.SiteAudit("A cafe.", make_findings(9))

        def generate(**kwargs):
            self.calls.append(("generate", kwargs["website"]))
            # A valid reply: it names what it used. An email that reports
            # "observation: none" while holding findings is a wrong answer and
            # would (correctly) be regenerated once.
            return ai.GeneratedEmail(
                "Subject", "Body", "no obvious way to get in touch",
                ["Issue 0"])

        with mock.patch.object(analyzer, "analyse", side_effect=analyse), \
             mock.patch.object(ai, "audit", side_effect=audit), \
             mock.patch.object(ai, "generate", side_effect=generate):
            runner._pipeline(self.campaign, resume=True)

    # --- detection -------------------------------------------------------- #

    def test_a_working_phase_with_no_thread_is_stalled(self):
        for phase in (Campaign.Phase.CRAWLING, Campaign.Phase.ANALYSING,
                      Campaign.Phase.GENERATING):
            with self.subTest(phase=phase):
                self.campaign.phase = phase
                self.assertEqual(runner.stalled(self.campaign), "pipeline")

    def test_a_stalled_send_is_reported_separately(self):
        self.campaign.phase = Campaign.Phase.SENDING
        self.assertEqual(runner.stalled(self.campaign), "send")

    def test_a_finished_or_waiting_campaign_is_not_stalled(self):
        for phase in (Campaign.Phase.SETUP, Campaign.Phase.REVIEW,
                      Campaign.Phase.DONE, Campaign.Phase.FAILED):
            with self.subTest(phase=phase):
                self.campaign.phase = phase
                self.assertEqual(runner.stalled(self.campaign), "")

    def test_a_running_campaign_is_not_stalled(self):
        with mock.patch.object(runner, "is_running", return_value=True):
            self.assertEqual(runner.stalled(self.campaign), "")

    # --- what a resumed run does and does not repeat ----------------------- #

    def test_finished_leads_are_not_crawled_or_drafted_again(self):
        self._finish("Alpha Cafe", status=EmailDraft.Status.GENERATED,
                     subject="Already written")

        self._run()

        self.assertEqual([url for _kind, url in self.calls], [
            "https://beta.example", "https://beta.example",
            "https://beta.example", "https://gamma.example",
            "https://gamma.example", "https://gamma.example",
        ])
        # And the finished lead's email was left exactly as it was.
        self.drafts["Alpha Cafe"].refresh_from_db()
        self.assertEqual(self.drafts["Alpha Cafe"].subject, "Already written")

    def test_a_lead_interrupted_after_its_crawl_is_not_crawled_again(self):
        EmailDraft.objects.filter(pk=self.drafts["Alpha Cafe"].pk).update(
            status=EmailDraft.Status.CRAWLED,
            analysis_context="### PAGE 1 -- HOME\nMeasured signals: cta_count=0",
            analysis_status=analyzer.OK,
        )
        self._finish("Beta Bakery", status=EmailDraft.Status.GENERATED,
                     subject="Done")
        self._finish("Gamma Grill", status=EmailDraft.Status.GENERATED,
                     subject="Done")

        self._run()

        # The crawl is the expensive part and it was already paid for.
        self.assertEqual(self.calls, [
            ("audit", "https://alpha.example"),
            ("generate", "https://alpha.example"),
        ])

    def test_a_lead_interrupted_after_its_review_only_needs_the_email(self):
        EmailDraft.objects.filter(pk=self.drafts["Alpha Cafe"].pk).update(
            status=EmailDraft.Status.ANALYSED,
            analysis_context="### PAGE 1 -- HOME",
            findings=[f.as_dict() for f in make_findings(4)],
        )
        for name in ("Beta Bakery", "Gamma Grill"):
            self._finish(name, status=EmailDraft.Status.GENERATED, subject="Done")

        self._run()

        self.assertEqual(self.calls, [("generate", "https://alpha.example")])
        self.drafts["Alpha Cafe"].refresh_from_db()
        self.assertEqual(len(self.drafts["Alpha Cafe"].findings), 4)

    def test_a_lead_that_only_missed_its_completion_stamp_costs_nothing(self):
        EmailDraft.objects.filter(pk=self.drafts["Alpha Cafe"].pk).update(
            status=EmailDraft.Status.GENERATED, subject="Written already",
        )
        for name in ("Beta Bakery", "Gamma Grill"):
            self._finish(name, status=EmailDraft.Status.GENERATED, subject="Done")

        self._run()

        self.assertEqual(self.calls, [])
        self.drafts["Alpha Cafe"].refresh_from_db()
        self.assertIsNotNone(self.drafts["Alpha Cafe"].processed_at)
        self.assertEqual(self.drafts["Alpha Cafe"].subject, "Written already")

    def test_the_running_order_is_kept_rather_than_restamped(self):
        self._finish("Alpha Cafe", status=EmailDraft.Status.GENERATED,
                     subject="Done")

        self._run()

        rows = dict(self.campaign.drafts.values_list("business_name", "sequence"))
        self.assertEqual(rows, {"Alpha Cafe": 1, "Beta Bakery": 2,
                                "Gamma Grill": 3})

    def test_the_run_lands_back_in_review_with_nothing_in_flight(self):
        self._run()

        self.campaign.refresh_from_db()
        self.assertEqual(self.campaign.phase, Campaign.Phase.REVIEW)
        self.assertIsNone(self.campaign.current_draft_id)
        self.assertEqual(self.campaign.current_step, "")

    def test_a_lead_unblocked_after_the_run_is_given_a_place_at_the_end(self):
        """"Contact anyway" clears the sequence; the resumed run assigns one."""
        for name in ("Alpha Cafe", "Beta Bakery", "Gamma Grill"):
            self._finish(name, status=EmailDraft.Status.GENERATED, subject="Done")
        late = make_draft(self.campaign, business_name="Delta Deli",
                          email="hi@delta.example", website="https://delta.example",
                          subject="", body="", analysis_context="",
                          analysis_status="", status=EmailDraft.Status.PENDING,
                          sequence=0, force_contact=True,
                          force_reason="different business, same name")

        self._run()

        late.refresh_from_db()
        self.assertEqual(late.sequence, 4)
        self.assertEqual(late.status, EmailDraft.Status.GENERATED)
        self.assertIsNotNone(late.processed_at)
        self.assertEqual([url for _kind, url in self.calls],
                         ["https://delta.example"] * 3)


class ResumeEndpointTests(SignedIn):
    """POST /outreach/<id>/resume."""

    def setUp(self):
        self.campaign = make_campaign(phase=Campaign.Phase.CRAWLING)
        self.draft = make_draft(self.campaign, subject="", body="",
                                status=EmailDraft.Status.PENDING, sequence=1)

    def _post(self):
        return self.client.post(
            reverse("outreach:resume", args=[self.campaign.id]))

    def test_a_stalled_pipeline_is_restarted_in_resume_mode(self):
        with mock.patch.object(runner, "start_pipeline",
                               return_value=True) as start:
            response = self._post()

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["resumed"], "pipeline")
        self.assertEqual(response.json()["remaining"], 1)
        self.assertTrue(start.call_args.kwargs["resume"])

    def test_a_campaign_that_is_not_stalled_is_refused(self):
        Campaign.objects.filter(pk=self.campaign.pk).update(
            phase=Campaign.Phase.REVIEW)

        response = self._post()

        self.assertEqual(response.status_code, 400)
        self.assertIn("nothing to resume", response.json()["error"])

    def test_a_running_campaign_is_refused(self):
        with mock.patch.object(runner, "is_running", return_value=True):
            response = self._post()

        self.assertEqual(response.status_code, 409)

    def test_a_stalled_send_releases_the_queue_instead_of_resending(self):
        """The password is never stored, so a send cannot resume itself."""
        Campaign.objects.filter(pk=self.campaign.pk).update(
            phase=Campaign.Phase.SENDING)
        stuck = make_draft(self.campaign, business_name="Stuck Co",
                           email="stuck@x.example", website="https://x.example",
                           status=EmailDraft.Status.SENDING)

        with mock.patch.object(runner, "start_pipeline") as start:
            response = self._post()

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["resumed"], "send")
        self.assertEqual(response.json()["released"], 1)
        start.assert_not_called()

        stuck.refresh_from_db()
        self.campaign.refresh_from_db()
        self.assertEqual(stuck.status, EmailDraft.Status.APPROVED)
        self.assertEqual(self.campaign.phase, Campaign.Phase.REVIEW)
        self.assertIn("interrupted", self.campaign.error)

    def test_the_state_endpoint_reports_the_stall(self):
        response = self.client.get(
            reverse("outreach:state", args=[self.campaign.id]))

        self.assertEqual(response.json()["campaign"]["stalled"], "pipeline")


class AiRetryTests(SignedIn):
    """One retry for a transient AI failure, none for a permanent one."""

    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(self.campaign, subject="", body="",
                                observation="")
        self.email = ai.GeneratedEmail("Subject", "Body", "none", [])

    def _generate(self, side_effect, **kwargs):
        with mock.patch.object(runner, "AI_RETRY_DELAY", 0), \
             mock.patch.object(ai, "generate", side_effect=side_effect) as call:
            ok = runner.generate_draft(self.draft, self.campaign, **kwargs)
        return ok, call

    def test_a_transient_failure_is_retried_and_can_succeed(self):
        ok, call = self._generate(
            [ai.AiError("rate limited", retryable=True), self.email],
            retries=1)

        self.assertTrue(ok)
        self.assertEqual(call.call_count, 2)
        self.draft.refresh_from_db()
        self.assertEqual(self.draft.subject, "Subject")
        self.assertEqual(self.draft.error_message, "")

    def test_a_permanent_failure_is_not_retried(self):
        ok, call = self._generate(
            ai.AiError("Set GROQ_API_KEY in .env"), retries=1)

        self.assertFalse(ok)
        self.assertEqual(call.call_count, 1)
        self.draft.refresh_from_db()
        self.assertIn("GROQ_API_KEY", self.draft.error_message)

    def test_the_retry_is_given_up_after_one_attempt(self):
        ok, call = self._generate(
            ai.AiError("still rate limited", retryable=True), retries=1)

        self.assertFalse(ok)
        self.assertEqual(call.call_count, 2)
        self.draft.refresh_from_db()
        self.assertIn("still rate limited", self.draft.error_message)

    def test_the_interactive_path_does_not_retry(self):
        """A user waiting on a click gets the error, not a silent 20s pause."""
        ok, call = self._generate(
            [ai.AiError("rate limited", retryable=True), self.email])

        self.assertFalse(ok)
        self.assertEqual(call.call_count, 1)

    def test_the_review_stage_retries_too(self):
        self.draft.analysis_context = "### PAGE 1 -- HOME"
        self.draft.save(update_fields=["analysis_context"])
        audit = ai.SiteAudit("A cafe.", make_findings(5))

        with mock.patch.object(runner, "AI_RETRY_DELAY", 0), \
             mock.patch.object(ai, "audit",
                              side_effect=[ai.AiError("429", retryable=True),
                                           audit]) as call:
            runner.review_draft(self.draft, retries=1)

        self.assertEqual(call.call_count, 2)
        self.draft.refresh_from_db()
        self.assertEqual(len(self.draft.findings), 5)

    def test_the_pipeline_asks_for_a_retry(self):
        EmailDraft.objects.filter(pk=self.draft.pk).update(
            status=EmailDraft.Status.PENDING, analysis_context="",
            analysis_status="")
        self.draft.refresh_from_db()

        with mock.patch.object(runner, "AI_RETRY_DELAY", 0), \
             mock.patch.object(analyzer, "analyse", return_value=analyzer.SiteAnalysis(
                 analyzer.NO_WEBSITE, "no website")), \
             mock.patch.object(ai, "generate",
                               side_effect=[ai.AiError("429", retryable=True),
                                            self.email]) as call:
            runner._pipeline(self.campaign)

        self.assertEqual(call.call_count, 2)
        self.draft.refresh_from_db()
        self.assertEqual(self.draft.status, EmailDraft.Status.GENERATED)

    def test_backends_mark_rate_limits_as_retryable(self):
        self.assertTrue(ai.AiError("x", retryable=True).retryable)
        self.assertFalse(ai.AiError("x").retryable)


class ProgressStateTests(SignedIn):
    """What /state hands the progress panel while a run is in flight."""

    def setUp(self):
        self.campaign = make_campaign(phase=Campaign.Phase.ANALYSING)
        self.done = make_draft(
            self.campaign, business_name="Alpha Cafe", email="a@alpha.example",
            sequence=1, processed_at=timezone.now(),
            status=EmailDraft.Status.GENERATED)
        self.current = make_draft(
            self.campaign, business_name="Beta Bakery", email="b@beta.example",
            sequence=2, subject="", body="", status=EmailDraft.Status.PENDING)
        self.waiting = make_draft(
            self.campaign, business_name="Gamma Grill", email="c@gamma.example",
            sequence=3, subject="", body="", status=EmailDraft.Status.PENDING)
        self.campaign.current_draft = self.current
        self.campaign.current_step = "review"
        self.campaign.save(update_fields=["current_draft", "current_step"])

    def _state(self):
        response = self.client.get(
            reverse("outreach:state", args=[self.campaign.id]))
        self.assertEqual(response.status_code, 200)
        return response.json()

    def test_progress_is_exposed_for_the_panel(self):
        progress = self._state()["progress"]
        self.assertEqual(progress["total"], 3)
        self.assertEqual(progress["done"], 1)
        self.assertEqual(progress["position"], 2)
        self.assertEqual(progress["current"]["business_name"], "Beta Bakery")
        self.assertEqual(progress["step"], "review")
        # Five steps now: crawl, review, generate, score, save.
        self.assertEqual([step["state"] for step in progress["steps"]],
                         ["done", "current", "waiting", "waiting", "waiting"])
        self.assertEqual(progress["next"]["business_name"], "Gamma Grill")

    def test_only_leads_the_run_has_reached_get_a_card(self):
        started = {draft["business_name"]: draft["started"]
                   for draft in self._state()["drafts"]}
        self.assertTrue(started["Alpha Cafe"])    # finished
        self.assertTrue(started["Beta Bakery"])   # in flight
        self.assertFalse(started["Gamma Grill"])  # still queued

    def test_cards_arrive_in_running_order(self):
        names = [draft["business_name"] for draft in self._state()["drafts"]]
        self.assertEqual(names, ["Alpha Cafe", "Beta Bakery", "Gamma Grill"])


class RereviewTests(SignedIn):
    """The Re-review action re-runs the review, then rebuilds the email."""

    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(
            self.campaign,
            analysis_context="### PAGE 1 -- HOME\nMeasured signals: cta_count=0",
        )

    def _act(self, action="rereview", **body):
        return self.client.post(
            reverse("outreach:draft_action", args=[self.draft.pk, action]),
            data=body, content_type="application/json",
        )

    def test_rereview_replaces_the_findings_and_the_email(self):
        audit = ai.SiteAudit("Pizzeria.", make_findings(8))
        email = ai.GeneratedEmail("Fresh", "Body", "no CTA", ["Issue 0"])

        with mock.patch.object(ai, "audit", return_value=audit), \
             mock.patch.object(ai, "generate", return_value=email):
            response = self._act()

        self.assertEqual(response.status_code, 200)
        self.draft.refresh_from_db()
        self.assertEqual(len(self.draft.findings), 8)
        self.assertEqual(self.draft.subject, "Fresh")
        self.assertEqual(response.json()["draft"]["findings"][0]["issue"], "Issue 0")

    def test_rereview_without_crawled_material_is_refused(self):
        EmailDraft.objects.filter(pk=self.draft.pk).update(
            analysis_context="", analysis_note="robots.txt disallows")

        response = self._act()

        self.assertEqual(response.status_code, 400)
        self.assertIn("no crawled website material", response.json()["error"])

    def test_a_failing_rereview_reports_the_reason(self):
        with mock.patch.object(ai, "audit", side_effect=ai.AiError("quota hit")):
            response = self._act()

        self.assertEqual(response.status_code, 502)
        self.assertIn("quota hit", response.json()["error"])


@__import__("unittest").skipUnless(
    __import__("os").environ.get("LIVE_WEB_TESTS") == "1",
    "set LIVE_WEB_TESTS=1 to fetch a real website",
)
class LiveWebsiteTests(SignedIn):
    """Reads one real public website. Opt-in, and needs a network."""

    def setUp(self):
        analyzer._robots.clear()
        analyzer._last_hit.clear()

    def test_reads_a_real_site_and_obeys_its_robots_txt(self):
        result = analyzer.analyse("https://www.python.org")

        self.assertEqual(result.status, analyzer.OK)
        self.assertTrue(result.usable)
        self.assertTrue(result.pages[0].title)
        self.assertGreater(len(result.pages[0].text), 200)
        self.assertIn("python", result.as_context().lower())

    def test_a_domain_that_does_not_resolve_fails_cleanly(self):
        result = analyzer.analyse("https://this-domain-does-not-exist-zzqq.example")

        self.assertEqual(result.status, analyzer.FAILED)
        self.assertIn("Could not read", result.detail)


class CountsTests(SignedIn):
    def test_counts_group_drafts_by_state(self):
        campaign = make_campaign()
        states = [
            EmailDraft.Status.APPROVED, EmailDraft.Status.APPROVED,
            EmailDraft.Status.SENT, EmailDraft.Status.FAILED,
            EmailDraft.Status.REJECTED, EmailDraft.Status.NO_EMAIL,
        ]
        for i, status in enumerate(states):
            make_draft(campaign, business_name=f"B{i}",
                       email=f"b{i}@x.test" if status != EmailDraft.Status.NO_EMAIL else "",
                       status=status)

        counts = campaign.counts()
        self.assertEqual(counts["total"], 6)
        self.assertEqual(counts["approved"], 2)
        self.assertEqual(counts["sent"], 1)
        self.assertEqual(counts["failed"], 1)
        self.assertEqual(counts["rejected"], 1)
        self.assertEqual(counts["no_email"], 1)
        self.assertEqual(counts["remaining"], 2)
