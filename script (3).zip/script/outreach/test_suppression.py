"""
The do-not-contact list, and the deliberate re-contact override.

Two rules that pull in opposite directions, which is why they are tested
together: an already-contacted match is a *hint* the user may overrule with a
written reason, and a suppression is an absolute rule that no override reaches.
The cases that matter are the ones where they meet.
"""

from __future__ import annotations

from unittest import mock

from django.test import TestCase
from django.urls import reverse

from . import history, runner
from .models import Campaign, EmailDraft, SentLead, Suppression
from .test_history import make_sent
from .tests import make_campaign, make_draft
from .testsupport import OtherUser, SignedIn, default_user


def suppress_email(email="ciao@bella.example", **overrides):
    return history.suppress(default_user(), email=email, **overrides)[0]


class SuppressionMatchTests(SignedIn):
    """What the do-not-contact list blocks, and what it deliberately does not."""

    def test_an_exact_address_is_blocked(self):
        suppress_email()
        blocked = history.SuppressionIndex(default_user()).match(email="ciao@bella.example")

        self.assertIsNotNone(blocked)
        self.assertEqual(blocked.matched_by, "email")

    def test_matching_is_case_insensitive(self):
        suppress_email()
        self.assertIsNotNone(
            history.SuppressionIndex(default_user()).match(email="CIAO@Bella.Example"))

    def test_a_domain_entry_blocks_every_address_at_it(self):
        history.suppress(default_user(), domain="bella.example", reason="unsubscribed")
        index = history.SuppressionIndex(default_user())

        for email in ("anyone@bella.example", "info@BELLA.example"):
            with self.subTest(email=email):
                blocked = index.match(email=email)
                self.assertIsNotNone(blocked)
                self.assertEqual(blocked.matched_by, "domain")

    def test_a_domain_entry_matches_the_website_too(self):
        history.suppress(default_user(), domain="bella.example")
        blocked = history.SuppressionIndex(default_user()).match(
            email="hello@some-other-host.example",
            website="https://www.bella.example/contact")

        self.assertIsNotNone(blocked)

    def test_an_unrelated_address_is_not_blocked(self):
        suppress_email()
        self.assertIsNone(
            history.SuppressionIndex(default_user()).match(email="hi@elsewhere.example"))

    def test_there_is_no_name_and_city_tier(self):
        """Suppression must never rest on a guess as loose as the history's tier 3.

        Blocking "every business called Bella Cucina in Delft" would silently
        block businesses whose owners never asked for anything.
        """
        suppress_email()
        index = history.SuppressionIndex(default_user())

        self.assertIsNone(index.match(email="different@elsewhere.example"))
        self.assertEqual(sorted(vars(index)), ["by_domain", "by_email"])

    def test_suppressing_twice_updates_rather_than_failing(self):
        first = suppress_email(note="first")
        row, created = history.suppress(default_user(), email="ciao@bella.example", note="second")

        self.assertFalse(created)
        self.assertEqual(row.pk, first.pk)
        self.assertEqual(row.note, "second")
        self.assertEqual(Suppression.objects.count(), 1)

    def test_an_entry_needs_a_target(self):
        with self.assertRaises(ValueError):
            history.suppress(default_user(), email="", domain="")


class SuppressionBlocksSelectionTests(SignedIn):
    """A suppressed lead never becomes selectable, at any layer."""

    def test_search_results_are_badged_and_counted(self):
        suppress_email("ciao@bella.example")
        leads = [
            {"business_name": "Bella Cucina", "email": "ciao@bella.example",
             "website": "https://bella.example", "city": "Delft"},
            {"business_name": "New Place", "email": "hi@new.example",
             "website": "https://new.example", "city": "Delft"},
        ]

        counts = history.annotate_leads(leads, default_user())

        self.assertEqual(counts["suppressed"], 1)
        self.assertEqual(counts["available"], 1)
        self.assertEqual(leads[0]["contact_state"], "suppressed")
        self.assertEqual(leads[0]["state_label"], "Do not contact")
        self.assertEqual(leads[0]["suppression"]["matched_by"], "email")

    def test_a_suppressed_lead_outranks_an_already_contacted_match(self):
        """Both rules match; the stronger badge has to win, or the UI lies."""
        make_sent("ciao@bella.example")
        suppress_email("ciao@bella.example")
        leads = [{"business_name": "Bella Cucina", "email": "ciao@bella.example",
                  "website": "https://bella.example", "city": "Delft"}]

        history.annotate_leads(leads, default_user())

        self.assertEqual(leads[0]["contact_state"], "suppressed")
        self.assertNotIn("history", leads[0])

    def test_a_new_campaign_stores_suppressed_leads_out_of_the_workflow(self):
        suppress_email("ciao@bella.example")
        response = self.client.post(
            reverse("outreach:start"),
            data={
                "leads": [
                    {"business_name": "Bella Cucina",
                     "email": "ciao@bella.example",
                     "website": "https://bella.example", "city": "Delft"},
                    {"business_name": "New Place", "email": "hi@new.example",
                     "website": "https://new.example", "city": "Delft"},
                ],
                "category": "Restaurants",
                "area": {"country": "Netherlands", "city": "Delft"},
            },
            content_type="application/json",
        )

        self.assertEqual(response.status_code, 200)
        body = response.json()
        self.assertEqual(body["suppressed"], 1)
        self.assertEqual(body["eligible"], 1)

        campaign = Campaign.objects.get(pk=body["campaign_id"])
        blocked = campaign.drafts.get(business_name="Bella Cucina")
        self.assertEqual(blocked.status, EmailDraft.Status.SUPPRESSED)
        self.assertFalse(blocked.in_workflow)
        self.assertIn("do-not-contact", blocked.error_message)

    def test_the_queue_sweep_separates_suppressed_from_duplicate(self):
        campaign = make_campaign()
        suppressed = make_draft(campaign, business_name="Bella Cucina",
                                email="ciao@bella.example",
                                status=EmailDraft.Status.APPROVED)
        duplicate = make_draft(campaign, business_name="Other Place",
                               email="hi@other.example",
                               website="https://other.example",
                               status=EmailDraft.Status.APPROVED)
        suppress_email("ciao@bella.example")
        make_sent("hi@other.example", business_name="Other Place",
                  website="https://other.example", domain="other.example")

        moved = history.mark_campaign_duplicates(campaign)

        self.assertEqual(moved, 2)
        suppressed.refresh_from_db()
        duplicate.refresh_from_db()
        self.assertEqual(suppressed.status, EmailDraft.Status.SUPPRESSED)
        self.assertEqual(duplicate.status, EmailDraft.Status.DUPLICATE)

    def test_reserve_refuses_a_suppressed_address(self):
        campaign = make_campaign()
        draft = make_draft(campaign, email="ciao@bella.example")
        suppress_email("ciao@bella.example")

        with self.assertRaises(history.DoNotContact):
            history.reserve(draft)

        self.assertEqual(SentLead.objects.count(), 0)

    def test_a_domain_suppression_refuses_the_reservation_too(self):
        campaign = make_campaign()
        draft = make_draft(campaign, email="anyone@bella.example",
                           website="https://bella.example")
        history.suppress(default_user(), domain="bella.example")

        with self.assertRaises(history.DoNotContact):
            history.reserve(draft)


class RecontactOverrideTests(SignedIn):
    """`force_contact` overrides the sending history -- and nothing else."""

    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(
            self.campaign, business_name="Bella Cucina",
            email="ciao@bella.example", website="https://bella.example",
            status=EmailDraft.Status.APPROVED,
        )
        make_sent("ciao@bella.example")

    def test_without_the_override_the_history_blocks_the_reservation(self):
        with self.assertRaises(history.AlreadyContacted):
            history.reserve(self.draft)

    def test_with_the_override_the_reservation_succeeds_and_is_labelled(self):
        self.draft.force_contact = True
        self.draft.force_reason = "different business, same name"
        self.draft.save(update_fields=["force_contact", "force_reason"])

        record = history.reserve(self.draft)

        self.assertTrue(record.recontact)
        self.assertEqual(record.recontact_reason, "different business, same name")
        # The original history row is untouched -- this is an addition to it.
        self.assertEqual(SentLead.objects.count(), 2)

    def test_the_override_does_not_reach_a_suppressed_address(self):
        suppress_email("ciao@bella.example")
        self.draft.force_contact = True
        self.draft.force_reason = "we agreed a follow-up on the phone"
        self.draft.save(update_fields=["force_contact", "force_reason"])

        with self.assertRaises(history.DoNotContact):
            history.reserve(self.draft)

    def test_a_second_reservation_in_the_same_campaign_still_fails(self):
        """The override gives up the cross-campaign block, not the double-send one."""
        self.draft.force_contact = True
        self.draft.force_reason = "different business, same name"
        self.draft.save(update_fields=["force_contact", "force_reason"])
        history.reserve(self.draft)

        with self.assertRaises(history.AlreadyContacted):
            history.reserve(self.draft)

        self.assertEqual(SentLead.objects.filter(recontact=True).count(), 1)

    def test_a_recontact_in_a_different_campaign_is_allowed(self):
        self.draft.force_contact = True
        self.draft.force_reason = "different business, same name"
        self.draft.save(update_fields=["force_contact", "force_reason"])
        history.reserve(self.draft)

        later = make_campaign()
        second = make_draft(later, business_name="Bella Cucina",
                            email="ciao@bella.example",
                            force_contact=True, force_reason="follow-up agreed")

        record = history.reserve(second)

        self.assertTrue(record.recontact)

    def test_the_sweep_leaves_an_overridden_draft_in_the_workflow(self):
        self.draft.force_contact = True
        self.draft.force_reason = "different business, same name"
        self.draft.save(update_fields=["force_contact", "force_reason"])

        moved = history.mark_campaign_duplicates(self.campaign)

        self.draft.refresh_from_db()
        self.assertEqual(moved, 0)
        self.assertEqual(self.draft.status, EmailDraft.Status.APPROVED)


class RecontactActionTests(SignedIn):
    """The "Contact anyway" button: what it demands before it will do anything."""

    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(
            self.campaign, business_name="Bella Cucina",
            email="ciao@bella.example", website="https://bella.example",
            subject="", body="", status=EmailDraft.Status.DUPLICATE,
            error_message="Skipped: already contacted (same business name and city)",
        )

    def _post(self, payload, pk=None):
        return self.client.post(
            reverse("outreach:draft_action",
                    args=[pk or self.draft.pk, "recontact"]),
            data=payload, content_type="application/json",
        )

    def test_a_short_reason_is_refused(self):
        for reason in ("", "dunno", "  ok  "):
            with self.subTest(reason=reason):
                response = self._post({"reason": reason})
                self.assertEqual(response.status_code, 400)
                self.draft.refresh_from_db()
                self.assertFalse(self.draft.force_contact)

    def test_a_reasoned_override_requeues_the_lead(self):
        with mock.patch.object(runner, "start_pipeline",
                               return_value=True) as start:
            response = self._post({"reason": "different business, same name"})

        self.assertEqual(response.status_code, 200)
        start.assert_called_once()
        self.assertTrue(start.call_args.kwargs["resume"])

        self.draft.refresh_from_db()
        self.assertTrue(self.draft.force_contact)
        self.assertEqual(self.draft.force_reason, "different business, same name")
        self.assertEqual(self.draft.status, EmailDraft.Status.PENDING)
        self.assertEqual(self.draft.error_message, "")
        # Cleared so the resumed run gives it a place at the end of the order.
        self.assertEqual(self.draft.sequence, 0)

    def test_a_suppressed_lead_cannot_be_overridden(self):
        suppress_email("ciao@bella.example")
        EmailDraft.objects.filter(pk=self.draft.pk).update(
            status=EmailDraft.Status.SUPPRESSED)

        response = self._post({"reason": "we agreed this on the phone"})

        self.assertEqual(response.status_code, 403)
        self.assertIn("do-not-contact", response.json()["error"])
        self.draft.refresh_from_db()
        self.assertFalse(self.draft.force_contact)

    def test_a_lead_suppressed_after_being_blocked_is_still_refused(self):
        """The draft says `duplicate`, but the list says no. The list wins."""
        suppress_email("ciao@bella.example")

        response = self._post({"reason": "different business, same name"})

        self.assertEqual(response.status_code, 403)
        self.draft.refresh_from_db()
        self.assertFalse(self.draft.force_contact)

    def test_a_lead_that_is_not_blocked_cannot_be_overridden(self):
        EmailDraft.objects.filter(pk=self.draft.pk).update(
            status=EmailDraft.Status.GENERATED)

        response = self._post({"reason": "just because I want to"})

        self.assertEqual(response.status_code, 400)


class SuppressFromCardTests(SignedIn):
    """Adding to the list from the review screen, where the reply arrives."""

    def setUp(self):
        self.campaign = make_campaign()
        self.draft = make_draft(self.campaign, email="ciao@bella.example",
                                website="https://bella.example")

    def _post(self, payload=None):
        return self.client.post(
            reverse("outreach:draft_action", args=[self.draft.pk, "suppress"]),
            data=payload or {}, content_type="application/json",
        )

    def test_the_address_is_added_and_the_draft_is_taken_out(self):
        response = self._post({"note": "replied asking to be removed"})

        self.assertEqual(response.status_code, 200)
        row = Suppression.objects.get()
        self.assertEqual(row.email, "ciao@bella.example")
        self.assertEqual(row.note, "replied asking to be removed")
        self.assertEqual(row.campaign_label, self.campaign.label)

        self.draft.refresh_from_db()
        self.assertEqual(self.draft.status, EmailDraft.Status.SUPPRESSED)
        self.assertFalse(self.draft.in_workflow)

    def test_the_whole_domain_can_be_suppressed(self):
        self._post({"scope": "domain"})

        row = Suppression.objects.get()
        self.assertEqual(row.email, "")
        self.assertEqual(row.domain, "bella.example")
        self.assertEqual(row.scope, "whole domain")

    def test_suppressing_clears_any_earlier_override(self):
        EmailDraft.objects.filter(pk=self.draft.pk).update(
            force_contact=True, force_reason="different business")

        self._post()

        self.draft.refresh_from_db()
        self.assertFalse(self.draft.force_contact)


class SuppressionScreenTests(SignedIn):
    """The do-not-contact screen and its two endpoints."""

    def test_the_page_renders_with_its_entries(self):
        suppress_email("ciao@bella.example", note="asked to be removed")

        response = self.client.get(reverse("outreach:suppressions"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "ciao@bella.example")
        self.assertContains(response, "asked to be removed")

    def test_adding_an_entry_sweeps_open_campaigns(self):
        campaign = make_campaign()
        queued = make_draft(campaign, email="ciao@bella.example",
                            status=EmailDraft.Status.PENDING)
        elsewhere = make_draft(campaign, business_name="New Place",
                               email="hi@new.example",
                               website="https://new.example",
                               status=EmailDraft.Status.PENDING)

        response = self.client.post(
            reverse("outreach:suppress_add"),
            data={"target": "ciao@bella.example", "reason": "unsubscribed"},
            content_type="application/json",
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["swept"], 1)
        queued.refresh_from_db()
        elsewhere.refresh_from_db()
        self.assertEqual(queued.status, EmailDraft.Status.SUPPRESSED)
        self.assertEqual(elsewhere.status, EmailDraft.Status.PENDING)

    def test_an_already_sent_draft_is_left_alone_by_the_sweep(self):
        """History is a record. Suppressing an address does not rewrite it."""
        campaign = make_campaign()
        sent = make_draft(campaign, email="ciao@bella.example",
                          status=EmailDraft.Status.SENT)

        self.client.post(
            reverse("outreach:suppress_add"),
            data={"target": "ciao@bella.example"},
            content_type="application/json",
        )

        sent.refresh_from_db()
        self.assertEqual(sent.status, EmailDraft.Status.SENT)

    def test_a_domain_target_is_accepted(self):
        response = self.client.post(
            reverse("outreach:suppress_add"),
            data={"target": "www.bella.example"},
            content_type="application/json",
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["scope"], "whole domain")
        self.assertEqual(Suppression.objects.get().domain, "bella.example")

    def test_a_malformed_address_is_refused(self):
        response = self.client.post(
            reverse("outreach:suppress_add"),
            data={"target": "not an @ address"},
            content_type="application/json",
        )

        self.assertEqual(response.status_code, 400)
        self.assertEqual(Suppression.objects.count(), 0)

    def test_an_empty_target_is_refused(self):
        response = self.client.post(
            reverse("outreach:suppress_add"), data={"target": "   "},
            content_type="application/json",
        )

        self.assertEqual(response.status_code, 400)

    def test_an_entry_can_be_removed(self):
        row = suppress_email("ciao@bella.example")

        response = self.client.post(
            reverse("outreach:suppress_remove", args=[row.pk]))

        self.assertEqual(response.status_code, 200)
        self.assertEqual(Suppression.objects.count(), 0)
        self.assertIsNone(
            history.SuppressionIndex(default_user()).match(email="ciao@bella.example"))
