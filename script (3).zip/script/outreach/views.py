"""
The email workflow's HTTP surface.

    POST /outreach/start              leads page hands over the selected leads
    GET  /outreach/<id>/setup         lead table + sender settings
    POST /outreach/<id>/run           save settings, start analyse -> generate
    GET  /outreach/<id>/              review workspace
    GET  /outreach/<id>/state         JSON progress + drafts (polled)
    POST /outreach/<id>/approve-all   approve every generated draft
    POST /outreach/<id>/send          start the bulk send
    GET  /outreach/<id>/report        sending report
    GET  /outreach/history            past campaigns
    POST /outreach/draft/<pk>/<action>  save | regenerate | approve | reject
"""

from __future__ import annotations

import importlib
import json
import os

from django.conf import settings
from django.conf import settings as django_settings
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from django.db import IntegrityError, transaction
from django.http import FileResponse, HttpRequest, HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_GET, require_POST

from . import (
    ai,
    aicontext,
    credentials,
    history,
    inbox,
    intelligence,
    pipeline,
    runner,
    scoring,
    sender,
)
from . import followups as followup_rules
from .models import (
    MANUAL_LIFECYCLE,
    Campaign,
    EmailDraft,
    FollowUp,
    Lifecycle,
    ProviderCredential,
    SentLead,
    Suppression,
)

MAX_LEADS_PER_CAMPAIGN = 300


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #

def _json(request: HttpRequest) -> dict:
    try:
        return json.loads(request.body or b"{}")
    except json.JSONDecodeError:
        return {}


def _valid_email(value: str) -> bool:
    try:
        validate_email(value)
    except ValidationError:
        return False
    return True


def _started(draft: EmailDraft, current_id: int | None) -> bool:
    """Has this lead's own analyse-and-write cycle begun?

    The workspace only shows cards for leads the run has reached, so the list
    grows one company at a time instead of opening as a wall of empty cards.
    A lead from a campaign that predates sequential processing has no
    `processed_at`, so the status check keeps its card visible too.
    """
    return (
        draft.processed_at is not None
        or draft.pk == current_id
        or draft.status != EmailDraft.Status.PENDING
    )


def _draft_json(draft: EmailDraft, contacted: dict[str, str],
                current_id: int | None = None) -> dict:
    return {
        "id": draft.pk,
        "sequence": draft.sequence,
        "started": _started(draft, current_id),
        "processed": draft.processed_at is not None,
        "business_name": draft.business_name,
        "email": draft.email,
        "website": draft.website,
        "category": draft.category,
        "address": draft.address,
        "phone": draft.phone,
        "status": draft.status,
        "status_label": draft.get_status_display(),
        "subject": draft.subject,
        "body": draft.body,
        "observation": draft.observation,
        "analysis_status": draft.analysis_status,
        "analysis_note": draft.analysis_note,
        "has_material": draft.has_website_material,
        "business_summary": draft.business_summary,
        "findings": draft.findings or [],
        "findings_used": draft.findings_used or [],
        "pages_read": draft.pages_read or [],
        "pages_discovered": draft.pages_discovered,
        "edited": draft.edited,
        "regenerations": draft.regenerations,
        "error_message": draft.error_message,
        "force_contact": draft.force_contact,
        "force_reason": draft.force_reason,
        # A duplicate can be overridden with a written reason; a suppression
        # cannot, so the UI must be able to tell them apart.
        "can_recontact": draft.status == EmailDraft.Status.DUPLICATE,
        "sent_at": draft.sent_at.isoformat() if draft.sent_at else None,
        "previously_contacted": contacted.get(draft.email.lower(), ""),
    }


def _previous_contacts(campaign: Campaign) -> dict[str, str]:
    """Addresses this project has already emailed in an *earlier* campaign."""
    rows = (
        EmailDraft.objects
        .filter(status=EmailDraft.Status.SENT)
        .exclude(campaign_id=campaign.pk)
        .values_list("email", "sent_at")
    )
    seen: dict[str, str] = {}
    for email, sent_at in rows:
        key = (email or "").lower()
        if key and key not in seen:
            seen[key] = sent_at.date().isoformat() if sent_at else "earlier"
    return seen


def _state(campaign: Campaign) -> dict:
    contacted = _previous_contacts(campaign)
    drafts = sorted(campaign.drafts.all(),
                    key=lambda d: (d.sequence or 10**6, d.business_name))
    current_id = campaign.current_draft_id
    return {
        "campaign": {
            "id": str(campaign.id),
            "label": campaign.label,
            "phase": campaign.phase,
            "phase_label": campaign.get_phase_display(),
            "error": campaign.error,
            "sender_name": campaign.sender_name,
            "sender_email": campaign.sender_email,
            "provider": campaign.provider,
            "provider_label": (
                sender.PROVIDERS[campaign.provider].label
                if campaign.provider in sender.PROVIDERS else ""
            ),
            "running": runner.is_running(campaign.id),
            # Work that claims to be running but is not -- almost always a
            # server restart mid-campaign. The workspace offers to pick it up.
            "stalled": runner.stalled(campaign),
            # Paused, cancelling, cancelled or running, with the facts behind it.
            # The panel reads this rather than interpreting the phase string, so
            # the server stays the only thing that decides what a run's state is.
            "control": campaign.control_state(),
        },
        "counts": campaign.counts(),
        "progress": campaign.progress(),
        "drafts": [_draft_json(d, contacted, current_id)
                   for d in drafts if d.in_workflow],
        "skipped": [
            _draft_json(d, contacted, current_id)
            for d in drafts if not d.in_workflow
        ],
    }


# --------------------------------------------------------------------------- #
# Ownership
#
# Every lookup below goes through one of these. The rule they enforce is that a
# URL parameter is never trusted on its own: `get_object_or_404(Campaign, pk=...)`
# would happily hand one user another user's campaign, so the owner is part of
# every query rather than checked afterwards. A 404 rather than a 403 is
# deliberate -- "not found" does not confirm that somebody else's campaign with
# that id exists.
# --------------------------------------------------------------------------- #

def _my_campaign(request: HttpRequest, campaign_id) -> Campaign:
    return get_object_or_404(Campaign, pk=campaign_id, owner=request.user)


def _my_draft(request: HttpRequest, pk: int) -> EmailDraft:
    return get_object_or_404(
        EmailDraft.objects.select_related("campaign"),
        pk=pk, campaign__owner=request.user,
    )


def _my_lead(request: HttpRequest, pk: int) -> SentLead:
    return get_object_or_404(SentLead, pk=pk, owner=request.user)


def _my_followup(request: HttpRequest, pk: int) -> FollowUp:
    return get_object_or_404(
        FollowUp.objects.select_related("lead", "campaign"),
        pk=pk, owner=request.user,
    )


# --------------------------------------------------------------------------- #
# Lead intelligence: dashboard, table, lead detail
#
# Every query goes through outreach/pipeline.py, which starts from
# `campaign__owner=request.user`. None of these views can return another
# account's leads, and none of them crawls anything -- opening a page reads the
# cached audit and recomputes arithmetic. Re-analysing is a POST, because it
# spends money.
# --------------------------------------------------------------------------- #

def _filters_from(request: HttpRequest) -> dict:
    """The filter set carried in the query string, validated against the lists."""
    def pick(name: str, options, default: str = "all") -> str:
        value = (request.GET.get(name) or default).strip().lower()
        return value if value in {key for key, _label in options} else default

    return {
        "website": pick("website", pipeline.WEBSITE_FILTERS),
        "priority": pick("priority", pipeline.PRIORITY_FILTERS),
        "outreach": pick("outreach", pipeline.OUTREACH_FILTERS),
        "whatsapp": pick("whatsapp", pipeline.WHATSAPP_FILTERS),
        "country": (request.GET.get("country") or "").strip()[:120],
        "category": (request.GET.get("category") or "").strip()[:120],
        "search": (request.GET.get("q") or "").strip()[:120],
        "sort": pick("sort", pipeline.SORTS, "score"),
    }


@require_GET
def dashboard(request: HttpRequest) -> HttpResponse:
    """The sales-intelligence home: totals, queues, and the best prospects."""
    summary = pipeline.summary(request.user)
    top = pipeline.filtered(request.user, sort="score")[:8]

    return render(request, "outreach/dashboard.html", {
        "nav": "dashboard",
        "summary": summary,
        "queues": pipeline.queues(request.user),
        "top": top,
        "history": history.stats(request.user),
        "replies": followup_rules.stats(request.user),
        "campaigns": Campaign.objects.filter(owner=request.user)[:6],
        "ai_provider": (credentials.status(ai.provider(), request.user)
                        if credentials.known(ai.provider()) else None),
    })


@require_GET
def leads(request: HttpRequest) -> HttpResponse:
    """The lead intelligence table: every lead, filtered and sorted."""
    active = _filters_from(request)
    campaign = None
    campaign_id = request.GET.get("campaign", "")
    if campaign_id:
        campaign = Campaign.objects.filter(
            pk=campaign_id, owner=request.user).first()

    rows = pipeline.filtered(request.user, campaign=campaign, **active)
    total = pipeline.base(request.user).count()

    # A hard cap rather than pagination: the point of this table is the top of a
    # sorted list, and a user with 5,000 leads wants the filters, not page 84.
    shown = list(rows[:300])

    return render(request, "outreach/leads.html", {
        "nav": "leads",
        "rows": shown,
        "count": rows.count(),
        "total": total,
        "capped": rows.count() > len(shown),
        "active": active,
        "campaign": campaign,
        "choices": pipeline.choices(request.user),
        "website_filters": pipeline.WEBSITE_FILTERS,
        "priority_filters": pipeline.PRIORITY_FILTERS,
        "outreach_filters": pipeline.OUTREACH_FILTERS,
        "whatsapp_filters": pipeline.WHATSAPP_FILTERS,
        "sorts": pipeline.SORTS,
        "queues": pipeline.queues(request.user),
        "summary": pipeline.summary(request.user),
    })


@require_GET
def lead_detail(request: HttpRequest, pk: int) -> HttpResponse:
    """One lead's full intelligence. Reads the cached audit; never crawls."""
    draft = _my_draft(request, pk)

    # Re-score on open. Arithmetic only, and it keeps a lead current when the
    # thresholds or the scoring rules have changed since it was last written.
    if draft.classification:
        intelligence.apply(draft)
        draft.refresh_from_db()

    audit = draft.audit
    contacted = _previous_contacts(draft.campaign)
    history_rows = list(draft.history_rows.order_by("-reserved_at")[:5])

    return render(request, "outreach/lead_detail.html", {
        "nav": "leads",
        "draft": draft,
        "audit": audit,
        "campaign": draft.campaign,
        "sub_scores": draft.sub_score_rows,
        "detail": draft.score_detail or {},
        "findings": draft.findings or (audit.findings if audit else []),
        "evidenced": [f for f in (draft.findings or
                                  (audit.findings if audit else []))
                      if f.get("evidence")],
        "lifecycle_steps": draft.lifecycle_steps,
        "lifecycle_choices": Lifecycle.choices,
        "manual_stages": [c.value for c in MANUAL_LIFECYCLE],
        "history_rows": history_rows,
        "previously_contacted": contacted.get(draft.email.lower(), ""),
        "ready": scoring.is_ready(draft.score_readiness),
        "readiness_min": int(getattr(django_settings,
                                     "OUTREACH_READINESS_MIN", 60)),
        "reply_line": sender.REPLY_LINE,
    })


@require_POST
def lead_reanalyse(request: HttpRequest, pk: int) -> JsonResponse:
    """Crawl this lead's website again, review it, and re-score.

    The only path in the application that spends a crawl on a single lead, and it
    exists precisely so that opening a page does not. Synchronous because the user
    asked and is waiting; the crawl is capped at a handful of pages.
    """
    draft = _my_draft(request, pk)

    if not draft.website:
        return JsonResponse({
            "error": "This lead has no website address to analyse.",
        }, status=400)

    try:
        audit = intelligence.audit_website(
            request.user, draft.website, refresh=True,
            business_name=draft.business_name, category=draft.category,
            city=draft.city, country=draft.country,
        )
    except Exception as exc:  # noqa: BLE001 - a crawl can fail in many ways
        return JsonResponse({
            "error": f"The website could not be analysed: {exc}",
        }, status=502)

    if audit is None:
        return JsonResponse({
            "error": "That website address could not be understood.",
        }, status=400)

    # The audit is the lead's own evidence now, so copy the parts the draft owns.
    draft.analysis_status = audit.status
    draft.analysis_note = audit.detail[:400]
    draft.pages_read = audit.pages
    draft.pages_discovered = audit.pages_discovered
    # Taken wholesale, empty included: the audit is now this lead's current
    # evidence, and keeping findings the fresh crawl did not reproduce would show
    # the user claims that are no longer true.
    draft.findings = audit.findings
    draft.business_summary = audit.business_summary
    draft.save(update_fields=["analysis_status", "analysis_note", "pages_read",
                             "pages_discovered", "findings",
                             "business_summary"])

    intelligence.apply(draft, audit=audit)
    draft.refresh_from_db()

    message = (f"{draft.business_name}: {audit.get_status_display().lower()}, "
               f"{len(audit.pages)} page(s) read")
    if audit.findings:
        message += f", {len(audit.findings)} finding(s)."
    else:
        # Said out loud rather than left as a silently empty list: the user asked
        # for an analysis and should know the review half of it did not produce
        # anything.
        message += ", but the review produced no findings."

    return JsonResponse({
        "message": message,
        "findings": len(audit.findings),
        "lead": _lead_json(draft),
        "reload": True,
    })


@require_POST
def lead_lifecycle(request: HttpRequest, pk: int) -> JsonResponse:
    """Move a lead to a stage a person has judged."""
    draft = _my_draft(request, pk)
    payload = _json(request)
    stage = str(payload.get("stage", "")).strip()

    try:
        intelligence.set_lifecycle(draft, stage,
                                   note=str(payload.get("note", "")))
    except ValueError as exc:
        return JsonResponse({"error": str(exc)}, status=400)

    draft.refresh_from_db()
    return JsonResponse({
        "message": f"{draft.business_name} moved to "
                   f"{draft.get_lifecycle_display()}.",
        "lead": _lead_json(draft),
    })


@require_POST
def rescore(request: HttpRequest) -> JsonResponse:
    """Re-score every lead this account owns. Arithmetic only -- no crawling.

    Wanted after changing the priority thresholds, which otherwise apply only to
    leads scored from then on.
    """
    count = 0
    for draft in pipeline.base(request.user).iterator():
        intelligence.apply(draft)
        count += 1

    return JsonResponse({
        "message": f"Re-scored {count} lead(s) against the current thresholds.",
        "summary": pipeline.summary(request.user),
    })


def _lead_json(draft: EmailDraft) -> dict:
    """The safe shape of one lead for a JSON response."""
    return {
        "id": draft.pk,
        "business_name": draft.business_name,
        "classification": draft.classification,
        "classification_label": draft.classification_label,
        "priority": draft.priority,
        "priority_label": draft.priority_label,
        "score_overall": draft.score_overall,
        "score_website": draft.score_website,
        "score_value": draft.score_value,
        "score_readiness": draft.score_readiness,
        "recommended_service": draft.recommended_service,
        "why_prospect": draft.why_prospect,
        "lifecycle": draft.lifecycle,
        "lifecycle_label": draft.get_lifecycle_display(),
        "main_issue": draft.main_issue,
    }


# --------------------------------------------------------------------------- #
# Step 1 -- hand the selected leads over from the map page
# --------------------------------------------------------------------------- #

@require_POST
def start(request: HttpRequest) -> JsonResponse:
    """Create a campaign from the leads ticked on the results page."""
    payload = _json(request)
    leads = payload.get("leads") or []
    if not isinstance(leads, list) or not leads:
        return JsonResponse({"error": "No leads were selected."}, status=400)
    if len(leads) > MAX_LEADS_PER_CAMPAIGN:
        return JsonResponse(
            {"error": f"Select at most {MAX_LEADS_PER_CAMPAIGN} leads per campaign."},
            status=400,
        )

    area = payload.get("area") or {}
    with transaction.atomic():
        campaign = Campaign.objects.create(
            owner=request.user,
            country=str(area.get("country", ""))[:120],
            city=str(area.get("city", ""))[:120],
            category=str(payload.get("category", ""))[:120],
        )

        # One history snapshot for the whole batch rather than a query per lead.
        index = history.Index(request.user)
        blocklist = history.SuppressionIndex(request.user)
        seen: set[str] = set()
        blocked = 0
        suppressed = 0
        for lead in leads:
            if not isinstance(lead, dict):
                continue
            email = str(lead.get("email", "")).strip()
            key = email.lower()
            note = ""

            if not email or not _valid_email(email):
                status = EmailDraft.Status.NO_EMAIL
                email = ""
            elif stop := blocklist.match(email=email,
                                         website=str(lead.get("website", ""))):
                # The do-not-contact list is absolute and is checked first, so
                # its record is never overwritten by a weaker duplicate match.
                status = EmailDraft.Status.SUPPRESSED
                note = stop.sentence()
                suppressed += 1
            elif key in seen:
                # Two map pins sharing one address: keep the first.
                status = EmailDraft.Status.DUPLICATE
                note = "Skipped: another selected lead uses this address."
            else:
                match = index.match(
                    email=email,
                    website=str(lead.get("website", "")),
                    business_name=str(lead.get("business_name", "")),
                    city=str(lead.get("city", "")),
                )
                if match:
                    # Already contacted: recorded, but kept out of the workflow
                    # so it costs no crawl and no AI call.
                    status = EmailDraft.Status.DUPLICATE
                    note = (
                        "Skipped: already contacted — "
                        + history.MATCH_LABELS.get(match.matched_by, match.matched_by)
                        + (f" on {match.sent_date}" if match.sent_date else "")
                        + (f" in {match.campaign_label}" if match.campaign_label else "")
                    )
                    blocked += 1
                else:
                    seen.add(key)
                    status = EmailDraft.Status.PENDING

            try:
                # Savepoint per row: a stray collision skips that lead instead
                # of rolling back the whole campaign.
                with transaction.atomic():
                    EmailDraft.objects.create(
                        campaign=campaign,
                        business_name=str(lead.get("business_name", ""))[:255] or "Unnamed",
                        email=email,
                        website=str(lead.get("website", ""))[:500],
                        category=str(lead.get("category", ""))[:160],
                        address=str(lead.get("address", ""))[:400],
                        phone=str(lead.get("phone", ""))[:80],
                        city=str(lead.get("city", ""))[:160],
                        country=str(lead.get("country", ""))[:160],
                        latitude=lead.get("latitude"),
                        longitude=lead.get("longitude"),
                        source=str(lead.get("source", ""))[:500],
                        status=status,
                        error_message=note,
                    )
            except IntegrityError:
                continue  # unique constraint caught a duplicate address

    return JsonResponse({
        "campaign_id": str(campaign.id),
        "setup_url": reverse("outreach:setup", args=[campaign.id]),
        "eligible": campaign.drafts.filter(status=EmailDraft.Status.PENDING).count(),
        "already_contacted": blocked,
        "suppressed": suppressed,
    })


# --------------------------------------------------------------------------- #
# Step 2 -- select leads, enter sender settings, kick off the pipeline
# --------------------------------------------------------------------------- #

@require_GET
def setup(request: HttpRequest, campaign_id) -> HttpResponse:
    campaign = _my_campaign(request, campaign_id)
    if campaign.phase != Campaign.Phase.SETUP:
        return redirect("outreach:workspace", campaign_id=campaign.id)

    drafts = list(campaign.drafts.all())

    # One row per selected lead with the badge it should wear. Built here rather
    # than in the template: the state depends on the sending history, and the
    # template language cannot do a keyed lookup.
    icons = {"ready": "mail", "contacted": "clock", "invalid": "alert",
             "sent": "check-circle", "failed": "x-circle", "sending": "send"}
    rows = []
    for draft in drafts:
        state = draft.contact_state
        rows.append({
            "draft": draft,
            "state": state,
            "label": history.STATES[state]["label"],
            "icon": icons.get(state, "info"),
            "selectable": draft.status == EmailDraft.Status.PENDING,
            "note": draft.error_message if state == "contacted" else "",
        })
    # Contactable leads first; the rest are context, not choices.
    rows.sort(key=lambda r: (0 if r["selectable"] else 1,
                             r["draft"].business_name.casefold()))

    eligible = [d for d in drafts if d.status == EmailDraft.Status.PENDING]
    blocked = [d for d in drafts if d.status == EmailDraft.Status.DUPLICATE]

    # A campaign started earlier keeps whatever it was given; a fresh one is
    # pre-filled from the configured identity in settings.
    return render(request, "outreach/setup.html", {
        "campaign": campaign,
        "all_drafts": rows,
        "blocked_count": len(blocked),
        "eligible": eligible,
        "ineligible": [d for d in drafts if not d.in_workflow],
        "providers": sender.PROVIDERS.values(),
        "sender_name": campaign.sender_name or settings.OUTREACH_SENDER_NAME,
        "sender_email": campaign.sender_email or settings.OUTREACH_SENDER_EMAIL,
        "sender_company": campaign.sender_company or settings.OUTREACH_SENDER_COMPANY,
        "chosen_provider": campaign.provider or settings.OUTREACH_PROVIDER,
        "default_offer": campaign.service_pitch or ai.DEFAULT_OFFER,
        "nav": "search",
        # So the screen can show which AI provider is about to write the emails,
        # and whether it is actually usable, before anything is spent.
        "ai_provider": credentials.status(ai.provider(), request.user)
                       if credentials.known(ai.provider()) else None,
        "ai_model": ai.model() if ai.describe_credentials()[0] else "",
    })


@require_POST
def run(request: HttpRequest, campaign_id) -> JsonResponse:
    """Save sender settings and start analysis + generation."""
    campaign = _my_campaign(request, campaign_id)
    if campaign.phase != Campaign.Phase.SETUP:
        return JsonResponse(
            {"error": "This campaign has already been started."}, status=409)

    payload = _json(request)
    sender_name = str(payload.get("sender_name", "")).strip()
    sender_email = str(payload.get("sender_email", "")).strip()
    provider = str(payload.get("provider", "")).strip()
    service_pitch = str(payload.get("service_pitch", "")).strip()
    selected = payload.get("selected")

    if not sender_name:
        return JsonResponse({"error": "Enter the sender name."}, status=400)
    if not _valid_email(sender_email):
        return JsonResponse({"error": "Enter a valid sender email address."}, status=400)
    if provider not in sender.PROVIDERS:
        return JsonResponse({"error": "Choose an email provider."}, status=400)
    if len(service_pitch) < 20:
        return JsonResponse({
            "error": "Describe what you offer in a sentence or two -- the AI "
                     "needs it to explain how you can help each business.",
        }, status=400)

    if not isinstance(selected, list) or not selected:
        return JsonResponse({"error": "Select at least one lead."}, status=400)

    # Fail fast on an unconfigured provider. Without this, every lead in the run
    # would be crawled and then fail its AI call with the same message -- paying
    # for the crawls to learn something knowable in advance.
    active = ai.provider()
    resolved = credentials.resolve(active, request.user)
    if not resolved.usable:
        return JsonResponse({
            "error": credentials.NOT_CONFIGURED_TEMPLATE.format(
                label=credentials.spec(active).label
                if credentials.known(active) else active),
            "settings_url": reverse("outreach:settings"),
        }, status=400)

    ids = {int(i) for i in selected if str(i).isdigit()}
    eligible = campaign.drafts.filter(status=EmailDraft.Status.PENDING)
    keep = eligible.filter(pk__in=ids)
    if not keep.exists():
        return JsonResponse({"error": "None of the selected leads are usable."},
                            status=400)

    with transaction.atomic():
        # Deselected leads stay on the record, marked as not chosen.
        eligible.exclude(pk__in=ids).update(status=EmailDraft.Status.EXCLUDED)
        campaign.sender_name = sender_name[:120]
        campaign.sender_email = sender_email
        campaign.sender_company = str(payload.get("sender_company", "")).strip()[:160]
        campaign.provider = provider
        campaign.service_pitch = service_pitch
        campaign.save(update_fields=[
            "sender_name", "sender_email", "sender_company", "provider",
            "service_pitch",
        ])

    runner.start_pipeline(campaign)
    return JsonResponse({
        "workspace_url": reverse("outreach:workspace", args=[campaign.id]),
        "queued": keep.count(),
    })


# --------------------------------------------------------------------------- #
# Steps 3-4 -- review workspace
# --------------------------------------------------------------------------- #

@require_GET
def workspace(request: HttpRequest, campaign_id) -> HttpResponse:
    campaign = _my_campaign(request, campaign_id)
    if campaign.phase == Campaign.Phase.SETUP:
        return redirect("outreach:setup", campaign_id=campaign.id)
    return render(request, "outreach/workspace.html", {
        "nav": "search",
        "campaign": campaign,
        "provider": sender.PROVIDERS.get(campaign.provider),
        "has_smtp_password_env": bool(os.environ.get("OUTREACH_SMTP_PASSWORD")),
        # Shown under every draft: it is appended at send time, so the review
        # screen has to show it or the review is of the wrong text.
        "reply_line": sender.REPLY_LINE,
    })


@require_GET
def state(request: HttpRequest, campaign_id) -> JsonResponse:
    campaign = _my_campaign(request, campaign_id)
    return JsonResponse(_state(campaign))


@require_POST
def cancel(request: HttpRequest, campaign_id) -> JsonResponse:
    """Stop the lead-processing job for this campaign.

    Two paths, because the answer depends on whether anything is actually
    running:

      * **a worker is running** -- the request is recorded as CANCEL_REQUESTED
        and the worker settles it. It checks before each lead and before each
        page fetch, so nothing new starts, and the lead in flight is abandoned
        without a completion stamp rather than half-saved.
      * **nothing is running** -- a paused run, or one whose process died. There
        is nobody to notice the request, so it is settled here.

    Idempotent by construction: a campaign that is already cancelled, or already
    cancelling, is reported as such and nothing is written. Pressing Cancel twice
    cannot restart anything or corrupt the state, which is the property the brief
    asks for.

    What it deliberately does not touch: the completion stamps. Every lead that
    finished stays finished, and a later resume starts from the first one that did
    not.
    """
    campaign = _my_campaign(request, campaign_id)

    if campaign.is_cancelled:
        return JsonResponse({
            "cancelled": True, "already": True,
            "message": "Processing was already cancelled.",
            "state": _state(campaign),
        })

    if campaign.phase not in Campaign.CANCELLABLE_PHASES:
        if campaign.phase == Campaign.Phase.SENDING:
            # A different animal: some of those emails are already delivered.
            return JsonResponse({
                "error": "A send is in progress and cannot be cancelled here. "
                         "It stops on its own; anything already delivered is "
                         "recorded in the history.",
            }, status=409)
        return JsonResponse({
            "error": "There is no lead processing to cancel for this campaign.",
        }, status=409)

    running = runner.is_running(campaign.id)

    if campaign.is_cancelling:
        # A previous press is still being acted on. Not an error -- say where it
        # is, and settle it if the worker has since disappeared.
        if running:
            return JsonResponse({
                "cancelled": False, "already": True,
                "message": "Cancelling — finishing the current lead.",
                "state": _state(campaign),
            })
        runner.mark_cancelled(campaign)
        campaign.refresh_from_db()
        return JsonResponse({
            "cancelled": True, "message": "Processing cancelled.",
            "state": _state(campaign),
        })

    if running:
        Campaign.objects.filter(
            pk=campaign.pk, phase__in=Campaign.CANCELLABLE_PHASES,
        ).update(phase=Campaign.Phase.CANCEL_REQUESTED, current_step="")
        campaign.refresh_from_db()
        return JsonResponse({
            "cancelled": False,
            "message": "Cancelling — no further leads will be started.",
            "state": _state(campaign),
        })

    # Paused, or the worker is gone. Nobody is watching for the request, so it
    # is applied directly.
    runner.mark_cancelled(campaign)
    campaign.refresh_from_db()
    unfinished = campaign.unfinished_count()
    return JsonResponse({
        "cancelled": True,
        "message": ("Processing cancelled."
                    + (f" {unfinished} lead(s) were not processed."
                       if unfinished else "")),
        "state": _state(campaign),
    })


@require_POST
def resume(request: HttpRequest, campaign_id) -> JsonResponse:
    """Pick up a campaign that stopped before the end of its queue.

    Three reasons a campaign is sitting still, and all three land here:

      * **paused by a rate limit** -- resumed once the retry window has passed.
        The window is enforced server-side: a browser that resumed early would
        walk straight into the same refusal.
      * **cancelled** -- resumed only because the user asked again, explicitly.
        Nothing auto-resumes a cancelled run; that is the point of cancelling.
      * **stalled** -- the process died mid-run. Offered as before.

    Leads already finished are skipped in every case, so resuming costs nothing
    for work already paid for. A stalled *send* is different: the password is not
    stored, so it cannot be resumed silently -- the queue is released back to
    approved and the user presses Send again.
    """
    campaign = _my_campaign(request, campaign_id)
    kind = runner.stalled(campaign)

    if campaign.is_paused:
        if runner.is_running(campaign.id):
            return JsonResponse({
                "error": "This campaign is waiting out a rate limit and will "
                         "carry on by itself.",
                "state": _state(campaign),
            }, status=409)

        remaining = campaign.retry_seconds
        forced = bool(_json(request).get("force"))
        if remaining and not forced:
            return JsonResponse({
                "error": (f"The AI provider asked to wait {remaining} more "
                          "second(s). Processing resumes automatically when the "
                          "window passes."),
                "retry_seconds": remaining,
                "state": _state(campaign),
            }, status=409)

        if not runner.start_pipeline(campaign, resume=True):
            return JsonResponse({"error": "A job is already running."}, status=409)
        return JsonResponse({"resumed": "pipeline",
                             "remaining": campaign.unfinished_count()})

    if campaign.is_cancelled:
        unfinished = campaign.unfinished_count()
        if not unfinished:
            return JsonResponse({
                "error": "Every lead in this campaign was already processed.",
            }, status=400)
        if not runner.start_pipeline(campaign, resume=True):
            return JsonResponse({"error": "A job is already running."}, status=409)
        return JsonResponse({"resumed": "pipeline", "remaining": unfinished})

    if not kind:
        if runner.is_running(campaign.id):
            return JsonResponse(
                {"error": "This campaign is already running."}, status=409)
        return JsonResponse(
            {"error": "There is nothing to resume for this campaign."}, status=400)

    if kind == "send":
        released = campaign.drafts.filter(
            status=EmailDraft.Status.SENDING,
        ).update(status=EmailDraft.Status.APPROVED)
        Campaign.objects.filter(pk=campaign.pk).update(
            phase=Campaign.Phase.REVIEW,
            error=("The send was interrupted. "
                   f"{released} email(s) were returned to the approved queue -- "
                   "press Send to continue. Anything already delivered is "
                   "recorded in the history and will not be sent twice."),
            current_draft=None, current_step="",
        )
        return JsonResponse({"resumed": "send", "released": released,
                             "counts": campaign.counts()})

    remaining = campaign.drafts.filter(
        sequence__gt=0, processed_at__isnull=True,
    ).exclude(status__in=(EmailDraft.Status.EXCLUDED,
                          EmailDraft.Status.DUPLICATE,
                          EmailDraft.Status.SUPPRESSED,
                          EmailDraft.Status.NO_EMAIL)).count()

    if not runner.start_pipeline(campaign, resume=True):
        return JsonResponse({"error": "A job is already running."}, status=409)

    return JsonResponse({"resumed": "pipeline", "remaining": remaining})


@require_POST
def draft_action(request: HttpRequest, pk: int, action: str) -> JsonResponse:
    """Edit, regenerate, approve or reject a single email."""
    draft = _my_draft(request, pk)
    campaign = draft.campaign
    payload = _json(request)

    if draft.status in (EmailDraft.Status.SENT, EmailDraft.Status.SENDING):
        return JsonResponse(
            {"error": "That email has already been sent."}, status=409)

    if action == "save":
        subject = str(payload.get("subject", "")).strip()
        body = str(payload.get("body", "")).strip()
        if not subject or not body:
            return JsonResponse(
                {"error": "Subject and body cannot be empty."}, status=400)
        draft.subject = subject[:400]
        draft.body = body
        draft.edited = True
        if draft.status == EmailDraft.Status.FAILED:
            draft.status = EmailDraft.Status.GENERATED
        draft.error_message = ""
        draft.save(update_fields=["subject", "body", "edited", "status",
                                 "error_message"])

    elif action == "regenerate":
        hint = str(payload.get("hint", "")).strip()[:500]
        draft.regenerations += 1
        draft.save(update_fields=["regenerations"])
        if not runner.generate_draft(draft, campaign, retry_hint=hint):
            draft.refresh_from_db()
            return JsonResponse({"error": draft.error_message}, status=502)

    elif action == "rereview":
        # Re-run the website review, then rebuild the email from the new
        # findings -- useful when the first review came back thin or failed.
        if not draft.analysis_context:
            return JsonResponse({
                "error": "There is no crawled website material to review. "
                         f"{draft.analysis_note}",
            }, status=400)
        runner.review_draft(draft)
        draft.refresh_from_db()
        if not draft.findings:
            return JsonResponse(
                {"error": draft.error_message or "The review found nothing."},
                status=502)
        if not runner.generate_draft(draft, campaign):
            draft.refresh_from_db()
            return JsonResponse({"error": draft.error_message}, status=502)

    elif action == "approve":
        if not draft.subject or not draft.body:
            return JsonResponse(
                {"error": "This email has no content to approve yet."}, status=400)
        draft.status = EmailDraft.Status.APPROVED
        draft.save(update_fields=["status"])

    elif action == "reject":
        draft.status = EmailDraft.Status.REJECTED
        draft.save(update_fields=["status"])

    elif action == "recontact":
        # The deliberate re-contact workflow. It overrules the sending history
        # only: tier 3 matches on business name and city, which occasionally
        # blocks two genuinely different businesses, and this is how the user
        # says so. A suppressed address is never reachable this way.
        if draft.status == EmailDraft.Status.SUPPRESSED:
            return JsonResponse({
                "error": "This address is on the do-not-contact list. Remove it "
                         "there first if that entry is wrong.",
            }, status=403)
        if draft.status != EmailDraft.Status.DUPLICATE:
            return JsonResponse(
                {"error": "This lead is not blocked as already contacted."},
                status=400)
        if not draft.email:
            return JsonResponse(
                {"error": "This lead has no email address."}, status=400)

        reason = str(payload.get("reason", "")).strip()
        if len(reason) < 10:
            return JsonResponse({
                "error": "Give a reason of at least 10 characters -- it is kept "
                         "with the send record.",
            }, status=400)

        blocked = history.SuppressionIndex(request.user).match(
            email=draft.email, website=draft.website)
        if blocked:
            return JsonResponse({"error": blocked.sentence()}, status=403)

        draft.force_contact = True
        draft.force_reason = reason[:300]
        draft.status = EmailDraft.Status.PENDING
        draft.error_message = ""
        draft.sequence = 0          # _queue_for gives it a place at the end
        draft.processed_at = None
        draft.save(update_fields=["force_contact", "force_reason", "status",
                                  "error_message", "sequence", "processed_at"])

        if not runner.start_pipeline(campaign, resume=True):
            return JsonResponse({
                "error": "The lead is queued, but another job is running for "
                         "this campaign. Resume once it finishes.",
            }, status=409)

    elif action == "suppress":
        # Add this lead to the do-not-contact list, from the card in front of
        # you -- the point where "take me off your list" actually gets handled.
        if not draft.email:
            return JsonResponse(
                {"error": "This lead has no email address to suppress."},
                status=400)
        scope = str(payload.get("scope", "email")).strip()
        history.suppress(
            request.user,
            email="" if scope == "domain" else draft.email,
            domain=SentLead.domain_of(draft.website)
                   or draft.email.split("@")[-1],
            reason=str(payload.get("reason", "")).strip()
                   or Suppression.Reason.UNSUBSCRIBED,
            note=str(payload.get("note", "")).strip(),
            business_name=draft.business_name,
            campaign_label=campaign.label,
        )
        EmailDraft.objects.filter(pk=draft.pk).update(
            status=EmailDraft.Status.SUPPRESSED,
            force_contact=False,
            error_message="Added to the do-not-contact list.",
        )

    else:
        return JsonResponse({"error": f"Unknown action {action!r}."}, status=400)

    draft.refresh_from_db()
    return JsonResponse({
        "draft": _draft_json(draft, _previous_contacts(campaign)),
        "counts": campaign.counts(),
    })


@require_POST
def approve_all(request: HttpRequest, campaign_id) -> JsonResponse:
    """Approve every drafted email that has not been rejected or sent."""
    campaign = _my_campaign(request, campaign_id)
    updated = campaign.drafts.filter(
        status=EmailDraft.Status.GENERATED,
    ).exclude(subject="").update(status=EmailDraft.Status.APPROVED)
    return JsonResponse({"approved": updated, "counts": campaign.counts()})


# --------------------------------------------------------------------------- #
# Steps 6-7 -- bulk send and report
# --------------------------------------------------------------------------- #

@require_POST
def send(request: HttpRequest, campaign_id) -> JsonResponse:
    """Start the bulk send over the user's own SMTP account."""
    campaign = _my_campaign(request, campaign_id)

    if runner.is_running(campaign.id):
        return JsonResponse(
            {"error": "This campaign is already sending."}, status=409)
    if not campaign.drafts.filter(status=EmailDraft.Status.APPROVED).exists():
        return JsonResponse(
            {"error": "Approve at least one email before sending."}, status=400)

    payload = _json(request)
    # The password is used for this run and never written to the database.
    password = (str(payload.get("password", "")).strip()
                or os.environ.get("OUTREACH_SMTP_PASSWORD", ""))
    if not password:
        return JsonResponse({
            "error": "Enter the SMTP password or app password for "
                     f"{campaign.sender_email}.",
        }, status=400)

    provider = sender.PROVIDERS.get(campaign.provider)
    host = os.environ.get("OUTREACH_SMTP_HOST", "")
    port = int(os.environ.get("OUTREACH_SMTP_PORT", "0") or 0)
    if provider and provider.key == "custom" and not host:
        return JsonResponse({
            "error": "Set OUTREACH_SMTP_HOST (and OUTREACH_SMTP_PORT) for a "
                     "custom SMTP server, then restart the server.",
        }, status=400)

    if not runner.start_send(campaign, password, host=host, port=port):
        return JsonResponse({"error": "A job is already running."}, status=409)

    return JsonResponse({"started": True, "counts": campaign.counts()})


@require_GET
def report(request: HttpRequest, campaign_id) -> HttpResponse:
    campaign = _my_campaign(request, campaign_id)
    drafts = list(campaign.drafts.all())
    return render(request, "outreach/report.html", {
        "nav": "history",
        "campaign": campaign,
        "counts": campaign.counts(),
        # What came back after the send, for this campaign only.
        "replies": followup_rules.stats(request.user, campaign),
        "sent": [d for d in drafts if d.status == EmailDraft.Status.SENT],
        "failed": [d for d in drafts if d.status == EmailDraft.Status.FAILED],
        "other": [d for d in drafts
                  if d.status not in (EmailDraft.Status.SENT,
                                      EmailDraft.Status.FAILED)],
    })


@require_GET
def campaign_history(request: HttpRequest) -> HttpResponse:
    """The campaigns list.

    Named `campaign_history` rather than `history` so it does not shadow the
    `history` module imported at the top of this file -- it did, and every view
    that used the module broke.
    """
    campaigns = list(Campaign.objects.filter(owner=request.user)[:50])
    rows = [(c, c.counts()) for c in campaigns]
    totals = {
        "campaigns": len(rows),
        "leads": sum(counts["total"] for _c, counts in rows),
        "sent": sum(counts["sent"] for _c, counts in rows),
        "failed": sum(counts["failed"] for _c, counts in rows),
    }
    return render(request, "outreach/history.html", {
        "rows": rows,
        "totals": totals if rows else None,
        "nav": "history",
    })


# --------------------------------------------------------------------------- #
# The do-not-contact list
# --------------------------------------------------------------------------- #

@require_GET
def suppressions(request: HttpRequest) -> HttpResponse:
    """The do-not-contact list: who may never be emailed, and why."""
    rows = list(Suppression.objects.filter(owner=request.user)[:500])
    return render(request, "outreach/suppressions.html", {
        "nav": "suppressions",
        "rows": rows,
        "reasons": Suppression.Reason.choices,
        "total": Suppression.objects.filter(owner=request.user).count(),
        "domain_rules": sum(1 for row in rows if not row.email),
    })


@require_POST
def suppress_add(request: HttpRequest) -> JsonResponse:
    """Add an address or a domain to the do-not-contact list."""
    payload = _json(request)
    target = str(payload.get("target", "")).strip()
    if not target:
        return JsonResponse(
            {"error": "Enter an email address or a domain."}, status=400)

    is_email = "@" in target
    if is_email and not _valid_email(target):
        return JsonResponse({"error": f"{target} is not a valid email address."},
                            status=400)

    try:
        row, created = history.suppress(
            request.user,
            email=target if is_email else "",
            domain="" if is_email else target,
            reason=str(payload.get("reason", "")).strip(),
            note=str(payload.get("note", "")).strip(),
        )
    except ValueError as exc:
        return JsonResponse({"error": str(exc)}, status=400)

    # Anything already queued or drafted for this target drops out now, rather
    # than at send time -- there is no reason to keep spending AI calls on it.
    swept = 0
    blocklist = history.SuppressionIndex(request.user)
    for draft in EmailDraft.objects.filter(
        campaign__owner=request.user,
    ).exclude(
        status__in=(EmailDraft.Status.SENT, EmailDraft.Status.SENDING,
                    EmailDraft.Status.SUPPRESSED),
    ).exclude(email=""):
        blocked = blocklist.match(email=draft.email, website=draft.website)
        if blocked:
            EmailDraft.objects.filter(pk=draft.pk).update(
                status=EmailDraft.Status.SUPPRESSED,
                force_contact=False,
                error_message=blocked.sentence(),
            )
            swept += 1

    return JsonResponse({
        "created": created,
        "target": row.target,
        "scope": row.scope,
        "swept": swept,
        "total": Suppression.objects.filter(owner=request.user).count(),
    })


@require_POST
def suppress_remove(request: HttpRequest, pk: int) -> JsonResponse:
    """Remove an entry. Existing drafts stay suppressed until re-selected."""
    row = get_object_or_404(Suppression, pk=pk, owner=request.user)
    target = row.target
    row.delete()
    return JsonResponse({
        "removed": target,
        "total": Suppression.objects.filter(owner=request.user).count(),
    })


@require_GET
def history_excel(request: HttpRequest) -> HttpResponse:
    """Download the Excel history, refreshing it first."""
    try:
        history.export_excel(request.user)
    except Exception as exc:  # noqa: BLE001 - still serve whatever exists
        if not history.excel_path(request.user).exists():
            return HttpResponse(
                f"Could not build the Excel history: {exc}",
                status=500, content_type="text/plain",
            )

    path = history.excel_path(request.user)
    if not path.exists():
        return HttpResponse(
            "No emails have been sent yet, so there is no history to export.",
            status=404, content_type="text/plain",
        )
    return FileResponse(
        path.open("rb"), as_attachment=True, filename=history.EXCEL_NAME,
        content_type=("application/vnd.openxmlformats-officedocument"
                      ".spreadsheetml.sheet"),
    )


# --------------------------------------------------------------------------- #
# Reply tracking and manual follow-ups
# --------------------------------------------------------------------------- #

def _followup_json(followup: FollowUp) -> dict:
    return {
        "id": followup.pk,
        "lead_id": followup.lead_id,
        "number": followup.number,
        "email": followup.email,
        "subject": followup.subject,
        "body": followup.body,
        "status": followup.status,
        "status_label": followup.get_status_display(),
        "reply_state": followup.reply_state,
        "edited": followup.edited,
        "regenerations": followup.regenerations,
        "error_message": followup.error_message,
        "created_at": followup.created_at.isoformat() if followup.created_at else None,
        "sent_at": followup.sent_at.isoformat() if followup.sent_at else None,
    }


@require_GET
def followups(request: HttpRequest) -> HttpResponse:
    """Replies and follow-ups: what came back, and what may be followed up."""
    only = request.GET.get("filter", "all")
    if only not in followup_rules.FILTERS:
        only = "all"

    campaign = None
    campaign_id = request.GET.get("campaign", "")
    if campaign_id:
        campaign = Campaign.objects.filter(
            pk=campaign_id, owner=request.user).first()

    return render(request, "outreach/followups.html", {
        "nav": "followups",
        "rows": followup_rules.rows(request.user, campaign=campaign, only=only),
        "stats": followup_rules.stats(request.user, campaign),
        "filter": only,
        "filters": followup_rules.FILTER_LABELS,
        "campaign": campaign,
        "campaigns": Campaign.objects.filter(
            owner=request.user).exclude(sender_email="")[:50],
        "reasons": followup_rules.REASONS,
        "has_smtp_password_env": bool(os.environ.get("OUTREACH_SMTP_PASSWORD")),
        "reply_line": sender.REPLY_LINE,
    })


@require_POST
def check_inbox(request: HttpRequest) -> JsonResponse:
    """Read the sending account's inbox once and record what came back.

    Only replies to emails sent from here are examined; anything else is dropped
    without being stored. Nothing is sent, and nothing in the mailbox is marked
    read or modified.
    """
    payload = _json(request)
    password = (str(payload.get("password", "")).strip()
                or os.environ.get("OUTREACH_SMTP_PASSWORD", ""))
    if not password:
        return JsonResponse({
            "error": "Enter the mailbox password (the same app password used "
                     f"for sending {django_settings.OUTREACH_SENDER_EMAIL}).",
        }, status=400)

    try:
        result = inbox.check(password=password, owner=request.user)
    except inbox.InboxError as exc:
        return JsonResponse({"error": str(exc)}, status=502)

    return JsonResponse({
        "summary": result.summary(),
        "examined": result.examined,
        "matched": result.matched,
        "replied": result.replied,
        "bounced": result.bounced,
        "unsubscribed": result.unsubscribed,
        "changed": result.changed[:20],
        "stats": followup_rules.stats(request.user),
    })


@require_POST
def followup_create(request: HttpRequest, pk: int) -> JsonResponse:
    """Generate a follow-up for one lead. Saves it as a draft; sends nothing."""
    lead = _my_lead(request, pk)
    verdict = followup_rules.eligibility(lead)
    if not verdict.eligible:
        return JsonResponse({"error": verdict.label}, status=409)

    original = lead.draft            # the EmailDraft this send came from
    days_since = 0
    if verdict.last_contact_at:
        days_since = max(0, (timezone.now() - verdict.last_contact_at).days)

    campaign = lead.campaign
    try:
        email = ai.follow_up(
            business_name=lead.business_name,
            category=getattr(original, "category", "") or "",
            city=lead.city,
            country=lead.country,
            website=lead.website,
            sender_name=getattr(campaign, "sender_name", "")
                        or django_settings.OUTREACH_SENDER_NAME,
            sender_company=getattr(campaign, "sender_company", "")
                           or django_settings.OUTREACH_SENDER_COMPANY,
            sender_email=getattr(campaign, "sender_email", "")
                         or django_settings.OUTREACH_SENDER_EMAIL,
            service_pitch=getattr(campaign, "service_pitch", "") or "",
            original_subject=lead.subject or getattr(original, "subject", ""),
            original_body=getattr(original, "body", "") or "",
            observation=getattr(original, "observation", "") or "",
            findings=original.finding_objects if original else [],
            business_summary=getattr(original, "business_summary", "") or "",
            days_since=days_since,
            number=verdict.next_number,
            campaign_label=lead.campaign_label,
        )
    except ai.AiError as exc:
        return JsonResponse({"error": str(exc)}, status=502)

    try:
        with transaction.atomic():
            followup = FollowUp.objects.create(
                lead=lead,
                owner=request.user,
                campaign=campaign,
                campaign_label=lead.campaign_label,
                number=verdict.next_number,
                email=lead.email,
                subject=email.subject,
                body=email.body,
            )
    except IntegrityError:
        # Two clicks raced; the first one's draft is the one to review.
        existing = lead.followups.filter(
            number=verdict.next_number).exclude(
            status=FollowUp.Status.CANCELLED).first()
        if existing is None:
            return JsonResponse(
                {"error": "Could not create the follow-up. Reload and retry."},
                status=409)
        return JsonResponse({"followup": _followup_json(existing),
                             "angle": "", "created": False})

    return JsonResponse({
        "followup": _followup_json(followup),
        "angle": email.observation,
        "created": True,
        "eligibility": followup_rules.eligibility(lead).as_dict(),
    })


@require_POST
def followup_action(request: HttpRequest, pk: int, action: str) -> JsonResponse:
    """Edit, regenerate, cancel or send one follow-up draft."""
    followup = _my_followup(request, pk)
    payload = _json(request)

    if followup.status in (FollowUp.Status.SENT, FollowUp.Status.SENDING):
        return JsonResponse(
            {"error": "That follow-up has already been sent."}, status=409)

    if action == "save":
        subject = str(payload.get("subject", "")).strip()
        body = str(payload.get("body", "")).strip()
        if not subject or not body:
            return JsonResponse(
                {"error": "Subject and body cannot be empty."}, status=400)
        followup.subject = subject[:400]
        followup.body = body
        followup.edited = True
        followup.status = FollowUp.Status.DRAFT
        followup.error_message = ""
        followup.save(update_fields=["subject", "body", "edited", "status",
                                     "error_message"])

    elif action == "regenerate":
        hint = str(payload.get("hint", "")).strip()[:500]
        lead = followup.lead
        original = lead.draft
        campaign = followup.campaign
        days_since = max(0, (timezone.now()
                             - (lead.sent_at or lead.reserved_at)).days)
        try:
            email = ai.follow_up(
                business_name=lead.business_name,
                category=getattr(original, "category", "") or "",
                city=lead.city, country=lead.country, website=lead.website,
                sender_name=getattr(campaign, "sender_name", "")
                            or django_settings.OUTREACH_SENDER_NAME,
                sender_company=getattr(campaign, "sender_company", "")
                               or django_settings.OUTREACH_SENDER_COMPANY,
                sender_email=getattr(campaign, "sender_email", "")
                             or django_settings.OUTREACH_SENDER_EMAIL,
                service_pitch=getattr(campaign, "service_pitch", "") or "",
                original_subject=lead.subject or getattr(original, "subject", ""),
                original_body=getattr(original, "body", "") or "",
                observation=getattr(original, "observation", "") or "",
                findings=original.finding_objects if original else [],
                business_summary=getattr(original, "business_summary", "") or "",
                days_since=days_since, number=followup.number,
                campaign_label=lead.campaign_label, retry_hint=hint,
            )
        except ai.AiError as exc:
            return JsonResponse({"error": str(exc)}, status=502)

        followup.subject = email.subject
        followup.body = email.body
        followup.edited = False
        followup.regenerations += 1
        followup.error_message = ""
        followup.save(update_fields=["subject", "body", "edited",
                                     "regenerations", "error_message"])

    elif action == "cancel":
        # Cancelled rather than deleted: the number is freed for another attempt
        # and the record of the decision survives.
        followup.status = FollowUp.Status.CANCELLED
        followup.error_message = "Cancelled before sending."
        followup.save(update_fields=["status", "error_message"])

    elif action == "send":
        return _send_followup(request, followup, payload)

    else:
        return JsonResponse({"error": f"Unknown action {action!r}."}, status=400)

    followup.refresh_from_db()
    return JsonResponse({
        "followup": _followup_json(followup),
        "eligibility": followup_rules.eligibility(followup.lead).as_dict(),
        "stats": followup_rules.stats(request.user),
    })


def _send_followup(request: HttpRequest, followup: FollowUp,
                   payload: dict) -> JsonResponse:
    """Send one follow-up, but only after re-checking everything.

    The order here is the whole safety story: check, then claim, then check
    again is not needed -- the claim is a conditional UPDATE, so exactly one
    caller can move the row out of `draft`, and the check happens before the
    connection opens.
    """
    password = (str(payload.get("password", "")).strip()
                or os.environ.get("OUTREACH_SMTP_PASSWORD", ""))
    if not password:
        return JsonResponse({
            "error": "Enter the SMTP password to send this follow-up.",
        }, status=400)

    # The final check, immediately before SMTP. Everything it looks at can have
    # changed while the draft sat in review -- that is exactly why it is here.
    try:
        lead = followup_rules.check_before_send(followup)
    except followup_rules.Blocked as exc:
        FollowUp.objects.filter(pk=followup.pk).update(
            status=FollowUp.Status.CANCELLED, error_message=str(exc)[:2000])
        return JsonResponse({"error": str(exc), "cancelled": True}, status=409)

    if not followup_rules.claim(followup):
        return JsonResponse(
            {"error": "This follow-up is already being sent."}, status=409)

    campaign = followup.campaign
    provider_key = (getattr(campaign, "provider", "")
                    or django_settings.OUTREACH_PROVIDER)
    sender_email = (getattr(campaign, "sender_email", "")
                    or django_settings.OUTREACH_SENDER_EMAIL)
    sender_name = (getattr(campaign, "sender_name", "")
                   or django_settings.OUTREACH_SENDER_NAME)

    try:
        provider = sender.provider_for(provider_key)
        with sender.Session(
            provider, sender_email, password,
            host=os.environ.get("OUTREACH_SMTP_HOST", ""),
            port=int(os.environ.get("OUTREACH_SMTP_PORT", "0") or 0),
        ) as session:
            message_id = session.send(
                to_email=followup.email, subject=followup.subject,
                body=followup.body, sender_name=sender_name,
            )
    except sender.SendError as exc:
        followup_rules.release(followup)
        return JsonResponse({"error": str(exc)}, status=502)
    except Exception as exc:  # noqa: BLE001 - one rejected recipient
        message = f"{type(exc).__name__}: {exc}"
        followup.mark_failed(message)
        return JsonResponse({"error": message}, status=502)

    followup.mark_sent(message_id=message_id)
    followup.refresh_from_db()
    return JsonResponse({
        "followup": _followup_json(followup),
        "eligibility": followup_rules.eligibility(lead).as_dict(),
        "stats": followup_rules.stats(request.user),
        "sent": True,
    })


# --------------------------------------------------------------------------- #
# The AI credential pool
#
# Providers are the parents; credentials are the children. These endpoints manage
# the children, and every one of them is scoped to `request.user` -- a credential
# id arriving in a URL is never trusted on its own.
#
# No endpoint here returns a key. Every response carries
# `credentials.status(provider)`, which holds masked hints, labels, counters and
# timestamps. There is no GET that returns a secret, and the only code path that
# accepts one from the browser is the single POST that saves it.
# --------------------------------------------------------------------------- #

def _credential_ui_enabled() -> bool:
    """Whether the write endpoints are available.

    A deployment that wants credentials to come only from `.env` can set
    OUTREACH_CREDENTIALS_UI=0 and close this surface entirely. On by default,
    because the feature is useless off -- and now safe by default too, since
    every credential belongs to the account that added it.
    """
    return os.environ.get("OUTREACH_CREDENTIALS_UI", "1") != "0"


def _credential_guard() -> JsonResponse | None:
    if _credential_ui_enabled():
        return None
    return JsonResponse({
        "error": "Credential editing is disabled here (OUTREACH_CREDENTIALS_UI=0). "
                 "Set provider keys in .env instead.",
    }, status=403)


def _provider_or_error(provider: str):
    """(spec_name, error_response). Rejects anything not in the provider table."""
    name = (provider or "").strip().lower()
    if not credentials.known(name):
        return "", JsonResponse({
            "error": f"Unknown AI provider {provider!r}. Choose one of: "
                     + ", ".join(sorted(credentials.SPECS)) + ".",
        }, status=400)
    return name, None


def _my_credential(request: HttpRequest, pk: int) -> ProviderCredential:
    """One of this account's credentials, or 404.

    404 rather than 403, and `owner` in the query rather than a check after the
    fetch: "forbidden" would confirm that a credential with that id exists and
    belongs to somebody else.
    """
    return get_object_or_404(ProviderCredential, pk=pk, owner=request.user)


def _pool(request: HttpRequest) -> dict:
    """The whole pool in its safe shape: providers, each with its children."""
    return {
        "providers": credentials.all_statuses(request.user),
        "selected": ai.provider(),
    }


def _verify_credential(row) -> tuple[str, str]:
    """Test one child credential. ("", reason) when there is no way to test it.

    ("blocked", reason) where outbound requests are switched off.

    Returns rather than raises: a provider being unreachable is information, not
    a reason to refuse to save a key. The verdict is recorded against the row, so
    the card can show when it was last tested and what happened.
    """
    if getattr(django_settings, "OUTREACH_BLOCK_SEND", False):
        # The same switch that blocks SMTP and IMAP. A connection test is an
        # outbound request like any other, so it is refused here rather than
        # quietly made -- which is also what keeps the test suite offline.
        return "blocked", ("Not verified: outbound requests are blocked in this "
                           "environment (OUTREACH_BLOCK_SEND).")

    provider_spec = credentials.spec(row.provider)
    try:
        module = importlib.import_module(provider_spec.module)
    except ImportError:
        return "", (f"Not verified: the {provider_spec.label} backend needs the "
                    f"{provider_spec.package!r} package, which is not "
                    f"installed. Run `pip install {provider_spec.package}`.")

    verify = getattr(module, "verify", None)
    if not callable(verify):
        return "", ""

    try:
        # Forced onto this specific child, so a spare can be tested without
        # activating it -- and so the test proves *this* key works rather than
        # whichever one happens to be active.
        with aicontext.using_credential(row):
            credentials.invalidate(row.provider)
            result, message = verify(row.model or "")
    except Exception as exc:      # noqa: BLE001 - a test must not raise at a user
        result, message = credentials.categorise(exc)
    finally:
        # The forced credential is gone; the cached client must go with it.
        credentials.invalidate(row.provider)

    credentials.record_test(row.provider, f"{result}: {message}", row.pk,
                            row.owner)
    return result, message


@require_POST
def credential_add(request: HttpRequest, provider: str) -> JsonResponse:
    """Add one child credential under a provider.

    Tested immediately after saving, where the SDK is installed and the provider
    offers a cheap check. A failed test does not undo the save -- the key may be
    fine and the provider merely unreachable -- but it is reported in the same
    response and recorded against the row, so a bad key is known now rather than
    in the middle of a campaign.
    """
    blocked = _credential_guard()
    if blocked is not None:
        return blocked
    name, error = _provider_or_error(provider)
    if error is not None:
        return error

    payload = _json(request)
    key = str(payload.get("api_key", ""))
    if not key.strip():
        return JsonResponse({"error": "Enter an API key."}, status=400)

    extras = payload.get("extras") or {}
    if not isinstance(extras, dict):
        extras = {}

    try:
        row = credentials.add(
            request.user, name, key,
            label=str(payload.get("label", "")),
            description=str(payload.get("description", "")),
            extras={k: str(v) for k, v in extras.items()},
            model=str(payload.get("model", "")),
            activate=payload.get("activate"),
            allow_fallback=bool(payload.get("allow_fallback")),
        )
    except credentials.CredentialConflict as exc:
        return JsonResponse({"error": str(exc)}, status=409)
    except credentials.CredentialError as exc:
        # Never contains the key: CredentialError is documented not to carry one.
        return JsonResponse({"error": str(exc)}, status=400)

    verdict, verdict_message = _verify_credential(row)

    status = credentials.status(name, request.user)
    message = f"{status['label']} credential {row.label!r} saved."
    if row.is_active:
        message += " It is now the active credential for this provider."
    if verdict and verdict != "ok":
        message += f" {verdict_message}"

    return JsonResponse({
        "saved": True,
        "message": message,
        "verified": verdict,
        "verify_message": verdict_message,
        "credential": credentials.child_status(
            ProviderCredential.objects.get(pk=row.pk)),
        "status": status,
        **_pool(request),
    })


@require_POST
def credential_activate(request: HttpRequest, pk: int) -> JsonResponse:
    """Make one child the active credential for its provider.

    The previous active credential stands down in the same transaction, and every
    AI feature uses the new one from the next request onwards -- because they all
    ask the same resolver which credential is active.
    """
    blocked = _credential_guard()
    if blocked is not None:
        return blocked
    row = _my_credential(request, pk)

    if row.is_active:
        return JsonResponse({
            "message": f"{row.label!r} is already the active credential.",
            "status": credentials.status(row.provider, request.user),
            **_pool(request),
        })

    try:
        status = credentials.activate(request.user, row)
    except IntegrityError:
        # Two tabs both pressed Activate. The database constraint held; say so
        # plainly rather than reporting a success that did not happen.
        return JsonResponse({
            "error": "Another change to this provider happened at the same "
                     "time. Reload the page and try again.",
        }, status=409)
    except credentials.CredentialError as exc:
        return JsonResponse({"error": str(exc)}, status=400)

    return JsonResponse({
        "message": f"{status['label']} now uses {row.label!r}. Every AI request "
                   "for this provider will use it from now on.",
        "status": status,
        **_pool(request),
    })


@require_POST
def credential_deactivate(request: HttpRequest, pk: int) -> JsonResponse:
    """Stand one child down, promoting nothing in its place.

    The response says exactly where the provider stands afterwards, because that
    is the part a user cannot see: with no active credential it falls back to the
    environment variable if one is set, and to nothing if not.
    """
    blocked = _credential_guard()
    if blocked is not None:
        return blocked
    row = _my_credential(request, pk)

    try:
        status = credentials.deactivate(request.user, row)
    except credentials.CredentialError as exc:
        return JsonResponse({"error": str(exc)}, status=400)

    if status["source"] == credentials.ENVIRONMENT:
        message = (f"{row.label!r} deactivated. {status['label']} now falls back "
                   "to the environment variable.")
    elif status["configured"]:
        message = (f"{row.label!r} deactivated. {status['label']} now uses "
                   f"{status['source_label'].lower()}.")
    else:
        message = (f"{row.label!r} deactivated. {status['label']} has no active "
                   "credential — activate one before running anything that "
                   "needs it.")

    return JsonResponse({"message": message, "status": status, **_pool(request)})


@require_POST
def credential_delete(request: HttpRequest, pk: int) -> JsonResponse:
    """Delete one child credential.

    Deleting the active one leaves the provider with no active credential rather
    than promoting a sibling: quietly redirecting every request onto a key nobody
    chose is the surprise this whole design avoids. The response says so, and the
    browser asks for confirmation before getting here.
    """
    blocked = _credential_guard()
    if blocked is not None:
        return blocked
    row = _my_credential(request, pk)
    label, was_active = row.label, row.is_active
    remaining = (credentials.children(row.provider, request.user)
                 .exclude(pk=row.pk).count())

    try:
        status = credentials.remove(request.user, row)
    except credentials.CredentialError as exc:
        return JsonResponse({"error": str(exc)}, status=400)

    message = f"{label!r} deleted."
    if was_active:
        if status["source"] == credentials.ENVIRONMENT:
            message += (f" {status['label']} now falls back to the environment "
                        "variable.")
        elif remaining:
            message += (f" {status['label']} has no active credential — "
                        f"activate one of the remaining {remaining}.")
        else:
            message += f" {status['label']} is no longer configured."

    return JsonResponse({
        "deleted": True, "message": message, "status": status, **_pool(request),
    })


@require_POST
def credential_test(request: HttpRequest, pk: int) -> JsonResponse:
    """Test one child credential, active or not.

    Categories are `ok`, `invalid`, `rate_limited`, `forbidden`, `model`,
    `unavailable`, `error`. The message is written locally and never passed
    through unread from the provider: provider error text can quote the request,
    and the request carried the key.
    """
    row = _my_credential(request, pk)
    result, message = _verify_credential(row)

    if not result:
        return JsonResponse({
            "result": "unsupported",
            "message": message or "This provider has no connection test.",
            "status": credentials.status(row.provider, request.user),
        }, status=400)

    if result == "blocked":
        # A local policy, not a provider verdict: 400, not a bad gateway.
        return JsonResponse({
            "result": result, "message": message,
            "status": credentials.status(row.provider, request.user),
        }, status=400)

    return JsonResponse({
        "result": result,
        "message": message,
        "credential": credentials.child_status(
            ProviderCredential.objects.get(pk=row.pk)),
        "status": credentials.status(row.provider, request.user),
    }, status=200 if result in ("ok", "rate_limited") else 502)


@require_POST
def credential_fallback(request: HttpRequest, pk: int) -> JsonResponse:
    """Mark whether this spare may be tried when the active credential fails.

    Off unless the user turns it on: automatic rotation has to be something they
    asked for. Even on, it never changes which credential is active -- it borrows
    the spare for one request, and writes down that it did.
    """
    blocked = _credential_guard()
    if blocked is not None:
        return blocked
    row = _my_credential(request, pk)
    payload = _json(request)
    enabled = bool(payload.get("enabled"))

    if row.is_active and enabled:
        return JsonResponse({
            "error": "The active credential is the one already in use. Mark a "
                     "spare as the fallback instead.",
        }, status=400)

    try:
        status = credentials.set_fallback(request.user, row, enabled)
    except credentials.CredentialError as exc:
        return JsonResponse({"error": str(exc)}, status=400)

    return JsonResponse({
        "message": (f"{row.label!r} may now be used for a single retry when the "
                    "active credential is rate limited." if enabled else
                    f"{row.label!r} will no longer be used as a fallback."),
        "status": status,
        **_pool(request),
    })


@require_GET
def credential_events(request: HttpRequest) -> JsonResponse:
    """The recent credential history for this account.

    Answers §11's questions after the fact -- which credential was used, why,
    when, and what happened -- and contains no keys, only labels and categories.
    """
    provider = (request.GET.get("provider") or "").strip().lower()
    if provider and not credentials.known(provider):
        provider = ""

    rows = credentials.events(request.user, provider, limit=40)
    return JsonResponse({
        "events": [
            {
                "kind": row.kind,
                "kind_label": row.get_kind_display(),
                "provider": row.provider,
                "provider_label": (credentials.spec(row.provider).label
                                   if credentials.known(row.provider)
                                   else row.provider),
                "label": row.label,
                "category": row.category,
                "detail": row.detail,
                "at": row.created_at.isoformat(),
            }
            for row in rows
        ],
    })


@require_POST
def ai_select(request: HttpRequest) -> JsonResponse:
    """Choose the provider used from now on.

    The browser sends `{"provider": "openai"}` and nothing else -- never a key.
    Which key that provider then uses is the server's business: the active child.
    """
    payload = _json(request)
    name, error = _provider_or_error(str(payload.get("provider", "")))
    if error is not None:
        return error

    resolved = credentials.resolve(name, request.user)
    if not resolved.usable:
        # Refused rather than saved: selecting a provider with no credential
        # would leave every later AI call failing with the same message.
        return JsonResponse({
            "error": credentials.NOT_CONFIGURED_TEMPLATE.format(
                label=credentials.spec(name).label),
            "status": credentials.status(name, request.user),
        }, status=400)

    provider_name, model_name = credentials.set_selection(
        name, str(payload.get("model", "")), request.user)

    return JsonResponse({
        "selected": provider_name,
        "model": model_name or credentials.spec(provider_name).default_model,
        "message": f"{credentials.spec(provider_name).label} selected"
                   + (f", using {resolved.label!r}." if resolved.label else "."),
        **_pool(request),
    })




def _imap_label(smtp_provider) -> str:
    """Where replies would be read from, or "" when nothing is configured."""
    if smtp_provider is None:
        return ""
    try:
        host, port = inbox.resolve_imap(smtp_provider)
    except inbox.InboxError:
        return ""
    return f"{host}:{port}"


@require_GET
def settings_view(request: HttpRequest) -> HttpResponse:
    """The current configuration, and the AI credential pool.

    Sending, scraping and crawling settings are read-only here: they come from
    `.env`, and a browser form that could rewrite an SMTP password would put it
    on the network for no reason.

    AI credentials are the exception, and the reason is that they are per
    account: this page shows each provider with the credentials this user has
    added under it, which of them is active, and how each has been behaving. No
    key is ever sent back -- only masked hints.
    """
    from leads import scraper

    from . import analyzer

    ai_ready, ai_source, ai_advice = ai.describe_credentials()
    active = ai.provider()

    # One list, from the credential resolver, so the cards, the selector and the
    # provider the pipeline will actually use cannot disagree.
    # Explicitly scoped to this account rather than relying on the middleware's
    # context: the owner is the one argument that must never be left implicit.
    providers = credentials.all_statuses(request.user)
    for entry in providers:
        entry["active"] = entry["name"] == active
        entry["effective_model"] = (
            ai.model() if entry["name"] == active
            else (entry["model"] or entry["default_model"])
        )

    provider_key = django_settings.OUTREACH_PROVIDER
    smtp_provider = sender.PROVIDERS.get(provider_key)
    host = os.environ.get("OUTREACH_SMTP_HOST", "")
    port = os.environ.get("OUTREACH_SMTP_PORT", "")
    if smtp_provider and not host:
        host, port = smtp_provider.host, smtp_provider.port

    return render(request, "outreach/settings.html", {
        "nav": "settings",
        "ai_ready": ai_ready,
        "ai_source": ai_source,
        "ai_advice": ai_advice,
        "providers": providers,
        "active_provider": active,
        "active_model": ai.model() if ai_ready else "",
        "credential_ui": _credential_ui_enabled(),
        "credential_total": sum(e["credential_count"] for e in providers),
        "credential_events": credentials.events(request.user, limit=12),
        "sender_name": django_settings.OUTREACH_SENDER_NAME,
        "sender_email": django_settings.OUTREACH_SENDER_EMAIL,
        "sender_company": django_settings.OUTREACH_SENDER_COMPANY,
        "smtp_provider": smtp_provider,
        "smtp_provider_key": provider_key,
        "smtp_host": f"{host}:{port}" if host else "not configured",
        "smtp_password_set": bool(os.environ.get("OUTREACH_SMTP_PASSWORD")),
        "send_blocked": getattr(django_settings, "OUTREACH_BLOCK_SEND", False),
        "osm_contact": django_settings.OSM_CONTACT_EMAIL,
        "max_leads": scraper.MAX_LEADS,
        "history": history.stats(request.user),
        "followup_max": followup_rules.max_followups(),
        "followup_delays": list(django_settings.OUTREACH_FOLLOWUP_DELAYS),
        "imap_host": _imap_label(smtp_provider),
        "crawl": {
            "target": analyzer.TARGET_INTERNAL,
            "max_pages": analyzer.MAX_PAGES,
            "delay": analyzer.HOST_DELAY,
            "context_budget": analyzer.CONTEXT_BUDGET,
        },
    })
