"""
OpenAI backend, via the official `openai` SDK.

Transport lives in `ai_openai_compatible`, shared with OpenRouter. This module is
the provider's identity: its name, label, default model, and how its optional
extras (a custom base URL, an organisation id) map onto the client.

The default model is deliberately a small, cheap one: this application writes one
short email per lead from supplied material, which is not a reasoning-heavy task,
and cost scales with list size. Override it in Settings or with
OUTREACH_AI_MODEL for a small, high-value list.
"""

from __future__ import annotations

from . import ai_openai_compatible as compat
from .ai_base import AiError

NAME = "openai"
LABEL = "OpenAI"
DEFAULT_MODEL = "gpt-4.1-mini"
CONSOLE_URL = "https://platform.openai.com/api-keys"

#: Kept for parity with the other backends and for the settings page. The
#: resolver owns priority; this is documentation of what it reads.
KEY_VARS = ("OPENAI_API_KEY",)

MAX_TOKENS = 4000

_client = None
_client_fingerprint = ""


def describe_credentials() -> tuple[bool, str, str]:
    """(usable, source, advice), from the central resolver."""
    from . import credentials

    resolved = credentials.resolve(NAME)
    if resolved.usable:
        return True, resolved.detail, ""
    return False, resolved.detail, resolved.advice


def reset_client() -> None:
    """Drop the cached client, so a newly saved key takes effect at once."""
    global _client, _client_fingerprint
    _client = None
    _client_fingerprint = ""


def client():
    """One shared client, rebuilt when the resolved credential changes."""
    global _client, _client_fingerprint
    from . import credentials

    resolved = credentials.require(NAME)
    if _client is None or _client_fingerprint != resolved.fingerprint:
        _client = compat.build_client(
            api_key=resolved.key,
            base_url=(resolved.extras or {}).get("base_url", ""),
            organization=(resolved.extras or {}).get("organization", ""),
            label=LABEL,
        )
        _client_fingerprint = resolved.fingerprint
    return _client


def complete(*, system: str, prompt: str, schema: dict, model: str,
             max_tokens: int = MAX_TOKENS) -> str:
    """Return the model's JSON text, or raise AiError."""
    return compat.complete(
        client(), system=system, prompt=prompt, schema=schema, model=model,
        max_tokens=max_tokens or MAX_TOKENS, label=LABEL,
        console_url=CONSOLE_URL,
    )


def verify(model: str = "") -> tuple[str, str]:
    """Test Connection: (category, message). Never raises for a bad key."""
    try:
        return compat.verify(client(), model=model or DEFAULT_MODEL, label=LABEL)
    except AiError as exc:
        return "error", str(exc)
