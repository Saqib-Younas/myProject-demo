"""
Discovers, crawls and measures a lead's public website.

The caller supplies one URL. Everything after that is automatic: this module
reads the navigation, the footer, the sitemap and the page links, decides which
internal pages are worth reading, and visits the best of them.

Its second job matters more than the crawl. For every page it records
**verifiable signals** -- how many images lack alt text, whether a viewport meta
tag exists, how long the page took to return, how many bytes it weighed, which
call-to-action phrases appear, how the headings are structured. Those numbers are
what the AI is given as evidence. Without them a model asked to "find website
problems" will confidently invent plausible ones; with them, every finding can be
traced to something that was actually measured.

What this module will not do:

  * ignore robots.txt -- it is fetched first and obeyed per URL,
  * push past a 401/403/429 or a bot-check page -- those mean "not welcome",
  * touch anything behind a login, paywall or CAPTCHA.

A blocked or broken site is recorded as such, never guessed at.
"""

from __future__ import annotations

import os
import re
import threading
import time
from dataclasses import dataclass, field
from urllib.parse import urljoin, urlparse, urlunparse
from urllib.robotparser import RobotFileParser

import requests
from bs4 import BeautifulSoup

# --------------------------------------------------------------------------- #
# Crawl budget and politeness
# --------------------------------------------------------------------------- #

USER_AGENT = (
    "LeadMapperBot/1.0 (+{contact}; respects robots.txt; "
    "contact to be excluded)"
)
CONTACT = "you@example.com"

#: Home page plus this many internal pages is the goal. The brief asks for at
#: least 5 internal pages where they exist.
TARGET_INTERNAL = 5
MAX_PAGES = 8              # hard ceiling including the home page
MAX_CANDIDATES = 400       # links considered before scoring
MAX_SITEMAP_URLS = 300

MAX_BYTES = 2_000_000
TIMEOUT = 15
HOST_DELAY = 1.0           # seconds between two requests to the same host
TEXT_BUDGET = 4_000        # characters of page text stored per page

#: Total characters of context handed to the AI, across all pages.
#:
#: This exists because breadth and prompt size pull against each other: reading
#: more pages is better analysis but a bigger request, and model rate limits are
#: unforgiving. A 6-page crawl at the full per-page budget came to ~10.5k tokens,
#: over Groq's free-tier 8k tokens/minute, so the review could never run. The
#: fix is to keep the page count and share a fixed character budget between
#: them -- signals stay whole (they are compact and are the evidence), prose gets
#: trimmed. Raise it if your provider's limits allow.
CONTEXT_BUDGET = int(os.environ.get("OUTREACH_AI_CONTEXT_CHARS", "9000"))

#: Never trim a page's text below this, or it stops being evidence at all.
MIN_PAGE_TEXT = 350

_lock = threading.Lock()
_last_hit: dict[str, float] = {}
_robots: dict[str, RobotFileParser | None] = {}

# --------------------------------------------------------------------------- #
# What makes a page worth reading
# --------------------------------------------------------------------------- #

#: (kind, pattern, score). Higher scores are visited first. Scores encode "how
#: much does this page tell us about the business and its customer journey".
#:
#: Word boundaries are load-bearing, not decoration. Without them "workshops"
#: matches "shop" and gets labelled a products page, and "quotes" (testimonials)
#: matches "quote" and gets labelled pricing -- both seen on a real site. Paths
#: separate words with "-" and "/", which are non-word characters, so \b behaves
#: as intended on URLs.
PAGE_KINDS: tuple[tuple[str, str, int], ...] = (
    ("services", r"\b(services?|solutions?|what-we-do|expertise|treatments?"
                 r"|capabilit\w+)\b", 100),
    ("products", r"\b(products?|shop|store|menu|catalogue?|collections?)\b", 95),
    ("pricing", r"\b(pricing|prices?|plans|packages|rates|quote|fees)\b", 90),
    ("contact", r"\b(contact|contact-us|get-in-touch|reach-us|enquir\w+"
                r"|inquir\w+|book|booking|appointments?|locations?)\b", 85),
    ("about", r"\b(about|about-us|who-we-are|our-story|company|mission"
              r"|history|values)\b", 80),
    ("testimonials", r"\b(testimonials?|reviews?|quotes|clients|case-stud\w+"
                     r"|success-stories|portfolio|our-work)\b", 70),
    ("team", r"\b(team|staff|people|our-doctors|practitioners|leadership)\b", 55),
    ("faq", r"\b(faqs?|frequently-asked\w*|help|support)\b", 50),
    ("gallery", r"\b(gallery|galleries|photos|images)\b", 40),
    ("blog", r"\b(blog|news|articles|insights|resources)\b", 30),
)

#: Never worth a request: legal boilerplate, account plumbing, feeds, archives.
SKIP_PATTERN = re.compile(
    r"(privacy|terms|conditions|cookie|disclaimer|gdpr|imprint|impressum"
    r"|login|log-in|signin|sign-in|register|signup|sign-up|account|my-account"
    r"|cart|checkout|basket|wishlist|compare"
    r"|wp-admin|wp-login|wp-json|xmlrpc|feed|rss|atom"
    r"|/tag/|/tags/|/category/|/categories/|/author/|/archive"
    r"|sitemap\.xml|\.pdf$|\.jpg$|\.jpeg$|\.png$|\.gif$|\.webp$|\.svg$"
    r"|\.zip$|\.doc|\.xls|\.mp4$|\.mp3$)",
    re.IGNORECASE,
)

#: Links inside these elements are the site's own idea of what matters.
NAV_CONTAINERS = ("nav", "header")
FOOTER_CONTAINERS = ("footer",)

#: Phrases that indicate a call to action.
CTA_PATTERN = re.compile(
    r"\b(contact us|get in touch|get a quote|request a quote|free quote"
    r"|book now|book online|book a|schedule|make an appointment|enquire|inquire"
    r"|buy now|add to cart|shop now|order now|subscribe|sign up|get started"
    r"|start now|try free|free trial|call us|call now|request a demo|learn more"
    r"|find out more|download)\b",
    re.IGNORECASE,
)

#: Words that suggest social proof is present on the page.
TRUST_PATTERN = re.compile(
    r"\b(testimonial|review|rated|rating|stars|award|certified|accredited"
    r"|licensed|insured|guarantee|warranty|years of experience|since \d{4}"
    r"|trusted by|our clients|case study|iso \d|member of)\b",
    re.IGNORECASE,
)

#: Placeholder and neglect markers -- strong, checkable content problems.
PLACEHOLDER_PATTERN = re.compile(
    r"(lorem ipsum|dolor sit amet|coming soon|under construction"
    r"|page not found|insert text here|your text here|sample text"
    r"|\[.{0,20}placeholder.{0,20}\]|xxx-xxx|123-456-7890"
    r"|example\.com|yourdomain|company name here)",
    re.IGNORECASE,
)

#: Link text that tells a screen-reader user nothing.
VAGUE_LINK_PATTERN = re.compile(
    r"^\s*(click here|here|read more|more|link|this|learn more|continue|\>+|\.\.\.)\s*$",
    re.IGNORECASE,
)

#: Markers that mean a bot wall, not a business page. Seeing one stops the run.
BOT_WALL_MARKERS = (
    "captcha",
    "cf-browser-verification",
    "cf_chl_opt",
    "checking your browser",
    "attention required! | cloudflare",
    "please enable javascript and cookies",
    "access to this page has been denied",
    "are you a robot",
    "recaptcha",
    "hcaptcha",
)

#: Boilerplate stripped before text extraction.
_STRIP_TAGS = ("script", "style", "noscript", "svg", "template", "iframe")

# --------------------------------------------------------------------------- #
# Results
# --------------------------------------------------------------------------- #

OK = "ok"
BLOCKED = "blocked"
FAILED = "failed"
NO_WEBSITE = "no_website"


@dataclass
class Page:
    """One crawled page: its text, and the signals measured on it."""

    url: str
    kind: str
    title: str
    description: str
    headings: list[str]
    text: str
    facts: dict = field(default_factory=dict)


@dataclass
class SiteAnalysis:
    status: str
    detail: str
    pages: list[Page] = field(default_factory=list)
    emails_found: list[str] = field(default_factory=list)
    discovered: int = 0
    sitemap_used: bool = False
    #: True when the caller asked the crawl to stop part-way -- a cancelled run.
    #: Kept separate from `status`, because a half-read site that nobody asked
    #: for is not a site that could not be read, and the caller needs to be able
    #: to throw the partial result away rather than store it as the whole truth.
    stopped: bool = False

    @property
    def usable(self) -> bool:
        return self.status == OK and bool(self.pages)

    def summary(self) -> str:
        """One line for the review UI."""
        if not self.usable:
            return self.detail
        kinds = ", ".join(dict.fromkeys(p.kind for p in self.pages))
        via = " via sitemap" if self.sitemap_used else ""
        return (f"Read {len(self.pages)} of {self.discovered} discovered "
                f"page(s){via}: {kinds}")

    def as_context(self, char_budget: int | None = None) -> str:
        """Page text and measured signals, formatted for the AI.

        The signals are never trimmed -- they are the evidence, and they are
        cheap. Prose is shared out across the pages that were read, so adding a
        sixth page shortens each excerpt rather than growing the request past the
        model's rate limit.
        """
        if not self.usable:
            return ""

        budget = CONTEXT_BUDGET if char_budget is None else char_budget
        blocks = []
        headers = []

        # Build everything except the prose first, so the leftover is known.
        for index, page in enumerate(self.pages, 1):
            parts = [f"### PAGE {index} -- {page.kind.upper()}: {page.url}"]
            if page.title:
                parts.append(f"Title: {page.title}")
            parts.append(
                f"Meta description: {page.description}" if page.description
                else "Meta description: MISSING"
            )
            if page.headings:
                parts.append("Headings: " + " | ".join(page.headings[:15]))
            if page.facts:
                parts.append("Measured signals: " + _format_facts(page.facts))
            headers.append("\n".join(parts))

        spent = sum(len(h) for h in headers)
        per_page = max(MIN_PAGE_TEXT, (budget - spent) // max(1, len(self.pages)))

        for header, page in zip(headers, self.pages):
            block = header
            if page.text:
                excerpt = page.text[:per_page]
                suffix = " (truncated)" if len(page.text) > per_page else ""
                block += f"\nVisible text{suffix}:\n{excerpt}"
            blocks.append(block)

        return "\n\n".join(blocks)


def _format_facts(facts: dict) -> str:
    return "; ".join(f"{k}={v}" for k, v in facts.items() if v not in (None, "", []))


# --------------------------------------------------------------------------- #
# HTTP plumbing
# --------------------------------------------------------------------------- #

def _headers() -> dict[str, str]:
    return {
        "User-Agent": USER_AGENT.format(contact=CONTACT),
        "Accept": "text/html,application/xhtml+xml",
        "Accept-Language": "en",
    }


def _throttle(host: str) -> None:
    with _lock:
        wait = HOST_DELAY - (time.monotonic() - _last_hit.get(host, 0.0))
        if wait > 0:
            time.sleep(wait)
        _last_hit[host] = time.monotonic()


def normalise(url: str) -> str:
    url = (url or "").strip()
    if not url:
        return ""
    if not url.startswith(("http://", "https://")):
        url = f"https://{url}"
    return url


def _canonical(url: str) -> str:
    """Strip fragment, query and trailing slash so duplicates collapse."""
    parsed = urlparse(url)
    path = parsed.path.rstrip("/") or "/"
    return urlunparse((parsed.scheme, parsed.netloc.lower(), path, "", "", ""))


class Blocked(Exception):
    """The site actively declined the request. Stop, do not work around it."""


@dataclass
class Fetched:
    html: str
    load_ms: int
    size: int
    final_url: str


def _fetch(url: str) -> Fetched:
    """GET one HTML page, timing it. Raises Blocked when clearly unwelcome."""
    _throttle(urlparse(url).netloc)
    started = time.monotonic()
    response = requests.get(
        url, headers=_headers(), timeout=TIMEOUT, allow_redirects=True, stream=True
    )

    if response.status_code in (401, 402, 403, 429):
        raise Blocked(
            f"site returned HTTP {response.status_code} -- access restricted"
        )
    response.raise_for_status()

    if "html" not in response.headers.get("Content-Type", "").lower():
        raise ValueError("not an HTML page")

    body = response.raw.read(MAX_BYTES, decode_content=True) or b""
    load_ms = int((time.monotonic() - started) * 1000)
    html = body.decode(response.encoding or "utf-8", errors="replace")

    if any(marker in html[:4000].lower() for marker in BOT_WALL_MARKERS):
        raise Blocked("site is behind a bot check -- not bypassed")

    return Fetched(html, load_ms, len(body), response.url)


def _robots_for(base: str) -> RobotFileParser | None:
    """Fetch and cache robots.txt. None means "no rules published"."""
    host = urlparse(base).netloc
    if host in _robots:
        return _robots[host]

    parser: RobotFileParser | None = None
    try:
        _throttle(host)
        response = requests.get(
            urljoin(base, "/robots.txt"), headers=_headers(), timeout=TIMEOUT
        )
        if response.status_code == 200:
            parser = RobotFileParser()
            parser.parse(response.text.splitlines())
        elif response.status_code in (401, 403):
            # The spec treats an unauthorised robots.txt as "stay out".
            parser = RobotFileParser()
            parser.parse(["User-agent: *", "Disallow: /"])
    except requests.RequestException:
        parser = None  # unreachable robots.txt -- proceed, but gently

    _robots[host] = parser
    return parser


def _allowed(url: str, robots: RobotFileParser | None) -> bool:
    if robots is None:
        return True
    return robots.can_fetch(_headers()["User-Agent"], url)


# --------------------------------------------------------------------------- #
# Step 1 -- discover candidate pages
# --------------------------------------------------------------------------- #

def classify(url: str, anchor_text: str = "") -> tuple[str, int]:
    """Guess what a link is and how valuable it looks. ("other", 0) if not."""
    haystack = f"{urlparse(url).path} {anchor_text}".lower()
    for kind, pattern, score in PAGE_KINDS:
        if re.search(pattern, haystack):
            return kind, score
    return "other", 0


def discover_links(html: str, base: str) -> list[tuple[str, str, int]]:
    """Read the page's own navigation and links.

    Returns (url, kind, score). Links in <nav>/<header> get a bonus because the
    site is telling us those pages matter; footer links get a smaller one.
    Shallow paths are preferred over deep ones.
    """
    soup = BeautifulSoup(html, "html.parser")
    home_host = urlparse(base).netloc.lower().removeprefix("www.")

    # Which anchors sit inside navigation, and which inside the footer?
    nav_hrefs, footer_hrefs = set(), set()
    for tag in soup.find_all(NAV_CONTAINERS):
        nav_hrefs.update(a.get("href", "") for a in tag.find_all("a", href=True))
    for tag in soup.find_all(FOOTER_CONTAINERS):
        footer_hrefs.update(a.get("href", "") for a in tag.find_all("a", href=True))

    seen: dict[str, tuple[str, str, int]] = {}
    for anchor in soup.find_all("a", href=True)[:MAX_CANDIDATES]:
        raw = anchor["href"].strip()
        if not raw or raw.startswith(("#", "mailto:", "tel:", "javascript:")):
            continue

        target = urljoin(base, raw)
        parsed = urlparse(target)
        if parsed.scheme not in ("http", "https"):
            continue
        if parsed.netloc.lower().removeprefix("www.") != home_host:
            continue  # stay on the lead's own site
        if SKIP_PATTERN.search(target):
            continue

        canonical = _canonical(target)
        if canonical == _canonical(base):
            continue  # that is the home page

        kind, score = classify(target, anchor.get_text(" ", strip=True))
        if not score:
            continue

        if raw in nav_hrefs:
            score += 25          # the site's own primary navigation
        elif raw in footer_hrefs:
            score += 5
        depth = len([p for p in urlparse(canonical).path.split("/") if p])
        score -= max(0, depth - 1) * 8   # prefer top-level pages

        if canonical not in seen or score > seen[canonical][2]:
            seen[canonical] = (canonical, kind, score)

    return sorted(seen.values(), key=lambda row: -row[2])


def discover_sitemap(base: str, robots: RobotFileParser | None) -> list[tuple[str, str, int]]:
    """Read the sitemap, if the site publishes one.

    Tries the URLs robots.txt advertises first, then /sitemap.xml. Follows one
    level of sitemap index. Sitemaps are published precisely so crawlers can
    find pages, which makes this the politest discovery route available.
    """
    targets: list[str] = []
    if robots is not None:
        try:
            targets.extend(robots.site_maps() or [])
        except Exception:  # noqa: BLE001 - older parsers lack site_maps()
            pass
    targets.append(urljoin(base, "/sitemap.xml"))

    home_host = urlparse(base).netloc.lower().removeprefix("www.")
    found: dict[str, tuple[str, str, int]] = {}

    for sitemap_url in targets[:3]:
        try:
            _throttle(urlparse(sitemap_url).netloc)
            response = requests.get(
                sitemap_url, headers=_headers(), timeout=TIMEOUT
            )
            if response.status_code != 200:
                continue
            body = response.text[:1_500_000]
        except requests.RequestException:
            continue

        locs = re.findall(r"<loc>\s*([^<\s]+)\s*</loc>", body, re.IGNORECASE)

        # A sitemap index points at more sitemaps; follow one level.
        if "<sitemapindex" in body[:2000].lower():
            for nested in locs[:3]:
                try:
                    _throttle(urlparse(nested).netloc)
                    nested_body = requests.get(
                        nested, headers=_headers(), timeout=TIMEOUT
                    ).text[:1_500_000]
                    locs.extend(re.findall(
                        r"<loc>\s*([^<\s]+)\s*</loc>", nested_body, re.IGNORECASE))
                except requests.RequestException:
                    continue

        for loc in locs[:MAX_SITEMAP_URLS]:
            parsed = urlparse(loc)
            if parsed.netloc.lower().removeprefix("www.") != home_host:
                continue
            if SKIP_PATTERN.search(loc):
                continue
            canonical = _canonical(loc)
            if canonical == _canonical(base):
                continue
            kind, score = classify(loc)
            if not score:
                continue
            depth = len([p for p in parsed.path.split("/") if p])
            score -= max(0, depth - 1) * 8
            if canonical not in found or score > found[canonical][2]:
                found[canonical] = (canonical, kind, score)

        if found:
            break  # one usable sitemap is enough

    return sorted(found.values(), key=lambda row: -row[2])


def choose_pages(candidates: list[tuple[str, str, int]],
                 limit: int) -> list[tuple[str, str, int]]:
    """Pick the most informative spread, not just the top scores.

    Diversity matters: five service pages say less about the customer journey
    than a services page plus pricing, contact, about and testimonials. So the
    first pass takes the best page of each kind, and only then does a second
    pass fill remaining slots with runners-up.
    """
    chosen: list[tuple[str, str, int]] = []
    used_kinds: set[str] = set()

    for row in candidates:
        if len(chosen) >= limit:
            break
        if row[1] not in used_kinds:
            chosen.append(row)
            used_kinds.add(row[1])

    for row in candidates:
        if len(chosen) >= limit:
            break
        if row not in chosen:
            chosen.append(row)

    return chosen


# --------------------------------------------------------------------------- #
# Step 2 -- measure a page
# --------------------------------------------------------------------------- #

def _clean(text: str) -> str:
    return re.sub(r"[ \t\r\f\v]+", " ", re.sub(r"\n{2,}", "\n", text)).strip()


def measure(soup: BeautifulSoup, html: str, fetched: Fetched) -> dict:
    """Collect checkable signals from one page.

    Everything here is a fact about the markup or the response -- a count, a
    presence check, a measured duration. These are the only grounds on which the
    AI is allowed to raise a finding.
    """
    facts: dict = {}

    # --- performance -----------------------------------------------------
    facts["load_ms"] = fetched.load_ms
    # One decimal place: rounding a small page to a flat "0" would read as
    # evidence of an empty response, which is not what it means.
    facts["page_kb"] = round(fetched.size / 1024, 1)
    facts["https"] = fetched.final_url.startswith("https://")
    scripts = soup.find_all("script", src=True)
    facts["external_scripts"] = len(scripts)
    facts["stylesheets"] = len(soup.find_all("link", rel="stylesheet"))
    facts["inline_style_blocks"] = len(soup.find_all("style"))

    # --- images ----------------------------------------------------------
    images = soup.find_all("img")
    facts["images"] = len(images)
    if images:
        facts["images_missing_alt"] = sum(
            1 for i in images if not (i.get("alt") or "").strip())
        facts["images_no_dimensions"] = sum(
            1 for i in images if not i.get("width") and not i.get("height"))
        facts["images_lazy_loaded"] = sum(
            1 for i in images if i.get("loading") == "lazy")
        srcs = " ".join((i.get("src") or "") for i in images).lower()
        modern = sum(srcs.count(ext) for ext in (".webp", ".avif"))
        legacy = sum(srcs.count(ext) for ext in (".jpg", ".jpeg", ".png", ".gif"))
        facts["images_modern_format"] = modern
        facts["images_legacy_format"] = legacy

    # --- mobile ----------------------------------------------------------
    viewport = soup.find("meta", attrs={"name": re.compile("^viewport$", re.I)})
    facts["viewport_meta"] = bool(viewport)
    if viewport:
        facts["viewport_content"] = (viewport.get("content") or "")[:80]
    facts["fixed_width_attrs"] = len(soup.find_all(
        attrs={"width": re.compile(r"^\d{3,}$")}))

    # --- structure and headings -----------------------------------------
    h1s = soup.find_all("h1")
    facts["h1_count"] = len(h1s)
    facts["h2_count"] = len(soup.find_all("h2"))
    facts["h3_count"] = len(soup.find_all("h3"))

    # --- SEO -------------------------------------------------------------
    title = soup.title.get_text(" ", strip=True) if soup.title else ""
    facts["title_length"] = len(title)
    meta_desc = soup.find("meta", attrs={"name": re.compile("^description$", re.I)})
    desc = (meta_desc.get("content") or "").strip() if meta_desc else ""
    facts["meta_description_length"] = len(desc)
    facts["canonical"] = bool(soup.find("link", rel="canonical"))
    facts["og_tags"] = len(soup.find_all(
        "meta", attrs={"property": re.compile("^og:", re.I)}))
    facts["structured_data_blocks"] = len(soup.find_all(
        "script", attrs={"type": re.compile("ld\\+json", re.I)}))
    facts["html_lang"] = (soup.find("html") or {}).get("lang") or "MISSING"

    # --- content ---------------------------------------------------------
    body_text = _clean(soup.get_text("\n"))
    words = body_text.split()
    facts["word_count"] = len(words)
    placeholders = PLACEHOLDER_PATTERN.findall(body_text)
    if placeholders:
        facts["placeholder_text_found"] = sorted({p.lower() for p in placeholders})[:4]
    years = re.findall(r"(?:©|copyright|&copy;)\s*(\d{4})", body_text, re.IGNORECASE)
    if years:
        facts["copyright_year"] = max(years)

    # --- conversion ------------------------------------------------------
    actionable = soup.find_all(["a", "button"])
    cta_hits = [
        _clean(el.get_text(" "))[:40]
        for el in actionable
        if CTA_PATTERN.search(el.get_text(" ", strip=True) or "")
    ]
    facts["cta_count"] = len(cta_hits)
    if cta_hits:
        facts["cta_examples"] = cta_hits[:5]

    forms = soup.find_all("form")
    facts["forms"] = len(forms)
    if forms:
        inputs = soup.find_all(["input", "textarea", "select"])
        facts["form_fields"] = len(inputs)
        facts["form_fields_unlabelled"] = sum(
            1 for i in inputs
            if not i.get("aria-label") and not i.get("placeholder")
            and not (i.get("id") and soup.find("label", attrs={"for": i.get("id")}))
            and i.get("type") not in ("hidden", "submit", "button")
        )

    # --- contact ---------------------------------------------------------
    facts["mailto_links"] = len(soup.select('a[href^="mailto:"]'))
    facts["tel_links"] = len(soup.select('a[href^="tel:"]'))
    facts["map_embed"] = bool(soup.find(
        "iframe", src=re.compile(r"(google\.com/maps|openstreetmap|mapbox)", re.I))
    ) or "google.com/maps" in html.lower()

    # --- trust and social ------------------------------------------------
    facts["trust_signal_mentions"] = len(TRUST_PATTERN.findall(body_text))
    facts["social_links"] = len(soup.select(
        'a[href*="facebook.com"], a[href*="instagram.com"], a[href*="linkedin.com"], '
        'a[href*="twitter.com"], a[href*="x.com"], a[href*="youtube.com"], '
        'a[href*="tiktok.com"]'
    ))

    # --- accessibility ---------------------------------------------------
    links = soup.find_all("a", href=True)
    facts["links"] = len(links)
    facts["vague_link_text"] = sum(
        1 for a in links if VAGUE_LINK_PATTERN.match(a.get_text(" ", strip=True) or ""))
    facts["links_new_tab_no_warning"] = sum(
        1 for a in links if a.get("target") == "_blank" and not a.get("aria-label"))

    # --- platform --------------------------------------------------------
    generator = soup.find("meta", attrs={"name": re.compile("^generator$", re.I)})
    if generator:
        facts["generator"] = (generator.get("content") or "")[:60]

    return facts


def extract(fetched: Fetched, url: str, kind: str) -> Page:
    """Measure the page, then strip it down to readable text."""
    soup = BeautifulSoup(fetched.html, "html.parser")
    facts = measure(soup, fetched.html, fetched)

    meta = soup.find("meta", attrs={"name": re.compile("^description$", re.I)}) or \
        soup.find("meta", attrs={"property": "og:description"})
    title = _clean(soup.title.get_text(" ")) if soup.title else ""

    # Measurement is done; now remove chrome so the text reads cleanly.
    for tag in soup(list(_STRIP_TAGS)):
        tag.decompose()
    for tag in soup.find_all(["nav", "footer", "header", "form"]):
        tag.decompose()

    headings = [
        _clean(h.get_text(" "))
        for h in soup.find_all(["h1", "h2", "h3"])
        if _clean(h.get_text(" "))
    ]

    return Page(
        url=url,
        kind=kind,
        title=title,
        description=_clean(meta.get("content", "")) if meta else "",
        headings=headings,
        text=_clean(soup.get_text("\n"))[:TEXT_BUDGET],
        facts=facts,
    )


def scrape_emails(html: str) -> list[str]:
    """Collect mailto: addresses -- these are published for contact."""
    soup = BeautifulSoup(html, "html.parser")
    addresses = []
    for anchor in soup.find_all("a", href=True):
        href = anchor["href"].strip()
        if href.lower().startswith("mailto:"):
            address = href[7:].split("?")[0].strip()
            if "@" in address and address not in addresses:
                addresses.append(address)
    return addresses


# --------------------------------------------------------------------------- #
# The public entry point
# --------------------------------------------------------------------------- #

def analyse(website: str, target_internal: int = TARGET_INTERNAL,
            should_stop=None) -> SiteAnalysis:
    """Crawl and measure a lead's website. Never raises.

    `should_stop` is an optional callable checked before every network request.
    It is how Cancel reaches a crawl that is already running: the fetch in flight
    cannot be aborted, but the next one need never start, so a cancelled lead
    stops within one page rather than after five. The result carries
    `stopped=True` so the caller can discard a partial read instead of saving it.
    """
    def stop_now() -> bool:
        return bool(should_stop and should_stop())

    if stop_now():
        return SiteAnalysis(FAILED, "Cancelled before the crawl started.",
                            stopped=True)

    url = normalise(website)
    if not url:
        return SiteAnalysis(NO_WEBSITE, "No website published for this lead.")

    try:
        robots = _robots_for(url)
    except Exception:  # noqa: BLE001 - robots is best-effort
        robots = None

    if not _allowed(url, robots):
        return SiteAnalysis(
            BLOCKED, "robots.txt disallows crawling this site -- skipped.")

    try:
        home = _fetch(url)
    except Blocked as exc:
        return SiteAnalysis(BLOCKED, f"Not analysed: {exc}.")
    except (requests.RequestException, ValueError) as exc:
        return SiteAnalysis(FAILED, f"Could not read the website: {exc}.")

    pages = [extract(home, url, "home")]
    emails = scrape_emails(home.html)

    if stop_now():
        return SiteAnalysis(
            OK, f"Cancelled after {len(pages)} page(s).",
            pages, emails, 0, False, stopped=True)

    # Discovery: the site's own links, plus its sitemap if it has one.
    candidates = discover_links(home.html, url)
    sitemap_rows = discover_sitemap(url, robots)
    sitemap_used = bool(sitemap_rows)

    merged: dict[str, tuple[str, str, int]] = {}
    for row in candidates + sitemap_rows:
        if row[0] not in merged or row[2] > merged[row[0]][2]:
            merged[row[0]] = row
    ranked = sorted(merged.values(), key=lambda row: -row[2])

    budget = min(target_internal, MAX_PAGES - 1)
    # Over-select so pages that turn out to be unreachable can be skipped
    # without dropping below the target.
    plan = choose_pages(ranked, budget * 2)

    for link, kind, _score in plan:
        if len(pages) - 1 >= budget:
            break
        # Checked before the fetch, not after: the point is not to start work
        # that has already been called off.
        if stop_now():
            return SiteAnalysis(
                OK, f"Cancelled after {len(pages)} page(s).",
                pages, emails, len(ranked), sitemap_used, stopped=True)
        if not _allowed(link, robots):
            continue
        try:
            fetched = _fetch(link)
        except Blocked as exc:
            # The site drew a line mid-crawl. Keep what we have and stop.
            return SiteAnalysis(
                OK if len(pages) > 1 else BLOCKED,
                f"Read {len(pages)} page(s); stopped: {exc}.",
                pages, emails, len(ranked), sitemap_used,
            )
        except (requests.RequestException, ValueError):
            continue

        pages.append(extract(fetched, link, kind))
        emails.extend(e for e in scrape_emails(fetched.html) if e not in emails)

    internal = len(pages) - 1
    detail = f"Read {len(pages)} page(s) ({internal} internal) of {len(ranked)} discovered."
    if internal < target_internal:
        detail += (f" Only {internal} useful internal page(s) were reachable on "
                   "this site.")

    return SiteAnalysis(OK, detail, pages, emails, len(ranked), sitemap_used)
