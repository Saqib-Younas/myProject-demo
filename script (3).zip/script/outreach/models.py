"""
Two tables: a campaign, and one draft per lead in it.

This is the sending history the brief asks for -- who was contacted, with what
subject, when, and what went wrong if it failed. It is also what prevents a
double send: `unique_together` on (campaign, email) stops the same lead entering
a campaign twice, and the send loop claims each draft with a conditional UPDATE
so a second Send click cannot re-send a row that is already on its way out.
"""

from __future__ import annotations

import uuid
from urllib.parse import urlparse

from django.conf import settings
from django.db import models
from django.utils import timezone

#: The per-lead cycle, in order. Every selected lead is taken through all four
#: steps before the next lead is started -- the whole run is sequential, never
#: batched by stage. `Campaign.current_step` holds the one in flight.
LEAD_STEPS = (
    ("crawl", "Website analysed"),
    ("review", "Issues identified"),
    ("generate", "Email generated"),
    ("score", "Scored and classified"),
    ("save", "Result saved"),
)
STEP_KEYS = [key for key, _label in LEAD_STEPS]


class Campaign(models.Model):
    """One outreach run over a set of scraped leads."""

    class Phase(models.TextChoices):
        SETUP = "setup", "Awaiting sender settings"
        CRAWLING = "crawling", "Discovering and reading websites"
        ANALYSING = "analysing", "Reviewing websites for issues"
        GENERATING = "generating", "Generating emails"
        #: Stopped by the AI provider, not by a failure. The run keeps its place
        #: and picks up from the first unfinished lead when the window passes.
        PAUSED_RATE_LIMIT = "paused_rate_limit", "Paused — AI rate limit"
        #: The user pressed Cancel and a worker is still finishing the lead it
        #: was on. Transient, and the state the worker checks before each lead.
        CANCEL_REQUESTED = "cancel_requested", "Cancelling…"
        CANCELLED = "cancelled", "Processing cancelled"
        REVIEW = "review", "Awaiting review"
        SENDING = "sending", "Sending"
        DONE = "done", "Finished"
        FAILED = "failed", "Failed"

    class Pause(models.TextChoices):
        """Why a run is paused. The two need opposite handling.

        A per-minute limit is waited out automatically. A spent daily, monthly or
        billing allowance is not: waiting a minute changes nothing, so the run
        stops and says so, and the user waits for the reset or switches provider.
        """

        RATE_LIMIT = "rate_limit", "Rate limit — retrying shortly"
        QUOTA = "quota", "Allowance used up"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)

    #: Who this campaign belongs to. Nullable only so the migration can run
    #: against a database that predates accounts; every new row sets it, and a
    #: row with no owner is visible to nobody -- see `manage.py claim_data`.
    #: EmailDraft ownership is derived from here rather than duplicated, so the
    #: two can never disagree about who a draft belongs to.
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="campaigns", null=True, blank=True, db_index=True,
    )

    # Where the leads came from, carried over from the scrape.
    country = models.CharField(max_length=120, blank=True)
    city = models.CharField(max_length=120, blank=True)
    category = models.CharField(max_length=120, blank=True)

    # Sender settings (section 5 of the brief).
    sender_name = models.CharField(max_length=120, blank=True)
    sender_email = models.EmailField(blank=True)
    sender_company = models.CharField(max_length=160, blank=True)
    provider = models.CharField(max_length=32, blank=True)
    service_pitch = models.TextField(blank=True)

    # 24, not 16: "paused_rate_limit" is 17 characters.
    phase = models.CharField(max_length=24, choices=Phase.choices,
                             default=Phase.SETUP)
    error = models.TextField(blank=True)
    finished_at = models.DateTimeField(null=True, blank=True)

    # --- why the run stopped, and when it may start again ------------------- #
    #
    # Persisted rather than held in the worker, for the same reason as
    # `current_step`: a rate limit that outlives the process must not leave the
    # page waiting for progress that will never arrive, and a user who reloads
    # needs to see how long the wait is.
    pause_reason = models.CharField(max_length=16, choices=Pause.choices,
                                    blank=True)
    #: What to tell the user. Written locally -- never a provider response body.
    pause_detail = models.CharField(max_length=300, blank=True)
    #: When processing may resume. Compared against the clock rather than counted
    #: down, so a closed laptop does not shorten the wait.
    retry_at = models.DateTimeField(null=True, blank=True)
    #: How many times this run has been rate limited. Drives the exponential
    #: backoff for providers that do not say how long to wait.
    pause_count = models.PositiveSmallIntegerField(default=0)
    cancelled_at = models.DateTimeField(null=True, blank=True)

    # Which lead the sequential run is on, and which of its four steps. Stored
    # rather than held in the worker thread so the progress panel survives a
    # page reload, and so a restarted server cannot leave the UI claiming a
    # lead is still being analysed.
    current_draft = models.ForeignKey(
        "EmailDraft", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="+",
    )
    current_step = models.CharField(max_length=12, blank=True)

    class Meta:
        ordering = ("-created_at",)

    def __str__(self) -> str:
        return f"{self.category or 'leads'} in {self.city or 'unknown'} ({self.id.hex[:8]})"

    @property
    def label(self) -> str:
        bits = [b for b in (self.category, self.city, self.country) if b]
        return " · ".join(bits) or "Untitled campaign"

    # --- run control ------------------------------------------------------- #
    #
    # One place answers "may this run carry on?", so the worker thread, the
    # cancel endpoint and the progress panel cannot disagree about it.

    #: Phases where a lead-processing job is, or should be, doing work.
    PROCESSING_PHASES = ("crawling", "analysing", "generating")
    #: Phases a Cancel press is meaningful in.
    CANCELLABLE_PHASES = PROCESSING_PHASES + (
        "paused_rate_limit", "cancel_requested")

    @property
    def is_processing(self) -> bool:
        return self.phase in self.PROCESSING_PHASES

    @property
    def is_paused(self) -> bool:
        return self.phase == self.Phase.PAUSED_RATE_LIMIT

    @property
    def is_cancelling(self) -> bool:
        return self.phase == self.Phase.CANCEL_REQUESTED

    @property
    def is_cancelled(self) -> bool:
        return self.phase == self.Phase.CANCELLED

    @property
    def stopping(self) -> bool:
        """Cancel has been asked for, or has already happened.

        The worker checks this before each lead, and cancellation therefore takes
        precedence over a rate-limit wait: a job asleep until the retry window
        wakes, sees this, and stops instead of resuming.
        """
        return self.phase in (self.Phase.CANCEL_REQUESTED, self.Phase.CANCELLED)

    @property
    def retry_seconds(self) -> int:
        """Whole seconds until the retry window opens. 0 once it has."""
        if not self.retry_at:
            return 0
        return max(0, int((self.retry_at - timezone.now()).total_seconds()))

    @property
    def retry_ready(self) -> bool:
        """Paused, and the wait is over."""
        return self.is_paused and self.retry_seconds == 0

    def unfinished_count(self) -> int:
        """Leads that were queued and never completed.

        What "resume" would pick up, and what a cancelled run leaves behind. A
        lead that finished stays finished -- this deliberately counts only the
        ones with no completion stamp.
        """
        return self.drafts.filter(
            sequence__gt=0, processed_at__isnull=True,
        ).exclude(status__in=(EmailDraft.Status.EXCLUDED,
                              EmailDraft.Status.DUPLICATE,
                              EmailDraft.Status.SUPPRESSED,
                              EmailDraft.Status.NO_EMAIL)).count()

    def counts(self) -> dict[str, int]:
        """Live progress figures, straight from the drafts table."""
        rows = self.drafts.values("status").annotate(n=models.Count("id"))
        by_status = {row["status"]: row["n"] for row in rows}
        working = sum(
            by_status.get(s, 0)
            for s in (EmailDraft.Status.PENDING, EmailDraft.Status.CRAWLED,
                      EmailDraft.Status.ANALYSED, EmailDraft.Status.GENERATED,
                      EmailDraft.Status.APPROVED, EmailDraft.Status.SENDING)
        )
        approved = by_status.get(EmailDraft.Status.APPROVED, 0)
        return {
            "total": sum(by_status.values()),
            "in_workflow": working,
            "approved": approved,
            "sent": by_status.get(EmailDraft.Status.SENT, 0),
            "failed": by_status.get(EmailDraft.Status.FAILED, 0),
            "rejected": by_status.get(EmailDraft.Status.REJECTED, 0),
            "excluded": by_status.get(EmailDraft.Status.EXCLUDED, 0),
            "no_email": by_status.get(EmailDraft.Status.NO_EMAIL, 0),
            "duplicate": by_status.get(EmailDraft.Status.DUPLICATE, 0),
            "suppressed": by_status.get(EmailDraft.Status.SUPPRESSED, 0),
            "remaining": approved,
        }

    def progress(self) -> dict:
        """Where the sequential run has got to: "lead 7 of 25", and which step.

        Computed from the drafts table plus `current_draft`/`current_step`, so it
        is the same answer whether the browser has been open the whole time or
        has just been reloaded.
        """
        rows = list(
            self.drafts.filter(sequence__gt=0).order_by("sequence")
            .values("id", "sequence", "business_name", "website", "subject",
                    "analysis_status", "error_message", "processed_at")
        )
        total = len(rows)
        done = sum(1 for row in rows if row["processed_at"])

        stopped = self.is_cancelled

        current_row = None
        leads = []
        for row in rows:
            if row["processed_at"]:
                # A lead that finished with no email is the only real failure;
                # an unreadable website still gets an email, just without any
                # claims about the site.
                state = "completed" if row["subject"] else "failed"
            elif stopped:
                # Cancelled: no lead is in flight, and the rest were never
                # started. "stopped" rather than "failed" -- nothing went wrong
                # with them, and resuming picks them up unchanged.
                state = "stopped"
            elif row["id"] == self.current_draft_id:
                state = "paused" if self.is_paused else "current"
                current_row = row
            else:
                state = "waiting"
            leads.append({
                "id": row["id"],
                "sequence": row["sequence"],
                "business_name": row["business_name"],
                "state": state,
            })

        index = STEP_KEYS.index(self.current_step) if self.current_step in STEP_KEYS else -1
        finished = total > 0 and done == total
        if stopped:
            # No step is in flight once a run is cancelled, so none is shown as
            # current -- a spinning tick on a cancelled job reads as still going.
            index = -1
        steps = []
        for position, (key, label) in enumerate(LEAD_STEPS):
            if index < 0:
                state = "done" if finished else "waiting"
            elif position < index:
                state = "done"
            elif position == index:
                state = "current"
            else:
                state = "waiting"
            steps.append({"key": key, "label": label, "state": state})

        # The lead in flight counts towards the bar: lead 7 of 25 reads as 28%,
        # not 24%, which is what somebody watching it expects to see.
        position = done + (1 if current_row else 0)
        upcoming = next((lead for lead in leads if lead["state"] == "waiting"), None)

        return {
            "total": total,
            "done": done,
            "position": position,
            "percent": round(position / total * 100) if total else 0,
            "step": self.current_step,
            "steps": steps,
            "leads": leads,
            # Why the run is not moving, when it is not moving. One dictionary so
            # the panel has a single thing to check rather than inferring it from
            # the phase string.
            "control": self.control_state(),
            "unfinished": total - done,
            "current": {
                "id": current_row["id"],
                "sequence": current_row["sequence"],
                "business_name": current_row["business_name"],
                "website": current_row["website"],
                "analysis_status": current_row["analysis_status"],
            } if current_row else None,
            "next": upcoming,
            "finished": finished,
        }

    def control_state(self) -> dict:
        """Paused, cancelling, cancelled or running -- and the facts behind it.

        Everything the progress panel needs to explain a stopped run without
        parsing a phase string or doing arithmetic on a timestamp.
        """
        return {
            "state": (
                "cancelled" if self.is_cancelled else
                "cancelling" if self.is_cancelling else
                "paused" if self.is_paused else
                "running" if self.is_processing else "idle"
            ),
            "cancellable": self.phase in self.CANCELLABLE_PHASES,
            "cancelled_at": (self.cancelled_at.isoformat()
                             if self.cancelled_at else None),
            "pause_reason": self.pause_reason,
            "pause_reason_label": (self.get_pause_reason_display()
                                   if self.pause_reason else ""),
            "pause_detail": self.pause_detail,
            "pause_count": self.pause_count,
            "retry_at": self.retry_at.isoformat() if self.retry_at else None,
            "retry_seconds": self.retry_seconds,
            # True once a paused run may carry on. The panel asks the server to
            # resume rather than deciding for itself that the wait is over.
            "retry_ready": self.retry_ready,
            #: A quota needs the provider's reset or a different credential --
            #: there is no wait that fixes it, so no countdown is offered.
            "waitable": self.pause_reason == self.Pause.RATE_LIMIT,
        }


class Lifecycle(models.TextChoices):
    """Where a lead has got to, in sales terms.

    Separate from EmailDraft.Status, which tracks the *machinery* -- crawled,
    analysed, approved, sending. This is what a person wants to know, and the two
    are not the same thing: a draft can be `generated` while the lead is still
    only `analyzed`, because nobody has decided to contact them yet.

    Most transitions are derived from the machinery (see `EmailDraft.derive_
    lifecycle`). The last four are judgements only a person can make, so they are
    set by hand and never overwritten by the derivation.
    """

    NEW = "new", "New"
    ANALYZING = "analyzing", "Analyzing"
    ANALYZED = "analyzed", "Analyzed"
    QUALIFIED = "qualified", "Qualified"
    EMAIL_READY = "email_ready", "Email ready"
    CONTACTED = "contacted", "Contacted"
    FOLLOW_UP = "follow_up", "Follow-up"
    REPLIED = "replied", "Replied"
    INTERESTED = "interested", "Interested"
    MEETING = "meeting", "Meeting"
    WON = "won", "Won"
    LOST = "lost", "Lost"
    DO_NOT_CONTACT = "do_not_contact", "Do not contact"


#: Stages a person sets, which the automatic derivation must not undo.
MANUAL_LIFECYCLE = (Lifecycle.INTERESTED, Lifecycle.MEETING, Lifecycle.WON,
                    Lifecycle.LOST, Lifecycle.DO_NOT_CONTACT)

#: The happy path, in order, for the progress display on the lead page.
LIFECYCLE_PATH = (Lifecycle.NEW, Lifecycle.ANALYZING, Lifecycle.ANALYZED,
                  Lifecycle.QUALIFIED, Lifecycle.EMAIL_READY,
                  Lifecycle.CONTACTED, Lifecycle.FOLLOW_UP, Lifecycle.REPLIED,
                  Lifecycle.INTERESTED, Lifecycle.MEETING, Lifecycle.WON)


class EmailDraft(models.Model):
    """One lead: its website analysis, its scores, its email, its outcome."""

    class Status(models.TextChoices):
        NO_EMAIL = "no_email", "No public email"
        EXCLUDED = "excluded", "Not selected"
        DUPLICATE = "duplicate", "Already contacted"
        SUPPRESSED = "suppressed", "Do not contact"
        PENDING = "pending", "Queued"
        CRAWLED = "crawled", "Website crawled"
        ANALYSED = "analysed", "Website reviewed"
        GENERATED = "generated", "Email drafted"
        APPROVED = "approved", "Approved"
        REJECTED = "rejected", "Rejected"
        SENDING = "sending", "Sending"
        SENT = "sent", "Sent"
        FAILED = "failed", "Failed"

    campaign = models.ForeignKey(Campaign, on_delete=models.CASCADE,
                                 related_name="drafts")

    # The lead, copied from the scrape so the campaign is self-contained.
    business_name = models.CharField(max_length=255)
    email = models.EmailField(blank=True)
    website = models.URLField(max_length=500, blank=True)
    category = models.CharField(max_length=160, blank=True)
    address = models.CharField(max_length=400, blank=True)
    phone = models.CharField(max_length=80, blank=True)
    city = models.CharField(max_length=160, blank=True)
    country = models.CharField(max_length=160, blank=True)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    source = models.URLField(max_length=500, blank=True)

    # Website crawl.
    analysis_status = models.CharField(max_length=16, blank=True)
    analysis_note = models.CharField(max_length=400, blank=True)
    analysis_context = models.TextField(blank=True)
    #: The pages the crawler chose and read, as [{"url", "kind"}, ...].
    #: One entry per page read: {"url", "kind", "facts"}. `facts` is that page's
    #: measured signals, and is absent on rows crawled before it was stored.
    pages_read = models.JSONField(default=list, blank=True)
    pages_discovered = models.PositiveIntegerField(default=0)

    # Website review.
    business_summary = models.TextField(blank=True)
    #: Verified findings, as [{"issue", "evidence", "why_it_matters", ...}, ...].
    findings = models.JSONField(default=list, blank=True)

    # The email.
    subject = models.CharField(max_length=400, blank=True)
    body = models.TextField(blank=True)
    observation = models.CharField(max_length=600, blank=True)
    #: Which findings the email actually drew on.
    findings_used = models.JSONField(default=list, blank=True)
    edited = models.BooleanField(default=False)
    regenerations = models.PositiveSmallIntegerField(default=0)

    status = models.CharField(max_length=16, choices=Status.choices,
                              default=Status.PENDING)
    error_message = models.TextField(blank=True)
    sent_at = models.DateTimeField(null=True, blank=True)

    #: 1-based position in the sequential run, stamped when the run starts. It
    #: is what lets the progress panel say "Lead 7 of 25" and keep saying the
    #: same thing after a reload; 0 means this lead is not in the run.
    sequence = models.PositiveIntegerField(default=0)
    #: When this lead's own crawl -> review -> email -> save cycle finished.
    #: Set whether the cycle succeeded or not: it means "we are done with this
    #: lead and have moved on", which is what the progress list needs to know.
    processed_at = models.DateTimeField(null=True, blank=True)

    # --- lead intelligence ------------------------------------------------
    #
    # Every number here is recomputed from the audit's measured signals by
    # outreach/scoring.py, and stored so the table can sort and filter in SQL.
    # `score_detail` holds the factors behind each one, which is what makes a
    # score explainable rather than merely present.

    #: website_found | no_website_opportunity | website_unverified
    classification = models.CharField(max_length=24, blank=True, db_index=True)
    classification_reason = models.CharField(max_length=400, blank=True)

    #: The cached audit these scores came from. Shared between drafts for the
    #: same website, so two campaigns do not pay for one crawl twice.
    audit = models.ForeignKey(
        "WebsiteAudit", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="drafts",
    )

    score_overall = models.PositiveSmallIntegerField(default=0, db_index=True)
    score_website = models.PositiveSmallIntegerField(default=0)
    score_value = models.PositiveSmallIntegerField(default=0)
    score_missing = models.PositiveSmallIntegerField(default=0)
    score_readiness = models.PositiveSmallIntegerField(default=0)
    #: hot | warm | low | skip -- derived from score_overall and the configured
    #: thresholds, stored so the queues are one indexed query each.
    priority = models.CharField(max_length=8, blank=True, db_index=True)

    #: {"overall": {...}, "website": {...}, ...} -- the factors behind each score.
    score_detail = models.JSONField(default=dict, blank=True)
    scored_at = models.DateTimeField(null=True, blank=True)

    recommended_service = models.CharField(max_length=64, blank=True)
    service_reason = models.CharField(max_length=400, blank=True)
    #: One factual sentence. Only ever restates evidence already held.
    why_prospect = models.CharField(max_length=400, blank=True)
    #: For no-website leads: the specific benefits worth talking about.
    benefits = models.JSONField(default=list, blank=True)

    lifecycle = models.CharField(max_length=16, choices=Lifecycle.choices,
                                 default=Lifecycle.NEW, db_index=True)
    lifecycle_note = models.CharField(max_length=300, blank=True)
    lifecycle_changed_at = models.DateTimeField(null=True, blank=True)

    #: A deliberate re-contact. Set only by the "Contact anyway" action, which
    #: exists because the name-and-city matching tier occasionally blocks two
    #: genuinely different businesses. It overrides the *sending history* and
    #: nothing else -- a suppressed address stays blocked, with or without it.
    force_contact = models.BooleanField(default=False)
    force_reason = models.CharField(max_length=300, blank=True)

    class Meta:
        ordering = ("business_name",)
        constraints = [
            # One *sendable* draft per address per campaign, so a campaign can
            # never mail the same mailbox twice. Rows flagged `duplicate` or
            # `suppressed` are exempt: they are the visible record of a
            # collision (two map pins sharing one info@ address) and are never
            # sent, so they must be allowed to keep the address they collided on.
            models.UniqueConstraint(
                fields=("campaign", "email"),
                condition=(
                    ~models.Q(email="")
                    & ~models.Q(status__in=("duplicate", "suppressed"))
                ),
                name="one_sendable_draft_per_email_per_campaign",
            ),
        ]
        indexes = [models.Index(fields=("status",)),
                   models.Index(fields=("email",))]

    def __str__(self) -> str:
        return f"{self.business_name} <{self.email or 'no email'}>"

    @property
    def in_workflow(self) -> bool:
        return self.status not in (
            self.Status.NO_EMAIL, self.Status.EXCLUDED, self.Status.DUPLICATE,
            self.Status.SUPPRESSED,
        )

    @property
    def has_website_material(self) -> bool:
        return bool(self.analysis_context)

    def as_history_kwargs(self) -> dict:
        """The fields SentLead copies off a draft when a send is reserved."""
        return {
            "business_name": self.business_name,
            "email": self.email,
            "website": self.website,
            "domain": SentLead.domain_of(self.website),
            "country": self.country,
            "city": self.city,
            "subject": self.subject,
            "campaign": self.campaign,
            "campaign_label": self.campaign.label,
            "draft": self,
        }

    @property
    def contact_state(self) -> str:
        """Which badge this lead should wear. See history.STATES."""
        if self.status == self.Status.NO_EMAIL:
            return "invalid"
        if self.status == self.Status.SUPPRESSED:
            return "suppressed"
        if self.status == self.Status.DUPLICATE:
            return "contacted"
        if self.status == self.Status.SENT:
            return "sent"
        if self.status == self.Status.FAILED:
            return "failed"
        if self.status == self.Status.SENDING:
            return "sending"
        return "ready"

    @property
    def measured_signals(self) -> dict:
        """This lead's own measured signals, merged across the pages read.

        Empty for a lead crawled before the facts were stored per page, and for
        one that was never crawled -- in both cases the caller falls back to the
        shared audit row rather than inventing a measurement.
        """
        from . import scoring

        facts = [
            page.get("facts") or {}
            for page in (self.pages_read or [])
            if isinstance(page, dict)
        ]
        return scoring.merge_signals(facts) if any(facts) else {}

    @property
    def finding_objects(self) -> list:
        """Stored findings as Finding instances, strongest first."""
        from .ai_base import Finding

        return [Finding.from_dict(f) for f in (self.findings or [])]

    # --- intelligence helpers ---------------------------------------------

    @property
    def classification_label(self) -> str:
        from .scoring import CLASSIFICATION_LABELS

        return CLASSIFICATION_LABELS.get(self.classification, "Not classified")

    @property
    def priority_label(self) -> str:
        from .scoring import PRIORITY_LABELS

        return PRIORITY_LABELS.get(self.priority, "Not scored")

    @property
    def has_website(self) -> bool:
        from .scoring import WEBSITE_FOUND

        return self.classification == WEBSITE_FOUND

    @property
    def main_issue(self) -> str:
        """The strongest evidenced finding, for the table's one-line summary."""
        for finding in self.findings or []:
            if finding.get("evidence"):
                return finding.get("issue", "")
        if self.classification == "no_website_opportunity":
            return "No website"
        if self.classification == "website_unverified":
            return "Not verified"
        return ""

    @property
    def sub_score_rows(self) -> list[dict]:
        """The six website sub-scores, in display order, from the audit."""
        from .scoring import SUB_SCORES

        stored = (self.audit.sub_scores if self.audit else {}) or {}
        rows = []
        for key, label, _fn in SUB_SCORES:
            entry = stored.get(key) or {}
            rows.append({
                "key": key,
                "label": label,
                "value": entry.get("value", 0),
                "measured": entry.get("measured", False),
                "display": (str(entry.get("value", 0))
                            if entry.get("measured") else "Unknown"),
                "factors": entry.get("factors", []),
            })
        return rows

    def derive_lifecycle(self) -> str:
        """Where this lead is, from the machinery. Never overrides a human stage.

        Read rather than written by most of the application: the send loop moves
        `status`, and this translates that into the sales vocabulary. The four
        judgement stages are left alone, because no amount of machinery can tell
        whether somebody is interested.
        """
        if self.lifecycle in [c.value for c in MANUAL_LIFECYCLE]:
            return self.lifecycle

        Status = self.Status
        if self.status == Status.SUPPRESSED:
            return Lifecycle.DO_NOT_CONTACT
        if self.status == Status.REJECTED:
            return Lifecycle.LOST
        if self.status in (Status.NO_EMAIL, Status.EXCLUDED, Status.DUPLICATE):
            return Lifecycle.ANALYZED if self.classification else Lifecycle.NEW

        # Contacted, and what came back.
        if self.status == Status.SENT:
            row = self.history_rows.order_by("-reserved_at").first()
            state = getattr(row, "reply_state", "") if row else ""
            if state == "replied":
                return Lifecycle.REPLIED
            if row and row.followups.filter(status="sent").exists():
                return Lifecycle.FOLLOW_UP
            return Lifecycle.CONTACTED
        if self.status in (Status.SENDING, Status.FAILED):
            return Lifecycle.CONTACTED

        if self.status == Status.APPROVED:
            return Lifecycle.EMAIL_READY
        if self.status == Status.GENERATED:
            from .scoring import is_ready

            return (Lifecycle.EMAIL_READY if is_ready(self.score_readiness)
                    else Lifecycle.QUALIFIED)
        if self.status == Status.ANALYSED:
            return Lifecycle.QUALIFIED if self.score_overall else Lifecycle.ANALYZED
        if self.status == Status.CRAWLED:
            return Lifecycle.ANALYZING
        return Lifecycle.NEW

    @property
    def lifecycle_steps(self) -> list[dict]:
        """The path so far, for the lead page's progress display."""
        current = self.lifecycle or Lifecycle.NEW
        if current in (Lifecycle.LOST, Lifecycle.DO_NOT_CONTACT):
            return [{"key": current, "label": self.get_lifecycle_display(),
                     "state": "ended"}]

        order = [c.value for c in LIFECYCLE_PATH]
        position = order.index(current) if current in order else 0
        rows = []
        for index, key in enumerate(order):
            rows.append({
                "key": key,
                "label": Lifecycle(key).label,
                "state": ("done" if index < position
                          else "current" if index == position else "waiting"),
            })
        return rows


class ReplyState(models.TextChoices):
    """What came back after a message went out.

    Shared by SentLead and FollowUp so a follow-up's outcome is described in the
    same words as the initial email's, and one lookup table drives both.
    """

    NO_REPLY = "no_reply", "No reply"
    REPLIED = "replied", "Replied"
    BOUNCED = "bounced", "Bounced"
    UNSUBSCRIBED = "unsubscribed", "Unsubscribed"


#: Reply states that permanently end outreach to a lead. `bounced` is included:
#: a follow-up to an address that does not exist is pure deliverability damage.
NO_FOLLOW_UP_STATES = (ReplyState.REPLIED, ReplyState.BOUNCED,
                       ReplyState.UNSUBSCRIBED)


class SentLead(models.Model):
    """The permanent record of who has been contacted.

    Separate from EmailDraft on purpose. A draft belongs to one campaign and can
    be edited, rejected or deleted; this table is append-only history and is the
    single source of truth for "have we already emailed these people?". It
    outlives the campaign that produced it -- deleting a campaign leaves the
    history intact, which is the whole point of keeping it separately.

    The unique constraint is the real duplicate protection. Everything else --
    the greyed-out checkbox, the campaign-level filter, the pre-send re-check --
    is there so the user sees the situation early; this is what makes a second
    send *impossible* rather than merely unlikely, including when two sending
    threads race for the same address.
    """

    class Status(models.TextChoices):
        SENDING = "sending", "Sending"
        SENT = "sent", "Sent"
        FAILED = "failed", "Failed"

    #: Stable identity for the Excel export. A primary key would do the job
    #: until a row is deleted -- SQLite reuses ids, so a later record could be
    #: mistaken for one already exported and silently skipped.
    uid = models.UUIDField(default=uuid.uuid4, editable=False, db_index=True)

    #: Whose sending history this row belongs to. Two users may each contact the
    #: same business without colliding -- the duplicate-prevention constraint
    #: below is scoped to the owner, because "have *I* already emailed them?" is
    #: the question it answers.
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="sent_leads", null=True, blank=True, db_index=True,
    )

    business_name = models.CharField(max_length=255)
    email = models.EmailField(db_index=True)
    website = models.URLField(max_length=500, blank=True)
    #: Host without "www.", so two URLs for one site collapse to one key.
    domain = models.CharField(max_length=255, blank=True, db_index=True)
    country = models.CharField(max_length=160, blank=True)
    city = models.CharField(max_length=160, blank=True)

    campaign = models.ForeignKey(
        Campaign, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="sent_leads",
    )
    #: Snapshot, so the history still reads correctly if the campaign is deleted.
    campaign_label = models.CharField(max_length=255, blank=True)
    draft = models.ForeignKey(
        EmailDraft, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="history_rows",
    )

    subject = models.CharField(max_length=400, blank=True)
    status = models.CharField(max_length=8, choices=Status.choices,
                              default=Status.SENDING)
    error_message = models.TextField(blank=True)

    #: This row is a deliberate re-contact, approved with a written reason. It is
    #: exempt from the one-live-row-per-address rule, because that rule is what
    #: the re-contact is overriding. See the constraints below.
    recontact = models.BooleanField(default=False)
    recontact_reason = models.CharField(max_length=300, blank=True)

    #: The Message-ID this email went out with. A reply quotes it in In-Reply-To
    #: or References, which is the only way to match a reply to its email
    #: without guessing from the subject line.
    message_id = models.CharField(max_length=255, blank=True, db_index=True)

    #: What came back. Set by the inbox check, never by the send.
    reply_state = models.CharField(max_length=16, choices=ReplyState.choices,
                                   default=ReplyState.NO_REPLY)
    replied_at = models.DateTimeField(null=True, blank=True)
    #: First line or two of the reply, so the list is readable without opening
    #: a mail client. Deliberately short: this is a pointer, not a mail store.
    reply_snippet = models.CharField(max_length=500, blank=True)
    #: When the inbox was last checked for this row.
    checked_at = models.DateTimeField(null=True, blank=True)

    reserved_at = models.DateTimeField(auto_now_add=True)
    sent_at = models.DateTimeField(null=True, blank=True)
    #: Denormalised so a spreadsheet reader gets plain date and time columns.
    sent_date = models.DateField(null=True, blank=True)
    sent_time = models.TimeField(null=True, blank=True)

    #: Set when a row has been written into sent_leads.xlsx, so the export
    #: appends rather than rewriting the sheet on every run.
    exported_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ("-reserved_at",)
        constraints = [
            # One live record per address. A `failed` row is excluded so a
            # genuine failure can be retried, but `sending` is included -- that
            # is what makes the reservation work as a lock between threads.
            #
            # Deliberate re-contacts are excluded too, since this rule is the
            # thing they exist to override. They are not left unprotected: the
            # constraint below still allows only one per campaign, so a
            # double-clicked Send cannot turn one approved re-contact into two
            # emails. What is given up is only the cross-campaign block, which
            # is precisely what the user asked for in writing.
            models.UniqueConstraint(
                fields=("owner", "email"),
                condition=~models.Q(status="failed") & models.Q(recontact=False),
                name="one_live_send_per_email",
            ),
            # SQL compares NULLs as distinct, so the constraint above does not
            # apply to rows with no owner -- which is every row created before
            # accounts existed. Without this second constraint, duplicate
            # prevention would silently switch itself off for that data.
            models.UniqueConstraint(
                fields=("email",),
                condition=(models.Q(owner__isnull=True)
                           & ~models.Q(status="failed")
                           & models.Q(recontact=False)),
                name="one_live_send_per_unowned_email",
            ),
            models.UniqueConstraint(
                fields=("email", "campaign"),
                condition=~models.Q(status="failed") & models.Q(recontact=True),
                name="one_recontact_per_email_per_campaign",
            ),
        ]
        indexes = [
            models.Index(fields=("status",)),
            models.Index(fields=("business_name", "city")),
            models.Index(fields=("owner", "status")),
        ]

    def __str__(self) -> str:
        return f"{self.business_name} <{self.email}> {self.status}"

    @staticmethod
    def domain_of(website: str) -> str:
        """Normalise a URL to a comparable host, or "" if there isn't one."""
        raw = (website or "").strip()
        if not raw:
            return ""
        if "//" not in raw:
            raw = "https://" + raw
        host = urlparse(raw).netloc.lower().split("@")[-1].split(":")[0]
        return host.removeprefix("www.")

    @property
    def is_live(self) -> bool:
        """Does this row block another send to the same address?"""
        return self.status != self.Status.FAILED

    def mark_sent(self, message_id: str = "") -> None:
        """Record delivery, and the Message-ID replies will quote."""
        now = timezone.localtime()
        SentLead.objects.filter(pk=self.pk).update(
            status=self.Status.SENT, sent_at=now,
            sent_date=now.date(), sent_time=now.time().replace(microsecond=0),
            message_id=(message_id or self.message_id or "")[:255],
            error_message="",
        )

    def mark_failed(self, message: str) -> None:
        """Record the failure and release the address for a retry."""
        SentLead.objects.filter(pk=self.pk).update(
            status=self.Status.FAILED, error_message=message[:2000],
        )


class Suppression(models.Model):
    """Addresses and domains that must never be contacted.

    Deliberately separate from SentLead, and deliberately stronger. The sending
    history answers "have we already emailed these people?", which a user may
    reasonably override for a follow-up or a bad name-and-city match. This table
    answers "are we allowed to email these people at all?", and the answer is no
    -- there is no override, at any layer, including a `force_contact` draft.

    An entry can cover a single address or a whole domain, because "take us off
    your list" is usually meant for the company, not just the mailbox that
    happened to reply.
    """

    class Reason(models.TextChoices):
        UNSUBSCRIBED = "unsubscribed", "Asked to be removed"
        COMPLAINED = "complained", "Reported as spam"
        BOUNCED = "bounced", "Address does not exist"
        MANUAL = "manual", "Added manually"

    #: Whose list this is. One user's do-not-contact entry must not silently
    #: block another user's outreach.
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="suppressions", null=True, blank=True, db_index=True,
    )

    email = models.EmailField(blank=True, db_index=True)
    #: Host without "www.", matching SentLead.domain_of.
    domain = models.CharField(max_length=255, blank=True, db_index=True)
    business_name = models.CharField(max_length=255, blank=True)

    reason = models.CharField(max_length=16, choices=Reason.choices,
                              default=Reason.UNSUBSCRIBED)
    note = models.CharField(max_length=400, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    #: Where it came from, when it was added off the back of a campaign.
    campaign_label = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ("-created_at",)
        constraints = [
            models.UniqueConstraint(
                fields=("owner", "email"), condition=~models.Q(email=""),
                name="one_suppression_per_email",
            ),
            models.UniqueConstraint(
                fields=("owner", "domain"),
                condition=~models.Q(domain="") & models.Q(email=""),
                name="one_suppression_per_domain",
            ),
            # Same NULL-owner gap as SentLead, for the same reason.
            models.UniqueConstraint(
                fields=("email",),
                condition=models.Q(owner__isnull=True) & ~models.Q(email=""),
                name="one_unowned_suppression_per_email",
            ),
            # A row that names neither is not a rule, it is a mistake.
            models.CheckConstraint(
                condition=~(models.Q(email="") & models.Q(domain="")),
                name="suppression_needs_an_email_or_a_domain",
            ),
        ]

    def __str__(self) -> str:
        return f"{self.target} ({self.get_reason_display()})"

    @property
    def target(self) -> str:
        return self.email or f"*@{self.domain}"

    @property
    def scope(self) -> str:
        return "address" if self.email else "whole domain"


class FollowUp(models.Model):
    """One manual follow-up to a lead that never replied.

    Separate from SentLead rather than another row in it. A SentLead row is the
    *first* contact and the thing duplicate prevention keys on; a follow-up is a
    deliberate second or third touch on that same thread, and only ever exists
    because a person clicked Create Follow-Up and then Send Follow-Up.

    Nothing here is ever sent automatically. `status` starts at `draft` and only
    an explicit send moves it on.
    """

    class Status(models.TextChoices):
        DRAFT = "draft", "Awaiting review"
        SENDING = "sending", "Sending"
        SENT = "sent", "Sent"
        FAILED = "failed", "Failed"
        CANCELLED = "cancelled", "Cancelled"

    lead = models.ForeignKey(SentLead, on_delete=models.CASCADE,
                             related_name="followups")
    #: Copied from the lead when the follow-up is created. Stored rather than
    #: joined because this table is queried on its own, and a filter that has to
    #: remember to join is a filter somebody will forget to join.
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="followups", null=True, blank=True, db_index=True,
    )
    campaign = models.ForeignKey(
        Campaign, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="followups",
    )
    #: Snapshot, so the record still reads correctly if the campaign is deleted.
    campaign_label = models.CharField(max_length=255, blank=True)

    #: 1 for the first follow-up, 2 for the second. Bounded by
    #: settings.OUTREACH_FOLLOWUP_MAX.
    number = models.PositiveSmallIntegerField(default=1)

    email = models.EmailField()
    subject = models.CharField(max_length=400, blank=True)
    body = models.TextField(blank=True)
    edited = models.BooleanField(default=False)
    regenerations = models.PositiveSmallIntegerField(default=0)

    status = models.CharField(max_length=12, choices=Status.choices,
                              default=Status.DRAFT)
    error_message = models.TextField(blank=True)

    #: Its own Message-ID, so a reply to the follow-up is matched to the
    #: follow-up rather than to the original email.
    message_id = models.CharField(max_length=255, blank=True, db_index=True)
    reply_state = models.CharField(max_length=16, choices=ReplyState.choices,
                                   default=ReplyState.NO_REPLY)
    replied_at = models.DateTimeField(null=True, blank=True)
    reply_snippet = models.CharField(max_length=500, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    sent_at = models.DateTimeField(null=True, blank=True)
    #: Denormalised so a spreadsheet reader gets plain date and time columns.
    sent_date = models.DateField(null=True, blank=True)
    sent_time = models.TimeField(null=True, blank=True)

    class Meta:
        ordering = ("-created_at",)
        constraints = [
            # One live follow-up per number per lead. This is what stops a
            # double-clicked Create Follow-Up producing two #1 drafts, and a
            # double-clicked Send Follow-Up producing two sends. A cancelled row
            # is excluded so the number can be used again after a cancel.
            models.UniqueConstraint(
                fields=("lead", "number"),
                condition=~models.Q(status="cancelled"),
                name="one_live_followup_per_number_per_lead",
            ),
        ]
        indexes = [
            models.Index(fields=("status",)),
            models.Index(fields=("email",)),
        ]

    def __str__(self) -> str:
        return f"Follow-up #{self.number} to {self.email} ({self.status})"

    @property
    def is_live(self) -> bool:
        """Does this row occupy its follow-up number?"""
        return self.status != self.Status.CANCELLED

    def mark_sent(self, message_id: str = "") -> None:
        now = timezone.localtime()
        FollowUp.objects.filter(pk=self.pk).update(
            status=self.Status.SENT, sent_at=now, sent_date=now.date(),
            sent_time=now.time().replace(microsecond=0),
            message_id=message_id or self.message_id, error_message="",
        )

    def mark_failed(self, message: str) -> None:
        FollowUp.objects.filter(pk=self.pk).update(
            status=self.Status.FAILED, error_message=message[:2000],
        )


class ProviderCredential(models.Model):
    """One API key for one provider, encrypted at rest.

    The parent/child structure lives in this one table. The *parent* is the
    provider -- a name from `credentials.SPECS`, not a row -- and each row here is
    a *child*: one key, with a label, belonging to one account. So a user can hold
    four OpenAI keys and switch between them without editing anything.

    Exactly one child per (owner, provider) may be active, enforced by a database
    constraint rather than by application code, because "which key is in use" has
    to have one answer even if two browser tabs try to change it at once.

    Nothing here is ever sent to a browser. `secret` is Fernet ciphertext and
    `hint` is the masked form (`sk-proj-••••••••9X2A`) that the UI shows instead --
    enough to tell two keys apart, never enough to reconstruct one.
    """

    #: Whose key this is. Credential management is per-account: one user must not
    #: be able to see, use or delete another user's keys.
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="ai_credentials", null=True, blank=True, db_index=True,
    )
    provider = models.CharField(max_length=32, db_index=True)

    #: What the user calls it: "OpenAI Production", "Backup", "Testing".
    label = models.CharField(max_length=80)
    description = models.CharField(max_length=300, blank=True)

    #: Fernet ciphertext. See outreach/credentials.py for the key derivation.
    secret = models.TextField()
    #: Masked form for display. Never enough to reconstruct the key.
    hint = models.CharField(max_length=64, blank=True)
    #: Non-secret provider configuration: base URL, organisation id.
    extras = models.JSONField(default=dict, blank=True)
    #: Optional model override carried with this key, so a testing credential can
    #: point at a cheaper model than the production one.
    model = models.CharField(max_length=120, blank=True)

    #: The one the application uses. At most one per (owner, provider).
    is_active = models.BooleanField(default=False, db_index=True)
    #: Whether this key may be tried when the active one hits a rate limit.
    #: Off by default: rotation must be something the user asked for, never
    #: something that happens quietly behind a failure.
    allow_fallback = models.BooleanField(default=False)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    # --- usage, all of it safe to display --------------------------------- #
    #: Null means "never", which the UI shows as Unknown rather than as a zero
    #: date. An invented timestamp is worse than an absent one.
    last_used_at = models.DateTimeField(null=True, blank=True)
    last_success_at = models.DateTimeField(null=True, blank=True)
    last_error_at = models.DateTimeField(null=True, blank=True)
    request_count = models.PositiveIntegerField(default=0)
    error_count = models.PositiveIntegerField(default=0)

    #: A category (`invalid`, `rate_limited`, `unavailable`), never the provider's
    #: own error text: that can quote request details, and request details can
    #: contain the key.
    last_error_category = models.CharField(max_length=32, blank=True)
    last_error_detail = models.CharField(max_length=300, blank=True)

    #: Outcome of the last Test Connection. Also a category, for the same reason.
    last_test_result = models.CharField(max_length=120, blank=True)
    last_tested_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ("provider", "-is_active", "label")
        constraints = [
            # The parent/child rule, in the database. Two tabs both pressing
            # Activate cannot leave a provider with two active keys.
            models.UniqueConstraint(
                fields=("owner", "provider"), condition=models.Q(is_active=True),
                name="one_active_credential_per_provider_per_owner",
            ),
            # Labels are how the user tells their keys apart, so they have to be
            # distinct within a provider.
            models.UniqueConstraint(
                fields=("owner", "provider", "label"),
                name="one_label_per_provider_per_owner",
            ),
        ]
        indexes = [models.Index(fields=("owner", "provider", "is_active"),
                                name="pc_owner_prov_active_idx")]

    def __str__(self) -> str:
        # The hint, never the secret: a stray repr in a log or a traceback must
        # not carry a key.
        state = "active" if self.is_active else "inactive"
        return f"{self.provider}/{self.label} ({self.hint or 'set'}, {state})"

    @property
    def status(self) -> str:
        """One word for the card: active, inactive, or failing."""
        if self.last_error_category and not self.is_active:
            return "error"
        if self.is_active and self.last_error_category and (
            self.last_success_at is None
            or (self.last_error_at and self.last_error_at > self.last_success_at)
        ):
            return "failing"
        return "active" if self.is_active else "inactive"

    @property
    def status_label(self) -> str:
        return {
            "active": "Active",
            "inactive": "Inactive",
            "failing": "Active — last request failed",
            "error": "Last request failed",
        }[self.status]


class CredentialEvent(models.Model):
    """A safe audit trail for one credential.

    Exists so two questions have answers: "which key did that request actually
    use?" and "why did it fall back?". Both matter when a provider bill or a
    failure has to be explained.

    Deliberately carries no secret and no provider response body -- only a
    category, a label and a timestamp. A log line is exactly the wrong place for
    an API key, and a provider error can quote the request that contained one.
    """

    class Kind(models.TextChoices):
        CREATED = "created", "Added"
        ACTIVATED = "activated", "Activated"
        DEACTIVATED = "deactivated", "Deactivated"
        DELETED = "deleted", "Deleted"
        TESTED = "tested", "Connection tested"
        USED = "used", "Request succeeded"
        ERROR = "error", "Request failed"
        FALLBACK = "fallback", "Fell back to another credential"

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="credential_events", null=True, blank=True, db_index=True,
    )
    credential = models.ForeignKey(
        ProviderCredential, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="events",
    )
    #: Snapshots, so the trail still reads after a credential is deleted.
    provider = models.CharField(max_length=32, db_index=True)
    label = models.CharField(max_length=80, blank=True)

    kind = models.CharField(max_length=16, choices=Kind.choices)
    #: `invalid`, `rate_limited`, `unavailable`, `ok` -- a category, never a body.
    category = models.CharField(max_length=32, blank=True)
    detail = models.CharField(max_length=300, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ("-created_at",)
        indexes = [models.Index(fields=("owner", "provider", "-created_at"),
                                name="ce_owner_prov_time_idx")]

    def __str__(self) -> str:
        return f"{self.provider}/{self.label} {self.kind} {self.created_at:%Y-%m-%d %H:%M}"


class AiSelection(models.Model):
    """Which provider and model one account has chosen.

    Per-account for the same reason the credentials are: two users of one
    deployment should be able to work on different providers without changing each
    other's settings.

    `OUTREACH_AI_PROVIDER` still works and is the fallback, so a deployment that
    never opens Settings behaves exactly as it did.
    """

    owner = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="ai_selection", null=True, blank=True,
    )
    provider = models.CharField(max_length=32, blank=True)
    model = models.CharField(max_length=120, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self) -> str:
        return f"{self.provider or 'default'} / {self.model or 'default model'}"


class WebsiteAudit(models.Model):
    """A cached, refreshable audit of one website.

    Keyed on (owner, domain) rather than on a draft, because the expensive part is
    the crawl and two campaigns that both contain the same business should not pay
    for it twice. Opening a lead page reads this row; it does not re-crawl. A new
    audit happens only when the user asks for one, or when this one is older than
    the configured lifetime.

    `signals` is what the crawler measured, and it is the reason every score in
    the application can be explained: the numbers are recomputed from here, so a
    score can always be traced back to a fact.
    """

    class Status(models.TextChoices):
        OK = "ok", "Analysed"
        BLOCKED = "blocked", "Blocked"
        FAILED = "failed", "Failed"
        NO_WEBSITE = "no_website", "No website"

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="website_audits", null=True, blank=True, db_index=True,
    )
    #: Host without "www.", matching SentLead.domain_of, so one site is one row.
    domain = models.CharField(max_length=255, db_index=True)
    #: The address actually analysed, which may differ from the listed one after
    #: redirects. Stored because a finding's evidence has to point somewhere real.
    url = models.URLField(max_length=500, blank=True)

    status = models.CharField(max_length=16, choices=Status.choices,
                              default=Status.OK)
    detail = models.CharField(max_length=400, blank=True)

    #: Measured facts, merged across the pages read. See analyzer.measure().
    signals = models.JSONField(default=dict, blank=True)
    #: [{"url", "kind"}, ...] -- which pages the audit is based on.
    pages = models.JSONField(default=list, blank=True)
    pages_discovered = models.PositiveIntegerField(default=0)

    #: Scores recomputed from `signals`, stored so the table can sort on them.
    quality_score = models.PositiveSmallIntegerField(default=0)
    opportunity_score = models.PositiveSmallIntegerField(default=0)
    #: {"performance": {"value", "measured", "factors"}, ...}
    sub_scores = models.JSONField(default=dict, blank=True)

    #: The reviewer's evidenced findings, and its summary of the business.
    findings = models.JSONField(default=list, blank=True)
    business_summary = models.TextField(blank=True)

    analysed_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)
    #: Bumped when the scoring rules change, so a stale score is recognisable.
    scoring_version = models.PositiveSmallIntegerField(default=1)
    #: Which provider and model produced the findings, for the same reason.
    ai_version = models.CharField(max_length=120, blank=True)
    refreshes = models.PositiveSmallIntegerField(default=0)

    class Meta:
        ordering = ("-analysed_at",)
        constraints = [
            models.UniqueConstraint(
                fields=("owner", "domain"),
                name="one_audit_per_domain_per_owner",
            ),
        ]
        indexes = [models.Index(fields=("owner", "status"))]

    def __str__(self) -> str:
        return f"{self.domain} ({self.status}, {self.quality_score}/100)"

    @property
    def usable(self) -> bool:
        return self.status == self.Status.OK and bool(self.pages)

    @property
    def age_days(self) -> int:
        if not self.analysed_at:
            return 0
        return (timezone.now() - self.analysed_at).days

    @property
    def stale(self) -> bool:
        """Old enough that a re-analysis is worth offering.

        Never triggers one on its own -- opening a lead page must not spend money.
        """
        limit = int(getattr(settings, "OUTREACH_AUDIT_MAX_AGE_DAYS", 30))
        return self.age_days >= limit

    @property
    def finding_objects(self) -> list:
        from .ai_base import Finding

        return [Finding.from_dict(f) for f in (self.findings or [])]
