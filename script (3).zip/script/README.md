# Lead Mapper

An AI-powered lead generation and outreach platform. It finds local businesses
from public map data, reads their websites, identifies genuine improvement
opportunities, writes a personalised email for each one, puts every email in
front of you for approval, and sends the approved ones from your own email
account — without ever contacting the same business twice.

Built with Django. Runs locally. Accounts are per-user — each one sees only its
own leads, campaigns and sending history. No CRM, no third-party sending
service.

---

## Table of contents

1. [Overview](#1-overview)
2. [Why this project was built](#2-why-this-project-was-built)
3. [Problem → solution](#3-problem--solution)
4. [Main features](#4-main-features)
5. [System workflow](#5-system-workflow)
6. [Architecture](#6-architecture)
7. [Technology stack](#7-technology-stack)
8. [Environment variables](#8-environment-variables)
9. [Installation](#9-installation)
10. [SMTP setup](#10-smtp-setup)
11. [AI setup](#11-ai-setup)
12. [Testing](#12-testing)
13. [Security](#13-security)
14. [Data and privacy](#14-data-and-privacy)
15. [Project structure](#15-project-structure)
16. [Troubleshooting](#16-troubleshooting)
17. [Future improvements](#17-future-improvements)

---

## 1. Overview

Lead Mapper turns a location and a business category into a reviewed, personalised
outreach campaign. It does the following, in one continuous workflow:

- **Requires a signed-in account** for every page and endpoint, and keeps each
  account's leads, campaigns and history private to it.
- **Searches for business leads** by country, city and category.
- **Collects permitted public business information** — name, category, address,
  phone, email, website and coordinates — from OpenStreetMap.
- **Displays leads** on an interactive map and in a result list.
- **Exports leads to CSV** automatically when a search completes.
- **Lets you select leads that publish an email address**; the rest are shown but
  cannot be selected.
- **Works through the selected leads one at a time.** A lead's website is
  analysed, its issues found, its email written and its result saved before the
  next lead is started — never all the websites first and the emails afterwards.
- **Automatically analyses publicly accessible business websites** — discovering
  the site's own pages and reading the most informative ones.
- **Identifies genuine website improvement opportunities**, each supported by a
  measured piece of evidence.
- **Generates a personalised email per business** using an AI API, built on the
  strongest verified findings — Claude, Gemini, OpenAI, OpenRouter or Groq,
  chosen in Settings.
- **Stores AI provider keys encrypted**, configurable in the browser, with
  `.env` as the fallback.
- **Shows live progress** — which company is being read right now, which of its
  four steps is running, and how many leads are done.
- **Puts every email through human review** — edit, regenerate, approve or reject.
- **Sends approved emails through your own authenticated SMTP account**, rate
  limited per provider.
- **Tracks every send** in a permanent history table.
- **Prevents duplicate outreach** with a three-tier check, re-run immediately
  before each message is transmitted.
- **Keeps a do-not-contact list** that no campaign can override.
- **Allows a deliberate, reasoned re-contact** when a duplicate match was wrong.
- **Resumes an interrupted run** without re-analysing or re-drafting leads that
  were already finished.
- **Tracks replies** by reading the sending account's inbox, marking each lead
  `Replied`, `Bounced`, `Unsubscribed` or `No reply` — and storing nothing about
  unrelated mail.
- **Offers a manual follow-up** to leads that never replied, written by the AI
  from the original email, reviewed by you, and sent only on an explicit click.
- **Maintains a spreadsheet history** at `exports/sent_leads.xlsx`, appended to
  after every campaign.
- **Generates campaign reports** showing sent, failed and queued counts with
  per-recipient outcomes.

> **Note on the spreadsheet.** The implemented export is a **single workbook**,
> `exports/sent_leads.xlsx`, containing every send with a `Country` column. It is
> not split into one file per country. See
> [Future improvements](#17-future-improvements).

---

## 2. Why this project was built

Cold outreach that works is mostly research, and research is mostly time:

- **Finding relevant leads manually takes hours.** Searching a map, copying names,
  hunting for an email address — for every prospect.
- **Checking every website by hand is slow.** Opening a site, clicking through its
  pages, and forming a useful opinion takes several minutes each. At fifty
  prospects that is most of a day.
- **Generic emails get ignored.** A mail merge with a `{{business_name}}` slot is
  recognisably a mail merge.
- **Sales teams spend their time researching rather than selling.** The valuable
  part is the conversation, not the preparation.
- **There is rarely a repeatable method.** Two people researching the same
  prospect produce different notes of different quality.
- **Emailing the same prospect twice is worse than not emailing them.** It reads
  as careless, and it happens easily when the same city is searched again a month
  later.
- **Campaign history gets lost.** Who was contacted, when, about what, and what
  happened — usually spread across a spreadsheet, an inbox and somebody's memory.

Lead Mapper combines **lead discovery + website research + AI analysis +
personalised outreach + lead history** into a single reviewed workflow, so the
repetitive parts are automated and the judgement stays with you.

---

## 3. Problem → solution

| Problem | Solution |
| --- | --- |
| Manual lead research | Automated lead collection from public map data |
| Manually checking websites | Automatic page discovery and website analysis |
| Generic emails | AI-generated emails built on verified, site-specific findings |
| Repeated outreach | Three-tier duplicate detection, re-checked before every send |
| Difficult campaign tracking | Campaign reports and a permanent sending-history table |
| Scattered records | A single appended Excel history export with a country column |
| Manual email sending | Authenticated SMTP sending with per-provider rate limits |
| Shared, unprotected data | Accounts, with ownership enforced in every query |
| Not knowing who replied | Inbox matching on the `Message-ID` of every email sent |
| Prospects lost to silence | A reviewed manual follow-up, capped and never automatic |

---

## 4. Main features

### Accounts and per-user data

Every page and endpoint requires a signed-in account. There is no anonymous mode
and no shared view of the data: each account sees only its own leads, campaigns,
sending history, follow-ups and do-not-contact list.

| Page | Purpose |
| --- | --- |
| `/signup` | Name, email, password, confirmation. Creates the account and signs straight in. |
| `/login` | Email and password. |
| `/dashboard` | The authenticated home: this account's campaigns and totals. |

Built on `django.contrib.auth` rather than anything hand-rolled — sessions,
password hashing and the login-required middleware are framework features, which
is both less code and less to get wrong. Email is the login identifier, which
needs an authentication backend rather than a custom user model, so
[`accounts/backends.py`](accounts/backends.py) looks accounts up by email
case-insensitively.

#### How routes are protected

Django's `LoginRequiredMiddleware` protects **everything by default**; the three
auth views opt out with `@login_not_required`. Deny-by-default is the point: a
view added later is protected without anybody remembering to protect it, and a
test walks the real URL configuration to prove no route answers an anonymous
request.

An anonymous request is redirected to `/login?next=…`, and the `next` value is
only honoured when it points at this site — an open redirect after login is a
ready-made phishing step.

A signed-in visitor asking for `/login` or `/signup` is sent to `/dashboard`.

#### How data is isolated

Route protection is not authorization. Two accounts both signed in are both
"authenticated", so ownership is enforced in the queries themselves:

- `Campaign`, `SentLead`, `Suppression` and `FollowUp` each carry an `owner`.
  `EmailDraft` derives its owner from its campaign rather than duplicating it, so
  the two can never disagree.
- Every view looks objects up through a helper that includes the owner —
  `get_object_or_404(Campaign, pk=…, owner=request.user)` — rather than fetching
  by id and checking afterwards. **A URL parameter is never trusted on its own.**
- The data-access layer takes the owner as a **required** argument.
  `history.Index(owner)`, `followups.rows(owner)` and `inbox.Matcher(owner)` have
  no "everything" mode, so a forgotten call site fails loudly instead of quietly
  returning somebody else's prospect list.
- **404, not 403.** "Forbidden" would confirm that an object with that id exists
  and belongs to someone else.

Two consequences worth knowing:

- **Duplicate prevention became per-account.** "Have we already emailed this
  address?" is now "have *I*", so two accounts may each contact the same business
  without one silently blocking the other. The unique constraints moved with it.
- **The Excel history export is per-account**, at
  `exports/sent_leads_<account-id>.xlsx`. A single shared workbook would put one
  account's prospect list in another's download.

#### Upgrading a database that predates accounts

Rows created before ownership existed have no owner, and a row with no owner is
visible to nobody — the safe default. Claim them:

```bash
python manage.py claim_data you@example.com --dry-run   # report only
python manage.py claim_data you@example.com
```

Only unowned rows are touched, so running it twice is harmless and it can never
move one account's data to another.

#### Sessions

| Behaviour | How |
| --- | --- |
| Persistence | Database-backed sessions, two weeks, refreshed on each request so an active user is not signed out mid-campaign |
| Expiry / invalid / purged | Treated as signed out — redirected to `/login` |
| Fixation | `login()` cycles the session key, so a key set before authentication cannot be reused after |
| Cookie | `HttpOnly`, `SameSite=Lax`, and `Secure` whenever `DEBUG=0` |
| Logout | POST only, and flushes the session row — a GET logout can be fired by any image tag |

`GET /api/session` reports `{"authenticated": …}` without any account details, so
the front end can tell "still loading" from "signed out" rather than guessing from
a redirect.

AI credentials are per-account too: the keys you add in Settings are yours,
resolved only for your campaigns, and invisible to every other account. See
[AI setup](#11-ai-setup) for how the pool works.

#### What is not per-account

Sending, scraping and crawling configuration. SMTP host, rate limits, the crawl
budget and the OSM contact address come from `.env` and are properties of the
deployment, not of a user. Nothing on that list is editable from the browser.

### Lead search

The search form takes four inputs:

| Field | Notes |
| --- | --- |
| **Country** | Searchable dropdown of all countries (252 ISO entries plus common aliases such as `UAE`, `UK`, `Holland`). Optional. |
| **City / location** | Searchable dropdown, populated from the selected country (~34,000 cities worldwide). Required. Disabled until a country is chosen. |
| **Business category** | ~30 presets (Restaurants, Dentists, Real Estate Agents, …) or free text. |
| **Number of leads** | 1–300. |

Both dropdowns filter as you type, because a native `<select>` is unusable at
these list sizes. Both still accept free text: the reference city data covers
places of roughly 15,000 people and up, while the geocoder resolves much smaller
ones. Validation therefore rejects a **contradiction** — a city the reference data
places in a different country — but allows a place it simply has not heard of.

Results are ordered by how contactable they are: leads with a phone, email,
website and address come first.

### Lead display

Collected leads appear as map markers and as a sidebar list. Clicking a marker
shows business name, category, address, phone and website. Each list row carries:

- a **state badge** — `New`, `Already contacted`, or `No email`;
- indicators for which contact details exist;
- a checkbox, enabled only for leads that can actually be contacted.

Above the list, a breakdown shows **Found / Available / Contacted**, with filters
for `All`, `New`, `Contacted` and `No email`, and a **Select new leads only**
action.

### CSV export

A CSV is written to `exports/` the moment a search finishes, and the **Download
CSV** button then serves that existing file. Columns:

```
Business Name, Category, Country, City, Address, Phone, Email, Website,
Latitude, Longitude, Source
```

Encoded UTF-8 with a BOM so Excel opens accented names correctly. `Source` is a
permalink to the exact OpenStreetMap object each row came from.

### Sequential per-lead processing

The selected leads are worked through **one at a time**. Each lead completes four
steps before the next lead is touched at all:

```
Lead 1 → analyse website → find issues → generate email → save
Lead 2 → analyse website → find issues → generate email → save
Lead 3 → …
```

The workspace shows a live panel while this runs: the position in the queue
(`Lead 7 of 25`), a percentage bar, the company and website being read at that
moment, which of the four steps is in flight, what is next, the full queue marked
*completed* / *analysing* / *waiting* / *paused* / *not processed*, and one
**Cancel** button for the job. A card appears in the list the moment a company is
finished, carrying its findings and its email together — rather than every card
sitting empty until the last crawl finishes.

Three things follow from processing this way:

- **A failure costs one lead, not the run.** An unreachable website, a blocked
  crawl or a refused AI call is recorded against that lead, and the next lead
  starts. Nothing stops the campaign.
- **Progress survives a reload.** The position and step are stored on the
  campaign, so reopening the page mid-run shows the true state.
- **An unreadable website still gets an email** — written without any claim about
  the site, and labelled as such on the card so you can judge it fairly.

**Transient failures are retried once.** A dropped connection, a 5xx or a reply
cut off mid-JSON gets a second attempt after a short pause. Permanent failures — a
missing API key, an unknown model, a context over the provider's ceiling — are not
retried: they fail identically every time, and retrying each of 25 leads would add
minutes to reach the same error. The interactive **Regenerate** button never
retries, so a click returns the error rather than pausing silently.

A **rate limit is not retried per lead** — it pauses the whole run. See
[AI rate limits](#ai-rate-limits) below.

**An interrupted run can be resumed.** If the server restarts mid-campaign the
phase would otherwise say `crawling` forever with nothing behind it. The
workspace detects that and offers **Resume**, which skips every lead already
finished — and, within the lead that was interrupted, skips the steps it already
completed. A crawl that was already paid for is not paid for twice. A stalled
*send* is handled differently: the SMTP password is never stored, so it cannot
resume itself. Instead the stuck queue is released back to approved and you press
Send again; anything already delivered is in the history and cannot go out twice.

### AI rate limits

An AI provider that refuses one request will refuse the next twenty-four. So a
rate limit stops the run rather than being retried per lead:

```
RUNNING  →  PAUSED_RATE_LIMIT  →  RUNNING
```

What happens the moment a provider says no:

1. **Processing stops immediately.** No further crawl, review or email is started.
   The lead that was refused is left unfinished, with no completion stamp.
2. **The same request is not retried.** One refusal produces one pause, not a
   second attempt at the same call.
3. **The position is saved.** Every lead that finished keeps its completion stamp,
   so resuming re-does nothing.
4. **The campaign is marked `PAUSED_RATE_LIMIT`**, with why, the provider's own
   message, and when it may resume — all in the database, so a reload or a restart
   still shows the truth.
5. **The workspace says so**, with a countdown and a **Resume now** button.
6. **It resumes from the first unfinished lead** once the window has passed.

Two kinds of refusal arrive as the same HTTP 429, and they need opposite handling:

| | Temporary rate limit | Quota or billing allowance |
| --- | --- | --- |
| Recognised by | the default; a per-minute message | `per day`, `per month`, `insufficient_quota`, `quota exceeded`, `billing`, `free tier` |
| Waiting helps? | Yes | No — it resets on the provider's clock |
| What happens | waited out, then the run carries on | the run stops and says so |
| The UI offers | a countdown, and Resume now | a link to **AI credentials** to switch provider or key |

**`Retry-After` is respected** where the provider sends one — as a header
(`Retry-After`, `retry-after-ms`, seconds or an HTTP date) or as "try again in
8.5s" in the message body. A provider that says how long to wait knows better than
any formula. With no answer, the wait is a **controlled exponential backoff**:
30s, 60s, 120s, 240s, capped at 15 minutes.

A short wait is held in the worker thread, which re-checks for a Cancel press
every second. A wait longer than five minutes, or any quota, is recorded and the
worker exits — a thread asleep for an hour survives no restart and tells the user
nothing that a stored timestamp does not. The workspace resumes it when the window
opens; **Resume now** is always available.

**Retrying is bounded.** After five pauses in one run the campaign stays paused
and waits for a person. Five refusals across an escalating backoff is not a burst
of traffic; it is a limit that needs a different credential or a shorter list, and
carrying on would just ask the same question more slowly.

### Cancelling a run

One **Cancel** button, in the run panel next to the progress it stops.

```
RUNNING  →  CANCEL_REQUESTED  →  CANCELLED
```

- **Nothing new is started.** The state is re-read from the database before every
  lead, and before every page fetch inside a crawl — so a running crawl stops
  within one page rather than after five, and an AI call that has not started
  never starts.
- **The lead being finished is finished.** Cancel is checked *before* each lead, so
  a lead whose crawl and review have already been paid for gets its email rather
  than being thrown away to save one call.
- **A lead interrupted mid-way keeps no completion stamp**, and a crawl cut short
  is discarded rather than saved — a half-read site stored as though it were the
  whole site would be analysed as one, and skipped as "already crawled" on the
  resume.
- **Completed leads stay completed.** Resuming later starts at the first
  unfinished one.
- **It is idempotent.** Pressing Cancel twice, or pressing it on a campaign that
  is already cancelled, changes nothing and reports the state. The button disables
  itself on the first press; the endpoint does not rely on that.
- **If nothing is running** — a paused run, or a worker that died with its
  process — the request is applied directly rather than waiting for a worker that
  will never see it.
- **The UI says `Processing cancelled`** immediately, with how many leads were not
  processed and a way to pick them up.

**Cancellation wins over a rate-limit retry.** A run asleep on a retry window
wakes, sees the request, and stays cancelled. Nothing auto-resumes a cancelled
run — that is the point of cancelling one. Resuming it is an explicit press.

A send in progress is not cancellable here: some of those emails are already
delivered, and the sender stops on its own between messages.

### Website analysis

You supply nothing beyond the website URL already in the lead data. For each
selected lead the crawler:

1. reads the site's own `<nav>` and `<header>`, its footer, and its internal links;
2. reads `sitemap.xml`, including any URL advertised in `robots.txt`, following one
   level of sitemap index;
3. scores candidates by how much they reveal about the business and its customer
   journey — services and products rank highest, then pricing and contact, down to
   blog posts;
4. picks a **spread of page types** rather than the top scores, because services +
   pricing + contact + about tells you far more than five service pages;
5. visits the home page plus **five internal pages** where they exist, capped at
   eight.

For every page it records **measurable signals**, which is what makes the findings
checkable rather than speculative:

| Area | Examples of what is measured |
| --- | --- |
| UI/UX and navigation | Heading counts and structure, vague link text, links opening new tabs |
| Content | Word count, placeholder text (`lorem ipsum`, "coming soon"), stale copyright year |
| Images | Total count, missing `alt` text, missing dimensions, lazy loading, modern vs legacy formats |
| CTA and conversion | Call-to-action phrase counts and examples, form count, unlabelled form fields |
| Contact experience | `mailto:`/`tel:` links, embedded map |
| Trust signals | Testimonial, review, certification and guarantee mentions; social links |
| SEO basics | Title length, meta description, canonical tag, Open Graph tags, structured data, `html lang` |
| Mobile / responsive | Viewport meta tag and its content, fixed-width attributes |
| Performance indicators | Measured response time in milliseconds, page weight, script and stylesheet counts |

**What the crawler will not do.** It fetches `robots.txt` first and obeys it per
URL, treats an unauthorised `robots.txt` as disallow-all, identifies itself with a
contact address, waits a second between requests to the same host, and stops on a
`401`, `402`, `403` or `429` or a bot-check page. It never bypasses **CAPTCHAs,
login pages, paywalls, access restrictions or anti-bot protections**. A site that
cannot be read is recorded as such — never guessed at.

### AI analysis

The AI receives the crawled page text and the measured signals, and is asked for
the strongest genuine issues and opportunities across seventeen named areas. The
prompt constrains it hard:

- every finding must cite a specific measured signal or quotation in an
  `evidence` field;
- specific claims are tied to specific signals — no "slow site" unless the
  measured load time says so, no "not mobile friendly" unless the viewport tag is
  actually absent;
- **nothing about colours, fonts, spacing or how the site looks** — the model
  receives text and numbers, not screenshots, and is told so explicitly;
- 8–10 findings **where the evidence supports that many**, fewer otherwise:
  *"padding the list with speculation is a failure; a short, solid list is a
  success."*

Findings come back with `issue`, `evidence`, `why_it_matters`,
`suggested_improvement`, `dimension` and `severity`, ordered strongest first. **A
finding returned with an empty evidence field is discarded in code**, not merely
discouraged in the prompt.

### Personalised email

One AI request per lead, built on the **actual findings from that lead's crawl**.
Not on the URL, and not on a general impression: the model is sent structured
evidence and is told those findings are the only website problems that exist.

```
Website URL          https://bella.example
Pages analysed       home, contact, menu  (the pages actually fetched)
Finding              The homepage has no obvious way to get in touch
  Severity           high
  Area               calls to action
  Evidence           cta_count=0 on the homepage      ← measured, never quoted
  What it costs      A visitor ready to book has to go looking
  Fix                Add a phone link and a booking button above the fold
  Found on           https://bella.example/
Measured signals     load_ms=3400, viewport_meta=false, title_length=0, …
```

So instead of:

> I noticed some issues with your website.

the email says something only true of this business:

> I noticed the main contact button is hard to find on a phone, and the homepage
> could also be loading more quickly. I also noticed the homepage is missing a
> meaningful page title.

The wording is generated per lead — none of it is a template.

**Which findings.** An audit produces eight to ten. An email may use **one to
three**, and which three is decided in code rather than left to the model, in the
commercial order that matters to a business owner:

| | Priority |
| --- | --- |
| 1 | Broken or missing functionality — a booking form that does not submit |
| 2 | Customer journey and conversion — no obvious way to enquire |
| 3 | Mobile usability |
| 4 | Speed and performance |
| 5 | Missing or thin content |
| 6 | Search visibility |
| 7 | Technical detail |

A broken contact form outranks a missing canonical tag however much easier the
second is to measure. Severity from the audit breaks ties *within* a band, never
across them. A finding with no evidence is dropped before the prompt is even
built — an unevidenced finding is exactly the invented problem this must never
send.

**In their language, not the auditor's.** The measurements go to the model as
context and are forbidden in the email. `LCP = 4.8s` becomes "the homepage takes
noticeably longer to load on mobile". `cta_count = 0` becomes "there is no obvious
way for a visitor to get in touch". Only measured values are ever described — a
figure that was not measured is not available to be described.

**Checked, not merely requested.** A prompt instruction is a request, so the draft
is inspected before it is saved. An email that gestures at problems without naming
one, or that puts `load_ms` or "4.8 seconds" in front of a business owner, is
regenerated once with the specific failure as the revision note. Two attempts, and
then it is saved for review with the problem logged — a person reads every email
before it goes out either way.

Two audit fields come back alongside the email: `observation` (the specific thing
it refers to) and `findings_used` (the exact issues it drew on). The review screen
displays both and tags each finding the email actually used, so you can see at a
glance whether an email is grounded or generic.

### Human review

Every email is shown before anything is sent. Per email:

| Action | Effect |
| --- | --- |
| **Edit** | Edit the subject and body in place, then save. |
| **Regenerate** | Rewrite from the same findings, optionally with a hint ("shorter", "less formal"). |
| **Re-review** | Re-run the website analysis over the already-crawled pages and rebuild the email. No extra crawling. |
| **Approve** | Move the email into the approved queue. |
| **Reject** | Exclude it from the campaign. |

Filter chips narrow the list by state, and **Approve all drafted** handles the bulk
case. Nothing is ever sent without an explicit approval.

Two further actions sit on each card: **Do not contact**, which adds the address
(or its whole domain) to the do-not-contact list, and **Contact anyway**, on
leads the duplicate check blocked.

Below every draft body is a line the sender appends to every outgoing message:

> If you're interested, simply reply to this email and our team will get back to
> you within 24 hours.

It is added in `build_message`, the single funnel every email passes through, so
no edit or regeneration can drop it. It is shown greyed out under the body so the
review is of the text that actually goes out. Moving it into the body while
editing keeps it where you put it rather than producing a second copy — the check
is idempotent and ignores wrapping and case.

### Do not contact

A separate list, and a deliberately stronger rule than the sending history. The
history answers *have we already emailed these people?*, which you may reasonably
override. This answers *are we allowed to email these people at all?*, and there
is no override at any layer — not from a campaign, not with a `force_contact`
draft, not from the pre-send reservation.

| | Sending history | Do-not-contact list |
| --- | --- | --- |
| Question | Already emailed? | Allowed to email? |
| Matching | Email, domain, name + city | Email, domain |
| Overridable | Yes, with a written reason | No |
| Undone by | A re-contact override | Removing the entry from the list |

Entries cover a single address or a whole domain, because "take us off your list"
usually means the company rather than the mailbox that happened to reply. There is
deliberately **no name-and-city tier**: that tier is a useful hint for spotting
duplicates, but far too loose to permanently block businesses whose owners never
asked for anything.

Adding an entry sweeps open campaigns immediately, so queued and drafted leads
drop out rather than continuing to cost AI calls. Already-sent drafts are left
alone — history is a record, and suppressing an address does not rewrite it.

The list is managed on the **Do not contact** screen, or from a lead's card during
a review, which is where a "please remove me" reply actually arrives.

### Deliberate re-contact

Tier 3 of the duplicate check matches on business name and city, so two unrelated
businesses sharing a name in one city will collide. **Contact anyway** is the
documented way out:

1. It requires a written reason of at least ten characters, kept with the send
   record.
2. It re-queues the lead — website analysed, email written — and the card appears
   with the others for review.
3. It overrides the sending history and nothing else. A suppressed address is
   refused with a 403 whatever reason is given.

The database guarantee is narrowed precisely and no further. Normally one live
history row per address is what makes a second send impossible. A re-contact row
is exempt from *that* rule — it is the rule being overridden — but a second
constraint still allows only one re-contact per address per campaign, so a
double-clicked Send cannot turn one approved re-contact into two emails. What is
given up is only the cross-campaign block, which is exactly what was asked for in
writing.

### Bulk email

Approved emails are sent through **your own authenticated SMTP account**. The
`From` header is built from the authenticated address and cannot be set to
anything else — a mismatch between the sender address and the SMTP login is a hard
error, not a warning.

| Provider | Host | Delay between messages | Daily cap |
| --- | --- | --- | --- |
| Gmail / Google Workspace | `smtp.gmail.com:587` | 2.5 s | 400 |
| Outlook / Microsoft 365 | `smtp.office365.com:587` | 3.5 s | 250 |
| Zoho Mail | `smtp.zoho.com:587` | 3.0 s | 200 |
| Fastmail | `smtp.fastmail.com:587` | 2.5 s | 300 |
| Other SMTP | `OUTREACH_SMTP_HOST` / `OUTREACH_SMTP_PORT` | 3.0 s | 200 |

Caps sit below each provider's published ceiling and count what that address has
already sent today across every campaign. Progress — **Total / Approved / Sent /
Failed / Queued** — is polled from the database, so reloading mid-send shows the
real state. **One rejected recipient is recorded and the run continues**; an
authentication or connection failure stops the run and returns every unsent draft
to the approved queue.

The SMTP password is never written to the database. It is supplied when the send
starts (or read from `OUTREACH_SMTP_PASSWORD`) and held only in the sending
thread's memory.

### Duplicate prevention

Every successful send writes a permanent row to a dedicated history table that
outlives the campaign which produced it: business name, email, website, domain,
country, city, campaign name and ID, sent date, sent time, subject and status.

Before any outreach, a lead is checked in **three tiers**:

1. **Exact email address** — the primary check.
2. **Website domain** — scheme and `www.` normalised, so `abc.com` and
   `https://www.abc.com/contact` count as one site.
3. **Business name + city** — deliberately *not* name alone, since chains share
   names across cities.

The tier that matched is always displayed, so a weaker name-and-city match can be
judged rather than silently blocking a lead.

The check runs at four points, because each catches what the others cannot:

| Layer | When | Catches |
| --- | --- | --- |
| Search annotation | As results arrive | The same city searched again |
| Campaign creation | On **Next** | A contacted lead entering a new campaign — costing no crawl and no AI call |
| Queue sweep | When Send starts | Anything contacted *since* the campaign was built |
| **Reservation** | Immediately before SMTP | A double-clicked Send, two campaigns sharing an address, two threads racing |

The do-not-contact list is checked at all four of the same points, and always
first, so its badge is never masked by a weaker already-contacted match.

**The reservation is what makes a duplicate impossible.** Before the connection
opens, the address is inserted into the history under a database unique constraint
covering every status except `failed`; a second caller receives an integrity error
instead of sending a second email. A genuine delivery failure marks the row
`failed`, which releases the address for a deliberate retry.

### Excel history

`exports/sent_leads.xlsx` is refreshed after every campaign and downloadable from
the Settings screen. Columns:

```
Record ID, Business Name, Email, Website, Country, City, Campaign,
Campaign ID, Sent Date, Sent Time, Email Subject, Status, Error
```

It **genuinely appends**: each row carries a stable UUID in the first column, the
IDs already present are read back, and only new records are written. Nothing
previously exported is touched, and running the export twice adds nothing the
second time. A new search does not create a second workbook — the existing file is
loaded and extended.

The **database is the source of truth** for duplicate prevention; the spreadsheet
is a human-readable export of it. A damaged or hand-edited file is replaced rather
than being allowed to fail a send, and an in-flight reservation is never exported.

### Reply tracking

Replies are read from the **same account and password used for sending** — there
is no second credential — over a read-only IMAP session. Nothing in the mailbox
is marked read or modified, and nothing is sent.

The rule that shapes it: an incoming email is examined only long enough to decide
whether it answers something this application sent. If it does not match, it is
dropped and **nothing about it is stored**. There is no mail store here — a
matched reply contributes a state, a timestamp and a two-line snippet to the row
it answers, and that is all.

Matching runs strongest-evidence-first:

| Tier | Evidence | Why it is trusted |
| --- | --- | --- |
| 1 | `In-Reply-To` / `References` quoting the `Message-ID` recorded at send time | Proof: the recipient's mail client quoted our own identifier |
| 2 | A delivery report naming the address, with a `5.x.x` status | The report comes from the mail system, not the recipient |
| 3 | Sender address, within the lookback window | Some clients strip threading headers |

**A subject line alone is never enough.** "Re: A quick idea for ABC Company" is
guessable, and acting on a guess would mark a lead as replied when it has not
replied.

Four states result: `No reply`, `Replied`, `Bounced`, `Unsubscribed`. Three
details are worth knowing:

- **A `4.x.x` deferral is not a bounce.** The mail system is still retrying, so
  recording it as bounced would close a live lead. Only `5.x.x` counts.
- **A quoted footer is not an unsubscribe request.** Every email invites a reply
  and mentions unsubscribing, so the reply's own text is separated from the
  quoted copy before it is read. A reply quoting our footer reads as `Replied`.
- **An unsubscribe or a bounce goes onto the do-not-contact list automatically.**
  Leaving a removal request to be actioned by hand is how it gets missed.

Run a check from the **Replies** screen, or on a schedule:

```bash
python manage.py check_replies              # read the inbox once
python manage.py check_replies --days 7     # narrow the window
python manage.py check_replies --dry-run    # report state, connect to nothing
```

The command only ever *reads*. It updates reply states, which is what makes
follow-ups available — it never sends one.

### Manual follow-ups

A follow-up exists because somebody clicked **Create follow-up**, and it goes out
because somebody then clicked **Send follow-up**. The waiting period makes a
follow-up *available*; it never makes one happen. There is no scheduler, no
queue, and no code path that sends a follow-up without a click.

Each emailed lead shows its thread and a verdict:

```
ABC Company
abc@company.com

✓ Initial email sent          17 Aug 2025
✕ No reply

Follow-up eligible: Yes (#1)          [ Create follow-up ]
```

```
ABC Company
abc@company.com

✓ Initial email sent          17 Aug 2025
↩ Replied — follow-ups stopped

Follow-up: not required
```

**A follow-up is never offered** to a lead that replied, bounced, unsubscribed, is
on the do-not-contact list, has an invalid address, has already reached the limit,
or already has a draft awaiting review.

Eligibility is **computed, not stored**. A lead's state changes underneath it — a
reply arrives, an address is suppressed, another follow-up goes out — and a stored
flag would be stale exactly when it matters. The same function answers for the
list, the create button and the pre-send check, so the count in the dashboard and
the buttons on the cards can never disagree.

#### What the AI is given

The follow-up is written from the original email, the website observation, the
verified findings, the company details, the campaign, and how long ago the last
message went out. The prompt's hardest rule is that it must **not restate the
first email** — the recipient may well read them side by side, and a follow-up
that repeats the original in new words reads as automated. So it references the
earlier message in a clause, adds a different angle or a smaller next step, and
stays under 90 words. The subject is rebuilt in code as `Re: <original>` rather
than trusted, because a follow-up that does not thread under the original defeats
the point.

Each draft reports the **angle** it added, so you can see at a glance whether it
is a genuine second message or a reworded first one.

#### Review, then send

Nothing is sent on generation. The draft appears with **Edit**, **Regenerate**,
**Cancel** and **Send follow-up**, and the recipient, subject and body are all
shown — including the standing reply line that gets appended.

Immediately before the connection opens, every question is asked again:

| # | Check | Why it is re-checked here |
| --- | --- | --- |
| 1 | Has the recipient replied since the draft was written? | The reason this check exists — a reply during review must stop the send |
| 2 | Is the address suppressed or unsubscribed? | The list may have gained the address minutes ago |
| 3 | Has this follow-up already been sent? | A double-clicked button |
| 4 | Has the follow-up limit been reached? | Another follow-up may have gone out meanwhile |
| 5 | Is the address still the lead's address? | A changed recipient is not the person who was reviewed |
| 6 | Is another process already sending to this lead? | A conditional `draft → sending` UPDATE, so exactly one caller wins |

If any check fails the send is cancelled and the reason is shown. A blocked draft
is marked `cancelled` rather than left looking sendable.

#### Limits and timing

| Setting | Default | Meaning |
| --- | --- | --- |
| `OUTREACH_FOLLOWUP_MAX` | `2` | Follow-ups a lead may ever receive |
| `OUTREACH_FOLLOWUP_DELAYS` | `3,7` | Days before #1 and #2 become available |
| `OUTREACH_INBOX_DAYS` | `45` | How far back an inbox check looks |
| `OUTREACH_IMAP_HOST` / `_PORT` | provider preset | Where replies are read from |

The wait runs from the **last message actually sent** to that lead, so follow-up
#2 waits seven days from follow-up #1 rather than from the original. Once the
maximum is reached the card reads *Follow-up limit reached* and no button is
offered; the deliberate re-contact workflow is separate and still available.

`OUTREACH_FOLLOWUP_MAX=0` disables follow-ups entirely.

#### History

Every follow-up is stored: lead, campaign, follow-up number, recipient, subject,
body, created date, sent date, status, and its own reply state and `Message-ID` —
so a reply to a follow-up is matched to the follow-up rather than to the original.
A `cancelled` row keeps the record of the decision and frees its number for
another attempt.

```
Initial email  →  no reply  →  Follow-up #1  →  no reply  →  Follow-up #2
Initial email  →  reply received  →  STOP
```

#### Dashboard

The **Replies** screen carries the roll-up and filters — `All`, `Replied`,
`No reply`, `Follow-up ready`, `Waiting`, `Follow-up sent`, `Bounced`,
`Unsubscribed` — and each campaign report repeats the figures for its own leads
with a link through.

```
Sent             100
Replies           18
No reply          72
Follow-up ready   35
Follow-ups sent   20
Bounced            5
Unsubscribed       3
```

### Campaign reports

Each campaign has a report showing **Total, Approved, Sent, Failed and Queued**,
the sender identity, start and finish times, and three tables:

- **Sent** — business, recipient, subject, timestamp.
- **Failed** — with the provider's own error text per recipient.
- **Not sent** — with the reason (rejected, already contacted, no email).

A **Campaigns** screen lists every run with roll-up totals, and each row links to
its report or reopens the original search.

---

## 5. System workflow

![System Workflow](docs/workflow.png)

*Source: [`docs/workflow.svg`](docs/workflow.svg) · regenerate with
`python docs/make_workflow.py`*

```
 1. Search for leads                   country, city, category, count
 2. Collect public business data        Nominatim + Overpass
 3. Display and export leads            map, list, CSV
 4. Check existing sending history      email, domain, name + city
 5. Select eligible leads               public email, not already contacted
    ┌─ for each selected lead, in turn ────────────────────────────────┐
 6. │ Automatically discover pages      nav, footer, sitemap, links    │
 7. │ Analyse the website               5+ pages, measured signals     │
 8. │ Identify genuine opportunities    8-10 findings, each with       │
    │                                   evidence                      │
 9. │ Generate a personalised email     built on the strongest         │
    │                                   findings                      │
    │ Save this lead's result           then, and only then, the next  │
    │                                   lead starts                   │
    └──────────────────────────────────────────────────────────────────┘
10. Review / edit / regenerate          nothing sends unreviewed
11. Approve the email                   explicit human decision
12. Perform the final duplicate check   address reserved before SMTP opens
13. Send via authenticated SMTP         your account, rate limited
14. Save sending history                permanent database record
15. Update the Excel export             appended, never overwritten
16. Generate the campaign report        sent / failed / queued

    ── days later ─────────────────────────────────────────────────────
17. Check the inbox for replies         replied / bounced / unsubscribed
18. Offer a manual follow-up            you create it, review it, send it
```

---

## 6. Architecture

Two Django apps with a clear split of responsibility.

```
leadmapper/          project configuration
├── settings.py      .env loader, SQLite, sender identity, send-block flag
└── urls.py          routes outreach/ to the outreach app, everything else to leads

accounts/            sign-up, sign-in, sign-out
├── backends.py      email-based authentication
├── forms.py         validation for both forms
└── views.py         the only views an anonymous visitor may reach

leads/               lead discovery — the map half
├── scraper.py       Nominatim geocoding, Overpass queries, tag normalisation, CSV
├── places.py        worldwide country and city data, dependent lookup, validation
└── views.py         search page, /api/search, /api/cities, /api/export/<job_id>

outreach/            research and outreach — the email half
├── analyzer.py      page discovery, polite crawling, signal measurement
├── ai.py            shared prompts, JSON schemas, parsing, provider dispatch
├── credentials.py   the one place provider keys are resolved and encrypted
├── aicontext.py     whose credentials the current request or thread uses
├── ai_claude.py     Anthropic backend
├── ai_gemini.py     Google backend
├── ai_groq.py       Groq backend
├── history.py       duplicate matching, send reservation, Excel export
├── inbox.py         read-only IMAP, reply/bounce/unsubscribe matching
├── followups.py     eligibility, timing, limits, the pre-send check
├── sender.py        SMTP providers, rate limits, anti-spoofing
├── runner.py        one lead at a time: crawl → review → generate → save; and the send
├── models.py        Campaign, EmailDraft, SentLead
└── views.py         setup, review workspace, send, report, campaigns, settings

exports/             generated CSVs and sent_leads.xlsx
docs/                workflow diagram and its generator
outreach.sqlite3     campaigns, drafts and sending history
```

| Module | Responsibility |
| --- | --- |
| `leads/scraper.py` | Talks to Nominatim and Overpass, converts OSM tags into lead records, writes CSV. Throttled per host. |
| `leads/places.py` | Country and city reference data, the dependent city lookup, and country/city validation. |
| `outreach/analyzer.py` | Decides which pages of a site to read, reads them politely, and measures the signals the AI is allowed to cite. |
| `outreach/ai.py` | Owns the prompts and schemas so switching provider cannot change the email contract. Backends are imported lazily. |
| `outreach/credentials.py` | Resolves every provider's key — the account's active credential, then `.env`, then a CLI profile — encrypts what Settings saves, and is the only module that ever holds a plaintext key. |
| `accounts/` | Sign-up, sign-in, sign-out, and the email-based authentication backend. Nothing else in the project touches authentication. |
| `outreach/history.py` | The duplicate-prevention core: the match index, the pre-send reservation, and the Excel export. |
| `outreach/sender.py` | SMTP transport, provider rate limits, the standing reply line, and the rule that the visible sender must be the authenticated account. |
| `outreach/inbox.py` | Reads replies over read-only IMAP and decides what an incoming email means. Drops anything that does not match something we sent, without storing it. |
| `outreach/followups.py` | The single answer to "may this lead be followed up, and if not, why not" — used by the list, the create button and the pre-send check alike. |
| `outreach/runner.py` | Runs the long jobs in a daemon thread so the browser can poll progress. Drives the per-lead loop and publishes which lead and step are in flight. |

Long-running work happens in background threads; the browser polls
`/outreach/<id>/state`, and all progress figures are computed from the database so
a reload mid-run shows the true state. `Campaign.current_draft` and
`Campaign.current_step` name the lead and the step being worked on, and each
draft carries its `sequence` in the run and a `processed_at` stamp — which is why
the progress panel reads the same after a reload as it did before.

---

## 7. Technology stack

| Layer | Technology |
| --- | --- |
| Language | Python 3.11+ (developed on 3.14) |
| Web framework | Django 5+ |
| Database | SQLite (`outreach.sqlite3`) |
| Authentication | `django.contrib.auth` — database sessions, PBKDF2 password hashing, `LoginRequiredMiddleware` |
| Frontend | Server-rendered Django templates, hand-written CSS design system, vanilla JavaScript — no build step, no framework |
| Map | Leaflet 1.9.4 with OpenStreetMap raster tiles |
| Geocoding | Nominatim (OpenStreetMap) |
| Business data | Overpass API (OpenStreetMap) |
| Country / city data | `geonamescache` — offline GeoNames extract |
| Website crawling | `requests` + `BeautifulSoup` (`beautifulsoup4`). **No headless browser** — pages are fetched as HTML and parsed; JavaScript is not executed. |
| AI | Anthropic, Google Gemini, OpenAI, OpenRouter or Groq — selectable in Settings |
| Credential storage | `cryptography` (Fernet) keyed off `DJANGO_SECRET_KEY` |
| Email | Python standard-library `smtplib` over STARTTLS/SSL |
| Reply reading | Python standard-library `imaplib` over IMAP4-SSL, read-only |
| Excel | `openpyxl` (no pandas) |
| Diagram | `Pillow` — docs-time only, not an application dependency |

---

## 8. Environment variables

Configuration is read from a git-ignored `.env` in the project root by a small
loader in `leadmapper/settings.py`. A real environment variable always takes
precedence over the file, so CI and one-off shell overrides still work.

**Never commit real credentials.** `.env` is listed in `.gitignore`;
`.env.example` is the template to copy.

```env
# --- Sender identity -------------------------------------------------------
OUTREACH_SENDER_EMAIL=you@example.com
OUTREACH_SENDER_NAME=Your Name
OUTREACH_SENDER_COMPANY=Your Company
OUTREACH_PROVIDER=gmail              # gmail | outlook | zoho | fastmail | custom

# --- SMTP ------------------------------------------------------------------
OUTREACH_SMTP_PASSWORD=your_app_password_here
# Only needed when OUTREACH_PROVIDER=custom
OUTREACH_SMTP_HOST=your_smtp_host
OUTREACH_SMTP_PORT=587

# --- Crawler identity ------------------------------------------------------
# Advertised in the User-Agent when fetching OpenStreetMap data and lead
# websites. Must be a real, reachable address: Nominatim returns 403 for
# placeholders such as you@example.com.
OSM_CONTACT_EMAIL=you@example.com

# --- AI provider -----------------------------------------------------------
# Optional: keys can also be saved in Settings, which take priority over these.
OUTREACH_AI_PROVIDER=claude          # claude | gemini | openai | openrouter | groq
ANTHROPIC_API_KEY=your_api_key_here
# GEMINI_API_KEY=your_api_key_here
# OPENAI_API_KEY=your_api_key_here
# OPENROUTER_API_KEY=your_api_key_here
# GROQ_API_KEY=your_api_key_here

# Set to 0 to close the credential-editing endpoints and use .env only.
# OUTREACH_CREDENTIALS_UI=1

# Optional overrides
# OUTREACH_AI_MODEL=claude-opus-5
# OUTREACH_AI_EFFORT=medium          # Claude only: low | medium | high
# OUTREACH_AI_CONTEXT_CHARS=9000     # crawled text sent per review
# OUTREACH_AI_AUDIT_TOKENS=2600      # output reservation for the review
# OUTREACH_AI_EMAIL_TOKENS=1200      # output reservation for one email

# --- Reply tracking and follow-ups -----------------------------------------
# Replies are read from the same account and password as sending; there is no
# second credential. Blank host uses the preset for OUTREACH_PROVIDER.
# OUTREACH_IMAP_HOST=imap.gmail.com
# OUTREACH_IMAP_PORT=993
# OUTREACH_INBOX_DAYS=45             # how far back an inbox check looks

# OUTREACH_FOLLOWUP_MAX=2            # follow-ups a lead may ever receive
# OUTREACH_FOLLOWUP_DELAYS=3,7       # days before #1 and #2 become available

# --- Django ----------------------------------------------------------------
# DJANGO_SECRET_KEY=change_me_before_exposing_this_anywhere
# DJANGO_DEBUG=1
# DJANGO_ALLOWED_HOSTS=example.com,www.example.com

# --- Safety ----------------------------------------------------------------
# Blocks all SMTP connections. On automatically during `manage.py test`.
# OUTREACH_BLOCK_SEND=1
```

| Variable | Required | Purpose |
| --- | --- | --- |
| `OUTREACH_SENDER_EMAIL` | Yes, to send | `From` header and SMTP login |
| `OUTREACH_SENDER_NAME` | Yes, to send | Display name and email sign-off |
| `OUTREACH_SENDER_COMPANY` | No | Referenced in the email body |
| `OUTREACH_PROVIDER` | Yes, to send | Selects SMTP host, delay and daily cap |
| `OUTREACH_SMTP_PASSWORD` | No | App password; prompted at send time if unset |
| `OUTREACH_SMTP_HOST` / `_PORT` | Only for `custom` | Custom SMTP server |
| `OSM_CONTACT_EMAIL` | Yes | Contact address in the crawler `User-Agent` |
| `OUTREACH_AI_PROVIDER` | No | Defaults to `claude` |
| `ANTHROPIC_API_KEY` / `GEMINI_API_KEY` / `OPENAI_API_KEY` / `OPENROUTER_API_KEY` / `GROQ_API_KEY` | For the chosen provider, unless saved in Settings | AI authentication |
| `OUTREACH_CREDENTIALS_UI` | No | `0` closes the credential write endpoints |
| `OUTREACH_AI_MODEL` | No | Overrides the provider's default model |
| `OUTREACH_IMAP_HOST` / `_PORT` | No | Where replies are read; defaults to the provider preset |
| `OUTREACH_INBOX_DAYS` | No | Lookback window for an inbox check (default 45) |
| `OUTREACH_FOLLOWUP_MAX` | No | Follow-ups per lead (default 2; `0` disables them) |
| `OUTREACH_FOLLOWUP_DELAYS` | No | Days before each follow-up (default `3,7`) |
| `OUTREACH_BLOCK_SEND` | No | Hard block on opening any SMTP **or IMAP** connection |
| `LIVE_OSM_TESTS` / `LIVE_WEB_TESTS` | No | Opt in to tests that make real network calls |

---

## 9. Installation

```bash
# 1. Clone
git clone <your-repository-url>
cd script

# 2. Create a virtual environment
python -m venv venv
```

Activate it:

```bash
# Windows (PowerShell)
venv\Scripts\Activate.ps1

# Windows (cmd)
venv\Scripts\activate.bat

# Linux / macOS
source venv/bin/activate
```

```bash
# 3. Install dependencies
pip install -r requirements.txt

# 4. Create the database
python manage.py migrate

# 5. Configure
cp .env.example .env        # Windows: copy .env.example .env
#    then edit .env

# 6. Run
python manage.py runserver
```

Open <http://127.0.0.1:8000/> — it redirects to `/login`. Create an account at
`/signup`; there is no separate admin step.

The lead search, map and CSV export work with no AI or SMTP credentials at all —
only the email half needs them.

Upgrading a database that predates accounts? Run
`python manage.py claim_data you@example.com` to assign the existing campaigns and
history to your account.

**Verify your configuration** before running a real campaign:

```bash
python manage.py ai_status          # which AI provider and credential are active
python manage.py claim_data you@example.com   # adopt pre-accounts rows and keys
python manage.py ai_status --live   # generate one throwaway email to prove it
python manage.py smtp_check         # connect, authenticate, quit — sends nothing
python manage.py check_replies --dry-run   # reply-tracking state, no connection
```

Only the provider named in `OUTREACH_AI_PROVIDER` needs its SDK installed;
backends are imported lazily, so the other two can be left uninstalled.

---

## 10. SMTP setup

Emails are sent from **your own authenticated account**. Nothing is relayed
through a third party.

1. Set `OUTREACH_SENDER_EMAIL` to the address you will log in with.
2. Set `OUTREACH_PROVIDER` to match that address — a `gmail.com` address pointed
   at the Outlook host will fail authentication on the first send.
3. Create an **app password**. Most providers no longer accept a normal account
   password over SMTP:
   - **Gmail / Workspace** — requires 2-Step Verification, then
     <https://myaccount.google.com/apppasswords>. Google displays it as four
     groups of four characters; either form can be pasted, as the spaces are
     stripped automatically.
   - **Outlook / Microsoft 365, Zoho, Fastmail** — see each provider's app-password
     documentation.
4. Put it in `OUTREACH_SMTP_PASSWORD`, or leave it unset and type it on the send
   screen each run.
5. Verify with `python manage.py smtp_check`.

**Rotating a password:** generate a new one, replace the line in `.env`, rerun
`smtp_check`, then revoke the old one at the provider.

Never commit a password, paste one into an issue, or include one in a screenshot.

---

## 11. AI setup

Five providers are supported. The prompts, JSON schemas, evidence rules and
parsing are shared, so switching provider changes cost, speed and quality — never
the email contract.

| Provider | Name | Default model | Environment variable | SDK |
| --- | --- | --- | --- | --- |
| Anthropic | `claude` *(code default)* | `claude-opus-5` | `ANTHROPIC_API_KEY` | `anthropic` |
| Google | `gemini` | `gemini-3.7-flash` | `GEMINI_API_KEY` / `GOOGLE_API_KEY` | `google-genai` |
| OpenAI | `openai` | `gpt-4.1-mini` | `OPENAI_API_KEY` | `openai` |
| OpenRouter | `openrouter` | `openai/gpt-4.1-mini` | `OPENROUTER_API_KEY` | `openai` |
| Groq | `groq` | `openai/gpt-oss-120b` | `GROQ_API_KEY` | `groq` |

Default models are deliberately small and cheap: writing one short email from
supplied material is not a reasoning-heavy task, and cost scales with list size.
Override the model per provider in Settings, or with `OUTREACH_AI_MODEL`.

### The credential pool

A provider is a **parent**. The keys you save under it are **children**, and
exactly one child is **active**:

```
OpenAI
  ● Production     sk-proj-••••••••9X2A    ACTIVE
  ○ Backup         sk-proj-••••••••4B71
  ○ Testing        sk-proj-••••••••K30Q    fallback
Groq
  ● Credential 1   gsk_••••••••5TR6        ACTIVE
Claude
  (no credentials — falls back to ANTHROPIC_API_KEY)
```

Activating a different child is the only thing needed to move **every** AI
feature — website reviews, first emails, follow-ups, no-website emails, and
anything added later — onto a different key. Nothing else in the application
refers to a key directly.

#### Where a key comes from

```
Active child credential   →  wins
Environment (.env)        →  used when no child is active
CLI login (Anthropic)     →  `ant auth login`, no key needed
Nothing                   →  a clear error naming the provider
```

Three setups are supported, with no migration between them:

| Setup | Behaviour |
| --- | --- |
| **`.env` only** | Exactly as before. Nothing to re-enter, no database row created. |
| **Settings only** | Add keys in the browser; no `.env` entries needed. |
| **Both** | The active child wins. Deactivate or delete it and `.env` takes over immediately. |

One module — [`outreach/credentials.py`](outreach/credentials.py) — answers
"which key?" for every provider, and one function in
[`outreach/ai.py`](outreach/ai.py) — `_complete()` — is the single path every AI
request takes. Tests assert both: no backend reads a provider environment
variable of its own, and no AI entry point calls a backend directly. Credential
resolution scattered across five files is how a provider ends up quietly using
another provider's key.

#### Whose key?

Credentials belong to an account, but the code that reaches for one is three
layers down (`ai.generate()` → `backend().complete()` → `client()` →
`credentials.require()`) and has no request. The owner is carried in a context
variable instead, set where work actually starts:

| Where work starts | Who sets the owner |
| --- | --- |
| An HTTP request | `AiOwnerMiddleware`, from `request.user` |
| A background campaign thread | `runner._spawn`, from `campaign.owner` |
| A management command | `--user`, or nobody |

With no owner set, the resolver uses **environment credentials only**. It never
falls back to "whichever database row it can find", so a context nobody set
cannot reach into an account's keys.

### Settings → AI credentials

Each provider card shows which credential is active, and one row per child with:

- **Name** — `Production`, `Backup`, whatever you called it
- **Masked key** — `sk-proj-••••••••9X2A`, the shape and last four characters
- **State** — `ACTIVE`, inactive, or `last request failed`
- **Usage** — when it was added, when it was last used, how many requests it has
  served and how many failed. Never used shows as `Unknown`, not as a zero date.
- **Last error** — a category and a locally written phrase, never the provider's
  own text
- **Activate / Deactivate**, **Test**, **Use as fallback**, **Delete**

**Add credential** takes a name, the key, an optional note, an optional model and
any provider-specific extras (a base URL and organisation id for OpenAI, a base
URL for OpenRouter). A duplicate name under the same provider is refused. The
first credential you add is activated automatically; later ones are not, unless
you tick the box — adding a spare must not silently redirect every request onto
it.

**Test** proves *that* credential, active or not, by making the cheapest call the
provider offers. It never changes which credential is active. Results are
`ok`, `invalid`, `rate_limited`, `forbidden`, `model`, `unavailable` or `error`,
and the message is written locally rather than passed through, because provider
error text can quote request details. Where `OUTREACH_BLOCK_SEND=1` — including
under `manage.py test` — a test is refused rather than quietly made.

**Deactivate** and **Delete** promote nothing in their place. The provider is left
reading `No active credential` and falls back to its environment variable if one
is set. Quietly moving every request onto a key nobody chose is the surprise this
whole design exists to prevent, so the confirmation says exactly that.

### Optional fallback

A spare credential can be marked **Use as fallback**. Then, if the active
credential fails with a rate limit or an unreachable provider, that spare is
tried **once, for that one request**:

- it is **off unless you turn it on**, per credential;
- the **active credential never changes** — a Settings page that no longer says
  what the application is doing is worse than a failed request;
- an **invalid key is not a reason to try another** — that is a configuration
  problem, not a transient one;
- if the spare fails too, the **active credential's** failure is what gets
  reported, so the real cause is not hidden;
- every use is recorded: which credential, why, when, and whether it worked.

### Choosing the provider

The provider selected in Settings decides **which service is called**; the
resolver decides **which key is used**. The browser sends `{"provider": "openai"}`
and never a key.

```
UI selection → resolver → active child → .env fallback → provider API
```

Model metadata belongs to the credential, so activating a different child can
change the model as well as the key — which is what you want when one key is on a
plan that allows a bigger model than another. Selecting a provider with no
credential is refused, in the browser and again on the server, with:

> OpenAI is not configured. Please add OpenAI credentials in Settings.

The same check runs when a campaign starts, so an unconfigured provider fails
before a single website is crawled rather than after all of them.

### How credentials are protected

- **Owned.** Every credential belongs to an account, and every endpoint re-reads
  it scoped to the signed-in user. A credential id in a URL grants nothing: it
  returns `404`, not `403`, because "forbidden" would confirm the credential
  exists.
- **Encrypted at rest** with Fernet, under a key derived from
  `DJANGO_SECRET_KEY` via PBKDF2-HMAC-SHA256 (200,000 iterations). The signing
  key alone does not decrypt them.
- **Never returned.** Every endpoint responds with masked hints, labels and
  counters. There is no `GET` that returns a key, and the settings page contains
  none — asserted by tests that scan the rendered HTML.
- **Never logged**, never placed in a URL, never written to `localStorage` or
  `sessionStorage`. The browser clears the input the moment it is posted.
- **Not in error messages.** `CredentialError` is documented never to carry a key,
  `ProviderCredential.__str__` returns the masked hint, and any diagnostic that
  looks like it might be quoting a request is replaced with
  `(withheld: the provider message may quote the request)`.
- **Not in the audit trail.** `CredentialEvent` records what happened to which
  label, and holds no key and no provider response body.
- **One active credential per provider per account**, enforced by a database
  constraint, so "which key is in use" has exactly one answer even if two tabs
  press Activate at the same moment.
- **Rotating `DJANGO_SECRET_KEY`** makes stored keys undecryptable. That is
  treated as "the saved credential is unusable, fall back to `.env`" and reported
  plainly, rather than crashing a campaign mid-run.

`OUTREACH_CREDENTIALS_UI=0` closes the write endpoints entirely and takes keys
only from `.env` — useful for a deployment where credentials are managed by
whoever manages the environment, not by whoever signs in.

### Command-line checks

```bash
python manage.py ai_status                        # environment only
python manage.py ai_status --user you@example.com  # include saved credentials
python manage.py ai_status --live                  # one throwaway email to prove it
```

Notes per provider:

- **Anthropic** — an API key is not the only option: after `ant auth login` the
  SDK reads the stored profile automatically. An **empty but present**
  `ANTHROPIC_API_KEY` still occupies the SDK's credential slot and authenticates
  with nothing, shadowing a working profile; `ai_status` reports that case
  specifically. `OUTREACH_AI_EFFORT` (`low`/`medium`/`high`) applies here only.
- **Groq** — strict JSON-schema enforcement requires a GPT-OSS model; other
  models fall back to looser JSON mode automatically. The output-token
  reservation counts against Groq's tokens-per-minute allowance, so if you see
  "request too large", lower `OUTREACH_AI_CONTEXT_CHARS`.
- **OpenAI and OpenRouter** share one SDK and one transport module. Models that
  cannot do strict schemas fall back to plain JSON mode; the parser validates the
  result either way.
- **OpenRouter** model names are `vendor/model`, and its catalogue moves — expect
  to set the model in Settings.
- **Google** — the free tier is heavily rate limited; adequate for testing, not
  for a real campaign.

A campaign is roughly two AI requests per lead: one website review and one email.

---

## 12. Testing

```bash
python manage.py test                            # full offline suite
python manage.py test leads                      # scraper, places, search views
python manage.py test outreach                   # crawler, AI, sender, history
python manage.py test outreach.test_suppression  # do-not-contact + re-contact
python manage.py test outreach.test_followups    # reply tracking + follow-ups
python manage.py test outreach.test_credentials   # the credential pool
python manage.py test accounts                   # login, signup, sessions, routes
python manage.py test outreach.test_authorization  # one account cannot read another's
```

Lint, checks and the static build:

```bash
python -m ruff check .                     # configured in ruff.toml
python manage.py check                     # configuration
python manage.py check --deploy            # production readiness
python manage.py makemigrations --check    # no pending model changes
python manage.py collectstatic --noinput   # the static build
```

There is no type-checking step: this is Python without annotations enforced, and
no type checker is configured. Ruff covers undefined and unused names, which is
what a type-checker would catch here.

The suite is **658 tests** and runs entirely offline: the AI providers, SMTP and
all HTTP calls are mocked, so it needs no credentials and costs nothing.

Two opt-in groups make real network calls:

```bash
# Nominatim and Overpass
LIVE_OSM_TESTS=1 python manage.py test          # PowerShell: $env:LIVE_OSM_TESTS="1"

# Fetch a real public website
LIVE_WEB_TESTS=1 python manage.py test
```

### Live sending is blocked during tests

`OUTREACH_BLOCK_SEND` is switched on automatically whenever `test` appears in
`sys.argv`, and **both** the SMTP session and the IMAP session refuse to open a
socket. This is deliberate: real credentials live in `.env`, so a stray test
reaching the send path would otherwise authenticate against a live mail server and
email real people — and a stray inbox check would read a real mailbox. Several
tests assert the block is active for each. Set `OUTREACH_BLOCK_SEND=1` to get the
same protection in any other environment.

Note that this guard keys on `test` in `sys.argv`, so a **standalone script** run
with `python myscript.py` does not get it. Export `OUTREACH_BLOCK_SEND=1` in the
environment before running anything ad hoc against the mail account.

---

## 13. Security

- **Every page and endpoint requires a session.** Enforced by
  `LoginRequiredMiddleware` — deny by default — with only `/login`, `/signup`,
  `/logout` and `/api/session` opting out. A test walks the real URL
  configuration to prove nothing else answers an anonymous request.
- **Users can only reach their own data.** Ownership is part of every query, not
  a check performed after fetching by id, so editing a URL parameter returns 404
  rather than another account's campaign. Thirty-three tests drive a second
  signed-in account against the first one's ids to prove it.
- **Passwords are hashed with PBKDF2** by `django.contrib.auth`, never stored or
  logged as typed, and never rendered into a page. Django's validators reject
  short, common, numeric and user-similar passwords.
- **A failed login says the same thing either way.** Wrong password, unknown
  address and disabled account produce a byte-identical message, so the form
  cannot be used to test whether an address has an account. The backend also does
  the same hashing work on a miss, so response time does not answer it either.
- **Sessions are cycled on login**, flushed on logout, and `HttpOnly` +
  `SameSite=Lax` always, `Secure` whenever `DEBUG=0`.
- **`next=` is validated** against this host, so login cannot be used as an open
  redirect.
- **Secrets live in `.env`**, never in tracked source. The repository contains no
  real credentials.
- **`.env` is excluded from Git** via `.gitignore`, alongside `outreach.sqlite3`
  and `exports/`. `.env.example` is the committed template.
- **SMTP is always authenticated.** The `From` header is constructed from the
  authenticated address; there is no code path that can send as an address you
  have not logged in to.
- **The SMTP password is never stored in the database.** It is passed in per run
  and held only in the sending thread's memory. A test asserts it does not appear
  in the campaign record.
- **Duplicate-send protection is enforced by a database constraint**, not only by
  application checks, so it holds even against two concurrent sending threads.
- **A rate-limited provider is not hammered.** One refusal pauses the whole run
  rather than being retried per lead, the provider's own `Retry-After` is
  respected, an unanswered wait uses exponential backoff, and a run that has
  parked five times stays parked until a person looks at it.
- **Cancellation is checked before every lead and every page fetch**, is
  idempotent, and takes precedence over any automatic retry. A cancelled run never
  resumes on its own.
- **The do-not-contact list cannot be overridden.** It is checked before the
  reservation, and a `force_contact` draft is refused just the same. A test
  asserts this specific combination.
- **Reading the inbox is read-only and narrow.** The IMAP mailbox is opened with
  `readonly=True`, so nothing is marked read or modified, and an email that does
  not match something this application sent is dropped without being stored.
- **No follow-up can be sent without a click.** There is no scheduler and no
  automatic send path; the waiting period only makes a follow-up available. Six
  conditions are re-checked immediately before the connection opens.
- **CAPTCHAs, login pages and paywalls are never bypassed.** A `401`, `402`, `403`
  or `429`, or a bot-check page, stops the crawl for that site.
- **`robots.txt` is fetched first and obeyed per URL**, with an unauthorised
  `robots.txt` treated as disallow-all. Requests to one host are spaced a second
  apart and identify themselves with a contact address.
- **The AI is never given room to invent a website problem.** Every finding must
  cite a measured signal, unevidenced findings are dropped in code before the
  prompt is built, and a draft that describes a problem vaguely or quotes a raw
  metric is regenerated rather than saved.
- **API keys are never exposed to the frontend.** All AI and SMTP calls are made
  server-side; no key is rendered into a template or served to the browser. Tests
  scan the rendered settings page and every endpoint response to prove it.
- **Provider keys saved in Settings are encrypted at rest** with Fernet under a
  key derived from `DJANGO_SECRET_KEY`, stored in one table, and readable only by
  the resolver.
- **Every credential belongs to one account.** The endpoints that manage them are
  signed-in-only and scoped to `request.user`; another account's credential id
  returns `404`. A request made in a context with no account resolves from the
  environment only, never from the database.
- **CSRF protection** is enabled on every state-changing request.
- Before deploying anywhere non-local, set `DJANGO_SECRET_KEY`, set
  `DJANGO_DEBUG=0`, and set `DJANGO_ALLOWED_HOSTS`.

---

## 14. Data and privacy

This tool collects **publicly published business information** from OpenStreetMap
and from businesses' own public web pages. It is designed for business-to-business
outreach.

- **Licensing.** OpenStreetMap data is provided under the
  [ODbL](https://www.openstreetmap.org/copyright). Publishing or redistributing
  collected data requires OpenStreetMap attribution; every CSV row includes a
  `Source` permalink, and the interface credits OpenStreetMap.
- **Usage policies.** Nominatim and Overpass are public services with published
  usage policies. This project honours them: a real contact address in the
  `User-Agent`, and per-host request throttling.
- **Website access.** Only publicly accessible pages are read. Access
  restrictions of any kind are respected rather than circumvented.
- **Email marketing rules are your responsibility.** A publicly listed address is
  not by itself consent to be marketed to, and the rules differ by jurisdiction
  and by whether the mailbox belongs to a company or a named person — GDPR and
  PECR in the EU and UK, CAN-SPAM in the US, CASL in Canada, and others. Check
  what applies to your recipients before sending.
- **Unsubscribes.** Every email carries a `List-Unsubscribe` header, and every
  email invites a reply. A reply asking to be removed is detected by the inbox
  check and added to the **Do not contact** list automatically; you can also add
  an address by hand. Either way it applies to every future campaign with no way
  to override it.
- **Reply content.** A matched reply contributes a state, a timestamp and a short
  snippet to the lead it answers. Unrelated inbox mail is never stored, and no
  mailbox is copied into the database.
- **Pointing the scraper elsewhere.** If you adapt this to a commercial directory
  instead of OpenStreetMap, that is a different legal question with a different
  answer — read that site's terms first.

---

## 15. Project structure

```
.
├── README.md
├── manage.py
├── requirements.txt
├── .env.example                  # committed template
├── .env                          # your credentials (git-ignored)
├── .gitignore
├── outreach.sqlite3              # database (git-ignored)
│
├── docs/
│   ├── workflow.png              # rendered diagram
│   ├── workflow.svg              # editable source
│   └── make_workflow.py          # regenerates both from one spec
│
├── exports/                      # generated output (git-ignored)
│   ├── leads_<city>_<category>_<timestamp>.csv
│   └── sent_leads.xlsx
│
├── accounts/                     # authentication
│   ├── backends.py               # log in with an email address
│   ├── forms.py                  # login + signup validation
│   ├── views.py                  # login, signup, logout, session state
│   ├── urls.py
│   ├── tests.py                  # login, signup, sessions, route protection
│   ├── templates/accounts/
│   │   ├── auth_base.html        # shell with no app navigation
│   │   ├── login.html
│   │   └── signup.html
│   └── static/accounts/js/auth.js
│
├── leadmapper/                   # project configuration
│   ├── settings.py
│   ├── urls.py
│   ├── wsgi.py
│   └── asgi.py
│
├── leads/                        # lead discovery
│   ├── scraper.py                # Nominatim + Overpass + CSV
│   ├── places.py                 # country and city data
│   ├── views.py                  # search page and JSON APIs
│   ├── urls.py
│   ├── tests.py                  # scraper and view tests
│   ├── test_places.py            # country/city dropdown tests
│   ├── templates/
│   │   ├── leads/index.html      # lead search screen
│   │   └── shared/
│   │       ├── base.html         # app shell
│   │       └── icons.html        # SVG icon sprite
│   └── static/leads/
│       ├── css/style.css         # design system
│       ├── css/combobox.css
│       ├── js/app.js             # search, map, selection
│       ├── js/combobox.js        # searchable dropdown
│       └── js/ui.js              # toasts, modals, helpers
│
└── outreach/                     # research and outreach
    ├── analyzer.py               # page discovery, crawling, measurement
    ├── ai.py                     # prompts, schemas, provider dispatch
    ├── ai_base.py                # shared types
    ├── credentials.py            # key resolution + encryption (the resolver)
    ├── ai_claude.py
    ├── ai_gemini.py
    ├── ai_groq.py
    ├── ai_openai.py
    ├── ai_openrouter.py
    ├── ai_openai_compatible.py   # shared transport for openai + openrouter
    ├── history.py                # duplicate prevention, suppression, Excel export
    ├── inbox.py                  # read-only IMAP reply/bounce/unsubscribe matching
    ├── followups.py              # eligibility, timing, limits, pre-send check
    ├── sender.py                 # SMTP transport, rate limits, the reply line
    ├── runner.py                 # the sequential per-lead loop, and the send
    ├── models.py                 # Campaign, EmailDraft, SentLead, Suppression
    ├── views.py
    ├── urls.py
    ├── tests.py
    ├── test_history.py
    ├── test_suppression.py       # do-not-contact list + re-contact override
    ├── test_followups.py         # reply tracking + manual follow-ups
    ├── test_credentials.py       # the credential pool: priority, ownership, masking
    ├── test_runcontrol.py        # rate-limit pauses, and one-click cancel
    ├── test_evidence.py          # the findings behind each email
    ├── test_authorization.py     # one account cannot reach another's data
    ├── testsupport.py            # signed-in TestCase, second-account fixture
    ├── migrations/
    ├── management/commands/
    │   ├── ai_status.py          # inspect / test the AI credential
    │   ├── claim_data.py         # assign pre-accounts rows to an account
    │   ├── check_replies.py      # read the inbox once (schedulable)
    │   └── smtp_check.py         # authenticate without sending
    ├── templates/outreach/
    │   ├── setup.html            # lead selection + sender settings
    │   ├── workspace.html        # findings + email review
    │   ├── report.html           # campaign report
    │   ├── history.html          # all campaigns
    │   ├── dashboard.html        # the authenticated home
    │   ├── followups.html        # replies, eligibility, follow-up review
    │   ├── suppressions.html     # the do-not-contact list
    │   └── settings.html         # read-only configuration
    └── static/outreach/
        ├── css/outreach.css
        ├── js/credentials.js
        ├── js/followups.js
        ├── js/setup.js
        ├── js/suppressions.js
        └── js/workspace.js
```

### Routes

All routes below require a signed-in account except the four marked *public*.

| Method | Path | Purpose |
| --- | --- | --- |
| GET/POST | `/login` | Sign in — *public* |
| GET/POST | `/signup` | Create an account — *public* |
| POST | `/logout` | Sign out — *public* |
| GET | `/api/session` | Whether this request is authenticated — *public* |
| GET | `/dashboard` | The authenticated home |
| GET | `/` | Lead search screen |
| POST | `/api/search` | Run a search; returns leads, history annotation, CSV name |
| GET | `/api/cities?country=` | Cities for the selected country |
| GET | `/api/export/<job_id>` | Download the search CSV |
| POST | `/outreach/start` | Create a campaign from selected leads |
| GET | `/outreach/<id>/setup` | Lead selection and sender settings |
| POST | `/outreach/<id>/run` | Start crawl → review → generate |
| GET | `/outreach/<id>/` | Review workspace |
| GET | `/outreach/<id>/state` | JSON progress and drafts (polled) |
| POST | `/outreach/<id>/resume` | Pick up an interrupted, paused or cancelled run, or release a stalled send |
| POST | `/outreach/<id>/cancel` | Stop the lead-processing job (idempotent) |
| POST | `/outreach/draft/<pk>/<action>` | `save`, `regenerate`, `rereview`, `approve`, `reject`, `recontact`, `suppress` |
| POST | `/outreach/<id>/approve-all` | Approve every drafted email |
| POST | `/outreach/<id>/send` | Start the bulk send |
| GET | `/outreach/<id>/report` | Campaign report |
| GET | `/outreach/history` | All campaigns |
| GET | `/outreach/history.xlsx` | Download the Excel history |
| POST | `/outreach/ai/select` | Choose the active provider (sends a name, never a key) |
| POST | `/outreach/ai/credentials/<provider>/add` | Add a credential under a provider; returns masked status |
| POST | `/outreach/ai/credentials/<id>/activate` | Make this credential the active one |
| POST | `/outreach/ai/credentials/<id>/deactivate` | Stand it down; promotes nothing in its place |
| POST | `/outreach/ai/credentials/<id>/test` | Minimal request to verify this credential |
| POST | `/outreach/ai/credentials/<id>/fallback` | Allow or stop one retry on this spare |
| POST | `/outreach/ai/credentials/<id>/delete` | Delete this credential |
| GET | `/outreach/ai/credentials/events` | Recent credential history (no keys) |
| GET | `/outreach/followups` | Replies, eligibility and follow-up review |
| POST | `/outreach/followups/check-inbox` | Read the inbox once |
| POST | `/outreach/lead/<pk>/followup` | Generate a follow-up draft (sends nothing) |
| POST | `/outreach/followup/<pk>/<action>` | `save`, `regenerate`, `cancel`, `send` |
| GET | `/outreach/suppressions` | The do-not-contact list |
| POST | `/outreach/suppressions/add` | Add an address or domain |
| POST | `/outreach/suppressions/<pk>/remove` | Remove an entry |
| GET | `/outreach/settings` | Configuration, and the AI credential pool |

---

## 16. Troubleshooting

**SMTP authentication failure**
Run `python manage.py smtp_check` for the exact error. Most often the password is
a normal account password rather than an app password, or `OUTREACH_PROVIDER` does
not match the address domain. The sender address must equal the SMTP login — the
app refuses to send as an address you have not authenticated.

**Missing AI API key**
`python manage.py ai_status` reports every provider, where its credential comes
from, and what to fix. Or open **Settings → AI providers** and save a key there.
Watch for one trap: an **empty but present** `ANTHROPIC_API_KEY` outranks an
`ant auth login` profile and authenticates with nothing. Unset it, don't blank it.

**A key saved in Settings is not being used**
Check the card's **Source**. If it reads `Environment`, the save did not take —
the most likely reason is that `DJANGO_SECRET_KEY` changed since it was saved, in
which case the card also says so. Save the key again to replace it.

**"This AI provider is not configured"**
The selected provider has no key in either place. Save one in **Settings → AI
providers**, or select a provider whose card shows a tick. The campaign start
screen refuses to run rather than crawling every website first and then failing.

**Test connection says the model was not found**
The key is probably fine — that error means the model name is wrong for the
account. Clear the model field to fall back to the provider's default, or set a
model the key has access to. OpenRouter names are `vendor/model`.

**"Request too large" from Groq**
The output reservation counts against Groq's tokens-per-minute allowance. Lower
`OUTREACH_AI_CONTEXT_CHARS` (default `9000`). The crawl itself is unaffected.

**A website cannot be analysed**
Expected and handled. `robots.txt` may disallow crawling, the site may return
`403`/`429`, or it may sit behind a bot check — all are recorded, none are
bypassed. The lead still gets an email, written without implying the site was
seen. The review card shows the reason.

**No emailable leads / "invalid email"**
OpenStreetMap email coverage is patchy; a minority of businesses publish one. Try
a broader category or a larger city. Leads without a valid address are shown but
cannot be selected.

**Nominatim returns 403**
`OSM_CONTACT_EMAIL` is a placeholder. Nominatim rejects `you@example.com` and
similar. Set a real, reachable address.

**CSV download says the export expired**
Finished searches are held in a capped in-memory dictionary, which a server
restart clears. The files themselves survive in `exports/` — or simply run the
search again.

**Excel history looks wrong or is locked**
Close the workbook in Excel; Windows locks an open file against writing. A damaged
file is replaced automatically rather than failing a send. The database is the
source of truth, so regenerating the export loses nothing: download it again from
Settings.

**A lead is wrongly flagged as already contacted**
Tier 3 matches on business name + city, so two unrelated businesses sharing a name
in one city will collide. The card shows which tier matched, and **Contact
anyway** in the *Not in this campaign* list overrides it once you give a reason.
The lead is then analysed and drafted like any other.

**A lead says "do not contact" and cannot be overridden**
That is correct — the do-not-contact list is absolute by design. If the entry
itself is wrong, remove it on the **Do not contact** screen, then re-select the
lead from a new search.

**A run stopped halfway and nothing is happening**
The server was restarted mid-campaign. The workspace shows a **Resume** banner;
resuming skips every lead already finished and every step the interrupted lead
already completed. For a stalled send the button reads **Release queue** instead,
because the SMTP password is never stored — press Send again afterwards.

**The inbox check finds nothing**
Emails sent before reply tracking existed have no stored `Message-ID`, so replies
to them can only be matched by sender address. `python manage.py check_replies
--dry-run` reports how many sends have one. New sends always record it.

**IMAP login is rejected**
The same app password as sending is used, but IMAP often has to be enabled
separately on the account (Gmail: Settings → Forwarding and POP/IMAP). Check
`OUTREACH_IMAP_HOST` if the account is not with a preset provider.

**A lead shows "no reply" but they did reply**
The reply may be outside the lookback window (`OUTREACH_INBOX_DAYS`, default 45),
or it arrived from a different address than the one emailed. A subject-line match
alone is deliberately not accepted, because acting on a guess would mark a lead as
replied when it has not.

**Create follow-up is not offered**
The card states the reason: the lead replied, bounced, unsubscribed, is
suppressed, has an invalid address, is still inside the waiting period, has a
draft already awaiting review, or has reached `OUTREACH_FOLLOWUP_MAX`.

**A follow-up was cancelled when I pressed Send**
Something changed while it sat in review — most often a reply arrived, or the
address went onto the do-not-contact list. That is the pre-send check doing its
job; the reason is shown on the card.

**Everything redirects to /login**
That is the design — no page is anonymous. Create an account at `/signup`.

**My campaigns disappeared after upgrading**
They have no owner yet, and an unowned row is visible to nobody. Run
`python manage.py claim_data you@example.com` to assign them to your account;
`--dry-run` reports what it would do first.

**A lead I emailed from another account is not flagged as contacted**
Correct: the sending history is per-account, so "already contacted" means "by
this account". Two accounts may each contact the same business.

**`check_replies` asks which account to use**
A reply can only answer something a particular account sent, so once more than
one account exists the command needs `--user you@example.com` rather than
guessing.

**Database migration issues**
Run `python manage.py migrate`. If models were changed locally,
`python manage.py makemigrations outreach` then migrate. `python manage.py check`
validates configuration without touching the database.

**A city is rejected as belonging to another country**
That is the validation working — for example city `Paris` with country `Germany`.
Pick a city from the dropdown, or clear the country field to search by place name
alone. A place the reference data has never heard of is *allowed* through; only
contradictions are blocked.

---

## 17. Future improvements

Ideas, **not implemented**. Nothing in this section exists in the codebase today.

- **Country-wise Excel workbooks.** Splitting the single `sent_leads.xlsx` into
  `email_history/Pakistan.xlsx`, `email_history/UAE.xlsx` and so on, loading and
  extending the existing file per country.
- **Automatic inbox polling.** The inbox is checked when you press the button or
  run `check_replies`; a background schedule inside the app would remove that
  step. Sending a follow-up would remain manual.
- **Reply-rate reporting over time.** Per-campaign reply rates exist as counts;
  trends across campaigns and per category do not.
- **Lead scoring.** Ranking prospects by the severity of their website findings and
  by business signals, so the best prospects are contacted first.
- **CRM integration.** Pushing approved or sent leads into an external CRM.
- **Richer analytics.** Open and click tracking, per-category conversion, and
  historical trends.
- **Additional permitted data sources** alongside OpenStreetMap, subject to each
  source's terms.
- **A headless-browser crawl mode** for sites that render entirely in JavaScript,
  which the current HTML-only fetch cannot read.
- **Multi-user support** with per-user sending identities and separate histories.
  This is also what the credential store is waiting for: `ProviderCredential` has
  one active row per provider, and the unique constraint would become
  `(user, provider)` with the endpoints behind an authenticated admin check.

---

## Licence and attribution

Business data comes from [OpenStreetMap](https://www.openstreetmap.org/copyright)
and is licensed under the ODbL — attribution is required if you redistribute it.
Country and city reference data comes from [GeoNames](https://www.geonames.org/)
via `geonamescache`.
