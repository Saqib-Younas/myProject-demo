# Deploying Lead Mapper on AWS EC2

A runbook for putting this application on a single EC2 instance. Two routes are
given: **Docker Compose**, which is six commands and gets its own TLS certificate,
and a **manual** install behind nginx for when you would rather not run Docker.

Written for **Ubuntu Server 24.04 LTS**. The manual route uses the Python 3.12 it
ships; the container pins its own.

Replace every `example.com`, `1.2.3.4` and `you@example.com` with your own. No
real secret appears in this file, and none should ever be added to it.

---

## 1. What you are deploying, and why the choices below are what they are

Four properties of this application decide the whole shape of the deployment.
They are worth reading before running anything, because two of them will bite
silently if ignored.

| Property | Consequence |
| --- | --- |
| **Background work runs in threads inside the web process.** `runner._running` is a per-process set, and a campaign's crawl → review → email job is a daemon thread spawned from the request that started it. | **Run exactly one Gunicorn worker.** With two, one Send click can land on worker A while a second lands on worker B, and both will start a job for the same campaign — the "one job per campaign" guarantee is per process, not per database. Use threads for concurrency instead. |
| **The database is a single SQLite file** (`outreach.sqlite3`), written by a worker thread while requests read from it. | One worker (see above), WAL journal mode, and a backup that copies one file. No RDS needed, and nothing here benefits from one. |
| **Saved AI keys are encrypted with a key derived from `DJANGO_SECRET_KEY`.** | If you copy an existing `outreach.sqlite3` to the server but generate a *new* secret key there, those saved keys cannot be decrypted. The application handles it gracefully — it falls back to the environment variables and says so — but you will need to add them again in Settings. Decide once, then keep the key stable. |
| **Some requests make a synchronous AI call** — Test Connection, and the interactive Regenerate button. | Gunicorn's default 30-second timeout will kill them mid-thought. Use `--timeout 120`. |

Everything else is a conventional Django deployment.

---

---

## 2. Instance and network

**Instance type.** `t3.small` (2 vCPU, 2 GB). The crawler parses HTML with
BeautifulSoup while Django serves the workspace poll, and 1 GB is tight for that
plus the AI SDK. `t4g.small` (ARM) is about 20% cheaper and works — every
dependency has an aarch64 wheel — but stay on `t3.small` if you would rather not
think about architecture at all.

**Storage.** 20 GB gp3. The database and the exports are small; the room is for
logs and OS upgrades.

**Elastic IP.** Allocate one and associate it. Without it the public IP changes
on every stop/start, which breaks `DJANGO_ALLOWED_HOSTS` and your DNS record.

**Security group.** Inbound:

| Port | Source | Why |
| --- | --- | --- |
| 22 | **your IP only** (`1.2.3.4/32`) | SSH. Never `0.0.0.0/0`. |
| 80 | `0.0.0.0/0` | HTTP, for the certificate challenge and the redirect to HTTPS |
| 443 | `0.0.0.0/0` | HTTPS |

Outbound: leave the default "all traffic". The application needs it for three
things — the AI provider (443), SMTP (**587**) and IMAP (**993**) — plus crawling
lead websites.

> **Port 25 is throttled by AWS** on new accounts. This does not affect you:
> Gmail and every provider in `outreach/sender.py` use 587 (STARTTLS) or 465,
> neither of which is restricted. Do not request the port-25 limit to be lifted;
> you do not need it.

---

## 3. Two routes

| | Docker (§4) | Manual (§5 onwards) |
| --- | --- | --- |
| Steps to a running site | 6 | ~40 |
| TLS certificate | automatic, renewed by Caddy | certbot, plus its timer |
| Python version | pinned in the image | whatever the OS ships |
| Rollback | `docker compose up -d` on the previous image | reinstall and hope |
| Debugging inside | one more layer to reason about | direct |

**Take the Docker route unless you have a reason not to.** The manual route is
kept because it is worth understanding what the container is doing, and because
some people would rather not run Docker on a box that also sends their email.

Everything from §12 (scheduled work) onwards applies to both, with the command
prefix noted there.

---

## 4. Docker

### 4.1 Install Docker

```bash
ssh -i leadmapper.pem ubuntu@example.com

sudo apt update && sudo apt upgrade -y
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
  | sudo tee /etc/apt/keyrings/docker.asc > /dev/null
sudo chmod a+r /etc/apt/keyrings/docker.asc
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] \
https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo $VERSION_CODENAME) stable" \
  | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io \
                    docker-buildx-plugin docker-compose-plugin
sudo usermod -aG docker ubuntu       # log out and back in for this to apply
sudo timedatectl set-timezone UTC
```

### 4.2 Get the code and the environment onto the box

```bash
# On your machine, from the project directory. Git Bash on Windows.
rsync -av --delete \
  --exclude '.venv' --exclude '__pycache__' --exclude '.env' \
  --exclude 'outreach.sqlite3' --exclude 'staticfiles' --exclude 'exports' \
  -e "ssh -i leadmapper.pem" ./ ubuntu@example.com:~/leadmapper/
```

Then on the server:

```bash
cd ~/leadmapper
cp .env.example .env
chmod 600 .env
nano .env
```

Fill in `.env` as §8 describes, plus the two keys that only Docker reads:

```ini
SITE_ADDRESS=leadmapper.example.com     # or :80 while DNS is still propagating
ACME_EMAIL=you@example.com
DJANGO_ALLOWED_HOSTS=leadmapper.example.com,localhost
```

`localhost` belongs in that list: the image's healthcheck asks the application
about itself over 127.0.0.1, and Django would answer `400 Bad Request` to a host
it has not been told about — which reads as an unhealthy container.

### 4.3 Start it

```bash
docker compose up -d --build
docker compose logs -f web           # watch it migrate and come up
```

The first start does four things in order, all idempotent, so a restart repeats
them harmlessly:

1. refuses to run if `DJANGO_SECRET_KEY` is unset — the development fallback would
   issue forgeable session cookies *and* make AI credentials saved in Settings
   undecryptable later;
2. runs `collectstatic` into the shared volume, so the proxy serves this
   release's CSS rather than the previous one's;
3. applies migrations;
4. switches the database to WAL journal mode, which is what lets the campaign
   worker thread write while the workspace polls for progress.

Create your account:

```bash
docker compose exec web python manage.py createsuperuser
```

Then open `https://leadmapper.example.com`. Caddy will have obtained a
certificate on the first request, provided DNS already points at the Elastic IP.

### 4.4 Bringing an existing database with you

The database lives in the `data` volume, not in the image. To carry your local
history over, copy the file in and claim it:

```bash
# locally
scp -i leadmapper.pem outreach.sqlite3 ubuntu@example.com:/tmp/

# on the server
docker compose cp /tmp/outreach.sqlite3 web:/data/outreach.sqlite3
docker compose restart web           # migrate + WAL run again on start
docker compose exec web python manage.py claim_data you@example.com
```

Those campaigns predate accounts and belong to nobody, which means they are
visible to nobody until `claim_data` assigns them — that is the safe default, not
a bug.

> **Keep `DJANGO_SECRET_KEY` the same as the one that wrote that database**, or
> any AI key saved through Settings cannot be decrypted on the server. The
> application degrades gracefully and says so, but you will be adding those keys
> again.

### 4.5 Day to day

```bash
docker compose logs -f web                    # application log
docker compose ps                             # health status
docker compose exec web python manage.py ai_status --user you@example.com
docker compose exec web python manage.py smtp_check
docker compose restart web
docker compose down                           # stop; volumes survive
```

Deploying a change:

```bash
cd ~/leadmapper
rsync ...                                     # or git pull
docker compose up -d --build
```

`--build` rebuilds the image; the entrypoint migrates and re-collects static on
start, so there is no separate deploy sequence to remember. A campaign that was
running is interrupted by the replacement — the workspace detects that and offers
**Resume**, which skips every lead already finished.

Backups are a copy of one file:

```bash
docker compose exec web sqlite3 /data/outreach.sqlite3 \
  ".backup '/data/backup-$(date +%F).sqlite3'"
docker compose cp web:/data/backup-$(date +%F).sqlite3 ./
```

Put that in the host's crontab, and push the result to S3 with an IAM instance
role if you want it off the box.

### 4.6 Running it locally first

Worth doing before you touch EC2 — it is the same image:

```bash
cp docker-compose.override.yml.example docker-compose.override.yml
docker compose up --build
# http://localhost:8000
```

The override mounts your working copy, switches to `runserver` for autoreload and
tracebacks, and disables Caddy — a certificate for a laptop is not a thing. Do not
copy it to the server.

### 4.7 What the container does and does not include

| | |
| --- | --- |
| **Included** | Python 3.12, the dependencies, Gunicorn, the static files, `sqlite3` and `curl` |
| **In the `data` volume** | `outreach.sqlite3` and `exports/` — the only state worth backing up |
| **From `.env` at runtime** | every secret. Nothing sensitive is baked into a layer, which is why `.dockerignore` excludes `.env` |
| **Not included** | a database server (there is nothing to run), Redis, Celery — the campaign worker is a thread, deliberately |
| **One process** | Gunicorn with `--workers 1 --threads 8`. Not a placeholder: see §1 |

---

## 5. First login and system packages

```bash
ssh -i leadmapper.pem ubuntu@example.com

sudo apt update && sudo apt upgrade -y
sudo apt install -y python3.12 python3.12-venv python3-pip nginx sqlite3 \
                    git rsync unattended-upgrades
sudo timedatectl set-timezone UTC          # the app stores UTC; keep the box UTC
```

`unattended-upgrades` is included deliberately: this box will sit on the public
internet holding email credentials.

Create a service account that owns the application and can log in to nothing:

```bash
sudo useradd --system --create-home --home-dir /opt/leadmapper \
             --shell /usr/sbin/nologin leadmapper
```

---

## 6. Get the code onto the box

The project is not currently a Git repository, so either path works.

**Option A — rsync from your machine** (simplest for now). Run this *locally*,
from the project directory:

```bash
# Windows: run from Git Bash. The excludes matter -- never ship .env, the local
# database, or the local virtualenv.
rsync -av --delete \
  --exclude '.venv' --exclude '__pycache__' --exclude '.env' \
  --exclude 'outreach.sqlite3' --exclude 'staticfiles' --exclude 'exports' \
  -e "ssh -i leadmapper.pem" ./ ubuntu@example.com:/tmp/leadmapper/

# then, on the server:
sudo rsync -a --delete /tmp/leadmapper/ /opt/leadmapper/app/
sudo chown -R leadmapper:leadmapper /opt/leadmapper
```

**Option B — a private Git repository** (better, and worth doing before the first
change you make in production). Create it private, confirm `.gitignore` already
excludes `.env`, `outreach.sqlite3`, `exports/` and `staticfiles/` — it does —
then:

```bash
sudo -u leadmapper git clone git@github.com:you/leadmapper.git /opt/leadmapper/app
```

Deploying an update then becomes `git pull` plus the steps in §13.

---

## 7. Virtualenv and dependencies

```bash
sudo -u leadmapper python3.12 -m venv /opt/leadmapper/venv
sudo -u leadmapper /opt/leadmapper/venv/bin/pip install --upgrade pip wheel
sudo -u leadmapper /opt/leadmapper/venv/bin/pip install \
     -r /opt/leadmapper/app/requirements.txt gunicorn
```

`requirements.txt` uses lower bounds, so a fresh install may pick up a newer
Django than the one this was tested against. The tested set is:

```
Django 6.1 · requests 2.34 · beautifulsoup4 4.15 · openpyxl 3.1.5
cryptography 49.0 · groq 1.6
```

If you want the server to match exactly, pin them: run `pip freeze >
requirements.lock.txt` on a machine where the suite passes, ship that file, and
install from it instead.

Only the SDK for the provider you actually use is needed — the backends are
imported lazily. Installing all four is harmless and lets you switch provider in
Settings without touching the server.

---

## 8. The environment file

```bash
sudo -u leadmapper cp /opt/leadmapper/app/.env.example /opt/leadmapper/app/.env
sudo -u leadmapper chmod 600 /opt/leadmapper/app/.env
sudo -u leadmapper nano /opt/leadmapper/app/.env
```

Generate the secret key **once** and never rotate it casually:

```bash
/opt/leadmapper/venv/bin/python -c \
  "import secrets; print(secrets.token_urlsafe(64))"
```

The production block, on top of what `.env.example` already documents:

```ini
# --- Django ---------------------------------------------------------------
DJANGO_SECRET_KEY=<the 64-character value you just generated>
DJANGO_DEBUG=0
DJANGO_ALLOWED_HOSTS=example.com,www.example.com

# HTTPS. Switch these on only once §11 is finished and the certificate works --
# both break a site that is not actually served over HTTPS, and HSTS is
# remembered by the browser, so it is hard to undo.
DJANGO_SSL_REDIRECT=1
DJANGO_HSTS_SECONDS=31536000
DJANGO_TRUST_PROXY_TLS=1

# --- Sending --------------------------------------------------------------
OUTREACH_SENDER_EMAIL=you@example.com
OUTREACH_SENDER_NAME=Your Name
OUTREACH_SENDER_COMPANY=Your Company
OUTREACH_PROVIDER=gmail
OSM_CONTACT_EMAIL=you@example.com

# Optional. Leave it out and the browser prompts for the password per run, which
# keeps it out of the filesystem entirely -- at the cost of typing it each time.
# OUTREACH_SMTP_PASSWORD=xxxx xxxx xxxx xxxx

# --- AI -------------------------------------------------------------------
OUTREACH_AI_PROVIDER=groq
GROQ_API_KEY=...
```

Three notes on that file:

- **`DJANGO_TRUST_PROXY_TLS=1` is required behind nginx.** Without it Django sees
  a plain-HTTP request from the proxy, and with `DJANGO_SSL_REDIRECT=1` that is a
  redirect loop.
- **Never set `OUTREACH_BLOCK_SEND`** in production. It blocks SMTP *and* IMAP —
  it exists for the test suite.
- The SMTP password is never written to the database either way. If you leave it
  out of `.env`, it is typed in the browser and held only in the sending thread's
  memory, which is why §11's HTTPS is not optional.

---

## 9. Database, static files, first account

```bash
cd /opt/leadmapper/app
sudo -u leadmapper /opt/leadmapper/venv/bin/python manage.py migrate
sudo -u leadmapper /opt/leadmapper/venv/bin/python manage.py collectstatic --noinput
```

Turn on WAL journal mode. This is stored in the database file itself, so it is a
one-off — and it is what lets the background worker thread write while the
workspace polls for progress, instead of the two waiting on each other:

```bash
sudo -u leadmapper sqlite3 /opt/leadmapper/app/outreach.sqlite3 \
  "PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL;"
```

Create your account:

```bash
sudo -u leadmapper /opt/leadmapper/venv/bin/python manage.py createsuperuser
```

**If you brought an existing database over**, its campaigns and history predate
accounts and belong to nobody, which means they are visible to nobody. Claim them
once:

```bash
sudo -u leadmapper /opt/leadmapper/venv/bin/python manage.py claim_data you@example.com
```

Confirm the AI side before serving anything:

```bash
sudo -u leadmapper /opt/leadmapper/venv/bin/python manage.py ai_status --user you@example.com
```

---

## 10. Gunicorn as a service

`/etc/systemd/system/leadmapper.service`:

```ini
[Unit]
Description=Lead Mapper (Django)
After=network.target

[Service]
Type=notify
User=leadmapper
Group=leadmapper
WorkingDirectory=/opt/leadmapper/app
EnvironmentFile=/opt/leadmapper/app/.env
ExecStart=/opt/leadmapper/venv/bin/gunicorn leadmapper.wsgi:application \
          --workers 1 \
          --threads 8 \
          --timeout 120 \
          --graceful-timeout 30 \
          --bind unix:/run/leadmapper/gunicorn.sock \
          --umask 007 \
          --access-logfile - \
          --error-logfile -
RuntimeDirectory=leadmapper
RuntimeDirectoryMode=0750
Restart=always
RestartSec=5

# Hardening. The application writes only to its own directory.
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ReadWritePaths=/opt/leadmapper/app

[Install]
WantedBy=multi-user.target
```

Every flag on `ExecStart` is load-bearing:

- **`--workers 1`** — see §1. This is the one setting not to "tune".
- **`--threads 8`** — where your concurrency comes from instead. The workspace
  polls `/state` every 1.5 seconds while a run is going; threads serve that
  alongside the campaign's own worker thread.
- **`--timeout 120`** — Test Connection and Regenerate call the AI provider
  synchronously. The default 30 seconds kills them.
- **`--graceful-timeout 30`** — gives an in-flight request time to finish on
  restart.

nginx has to be able to reach that socket. `--umask 007` makes it
group-writable rather than world-writable, so add nginx's user to the group that
owns it:

```bash
sudo usermod -aG leadmapper www-data
```

Skipping this is the most common cause of a `502 Bad Gateway` with
`Permission denied` in `/var/log/nginx/error.log`.

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now leadmapper
sudo systemctl status leadmapper
sudo systemctl restart nginx          # picks up the new group membership
```

> `EnvironmentFile` does not understand quotes or `export`. Write
> `KEY=value`, one per line — which is what `.env.example` already does. A value
> containing `#` must not be quoted; systemd would keep the quotes.

---

## 11. nginx and HTTPS

`/etc/nginx/sites-available/leadmapper`:

```nginx
server {
    listen 80;
    listen [::]:80;
    server_name example.com www.example.com;

    # Django is not asked for a single static byte; nginx serves them from the
    # collectstatic output directly.
    location /static/ {
        alias /opt/leadmapper/app/staticfiles/;
        access_log off;
        expires 30d;
    }

    location / {
        proxy_pass http://unix:/run/leadmapper/gunicorn.sock;
        proxy_set_header Host              $host;
        proxy_set_header X-Real-IP         $remote_addr;
        proxy_set_header X-Forwarded-For   $proxy_add_x_forwarded_for;
        # This is the header DJANGO_TRUST_PROXY_TLS tells Django to believe.
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_redirect off;

        # A campaign start posts the whole selected lead list.
        client_max_body_size 10m;
        # The AI calls behind Regenerate and Test Connection are synchronous.
        proxy_read_timeout 120s;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/leadmapper /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx
```

Point your DNS `A` record at the Elastic IP, wait for it to resolve, then:

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d example.com -d www.example.com
```

Certbot rewrites the file to listen on 443 and installs a renewal timer. Verify
it will renew:

```bash
sudo certbot renew --dry-run
```

**Only now** set `DJANGO_SSL_REDIRECT=1` and `DJANGO_HSTS_SECONDS=31536000` in
`.env` if you had left them off, and restart. Then confirm Django agrees the
deployment is sound:

```bash
sudo systemctl restart leadmapper
cd /opt/leadmapper/app
sudo -u leadmapper env $(grep -v '^#' .env | xargs) \
  /opt/leadmapper/venv/bin/python manage.py check --deploy
```

It should print `System check identified no issues`.

---

## 12. Scheduled work

Two things want a schedule. Neither of them sends anything — a follow-up still
requires a click, by design.

**Under Docker**, the environment comes from the container, so cron is
straightforward — every command is `docker compose exec`:

```bash
crontab -e
```

```cron
# Replies and bounces, every 30 minutes. -T because cron has no TTY.
*/30 * * * * cd /home/ubuntu/leadmapper && /usr/bin/docker compose exec -T web python manage.py check_replies --user you@example.com >> /var/log/leadmapper-replies.log 2>&1

# Daily backup, into the data volume and then out to the host.
15 3 * * * cd /home/ubuntu/leadmapper && /usr/bin/docker compose exec -T web sqlite3 /data/outreach.sqlite3 ".backup '/data/backup.sqlite3'" && /usr/bin/docker compose cp web:/data/backup.sqlite3 ./backups/outreach-$(date +\%F).sqlite3

# Keep two weeks.
20 3 * * * find /home/ubuntu/leadmapper/backups -name 'outreach-*.sqlite3' -mtime +14 -delete
```

```bash
mkdir -p /home/ubuntu/leadmapper/backups
sudo touch /var/log/leadmapper-replies.log && sudo chown ubuntu /var/log/leadmapper-replies.log
```

The rest of this section is the **manual route**. Skip to the trade-off table at
the end, which applies to both.

**Cron does not read `.env`**, and the environment matters more than it looks:
without `DJANGO_SECRET_KEY` the command falls back to the development key, and any
AI credential saved through Settings then cannot be decrypted. So wrap the
commands in a script that loads the file.

`/opt/leadmapper/bin/manage` — create it, then `chmod 750` and
`chown leadmapper:leadmapper`:

```bash
#!/bin/bash
# Run a manage.py command with the production environment loaded.
set -euo pipefail
set -a                                   # export everything the file defines
source /opt/leadmapper/app/.env
set +a
cd /opt/leadmapper/app
exec /opt/leadmapper/venv/bin/python manage.py "$@"
```

Then:

```bash
sudo crontab -u leadmapper -e
```

```cron
# Read the inbox for replies and bounces, every 30 minutes. --user is required
# once the database holds more than one account.
*/30 * * * * /opt/leadmapper/bin/manage check_replies --user you@example.com >> /var/log/leadmapper-replies.log 2>&1

# Back up the database daily. One file, so a copy is a backup -- but use
# sqlite3 .backup rather than cp, which can catch a write in progress.
15 3 * * * sqlite3 /opt/leadmapper/app/outreach.sqlite3 ".backup '/opt/leadmapper/backups/outreach-$(date +\%F).sqlite3'"

# Keep two weeks.
20 3 * * * find /opt/leadmapper/backups -name 'outreach-*.sqlite3' -mtime +14 -delete
```

```bash
sudo -u leadmapper mkdir -p /opt/leadmapper/backups /opt/leadmapper/bin
sudo touch /var/log/leadmapper-replies.log
sudo chown leadmapper:leadmapper /var/log/leadmapper-replies.log
```

Check it by hand first — it is read-only and safe to run:

```bash
sudo -u leadmapper /opt/leadmapper/bin/manage check_replies \
     --user you@example.com --dry-run
```

**Automated reply checking needs the mailbox password in `.env`**
(`OUTREACH_SMTP_PASSWORD`), because nothing else can supply it at 3am. That is a
real trade-off, and it is yours to make:

| | Password in `.env` | Password typed per run |
| --- | --- | --- |
| Sending | no prompt | prompted each campaign |
| Reply checking | automatic, on this schedule | the **Check inbox** button only |
| If the box is compromised | the mailbox goes with it | it does not |

If you leave it out, drop the `check_replies` line and use the button in the
Follow-ups screen instead. The inbox is opened read-only either way, and an email
that does not match something this application sent is dropped without being
stored.

For off-box backups, add an S3 bucket with versioning, attach an IAM **instance
role** granting `s3:PutObject` on that bucket only, and append
`&& aws s3 cp /opt/leadmapper/backups/outreach-$(date +\%F).sqlite3 s3://your-bucket/`
to the backup line. Use a role rather than putting access keys on the instance.

## 13. Deploying a change

```bash
cd /opt/leadmapper/app
sudo -u leadmapper git pull                    # or rsync again, per §6
sudo -u leadmapper /opt/leadmapper/venv/bin/pip install -r requirements.txt
sudo -u leadmapper /opt/leadmapper/venv/bin/python manage.py migrate
sudo -u leadmapper /opt/leadmapper/venv/bin/python manage.py collectstatic --noinput
sudo systemctl restart leadmapper
```

**A restart kills any campaign in flight**, because the worker is a thread inside
the process being restarted. That is handled rather than fatal: the campaign is
left in a working phase with no thread behind it, the workspace detects exactly
that and offers **Resume**, and resuming skips every lead already finished — and,
within the interrupted lead, the steps it already completed. Nothing is paid for
twice. Still, prefer to deploy when nothing is running.

---

## 14. Operating it

```bash
sudo journalctl -u leadmapper -f              # application log, live
sudo journalctl -u leadmapper --since '1 hour ago' | grep -i error
sudo systemctl restart leadmapper
sudo tail -f /var/log/nginx/access.log
```

Useful checks from the app itself:

```bash
cd /opt/leadmapper/app
V=/opt/leadmapper/venv/bin/python
sudo -u leadmapper $V manage.py ai_status --user you@example.com   # which key is live
sudo -u leadmapper $V manage.py smtp_check                        # SMTP, without emailing
```

---

## 15. Cost

Roughly, in `us-east-1`, on-demand:

| | Monthly |
| --- | --- |
| t3.small | ~$15 |
| 20 GB gp3 | ~$1.60 |
| Elastic IP (attached) | free |
| Data transfer out | a few cents at this scale |
| **Total** | **~$17** |

`t4g.small` brings that to about $13. A one-year no-upfront Savings Plan takes
roughly 30% off. The AI provider and the crawling are billed by whoever provides
them, not by AWS.

---

## 16. Things that will bite, and what they look like

| Symptom | Cause | Fix |
| --- | --- | --- |
| Infinite redirect, or `ERR_TOO_MANY_REDIRECTS` | `DJANGO_SSL_REDIRECT=1` without `DJANGO_TRUST_PROXY_TLS=1` — Django cannot see that nginx already served HTTPS | set `DJANGO_TRUST_PROXY_TLS=1`, restart |
| `DisallowedHost` in the log, `400 Bad Request` in the browser | the hostname is not in `DJANGO_ALLOWED_HOSTS` | add it; include `www.` if you serve it |
| Two campaigns interfere, or a send starts twice | more than one Gunicorn worker | `--workers 1`; scale with `--threads` |
| `502 Bad Gateway` right after a deploy | Gunicorn failed to start — usually a bad `.env` line or a missing dependency | `journalctl -u leadmapper -n 50` |
| `502` with `Permission denied` on the socket in the nginx log | `www-data` is not in the `leadmapper` group | `sudo usermod -aG leadmapper www-data && sudo systemctl restart nginx` |
| Docker: the container exits immediately with `FATAL: DJANGO_SECRET_KEY is not set` | `.env` is missing, unreadable, or the key is blank | generate one, put it in `.env`, `docker compose up -d` |
| Docker: `docker compose ps` shows the container `unhealthy` | `localhost` is not in `DJANGO_ALLOWED_HOSTS`, so the healthcheck gets a 400 | add it and restart |
| Docker: CSS from the previous release after a rebuild | the static volume was not refreshed — the entrypoint does this, so it means the container did not restart | `docker compose up -d --build` (not just `build`) |
| Docker: Caddy cannot get a certificate | DNS does not point at the instance yet, or 80/443 are closed in the security group | set `SITE_ADDRESS=:80` until DNS resolves, then switch back |
| Docker: the database is empty after a redeploy | the `data` volume was removed (`docker compose down -v`) | restore from `./backups`; never use `-v` unless you mean it |
| Test Connection or Regenerate returns `504` | Gunicorn or nginx timeout below the AI call | `--timeout 120` and `proxy_read_timeout 120s` |
| Unstyled pages | `collectstatic` not run, or the nginx `alias` path is wrong | re-run it; check `/opt/leadmapper/app/staticfiles/` exists and is readable |
| `database is locked` | WAL not enabled | the `PRAGMA` in §9, or a restart under Docker |
| Settings shows "cannot be decrypted" against a saved AI key | `DJANGO_SECRET_KEY` differs from the one that encrypted it | add the key again in Settings, and keep the secret key stable from now on |
| Emails never send, no error | `OUTREACH_BLOCK_SEND` is set | remove it; it is for tests only |
| A campaign says it is crawling but nothing happens | the process restarted mid-run | the workspace offers **Resume** — take it |
| A run sits on "Paused — AI rate limit" longer than the countdown | the automatic resume runs in the browser, so it needs the tab open | press **Resume now**, or ask for the `resume_paused` management command described in the project's suggestions |

---

## 17. Before you point real leads at it

- [ ] `manage.py check --deploy` reports no issues, with the production `.env` loaded
- [ ] `https://example.com` serves, and `http://` redirects to it
- [ ] SSH is restricted to your own IP in the security group
- [ ] `.env` is `chmod 600` and owned by `leadmapper`
- [ ] The secret key is new, and recorded somewhere safe — losing it makes saved AI keys unreadable
- [ ] **The Gmail app password and the AI key that were pasted into a chat window have been rotated**
- [ ] `manage.py smtp_check` passes, and one test email to yourself arrives
- [ ] `manage.py ai_status --user you@…` shows the credential you expect
- [ ] A one-lead campaign completes end to end: crawl → findings → email → review → send
- [ ] The backup cron has produced a file in `/opt/leadmapper/backups`
- [ ] `certbot renew --dry-run` passes
