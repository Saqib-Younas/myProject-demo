# Lead Mapper

An AI lead-generation and outreach tool. It finds local businesses on a public
map, reads their websites, works out what is wrong with them, writes a personal
email about what it actually found, and sends it once you approve it.

- **Django 6.1**, server-rendered templates, vanilla JavaScript. No build step.
- **SQLite** in one file. No database server, no Redis, no task queue.
- **959 tests**, all passing.
- Every AI provider is optional and swappable: Groq, Claude, Gemini, OpenAI,
  OpenRouter.

---

## Contents

1. [What it does](#1-what-it-does)
2. [The workflow, step by step](#2-the-workflow-step-by-step)
3. [Features, point by point](#3-features-point-by-point)
4. [Rules the system will not break](#4-rules-the-system-will-not-break)
5. [Setup](#5-setup)
6. [Environment variables](#6-environment-variables)
7. [Commands](#7-commands)
8. [Routes](#8-routes)
9. [Testing](#9-testing)
10. [Troubleshooting](#10-troubleshooting)

Deployment is in **[DEPLOY.md](DEPLOY.md)** — Docker Compose or a manual install
on AWS EC2.

---

## 1. What it does

- Searches **OpenStreetMap** for businesses by country, city and category.
- Shows them on a map and in a table, with whatever contact details are published.
- Crawls each selected lead's website — its own pages only, obeying `robots.txt`.
- **Measures** the site: load time, page weight, mobile viewport, calls to action,
  forms, headings, titles, alt text, HTTPS — 38 signals per page.
- Asks the AI to turn those measurements into **evidenced findings** — never
  opinions, never anything it cannot point at.
- Scores every lead on six dimensions and gives it a priority band.
- Writes **one email per lead** built on that lead's strongest findings.
- Lets you edit, regenerate or reject each email before anything is sent.
- Sends the approved ones over your own SMTP account, at the provider's rate limit.
- Reads your inbox afterwards to match **replies and bounces** to what was sent.
- Drafts follow-ups for the ones that never answered — you press Send.
- Keeps the whole history, per account, exportable to Excel.

---

## 2. The workflow, step by step

### Search and select

1. Sign in. Every page requires it; there is no anonymous access.
2. Choose a **country**, a **city** and a **category** (restaurants, dentists,
   garages, and so on).
3. The search runs against OpenStreetMap and returns businesses with their
   address, phone, email and website where published.
4. Review them on the map or in the table. Tick the ones worth contacting.
5. Press **Start campaign**. The selected leads become a campaign.

### Set up the campaign

6. Enter the sender name, sender email and email provider.
7. Enter **what you offer**. Every email connects a website finding to this text,
   and the AI may not describe your service in any terms other than these.
8. Press **Run**. An unconfigured AI provider stops here, before a single website
   is crawled.

### Per lead, one at a time

Each lead completes all five steps before the next lead is touched. Nothing is
batched by stage.

```
Lead 1 → crawl → find issues → write email → score → save
Lead 2 → crawl → find issues → write email → score → save
Lead 3 → …
```

9. **Crawl.** Fetch `robots.txt`, discover the site's own pages from its links and
   sitemap, read the most useful ones, and measure every page.
10. **Find issues.** The AI receives the page text and the measurements and returns
    8–10 findings, each with the specific measurement behind it, what it costs the
    business, a suggested fix and a severity.
11. **Write the email.** The findings are ranked by commercial importance, the
    strongest one to three are sent to the AI as structured evidence, and it writes
    a subject and body naming those specific findings.
12. **Score.** Six sub-scores, a classification, a priority band and a recommended
    service — arithmetic over what was measured, no AI call, no cost.
13. **Save.** The lead is stamped complete. Its card appears in the workspace with
    its findings and its email together.

While this runs, the workspace shows: `Lead 7 of 25`, a percentage bar, the company
and website being read right now, which of the five steps is in flight, what is
next, the whole queue, and one **Cancel** button.

### Review

14. Read each email. The findings the email used are tagged, so you can see at a
    glance whether it is grounded or vague.
15. **Edit** it, **Regenerate** it (optionally with a note like "make it shorter"),
    **Re-review** the website, **Approve** it or **Reject** it.
16. Or **Approve all** once you trust them.

### Send

17. Press **Send**. Enter the SMTP password if it is not in `.env` — it is never
    stored in the database.
18. Emails go out one at a time, pausing between each for the provider's rate
    limit, and stopping at the daily cap.
19. Every send is recorded: to whom, what subject, when, and the `Message-ID` that
    a reply will quote.

### Follow up

20. Press **Check inbox**. Replies and bounces are matched to what was sent, by
    `Message-ID` first, then address, then subject.
21. Leads that never answered become eligible for a follow-up after 3 days, then
    7 days, up to 2 follow-ups.
22. Press **Create follow-up**. The AI drafts it from the original email and what
    was noticed on the site.
23. Read it, edit it, and press **Send follow-up**. Nothing sends itself.

---

## 3. Features, point by point

### Accounts

- Sign up, log in, log out. Sessions are cycled on login and flushed on logout.
- Deny-by-default: every view requires a session unless explicitly marked public.
- Every campaign, lead, email, reply, suppression and AI credential belongs to one
  account, enforced in the database query rather than checked afterwards.
- Reaching another account's record by changing a URL returns **404**, not 403 —
  "forbidden" would confirm the record exists.

### Lead search

- 252 countries and ~34,000 cities, offline. No geocoding API.
- Category presets plus free text.
- Results on a map with clustering, and in a sortable table.
- CSV export of any result set.
- `robots.txt` is honoured, requests to one host are spaced a second apart, and the
  crawler identifies itself with a contact address.

### Website analysis

- Discovers the site's own pages from its links and its sitemap; ranks them by
  usefulness (home, services, contact, about) and reads the best few.
- Measures **38 signals per page** — performance, mobile, SEO, content,
  conversion, trust and technical.
- A blocked or unreachable site is recorded as **unverified**, never as "no
  website". The two are completely different sales situations.
- A CAPTCHA, a login wall, a `401`, `402`, `403` or `429` stops the crawl for that
  site. Nothing is bypassed.

### Lead intelligence

- **Classification**: website found · no-website opportunity · website unverified.
- **Six sub-scores**: performance, mobile, SEO, UX & content, conversion,
  security & technical.
- **Opportunity score** and a priority band: hot · warm · low · skip.
- **Recommended service** from nine options, chosen from the measured weaknesses.
- **Email readiness score**, so you can see which leads are worth contacting now.
- **Five smart queues**: hot website leads · no-website opportunities · warm leads
  · unverified websites · skip.
- **Thirteen lifecycle stages** from `new` through `qualified`, `email_ready`,
  `contacted`, `replied`, `interested`, `meeting`, `won` / `lost`.
- A lead detail page with the sub-scores, every finding and its evidence, and a
  "why this is a good prospect" explanation.
- Opening a lead page never crawls anything. Audits are cached per domain and
  refreshed on request or after 30 days.

### The email

- Built on the **actual findings from that lead's crawl** — the pages read, the
  measurements taken, and the one to three findings that matter commercially.
- Findings are prioritised in this order: broken functionality → conversion and
  customer journey → mobile usability → speed → missing content → search
  visibility → technical detail.
- Measurements are context for the AI and are **forbidden in the email**.
  `LCP = 4.8s` becomes "the homepage takes noticeably longer to load on mobile".
- A draft that says "I noticed some issues with your website", or that quotes a
  metric at a business owner, is **detected and regenerated** with the specific
  failure as the note.
- Two audit fields come back with every email: what specifically it refers to, and
  which findings it used.
- Businesses with no website get a different email entirely — about what a site
  would make easier, with no critique of a site nobody has seen.
- Every email closes with an invitation to reply, and carries a
  `List-Unsubscribe` header.

### Duplicate prevention and do-not-contact

- The same address cannot enter one campaign twice.
- An address contacted before is flagged, with when and in which campaign.
- **Contact anyway** exists as a deliberate, recorded override.
- A do-not-contact list of addresses and whole domains, checked before the send is
  reserved — and it cannot be overridden, not even by "contact anyway".
- The final guarantee is a database constraint, so two concurrent send threads
  cannot both send to the same person.

### Sending

- Gmail, Outlook, Zoho, Fastmail or a custom SMTP host.
- Always authenticated. The `From` header is built from the address you logged in
  as, so there is no code path that can spoof a sender.
- One message at a time, spaced for the provider, stopping at its daily cap.
- The SMTP password is never written to the database — it is held only in the
  sending thread's memory.

### Replies and follow-ups

- Read-only IMAP. Nothing is marked read, and an email that does not match
  something this application sent is dropped without being stored.
- Five statuses per sent lead: sent · replied · bounced · no reply · unsubscribed.
- Follow-up eligibility after configurable delays (3 and 7 days by default), to a
  configurable maximum (2).
- A follow-up is drafted by the AI and sent only by a click. There is no scheduler
  and no automatic send path.
- Six conditions are re-checked immediately before the connection opens.

### AI credentials

- Providers are parents; the keys you add under them are children. **One is
  active** and every AI feature uses it.
- Add as many keys per provider as you like, name them, and switch which is active
  in one click.
- Resolution order: **active credential → environment variable → a clear error**.
- Keys are encrypted at rest with Fernet, shown only as `sk-proj-••••••••9X2A`, and
  never returned to the browser.
- Per credential: when it was added, when it was last used, how many requests it
  served, how many failed, and the last error category.
- An optional fallback: a spare key you mark may be tried **once** when the active
  one is rate limited. It never changes which key is active, and every use is
  recorded.

### AI rate limits

- A rate limit pauses the **whole run** rather than being retried per lead. A
  provider that refuses one request will refuse the next twenty-four.
- `RUNNING → PAUSED_RATE_LIMIT → RUNNING`.
- The position is saved. Every lead already finished keeps its completion stamp.
- `Retry-After` is respected — from the header or from "try again in 8.5s" in the
  message. With no answer, exponential backoff: 30s, 60s, 120s, 240s, capped at
  15 minutes.
- A **temporary limit** is waited out. An **exhausted quota** is not — waiting
  cannot fix it, so the run stops and offers a link to switch provider or key.
- After five pauses in one run it stays paused and waits for a person.

### Cancelling

- One Cancel button for the job. `RUNNING → CANCEL_REQUESTED → CANCELLED`.
- Checked before every lead **and** before every page fetch, so a running crawl
  stops within one page.
- The lead being written finishes; nothing new starts.
- Completed leads stay completed. Resuming later starts at the first unfinished one.
- Idempotent: pressing it twice changes nothing.
- Cancellation beats an automatic retry. A cancelled run never resumes on its own.

### Resuming

- A server restart mid-campaign leaves the phase saying `crawling` with no thread
  behind it. The workspace detects exactly that and offers **Resume**.
- Resuming skips every finished lead, and within an interrupted lead, the steps it
  already completed. A crawl already paid for is not paid for twice.
- An interrupted **send** is different: the password is not stored, so the queue is
  released back to approved and you press Send again. Anything already delivered
  is in the history and cannot go out twice.

### History and reporting

- Per-campaign report: what was sent, what failed and why.
- Full sending history per account, with an Excel export split by country.
- Dashboard with live counts, the five queues, and reply statistics.

---

## 4. Rules the system will not break

- **The AI may never invent a website problem.** Every finding must cite a
  measured signal or a quoted phrase. Unevidenced findings are discarded in code
  before the prompt is even built.
- **The AI may never invent a business fact** — revenue, customer numbers,
  traffic, rankings, company size, technology, contact details. Where something is
  not known it says `Unknown` or `Not detected`.
- **The AI may never invent your service.** It describes your offer only in the
  words you supplied.
- **No email sends itself.** Not the first one, and not a follow-up whose waiting
  period has passed.
- **No sender address is ever spoofed.**
- **No CAPTCHA, login wall or anti-bot protection is ever bypassed.**
- **No API key reaches the browser**, a log, a URL, an error message or an audit
  row. Tests scan the rendered pages and every endpoint response to prove it.
- **The inbox is read-only**, and unrelated email is never stored.
- **A do-not-contact entry cannot be overridden.**

---

## 5. Setup

### With Docker

```bash
cp .env.example .env       # fill in DJANGO_SECRET_KEY and one provider key
cp docker-compose.override.yml.example docker-compose.override.yml
docker compose up --build
docker compose exec web python manage.py createsuperuser
# http://localhost:8000
```

### Without Docker

```bash
python -m venv .venv
.venv\Scripts\activate                # Windows
# source .venv/bin/activate           # macOS / Linux

pip install -r requirements.txt
cp .env.example .env                  # then edit it
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Then sign in at `http://127.0.0.1:8000/`.

Only the SDK for the provider you actually use is needed — the backends are
imported lazily.

---

## 6. Environment variables

Everything lives in a git-ignored `.env`. `.env.example` is the committed
template. **Never put a real password or key in a tracked file.**

### Django

| Variable | Required | Notes |
| --- | --- | --- |
| `DJANGO_SECRET_KEY` | In production | Signs sessions **and** derives the encryption key for saved AI credentials. Keep it stable. |
| `DJANGO_DEBUG` | No | `1` for local development |
| `DJANGO_ALLOWED_HOSTS` | In production | Comma-separated |
| `DJANGO_SSL_REDIRECT` | No | `1` behind HTTPS |
| `DJANGO_HSTS_SECONDS` | No | e.g. `31536000` |
| `DJANGO_TRUST_PROXY_TLS` | Behind a proxy | `1` when nginx or Caddy terminates TLS |
| `DJANGO_DATA_DIR` | No | Where the database and exports live. Defaults to the project directory. |

### Sending

| Variable | Required | Notes |
| --- | --- | --- |
| `OUTREACH_SENDER_EMAIL` | Yes | The authenticated address |
| `OUTREACH_SENDER_NAME` | Yes | |
| `OUTREACH_SENDER_COMPANY` | No | |
| `OUTREACH_PROVIDER` | Yes | `gmail` · `outlook` · `zoho` · `fastmail` · `custom` |
| `OUTREACH_SMTP_PASSWORD` | No | Leave it out and the browser prompts per run |
| `OUTREACH_SMTP_HOST` / `_PORT` | Only for `custom` | |
| `OUTREACH_BLOCK_SEND` | No | `1` blocks SMTP **and** IMAP. For tests. Never set it in production. |

### Replies and follow-ups

| Variable | Required | Notes |
| --- | --- | --- |
| `OUTREACH_IMAP_HOST` / `_PORT` | No | Defaults from the sending provider |
| `OUTREACH_INBOX_DAYS` | No | How far back to look. Default 45. |
| `OUTREACH_FOLLOWUP_MAX` | No | Default 2 |
| `OUTREACH_FOLLOWUP_DELAYS` | No | Default `3,7` (days) |

### AI

| Variable | Required | Notes |
| --- | --- | --- |
| `OUTREACH_AI_PROVIDER` | No | `groq` · `claude` · `gemini` · `openai` · `openrouter`. A choice made in Settings wins. |
| `OUTREACH_AI_MODEL` | No | Per-credential models in Settings win |
| `GROQ_API_KEY`, `ANTHROPIC_API_KEY`, `GEMINI_API_KEY`, `OPENAI_API_KEY`, `OPENROUTER_API_KEY` | No | Used when no credential is active for that provider |
| `OUTREACH_CREDENTIALS_UI` | No | `0` closes the credential write endpoints and takes keys only from `.env` |
| `OUTREACH_AI_CONTEXT_CHARS` | No | Crawl material sent to the reviewer. Default 9000. |
| `OUTREACH_AI_AUDIT_TOKENS` / `_EMAIL_TOKENS` / `_FOLLOWUP_TOKENS` | No | Reply size ceilings |

### Scoring

| Variable | Required | Notes |
| --- | --- | --- |
| `OUTREACH_PRIORITY_HOT` / `_WARM` / `_LOW` | No | Band thresholds. Default 80 / 60 / 40. |
| `OUTREACH_READINESS_MIN` | No | Default 60 |
| `OUTREACH_AUDIT_MAX_AGE_DAYS` | No | Default 30 |
| `OSM_CONTACT_EMAIL` | Yes | Sent in the crawler's User-Agent, as OpenStreetMap's policy asks |

---

## 7. Commands

| Command | What it does |
| --- | --- |
| `python manage.py runserver` | Start the development server |
| `python manage.py migrate` | Apply migrations |
| `python manage.py createsuperuser` | Create an account |
| `python manage.py test` | Run all 959 tests. Sends nothing, contacts nothing. |
| `python manage.py ai_status` | Which AI provider and credential are active |
| `python manage.py ai_status --user you@example.com` | Include that account's saved credentials |
| `python manage.py ai_status --live` | Generate one throwaway email to prove it works |
| `python manage.py smtp_check` | Verify SMTP without emailing anybody |
| `python manage.py check_replies --user you@example.com` | Read the inbox once |
| `python manage.py claim_data you@example.com` | Assign pre-accounts rows to an account |
| `python manage.py check --deploy` | Production readiness |

---

## 8. Routes

| Method | Path | Purpose |
| --- | --- | --- |
| GET | `/` | Lead search |
| GET/POST | `/login`, `/signup`, `/logout` | Accounts |
| GET | `/dashboard` | Sales dashboard |
| POST | `/api/search` | Run a search |
| GET | `/api/export/<job_id>` | Download a CSV |
| POST | `/outreach/start` | Turn selected leads into a campaign |
| GET | `/outreach/<id>/setup` | Sender settings and lead table |
| POST | `/outreach/<id>/run` | Start crawl → findings → email |
| GET | `/outreach/<id>/` | Review workspace |
| GET | `/outreach/<id>/state` | Live progress (polled) |
| POST | `/outreach/<id>/cancel` | Stop the job |
| POST | `/outreach/<id>/resume` | Pick up a paused, cancelled or interrupted run |
| POST | `/outreach/draft/<pk>/<action>` | `save` · `regenerate` · `rereview` · `approve` · `reject` · `recontact` · `suppress` |
| POST | `/outreach/<id>/approve-all` | Approve every draft |
| POST | `/outreach/<id>/send` | Start the send |
| GET | `/outreach/<id>/report` | Campaign report |
| GET | `/outreach/leads` | Lead intelligence table |
| GET | `/outreach/lead/<pk>/intel` | Lead detail |
| POST | `/outreach/lead/<pk>/reanalyse` | Refresh the audit |
| POST | `/outreach/lead/<pk>/lifecycle` | Move the lifecycle stage |
| GET | `/outreach/followups` | Replies and follow-up review |
| POST | `/outreach/followups/check-inbox` | Read the inbox |
| POST | `/outreach/lead/<pk>/followup` | Draft a follow-up (sends nothing) |
| POST | `/outreach/followup/<pk>/<action>` | `save` · `regenerate` · `cancel` · `send` |
| GET/POST | `/outreach/suppressions…` | Do-not-contact list |
| GET | `/outreach/settings` | Configuration and the AI credential pool |
| POST | `/outreach/ai/select` | Choose the provider (sends a name, never a key) |
| POST | `/outreach/ai/credentials/<provider>/add` | Add a credential |
| POST | `/outreach/ai/credentials/<id>/activate` · `deactivate` · `test` · `fallback` · `delete` | Manage one credential |
| GET | `/outreach/ai/credentials/events` | Recent credential history (no keys) |
| POST | `/outreach/rescore` | Re-score every lead from what is already known |
| GET | `/outreach/history`, `/outreach/history.xlsx` | History and Excel export |

---

## 9. Testing

```bash
python manage.py test                          # everything
python manage.py test outreach.test_evidence   # the findings behind each email
python manage.py test outreach.test_runcontrol # rate-limit pauses and cancel
python manage.py test outreach.test_credentials
python manage.py test accounts
```

- **959 tests**, about a minute.
- **Nothing leaves the machine.** `OUTREACH_BLOCK_SEND` is forced on under
  `manage.py test`, which blocks SMTP and IMAP, and every AI call and HTTP fetch is
  a double. A test asserts that this is on.
- Lint with `ruff check .`

---

## 10. Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
| "OpenAI is not configured…" | No active credential and no environment key | Add one in Settings → AI credentials |
| Every lead fails with the same AI error | Missing or rejected key | `python manage.py ai_status --user you@…` |
| The run says "Paused — AI rate limit" | The provider refused; the run kept its place | Wait for the countdown, or press **Resume now** |
| Paused with "quota exhausted" | A daily or billing allowance is spent | Switch provider or credential, then resume |
| Gmail rejects the password | An account password was used | Use an **App Password** |
| A campaign says it is crawling but nothing happens | The server restarted mid-run | Press **Resume** |
| Emails look generic | The site could not be crawled, so there were no findings | The card says so; the email makes no claim about the site |
| A saved AI key reads "cannot be decrypted" | `DJANGO_SECRET_KEY` changed | Add the key again, and keep the secret key stable |
| Nothing sends and there is no error | `OUTREACH_BLOCK_SEND` is set | Remove it |
| `database is locked` | WAL not enabled on a busy install | `sqlite3 outreach.sqlite3 "PRAGMA journal_mode=WAL;"` |
| Old campaigns are invisible after adding accounts | They belong to nobody | `python manage.py claim_data you@example.com` |

---

## Licence and attribution

- Business data from **OpenStreetMap**, © OpenStreetMap contributors, ODbL.
- Nominatim's usage policy is respected: one request per second per host, and a
  contact address in the User-Agent.
- Use it only for outreach you are entitled to send, under the marketing and
  privacy law that applies to you.
