"""
Django settings for the Lead Mapper.

Kept as small as the feature set allows. It grew in three steps, and the comments
explain each: SQLite arrived with the sending history, and `django.contrib.auth`
arrived with per-user accounts once the application started holding one user's
prospect list separately from another's.

Authentication uses Django's own auth app rather than anything hand-rolled --
sessions, password hashing, and the login-required middleware are all framework
features here, which is both less code and less to get wrong.
"""

import os
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

#: Where everything the application *writes* lives: the SQLite database and the
#: CSV/Excel exports.
#:
#: Separate from BASE_DIR because of containers. In an image the code directory is
#: replaced on every deploy, so a database inside it would be a new empty database
#: each time -- this is the one path a volume gets mounted at. Defaults to
#: BASE_DIR, so a local checkout is unchanged and needs no configuration.
DATA_DIR = Path(os.environ.get("DJANGO_DATA_DIR") or BASE_DIR)


def _load_env(path: Path = BASE_DIR / ".env") -> None:
    """Read KEY=VALUE lines from .env into the environment.

    Keeps the live SMTP password in a git-ignored file instead of in this
    source file. A real environment variable always wins, so CI and one-off
    shell overrides still work.
    """
    if not path.is_file():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip().strip("\"'"))


_load_env()

# Fine as-is for local use. Set the env var before exposing this anywhere.
SECRET_KEY = os.environ.get("DJANGO_SECRET_KEY", "dev-only-not-a-secret")
DEBUG = os.environ.get("DJANGO_DEBUG", "1") == "1"

ALLOWED_HOSTS = (
    ["*"] if DEBUG
    else [h for h in os.environ.get("DJANGO_ALLOWED_HOSTS", "").split(",") if h]
)

INSTALLED_APPS = [
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "accounts",
    "leads",
    "outreach",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    # Django's own middleware, added in 5.1: every view requires a logged-in
    # user unless it is explicitly marked otherwise with @login_not_required.
    # Deny-by-default is the point -- a new view added later is protected
    # without anybody remembering to protect it.
    "django.contrib.auth.middleware.LoginRequiredMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    # Sends X-Frame-Options: DENY. Now that there are sessions, a page framed by
    # another site is a clickjacking target -- an invisible frame over a
    # convincing decoy can turn a stray click into a real, authenticated action.
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    # Binds the signed-in account to the AI credential resolver for the length of
    # the request. Without it, code three layers down -- ai.generate() ->
    # backend().complete() -> client() -> credentials.require() -- would have no
    # way to know whose API key to use, and threading an owner argument through
    # all of it would break the first time somebody forgot.
    "outreach.aicontext.AiOwnerMiddleware",
]

ROOT_URLCONF = "leadmapper.urls"
WSGI_APPLICATION = "leadmapper.wsgi.application"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

# SQLite, purely so the email workflow can keep its sending history and refuse
# to contact the same lead twice. The scraper still uses no database at all.
# `timeout` matters: the background analyse/generate/send jobs write from a
# worker thread while the page polls for progress from the request thread.
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": DATA_DIR / "outreach.sqlite3",
        "OPTIONS": {"timeout": 20},
    }
}

# --------------------------------------------------------------------------- #
# Authentication
# --------------------------------------------------------------------------- #

#: Email is the login identifier, so the backend looks users up by email
#: (case-insensitively) rather than by username. ModelBackend stays in the list
#: so `createsuperuser` and the admin-style username path keep working.
AUTHENTICATION_BACKENDS = [
    "accounts.backends.EmailBackend",
    "django.contrib.auth.backends.ModelBackend",
]

LOGIN_URL = "/login"
LOGIN_REDIRECT_URL = "/dashboard"
LOGOUT_REDIRECT_URL = "/login"

#: Django's standard validators. Rejecting a password is cheaper than dealing
#: with a compromised account, and the messages are already written and
#: translated.
AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation."
             "UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
     "OPTIONS": {"min_length": 10}},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

# Session cookies. HttpOnly and SameSite are set explicitly rather than left to
# the defaults so the intent is visible: no JavaScript reads the session, and it
# is not sent on cross-site requests.
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = "Lax"
CSRF_COOKIE_SAMESITE = "Lax"
#: Two weeks, refreshed on each request so an active user is not logged out
#: mid-campaign, and an idle one expires.
SESSION_COOKIE_AGE = 60 * 60 * 24 * 14
SESSION_SAVE_EVERY_REQUEST = True
SESSION_EXPIRE_AT_BROWSER_CLOSE = False

#: Password hashing is deliberately slow -- that is the point of PBKDF2. Under
#: `manage.py test` it becomes the dominant cost, because every test signs an
#: account in, so the suite uses a fast hasher instead. Never enabled outside
#: tests: MD5 is worthless for storing a real password.
if "test" in sys.argv:
    PASSWORD_HASHERS = ["django.contrib.auth.hashers.MD5PasswordHasher"]

#: Cookies over HTTPS only, off in DEBUG because local development is plain
#: HTTP and a Secure cookie would never be sent.
SESSION_COOKIE_SECURE = not DEBUG
CSRF_COOKIE_SECURE = not DEBUG

#: HTTPS enforcement, opt-in rather than on by default.
#:
#: Both of these break a site that is not actually served over HTTPS -- a
#: redirect loop in one case, and a browser that refuses to connect for the
#: length of the HSTS window in the other. HSTS in particular is hard to undo,
#: because the browser remembers it. So they are switched on by the deployment
#: that knows it has a certificate, not by a default that assumes one.
SECURE_SSL_REDIRECT = os.environ.get("DJANGO_SSL_REDIRECT") == "1"
SECURE_HSTS_SECONDS = int(os.environ.get("DJANGO_HSTS_SECONDS", "0") or 0)
SECURE_HSTS_INCLUDE_SUBDOMAINS = SECURE_HSTS_SECONDS > 0
SECURE_HSTS_PRELOAD = SECURE_HSTS_SECONDS > 0

#: Behind a reverse proxy that terminates TLS, this is how Django learns the
#: original request was HTTPS. Only trusted when the deployment says so: setting
#: it without a proxy that overwrites the header lets a client claim HTTPS.
if os.environ.get("DJANGO_TRUST_PROXY_TLS") == "1":
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")

STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "staticfiles"

LANGUAGE_CODE = "en-us"
TIME_ZONE = "UTC"
USE_I18N = True
USE_TZ = True

# --------------------------------------------------------------------------- #
# App settings
# --------------------------------------------------------------------------- #

#: Where generated CSV files are written.
EXPORT_DIR = DATA_DIR / "exports"

#: Nominatim's usage policy asks for a contact address in the User-Agent so
#: they can get in touch if this app ever misbehaves. It has to be a real
#: address -- placeholders like you@example.com are answered with a 403 -- so
#: this defaults to the address the project was set up with. Change it, or set
#: OSM_CONTACT_EMAIL, if a different mailbox should own the traffic.
OSM_CONTACT_EMAIL = os.environ.get(
    "OSM_CONTACT_EMAIL", "muhammadsaqibyounas11@gmail.com"
)

# --------------------------------------------------------------------------- #
# Outreach sender identity
# --------------------------------------------------------------------------- #

#: Default identity for outreach campaigns. These pre-fill the sender form on
#: the setup page; each campaign stores whatever was submitted, so a one-off can
#: still be sent from a different account by editing the form.
#:
#: The address must be one you can actually log in to over SMTP -- it becomes
#: the From header, and outreach/sender.py refuses to send if the visible sender
#: and the SMTP login differ. For Gmail that means a 16-character App Password,
#: not the account password: Google rejects plain passwords on SMTP.
OUTREACH_SENDER_EMAIL = os.environ.get(
    "OUTREACH_SENDER_EMAIL", "muhammadsaqibyounas11@gmail.com"
)
OUTREACH_SENDER_NAME = os.environ.get(
    "OUTREACH_SENDER_NAME", "Muhammad Saqib Younas"
)
OUTREACH_SENDER_COMPANY = os.environ.get("OUTREACH_SENDER_COMPANY", "7skysolutions")

#: Matches the address above -- see PROVIDERS in outreach/sender.py.
OUTREACH_PROVIDER = os.environ.get("OUTREACH_PROVIDER", "gmail")

#: Hard block on opening an SMTP connection, on by default under `manage.py
#: test`. Real credentials now live in .env, so without this a stray test that
#: reached the send path could authenticate against Gmail and mail live people.
#: The suite mocks the transport anyway; this makes the mistake impossible
#: rather than merely unlikely.
OUTREACH_BLOCK_SEND = os.environ.get("OUTREACH_BLOCK_SEND") == "1" or "test" in sys.argv

# --------------------------------------------------------------------------- #
# Reply tracking and manual follow-ups
# --------------------------------------------------------------------------- #

#: How many follow-ups a single lead may ever receive. Reaching it closes the
#: lead to further follow-ups; the deliberate re-contact workflow is separate.
OUTREACH_FOLLOWUP_MAX = int(os.environ.get("OUTREACH_FOLLOWUP_MAX", "2"))

#: Days to wait before each follow-up becomes available, counted from the last
#: message actually sent to that lead. One entry per follow-up: the first number
#: gates follow-up #1, the second gates #2. A shorter list than
#: OUTREACH_FOLLOWUP_MAX reuses its final value for the remaining numbers.
OUTREACH_FOLLOWUP_DELAYS = [
    int(part) for part in
    os.environ.get("OUTREACH_FOLLOWUP_DELAYS", "3,7").replace(" ", "").split(",")
    if part
] or [3]

#: Where to read replies. Blank means "use the provider preset in
#: outreach/sender.py" -- the same account and password as sending, never a
#: second credential.
OUTREACH_IMAP_HOST = os.environ.get("OUTREACH_IMAP_HOST", "")
OUTREACH_IMAP_PORT = int(os.environ.get("OUTREACH_IMAP_PORT", "0") or 0)

#: How far back an inbox check looks. Replies older than this are assumed to
#: have been seen already, and it keeps the IMAP search cheap on a busy mailbox.
OUTREACH_INBOX_DAYS = int(os.environ.get("OUTREACH_INBOX_DAYS", "45"))

# --------------------------------------------------------------------------- #
# Lead scoring
# --------------------------------------------------------------------------- #

#: Outreach priority bands. A lead scoring at or above HOT is hot, and so on
#: down; below LOW it is a skip. Configurable because "worth emailing" depends on
#: how much list a user has to work through -- somebody with 2,000 leads can
#: afford to be pickier than somebody with 40.
OUTREACH_PRIORITY_HOT = int(os.environ.get("OUTREACH_PRIORITY_HOT", "80"))
OUTREACH_PRIORITY_WARM = int(os.environ.get("OUTREACH_PRIORITY_WARM", "60"))
OUTREACH_PRIORITY_LOW = int(os.environ.get("OUTREACH_PRIORITY_LOW", "40"))

#: Below this, the application does not recommend sending: it means there is not
#: enough reliable material to write anything worth reading. Advisory -- the user
#: can still send.
OUTREACH_READINESS_MIN = int(os.environ.get("OUTREACH_READINESS_MIN", "60"))

#: How long a stored website audit stays fresh. A stale audit is still used and
#: still shown; the lead page offers a re-analysis rather than silently spending
#: a crawl on page load.
OUTREACH_AUDIT_MAX_AGE_DAYS = int(
    os.environ.get("OUTREACH_AUDIT_MAX_AGE_DAYS", "30"))
